"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.WAZUH_ALERTS_INDEX_PATTERN = exports.VALUELESS_OPERATORS = exports.TLP_LEVELS = exports.THEME = exports.STATUS_TRANSITIONS = exports.SMTP_SECURITY_OPTIONS = exports.SMTP_DEFAULT_TIMEOUT_MS = exports.SMTP_AUTH_TYPES = exports.SETTINGS_INDEX = exports.PLUGIN_NAME = exports.PLUGIN_ID = exports.PLUGIN_DESCRIPTION = exports.OBSERVABLE_TYPES = exports.NOTIFICATION_INDEX = exports.NOTIFICATION_EVENTS = exports.NOTIFICATION_CHANNEL_TYPES = exports.MONITOR_OPERATORS = exports.MONITOR_FIELDS = exports.MONITOR_CONFIG_INDEX = exports.MAX_PAGE_SIZE = exports.LEVEL_SEVERITY_MAP = exports.EXTERNAL_API_PREFIX = exports.ESCALATION_ACTIONS = exports.DEFAULT_SORT_ORDER = exports.DEFAULT_SORT_FIELD = exports.DEFAULT_PAGE_SIZE = exports.CHANNEL_AUTH_TYPES = exports.CASE_STATUSES = exports.CASE_SEVERITIES = exports.CASE_PRIORITIES = exports.CASE_INDEX_PATTERN = exports.CASE_INDEX = exports.CASE_ID_SEPARATOR = exports.CASE_ID_PREFIX = exports.CASE_ID_PADDING = exports.CASE_ID_INCLUDE_YEAR = exports.CASE_COUNTER_INDEX = exports.CASE_CATEGORIES = exports.API_ROUTES = exports.API_PREFIX = exports.API_KEY_TOKEN_PREFIX = exports.API_KEY_HEADER = void 0;
/*
 * Wazuh Case Management Plugin
 * Shared constants between server and client
 */

// ─── Plugin Identification ────────────────────────────────────
const PLUGIN_ID = exports.PLUGIN_ID = 'wazuhCaseManagement';
const PLUGIN_NAME = exports.PLUGIN_NAME = 'Case Management';
const PLUGIN_DESCRIPTION = exports.PLUGIN_DESCRIPTION = 'Security incident case management for Wazuh';

// ─── OpenSearch Index ─────────────────────────────────────────
const CASE_INDEX = exports.CASE_INDEX = 'wazuh-case-management-cases';
const CASE_INDEX_PATTERN = exports.CASE_INDEX_PATTERN = 'wazuh-case-management-*';
const CASE_COUNTER_INDEX = exports.CASE_COUNTER_INDEX = 'wazuh-case-management-counter';
const MONITOR_CONFIG_INDEX = exports.MONITOR_CONFIG_INDEX = 'wazuh-case-management-monitor';
const SETTINGS_INDEX = exports.SETTINGS_INDEX = 'wazuh-case-management-settings';
const NOTIFICATION_INDEX = exports.NOTIFICATION_INDEX = 'wazuh-case-management-notifications';

// ─── Wazuh Alert Index ────────────────────────────────────────
const WAZUH_ALERTS_INDEX_PATTERN = exports.WAZUH_ALERTS_INDEX_PATTERN = 'wazuh-alerts-*';

// ─── API Routes ───────────────────────────────────────────────
const API_PREFIX = exports.API_PREFIX = '/api/wazuh-case-management';
const API_ROUTES = exports.API_ROUTES = {
  // Cases
  CASES: `${API_PREFIX}/cases`,
  CASE_BY_ID: `${API_PREFIX}/cases/{id}`,
  CASE_STATUS: `${API_PREFIX}/cases/{id}/status`,
  CASE_ASSIGN: `${API_PREFIX}/cases/{id}/assign`,
  // Comments
  CASE_COMMENTS: `${API_PREFIX}/cases/{id}/comments`,
  CASE_COMMENT_BY_ID: `${API_PREFIX}/cases/{id}/comments/{commentId}`,
  // Alerts
  CASE_ALERTS: `${API_PREFIX}/cases/{id}/alerts`,
  CASE_ALERT_BY_ID: `${API_PREFIX}/cases/{id}/alerts/{alertId}`,
  ALERTS_SEARCH: `${API_PREFIX}/alerts/search`,
  // Observables
  CASE_OBSERVABLES: `${API_PREFIX}/cases/{id}/observables`,
  CASE_OBSERVABLE_BY_ID: `${API_PREFIX}/cases/{id}/observables/{observableId}`,
  // Analytics
  ANALYTICS_SUMMARY: `${API_PREFIX}/analytics/summary`,
  ANALYTICS_TRENDS: `${API_PREFIX}/analytics/trends`,
  // Settings
  SETTINGS: `${API_PREFIX}/settings`,
  // Users
  ME: `${API_PREFIX}/me`,
  USERS: `${API_PREFIX}/users`,
  // Auto Monitor
  MONITOR: `${API_PREFIX}/monitor`,
  MONITOR_STATUS: `${API_PREFIX}/monitor/status`,
  MONITOR_TEST: `${API_PREFIX}/monitor/test`,
  // Notifications
  NOTIFICATIONS: `${API_PREFIX}/notifications`,
  NOTIFICATIONS_READ: `${API_PREFIX}/notifications/read`,
  NOTIFICATION_BY_ID: `${API_PREFIX}/notifications/{notificationId}`,
  // Notification channel test delivery
  NOTIFICATION_CHANNEL_TEST: `${API_PREFIX}/settings/notifications/test`,
  SMTP_TEST: `${API_PREFIX}/settings/smtp/test`,
  // API keys
  API_KEYS: `${API_PREFIX}/settings/api-keys`,
  API_KEY_BY_ID: `${API_PREFIX}/settings/api-keys/{keyId}`,
  // Tasks
  CASE_TASKS: `${API_PREFIX}/cases/{id}/tasks`,
  CASE_TASK_BY_ID: `${API_PREFIX}/cases/{id}/tasks/{taskId}`,
  // Escalation
  ESCALATION_RUN: `${API_PREFIX}/escalation/run`
};

/** Prefix of the external, API-key authenticated surface. */
const EXTERNAL_API_PREFIX = exports.EXTERNAL_API_PREFIX = `${API_PREFIX}/external`;

/** Header carrying the API key on external requests. */
const API_KEY_HEADER = exports.API_KEY_HEADER = 'x-cm-api-key';

/** Human-readable prefix of every generated API key. */
const API_KEY_TOKEN_PREFIX = exports.API_KEY_TOKEN_PREFIX = 'wcm';

// ─── Case ID Configuration ───────────────────────────────────
// These are the *fallback defaults*. The effective format is stored in the
// settings index and is editable from Settings → Case ID Format.
const CASE_ID_PREFIX = exports.CASE_ID_PREFIX = 'CASE';
const CASE_ID_SEPARATOR = exports.CASE_ID_SEPARATOR = '-';
const CASE_ID_PADDING = exports.CASE_ID_PADDING = 4;
const CASE_ID_INCLUDE_YEAR = exports.CASE_ID_INCLUDE_YEAR = true;

// ─── Status Definitions ──────────────────────────────────────
// Colors use the OpenSearch/Wazuh visualization palette (ouiPaletteColorBlind)
const CASE_STATUSES = exports.CASE_STATUSES = [{
  value: 'open',
  label: 'Open',
  color: '#6092C0',
  icon: 'folderOpen'
}, {
  value: 'in_progress',
  label: 'In Progress',
  color: '#9170B8',
  icon: 'playFilled'
}, {
  value: 'waiting',
  label: 'Waiting',
  color: '#D6BF57',
  icon: 'clock'
}, {
  value: 'resolved',
  label: 'Resolved',
  color: '#54B399',
  icon: 'checkInCircleFilled'
}, {
  value: 'closed',
  label: 'Closed',
  color: '#98A2B3',
  icon: 'cross'
}];

// Valid status transitions
const STATUS_TRANSITIONS = exports.STATUS_TRANSITIONS = {
  open: ['in_progress', 'waiting', 'closed'],
  in_progress: ['waiting', 'resolved', 'closed'],
  waiting: ['in_progress', 'resolved', 'closed'],
  resolved: ['closed', 'in_progress'],
  // can reopen
  closed: ['open'] // can reopen
};

// ─── Severity Definitions ────────────────────────────────────
const CASE_SEVERITIES = exports.CASE_SEVERITIES = [{
  value: 'informational',
  label: 'Informational',
  color: '#98A2B3',
  order: 0
}, {
  value: 'low',
  label: 'Low',
  color: '#54B399',
  order: 1
}, {
  value: 'medium',
  label: 'Medium',
  color: '#D6BF57',
  order: 2
}, {
  value: 'high',
  label: 'High',
  color: '#DA8B45',
  order: 3
}, {
  value: 'critical',
  label: 'Critical',
  color: '#E7664C',
  order: 4
}];

// ─── Priority Definitions ────────────────────────────────────
const CASE_PRIORITIES = exports.CASE_PRIORITIES = [{
  value: 'P1',
  label: 'P1 (Urgent)',
  color: '#E7664C',
  order: 0
}, {
  value: 'P2',
  label: 'P2 (High)',
  color: '#DA8B45',
  order: 1
}, {
  value: 'P3',
  label: 'P3 (Medium)',
  color: '#D6BF57',
  order: 2
}, {
  value: 'P4',
  label: 'P4 (Low)',
  color: '#98A2B3',
  order: 3
}];

// ─── Category Definitions ────────────────────────────────────
const CASE_CATEGORIES = exports.CASE_CATEGORIES = [{
  value: 'malware',
  label: 'Malware',
  icon: 'bug'
}, {
  value: 'intrusion_attempt',
  label: 'Intrusion Attempt',
  icon: 'lock'
}, {
  value: 'data_exfiltration',
  label: 'Data Exfiltration',
  icon: 'exportAction'
}, {
  value: 'policy_violation',
  label: 'Policy Violation',
  icon: 'alert'
}, {
  value: 'vulnerability',
  label: 'Vulnerability',
  icon: 'securitySignal'
}, {
  value: 'phishing',
  label: 'Phishing',
  icon: 'email'
}, {
  value: 'denial_of_service',
  label: 'Denial of Service',
  icon: 'offline'
}, {
  value: 'insider_threat',
  label: 'Insider Threat',
  icon: 'user'
}, {
  value: 'unauthorized_access',
  label: 'Unauthorized Access',
  icon: 'crossInACircleFilled'
}, {
  value: 'other',
  label: 'Other',
  icon: 'questionInCircle'
}];

// ─── Observable Type Definitions ─────────────────────────────
const OBSERVABLE_TYPES = exports.OBSERVABLE_TYPES = [{
  value: 'ip',
  label: 'IP Address'
}, {
  value: 'domain',
  label: 'Domain'
}, {
  value: 'url',
  label: 'URL'
}, {
  value: 'hash_md5',
  label: 'Hash (MD5)'
}, {
  value: 'hash_sha1',
  label: 'Hash (SHA-1)'
}, {
  value: 'hash_sha256',
  label: 'Hash (SHA-256)'
}, {
  value: 'email',
  label: 'Email Address'
}, {
  value: 'filename',
  label: 'Filename'
}, {
  value: 'hostname',
  label: 'Hostname'
}, {
  value: 'port',
  label: 'Port'
}, {
  value: 'registry_key',
  label: 'Registry Key'
}, {
  value: 'user_account',
  label: 'User Account'
}, {
  value: 'process',
  label: 'Process'
}, {
  value: 'other',
  label: 'Other'
}];

// ─── Pagination Defaults ─────────────────────────────────────
const DEFAULT_PAGE_SIZE = exports.DEFAULT_PAGE_SIZE = 20;
const MAX_PAGE_SIZE = exports.MAX_PAGE_SIZE = 100;
const DEFAULT_SORT_FIELD = exports.DEFAULT_SORT_FIELD = 'created_at';
const DEFAULT_SORT_ORDER = exports.DEFAULT_SORT_ORDER = 'desc';

// ─── UI Theme Colors ─────────────────────────────────────────
const THEME = exports.THEME = {
  background: '#1D1E24',
  surface: '#25263A',
  surfaceHover: '#2E2F42',
  border: '#3D3E5A',
  primary: '#6092C0',
  primaryLight: '#6092C0',
  primaryDark: '#1558B0',
  success: '#54B399',
  warning: '#D6BF57',
  danger: '#E7664C',
  critical: '#9170B8',
  info: '#6092C0',
  textPrimary: '#FFFFFF',
  textSecondary: '#98A2B3',
  textMuted: '#6B7280'
};

// ─── TLP Definitions ─────────────────────────────────────────
const TLP_LEVELS = exports.TLP_LEVELS = [{
  value: 'WHITE',
  label: 'TLP:WHITE',
  color: '#FFFFFF',
  bg: 'rgba(255,255,255,0.1)'
}, {
  value: 'GREEN',
  label: 'TLP:GREEN',
  color: '#54B399',
  bg: 'rgba(0,187,122,0.15)'
}, {
  value: 'AMBER',
  label: 'TLP:AMBER',
  color: '#D6BF57',
  bg: 'rgba(245,166,35,0.15)'
}, {
  value: 'RED',
  label: 'TLP:RED',
  color: '#E7664C',
  bg: 'rgba(238,52,52,0.15)'
}];

// ─── Notification Events ─────────────────────────────────────
const NOTIFICATION_EVENTS = exports.NOTIFICATION_EVENTS = [{
  value: 'case_created',
  label: 'Case created'
}, {
  value: 'case_assigned',
  label: 'Case assigned'
}, {
  value: 'status_changed',
  label: 'Status changed'
}, {
  value: 'priority_changed',
  label: 'Priority changed'
}, {
  value: 'comment_added',
  label: 'Comment added'
}, {
  value: 'task_assigned',
  label: 'Task assigned'
}, {
  value: 'case_escalated',
  label: 'Case escalated'
}];
const NOTIFICATION_CHANNEL_TYPES = exports.NOTIFICATION_CHANNEL_TYPES = [{
  value: 'webhook',
  label: 'Generic webhook (JSON POST)'
}, {
  value: 'slack',
  label: 'Slack incoming webhook'
}, {
  value: 'teams',
  label: 'Microsoft Teams webhook'
}, {
  value: 'email',
  label: 'Email (SMTP)'
}];

// ─── SMTP ────────────────────────────────────────────────────
const SMTP_SECURITY_OPTIONS = exports.SMTP_SECURITY_OPTIONS = [{
  value: 'starttls',
  label: 'STARTTLS (upgrade a plain connection)',
  port: 587
}, {
  value: 'tls',
  label: 'TLS (implicit, encrypted from the start)',
  port: 465
}, {
  value: 'none',
  label: 'None (unencrypted)',
  port: 25
}];
const SMTP_AUTH_TYPES = exports.SMTP_AUTH_TYPES = [{
  value: 'auto',
  label: 'Auto (negotiate from server capabilities)'
}, {
  value: 'login',
  label: 'LOGIN'
}, {
  value: 'plain',
  label: 'PLAIN'
}, {
  value: 'cram-md5',
  label: 'CRAM-MD5'
}, {
  value: 'none',
  label: 'None (no authentication)'
}];

/** Default socket timeout for the whole SMTP conversation. */
const SMTP_DEFAULT_TIMEOUT_MS = exports.SMTP_DEFAULT_TIMEOUT_MS = 15000;

// ─── Outbound Channel Authentication ─────────────────────────
const CHANNEL_AUTH_TYPES = exports.CHANNEL_AUTH_TYPES = [{
  value: 'none',
  label: 'None',
  hint: 'For endpoints whose URL already contains the secret, such as Slack and Teams incoming webhooks.'
}, {
  value: 'bearer',
  label: 'Bearer token',
  hint: 'Sent as: Authorization: Bearer <token>'
}, {
  value: 'basic',
  label: 'Basic auth',
  hint: 'Sent as: Authorization: Basic base64(username:password)'
}, {
  value: 'api_key',
  label: 'API key header',
  hint: 'A custom header, e.g. X-API-Key: <value>'
}];

// ─── Escalation Actions ──────────────────────────────────────
const ESCALATION_ACTIONS = exports.ESCALATION_ACTIONS = [{
  value: 'notify',
  label: 'Notify',
  hint: 'Username to notify. Leave blank to notify the assignee and the case creator.'
}, {
  value: 'raise_priority',
  label: 'Raise priority',
  hint: 'Moves the case up one priority level (P4→P3→P2→P1)'
}, {
  value: 'set_priority',
  label: 'Set priority',
  hint: 'Target priority, e.g. P1'
}, {
  value: 'reassign',
  label: 'Reassign case',
  hint: 'Username to reassign the case to'
}, {
  value: 'add_tag',
  label: 'Add tag',
  hint: 'Tag to add to the case'
}];

// ─── Auto-Monitor Rule Builder ───────────────────────────────
const MONITOR_FIELDS = exports.MONITOR_FIELDS = [{
  value: 'rule.level',
  label: 'Rule level',
  kind: 'number'
}, {
  value: 'rule.id',
  label: 'Rule ID',
  kind: 'keyword'
}, {
  value: 'rule.groups',
  label: 'Rule group',
  kind: 'keyword'
}, {
  value: 'rule.description',
  label: 'Rule description',
  kind: 'text'
}, {
  value: 'rule.mitre.id',
  label: 'MITRE technique ID',
  kind: 'keyword'
}, {
  value: 'rule.mitre.tactic',
  label: 'MITRE tactic',
  kind: 'keyword'
}, {
  value: 'agent.id',
  label: 'Agent ID',
  kind: 'keyword'
}, {
  value: 'agent.name',
  label: 'Agent name',
  kind: 'keyword'
}, {
  value: 'agent.ip',
  label: 'Agent IP',
  kind: 'keyword'
}, {
  value: 'location',
  label: 'Log location',
  kind: 'keyword'
}, {
  value: 'decoder.name',
  label: 'Decoder name',
  kind: 'keyword'
}, {
  value: 'data.srcip',
  label: 'Source IP',
  kind: 'keyword'
}, {
  value: 'data.dstuser',
  label: 'Destination user',
  kind: 'keyword'
}, {
  value: 'full_log',
  label: 'Raw log',
  kind: 'text'
}];
const MONITOR_OPERATORS = exports.MONITOR_OPERATORS = [{
  value: 'eq',
  label: 'is',
  kinds: ['number', 'keyword', 'text']
}, {
  value: 'neq',
  label: 'is not',
  kinds: ['number', 'keyword', 'text']
}, {
  value: 'gt',
  label: 'greater than',
  kinds: ['number']
}, {
  value: 'gte',
  label: 'greater or equal',
  kinds: ['number']
}, {
  value: 'lt',
  label: 'less than',
  kinds: ['number']
}, {
  value: 'lte',
  label: 'less or equal',
  kinds: ['number']
}, {
  value: 'in',
  label: 'is one of',
  kinds: ['number', 'keyword']
}, {
  value: 'not_in',
  label: 'is none of',
  kinds: ['number', 'keyword']
}, {
  value: 'contains',
  label: 'contains',
  kinds: ['keyword', 'text']
}, {
  value: 'not_contains',
  label: 'does not contain',
  kinds: ['keyword', 'text']
}, {
  value: 'starts_with',
  label: 'starts with',
  kinds: ['keyword', 'text']
}, {
  value: 'exists',
  label: 'exists',
  kinds: ['number', 'keyword', 'text']
}, {
  value: 'not_exists',
  label: 'does not exist',
  kinds: ['number', 'keyword', 'text']
}];

/** Operators that take no value input */
const VALUELESS_OPERATORS = exports.VALUELESS_OPERATORS = ['exists', 'not_exists'];

/** Severity derived from rule.level when a monitor rule uses severity: 'auto' */
const LEVEL_SEVERITY_MAP = exports.LEVEL_SEVERITY_MAP = [{
  min: 13,
  severity: 'critical'
}, {
  min: 10,
  severity: 'high'
}, {
  min: 7,
  severity: 'medium'
}, {
  min: 4,
  severity: 'low'
}, {
  min: 0,
  severity: 'informational'
}];
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJQTFVHSU5fSUQiLCJleHBvcnRzIiwiUExVR0lOX05BTUUiLCJQTFVHSU5fREVTQ1JJUFRJT04iLCJDQVNFX0lOREVYIiwiQ0FTRV9JTkRFWF9QQVRURVJOIiwiQ0FTRV9DT1VOVEVSX0lOREVYIiwiTU9OSVRPUl9DT05GSUdfSU5ERVgiLCJTRVRUSU5HU19JTkRFWCIsIk5PVElGSUNBVElPTl9JTkRFWCIsIldBWlVIX0FMRVJUU19JTkRFWF9QQVRURVJOIiwiQVBJX1BSRUZJWCIsIkFQSV9ST1VURVMiLCJDQVNFUyIsIkNBU0VfQllfSUQiLCJDQVNFX1NUQVRVUyIsIkNBU0VfQVNTSUdOIiwiQ0FTRV9DT01NRU5UUyIsIkNBU0VfQ09NTUVOVF9CWV9JRCIsIkNBU0VfQUxFUlRTIiwiQ0FTRV9BTEVSVF9CWV9JRCIsIkFMRVJUU19TRUFSQ0giLCJDQVNFX09CU0VSVkFCTEVTIiwiQ0FTRV9PQlNFUlZBQkxFX0JZX0lEIiwiQU5BTFlUSUNTX1NVTU1BUlkiLCJBTkFMWVRJQ1NfVFJFTkRTIiwiU0VUVElOR1MiLCJNRSIsIlVTRVJTIiwiTU9OSVRPUiIsIk1PTklUT1JfU1RBVFVTIiwiTU9OSVRPUl9URVNUIiwiTk9USUZJQ0FUSU9OUyIsIk5PVElGSUNBVElPTlNfUkVBRCIsIk5PVElGSUNBVElPTl9CWV9JRCIsIk5PVElGSUNBVElPTl9DSEFOTkVMX1RFU1QiLCJTTVRQX1RFU1QiLCJBUElfS0VZUyIsIkFQSV9LRVlfQllfSUQiLCJDQVNFX1RBU0tTIiwiQ0FTRV9UQVNLX0JZX0lEIiwiRVNDQUxBVElPTl9SVU4iLCJFWFRFUk5BTF9BUElfUFJFRklYIiwiQVBJX0tFWV9IRUFERVIiLCJBUElfS0VZX1RPS0VOX1BSRUZJWCIsIkNBU0VfSURfUFJFRklYIiwiQ0FTRV9JRF9TRVBBUkFUT1IiLCJDQVNFX0lEX1BBRERJTkciLCJDQVNFX0lEX0lOQ0xVREVfWUVBUiIsIkNBU0VfU1RBVFVTRVMiLCJ2YWx1ZSIsImxhYmVsIiwiY29sb3IiLCJpY29uIiwiU1RBVFVTX1RSQU5TSVRJT05TIiwib3BlbiIsImluX3Byb2dyZXNzIiwid2FpdGluZyIsInJlc29sdmVkIiwiY2xvc2VkIiwiQ0FTRV9TRVZFUklUSUVTIiwib3JkZXIiLCJDQVNFX1BSSU9SSVRJRVMiLCJDQVNFX0NBVEVHT1JJRVMiLCJPQlNFUlZBQkxFX1RZUEVTIiwiREVGQVVMVF9QQUdFX1NJWkUiLCJNQVhfUEFHRV9TSVpFIiwiREVGQVVMVF9TT1JUX0ZJRUxEIiwiREVGQVVMVF9TT1JUX09SREVSIiwiVEhFTUUiLCJiYWNrZ3JvdW5kIiwic3VyZmFjZSIsInN1cmZhY2VIb3ZlciIsImJvcmRlciIsInByaW1hcnkiLCJwcmltYXJ5TGlnaHQiLCJwcmltYXJ5RGFyayIsInN1Y2Nlc3MiLCJ3YXJuaW5nIiwiZGFuZ2VyIiwiY3JpdGljYWwiLCJpbmZvIiwidGV4dFByaW1hcnkiLCJ0ZXh0U2Vjb25kYXJ5IiwidGV4dE11dGVkIiwiVExQX0xFVkVMUyIsImJnIiwiTk9USUZJQ0FUSU9OX0VWRU5UUyIsIk5PVElGSUNBVElPTl9DSEFOTkVMX1RZUEVTIiwiU01UUF9TRUNVUklUWV9PUFRJT05TIiwicG9ydCIsIlNNVFBfQVVUSF9UWVBFUyIsIlNNVFBfREVGQVVMVF9USU1FT1VUX01TIiwiQ0hBTk5FTF9BVVRIX1RZUEVTIiwiaGludCIsIkVTQ0FMQVRJT05fQUNUSU9OUyIsIk1PTklUT1JfRklFTERTIiwia2luZCIsIk1PTklUT1JfT1BFUkFUT1JTIiwia2luZHMiLCJWQUxVRUxFU1NfT1BFUkFUT1JTIiwiTEVWRUxfU0VWRVJJVFlfTUFQIiwibWluIiwic2V2ZXJpdHkiXSwic291cmNlcyI6WyJjb25zdGFudHMudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLypcbiAqIFdhenVoIENhc2UgTWFuYWdlbWVudCBQbHVnaW5cbiAqIFNoYXJlZCBjb25zdGFudHMgYmV0d2VlbiBzZXJ2ZXIgYW5kIGNsaWVudFxuICovXG5cbi8vIOKUgOKUgOKUgCBQbHVnaW4gSWRlbnRpZmljYXRpb24g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5leHBvcnQgY29uc3QgUExVR0lOX0lEID0gJ3dhenVoQ2FzZU1hbmFnZW1lbnQnO1xuZXhwb3J0IGNvbnN0IFBMVUdJTl9OQU1FID0gJ0Nhc2UgTWFuYWdlbWVudCc7XG5leHBvcnQgY29uc3QgUExVR0lOX0RFU0NSSVBUSU9OID0gJ1NlY3VyaXR5IGluY2lkZW50IGNhc2UgbWFuYWdlbWVudCBmb3IgV2F6dWgnO1xuXG4vLyDilIDilIDilIAgT3BlblNlYXJjaCBJbmRleCDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbmV4cG9ydCBjb25zdCBDQVNFX0lOREVYID0gJ3dhenVoLWNhc2UtbWFuYWdlbWVudC1jYXNlcyc7XG5leHBvcnQgY29uc3QgQ0FTRV9JTkRFWF9QQVRURVJOID0gJ3dhenVoLWNhc2UtbWFuYWdlbWVudC0qJztcbmV4cG9ydCBjb25zdCBDQVNFX0NPVU5URVJfSU5ERVggPSAnd2F6dWgtY2FzZS1tYW5hZ2VtZW50LWNvdW50ZXInO1xuZXhwb3J0IGNvbnN0IE1PTklUT1JfQ09ORklHX0lOREVYID0gJ3dhenVoLWNhc2UtbWFuYWdlbWVudC1tb25pdG9yJztcbmV4cG9ydCBjb25zdCBTRVRUSU5HU19JTkRFWCA9ICd3YXp1aC1jYXNlLW1hbmFnZW1lbnQtc2V0dGluZ3MnO1xuZXhwb3J0IGNvbnN0IE5PVElGSUNBVElPTl9JTkRFWCA9ICd3YXp1aC1jYXNlLW1hbmFnZW1lbnQtbm90aWZpY2F0aW9ucyc7XG5cbi8vIOKUgOKUgOKUgCBXYXp1aCBBbGVydCBJbmRleCDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbmV4cG9ydCBjb25zdCBXQVpVSF9BTEVSVFNfSU5ERVhfUEFUVEVSTiA9ICd3YXp1aC1hbGVydHMtKic7XG5cbi8vIOKUgOKUgOKUgCBBUEkgUm91dGVzIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuZXhwb3J0IGNvbnN0IEFQSV9QUkVGSVggPSAnL2FwaS93YXp1aC1jYXNlLW1hbmFnZW1lbnQnO1xuXG5leHBvcnQgY29uc3QgQVBJX1JPVVRFUyA9IHtcbiAgLy8gQ2FzZXNcbiAgQ0FTRVM6IGAke0FQSV9QUkVGSVh9L2Nhc2VzYCxcbiAgQ0FTRV9CWV9JRDogYCR7QVBJX1BSRUZJWH0vY2FzZXMve2lkfWAsXG4gIENBU0VfU1RBVFVTOiBgJHtBUElfUFJFRklYfS9jYXNlcy97aWR9L3N0YXR1c2AsXG4gIENBU0VfQVNTSUdOOiBgJHtBUElfUFJFRklYfS9jYXNlcy97aWR9L2Fzc2lnbmAsXG5cbiAgLy8gQ29tbWVudHNcbiAgQ0FTRV9DT01NRU5UUzogYCR7QVBJX1BSRUZJWH0vY2FzZXMve2lkfS9jb21tZW50c2AsXG4gIENBU0VfQ09NTUVOVF9CWV9JRDogYCR7QVBJX1BSRUZJWH0vY2FzZXMve2lkfS9jb21tZW50cy97Y29tbWVudElkfWAsXG5cbiAgLy8gQWxlcnRzXG4gIENBU0VfQUxFUlRTOiBgJHtBUElfUFJFRklYfS9jYXNlcy97aWR9L2FsZXJ0c2AsXG4gIENBU0VfQUxFUlRfQllfSUQ6IGAke0FQSV9QUkVGSVh9L2Nhc2VzL3tpZH0vYWxlcnRzL3thbGVydElkfWAsXG4gIEFMRVJUU19TRUFSQ0g6IGAke0FQSV9QUkVGSVh9L2FsZXJ0cy9zZWFyY2hgLFxuXG4gIC8vIE9ic2VydmFibGVzXG4gIENBU0VfT0JTRVJWQUJMRVM6IGAke0FQSV9QUkVGSVh9L2Nhc2VzL3tpZH0vb2JzZXJ2YWJsZXNgLFxuICBDQVNFX09CU0VSVkFCTEVfQllfSUQ6IGAke0FQSV9QUkVGSVh9L2Nhc2VzL3tpZH0vb2JzZXJ2YWJsZXMve29ic2VydmFibGVJZH1gLFxuXG4gIC8vIEFuYWx5dGljc1xuICBBTkFMWVRJQ1NfU1VNTUFSWTogYCR7QVBJX1BSRUZJWH0vYW5hbHl0aWNzL3N1bW1hcnlgLFxuICBBTkFMWVRJQ1NfVFJFTkRTOiBgJHtBUElfUFJFRklYfS9hbmFseXRpY3MvdHJlbmRzYCxcblxuICAvLyBTZXR0aW5nc1xuICBTRVRUSU5HUzogYCR7QVBJX1BSRUZJWH0vc2V0dGluZ3NgLFxuXG4gIC8vIFVzZXJzXG4gIE1FOiBgJHtBUElfUFJFRklYfS9tZWAsXG4gIFVTRVJTOiBgJHtBUElfUFJFRklYfS91c2Vyc2AsXG5cbiAgLy8gQXV0byBNb25pdG9yXG4gIE1PTklUT1I6IGAke0FQSV9QUkVGSVh9L21vbml0b3JgLFxuICBNT05JVE9SX1NUQVRVUzogYCR7QVBJX1BSRUZJWH0vbW9uaXRvci9zdGF0dXNgLFxuICBNT05JVE9SX1RFU1Q6IGAke0FQSV9QUkVGSVh9L21vbml0b3IvdGVzdGAsXG5cbiAgLy8gTm90aWZpY2F0aW9uc1xuICBOT1RJRklDQVRJT05TOiBgJHtBUElfUFJFRklYfS9ub3RpZmljYXRpb25zYCxcbiAgTk9USUZJQ0FUSU9OU19SRUFEOiBgJHtBUElfUFJFRklYfS9ub3RpZmljYXRpb25zL3JlYWRgLFxuICBOT1RJRklDQVRJT05fQllfSUQ6IGAke0FQSV9QUkVGSVh9L25vdGlmaWNhdGlvbnMve25vdGlmaWNhdGlvbklkfWAsXG5cbiAgLy8gTm90aWZpY2F0aW9uIGNoYW5uZWwgdGVzdCBkZWxpdmVyeVxuICBOT1RJRklDQVRJT05fQ0hBTk5FTF9URVNUOiBgJHtBUElfUFJFRklYfS9zZXR0aW5ncy9ub3RpZmljYXRpb25zL3Rlc3RgLFxuICBTTVRQX1RFU1Q6IGAke0FQSV9QUkVGSVh9L3NldHRpbmdzL3NtdHAvdGVzdGAsXG5cbiAgLy8gQVBJIGtleXNcbiAgQVBJX0tFWVM6IGAke0FQSV9QUkVGSVh9L3NldHRpbmdzL2FwaS1rZXlzYCxcbiAgQVBJX0tFWV9CWV9JRDogYCR7QVBJX1BSRUZJWH0vc2V0dGluZ3MvYXBpLWtleXMve2tleUlkfWAsXG5cbiAgLy8gVGFza3NcbiAgQ0FTRV9UQVNLUzogYCR7QVBJX1BSRUZJWH0vY2FzZXMve2lkfS90YXNrc2AsXG4gIENBU0VfVEFTS19CWV9JRDogYCR7QVBJX1BSRUZJWH0vY2FzZXMve2lkfS90YXNrcy97dGFza0lkfWAsXG5cbiAgLy8gRXNjYWxhdGlvblxuICBFU0NBTEFUSU9OX1JVTjogYCR7QVBJX1BSRUZJWH0vZXNjYWxhdGlvbi9ydW5gLFxufSBhcyBjb25zdDtcblxuLyoqIFByZWZpeCBvZiB0aGUgZXh0ZXJuYWwsIEFQSS1rZXkgYXV0aGVudGljYXRlZCBzdXJmYWNlLiAqL1xuZXhwb3J0IGNvbnN0IEVYVEVSTkFMX0FQSV9QUkVGSVggPSBgJHtBUElfUFJFRklYfS9leHRlcm5hbGA7XG5cbi8qKiBIZWFkZXIgY2FycnlpbmcgdGhlIEFQSSBrZXkgb24gZXh0ZXJuYWwgcmVxdWVzdHMuICovXG5leHBvcnQgY29uc3QgQVBJX0tFWV9IRUFERVIgPSAneC1jbS1hcGkta2V5JztcblxuLyoqIEh1bWFuLXJlYWRhYmxlIHByZWZpeCBvZiBldmVyeSBnZW5lcmF0ZWQgQVBJIGtleS4gKi9cbmV4cG9ydCBjb25zdCBBUElfS0VZX1RPS0VOX1BSRUZJWCA9ICd3Y20nO1xuXG4vLyDilIDilIDilIAgQ2FzZSBJRCBDb25maWd1cmF0aW9uIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuLy8gVGhlc2UgYXJlIHRoZSAqZmFsbGJhY2sgZGVmYXVsdHMqLiBUaGUgZWZmZWN0aXZlIGZvcm1hdCBpcyBzdG9yZWQgaW4gdGhlXG4vLyBzZXR0aW5ncyBpbmRleCBhbmQgaXMgZWRpdGFibGUgZnJvbSBTZXR0aW5ncyDihpIgQ2FzZSBJRCBGb3JtYXQuXG5leHBvcnQgY29uc3QgQ0FTRV9JRF9QUkVGSVggPSAnQ0FTRSc7XG5leHBvcnQgY29uc3QgQ0FTRV9JRF9TRVBBUkFUT1IgPSAnLSc7XG5leHBvcnQgY29uc3QgQ0FTRV9JRF9QQURESU5HID0gNDtcbmV4cG9ydCBjb25zdCBDQVNFX0lEX0lOQ0xVREVfWUVBUiA9IHRydWU7XG5cbi8vIOKUgOKUgOKUgCBTdGF0dXMgRGVmaW5pdGlvbnMg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4vLyBDb2xvcnMgdXNlIHRoZSBPcGVuU2VhcmNoL1dhenVoIHZpc3VhbGl6YXRpb24gcGFsZXR0ZSAob3VpUGFsZXR0ZUNvbG9yQmxpbmQpXG5leHBvcnQgY29uc3QgQ0FTRV9TVEFUVVNFUyA9IFtcbiAgeyB2YWx1ZTogJ29wZW4nLCBsYWJlbDogJ09wZW4nLCBjb2xvcjogJyM2MDkyQzAnLCBpY29uOiAnZm9sZGVyT3BlbicgfSxcbiAgeyB2YWx1ZTogJ2luX3Byb2dyZXNzJywgbGFiZWw6ICdJbiBQcm9ncmVzcycsIGNvbG9yOiAnIzkxNzBCOCcsIGljb246ICdwbGF5RmlsbGVkJyB9LFxuICB7IHZhbHVlOiAnd2FpdGluZycsIGxhYmVsOiAnV2FpdGluZycsIGNvbG9yOiAnI0Q2QkY1NycsIGljb246ICdjbG9jaycgfSxcbiAgeyB2YWx1ZTogJ3Jlc29sdmVkJywgbGFiZWw6ICdSZXNvbHZlZCcsIGNvbG9yOiAnIzU0QjM5OScsIGljb246ICdjaGVja0luQ2lyY2xlRmlsbGVkJyB9LFxuICB7IHZhbHVlOiAnY2xvc2VkJywgbGFiZWw6ICdDbG9zZWQnLCBjb2xvcjogJyM5OEEyQjMnLCBpY29uOiAnY3Jvc3MnIH0sXG5dIGFzIGNvbnN0O1xuXG4vLyBWYWxpZCBzdGF0dXMgdHJhbnNpdGlvbnNcbmV4cG9ydCBjb25zdCBTVEFUVVNfVFJBTlNJVElPTlM6IFJlY29yZDxzdHJpbmcsIHN0cmluZ1tdPiA9IHtcbiAgb3BlbjogWydpbl9wcm9ncmVzcycsICd3YWl0aW5nJywgJ2Nsb3NlZCddLFxuICBpbl9wcm9ncmVzczogWyd3YWl0aW5nJywgJ3Jlc29sdmVkJywgJ2Nsb3NlZCddLFxuICB3YWl0aW5nOiBbJ2luX3Byb2dyZXNzJywgJ3Jlc29sdmVkJywgJ2Nsb3NlZCddLFxuICByZXNvbHZlZDogWydjbG9zZWQnLCAnaW5fcHJvZ3Jlc3MnXSwgLy8gY2FuIHJlb3BlblxuICBjbG9zZWQ6IFsnb3BlbiddLCAvLyBjYW4gcmVvcGVuXG59O1xuXG4vLyDilIDilIDilIAgU2V2ZXJpdHkgRGVmaW5pdGlvbnMg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5leHBvcnQgY29uc3QgQ0FTRV9TRVZFUklUSUVTID0gW1xuICB7IHZhbHVlOiAnaW5mb3JtYXRpb25hbCcsIGxhYmVsOiAnSW5mb3JtYXRpb25hbCcsIGNvbG9yOiAnIzk4QTJCMycsIG9yZGVyOiAwIH0sXG4gIHsgdmFsdWU6ICdsb3cnLCBsYWJlbDogJ0xvdycsIGNvbG9yOiAnIzU0QjM5OScsIG9yZGVyOiAxIH0sXG4gIHsgdmFsdWU6ICdtZWRpdW0nLCBsYWJlbDogJ01lZGl1bScsIGNvbG9yOiAnI0Q2QkY1NycsIG9yZGVyOiAyIH0sXG4gIHsgdmFsdWU6ICdoaWdoJywgbGFiZWw6ICdIaWdoJywgY29sb3I6ICcjREE4QjQ1Jywgb3JkZXI6IDMgfSxcbiAgeyB2YWx1ZTogJ2NyaXRpY2FsJywgbGFiZWw6ICdDcml0aWNhbCcsIGNvbG9yOiAnI0U3NjY0QycsIG9yZGVyOiA0IH0sXG5dIGFzIGNvbnN0O1xuXG4vLyDilIDilIDilIAgUHJpb3JpdHkgRGVmaW5pdGlvbnMg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5leHBvcnQgY29uc3QgQ0FTRV9QUklPUklUSUVTID0gW1xuICB7IHZhbHVlOiAnUDEnLCBsYWJlbDogJ1AxIChVcmdlbnQpJywgY29sb3I6ICcjRTc2NjRDJywgb3JkZXI6IDAgfSxcbiAgeyB2YWx1ZTogJ1AyJywgbGFiZWw6ICdQMiAoSGlnaCknLCBjb2xvcjogJyNEQThCNDUnLCBvcmRlcjogMSB9LFxuICB7IHZhbHVlOiAnUDMnLCBsYWJlbDogJ1AzIChNZWRpdW0pJywgY29sb3I6ICcjRDZCRjU3Jywgb3JkZXI6IDIgfSxcbiAgeyB2YWx1ZTogJ1A0JywgbGFiZWw6ICdQNCAoTG93KScsIGNvbG9yOiAnIzk4QTJCMycsIG9yZGVyOiAzIH0sXG5dIGFzIGNvbnN0O1xuXG4vLyDilIDilIDilIAgQ2F0ZWdvcnkgRGVmaW5pdGlvbnMg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5leHBvcnQgY29uc3QgQ0FTRV9DQVRFR09SSUVTID0gW1xuICB7IHZhbHVlOiAnbWFsd2FyZScsIGxhYmVsOiAnTWFsd2FyZScsIGljb246ICdidWcnIH0sXG4gIHsgdmFsdWU6ICdpbnRydXNpb25fYXR0ZW1wdCcsIGxhYmVsOiAnSW50cnVzaW9uIEF0dGVtcHQnLCBpY29uOiAnbG9jaycgfSxcbiAgeyB2YWx1ZTogJ2RhdGFfZXhmaWx0cmF0aW9uJywgbGFiZWw6ICdEYXRhIEV4ZmlsdHJhdGlvbicsIGljb246ICdleHBvcnRBY3Rpb24nIH0sXG4gIHsgdmFsdWU6ICdwb2xpY3lfdmlvbGF0aW9uJywgbGFiZWw6ICdQb2xpY3kgVmlvbGF0aW9uJywgaWNvbjogJ2FsZXJ0JyB9LFxuICB7IHZhbHVlOiAndnVsbmVyYWJpbGl0eScsIGxhYmVsOiAnVnVsbmVyYWJpbGl0eScsIGljb246ICdzZWN1cml0eVNpZ25hbCcgfSxcbiAgeyB2YWx1ZTogJ3BoaXNoaW5nJywgbGFiZWw6ICdQaGlzaGluZycsIGljb246ICdlbWFpbCcgfSxcbiAgeyB2YWx1ZTogJ2RlbmlhbF9vZl9zZXJ2aWNlJywgbGFiZWw6ICdEZW5pYWwgb2YgU2VydmljZScsIGljb246ICdvZmZsaW5lJyB9LFxuICB7IHZhbHVlOiAnaW5zaWRlcl90aHJlYXQnLCBsYWJlbDogJ0luc2lkZXIgVGhyZWF0JywgaWNvbjogJ3VzZXInIH0sXG4gIHsgdmFsdWU6ICd1bmF1dGhvcml6ZWRfYWNjZXNzJywgbGFiZWw6ICdVbmF1dGhvcml6ZWQgQWNjZXNzJywgaWNvbjogJ2Nyb3NzSW5BQ2lyY2xlRmlsbGVkJyB9LFxuICB7IHZhbHVlOiAnb3RoZXInLCBsYWJlbDogJ090aGVyJywgaWNvbjogJ3F1ZXN0aW9uSW5DaXJjbGUnIH0sXG5dIGFzIGNvbnN0O1xuXG4vLyDilIDilIDilIAgT2JzZXJ2YWJsZSBUeXBlIERlZmluaXRpb25zIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuZXhwb3J0IGNvbnN0IE9CU0VSVkFCTEVfVFlQRVMgPSBbXG4gIHsgdmFsdWU6ICdpcCcsIGxhYmVsOiAnSVAgQWRkcmVzcycgfSxcbiAgeyB2YWx1ZTogJ2RvbWFpbicsIGxhYmVsOiAnRG9tYWluJyB9LFxuICB7IHZhbHVlOiAndXJsJywgbGFiZWw6ICdVUkwnIH0sXG4gIHsgdmFsdWU6ICdoYXNoX21kNScsIGxhYmVsOiAnSGFzaCAoTUQ1KScgfSxcbiAgeyB2YWx1ZTogJ2hhc2hfc2hhMScsIGxhYmVsOiAnSGFzaCAoU0hBLTEpJyB9LFxuICB7IHZhbHVlOiAnaGFzaF9zaGEyNTYnLCBsYWJlbDogJ0hhc2ggKFNIQS0yNTYpJyB9LFxuICB7IHZhbHVlOiAnZW1haWwnLCBsYWJlbDogJ0VtYWlsIEFkZHJlc3MnIH0sXG4gIHsgdmFsdWU6ICdmaWxlbmFtZScsIGxhYmVsOiAnRmlsZW5hbWUnIH0sXG4gIHsgdmFsdWU6ICdob3N0bmFtZScsIGxhYmVsOiAnSG9zdG5hbWUnIH0sXG4gIHsgdmFsdWU6ICdwb3J0JywgbGFiZWw6ICdQb3J0JyB9LFxuICB7IHZhbHVlOiAncmVnaXN0cnlfa2V5JywgbGFiZWw6ICdSZWdpc3RyeSBLZXknIH0sXG4gIHsgdmFsdWU6ICd1c2VyX2FjY291bnQnLCBsYWJlbDogJ1VzZXIgQWNjb3VudCcgfSxcbiAgeyB2YWx1ZTogJ3Byb2Nlc3MnLCBsYWJlbDogJ1Byb2Nlc3MnIH0sXG4gIHsgdmFsdWU6ICdvdGhlcicsIGxhYmVsOiAnT3RoZXInIH0sXG5dIGFzIGNvbnN0O1xuXG4vLyDilIDilIDilIAgUGFnaW5hdGlvbiBEZWZhdWx0cyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbmV4cG9ydCBjb25zdCBERUZBVUxUX1BBR0VfU0laRSA9IDIwO1xuZXhwb3J0IGNvbnN0IE1BWF9QQUdFX1NJWkUgPSAxMDA7XG5leHBvcnQgY29uc3QgREVGQVVMVF9TT1JUX0ZJRUxEID0gJ2NyZWF0ZWRfYXQnO1xuZXhwb3J0IGNvbnN0IERFRkFVTFRfU09SVF9PUkRFUiA9ICdkZXNjJztcblxuLy8g4pSA4pSA4pSAIFVJIFRoZW1lIENvbG9ycyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbmV4cG9ydCBjb25zdCBUSEVNRSA9IHtcbiAgYmFja2dyb3VuZDogJyMxRDFFMjQnLFxuICBzdXJmYWNlOiAnIzI1MjYzQScsXG4gIHN1cmZhY2VIb3ZlcjogJyMyRTJGNDInLFxuICBib3JkZXI6ICcjM0QzRTVBJyxcbiAgcHJpbWFyeTogJyM2MDkyQzAnLFxuICBwcmltYXJ5TGlnaHQ6ICcjNjA5MkMwJyxcbiAgcHJpbWFyeURhcms6ICcjMTU1OEIwJyxcbiAgc3VjY2VzczogJyM1NEIzOTknLFxuICB3YXJuaW5nOiAnI0Q2QkY1NycsXG4gIGRhbmdlcjogJyNFNzY2NEMnLFxuICBjcml0aWNhbDogJyM5MTcwQjgnLFxuICBpbmZvOiAnIzYwOTJDMCcsXG4gIHRleHRQcmltYXJ5OiAnI0ZGRkZGRicsXG4gIHRleHRTZWNvbmRhcnk6ICcjOThBMkIzJyxcbiAgdGV4dE11dGVkOiAnIzZCNzI4MCcsXG59IGFzIGNvbnN0O1xuXG4vLyDilIDilIDilIAgVExQIERlZmluaXRpb25zIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuZXhwb3J0IGNvbnN0IFRMUF9MRVZFTFMgPSBbXG4gIHsgdmFsdWU6ICdXSElURScsIGxhYmVsOiAnVExQOldISVRFJywgY29sb3I6ICcjRkZGRkZGJywgYmc6ICdyZ2JhKDI1NSwyNTUsMjU1LDAuMSknIH0sXG4gIHsgdmFsdWU6ICdHUkVFTicsIGxhYmVsOiAnVExQOkdSRUVOJywgY29sb3I6ICcjNTRCMzk5JywgYmc6ICdyZ2JhKDAsMTg3LDEyMiwwLjE1KScgfSxcbiAgeyB2YWx1ZTogJ0FNQkVSJywgbGFiZWw6ICdUTFA6QU1CRVInLCBjb2xvcjogJyNENkJGNTcnLCBiZzogJ3JnYmEoMjQ1LDE2NiwzNSwwLjE1KScgfSxcbiAgeyB2YWx1ZTogJ1JFRCcsICAgbGFiZWw6ICdUTFA6UkVEJywgICBjb2xvcjogJyNFNzY2NEMnLCBiZzogJ3JnYmEoMjM4LDUyLDUyLDAuMTUpJyB9LFxuXSBhcyBjb25zdDtcblxuLy8g4pSA4pSA4pSAIE5vdGlmaWNhdGlvbiBFdmVudHMg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5leHBvcnQgY29uc3QgTk9USUZJQ0FUSU9OX0VWRU5UUyA9IFtcbiAgeyB2YWx1ZTogJ2Nhc2VfY3JlYXRlZCcsICAgICBsYWJlbDogJ0Nhc2UgY3JlYXRlZCcgfSxcbiAgeyB2YWx1ZTogJ2Nhc2VfYXNzaWduZWQnLCAgICBsYWJlbDogJ0Nhc2UgYXNzaWduZWQnIH0sXG4gIHsgdmFsdWU6ICdzdGF0dXNfY2hhbmdlZCcsICAgbGFiZWw6ICdTdGF0dXMgY2hhbmdlZCcgfSxcbiAgeyB2YWx1ZTogJ3ByaW9yaXR5X2NoYW5nZWQnLCBsYWJlbDogJ1ByaW9yaXR5IGNoYW5nZWQnIH0sXG4gIHsgdmFsdWU6ICdjb21tZW50X2FkZGVkJywgICAgbGFiZWw6ICdDb21tZW50IGFkZGVkJyB9LFxuICB7IHZhbHVlOiAndGFza19hc3NpZ25lZCcsICAgIGxhYmVsOiAnVGFzayBhc3NpZ25lZCcgfSxcbiAgeyB2YWx1ZTogJ2Nhc2VfZXNjYWxhdGVkJywgICBsYWJlbDogJ0Nhc2UgZXNjYWxhdGVkJyB9LFxuXSBhcyBjb25zdDtcblxuZXhwb3J0IGNvbnN0IE5PVElGSUNBVElPTl9DSEFOTkVMX1RZUEVTID0gW1xuICB7IHZhbHVlOiAnd2ViaG9vaycsIGxhYmVsOiAnR2VuZXJpYyB3ZWJob29rIChKU09OIFBPU1QpJyB9LFxuICB7IHZhbHVlOiAnc2xhY2snLCAgIGxhYmVsOiAnU2xhY2sgaW5jb21pbmcgd2ViaG9vaycgfSxcbiAgeyB2YWx1ZTogJ3RlYW1zJywgICBsYWJlbDogJ01pY3Jvc29mdCBUZWFtcyB3ZWJob29rJyB9LFxuICB7IHZhbHVlOiAnZW1haWwnLCAgIGxhYmVsOiAnRW1haWwgKFNNVFApJyB9LFxuXSBhcyBjb25zdDtcblxuLy8g4pSA4pSA4pSAIFNNVFAg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5leHBvcnQgY29uc3QgU01UUF9TRUNVUklUWV9PUFRJT05TID0gW1xuICB7IHZhbHVlOiAnc3RhcnR0bHMnLCBsYWJlbDogJ1NUQVJUVExTICh1cGdyYWRlIGEgcGxhaW4gY29ubmVjdGlvbiknLCBwb3J0OiA1ODcgfSxcbiAgeyB2YWx1ZTogJ3RscycsICAgICAgbGFiZWw6ICdUTFMgKGltcGxpY2l0LCBlbmNyeXB0ZWQgZnJvbSB0aGUgc3RhcnQpJywgcG9ydDogNDY1IH0sXG4gIHsgdmFsdWU6ICdub25lJywgICAgIGxhYmVsOiAnTm9uZSAodW5lbmNyeXB0ZWQpJywgcG9ydDogMjUgfSxcbl0gYXMgY29uc3Q7XG5cbmV4cG9ydCBjb25zdCBTTVRQX0FVVEhfVFlQRVMgPSBbXG4gIHsgdmFsdWU6ICdhdXRvJywgICAgIGxhYmVsOiAnQXV0byAobmVnb3RpYXRlIGZyb20gc2VydmVyIGNhcGFiaWxpdGllcyknIH0sXG4gIHsgdmFsdWU6ICdsb2dpbicsICAgIGxhYmVsOiAnTE9HSU4nIH0sXG4gIHsgdmFsdWU6ICdwbGFpbicsICAgIGxhYmVsOiAnUExBSU4nIH0sXG4gIHsgdmFsdWU6ICdjcmFtLW1kNScsIGxhYmVsOiAnQ1JBTS1NRDUnIH0sXG4gIHsgdmFsdWU6ICdub25lJywgICAgIGxhYmVsOiAnTm9uZSAobm8gYXV0aGVudGljYXRpb24pJyB9LFxuXSBhcyBjb25zdDtcblxuLyoqIERlZmF1bHQgc29ja2V0IHRpbWVvdXQgZm9yIHRoZSB3aG9sZSBTTVRQIGNvbnZlcnNhdGlvbi4gKi9cbmV4cG9ydCBjb25zdCBTTVRQX0RFRkFVTFRfVElNRU9VVF9NUyA9IDE1MDAwO1xuXG4vLyDilIDilIDilIAgT3V0Ym91bmQgQ2hhbm5lbCBBdXRoZW50aWNhdGlvbiDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbmV4cG9ydCBjb25zdCBDSEFOTkVMX0FVVEhfVFlQRVMgPSBbXG4gIHsgdmFsdWU6ICdub25lJywgICAgbGFiZWw6ICdOb25lJyxcbiAgICBoaW50OiAnRm9yIGVuZHBvaW50cyB3aG9zZSBVUkwgYWxyZWFkeSBjb250YWlucyB0aGUgc2VjcmV0LCBzdWNoIGFzIFNsYWNrIGFuZCBUZWFtcyBpbmNvbWluZyB3ZWJob29rcy4nIH0sXG4gIHsgdmFsdWU6ICdiZWFyZXInLCAgbGFiZWw6ICdCZWFyZXIgdG9rZW4nLFxuICAgIGhpbnQ6ICdTZW50IGFzOiBBdXRob3JpemF0aW9uOiBCZWFyZXIgPHRva2VuPicgfSxcbiAgeyB2YWx1ZTogJ2Jhc2ljJywgICBsYWJlbDogJ0Jhc2ljIGF1dGgnLFxuICAgIGhpbnQ6ICdTZW50IGFzOiBBdXRob3JpemF0aW9uOiBCYXNpYyBiYXNlNjQodXNlcm5hbWU6cGFzc3dvcmQpJyB9LFxuICB7IHZhbHVlOiAnYXBpX2tleScsIGxhYmVsOiAnQVBJIGtleSBoZWFkZXInLFxuICAgIGhpbnQ6ICdBIGN1c3RvbSBoZWFkZXIsIGUuZy4gWC1BUEktS2V5OiA8dmFsdWU+JyB9LFxuXSBhcyBjb25zdDtcblxuLy8g4pSA4pSA4pSAIEVzY2FsYXRpb24gQWN0aW9ucyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbmV4cG9ydCBjb25zdCBFU0NBTEFUSU9OX0FDVElPTlMgPSBbXG4gIHsgdmFsdWU6ICdub3RpZnknLCAgICAgICAgIGxhYmVsOiAnTm90aWZ5JywgICAgICAgICAgICBoaW50OiAnVXNlcm5hbWUgdG8gbm90aWZ5LiBMZWF2ZSBibGFuayB0byBub3RpZnkgdGhlIGFzc2lnbmVlIGFuZCB0aGUgY2FzZSBjcmVhdG9yLicgfSxcbiAgeyB2YWx1ZTogJ3JhaXNlX3ByaW9yaXR5JywgbGFiZWw6ICdSYWlzZSBwcmlvcml0eScsICAgIGhpbnQ6ICdNb3ZlcyB0aGUgY2FzZSB1cCBvbmUgcHJpb3JpdHkgbGV2ZWwgKFA04oaSUDPihpJQMuKGklAxKScgfSxcbiAgeyB2YWx1ZTogJ3NldF9wcmlvcml0eScsICAgbGFiZWw6ICdTZXQgcHJpb3JpdHknLCAgICAgIGhpbnQ6ICdUYXJnZXQgcHJpb3JpdHksIGUuZy4gUDEnIH0sXG4gIHsgdmFsdWU6ICdyZWFzc2lnbicsICAgICAgIGxhYmVsOiAnUmVhc3NpZ24gY2FzZScsICAgICBoaW50OiAnVXNlcm5hbWUgdG8gcmVhc3NpZ24gdGhlIGNhc2UgdG8nIH0sXG4gIHsgdmFsdWU6ICdhZGRfdGFnJywgICAgICAgIGxhYmVsOiAnQWRkIHRhZycsICAgICAgICAgICBoaW50OiAnVGFnIHRvIGFkZCB0byB0aGUgY2FzZScgfSxcbl0gYXMgY29uc3Q7XG5cbi8vIOKUgOKUgOKUgCBBdXRvLU1vbml0b3IgUnVsZSBCdWlsZGVyIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuZXhwb3J0IGNvbnN0IE1PTklUT1JfRklFTERTID0gW1xuICB7IHZhbHVlOiAncnVsZS5sZXZlbCcsICAgICAgICBsYWJlbDogJ1J1bGUgbGV2ZWwnLCAgICAgICAga2luZDogJ251bWJlcicgfSxcbiAgeyB2YWx1ZTogJ3J1bGUuaWQnLCAgICAgICAgICAgbGFiZWw6ICdSdWxlIElEJywgICAgICAgICAgIGtpbmQ6ICdrZXl3b3JkJyB9LFxuICB7IHZhbHVlOiAncnVsZS5ncm91cHMnLCAgICAgICBsYWJlbDogJ1J1bGUgZ3JvdXAnLCAgICAgICAga2luZDogJ2tleXdvcmQnIH0sXG4gIHsgdmFsdWU6ICdydWxlLmRlc2NyaXB0aW9uJywgIGxhYmVsOiAnUnVsZSBkZXNjcmlwdGlvbicsICBraW5kOiAndGV4dCcgfSxcbiAgeyB2YWx1ZTogJ3J1bGUubWl0cmUuaWQnLCAgICAgbGFiZWw6ICdNSVRSRSB0ZWNobmlxdWUgSUQnLCBraW5kOiAna2V5d29yZCcgfSxcbiAgeyB2YWx1ZTogJ3J1bGUubWl0cmUudGFjdGljJywgbGFiZWw6ICdNSVRSRSB0YWN0aWMnLCAgICAgIGtpbmQ6ICdrZXl3b3JkJyB9LFxuICB7IHZhbHVlOiAnYWdlbnQuaWQnLCAgICAgICAgICBsYWJlbDogJ0FnZW50IElEJywgICAgICAgICAga2luZDogJ2tleXdvcmQnIH0sXG4gIHsgdmFsdWU6ICdhZ2VudC5uYW1lJywgICAgICAgIGxhYmVsOiAnQWdlbnQgbmFtZScsICAgICAgICBraW5kOiAna2V5d29yZCcgfSxcbiAgeyB2YWx1ZTogJ2FnZW50LmlwJywgICAgICAgICAgbGFiZWw6ICdBZ2VudCBJUCcsICAgICAgICAgIGtpbmQ6ICdrZXl3b3JkJyB9LFxuICB7IHZhbHVlOiAnbG9jYXRpb24nLCAgICAgICAgICBsYWJlbDogJ0xvZyBsb2NhdGlvbicsICAgICAga2luZDogJ2tleXdvcmQnIH0sXG4gIHsgdmFsdWU6ICdkZWNvZGVyLm5hbWUnLCAgICAgIGxhYmVsOiAnRGVjb2RlciBuYW1lJywgICAgICBraW5kOiAna2V5d29yZCcgfSxcbiAgeyB2YWx1ZTogJ2RhdGEuc3JjaXAnLCAgICAgICAgbGFiZWw6ICdTb3VyY2UgSVAnLCAgICAgICAgIGtpbmQ6ICdrZXl3b3JkJyB9LFxuICB7IHZhbHVlOiAnZGF0YS5kc3R1c2VyJywgICAgICBsYWJlbDogJ0Rlc3RpbmF0aW9uIHVzZXInLCAga2luZDogJ2tleXdvcmQnIH0sXG4gIHsgdmFsdWU6ICdmdWxsX2xvZycsICAgICAgICAgIGxhYmVsOiAnUmF3IGxvZycsICAgICAgICAgICBraW5kOiAndGV4dCcgfSxcbl0gYXMgY29uc3Q7XG5cbmV4cG9ydCBjb25zdCBNT05JVE9SX09QRVJBVE9SUyA9IFtcbiAgeyB2YWx1ZTogJ2VxJywgICAgICAgICAgIGxhYmVsOiAnaXMnLCAgICAgICAgICAgICAgICAga2luZHM6IFsnbnVtYmVyJywgJ2tleXdvcmQnLCAndGV4dCddIH0sXG4gIHsgdmFsdWU6ICduZXEnLCAgICAgICAgICBsYWJlbDogJ2lzIG5vdCcsICAgICAgICAgICAgIGtpbmRzOiBbJ251bWJlcicsICdrZXl3b3JkJywgJ3RleHQnXSB9LFxuICB7IHZhbHVlOiAnZ3QnLCAgICAgICAgICAgbGFiZWw6ICdncmVhdGVyIHRoYW4nLCAgICAgICBraW5kczogWydudW1iZXInXSB9LFxuICB7IHZhbHVlOiAnZ3RlJywgICAgICAgICAgbGFiZWw6ICdncmVhdGVyIG9yIGVxdWFsJywgICBraW5kczogWydudW1iZXInXSB9LFxuICB7IHZhbHVlOiAnbHQnLCAgICAgICAgICAgbGFiZWw6ICdsZXNzIHRoYW4nLCAgICAgICAgICBraW5kczogWydudW1iZXInXSB9LFxuICB7IHZhbHVlOiAnbHRlJywgICAgICAgICAgbGFiZWw6ICdsZXNzIG9yIGVxdWFsJywgICAgICBraW5kczogWydudW1iZXInXSB9LFxuICB7IHZhbHVlOiAnaW4nLCAgICAgICAgICAgbGFiZWw6ICdpcyBvbmUgb2YnLCAgICAgICAgICBraW5kczogWydudW1iZXInLCAna2V5d29yZCddIH0sXG4gIHsgdmFsdWU6ICdub3RfaW4nLCAgICAgICBsYWJlbDogJ2lzIG5vbmUgb2YnLCAgICAgICAgIGtpbmRzOiBbJ251bWJlcicsICdrZXl3b3JkJ10gfSxcbiAgeyB2YWx1ZTogJ2NvbnRhaW5zJywgICAgIGxhYmVsOiAnY29udGFpbnMnLCAgICAgICAgICAga2luZHM6IFsna2V5d29yZCcsICd0ZXh0J10gfSxcbiAgeyB2YWx1ZTogJ25vdF9jb250YWlucycsIGxhYmVsOiAnZG9lcyBub3QgY29udGFpbicsICAga2luZHM6IFsna2V5d29yZCcsICd0ZXh0J10gfSxcbiAgeyB2YWx1ZTogJ3N0YXJ0c193aXRoJywgIGxhYmVsOiAnc3RhcnRzIHdpdGgnLCAgICAgICAga2luZHM6IFsna2V5d29yZCcsICd0ZXh0J10gfSxcbiAgeyB2YWx1ZTogJ2V4aXN0cycsICAgICAgIGxhYmVsOiAnZXhpc3RzJywgICAgICAgICAgICAga2luZHM6IFsnbnVtYmVyJywgJ2tleXdvcmQnLCAndGV4dCddIH0sXG4gIHsgdmFsdWU6ICdub3RfZXhpc3RzJywgICBsYWJlbDogJ2RvZXMgbm90IGV4aXN0JywgICAgIGtpbmRzOiBbJ251bWJlcicsICdrZXl3b3JkJywgJ3RleHQnXSB9LFxuXSBhcyBjb25zdDtcblxuLyoqIE9wZXJhdG9ycyB0aGF0IHRha2Ugbm8gdmFsdWUgaW5wdXQgKi9cbmV4cG9ydCBjb25zdCBWQUxVRUxFU1NfT1BFUkFUT1JTID0gWydleGlzdHMnLCAnbm90X2V4aXN0cyddO1xuXG4vKiogU2V2ZXJpdHkgZGVyaXZlZCBmcm9tIHJ1bGUubGV2ZWwgd2hlbiBhIG1vbml0b3IgcnVsZSB1c2VzIHNldmVyaXR5OiAnYXV0bycgKi9cbmV4cG9ydCBjb25zdCBMRVZFTF9TRVZFUklUWV9NQVAgPSBbXG4gIHsgbWluOiAxMywgc2V2ZXJpdHk6ICdjcml0aWNhbCcgfSxcbiAgeyBtaW46IDEwLCBzZXZlcml0eTogJ2hpZ2gnIH0sXG4gIHsgbWluOiA3LCAgc2V2ZXJpdHk6ICdtZWRpdW0nIH0sXG4gIHsgbWluOiA0LCAgc2V2ZXJpdHk6ICdsb3cnIH0sXG4gIHsgbWluOiAwLCAgc2V2ZXJpdHk6ICdpbmZvcm1hdGlvbmFsJyB9LFxuXSBhcyBjb25zdDtcbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDTyxNQUFNQSxTQUFTLEdBQUFDLE9BQUEsQ0FBQUQsU0FBQSxHQUFHLHFCQUFxQjtBQUN2QyxNQUFNRSxXQUFXLEdBQUFELE9BQUEsQ0FBQUMsV0FBQSxHQUFHLGlCQUFpQjtBQUNyQyxNQUFNQyxrQkFBa0IsR0FBQUYsT0FBQSxDQUFBRSxrQkFBQSxHQUFHLDZDQUE2Qzs7QUFFL0U7QUFDTyxNQUFNQyxVQUFVLEdBQUFILE9BQUEsQ0FBQUcsVUFBQSxHQUFHLDZCQUE2QjtBQUNoRCxNQUFNQyxrQkFBa0IsR0FBQUosT0FBQSxDQUFBSSxrQkFBQSxHQUFHLHlCQUF5QjtBQUNwRCxNQUFNQyxrQkFBa0IsR0FBQUwsT0FBQSxDQUFBSyxrQkFBQSxHQUFHLCtCQUErQjtBQUMxRCxNQUFNQyxvQkFBb0IsR0FBQU4sT0FBQSxDQUFBTSxvQkFBQSxHQUFHLCtCQUErQjtBQUM1RCxNQUFNQyxjQUFjLEdBQUFQLE9BQUEsQ0FBQU8sY0FBQSxHQUFHLGdDQUFnQztBQUN2RCxNQUFNQyxrQkFBa0IsR0FBQVIsT0FBQSxDQUFBUSxrQkFBQSxHQUFHLHFDQUFxQzs7QUFFdkU7QUFDTyxNQUFNQywwQkFBMEIsR0FBQVQsT0FBQSxDQUFBUywwQkFBQSxHQUFHLGdCQUFnQjs7QUFFMUQ7QUFDTyxNQUFNQyxVQUFVLEdBQUFWLE9BQUEsQ0FBQVUsVUFBQSxHQUFHLDRCQUE0QjtBQUUvQyxNQUFNQyxVQUFVLEdBQUFYLE9BQUEsQ0FBQVcsVUFBQSxHQUFHO0VBQ3hCO0VBQ0FDLEtBQUssRUFBRyxHQUFFRixVQUFXLFFBQU87RUFDNUJHLFVBQVUsRUFBRyxHQUFFSCxVQUFXLGFBQVk7RUFDdENJLFdBQVcsRUFBRyxHQUFFSixVQUFXLG9CQUFtQjtFQUM5Q0ssV0FBVyxFQUFHLEdBQUVMLFVBQVcsb0JBQW1CO0VBRTlDO0VBQ0FNLGFBQWEsRUFBRyxHQUFFTixVQUFXLHNCQUFxQjtFQUNsRE8sa0JBQWtCLEVBQUcsR0FBRVAsVUFBVyxrQ0FBaUM7RUFFbkU7RUFDQVEsV0FBVyxFQUFHLEdBQUVSLFVBQVcsb0JBQW1CO0VBQzlDUyxnQkFBZ0IsRUFBRyxHQUFFVCxVQUFXLDhCQUE2QjtFQUM3RFUsYUFBYSxFQUFHLEdBQUVWLFVBQVcsZ0JBQWU7RUFFNUM7RUFDQVcsZ0JBQWdCLEVBQUcsR0FBRVgsVUFBVyx5QkFBd0I7RUFDeERZLHFCQUFxQixFQUFHLEdBQUVaLFVBQVcsd0NBQXVDO0VBRTVFO0VBQ0FhLGlCQUFpQixFQUFHLEdBQUViLFVBQVcsb0JBQW1CO0VBQ3BEYyxnQkFBZ0IsRUFBRyxHQUFFZCxVQUFXLG1CQUFrQjtFQUVsRDtFQUNBZSxRQUFRLEVBQUcsR0FBRWYsVUFBVyxXQUFVO0VBRWxDO0VBQ0FnQixFQUFFLEVBQUcsR0FBRWhCLFVBQVcsS0FBSTtFQUN0QmlCLEtBQUssRUFBRyxHQUFFakIsVUFBVyxRQUFPO0VBRTVCO0VBQ0FrQixPQUFPLEVBQUcsR0FBRWxCLFVBQVcsVUFBUztFQUNoQ21CLGNBQWMsRUFBRyxHQUFFbkIsVUFBVyxpQkFBZ0I7RUFDOUNvQixZQUFZLEVBQUcsR0FBRXBCLFVBQVcsZUFBYztFQUUxQztFQUNBcUIsYUFBYSxFQUFHLEdBQUVyQixVQUFXLGdCQUFlO0VBQzVDc0Isa0JBQWtCLEVBQUcsR0FBRXRCLFVBQVcscUJBQW9CO0VBQ3REdUIsa0JBQWtCLEVBQUcsR0FBRXZCLFVBQVcsaUNBQWdDO0VBRWxFO0VBQ0F3Qix5QkFBeUIsRUFBRyxHQUFFeEIsVUFBVyw4QkFBNkI7RUFDdEV5QixTQUFTLEVBQUcsR0FBRXpCLFVBQVcscUJBQW9CO0VBRTdDO0VBQ0EwQixRQUFRLEVBQUcsR0FBRTFCLFVBQVcsb0JBQW1CO0VBQzNDMkIsYUFBYSxFQUFHLEdBQUUzQixVQUFXLDRCQUEyQjtFQUV4RDtFQUNBNEIsVUFBVSxFQUFHLEdBQUU1QixVQUFXLG1CQUFrQjtFQUM1QzZCLGVBQWUsRUFBRyxHQUFFN0IsVUFBVyw0QkFBMkI7RUFFMUQ7RUFDQThCLGNBQWMsRUFBRyxHQUFFOUIsVUFBVztBQUNoQyxDQUFVOztBQUVWO0FBQ08sTUFBTStCLG1CQUFtQixHQUFBekMsT0FBQSxDQUFBeUMsbUJBQUEsR0FBSSxHQUFFL0IsVUFBVyxXQUFVOztBQUUzRDtBQUNPLE1BQU1nQyxjQUFjLEdBQUExQyxPQUFBLENBQUEwQyxjQUFBLEdBQUcsY0FBYzs7QUFFNUM7QUFDTyxNQUFNQyxvQkFBb0IsR0FBQTNDLE9BQUEsQ0FBQTJDLG9CQUFBLEdBQUcsS0FBSzs7QUFFekM7QUFDQTtBQUNBO0FBQ08sTUFBTUMsY0FBYyxHQUFBNUMsT0FBQSxDQUFBNEMsY0FBQSxHQUFHLE1BQU07QUFDN0IsTUFBTUMsaUJBQWlCLEdBQUE3QyxPQUFBLENBQUE2QyxpQkFBQSxHQUFHLEdBQUc7QUFDN0IsTUFBTUMsZUFBZSxHQUFBOUMsT0FBQSxDQUFBOEMsZUFBQSxHQUFHLENBQUM7QUFDekIsTUFBTUMsb0JBQW9CLEdBQUEvQyxPQUFBLENBQUErQyxvQkFBQSxHQUFHLElBQUk7O0FBRXhDO0FBQ0E7QUFDTyxNQUFNQyxhQUFhLEdBQUFoRCxPQUFBLENBQUFnRCxhQUFBLEdBQUcsQ0FDM0I7RUFBRUMsS0FBSyxFQUFFLE1BQU07RUFBRUMsS0FBSyxFQUFFLE1BQU07RUFBRUMsS0FBSyxFQUFFLFNBQVM7RUFBRUMsSUFBSSxFQUFFO0FBQWEsQ0FBQyxFQUN0RTtFQUFFSCxLQUFLLEVBQUUsYUFBYTtFQUFFQyxLQUFLLEVBQUUsYUFBYTtFQUFFQyxLQUFLLEVBQUUsU0FBUztFQUFFQyxJQUFJLEVBQUU7QUFBYSxDQUFDLEVBQ3BGO0VBQUVILEtBQUssRUFBRSxTQUFTO0VBQUVDLEtBQUssRUFBRSxTQUFTO0VBQUVDLEtBQUssRUFBRSxTQUFTO0VBQUVDLElBQUksRUFBRTtBQUFRLENBQUMsRUFDdkU7RUFBRUgsS0FBSyxFQUFFLFVBQVU7RUFBRUMsS0FBSyxFQUFFLFVBQVU7RUFBRUMsS0FBSyxFQUFFLFNBQVM7RUFBRUMsSUFBSSxFQUFFO0FBQXNCLENBQUMsRUFDdkY7RUFBRUgsS0FBSyxFQUFFLFFBQVE7RUFBRUMsS0FBSyxFQUFFLFFBQVE7RUFBRUMsS0FBSyxFQUFFLFNBQVM7RUFBRUMsSUFBSSxFQUFFO0FBQVEsQ0FBQyxDQUM3RDs7QUFFVjtBQUNPLE1BQU1DLGtCQUE0QyxHQUFBckQsT0FBQSxDQUFBcUQsa0JBQUEsR0FBRztFQUMxREMsSUFBSSxFQUFFLENBQUMsYUFBYSxFQUFFLFNBQVMsRUFBRSxRQUFRLENBQUM7RUFDMUNDLFdBQVcsRUFBRSxDQUFDLFNBQVMsRUFBRSxVQUFVLEVBQUUsUUFBUSxDQUFDO0VBQzlDQyxPQUFPLEVBQUUsQ0FBQyxhQUFhLEVBQUUsVUFBVSxFQUFFLFFBQVEsQ0FBQztFQUM5Q0MsUUFBUSxFQUFFLENBQUMsUUFBUSxFQUFFLGFBQWEsQ0FBQztFQUFFO0VBQ3JDQyxNQUFNLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBRTtBQUNwQixDQUFDOztBQUVEO0FBQ08sTUFBTUMsZUFBZSxHQUFBM0QsT0FBQSxDQUFBMkQsZUFBQSxHQUFHLENBQzdCO0VBQUVWLEtBQUssRUFBRSxlQUFlO0VBQUVDLEtBQUssRUFBRSxlQUFlO0VBQUVDLEtBQUssRUFBRSxTQUFTO0VBQUVTLEtBQUssRUFBRTtBQUFFLENBQUMsRUFDOUU7RUFBRVgsS0FBSyxFQUFFLEtBQUs7RUFBRUMsS0FBSyxFQUFFLEtBQUs7RUFBRUMsS0FBSyxFQUFFLFNBQVM7RUFBRVMsS0FBSyxFQUFFO0FBQUUsQ0FBQyxFQUMxRDtFQUFFWCxLQUFLLEVBQUUsUUFBUTtFQUFFQyxLQUFLLEVBQUUsUUFBUTtFQUFFQyxLQUFLLEVBQUUsU0FBUztFQUFFUyxLQUFLLEVBQUU7QUFBRSxDQUFDLEVBQ2hFO0VBQUVYLEtBQUssRUFBRSxNQUFNO0VBQUVDLEtBQUssRUFBRSxNQUFNO0VBQUVDLEtBQUssRUFBRSxTQUFTO0VBQUVTLEtBQUssRUFBRTtBQUFFLENBQUMsRUFDNUQ7RUFBRVgsS0FBSyxFQUFFLFVBQVU7RUFBRUMsS0FBSyxFQUFFLFVBQVU7RUFBRUMsS0FBSyxFQUFFLFNBQVM7RUFBRVMsS0FBSyxFQUFFO0FBQUUsQ0FBQyxDQUM1RDs7QUFFVjtBQUNPLE1BQU1DLGVBQWUsR0FBQTdELE9BQUEsQ0FBQTZELGVBQUEsR0FBRyxDQUM3QjtFQUFFWixLQUFLLEVBQUUsSUFBSTtFQUFFQyxLQUFLLEVBQUUsYUFBYTtFQUFFQyxLQUFLLEVBQUUsU0FBUztFQUFFUyxLQUFLLEVBQUU7QUFBRSxDQUFDLEVBQ2pFO0VBQUVYLEtBQUssRUFBRSxJQUFJO0VBQUVDLEtBQUssRUFBRSxXQUFXO0VBQUVDLEtBQUssRUFBRSxTQUFTO0VBQUVTLEtBQUssRUFBRTtBQUFFLENBQUMsRUFDL0Q7RUFBRVgsS0FBSyxFQUFFLElBQUk7RUFBRUMsS0FBSyxFQUFFLGFBQWE7RUFBRUMsS0FBSyxFQUFFLFNBQVM7RUFBRVMsS0FBSyxFQUFFO0FBQUUsQ0FBQyxFQUNqRTtFQUFFWCxLQUFLLEVBQUUsSUFBSTtFQUFFQyxLQUFLLEVBQUUsVUFBVTtFQUFFQyxLQUFLLEVBQUUsU0FBUztFQUFFUyxLQUFLLEVBQUU7QUFBRSxDQUFDLENBQ3REOztBQUVWO0FBQ08sTUFBTUUsZUFBZSxHQUFBOUQsT0FBQSxDQUFBOEQsZUFBQSxHQUFHLENBQzdCO0VBQUViLEtBQUssRUFBRSxTQUFTO0VBQUVDLEtBQUssRUFBRSxTQUFTO0VBQUVFLElBQUksRUFBRTtBQUFNLENBQUMsRUFDbkQ7RUFBRUgsS0FBSyxFQUFFLG1CQUFtQjtFQUFFQyxLQUFLLEVBQUUsbUJBQW1CO0VBQUVFLElBQUksRUFBRTtBQUFPLENBQUMsRUFDeEU7RUFBRUgsS0FBSyxFQUFFLG1CQUFtQjtFQUFFQyxLQUFLLEVBQUUsbUJBQW1CO0VBQUVFLElBQUksRUFBRTtBQUFlLENBQUMsRUFDaEY7RUFBRUgsS0FBSyxFQUFFLGtCQUFrQjtFQUFFQyxLQUFLLEVBQUUsa0JBQWtCO0VBQUVFLElBQUksRUFBRTtBQUFRLENBQUMsRUFDdkU7RUFBRUgsS0FBSyxFQUFFLGVBQWU7RUFBRUMsS0FBSyxFQUFFLGVBQWU7RUFBRUUsSUFBSSxFQUFFO0FBQWlCLENBQUMsRUFDMUU7RUFBRUgsS0FBSyxFQUFFLFVBQVU7RUFBRUMsS0FBSyxFQUFFLFVBQVU7RUFBRUUsSUFBSSxFQUFFO0FBQVEsQ0FBQyxFQUN2RDtFQUFFSCxLQUFLLEVBQUUsbUJBQW1CO0VBQUVDLEtBQUssRUFBRSxtQkFBbUI7RUFBRUUsSUFBSSxFQUFFO0FBQVUsQ0FBQyxFQUMzRTtFQUFFSCxLQUFLLEVBQUUsZ0JBQWdCO0VBQUVDLEtBQUssRUFBRSxnQkFBZ0I7RUFBRUUsSUFBSSxFQUFFO0FBQU8sQ0FBQyxFQUNsRTtFQUFFSCxLQUFLLEVBQUUscUJBQXFCO0VBQUVDLEtBQUssRUFBRSxxQkFBcUI7RUFBRUUsSUFBSSxFQUFFO0FBQXVCLENBQUMsRUFDNUY7RUFBRUgsS0FBSyxFQUFFLE9BQU87RUFBRUMsS0FBSyxFQUFFLE9BQU87RUFBRUUsSUFBSSxFQUFFO0FBQW1CLENBQUMsQ0FDcEQ7O0FBRVY7QUFDTyxNQUFNVyxnQkFBZ0IsR0FBQS9ELE9BQUEsQ0FBQStELGdCQUFBLEdBQUcsQ0FDOUI7RUFBRWQsS0FBSyxFQUFFLElBQUk7RUFBRUMsS0FBSyxFQUFFO0FBQWEsQ0FBQyxFQUNwQztFQUFFRCxLQUFLLEVBQUUsUUFBUTtFQUFFQyxLQUFLLEVBQUU7QUFBUyxDQUFDLEVBQ3BDO0VBQUVELEtBQUssRUFBRSxLQUFLO0VBQUVDLEtBQUssRUFBRTtBQUFNLENBQUMsRUFDOUI7RUFBRUQsS0FBSyxFQUFFLFVBQVU7RUFBRUMsS0FBSyxFQUFFO0FBQWEsQ0FBQyxFQUMxQztFQUFFRCxLQUFLLEVBQUUsV0FBVztFQUFFQyxLQUFLLEVBQUU7QUFBZSxDQUFDLEVBQzdDO0VBQUVELEtBQUssRUFBRSxhQUFhO0VBQUVDLEtBQUssRUFBRTtBQUFpQixDQUFDLEVBQ2pEO0VBQUVELEtBQUssRUFBRSxPQUFPO0VBQUVDLEtBQUssRUFBRTtBQUFnQixDQUFDLEVBQzFDO0VBQUVELEtBQUssRUFBRSxVQUFVO0VBQUVDLEtBQUssRUFBRTtBQUFXLENBQUMsRUFDeEM7RUFBRUQsS0FBSyxFQUFFLFVBQVU7RUFBRUMsS0FBSyxFQUFFO0FBQVcsQ0FBQyxFQUN4QztFQUFFRCxLQUFLLEVBQUUsTUFBTTtFQUFFQyxLQUFLLEVBQUU7QUFBTyxDQUFDLEVBQ2hDO0VBQUVELEtBQUssRUFBRSxjQUFjO0VBQUVDLEtBQUssRUFBRTtBQUFlLENBQUMsRUFDaEQ7RUFBRUQsS0FBSyxFQUFFLGNBQWM7RUFBRUMsS0FBSyxFQUFFO0FBQWUsQ0FBQyxFQUNoRDtFQUFFRCxLQUFLLEVBQUUsU0FBUztFQUFFQyxLQUFLLEVBQUU7QUFBVSxDQUFDLEVBQ3RDO0VBQUVELEtBQUssRUFBRSxPQUFPO0VBQUVDLEtBQUssRUFBRTtBQUFRLENBQUMsQ0FDMUI7O0FBRVY7QUFDTyxNQUFNYyxpQkFBaUIsR0FBQWhFLE9BQUEsQ0FBQWdFLGlCQUFBLEdBQUcsRUFBRTtBQUM1QixNQUFNQyxhQUFhLEdBQUFqRSxPQUFBLENBQUFpRSxhQUFBLEdBQUcsR0FBRztBQUN6QixNQUFNQyxrQkFBa0IsR0FBQWxFLE9BQUEsQ0FBQWtFLGtCQUFBLEdBQUcsWUFBWTtBQUN2QyxNQUFNQyxrQkFBa0IsR0FBQW5FLE9BQUEsQ0FBQW1FLGtCQUFBLEdBQUcsTUFBTTs7QUFFeEM7QUFDTyxNQUFNQyxLQUFLLEdBQUFwRSxPQUFBLENBQUFvRSxLQUFBLEdBQUc7RUFDbkJDLFVBQVUsRUFBRSxTQUFTO0VBQ3JCQyxPQUFPLEVBQUUsU0FBUztFQUNsQkMsWUFBWSxFQUFFLFNBQVM7RUFDdkJDLE1BQU0sRUFBRSxTQUFTO0VBQ2pCQyxPQUFPLEVBQUUsU0FBUztFQUNsQkMsWUFBWSxFQUFFLFNBQVM7RUFDdkJDLFdBQVcsRUFBRSxTQUFTO0VBQ3RCQyxPQUFPLEVBQUUsU0FBUztFQUNsQkMsT0FBTyxFQUFFLFNBQVM7RUFDbEJDLE1BQU0sRUFBRSxTQUFTO0VBQ2pCQyxRQUFRLEVBQUUsU0FBUztFQUNuQkMsSUFBSSxFQUFFLFNBQVM7RUFDZkMsV0FBVyxFQUFFLFNBQVM7RUFDdEJDLGFBQWEsRUFBRSxTQUFTO0VBQ3hCQyxTQUFTLEVBQUU7QUFDYixDQUFVOztBQUVWO0FBQ08sTUFBTUMsVUFBVSxHQUFBcEYsT0FBQSxDQUFBb0YsVUFBQSxHQUFHLENBQ3hCO0VBQUVuQyxLQUFLLEVBQUUsT0FBTztFQUFFQyxLQUFLLEVBQUUsV0FBVztFQUFFQyxLQUFLLEVBQUUsU0FBUztFQUFFa0MsRUFBRSxFQUFFO0FBQXdCLENBQUMsRUFDckY7RUFBRXBDLEtBQUssRUFBRSxPQUFPO0VBQUVDLEtBQUssRUFBRSxXQUFXO0VBQUVDLEtBQUssRUFBRSxTQUFTO0VBQUVrQyxFQUFFLEVBQUU7QUFBdUIsQ0FBQyxFQUNwRjtFQUFFcEMsS0FBSyxFQUFFLE9BQU87RUFBRUMsS0FBSyxFQUFFLFdBQVc7RUFBRUMsS0FBSyxFQUFFLFNBQVM7RUFBRWtDLEVBQUUsRUFBRTtBQUF3QixDQUFDLEVBQ3JGO0VBQUVwQyxLQUFLLEVBQUUsS0FBSztFQUFJQyxLQUFLLEVBQUUsU0FBUztFQUFJQyxLQUFLLEVBQUUsU0FBUztFQUFFa0MsRUFBRSxFQUFFO0FBQXVCLENBQUMsQ0FDNUU7O0FBRVY7QUFDTyxNQUFNQyxtQkFBbUIsR0FBQXRGLE9BQUEsQ0FBQXNGLG1CQUFBLEdBQUcsQ0FDakM7RUFBRXJDLEtBQUssRUFBRSxjQUFjO0VBQU1DLEtBQUssRUFBRTtBQUFlLENBQUMsRUFDcEQ7RUFBRUQsS0FBSyxFQUFFLGVBQWU7RUFBS0MsS0FBSyxFQUFFO0FBQWdCLENBQUMsRUFDckQ7RUFBRUQsS0FBSyxFQUFFLGdCQUFnQjtFQUFJQyxLQUFLLEVBQUU7QUFBaUIsQ0FBQyxFQUN0RDtFQUFFRCxLQUFLLEVBQUUsa0JBQWtCO0VBQUVDLEtBQUssRUFBRTtBQUFtQixDQUFDLEVBQ3hEO0VBQUVELEtBQUssRUFBRSxlQUFlO0VBQUtDLEtBQUssRUFBRTtBQUFnQixDQUFDLEVBQ3JEO0VBQUVELEtBQUssRUFBRSxlQUFlO0VBQUtDLEtBQUssRUFBRTtBQUFnQixDQUFDLEVBQ3JEO0VBQUVELEtBQUssRUFBRSxnQkFBZ0I7RUFBSUMsS0FBSyxFQUFFO0FBQWlCLENBQUMsQ0FDOUM7QUFFSCxNQUFNcUMsMEJBQTBCLEdBQUF2RixPQUFBLENBQUF1RiwwQkFBQSxHQUFHLENBQ3hDO0VBQUV0QyxLQUFLLEVBQUUsU0FBUztFQUFFQyxLQUFLLEVBQUU7QUFBOEIsQ0FBQyxFQUMxRDtFQUFFRCxLQUFLLEVBQUUsT0FBTztFQUFJQyxLQUFLLEVBQUU7QUFBeUIsQ0FBQyxFQUNyRDtFQUFFRCxLQUFLLEVBQUUsT0FBTztFQUFJQyxLQUFLLEVBQUU7QUFBMEIsQ0FBQyxFQUN0RDtFQUFFRCxLQUFLLEVBQUUsT0FBTztFQUFJQyxLQUFLLEVBQUU7QUFBZSxDQUFDLENBQ25DOztBQUVWO0FBQ08sTUFBTXNDLHFCQUFxQixHQUFBeEYsT0FBQSxDQUFBd0YscUJBQUEsR0FBRyxDQUNuQztFQUFFdkMsS0FBSyxFQUFFLFVBQVU7RUFBRUMsS0FBSyxFQUFFLHVDQUF1QztFQUFFdUMsSUFBSSxFQUFFO0FBQUksQ0FBQyxFQUNoRjtFQUFFeEMsS0FBSyxFQUFFLEtBQUs7RUFBT0MsS0FBSyxFQUFFLDBDQUEwQztFQUFFdUMsSUFBSSxFQUFFO0FBQUksQ0FBQyxFQUNuRjtFQUFFeEMsS0FBSyxFQUFFLE1BQU07RUFBTUMsS0FBSyxFQUFFLG9CQUFvQjtFQUFFdUMsSUFBSSxFQUFFO0FBQUcsQ0FBQyxDQUNwRDtBQUVILE1BQU1DLGVBQWUsR0FBQTFGLE9BQUEsQ0FBQTBGLGVBQUEsR0FBRyxDQUM3QjtFQUFFekMsS0FBSyxFQUFFLE1BQU07RUFBTUMsS0FBSyxFQUFFO0FBQTRDLENBQUMsRUFDekU7RUFBRUQsS0FBSyxFQUFFLE9BQU87RUFBS0MsS0FBSyxFQUFFO0FBQVEsQ0FBQyxFQUNyQztFQUFFRCxLQUFLLEVBQUUsT0FBTztFQUFLQyxLQUFLLEVBQUU7QUFBUSxDQUFDLEVBQ3JDO0VBQUVELEtBQUssRUFBRSxVQUFVO0VBQUVDLEtBQUssRUFBRTtBQUFXLENBQUMsRUFDeEM7RUFBRUQsS0FBSyxFQUFFLE1BQU07RUFBTUMsS0FBSyxFQUFFO0FBQTJCLENBQUMsQ0FDaEQ7O0FBRVY7QUFDTyxNQUFNeUMsdUJBQXVCLEdBQUEzRixPQUFBLENBQUEyRix1QkFBQSxHQUFHLEtBQUs7O0FBRTVDO0FBQ08sTUFBTUMsa0JBQWtCLEdBQUE1RixPQUFBLENBQUE0RixrQkFBQSxHQUFHLENBQ2hDO0VBQUUzQyxLQUFLLEVBQUUsTUFBTTtFQUFLQyxLQUFLLEVBQUUsTUFBTTtFQUMvQjJDLElBQUksRUFBRTtBQUFrRyxDQUFDLEVBQzNHO0VBQUU1QyxLQUFLLEVBQUUsUUFBUTtFQUFHQyxLQUFLLEVBQUUsY0FBYztFQUN2QzJDLElBQUksRUFBRTtBQUF5QyxDQUFDLEVBQ2xEO0VBQUU1QyxLQUFLLEVBQUUsT0FBTztFQUFJQyxLQUFLLEVBQUUsWUFBWTtFQUNyQzJDLElBQUksRUFBRTtBQUEwRCxDQUFDLEVBQ25FO0VBQUU1QyxLQUFLLEVBQUUsU0FBUztFQUFFQyxLQUFLLEVBQUUsZ0JBQWdCO0VBQ3pDMkMsSUFBSSxFQUFFO0FBQTJDLENBQUMsQ0FDNUM7O0FBRVY7QUFDTyxNQUFNQyxrQkFBa0IsR0FBQTlGLE9BQUEsQ0FBQThGLGtCQUFBLEdBQUcsQ0FDaEM7RUFBRTdDLEtBQUssRUFBRSxRQUFRO0VBQVVDLEtBQUssRUFBRSxRQUFRO0VBQWEyQyxJQUFJLEVBQUU7QUFBK0UsQ0FBQyxFQUM3STtFQUFFNUMsS0FBSyxFQUFFLGdCQUFnQjtFQUFFQyxLQUFLLEVBQUUsZ0JBQWdCO0VBQUsyQyxJQUFJLEVBQUU7QUFBcUQsQ0FBQyxFQUNuSDtFQUFFNUMsS0FBSyxFQUFFLGNBQWM7RUFBSUMsS0FBSyxFQUFFLGNBQWM7RUFBTzJDLElBQUksRUFBRTtBQUEyQixDQUFDLEVBQ3pGO0VBQUU1QyxLQUFLLEVBQUUsVUFBVTtFQUFRQyxLQUFLLEVBQUUsZUFBZTtFQUFNMkMsSUFBSSxFQUFFO0FBQW1DLENBQUMsRUFDakc7RUFBRTVDLEtBQUssRUFBRSxTQUFTO0VBQVNDLEtBQUssRUFBRSxTQUFTO0VBQVkyQyxJQUFJLEVBQUU7QUFBeUIsQ0FBQyxDQUMvRTs7QUFFVjtBQUNPLE1BQU1FLGNBQWMsR0FBQS9GLE9BQUEsQ0FBQStGLGNBQUEsR0FBRyxDQUM1QjtFQUFFOUMsS0FBSyxFQUFFLFlBQVk7RUFBU0MsS0FBSyxFQUFFLFlBQVk7RUFBUzhDLElBQUksRUFBRTtBQUFTLENBQUMsRUFDMUU7RUFBRS9DLEtBQUssRUFBRSxTQUFTO0VBQVlDLEtBQUssRUFBRSxTQUFTO0VBQVk4QyxJQUFJLEVBQUU7QUFBVSxDQUFDLEVBQzNFO0VBQUUvQyxLQUFLLEVBQUUsYUFBYTtFQUFRQyxLQUFLLEVBQUUsWUFBWTtFQUFTOEMsSUFBSSxFQUFFO0FBQVUsQ0FBQyxFQUMzRTtFQUFFL0MsS0FBSyxFQUFFLGtCQUFrQjtFQUFHQyxLQUFLLEVBQUUsa0JBQWtCO0VBQUc4QyxJQUFJLEVBQUU7QUFBTyxDQUFDLEVBQ3hFO0VBQUUvQyxLQUFLLEVBQUUsZUFBZTtFQUFNQyxLQUFLLEVBQUUsb0JBQW9CO0VBQUU4QyxJQUFJLEVBQUU7QUFBVSxDQUFDLEVBQzVFO0VBQUUvQyxLQUFLLEVBQUUsbUJBQW1CO0VBQUVDLEtBQUssRUFBRSxjQUFjO0VBQU84QyxJQUFJLEVBQUU7QUFBVSxDQUFDLEVBQzNFO0VBQUUvQyxLQUFLLEVBQUUsVUFBVTtFQUFXQyxLQUFLLEVBQUUsVUFBVTtFQUFXOEMsSUFBSSxFQUFFO0FBQVUsQ0FBQyxFQUMzRTtFQUFFL0MsS0FBSyxFQUFFLFlBQVk7RUFBU0MsS0FBSyxFQUFFLFlBQVk7RUFBUzhDLElBQUksRUFBRTtBQUFVLENBQUMsRUFDM0U7RUFBRS9DLEtBQUssRUFBRSxVQUFVO0VBQVdDLEtBQUssRUFBRSxVQUFVO0VBQVc4QyxJQUFJLEVBQUU7QUFBVSxDQUFDLEVBQzNFO0VBQUUvQyxLQUFLLEVBQUUsVUFBVTtFQUFXQyxLQUFLLEVBQUUsY0FBYztFQUFPOEMsSUFBSSxFQUFFO0FBQVUsQ0FBQyxFQUMzRTtFQUFFL0MsS0FBSyxFQUFFLGNBQWM7RUFBT0MsS0FBSyxFQUFFLGNBQWM7RUFBTzhDLElBQUksRUFBRTtBQUFVLENBQUMsRUFDM0U7RUFBRS9DLEtBQUssRUFBRSxZQUFZO0VBQVNDLEtBQUssRUFBRSxXQUFXO0VBQVU4QyxJQUFJLEVBQUU7QUFBVSxDQUFDLEVBQzNFO0VBQUUvQyxLQUFLLEVBQUUsY0FBYztFQUFPQyxLQUFLLEVBQUUsa0JBQWtCO0VBQUc4QyxJQUFJLEVBQUU7QUFBVSxDQUFDLEVBQzNFO0VBQUUvQyxLQUFLLEVBQUUsVUFBVTtFQUFXQyxLQUFLLEVBQUUsU0FBUztFQUFZOEMsSUFBSSxFQUFFO0FBQU8sQ0FBQyxDQUNoRTtBQUVILE1BQU1DLGlCQUFpQixHQUFBakcsT0FBQSxDQUFBaUcsaUJBQUEsR0FBRyxDQUMvQjtFQUFFaEQsS0FBSyxFQUFFLElBQUk7RUFBWUMsS0FBSyxFQUFFLElBQUk7RUFBa0JnRCxLQUFLLEVBQUUsQ0FBQyxRQUFRLEVBQUUsU0FBUyxFQUFFLE1BQU07QUFBRSxDQUFDLEVBQzVGO0VBQUVqRCxLQUFLLEVBQUUsS0FBSztFQUFXQyxLQUFLLEVBQUUsUUFBUTtFQUFjZ0QsS0FBSyxFQUFFLENBQUMsUUFBUSxFQUFFLFNBQVMsRUFBRSxNQUFNO0FBQUUsQ0FBQyxFQUM1RjtFQUFFakQsS0FBSyxFQUFFLElBQUk7RUFBWUMsS0FBSyxFQUFFLGNBQWM7RUFBUWdELEtBQUssRUFBRSxDQUFDLFFBQVE7QUFBRSxDQUFDLEVBQ3pFO0VBQUVqRCxLQUFLLEVBQUUsS0FBSztFQUFXQyxLQUFLLEVBQUUsa0JBQWtCO0VBQUlnRCxLQUFLLEVBQUUsQ0FBQyxRQUFRO0FBQUUsQ0FBQyxFQUN6RTtFQUFFakQsS0FBSyxFQUFFLElBQUk7RUFBWUMsS0FBSyxFQUFFLFdBQVc7RUFBV2dELEtBQUssRUFBRSxDQUFDLFFBQVE7QUFBRSxDQUFDLEVBQ3pFO0VBQUVqRCxLQUFLLEVBQUUsS0FBSztFQUFXQyxLQUFLLEVBQUUsZUFBZTtFQUFPZ0QsS0FBSyxFQUFFLENBQUMsUUFBUTtBQUFFLENBQUMsRUFDekU7RUFBRWpELEtBQUssRUFBRSxJQUFJO0VBQVlDLEtBQUssRUFBRSxXQUFXO0VBQVdnRCxLQUFLLEVBQUUsQ0FBQyxRQUFRLEVBQUUsU0FBUztBQUFFLENBQUMsRUFDcEY7RUFBRWpELEtBQUssRUFBRSxRQUFRO0VBQVFDLEtBQUssRUFBRSxZQUFZO0VBQVVnRCxLQUFLLEVBQUUsQ0FBQyxRQUFRLEVBQUUsU0FBUztBQUFFLENBQUMsRUFDcEY7RUFBRWpELEtBQUssRUFBRSxVQUFVO0VBQU1DLEtBQUssRUFBRSxVQUFVO0VBQVlnRCxLQUFLLEVBQUUsQ0FBQyxTQUFTLEVBQUUsTUFBTTtBQUFFLENBQUMsRUFDbEY7RUFBRWpELEtBQUssRUFBRSxjQUFjO0VBQUVDLEtBQUssRUFBRSxrQkFBa0I7RUFBSWdELEtBQUssRUFBRSxDQUFDLFNBQVMsRUFBRSxNQUFNO0FBQUUsQ0FBQyxFQUNsRjtFQUFFakQsS0FBSyxFQUFFLGFBQWE7RUFBR0MsS0FBSyxFQUFFLGFBQWE7RUFBU2dELEtBQUssRUFBRSxDQUFDLFNBQVMsRUFBRSxNQUFNO0FBQUUsQ0FBQyxFQUNsRjtFQUFFakQsS0FBSyxFQUFFLFFBQVE7RUFBUUMsS0FBSyxFQUFFLFFBQVE7RUFBY2dELEtBQUssRUFBRSxDQUFDLFFBQVEsRUFBRSxTQUFTLEVBQUUsTUFBTTtBQUFFLENBQUMsRUFDNUY7RUFBRWpELEtBQUssRUFBRSxZQUFZO0VBQUlDLEtBQUssRUFBRSxnQkFBZ0I7RUFBTWdELEtBQUssRUFBRSxDQUFDLFFBQVEsRUFBRSxTQUFTLEVBQUUsTUFBTTtBQUFFLENBQUMsQ0FDcEY7O0FBRVY7QUFDTyxNQUFNQyxtQkFBbUIsR0FBQW5HLE9BQUEsQ0FBQW1HLG1CQUFBLEdBQUcsQ0FBQyxRQUFRLEVBQUUsWUFBWSxDQUFDOztBQUUzRDtBQUNPLE1BQU1DLGtCQUFrQixHQUFBcEcsT0FBQSxDQUFBb0csa0JBQUEsR0FBRyxDQUNoQztFQUFFQyxHQUFHLEVBQUUsRUFBRTtFQUFFQyxRQUFRLEVBQUU7QUFBVyxDQUFDLEVBQ2pDO0VBQUVELEdBQUcsRUFBRSxFQUFFO0VBQUVDLFFBQVEsRUFBRTtBQUFPLENBQUMsRUFDN0I7RUFBRUQsR0FBRyxFQUFFLENBQUM7RUFBR0MsUUFBUSxFQUFFO0FBQVMsQ0FBQyxFQUMvQjtFQUFFRCxHQUFHLEVBQUUsQ0FBQztFQUFHQyxRQUFRLEVBQUU7QUFBTSxDQUFDLEVBQzVCO0VBQUVELEdBQUcsRUFBRSxDQUFDO0VBQUdDLFFBQVEsRUFBRTtBQUFnQixDQUFDLENBQzlCIn0=