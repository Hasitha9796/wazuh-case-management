"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.WazuhCaseManagementPlugin = void 0;
var _constants = require("../common/constants");
var _case_mappings = require("./saved_objects/case_mappings");
var _opensearch_service = require("./services/opensearch_service");
var _monitor_service = require("./services/monitor_service");
var _routes = require("./routes");
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); } /*
 * Wazuh Case Management Plugin
 * Server-side plugin class
 *
 * Handles plugin lifecycle: registers routes, ensures OpenSearch indices exist.
 */
class WazuhCaseManagementPlugin {
  constructor(initializerContext) {
    _defineProperty(this, "logger", void 0);
    this.logger = initializerContext.logger.get();
  }
  setup(core) {
    this.logger.info('Wazuh Case Management plugin: Setting up');

    // Register all API routes
    const router = core.http.createRouter();
    (0, _routes.defineRoutes)(router, this.logger);
    return {};
  }
  async start(core) {
    this.logger.info('Wazuh Case Management plugin: Starting');

    // Ensure required indices exist on startup
    try {
      const client = core.opensearch.client.asInternalUser;
      await this.ensureIndices(client);
      await _monitor_service.MonitorService.ensureConfigIndex(client);
      _monitor_service.MonitorService.start(client, this.logger);
    } catch (error) {
      this.logger.error(`Failed to initialize indices: ${error}`);
    }
    return {};
  }
  stop() {
    _monitor_service.MonitorService.stop();
    this.logger.info('Wazuh Case Management plugin: Stopped');
  }

  /**
   * Ensure that the cases index and counter index exist.
   * Called on startup and safe to call multiple times (idempotent).
   */
  async ensureIndices(client) {
    // Create the main cases index
    const casesExist = await _opensearch_service.OpenSearchService.indexExists(client, _constants.CASE_INDEX);
    if (!casesExist) {
      this.logger.info(`Creating index: ${_constants.CASE_INDEX}`);
      await _opensearch_service.OpenSearchService.createIndex(client, _constants.CASE_INDEX, _case_mappings.caseMappings);
      this.logger.info(`Index created: ${_constants.CASE_INDEX}`);
    } else {
      // Update mappings on existing index to add new fields (tlp, notes)
      try {
        await client.indices.putMapping({
          index: _constants.CASE_INDEX,
          body: {
            properties: {
              tlp: {
                type: 'keyword'
              },
              notes: {
                type: 'text'
              }
            }
          }
        });
      } catch (e) {
        // Non-fatal — dynamic mapping will handle it if putMapping fails
        this.logger.warn(`Could not update mappings: ${e}`);
      }
    }

    // Create the counter index for auto-incrementing case IDs
    const counterExist = await _opensearch_service.OpenSearchService.indexExists(client, _constants.CASE_COUNTER_INDEX);
    if (!counterExist) {
      this.logger.info(`Creating index: ${_constants.CASE_COUNTER_INDEX}`);
      await _opensearch_service.OpenSearchService.createIndex(client, _constants.CASE_COUNTER_INDEX, _case_mappings.counterMappings);
      this.logger.info(`Index created: ${_constants.CASE_COUNTER_INDEX}`);
    }
  }
}
exports.WazuhCaseManagementPlugin = WazuhCaseManagementPlugin;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfY29uc3RhbnRzIiwicmVxdWlyZSIsIl9jYXNlX21hcHBpbmdzIiwiX29wZW5zZWFyY2hfc2VydmljZSIsIl9tb25pdG9yX3NlcnZpY2UiLCJfcm91dGVzIiwiX2RlZmluZVByb3BlcnR5IiwiZSIsInIiLCJ0IiwiX3RvUHJvcGVydHlLZXkiLCJPYmplY3QiLCJkZWZpbmVQcm9wZXJ0eSIsInZhbHVlIiwiZW51bWVyYWJsZSIsImNvbmZpZ3VyYWJsZSIsIndyaXRhYmxlIiwiaSIsIl90b1ByaW1pdGl2ZSIsIlN5bWJvbCIsInRvUHJpbWl0aXZlIiwiY2FsbCIsIlR5cGVFcnJvciIsIlN0cmluZyIsIk51bWJlciIsIldhenVoQ2FzZU1hbmFnZW1lbnRQbHVnaW4iLCJjb25zdHJ1Y3RvciIsImluaXRpYWxpemVyQ29udGV4dCIsImxvZ2dlciIsImdldCIsInNldHVwIiwiY29yZSIsImluZm8iLCJyb3V0ZXIiLCJodHRwIiwiY3JlYXRlUm91dGVyIiwiZGVmaW5lUm91dGVzIiwic3RhcnQiLCJjbGllbnQiLCJvcGVuc2VhcmNoIiwiYXNJbnRlcm5hbFVzZXIiLCJlbnN1cmVJbmRpY2VzIiwiTW9uaXRvclNlcnZpY2UiLCJlbnN1cmVDb25maWdJbmRleCIsImVycm9yIiwic3RvcCIsImNhc2VzRXhpc3QiLCJPcGVuU2VhcmNoU2VydmljZSIsImluZGV4RXhpc3RzIiwiQ0FTRV9JTkRFWCIsImNyZWF0ZUluZGV4IiwiY2FzZU1hcHBpbmdzIiwiaW5kaWNlcyIsInB1dE1hcHBpbmciLCJpbmRleCIsImJvZHkiLCJwcm9wZXJ0aWVzIiwidGxwIiwidHlwZSIsIm5vdGVzIiwid2FybiIsImNvdW50ZXJFeGlzdCIsIkNBU0VfQ09VTlRFUl9JTkRFWCIsImNvdW50ZXJNYXBwaW5ncyIsImV4cG9ydHMiXSwic291cmNlcyI6WyJwbHVnaW4udHMiXSwic291cmNlc0NvbnRlbnQiOlsiLypcbiAqIFdhenVoIENhc2UgTWFuYWdlbWVudCBQbHVnaW5cbiAqIFNlcnZlci1zaWRlIHBsdWdpbiBjbGFzc1xuICpcbiAqIEhhbmRsZXMgcGx1Z2luIGxpZmVjeWNsZTogcmVnaXN0ZXJzIHJvdXRlcywgZW5zdXJlcyBPcGVuU2VhcmNoIGluZGljZXMgZXhpc3QuXG4gKi9cblxuaW1wb3J0IHtcbiAgUGx1Z2luSW5pdGlhbGl6ZXJDb250ZXh0LFxuICBDb3JlU2V0dXAsXG4gIENvcmVTdGFydCxcbiAgUGx1Z2luLFxuICBMb2dnZXIsXG59IGZyb20gJy4uLy4uLy4uL3NyYy9jb3JlL3NlcnZlcic7XG5pbXBvcnQgeyBDQVNFX0lOREVYLCBDQVNFX0NPVU5URVJfSU5ERVggfSBmcm9tICcuLi9jb21tb24vY29uc3RhbnRzJztcbmltcG9ydCB7IGNhc2VNYXBwaW5ncywgY291bnRlck1hcHBpbmdzIH0gZnJvbSAnLi9zYXZlZF9vYmplY3RzL2Nhc2VfbWFwcGluZ3MnO1xuaW1wb3J0IHsgT3BlblNlYXJjaFNlcnZpY2UgfSBmcm9tICcuL3NlcnZpY2VzL29wZW5zZWFyY2hfc2VydmljZSc7XG5pbXBvcnQgeyBNb25pdG9yU2VydmljZSB9IGZyb20gJy4vc2VydmljZXMvbW9uaXRvcl9zZXJ2aWNlJztcbmltcG9ydCB7IGRlZmluZVJvdXRlcyB9IGZyb20gJy4vcm91dGVzJztcblxuZXhwb3J0IGNsYXNzIFdhenVoQ2FzZU1hbmFnZW1lbnRQbHVnaW4gaW1wbGVtZW50cyBQbHVnaW4ge1xuICBwcml2YXRlIHJlYWRvbmx5IGxvZ2dlcjogTG9nZ2VyO1xuXG4gIGNvbnN0cnVjdG9yKGluaXRpYWxpemVyQ29udGV4dDogUGx1Z2luSW5pdGlhbGl6ZXJDb250ZXh0KSB7XG4gICAgdGhpcy5sb2dnZXIgPSBpbml0aWFsaXplckNvbnRleHQubG9nZ2VyLmdldCgpO1xuICB9XG5cbiAgcHVibGljIHNldHVwKGNvcmU6IENvcmVTZXR1cCkge1xuICAgIHRoaXMubG9nZ2VyLmluZm8oJ1dhenVoIENhc2UgTWFuYWdlbWVudCBwbHVnaW46IFNldHRpbmcgdXAnKTtcblxuICAgIC8vIFJlZ2lzdGVyIGFsbCBBUEkgcm91dGVzXG4gICAgY29uc3Qgcm91dGVyID0gY29yZS5odHRwLmNyZWF0ZVJvdXRlcigpO1xuICAgIGRlZmluZVJvdXRlcyhyb3V0ZXIsIHRoaXMubG9nZ2VyKTtcblxuICAgIHJldHVybiB7fTtcbiAgfVxuXG4gIHB1YmxpYyBhc3luYyBzdGFydChjb3JlOiBDb3JlU3RhcnQpIHtcbiAgICB0aGlzLmxvZ2dlci5pbmZvKCdXYXp1aCBDYXNlIE1hbmFnZW1lbnQgcGx1Z2luOiBTdGFydGluZycpO1xuXG4gICAgLy8gRW5zdXJlIHJlcXVpcmVkIGluZGljZXMgZXhpc3Qgb24gc3RhcnR1cFxuICAgIHRyeSB7XG4gICAgICBjb25zdCBjbGllbnQgPSBjb3JlLm9wZW5zZWFyY2guY2xpZW50LmFzSW50ZXJuYWxVc2VyO1xuICAgICAgYXdhaXQgdGhpcy5lbnN1cmVJbmRpY2VzKGNsaWVudCk7XG4gICAgICBhd2FpdCBNb25pdG9yU2VydmljZS5lbnN1cmVDb25maWdJbmRleChjbGllbnQpO1xuICAgICAgTW9uaXRvclNlcnZpY2Uuc3RhcnQoY2xpZW50LCB0aGlzLmxvZ2dlcik7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIHRoaXMubG9nZ2VyLmVycm9yKGBGYWlsZWQgdG8gaW5pdGlhbGl6ZSBpbmRpY2VzOiAke2Vycm9yfWApO1xuICAgIH1cblxuICAgIHJldHVybiB7fTtcbiAgfVxuXG4gIHB1YmxpYyBzdG9wKCkge1xuICAgIE1vbml0b3JTZXJ2aWNlLnN0b3AoKTtcbiAgICB0aGlzLmxvZ2dlci5pbmZvKCdXYXp1aCBDYXNlIE1hbmFnZW1lbnQgcGx1Z2luOiBTdG9wcGVkJyk7XG4gIH1cblxuICAvKipcbiAgICogRW5zdXJlIHRoYXQgdGhlIGNhc2VzIGluZGV4IGFuZCBjb3VudGVyIGluZGV4IGV4aXN0LlxuICAgKiBDYWxsZWQgb24gc3RhcnR1cCBhbmQgc2FmZSB0byBjYWxsIG11bHRpcGxlIHRpbWVzIChpZGVtcG90ZW50KS5cbiAgICovXG4gIHByaXZhdGUgYXN5bmMgZW5zdXJlSW5kaWNlcyhjbGllbnQ6IGFueSk6IFByb21pc2U8dm9pZD4ge1xuICAgIC8vIENyZWF0ZSB0aGUgbWFpbiBjYXNlcyBpbmRleFxuICAgIGNvbnN0IGNhc2VzRXhpc3QgPSBhd2FpdCBPcGVuU2VhcmNoU2VydmljZS5pbmRleEV4aXN0cyhjbGllbnQsIENBU0VfSU5ERVgpO1xuICAgIGlmICghY2FzZXNFeGlzdCkge1xuICAgICAgdGhpcy5sb2dnZXIuaW5mbyhgQ3JlYXRpbmcgaW5kZXg6ICR7Q0FTRV9JTkRFWH1gKTtcbiAgICAgIGF3YWl0IE9wZW5TZWFyY2hTZXJ2aWNlLmNyZWF0ZUluZGV4KGNsaWVudCwgQ0FTRV9JTkRFWCwgY2FzZU1hcHBpbmdzKTtcbiAgICAgIHRoaXMubG9nZ2VyLmluZm8oYEluZGV4IGNyZWF0ZWQ6ICR7Q0FTRV9JTkRFWH1gKTtcbiAgICB9IGVsc2Uge1xuICAgICAgLy8gVXBkYXRlIG1hcHBpbmdzIG9uIGV4aXN0aW5nIGluZGV4IHRvIGFkZCBuZXcgZmllbGRzICh0bHAsIG5vdGVzKVxuICAgICAgdHJ5IHtcbiAgICAgICAgYXdhaXQgY2xpZW50LmluZGljZXMucHV0TWFwcGluZyh7XG4gICAgICAgICAgaW5kZXg6IENBU0VfSU5ERVgsXG4gICAgICAgICAgYm9keTogeyBwcm9wZXJ0aWVzOiB7IHRscDogeyB0eXBlOiAna2V5d29yZCcgfSwgbm90ZXM6IHsgdHlwZTogJ3RleHQnIH0gfSB9LFxuICAgICAgICB9KTtcbiAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgLy8gTm9uLWZhdGFsIOKAlCBkeW5hbWljIG1hcHBpbmcgd2lsbCBoYW5kbGUgaXQgaWYgcHV0TWFwcGluZyBmYWlsc1xuICAgICAgICB0aGlzLmxvZ2dlci53YXJuKGBDb3VsZCBub3QgdXBkYXRlIG1hcHBpbmdzOiAke2V9YCk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgLy8gQ3JlYXRlIHRoZSBjb3VudGVyIGluZGV4IGZvciBhdXRvLWluY3JlbWVudGluZyBjYXNlIElEc1xuICAgIGNvbnN0IGNvdW50ZXJFeGlzdCA9IGF3YWl0IE9wZW5TZWFyY2hTZXJ2aWNlLmluZGV4RXhpc3RzKGNsaWVudCwgQ0FTRV9DT1VOVEVSX0lOREVYKTtcbiAgICBpZiAoIWNvdW50ZXJFeGlzdCkge1xuICAgICAgdGhpcy5sb2dnZXIuaW5mbyhgQ3JlYXRpbmcgaW5kZXg6ICR7Q0FTRV9DT1VOVEVSX0lOREVYfWApO1xuICAgICAgYXdhaXQgT3BlblNlYXJjaFNlcnZpY2UuY3JlYXRlSW5kZXgoY2xpZW50LCBDQVNFX0NPVU5URVJfSU5ERVgsIGNvdW50ZXJNYXBwaW5ncyk7XG4gICAgICB0aGlzLmxvZ2dlci5pbmZvKGBJbmRleCBjcmVhdGVkOiAke0NBU0VfQ09VTlRFUl9JTkRFWH1gKTtcbiAgICB9XG4gIH1cbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBY0EsSUFBQUEsVUFBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsY0FBQSxHQUFBRCxPQUFBO0FBQ0EsSUFBQUUsbUJBQUEsR0FBQUYsT0FBQTtBQUNBLElBQUFHLGdCQUFBLEdBQUFILE9BQUE7QUFDQSxJQUFBSSxPQUFBLEdBQUFKLE9BQUE7QUFBd0MsU0FBQUssZ0JBQUFDLENBQUEsRUFBQUMsQ0FBQSxFQUFBQyxDQUFBLFlBQUFELENBQUEsR0FBQUUsY0FBQSxDQUFBRixDQUFBLE1BQUFELENBQUEsR0FBQUksTUFBQSxDQUFBQyxjQUFBLENBQUFMLENBQUEsRUFBQUMsQ0FBQSxJQUFBSyxLQUFBLEVBQUFKLENBQUEsRUFBQUssVUFBQSxNQUFBQyxZQUFBLE1BQUFDLFFBQUEsVUFBQVQsQ0FBQSxDQUFBQyxDQUFBLElBQUFDLENBQUEsRUFBQUYsQ0FBQTtBQUFBLFNBQUFHLGVBQUFELENBQUEsUUFBQVEsQ0FBQSxHQUFBQyxZQUFBLENBQUFULENBQUEsdUNBQUFRLENBQUEsR0FBQUEsQ0FBQSxHQUFBQSxDQUFBO0FBQUEsU0FBQUMsYUFBQVQsQ0FBQSxFQUFBRCxDQUFBLDJCQUFBQyxDQUFBLEtBQUFBLENBQUEsU0FBQUEsQ0FBQSxNQUFBRixDQUFBLEdBQUFFLENBQUEsQ0FBQVUsTUFBQSxDQUFBQyxXQUFBLGtCQUFBYixDQUFBLFFBQUFVLENBQUEsR0FBQVYsQ0FBQSxDQUFBYyxJQUFBLENBQUFaLENBQUEsRUFBQUQsQ0FBQSx1Q0FBQVMsQ0FBQSxTQUFBQSxDQUFBLFlBQUFLLFNBQUEseUVBQUFkLENBQUEsR0FBQWUsTUFBQSxHQUFBQyxNQUFBLEVBQUFmLENBQUEsS0FsQnhDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQWVPLE1BQU1nQix5QkFBeUIsQ0FBbUI7RUFHdkRDLFdBQVdBLENBQUNDLGtCQUE0QyxFQUFFO0lBQUFyQixlQUFBO0lBQ3hELElBQUksQ0FBQ3NCLE1BQU0sR0FBR0Qsa0JBQWtCLENBQUNDLE1BQU0sQ0FBQ0MsR0FBRyxDQUFDLENBQUM7RUFDL0M7RUFFT0MsS0FBS0EsQ0FBQ0MsSUFBZSxFQUFFO0lBQzVCLElBQUksQ0FBQ0gsTUFBTSxDQUFDSSxJQUFJLENBQUMsMENBQTBDLENBQUM7O0lBRTVEO0lBQ0EsTUFBTUMsTUFBTSxHQUFHRixJQUFJLENBQUNHLElBQUksQ0FBQ0MsWUFBWSxDQUFDLENBQUM7SUFDdkMsSUFBQUMsb0JBQVksRUFBQ0gsTUFBTSxFQUFFLElBQUksQ0FBQ0wsTUFBTSxDQUFDO0lBRWpDLE9BQU8sQ0FBQyxDQUFDO0VBQ1g7RUFFQSxNQUFhUyxLQUFLQSxDQUFDTixJQUFlLEVBQUU7SUFDbEMsSUFBSSxDQUFDSCxNQUFNLENBQUNJLElBQUksQ0FBQyx3Q0FBd0MsQ0FBQzs7SUFFMUQ7SUFDQSxJQUFJO01BQ0YsTUFBTU0sTUFBTSxHQUFHUCxJQUFJLENBQUNRLFVBQVUsQ0FBQ0QsTUFBTSxDQUFDRSxjQUFjO01BQ3BELE1BQU0sSUFBSSxDQUFDQyxhQUFhLENBQUNILE1BQU0sQ0FBQztNQUNoQyxNQUFNSSwrQkFBYyxDQUFDQyxpQkFBaUIsQ0FBQ0wsTUFBTSxDQUFDO01BQzlDSSwrQkFBYyxDQUFDTCxLQUFLLENBQUNDLE1BQU0sRUFBRSxJQUFJLENBQUNWLE1BQU0sQ0FBQztJQUMzQyxDQUFDLENBQUMsT0FBT2dCLEtBQUssRUFBRTtNQUNkLElBQUksQ0FBQ2hCLE1BQU0sQ0FBQ2dCLEtBQUssQ0FBRSxpQ0FBZ0NBLEtBQU0sRUFBQyxDQUFDO0lBQzdEO0lBRUEsT0FBTyxDQUFDLENBQUM7RUFDWDtFQUVPQyxJQUFJQSxDQUFBLEVBQUc7SUFDWkgsK0JBQWMsQ0FBQ0csSUFBSSxDQUFDLENBQUM7SUFDckIsSUFBSSxDQUFDakIsTUFBTSxDQUFDSSxJQUFJLENBQUMsdUNBQXVDLENBQUM7RUFDM0Q7O0VBRUE7QUFDRjtBQUNBO0FBQ0E7RUFDRSxNQUFjUyxhQUFhQSxDQUFDSCxNQUFXLEVBQWlCO0lBQ3REO0lBQ0EsTUFBTVEsVUFBVSxHQUFHLE1BQU1DLHFDQUFpQixDQUFDQyxXQUFXLENBQUNWLE1BQU0sRUFBRVcscUJBQVUsQ0FBQztJQUMxRSxJQUFJLENBQUNILFVBQVUsRUFBRTtNQUNmLElBQUksQ0FBQ2xCLE1BQU0sQ0FBQ0ksSUFBSSxDQUFFLG1CQUFrQmlCLHFCQUFXLEVBQUMsQ0FBQztNQUNqRCxNQUFNRixxQ0FBaUIsQ0FBQ0csV0FBVyxDQUFDWixNQUFNLEVBQUVXLHFCQUFVLEVBQUVFLDJCQUFZLENBQUM7TUFDckUsSUFBSSxDQUFDdkIsTUFBTSxDQUFDSSxJQUFJLENBQUUsa0JBQWlCaUIscUJBQVcsRUFBQyxDQUFDO0lBQ2xELENBQUMsTUFBTTtNQUNMO01BQ0EsSUFBSTtRQUNGLE1BQU1YLE1BQU0sQ0FBQ2MsT0FBTyxDQUFDQyxVQUFVLENBQUM7VUFDOUJDLEtBQUssRUFBRUwscUJBQVU7VUFDakJNLElBQUksRUFBRTtZQUFFQyxVQUFVLEVBQUU7Y0FBRUMsR0FBRyxFQUFFO2dCQUFFQyxJQUFJLEVBQUU7Y0FBVSxDQUFDO2NBQUVDLEtBQUssRUFBRTtnQkFBRUQsSUFBSSxFQUFFO2NBQU87WUFBRTtVQUFFO1FBQzVFLENBQUMsQ0FBQztNQUNKLENBQUMsQ0FBQyxPQUFPbkQsQ0FBQyxFQUFFO1FBQ1Y7UUFDQSxJQUFJLENBQUNxQixNQUFNLENBQUNnQyxJQUFJLENBQUUsOEJBQTZCckQsQ0FBRSxFQUFDLENBQUM7TUFDckQ7SUFDRjs7SUFFQTtJQUNBLE1BQU1zRCxZQUFZLEdBQUcsTUFBTWQscUNBQWlCLENBQUNDLFdBQVcsQ0FBQ1YsTUFBTSxFQUFFd0IsNkJBQWtCLENBQUM7SUFDcEYsSUFBSSxDQUFDRCxZQUFZLEVBQUU7TUFDakIsSUFBSSxDQUFDakMsTUFBTSxDQUFDSSxJQUFJLENBQUUsbUJBQWtCOEIsNkJBQW1CLEVBQUMsQ0FBQztNQUN6RCxNQUFNZixxQ0FBaUIsQ0FBQ0csV0FBVyxDQUFDWixNQUFNLEVBQUV3Qiw2QkFBa0IsRUFBRUMsOEJBQWUsQ0FBQztNQUNoRixJQUFJLENBQUNuQyxNQUFNLENBQUNJLElBQUksQ0FBRSxrQkFBaUI4Qiw2QkFBbUIsRUFBQyxDQUFDO0lBQzFEO0VBQ0Y7QUFDRjtBQUFDRSxPQUFBLENBQUF2Qyx5QkFBQSxHQUFBQSx5QkFBQSJ9