"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.WazuhCaseManagementPlugin = void 0;
var _constants = require("../common/constants");
var _case_mappings = require("./saved_objects/case_mappings");
var _opensearch_service = require("./services/opensearch_service");
var _monitor_service = require("./services/monitor_service");
var _settings_service = require("./services/settings_service");
var _notification_service = require("./services/notification_service");
var _escalation_service = require("./services/escalation_service");
var _routes = require("./routes");
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); } /*
 * Wazuh Case Management Plugin
 * Server-side plugin class
 *
 * Handles plugin lifecycle: registers routes, ensures OpenSearch indices exist.
 */
class WazuhCaseManagementPlugin {
  constructor(initializerContext) {
    _defineProperty(this, "logger", void 0);
    this.logger = initializerContext.logger.get();
  }
  setup(core) {
    this.logger.info('Wazuh Case Management plugin: Setting up');

    // Register all API routes
    const router = core.http.createRouter();
    (0, _routes.defineRoutes)(router, this.logger);
    return {};
  }
  async start(core) {
    this.logger.info('Wazuh Case Management plugin: Starting');

    // Ensure required indices exist on startup
    try {
      const client = core.opensearch.client.asInternalUser;
      await this.ensureIndices(client);
      await _monitor_service.MonitorService.ensureConfigIndex(client);
      await _settings_service.SettingsService.ensureIndex(client);
      await _notification_service.NotificationService.ensureIndex(client);
      _monitor_service.MonitorService.start(client, this.logger);
      _escalation_service.EscalationService.start(client, this.logger);
    } catch (error) {
      this.logger.error(`Failed to initialize indices: ${error}`);
    }
    return {};
  }
  stop() {
    _monitor_service.MonitorService.stop();
    _escalation_service.EscalationService.stop();
    this.logger.info('Wazuh Case Management plugin: Stopped');
  }

  /**
   * Ensure that the cases index and counter index exist.
   * Called on startup and safe to call multiple times (idempotent).
   */
  async ensureIndices(client) {
    // Register index templates FIRST so that any future (re)creation of these
    // indices uses the correct keyword mappings instead of dynamic text ones.
    // That includes an implicit creation triggered by a write after the index
    // has been deleted.
    try {
      await _opensearch_service.OpenSearchService.ensureTemplate(client, 'wazuh-case-management-cases', [_constants.CASE_INDEX], _case_mappings.caseMappings);
      await _opensearch_service.OpenSearchService.ensureTemplate(client, 'wazuh-case-management-counter', [_constants.CASE_COUNTER_INDEX], _case_mappings.counterMappings);
      this.logger.info('Case management index templates ensured');
    } catch (e) {
      this.logger.warn(`Could not register index templates: ${e}`);
    }

    // Create the main cases index
    const casesExist = await _opensearch_service.OpenSearchService.indexExists(client, _constants.CASE_INDEX);
    if (!casesExist) {
      this.logger.info(`Creating index: ${_constants.CASE_INDEX}`);
      await _opensearch_service.OpenSearchService.createIndex(client, _constants.CASE_INDEX, _case_mappings.caseMappings);
      this.logger.info(`Index created: ${_constants.CASE_INDEX}`);
    } else {
      // Update mappings on existing index to add new fields (tlp, notes)
      try {
        // Additive mapping update so indices created by earlier plugin versions
        // gain the fields added since (tlp, notes, tasks, escalation_state).
        await client.indices.putMapping({
          index: _constants.CASE_INDEX,
          body: {
            properties: {
              tlp: {
                type: 'keyword'
              },
              notes: {
                type: 'text'
              },
              escalation_state: {
                properties: {
                  policy_id: {
                    type: 'keyword'
                  },
                  level: {
                    type: 'integer'
                  },
                  last_escalated_at: {
                    type: 'date'
                  },
                  history: {
                    type: 'object',
                    enabled: false
                  }
                }
              }
            }
          }
        });
      } catch (e) {
        // Non-fatal: dynamic mapping will handle it if putMapping fails
        this.logger.warn(`Could not update mappings: ${e}`);
      }
    }

    // Create the counter index for auto-incrementing case IDs
    const counterExist = await _opensearch_service.OpenSearchService.indexExists(client, _constants.CASE_COUNTER_INDEX);
    if (!counterExist) {
      this.logger.info(`Creating index: ${_constants.CASE_COUNTER_INDEX}`);
      await _opensearch_service.OpenSearchService.createIndex(client, _constants.CASE_COUNTER_INDEX, _case_mappings.counterMappings);
      this.logger.info(`Index created: ${_constants.CASE_COUNTER_INDEX}`);
    }
  }
}
exports.WazuhCaseManagementPlugin = WazuhCaseManagementPlugin;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfY29uc3RhbnRzIiwicmVxdWlyZSIsIl9jYXNlX21hcHBpbmdzIiwiX29wZW5zZWFyY2hfc2VydmljZSIsIl9tb25pdG9yX3NlcnZpY2UiLCJfc2V0dGluZ3Nfc2VydmljZSIsIl9ub3RpZmljYXRpb25fc2VydmljZSIsIl9lc2NhbGF0aW9uX3NlcnZpY2UiLCJfcm91dGVzIiwiX2RlZmluZVByb3BlcnR5IiwiZSIsInIiLCJ0IiwiX3RvUHJvcGVydHlLZXkiLCJPYmplY3QiLCJkZWZpbmVQcm9wZXJ0eSIsInZhbHVlIiwiZW51bWVyYWJsZSIsImNvbmZpZ3VyYWJsZSIsIndyaXRhYmxlIiwiaSIsIl90b1ByaW1pdGl2ZSIsIlN5bWJvbCIsInRvUHJpbWl0aXZlIiwiY2FsbCIsIlR5cGVFcnJvciIsIlN0cmluZyIsIk51bWJlciIsIldhenVoQ2FzZU1hbmFnZW1lbnRQbHVnaW4iLCJjb25zdHJ1Y3RvciIsImluaXRpYWxpemVyQ29udGV4dCIsImxvZ2dlciIsImdldCIsInNldHVwIiwiY29yZSIsImluZm8iLCJyb3V0ZXIiLCJodHRwIiwiY3JlYXRlUm91dGVyIiwiZGVmaW5lUm91dGVzIiwic3RhcnQiLCJjbGllbnQiLCJvcGVuc2VhcmNoIiwiYXNJbnRlcm5hbFVzZXIiLCJlbnN1cmVJbmRpY2VzIiwiTW9uaXRvclNlcnZpY2UiLCJlbnN1cmVDb25maWdJbmRleCIsIlNldHRpbmdzU2VydmljZSIsImVuc3VyZUluZGV4IiwiTm90aWZpY2F0aW9uU2VydmljZSIsIkVzY2FsYXRpb25TZXJ2aWNlIiwiZXJyb3IiLCJzdG9wIiwiT3BlblNlYXJjaFNlcnZpY2UiLCJlbnN1cmVUZW1wbGF0ZSIsIkNBU0VfSU5ERVgiLCJjYXNlTWFwcGluZ3MiLCJDQVNFX0NPVU5URVJfSU5ERVgiLCJjb3VudGVyTWFwcGluZ3MiLCJ3YXJuIiwiY2FzZXNFeGlzdCIsImluZGV4RXhpc3RzIiwiY3JlYXRlSW5kZXgiLCJpbmRpY2VzIiwicHV0TWFwcGluZyIsImluZGV4IiwiYm9keSIsInByb3BlcnRpZXMiLCJ0bHAiLCJ0eXBlIiwibm90ZXMiLCJlc2NhbGF0aW9uX3N0YXRlIiwicG9saWN5X2lkIiwibGV2ZWwiLCJsYXN0X2VzY2FsYXRlZF9hdCIsImhpc3RvcnkiLCJlbmFibGVkIiwiY291bnRlckV4aXN0IiwiZXhwb3J0cyJdLCJzb3VyY2VzIjpbInBsdWdpbi50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogV2F6dWggQ2FzZSBNYW5hZ2VtZW50IFBsdWdpblxuICogU2VydmVyLXNpZGUgcGx1Z2luIGNsYXNzXG4gKlxuICogSGFuZGxlcyBwbHVnaW4gbGlmZWN5Y2xlOiByZWdpc3RlcnMgcm91dGVzLCBlbnN1cmVzIE9wZW5TZWFyY2ggaW5kaWNlcyBleGlzdC5cbiAqL1xuXG5pbXBvcnQge1xuICBQbHVnaW5Jbml0aWFsaXplckNvbnRleHQsXG4gIENvcmVTZXR1cCxcbiAgQ29yZVN0YXJ0LFxuICBQbHVnaW4sXG4gIExvZ2dlcixcbn0gZnJvbSAnLi4vLi4vLi4vc3JjL2NvcmUvc2VydmVyJztcbmltcG9ydCB7IENBU0VfSU5ERVgsIENBU0VfQ09VTlRFUl9JTkRFWCB9IGZyb20gJy4uL2NvbW1vbi9jb25zdGFudHMnO1xuaW1wb3J0IHsgY2FzZU1hcHBpbmdzLCBjb3VudGVyTWFwcGluZ3MgfSBmcm9tICcuL3NhdmVkX29iamVjdHMvY2FzZV9tYXBwaW5ncyc7XG5pbXBvcnQgeyBPcGVuU2VhcmNoU2VydmljZSB9IGZyb20gJy4vc2VydmljZXMvb3BlbnNlYXJjaF9zZXJ2aWNlJztcbmltcG9ydCB7IE1vbml0b3JTZXJ2aWNlIH0gZnJvbSAnLi9zZXJ2aWNlcy9tb25pdG9yX3NlcnZpY2UnO1xuaW1wb3J0IHsgU2V0dGluZ3NTZXJ2aWNlIH0gZnJvbSAnLi9zZXJ2aWNlcy9zZXR0aW5nc19zZXJ2aWNlJztcbmltcG9ydCB7IE5vdGlmaWNhdGlvblNlcnZpY2UgfSBmcm9tICcuL3NlcnZpY2VzL25vdGlmaWNhdGlvbl9zZXJ2aWNlJztcbmltcG9ydCB7IEVzY2FsYXRpb25TZXJ2aWNlIH0gZnJvbSAnLi9zZXJ2aWNlcy9lc2NhbGF0aW9uX3NlcnZpY2UnO1xuaW1wb3J0IHsgZGVmaW5lUm91dGVzIH0gZnJvbSAnLi9yb3V0ZXMnO1xuXG5leHBvcnQgY2xhc3MgV2F6dWhDYXNlTWFuYWdlbWVudFBsdWdpbiBpbXBsZW1lbnRzIFBsdWdpbiB7XG4gIHByaXZhdGUgcmVhZG9ubHkgbG9nZ2VyOiBMb2dnZXI7XG5cbiAgY29uc3RydWN0b3IoaW5pdGlhbGl6ZXJDb250ZXh0OiBQbHVnaW5Jbml0aWFsaXplckNvbnRleHQpIHtcbiAgICB0aGlzLmxvZ2dlciA9IGluaXRpYWxpemVyQ29udGV4dC5sb2dnZXIuZ2V0KCk7XG4gIH1cblxuICBwdWJsaWMgc2V0dXAoY29yZTogQ29yZVNldHVwKSB7XG4gICAgdGhpcy5sb2dnZXIuaW5mbygnV2F6dWggQ2FzZSBNYW5hZ2VtZW50IHBsdWdpbjogU2V0dGluZyB1cCcpO1xuXG4gICAgLy8gUmVnaXN0ZXIgYWxsIEFQSSByb3V0ZXNcbiAgICBjb25zdCByb3V0ZXIgPSBjb3JlLmh0dHAuY3JlYXRlUm91dGVyKCk7XG4gICAgZGVmaW5lUm91dGVzKHJvdXRlciwgdGhpcy5sb2dnZXIpO1xuXG4gICAgcmV0dXJuIHt9O1xuICB9XG5cbiAgcHVibGljIGFzeW5jIHN0YXJ0KGNvcmU6IENvcmVTdGFydCkge1xuICAgIHRoaXMubG9nZ2VyLmluZm8oJ1dhenVoIENhc2UgTWFuYWdlbWVudCBwbHVnaW46IFN0YXJ0aW5nJyk7XG5cbiAgICAvLyBFbnN1cmUgcmVxdWlyZWQgaW5kaWNlcyBleGlzdCBvbiBzdGFydHVwXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGNsaWVudCA9IGNvcmUub3BlbnNlYXJjaC5jbGllbnQuYXNJbnRlcm5hbFVzZXI7XG4gICAgICBhd2FpdCB0aGlzLmVuc3VyZUluZGljZXMoY2xpZW50KTtcbiAgICAgIGF3YWl0IE1vbml0b3JTZXJ2aWNlLmVuc3VyZUNvbmZpZ0luZGV4KGNsaWVudCk7XG4gICAgICBhd2FpdCBTZXR0aW5nc1NlcnZpY2UuZW5zdXJlSW5kZXgoY2xpZW50KTtcbiAgICAgIGF3YWl0IE5vdGlmaWNhdGlvblNlcnZpY2UuZW5zdXJlSW5kZXgoY2xpZW50KTtcbiAgICAgIE1vbml0b3JTZXJ2aWNlLnN0YXJ0KGNsaWVudCwgdGhpcy5sb2dnZXIpO1xuICAgICAgRXNjYWxhdGlvblNlcnZpY2Uuc3RhcnQoY2xpZW50LCB0aGlzLmxvZ2dlcik7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIHRoaXMubG9nZ2VyLmVycm9yKGBGYWlsZWQgdG8gaW5pdGlhbGl6ZSBpbmRpY2VzOiAke2Vycm9yfWApO1xuICAgIH1cblxuICAgIHJldHVybiB7fTtcbiAgfVxuXG4gIHB1YmxpYyBzdG9wKCkge1xuICAgIE1vbml0b3JTZXJ2aWNlLnN0b3AoKTtcbiAgICBFc2NhbGF0aW9uU2VydmljZS5zdG9wKCk7XG4gICAgdGhpcy5sb2dnZXIuaW5mbygnV2F6dWggQ2FzZSBNYW5hZ2VtZW50IHBsdWdpbjogU3RvcHBlZCcpO1xuICB9XG5cbiAgLyoqXG4gICAqIEVuc3VyZSB0aGF0IHRoZSBjYXNlcyBpbmRleCBhbmQgY291bnRlciBpbmRleCBleGlzdC5cbiAgICogQ2FsbGVkIG9uIHN0YXJ0dXAgYW5kIHNhZmUgdG8gY2FsbCBtdWx0aXBsZSB0aW1lcyAoaWRlbXBvdGVudCkuXG4gICAqL1xuICBwcml2YXRlIGFzeW5jIGVuc3VyZUluZGljZXMoY2xpZW50OiBhbnkpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICAvLyBSZWdpc3RlciBpbmRleCB0ZW1wbGF0ZXMgRklSU1Qgc28gdGhhdCBhbnkgZnV0dXJlIChyZSljcmVhdGlvbiBvZiB0aGVzZVxuICAgIC8vIGluZGljZXMgdXNlcyB0aGUgY29ycmVjdCBrZXl3b3JkIG1hcHBpbmdzIGluc3RlYWQgb2YgZHluYW1pYyB0ZXh0IG9uZXMuXG4gICAgLy8gVGhhdCBpbmNsdWRlcyBhbiBpbXBsaWNpdCBjcmVhdGlvbiB0cmlnZ2VyZWQgYnkgYSB3cml0ZSBhZnRlciB0aGUgaW5kZXhcbiAgICAvLyBoYXMgYmVlbiBkZWxldGVkLlxuICAgIHRyeSB7XG4gICAgICBhd2FpdCBPcGVuU2VhcmNoU2VydmljZS5lbnN1cmVUZW1wbGF0ZShjbGllbnQsICd3YXp1aC1jYXNlLW1hbmFnZW1lbnQtY2FzZXMnLCBbQ0FTRV9JTkRFWF0sIGNhc2VNYXBwaW5ncyk7XG4gICAgICBhd2FpdCBPcGVuU2VhcmNoU2VydmljZS5lbnN1cmVUZW1wbGF0ZShjbGllbnQsICd3YXp1aC1jYXNlLW1hbmFnZW1lbnQtY291bnRlcicsIFtDQVNFX0NPVU5URVJfSU5ERVhdLCBjb3VudGVyTWFwcGluZ3MpO1xuICAgICAgdGhpcy5sb2dnZXIuaW5mbygnQ2FzZSBtYW5hZ2VtZW50IGluZGV4IHRlbXBsYXRlcyBlbnN1cmVkJyk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgdGhpcy5sb2dnZXIud2FybihgQ291bGQgbm90IHJlZ2lzdGVyIGluZGV4IHRlbXBsYXRlczogJHtlfWApO1xuICAgIH1cblxuICAgIC8vIENyZWF0ZSB0aGUgbWFpbiBjYXNlcyBpbmRleFxuICAgIGNvbnN0IGNhc2VzRXhpc3QgPSBhd2FpdCBPcGVuU2VhcmNoU2VydmljZS5pbmRleEV4aXN0cyhjbGllbnQsIENBU0VfSU5ERVgpO1xuICAgIGlmICghY2FzZXNFeGlzdCkge1xuICAgICAgdGhpcy5sb2dnZXIuaW5mbyhgQ3JlYXRpbmcgaW5kZXg6ICR7Q0FTRV9JTkRFWH1gKTtcbiAgICAgIGF3YWl0IE9wZW5TZWFyY2hTZXJ2aWNlLmNyZWF0ZUluZGV4KGNsaWVudCwgQ0FTRV9JTkRFWCwgY2FzZU1hcHBpbmdzKTtcbiAgICAgIHRoaXMubG9nZ2VyLmluZm8oYEluZGV4IGNyZWF0ZWQ6ICR7Q0FTRV9JTkRFWH1gKTtcbiAgICB9IGVsc2Uge1xuICAgICAgLy8gVXBkYXRlIG1hcHBpbmdzIG9uIGV4aXN0aW5nIGluZGV4IHRvIGFkZCBuZXcgZmllbGRzICh0bHAsIG5vdGVzKVxuICAgICAgdHJ5IHtcbiAgICAgICAgLy8gQWRkaXRpdmUgbWFwcGluZyB1cGRhdGUgc28gaW5kaWNlcyBjcmVhdGVkIGJ5IGVhcmxpZXIgcGx1Z2luIHZlcnNpb25zXG4gICAgICAgIC8vIGdhaW4gdGhlIGZpZWxkcyBhZGRlZCBzaW5jZSAodGxwLCBub3RlcywgdGFza3MsIGVzY2FsYXRpb25fc3RhdGUpLlxuICAgICAgICBhd2FpdCBjbGllbnQuaW5kaWNlcy5wdXRNYXBwaW5nKHtcbiAgICAgICAgICBpbmRleDogQ0FTRV9JTkRFWCxcbiAgICAgICAgICBib2R5OiB7XG4gICAgICAgICAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgICAgICAgIHRscDogeyB0eXBlOiAna2V5d29yZCcgfSxcbiAgICAgICAgICAgICAgbm90ZXM6IHsgdHlwZTogJ3RleHQnIH0sXG4gICAgICAgICAgICAgIGVzY2FsYXRpb25fc3RhdGU6IHtcbiAgICAgICAgICAgICAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgICAgICAgICAgICBwb2xpY3lfaWQ6IHsgdHlwZTogJ2tleXdvcmQnIH0sXG4gICAgICAgICAgICAgICAgICBsZXZlbDogeyB0eXBlOiAnaW50ZWdlcicgfSxcbiAgICAgICAgICAgICAgICAgIGxhc3RfZXNjYWxhdGVkX2F0OiB7IHR5cGU6ICdkYXRlJyB9LFxuICAgICAgICAgICAgICAgICAgaGlzdG9yeTogeyB0eXBlOiAnb2JqZWN0JywgZW5hYmxlZDogZmFsc2UgfSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgLy8gTm9uLWZhdGFsOiBkeW5hbWljIG1hcHBpbmcgd2lsbCBoYW5kbGUgaXQgaWYgcHV0TWFwcGluZyBmYWlsc1xuICAgICAgICB0aGlzLmxvZ2dlci53YXJuKGBDb3VsZCBub3QgdXBkYXRlIG1hcHBpbmdzOiAke2V9YCk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgLy8gQ3JlYXRlIHRoZSBjb3VudGVyIGluZGV4IGZvciBhdXRvLWluY3JlbWVudGluZyBjYXNlIElEc1xuICAgIGNvbnN0IGNvdW50ZXJFeGlzdCA9IGF3YWl0IE9wZW5TZWFyY2hTZXJ2aWNlLmluZGV4RXhpc3RzKGNsaWVudCwgQ0FTRV9DT1VOVEVSX0lOREVYKTtcbiAgICBpZiAoIWNvdW50ZXJFeGlzdCkge1xuICAgICAgdGhpcy5sb2dnZXIuaW5mbyhgQ3JlYXRpbmcgaW5kZXg6ICR7Q0FTRV9DT1VOVEVSX0lOREVYfWApO1xuICAgICAgYXdhaXQgT3BlblNlYXJjaFNlcnZpY2UuY3JlYXRlSW5kZXgoY2xpZW50LCBDQVNFX0NPVU5URVJfSU5ERVgsIGNvdW50ZXJNYXBwaW5ncyk7XG4gICAgICB0aGlzLmxvZ2dlci5pbmZvKGBJbmRleCBjcmVhdGVkOiAke0NBU0VfQ09VTlRFUl9JTkRFWH1gKTtcbiAgICB9XG4gIH1cbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBY0EsSUFBQUEsVUFBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsY0FBQSxHQUFBRCxPQUFBO0FBQ0EsSUFBQUUsbUJBQUEsR0FBQUYsT0FBQTtBQUNBLElBQUFHLGdCQUFBLEdBQUFILE9BQUE7QUFDQSxJQUFBSSxpQkFBQSxHQUFBSixPQUFBO0FBQ0EsSUFBQUsscUJBQUEsR0FBQUwsT0FBQTtBQUNBLElBQUFNLG1CQUFBLEdBQUFOLE9BQUE7QUFDQSxJQUFBTyxPQUFBLEdBQUFQLE9BQUE7QUFBd0MsU0FBQVEsZ0JBQUFDLENBQUEsRUFBQUMsQ0FBQSxFQUFBQyxDQUFBLFlBQUFELENBQUEsR0FBQUUsY0FBQSxDQUFBRixDQUFBLE1BQUFELENBQUEsR0FBQUksTUFBQSxDQUFBQyxjQUFBLENBQUFMLENBQUEsRUFBQUMsQ0FBQSxJQUFBSyxLQUFBLEVBQUFKLENBQUEsRUFBQUssVUFBQSxNQUFBQyxZQUFBLE1BQUFDLFFBQUEsVUFBQVQsQ0FBQSxDQUFBQyxDQUFBLElBQUFDLENBQUEsRUFBQUYsQ0FBQTtBQUFBLFNBQUFHLGVBQUFELENBQUEsUUFBQVEsQ0FBQSxHQUFBQyxZQUFBLENBQUFULENBQUEsdUNBQUFRLENBQUEsR0FBQUEsQ0FBQSxHQUFBQSxDQUFBO0FBQUEsU0FBQUMsYUFBQVQsQ0FBQSxFQUFBRCxDQUFBLDJCQUFBQyxDQUFBLEtBQUFBLENBQUEsU0FBQUEsQ0FBQSxNQUFBRixDQUFBLEdBQUFFLENBQUEsQ0FBQVUsTUFBQSxDQUFBQyxXQUFBLGtCQUFBYixDQUFBLFFBQUFVLENBQUEsR0FBQVYsQ0FBQSxDQUFBYyxJQUFBLENBQUFaLENBQUEsRUFBQUQsQ0FBQSx1Q0FBQVMsQ0FBQSxTQUFBQSxDQUFBLFlBQUFLLFNBQUEseUVBQUFkLENBQUEsR0FBQWUsTUFBQSxHQUFBQyxNQUFBLEVBQUFmLENBQUEsS0FyQnhDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQWtCTyxNQUFNZ0IseUJBQXlCLENBQW1CO0VBR3ZEQyxXQUFXQSxDQUFDQyxrQkFBNEMsRUFBRTtJQUFBckIsZUFBQTtJQUN4RCxJQUFJLENBQUNzQixNQUFNLEdBQUdELGtCQUFrQixDQUFDQyxNQUFNLENBQUNDLEdBQUcsQ0FBQyxDQUFDO0VBQy9DO0VBRU9DLEtBQUtBLENBQUNDLElBQWUsRUFBRTtJQUM1QixJQUFJLENBQUNILE1BQU0sQ0FBQ0ksSUFBSSxDQUFDLDBDQUEwQyxDQUFDOztJQUU1RDtJQUNBLE1BQU1DLE1BQU0sR0FBR0YsSUFBSSxDQUFDRyxJQUFJLENBQUNDLFlBQVksQ0FBQyxDQUFDO0lBQ3ZDLElBQUFDLG9CQUFZLEVBQUNILE1BQU0sRUFBRSxJQUFJLENBQUNMLE1BQU0sQ0FBQztJQUVqQyxPQUFPLENBQUMsQ0FBQztFQUNYO0VBRUEsTUFBYVMsS0FBS0EsQ0FBQ04sSUFBZSxFQUFFO0lBQ2xDLElBQUksQ0FBQ0gsTUFBTSxDQUFDSSxJQUFJLENBQUMsd0NBQXdDLENBQUM7O0lBRTFEO0lBQ0EsSUFBSTtNQUNGLE1BQU1NLE1BQU0sR0FBR1AsSUFBSSxDQUFDUSxVQUFVLENBQUNELE1BQU0sQ0FBQ0UsY0FBYztNQUNwRCxNQUFNLElBQUksQ0FBQ0MsYUFBYSxDQUFDSCxNQUFNLENBQUM7TUFDaEMsTUFBTUksK0JBQWMsQ0FBQ0MsaUJBQWlCLENBQUNMLE1BQU0sQ0FBQztNQUM5QyxNQUFNTSxpQ0FBZSxDQUFDQyxXQUFXLENBQUNQLE1BQU0sQ0FBQztNQUN6QyxNQUFNUSx5Q0FBbUIsQ0FBQ0QsV0FBVyxDQUFDUCxNQUFNLENBQUM7TUFDN0NJLCtCQUFjLENBQUNMLEtBQUssQ0FBQ0MsTUFBTSxFQUFFLElBQUksQ0FBQ1YsTUFBTSxDQUFDO01BQ3pDbUIscUNBQWlCLENBQUNWLEtBQUssQ0FBQ0MsTUFBTSxFQUFFLElBQUksQ0FBQ1YsTUFBTSxDQUFDO0lBQzlDLENBQUMsQ0FBQyxPQUFPb0IsS0FBSyxFQUFFO01BQ2QsSUFBSSxDQUFDcEIsTUFBTSxDQUFDb0IsS0FBSyxDQUFFLGlDQUFnQ0EsS0FBTSxFQUFDLENBQUM7SUFDN0Q7SUFFQSxPQUFPLENBQUMsQ0FBQztFQUNYO0VBRU9DLElBQUlBLENBQUEsRUFBRztJQUNaUCwrQkFBYyxDQUFDTyxJQUFJLENBQUMsQ0FBQztJQUNyQkYscUNBQWlCLENBQUNFLElBQUksQ0FBQyxDQUFDO0lBQ3hCLElBQUksQ0FBQ3JCLE1BQU0sQ0FBQ0ksSUFBSSxDQUFDLHVDQUF1QyxDQUFDO0VBQzNEOztFQUVBO0FBQ0Y7QUFDQTtBQUNBO0VBQ0UsTUFBY1MsYUFBYUEsQ0FBQ0gsTUFBVyxFQUFpQjtJQUN0RDtJQUNBO0lBQ0E7SUFDQTtJQUNBLElBQUk7TUFDRixNQUFNWSxxQ0FBaUIsQ0FBQ0MsY0FBYyxDQUFDYixNQUFNLEVBQUUsNkJBQTZCLEVBQUUsQ0FBQ2MscUJBQVUsQ0FBQyxFQUFFQywyQkFBWSxDQUFDO01BQ3pHLE1BQU1ILHFDQUFpQixDQUFDQyxjQUFjLENBQUNiLE1BQU0sRUFBRSwrQkFBK0IsRUFBRSxDQUFDZ0IsNkJBQWtCLENBQUMsRUFBRUMsOEJBQWUsQ0FBQztNQUN0SCxJQUFJLENBQUMzQixNQUFNLENBQUNJLElBQUksQ0FBQyx5Q0FBeUMsQ0FBQztJQUM3RCxDQUFDLENBQUMsT0FBT3pCLENBQUMsRUFBRTtNQUNWLElBQUksQ0FBQ3FCLE1BQU0sQ0FBQzRCLElBQUksQ0FBRSx1Q0FBc0NqRCxDQUFFLEVBQUMsQ0FBQztJQUM5RDs7SUFFQTtJQUNBLE1BQU1rRCxVQUFVLEdBQUcsTUFBTVAscUNBQWlCLENBQUNRLFdBQVcsQ0FBQ3BCLE1BQU0sRUFBRWMscUJBQVUsQ0FBQztJQUMxRSxJQUFJLENBQUNLLFVBQVUsRUFBRTtNQUNmLElBQUksQ0FBQzdCLE1BQU0sQ0FBQ0ksSUFBSSxDQUFFLG1CQUFrQm9CLHFCQUFXLEVBQUMsQ0FBQztNQUNqRCxNQUFNRixxQ0FBaUIsQ0FBQ1MsV0FBVyxDQUFDckIsTUFBTSxFQUFFYyxxQkFBVSxFQUFFQywyQkFBWSxDQUFDO01BQ3JFLElBQUksQ0FBQ3pCLE1BQU0sQ0FBQ0ksSUFBSSxDQUFFLGtCQUFpQm9CLHFCQUFXLEVBQUMsQ0FBQztJQUNsRCxDQUFDLE1BQU07TUFDTDtNQUNBLElBQUk7UUFDRjtRQUNBO1FBQ0EsTUFBTWQsTUFBTSxDQUFDc0IsT0FBTyxDQUFDQyxVQUFVLENBQUM7VUFDOUJDLEtBQUssRUFBRVYscUJBQVU7VUFDakJXLElBQUksRUFBRTtZQUNKQyxVQUFVLEVBQUU7Y0FDVkMsR0FBRyxFQUFFO2dCQUFFQyxJQUFJLEVBQUU7Y0FBVSxDQUFDO2NBQ3hCQyxLQUFLLEVBQUU7Z0JBQUVELElBQUksRUFBRTtjQUFPLENBQUM7Y0FDdkJFLGdCQUFnQixFQUFFO2dCQUNoQkosVUFBVSxFQUFFO2tCQUNWSyxTQUFTLEVBQUU7b0JBQUVILElBQUksRUFBRTtrQkFBVSxDQUFDO2tCQUM5QkksS0FBSyxFQUFFO29CQUFFSixJQUFJLEVBQUU7a0JBQVUsQ0FBQztrQkFDMUJLLGlCQUFpQixFQUFFO29CQUFFTCxJQUFJLEVBQUU7a0JBQU8sQ0FBQztrQkFDbkNNLE9BQU8sRUFBRTtvQkFBRU4sSUFBSSxFQUFFLFFBQVE7b0JBQUVPLE9BQU8sRUFBRTtrQkFBTTtnQkFDNUM7Y0FDRjtZQUNGO1VBQ0Y7UUFDRixDQUFDLENBQUM7TUFDSixDQUFDLENBQUMsT0FBT2xFLENBQUMsRUFBRTtRQUNWO1FBQ0EsSUFBSSxDQUFDcUIsTUFBTSxDQUFDNEIsSUFBSSxDQUFFLDhCQUE2QmpELENBQUUsRUFBQyxDQUFDO01BQ3JEO0lBQ0Y7O0lBRUE7SUFDQSxNQUFNbUUsWUFBWSxHQUFHLE1BQU14QixxQ0FBaUIsQ0FBQ1EsV0FBVyxDQUFDcEIsTUFBTSxFQUFFZ0IsNkJBQWtCLENBQUM7SUFDcEYsSUFBSSxDQUFDb0IsWUFBWSxFQUFFO01BQ2pCLElBQUksQ0FBQzlDLE1BQU0sQ0FBQ0ksSUFBSSxDQUFFLG1CQUFrQnNCLDZCQUFtQixFQUFDLENBQUM7TUFDekQsTUFBTUoscUNBQWlCLENBQUNTLFdBQVcsQ0FBQ3JCLE1BQU0sRUFBRWdCLDZCQUFrQixFQUFFQyw4QkFBZSxDQUFDO01BQ2hGLElBQUksQ0FBQzNCLE1BQU0sQ0FBQ0ksSUFBSSxDQUFFLGtCQUFpQnNCLDZCQUFtQixFQUFDLENBQUM7SUFDMUQ7RUFDRjtBQUNGO0FBQUNxQixPQUFBLENBQUFsRCx5QkFBQSxHQUFBQSx5QkFBQSJ9