"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.registerExternalRoutes = registerExternalRoutes;
var _configSchema = require("@osd/config-schema");
var _case_service = require("../services/case_service");
var _settings_service = require("../services/settings_service");
var _constants = require("../../common/constants");
/*
 * Wazuh Case Management Plugin
 * External API: API-key authenticated surface for third-party integrations
 *
 * These routes are the integration point for systems that have no OpenSearch
 * Dashboards session: SOAR platforms, ticketing systems, scripts, the Wazuh
 * manager's active-response hooks, and so on.
 *
 * Authentication is a plugin-issued API key sent in the `x-cm-api-key` header.
 * Keys are created in Settings → API Integration and stored only as a SHA-256
 * hash. Because there is no user session, these routes declare
 * `authRequired: false` and run against the internal OpenSearch user; every
 * request is instead gated on a valid, enabled, unexpired key with the right
 * scope. `xsrfRequired: false` is set because XSRF protection defends
 * cookie-authenticated browsers, which is not how this surface is reached.
 */

/**
 * Route options for the external surface.
 *
 * GET routes only need `authRequired: false`; OSD's route typing does not accept
 * `xsrfRequired` on them because XSRF is only enforced on state-changing verbs.
 */
const EXTERNAL_GET_OPTIONS = {
  authRequired: false
};
const EXTERNAL_WRITE_OPTIONS = {
  authRequired: false,
  xsrfRequired: false
};
/** Validate the API key on a request and check it carries the required scope. */
async function authenticate(client, request, required) {
  var _request$headers, _request$headers2;
  const header = ((_request$headers = request.headers) === null || _request$headers === void 0 ? void 0 : _request$headers[_constants.API_KEY_HEADER]) || ((_request$headers2 = request.headers) === null || _request$headers2 === void 0 ? void 0 : _request$headers2[_constants.API_KEY_HEADER.toLowerCase()]);
  const raw = Array.isArray(header) ? header[0] : header;
  if (!raw) {
    return {
      ok: false,
      status: 401,
      message: `Missing ${_constants.API_KEY_HEADER} header`
    };
  }
  const key = await _settings_service.SettingsService.verifyApiKey(client, String(raw).trim());
  if (!key) {
    return {
      ok: false,
      status: 401,
      message: 'Invalid, disabled or expired API key'
    };
  }

  // 'write' implies 'read'.
  const hasScope = key.scopes.includes(required) || required === 'read' && key.scopes.includes('write');
  if (!hasScope) {
    return {
      ok: false,
      status: 403,
      message: `API key lacks the '${required}' scope`
    };
  }
  return {
    ok: true,
    key
  };
}
function registerExternalRoutes(router, logger) {
  /**
   * Wrap a handler with API-key auth so each route body only deals with its own
   * logic. `asInternalUser` is used because there is no session to scope to.
   */
  const withAuth = (required, handler) => async (context, request, response) => {
    const client = context.core.opensearch.client.asInternalUser;
    const auth = await authenticate(client, request, required);
    if (!auth.ok) {
      logger.warn(`External API: rejected request to ${request.route.path}: ${auth.message}`);
      return response.customError({
        statusCode: auth.status || 401,
        body: {
          message: auth.message
        }
      });
    }

    // Fire-and-forget usage tracking.
    _settings_service.SettingsService.touchApiKey(client, auth.key.id).catch(() => undefined);
    try {
      return await handler(context, request, response, client, auth.key);
    } catch (error) {
      logger.error(`External API error on ${request.route.path}: ${error.message}`);
      return response.customError({
        statusCode: error.statusCode || 500,
        body: {
          message: error.message
        }
      });
    }
  };

  // ─── HEALTH / KEY INTROSPECTION ─────────────────────────────
  router.get({
    path: `${_constants.EXTERNAL_API_PREFIX}/health`,
    validate: false,
    options: EXTERNAL_GET_OPTIONS
  }, withAuth('read', async (_ctx, _req, response, _client, key) => response.ok({
    body: {
      status: 'ok',
      api: 'wazuh-case-management',
      version: '1.2.0',
      key: {
        id: key.id,
        name: key.name,
        scopes: key.scopes
      },
      server_time: new Date().toISOString()
    }
  })));

  // ─── LIST CASES ─────────────────────────────────────────────
  router.get({
    path: `${_constants.EXTERNAL_API_PREFIX}/cases`,
    validate: {
      query: _configSchema.schema.object({
        page: _configSchema.schema.maybe(_configSchema.schema.number({
          min: 1
        })),
        per_page: _configSchema.schema.maybe(_configSchema.schema.number({
          min: 1,
          max: 100
        })),
        sort_field: _configSchema.schema.maybe(_configSchema.schema.string()),
        sort_order: _configSchema.schema.maybe(_configSchema.schema.oneOf([_configSchema.schema.literal('asc'), _configSchema.schema.literal('desc')])),
        status: _configSchema.schema.maybe(_configSchema.schema.string()),
        severity: _configSchema.schema.maybe(_configSchema.schema.string()),
        priority: _configSchema.schema.maybe(_configSchema.schema.string()),
        category: _configSchema.schema.maybe(_configSchema.schema.string()),
        assignee: _configSchema.schema.maybe(_configSchema.schema.string()),
        search: _configSchema.schema.maybe(_configSchema.schema.string()),
        tags: _configSchema.schema.maybe(_configSchema.schema.string()),
        created_from: _configSchema.schema.maybe(_configSchema.schema.string()),
        created_to: _configSchema.schema.maybe(_configSchema.schema.string())
      }, {
        unknowns: 'ignore'
      })
    },
    options: EXTERNAL_GET_OPTIONS
  }, withAuth('read', async (_ctx, request, response, client) => {
    const result = await _case_service.CaseService.listCases(client, request.query);
    return response.ok({
      body: result
    });
  }));

  // ─── GET ONE CASE ───────────────────────────────────────────
  router.get({
    path: `${_constants.EXTERNAL_API_PREFIX}/cases/{id}`,
    validate: {
      params: _configSchema.schema.object({
        id: _configSchema.schema.string()
      })
    },
    options: EXTERNAL_GET_OPTIONS
  }, withAuth('read', async (_ctx, request, response, client) => {
    const found = await _case_service.CaseService.getCase(client, request.params.id);
    if (!found) return response.notFound({
      body: {
        message: 'Case not found'
      }
    });
    return response.ok({
      body: found
    });
  }));

  // ─── CREATE CASE ────────────────────────────────────────────
  router.post({
    path: `${_constants.EXTERNAL_API_PREFIX}/cases`,
    validate: {
      body: _configSchema.schema.object({
        title: _configSchema.schema.string({
          minLength: 1
        }),
        description: _configSchema.schema.string({
          defaultValue: ''
        }),
        severity: _configSchema.schema.string({
          defaultValue: 'medium'
        }),
        priority: _configSchema.schema.string({
          defaultValue: 'P3'
        }),
        category: _configSchema.schema.string({
          defaultValue: 'other'
        }),
        tlp: _configSchema.schema.maybe(_configSchema.schema.string()),
        tags: _configSchema.schema.maybe(_configSchema.schema.arrayOf(_configSchema.schema.string())),
        assignee: _configSchema.schema.maybe(_configSchema.schema.nullable(_configSchema.schema.string()))
      })
    },
    options: EXTERNAL_WRITE_OPTIONS
  }, withAuth('write', async (_ctx, request, response, client, key) => {
    const created = await _case_service.CaseService.createCase(client, request.body, `api:${key.name}`);
    logger.info(`External API: case ${created.case_id} created via key "${key.name}"`);
    return response.ok({
      body: created
    });
  }));

  // ─── UPDATE CASE ────────────────────────────────────────────
  router.put({
    path: `${_constants.EXTERNAL_API_PREFIX}/cases/{id}`,
    validate: {
      params: _configSchema.schema.object({
        id: _configSchema.schema.string()
      }),
      body: _configSchema.schema.object({
        title: _configSchema.schema.maybe(_configSchema.schema.string()),
        description: _configSchema.schema.maybe(_configSchema.schema.string()),
        severity: _configSchema.schema.maybe(_configSchema.schema.string()),
        priority: _configSchema.schema.maybe(_configSchema.schema.string()),
        category: _configSchema.schema.maybe(_configSchema.schema.string()),
        tlp: _configSchema.schema.maybe(_configSchema.schema.string()),
        tags: _configSchema.schema.maybe(_configSchema.schema.arrayOf(_configSchema.schema.string())),
        assignee: _configSchema.schema.maybe(_configSchema.schema.nullable(_configSchema.schema.string())),
        resolution_summary: _configSchema.schema.maybe(_configSchema.schema.nullable(_configSchema.schema.string()))
      })
    },
    options: EXTERNAL_WRITE_OPTIONS
  }, withAuth('write', async (_ctx, request, response, client, key) => {
    const updated = await _case_service.CaseService.updateCase(client, request.params.id, request.body, `api:${key.name}`);
    if (!updated) return response.notFound({
      body: {
        message: 'Case not found'
      }
    });
    return response.ok({
      body: updated
    });
  }));

  // ─── CHANGE STATUS ──────────────────────────────────────────
  router.post({
    path: `${_constants.EXTERNAL_API_PREFIX}/cases/{id}/status`,
    validate: {
      params: _configSchema.schema.object({
        id: _configSchema.schema.string()
      }),
      body: _configSchema.schema.object({
        status: _configSchema.schema.string()
      })
    },
    options: EXTERNAL_WRITE_OPTIONS
  }, withAuth('write', async (_ctx, request, response, client, key) => {
    const result = await _case_service.CaseService.changeStatus(client, request.params.id, request.body.status, `api:${key.name}`);
    if (!result.success) {
      return response.badRequest({
        body: {
          message: result.error
        }
      });
    }
    return response.ok({
      body: result.case
    });
  }));

  // ─── ASSIGN ─────────────────────────────────────────────────
  router.post({
    path: `${_constants.EXTERNAL_API_PREFIX}/cases/{id}/assign`,
    validate: {
      params: _configSchema.schema.object({
        id: _configSchema.schema.string()
      }),
      body: _configSchema.schema.object({
        assignee: _configSchema.schema.nullable(_configSchema.schema.string())
      })
    },
    options: EXTERNAL_WRITE_OPTIONS
  }, withAuth('write', async (_ctx, request, response, client, key) => {
    const updated = await _case_service.CaseService.assignCase(client, request.params.id, request.body.assignee, `api:${key.name}`);
    if (!updated) return response.notFound({
      body: {
        message: 'Case not found'
      }
    });
    return response.ok({
      body: updated
    });
  }));

  // ─── ADD COMMENT ────────────────────────────────────────────
  router.post({
    path: `${_constants.EXTERNAL_API_PREFIX}/cases/{id}/comments`,
    validate: {
      params: _configSchema.schema.object({
        id: _configSchema.schema.string()
      }),
      body: _configSchema.schema.object({
        content: _configSchema.schema.string({
          minLength: 1
        }),
        author: _configSchema.schema.maybe(_configSchema.schema.string())
      })
    },
    options: EXTERNAL_WRITE_OPTIONS
  }, withAuth('write', async (_ctx, request, response, client, key) => {
    const author = request.body.author || `api:${key.name}`;
    const updated = await _case_service.CaseService.addComment(client, request.params.id, request.body.content, author);
    if (!updated) return response.notFound({
      body: {
        message: 'Case not found'
      }
    });
    return response.ok({
      body: updated
    });
  }));

  // ─── ADD OBSERVABLE ─────────────────────────────────────────
  router.post({
    path: `${_constants.EXTERNAL_API_PREFIX}/cases/{id}/observables`,
    validate: {
      params: _configSchema.schema.object({
        id: _configSchema.schema.string()
      }),
      body: _configSchema.schema.object({
        type: _configSchema.schema.string(),
        value: _configSchema.schema.string({
          minLength: 1
        }),
        description: _configSchema.schema.maybe(_configSchema.schema.string()),
        is_ioc: _configSchema.schema.boolean({
          defaultValue: false
        })
      })
    },
    options: EXTERNAL_WRITE_OPTIONS
  }, withAuth('write', async (_ctx, request, response, client, key) => {
    const updated = await _case_service.CaseService.addObservable(client, request.params.id, request.body, `api:${key.name}`);
    if (!updated) return response.notFound({
      body: {
        message: 'Case not found'
      }
    });
    return response.ok({
      body: updated
    });
  }));

  // ─── ANALYTICS ──────────────────────────────────────────────
  router.get({
    path: `${_constants.EXTERNAL_API_PREFIX}/analytics/summary`,
    validate: false,
    options: EXTERNAL_GET_OPTIONS
  }, withAuth('read', async (_ctx, _request, response, client) => {
    const summary = await _case_service.CaseService.getAnalyticsSummary(client);
    return response.ok({
      body: summary
    });
  }));

  // ─── INGEST A RAW WAZUH ALERT ───────────────────────────────
  router.post({
    path: `${_constants.EXTERNAL_API_PREFIX}/alerts/ingest`,
    validate: {
      body: _configSchema.schema.object({}, {
        unknowns: 'allow'
      })
    },
    options: EXTERNAL_WRITE_OPTIONS
  }, withAuth('write', async (_ctx, request, response, client, key) => {
    const created = await _case_service.CaseService.handleAutomatedAlert(client, request.body, `api:${key.name}`);
    return response.ok({
      body: {
        success: true,
        case: created
      }
    });
  }));
  logger.info('External (API-key) routes registered');
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfY29uZmlnU2NoZW1hIiwicmVxdWlyZSIsIl9jYXNlX3NlcnZpY2UiLCJfc2V0dGluZ3Nfc2VydmljZSIsIl9jb25zdGFudHMiLCJFWFRFUk5BTF9HRVRfT1BUSU9OUyIsImF1dGhSZXF1aXJlZCIsIkVYVEVSTkFMX1dSSVRFX09QVElPTlMiLCJ4c3JmUmVxdWlyZWQiLCJhdXRoZW50aWNhdGUiLCJjbGllbnQiLCJyZXF1ZXN0IiwicmVxdWlyZWQiLCJfcmVxdWVzdCRoZWFkZXJzIiwiX3JlcXVlc3QkaGVhZGVyczIiLCJoZWFkZXIiLCJoZWFkZXJzIiwiQVBJX0tFWV9IRUFERVIiLCJ0b0xvd2VyQ2FzZSIsInJhdyIsIkFycmF5IiwiaXNBcnJheSIsIm9rIiwic3RhdHVzIiwibWVzc2FnZSIsImtleSIsIlNldHRpbmdzU2VydmljZSIsInZlcmlmeUFwaUtleSIsIlN0cmluZyIsInRyaW0iLCJoYXNTY29wZSIsInNjb3BlcyIsImluY2x1ZGVzIiwicmVnaXN0ZXJFeHRlcm5hbFJvdXRlcyIsInJvdXRlciIsImxvZ2dlciIsIndpdGhBdXRoIiwiaGFuZGxlciIsImNvbnRleHQiLCJyZXNwb25zZSIsImNvcmUiLCJvcGVuc2VhcmNoIiwiYXNJbnRlcm5hbFVzZXIiLCJhdXRoIiwid2FybiIsInJvdXRlIiwicGF0aCIsImN1c3RvbUVycm9yIiwic3RhdHVzQ29kZSIsImJvZHkiLCJ0b3VjaEFwaUtleSIsImlkIiwiY2F0Y2giLCJ1bmRlZmluZWQiLCJlcnJvciIsImdldCIsIkVYVEVSTkFMX0FQSV9QUkVGSVgiLCJ2YWxpZGF0ZSIsIm9wdGlvbnMiLCJfY3R4IiwiX3JlcSIsIl9jbGllbnQiLCJhcGkiLCJ2ZXJzaW9uIiwibmFtZSIsInNlcnZlcl90aW1lIiwiRGF0ZSIsInRvSVNPU3RyaW5nIiwicXVlcnkiLCJzY2hlbWEiLCJvYmplY3QiLCJwYWdlIiwibWF5YmUiLCJudW1iZXIiLCJtaW4iLCJwZXJfcGFnZSIsIm1heCIsInNvcnRfZmllbGQiLCJzdHJpbmciLCJzb3J0X29yZGVyIiwib25lT2YiLCJsaXRlcmFsIiwic2V2ZXJpdHkiLCJwcmlvcml0eSIsImNhdGVnb3J5IiwiYXNzaWduZWUiLCJzZWFyY2giLCJ0YWdzIiwiY3JlYXRlZF9mcm9tIiwiY3JlYXRlZF90byIsInVua25vd25zIiwicmVzdWx0IiwiQ2FzZVNlcnZpY2UiLCJsaXN0Q2FzZXMiLCJwYXJhbXMiLCJmb3VuZCIsImdldENhc2UiLCJub3RGb3VuZCIsInBvc3QiLCJ0aXRsZSIsIm1pbkxlbmd0aCIsImRlc2NyaXB0aW9uIiwiZGVmYXVsdFZhbHVlIiwidGxwIiwiYXJyYXlPZiIsIm51bGxhYmxlIiwiY3JlYXRlZCIsImNyZWF0ZUNhc2UiLCJpbmZvIiwiY2FzZV9pZCIsInB1dCIsInJlc29sdXRpb25fc3VtbWFyeSIsInVwZGF0ZWQiLCJ1cGRhdGVDYXNlIiwiY2hhbmdlU3RhdHVzIiwic3VjY2VzcyIsImJhZFJlcXVlc3QiLCJjYXNlIiwiYXNzaWduQ2FzZSIsImNvbnRlbnQiLCJhdXRob3IiLCJhZGRDb21tZW50IiwidHlwZSIsInZhbHVlIiwiaXNfaW9jIiwiYm9vbGVhbiIsImFkZE9ic2VydmFibGUiLCJfcmVxdWVzdCIsInN1bW1hcnkiLCJnZXRBbmFseXRpY3NTdW1tYXJ5IiwiaGFuZGxlQXV0b21hdGVkQWxlcnQiXSwic291cmNlcyI6WyJleHRlcm5hbC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogV2F6dWggQ2FzZSBNYW5hZ2VtZW50IFBsdWdpblxuICogRXh0ZXJuYWwgQVBJOiBBUEkta2V5IGF1dGhlbnRpY2F0ZWQgc3VyZmFjZSBmb3IgdGhpcmQtcGFydHkgaW50ZWdyYXRpb25zXG4gKlxuICogVGhlc2Ugcm91dGVzIGFyZSB0aGUgaW50ZWdyYXRpb24gcG9pbnQgZm9yIHN5c3RlbXMgdGhhdCBoYXZlIG5vIE9wZW5TZWFyY2hcbiAqIERhc2hib2FyZHMgc2Vzc2lvbjogU09BUiBwbGF0Zm9ybXMsIHRpY2tldGluZyBzeXN0ZW1zLCBzY3JpcHRzLCB0aGUgV2F6dWhcbiAqIG1hbmFnZXIncyBhY3RpdmUtcmVzcG9uc2UgaG9va3MsIGFuZCBzbyBvbi5cbiAqXG4gKiBBdXRoZW50aWNhdGlvbiBpcyBhIHBsdWdpbi1pc3N1ZWQgQVBJIGtleSBzZW50IGluIHRoZSBgeC1jbS1hcGkta2V5YCBoZWFkZXIuXG4gKiBLZXlzIGFyZSBjcmVhdGVkIGluIFNldHRpbmdzIOKGkiBBUEkgSW50ZWdyYXRpb24gYW5kIHN0b3JlZCBvbmx5IGFzIGEgU0hBLTI1NlxuICogaGFzaC4gQmVjYXVzZSB0aGVyZSBpcyBubyB1c2VyIHNlc3Npb24sIHRoZXNlIHJvdXRlcyBkZWNsYXJlXG4gKiBgYXV0aFJlcXVpcmVkOiBmYWxzZWAgYW5kIHJ1biBhZ2FpbnN0IHRoZSBpbnRlcm5hbCBPcGVuU2VhcmNoIHVzZXI7IGV2ZXJ5XG4gKiByZXF1ZXN0IGlzIGluc3RlYWQgZ2F0ZWQgb24gYSB2YWxpZCwgZW5hYmxlZCwgdW5leHBpcmVkIGtleSB3aXRoIHRoZSByaWdodFxuICogc2NvcGUuIGB4c3JmUmVxdWlyZWQ6IGZhbHNlYCBpcyBzZXQgYmVjYXVzZSBYU1JGIHByb3RlY3Rpb24gZGVmZW5kc1xuICogY29va2llLWF1dGhlbnRpY2F0ZWQgYnJvd3NlcnMsIHdoaWNoIGlzIG5vdCBob3cgdGhpcyBzdXJmYWNlIGlzIHJlYWNoZWQuXG4gKi9cblxuaW1wb3J0IHsgSVJvdXRlciwgTG9nZ2VyIH0gZnJvbSAnLi4vLi4vLi4vLi4vc3JjL2NvcmUvc2VydmVyJztcbmltcG9ydCB7IHNjaGVtYSB9IGZyb20gJ0Bvc2QvY29uZmlnLXNjaGVtYSc7XG5pbXBvcnQgeyBDYXNlU2VydmljZSB9IGZyb20gJy4uL3NlcnZpY2VzL2Nhc2Vfc2VydmljZSc7XG5pbXBvcnQgeyBTZXR0aW5nc1NlcnZpY2UgfSBmcm9tICcuLi9zZXJ2aWNlcy9zZXR0aW5nc19zZXJ2aWNlJztcbmltcG9ydCB7IEFwaUtleSwgQXBpS2V5U2NvcGUgfSBmcm9tICcuLi8uLi9jb21tb24vdHlwZXMnO1xuaW1wb3J0IHsgQVBJX0tFWV9IRUFERVIsIEVYVEVSTkFMX0FQSV9QUkVGSVggfSBmcm9tICcuLi8uLi9jb21tb24vY29uc3RhbnRzJztcblxuLyoqXG4gKiBSb3V0ZSBvcHRpb25zIGZvciB0aGUgZXh0ZXJuYWwgc3VyZmFjZS5cbiAqXG4gKiBHRVQgcm91dGVzIG9ubHkgbmVlZCBgYXV0aFJlcXVpcmVkOiBmYWxzZWA7IE9TRCdzIHJvdXRlIHR5cGluZyBkb2VzIG5vdCBhY2NlcHRcbiAqIGB4c3JmUmVxdWlyZWRgIG9uIHRoZW0gYmVjYXVzZSBYU1JGIGlzIG9ubHkgZW5mb3JjZWQgb24gc3RhdGUtY2hhbmdpbmcgdmVyYnMuXG4gKi9cbmNvbnN0IEVYVEVSTkFMX0dFVF9PUFRJT05TID0ge1xuICBhdXRoUmVxdWlyZWQ6IGZhbHNlIGFzIGNvbnN0LFxufTtcblxuY29uc3QgRVhURVJOQUxfV1JJVEVfT1BUSU9OUyA9IHtcbiAgYXV0aFJlcXVpcmVkOiBmYWxzZSBhcyBjb25zdCxcbiAgeHNyZlJlcXVpcmVkOiBmYWxzZSBhcyBjb25zdCxcbn07XG5cbmludGVyZmFjZSBBdXRoUmVzdWx0IHtcbiAgb2s6IGJvb2xlYW47XG4gIGtleT86IEFwaUtleTtcbiAgc3RhdHVzPzogbnVtYmVyO1xuICBtZXNzYWdlPzogc3RyaW5nO1xufVxuXG4vKiogVmFsaWRhdGUgdGhlIEFQSSBrZXkgb24gYSByZXF1ZXN0IGFuZCBjaGVjayBpdCBjYXJyaWVzIHRoZSByZXF1aXJlZCBzY29wZS4gKi9cbmFzeW5jIGZ1bmN0aW9uIGF1dGhlbnRpY2F0ZShcbiAgY2xpZW50OiBhbnksXG4gIHJlcXVlc3Q6IGFueSxcbiAgcmVxdWlyZWQ6IEFwaUtleVNjb3BlLFxuKTogUHJvbWlzZTxBdXRoUmVzdWx0PiB7XG4gIGNvbnN0IGhlYWRlciA9IHJlcXVlc3QuaGVhZGVycz8uW0FQSV9LRVlfSEVBREVSXSB8fCByZXF1ZXN0LmhlYWRlcnM/LltBUElfS0VZX0hFQURFUi50b0xvd2VyQ2FzZSgpXTtcbiAgY29uc3QgcmF3ID0gQXJyYXkuaXNBcnJheShoZWFkZXIpID8gaGVhZGVyWzBdIDogaGVhZGVyO1xuXG4gIGlmICghcmF3KSB7XG4gICAgcmV0dXJuIHsgb2s6IGZhbHNlLCBzdGF0dXM6IDQwMSwgbWVzc2FnZTogYE1pc3NpbmcgJHtBUElfS0VZX0hFQURFUn0gaGVhZGVyYCB9O1xuICB9XG5cbiAgY29uc3Qga2V5ID0gYXdhaXQgU2V0dGluZ3NTZXJ2aWNlLnZlcmlmeUFwaUtleShjbGllbnQsIFN0cmluZyhyYXcpLnRyaW0oKSk7XG4gIGlmICgha2V5KSB7XG4gICAgcmV0dXJuIHsgb2s6IGZhbHNlLCBzdGF0dXM6IDQwMSwgbWVzc2FnZTogJ0ludmFsaWQsIGRpc2FibGVkIG9yIGV4cGlyZWQgQVBJIGtleScgfTtcbiAgfVxuXG4gIC8vICd3cml0ZScgaW1wbGllcyAncmVhZCcuXG4gIGNvbnN0IGhhc1Njb3BlID0ga2V5LnNjb3Blcy5pbmNsdWRlcyhyZXF1aXJlZCkgfHwgKHJlcXVpcmVkID09PSAncmVhZCcgJiYga2V5LnNjb3Blcy5pbmNsdWRlcygnd3JpdGUnKSk7XG4gIGlmICghaGFzU2NvcGUpIHtcbiAgICByZXR1cm4geyBvazogZmFsc2UsIHN0YXR1czogNDAzLCBtZXNzYWdlOiBgQVBJIGtleSBsYWNrcyB0aGUgJyR7cmVxdWlyZWR9JyBzY29wZWAgfTtcbiAgfVxuXG4gIHJldHVybiB7IG9rOiB0cnVlLCBrZXkgfTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHJlZ2lzdGVyRXh0ZXJuYWxSb3V0ZXMocm91dGVyOiBJUm91dGVyLCBsb2dnZXI6IExvZ2dlcik6IHZvaWQge1xuICAvKipcbiAgICogV3JhcCBhIGhhbmRsZXIgd2l0aCBBUEkta2V5IGF1dGggc28gZWFjaCByb3V0ZSBib2R5IG9ubHkgZGVhbHMgd2l0aCBpdHMgb3duXG4gICAqIGxvZ2ljLiBgYXNJbnRlcm5hbFVzZXJgIGlzIHVzZWQgYmVjYXVzZSB0aGVyZSBpcyBubyBzZXNzaW9uIHRvIHNjb3BlIHRvLlxuICAgKi9cbiAgY29uc3Qgd2l0aEF1dGggPVxuICAgIChyZXF1aXJlZDogQXBpS2V5U2NvcGUsIGhhbmRsZXI6IChjdHg6IGFueSwgcmVxOiBhbnksIHJlczogYW55LCBjbGllbnQ6IGFueSwga2V5OiBBcGlLZXkpID0+IFByb21pc2U8YW55PikgPT5cbiAgICBhc3luYyAoY29udGV4dDogYW55LCByZXF1ZXN0OiBhbnksIHJlc3BvbnNlOiBhbnkpID0+IHtcbiAgICAgIGNvbnN0IGNsaWVudCA9IGNvbnRleHQuY29yZS5vcGVuc2VhcmNoLmNsaWVudC5hc0ludGVybmFsVXNlcjtcbiAgICAgIGNvbnN0IGF1dGggPSBhd2FpdCBhdXRoZW50aWNhdGUoY2xpZW50LCByZXF1ZXN0LCByZXF1aXJlZCk7XG4gICAgICBpZiAoIWF1dGgub2spIHtcbiAgICAgICAgbG9nZ2VyLndhcm4oYEV4dGVybmFsIEFQSTogcmVqZWN0ZWQgcmVxdWVzdCB0byAke3JlcXVlc3Qucm91dGUucGF0aH06ICR7YXV0aC5tZXNzYWdlfWApO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2UuY3VzdG9tRXJyb3Ioe1xuICAgICAgICAgIHN0YXR1c0NvZGU6IGF1dGguc3RhdHVzIHx8IDQwMSxcbiAgICAgICAgICBib2R5OiB7IG1lc3NhZ2U6IGF1dGgubWVzc2FnZSB9LFxuICAgICAgICB9KTtcbiAgICAgIH1cblxuICAgICAgLy8gRmlyZS1hbmQtZm9yZ2V0IHVzYWdlIHRyYWNraW5nLlxuICAgICAgU2V0dGluZ3NTZXJ2aWNlLnRvdWNoQXBpS2V5KGNsaWVudCwgYXV0aC5rZXkhLmlkKS5jYXRjaCgoKSA9PiB1bmRlZmluZWQpO1xuXG4gICAgICB0cnkge1xuICAgICAgICByZXR1cm4gYXdhaXQgaGFuZGxlcihjb250ZXh0LCByZXF1ZXN0LCByZXNwb25zZSwgY2xpZW50LCBhdXRoLmtleSEpO1xuICAgICAgfSBjYXRjaCAoZXJyb3I6IGFueSkge1xuICAgICAgICBsb2dnZXIuZXJyb3IoYEV4dGVybmFsIEFQSSBlcnJvciBvbiAke3JlcXVlc3Qucm91dGUucGF0aH06ICR7ZXJyb3IubWVzc2FnZX1gKTtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmN1c3RvbUVycm9yKHtcbiAgICAgICAgICBzdGF0dXNDb2RlOiBlcnJvci5zdGF0dXNDb2RlIHx8IDUwMCxcbiAgICAgICAgICBib2R5OiB7IG1lc3NhZ2U6IGVycm9yLm1lc3NhZ2UgfSxcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfTtcblxuICAvLyDilIDilIDilIAgSEVBTFRIIC8gS0VZIElOVFJPU1BFQ1RJT04g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gIHJvdXRlci5nZXQoXG4gICAgeyBwYXRoOiBgJHtFWFRFUk5BTF9BUElfUFJFRklYfS9oZWFsdGhgLCB2YWxpZGF0ZTogZmFsc2UsIG9wdGlvbnM6IEVYVEVSTkFMX0dFVF9PUFRJT05TIH0sXG4gICAgd2l0aEF1dGgoJ3JlYWQnLCBhc3luYyAoX2N0eCwgX3JlcSwgcmVzcG9uc2UsIF9jbGllbnQsIGtleSkgPT5cbiAgICAgIHJlc3BvbnNlLm9rKHtcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIHN0YXR1czogJ29rJyxcbiAgICAgICAgICBhcGk6ICd3YXp1aC1jYXNlLW1hbmFnZW1lbnQnLFxuICAgICAgICAgIHZlcnNpb246ICcxLjIuMCcsXG4gICAgICAgICAga2V5OiB7IGlkOiBrZXkuaWQsIG5hbWU6IGtleS5uYW1lLCBzY29wZXM6IGtleS5zY29wZXMgfSxcbiAgICAgICAgICBzZXJ2ZXJfdGltZTogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgICB9LFxuICAgICAgfSksXG4gICAgKSxcbiAgKTtcblxuICAvLyDilIDilIDilIAgTElTVCBDQVNFUyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgcm91dGVyLmdldChcbiAgICB7XG4gICAgICBwYXRoOiBgJHtFWFRFUk5BTF9BUElfUFJFRklYfS9jYXNlc2AsXG4gICAgICB2YWxpZGF0ZToge1xuICAgICAgICBxdWVyeTogc2NoZW1hLm9iamVjdChcbiAgICAgICAgICB7XG4gICAgICAgICAgICBwYWdlOiBzY2hlbWEubWF5YmUoc2NoZW1hLm51bWJlcih7IG1pbjogMSB9KSksXG4gICAgICAgICAgICBwZXJfcGFnZTogc2NoZW1hLm1heWJlKHNjaGVtYS5udW1iZXIoeyBtaW46IDEsIG1heDogMTAwIH0pKSxcbiAgICAgICAgICAgIHNvcnRfZmllbGQ6IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICAgICAgICAgICAgc29ydF9vcmRlcjogc2NoZW1hLm1heWJlKHNjaGVtYS5vbmVPZihbc2NoZW1hLmxpdGVyYWwoJ2FzYycpLCBzY2hlbWEubGl0ZXJhbCgnZGVzYycpXSkpLFxuICAgICAgICAgICAgc3RhdHVzOiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcbiAgICAgICAgICAgIHNldmVyaXR5OiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcbiAgICAgICAgICAgIHByaW9yaXR5OiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcbiAgICAgICAgICAgIGNhdGVnb3J5OiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcbiAgICAgICAgICAgIGFzc2lnbmVlOiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcbiAgICAgICAgICAgIHNlYXJjaDogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXG4gICAgICAgICAgICB0YWdzOiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcbiAgICAgICAgICAgIGNyZWF0ZWRfZnJvbTogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXG4gICAgICAgICAgICBjcmVhdGVkX3RvOiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHsgdW5rbm93bnM6ICdpZ25vcmUnIH0sXG4gICAgICAgICksXG4gICAgICB9LFxuICAgICAgb3B0aW9uczogRVhURVJOQUxfR0VUX09QVElPTlMsXG4gICAgfSxcbiAgICB3aXRoQXV0aCgncmVhZCcsIGFzeW5jIChfY3R4LCByZXF1ZXN0LCByZXNwb25zZSwgY2xpZW50KSA9PiB7XG4gICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBDYXNlU2VydmljZS5saXN0Q2FzZXMoY2xpZW50LCByZXF1ZXN0LnF1ZXJ5IGFzIGFueSk7XG4gICAgICByZXR1cm4gcmVzcG9uc2Uub2soeyBib2R5OiByZXN1bHQgfSk7XG4gICAgfSksXG4gICk7XG5cbiAgLy8g4pSA4pSA4pSAIEdFVCBPTkUgQ0FTRSDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgcm91dGVyLmdldChcbiAgICB7XG4gICAgICBwYXRoOiBgJHtFWFRFUk5BTF9BUElfUFJFRklYfS9jYXNlcy97aWR9YCxcbiAgICAgIHZhbGlkYXRlOiB7IHBhcmFtczogc2NoZW1hLm9iamVjdCh7IGlkOiBzY2hlbWEuc3RyaW5nKCkgfSkgfSxcbiAgICAgIG9wdGlvbnM6IEVYVEVSTkFMX0dFVF9PUFRJT05TLFxuICAgIH0sXG4gICAgd2l0aEF1dGgoJ3JlYWQnLCBhc3luYyAoX2N0eCwgcmVxdWVzdCwgcmVzcG9uc2UsIGNsaWVudCkgPT4ge1xuICAgICAgY29uc3QgZm91bmQgPSBhd2FpdCBDYXNlU2VydmljZS5nZXRDYXNlKGNsaWVudCwgcmVxdWVzdC5wYXJhbXMuaWQpO1xuICAgICAgaWYgKCFmb3VuZCkgcmV0dXJuIHJlc3BvbnNlLm5vdEZvdW5kKHsgYm9keTogeyBtZXNzYWdlOiAnQ2FzZSBub3QgZm91bmQnIH0gfSk7XG4gICAgICByZXR1cm4gcmVzcG9uc2Uub2soeyBib2R5OiBmb3VuZCB9KTtcbiAgICB9KSxcbiAgKTtcblxuICAvLyDilIDilIDilIAgQ1JFQVRFIENBU0Ug4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gIHJvdXRlci5wb3N0KFxuICAgIHtcbiAgICAgIHBhdGg6IGAke0VYVEVSTkFMX0FQSV9QUkVGSVh9L2Nhc2VzYCxcbiAgICAgIHZhbGlkYXRlOiB7XG4gICAgICAgIGJvZHk6IHNjaGVtYS5vYmplY3Qoe1xuICAgICAgICAgIHRpdGxlOiBzY2hlbWEuc3RyaW5nKHsgbWluTGVuZ3RoOiAxIH0pLFxuICAgICAgICAgIGRlc2NyaXB0aW9uOiBzY2hlbWEuc3RyaW5nKHsgZGVmYXVsdFZhbHVlOiAnJyB9KSxcbiAgICAgICAgICBzZXZlcml0eTogc2NoZW1hLnN0cmluZyh7IGRlZmF1bHRWYWx1ZTogJ21lZGl1bScgfSksXG4gICAgICAgICAgcHJpb3JpdHk6IHNjaGVtYS5zdHJpbmcoeyBkZWZhdWx0VmFsdWU6ICdQMycgfSksXG4gICAgICAgICAgY2F0ZWdvcnk6IHNjaGVtYS5zdHJpbmcoeyBkZWZhdWx0VmFsdWU6ICdvdGhlcicgfSksXG4gICAgICAgICAgdGxwOiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcbiAgICAgICAgICB0YWdzOiBzY2hlbWEubWF5YmUoc2NoZW1hLmFycmF5T2Yoc2NoZW1hLnN0cmluZygpKSksXG4gICAgICAgICAgYXNzaWduZWU6IHNjaGVtYS5tYXliZShzY2hlbWEubnVsbGFibGUoc2NoZW1hLnN0cmluZygpKSksXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICAgIG9wdGlvbnM6IEVYVEVSTkFMX1dSSVRFX09QVElPTlMsXG4gICAgfSxcbiAgICB3aXRoQXV0aCgnd3JpdGUnLCBhc3luYyAoX2N0eCwgcmVxdWVzdCwgcmVzcG9uc2UsIGNsaWVudCwga2V5KSA9PiB7XG4gICAgICBjb25zdCBjcmVhdGVkID0gYXdhaXQgQ2FzZVNlcnZpY2UuY3JlYXRlQ2FzZShjbGllbnQsIHJlcXVlc3QuYm9keSBhcyBhbnksIGBhcGk6JHtrZXkubmFtZX1gKTtcbiAgICAgIGxvZ2dlci5pbmZvKGBFeHRlcm5hbCBBUEk6IGNhc2UgJHtjcmVhdGVkLmNhc2VfaWR9IGNyZWF0ZWQgdmlhIGtleSBcIiR7a2V5Lm5hbWV9XCJgKTtcbiAgICAgIHJldHVybiByZXNwb25zZS5vayh7IGJvZHk6IGNyZWF0ZWQgfSk7XG4gICAgfSksXG4gICk7XG5cbiAgLy8g4pSA4pSA4pSAIFVQREFURSBDQVNFIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICByb3V0ZXIucHV0KFxuICAgIHtcbiAgICAgIHBhdGg6IGAke0VYVEVSTkFMX0FQSV9QUkVGSVh9L2Nhc2VzL3tpZH1gLFxuICAgICAgdmFsaWRhdGU6IHtcbiAgICAgICAgcGFyYW1zOiBzY2hlbWEub2JqZWN0KHsgaWQ6IHNjaGVtYS5zdHJpbmcoKSB9KSxcbiAgICAgICAgYm9keTogc2NoZW1hLm9iamVjdCh7XG4gICAgICAgICAgdGl0bGU6IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICAgICAgICAgIGRlc2NyaXB0aW9uOiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcbiAgICAgICAgICBzZXZlcml0eTogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXG4gICAgICAgICAgcHJpb3JpdHk6IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICAgICAgICAgIGNhdGVnb3J5OiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcbiAgICAgICAgICB0bHA6IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICAgICAgICAgIHRhZ3M6IHNjaGVtYS5tYXliZShzY2hlbWEuYXJyYXlPZihzY2hlbWEuc3RyaW5nKCkpKSxcbiAgICAgICAgICBhc3NpZ25lZTogc2NoZW1hLm1heWJlKHNjaGVtYS5udWxsYWJsZShzY2hlbWEuc3RyaW5nKCkpKSxcbiAgICAgICAgICByZXNvbHV0aW9uX3N1bW1hcnk6IHNjaGVtYS5tYXliZShzY2hlbWEubnVsbGFibGUoc2NoZW1hLnN0cmluZygpKSksXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICAgIG9wdGlvbnM6IEVYVEVSTkFMX1dSSVRFX09QVElPTlMsXG4gICAgfSxcbiAgICB3aXRoQXV0aCgnd3JpdGUnLCBhc3luYyAoX2N0eCwgcmVxdWVzdCwgcmVzcG9uc2UsIGNsaWVudCwga2V5KSA9PiB7XG4gICAgICBjb25zdCB1cGRhdGVkID0gYXdhaXQgQ2FzZVNlcnZpY2UudXBkYXRlQ2FzZShcbiAgICAgICAgY2xpZW50LFxuICAgICAgICByZXF1ZXN0LnBhcmFtcy5pZCxcbiAgICAgICAgcmVxdWVzdC5ib2R5IGFzIGFueSxcbiAgICAgICAgYGFwaToke2tleS5uYW1lfWAsXG4gICAgICApO1xuICAgICAgaWYgKCF1cGRhdGVkKSByZXR1cm4gcmVzcG9uc2Uubm90Rm91bmQoeyBib2R5OiB7IG1lc3NhZ2U6ICdDYXNlIG5vdCBmb3VuZCcgfSB9KTtcbiAgICAgIHJldHVybiByZXNwb25zZS5vayh7IGJvZHk6IHVwZGF0ZWQgfSk7XG4gICAgfSksXG4gICk7XG5cbiAgLy8g4pSA4pSA4pSAIENIQU5HRSBTVEFUVVMg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gIHJvdXRlci5wb3N0KFxuICAgIHtcbiAgICAgIHBhdGg6IGAke0VYVEVSTkFMX0FQSV9QUkVGSVh9L2Nhc2VzL3tpZH0vc3RhdHVzYCxcbiAgICAgIHZhbGlkYXRlOiB7XG4gICAgICAgIHBhcmFtczogc2NoZW1hLm9iamVjdCh7IGlkOiBzY2hlbWEuc3RyaW5nKCkgfSksXG4gICAgICAgIGJvZHk6IHNjaGVtYS5vYmplY3QoeyBzdGF0dXM6IHNjaGVtYS5zdHJpbmcoKSB9KSxcbiAgICAgIH0sXG4gICAgICBvcHRpb25zOiBFWFRFUk5BTF9XUklURV9PUFRJT05TLFxuICAgIH0sXG4gICAgd2l0aEF1dGgoJ3dyaXRlJywgYXN5bmMgKF9jdHgsIHJlcXVlc3QsIHJlc3BvbnNlLCBjbGllbnQsIGtleSkgPT4ge1xuICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgQ2FzZVNlcnZpY2UuY2hhbmdlU3RhdHVzKFxuICAgICAgICBjbGllbnQsXG4gICAgICAgIHJlcXVlc3QucGFyYW1zLmlkLFxuICAgICAgICByZXF1ZXN0LmJvZHkuc3RhdHVzIGFzIGFueSxcbiAgICAgICAgYGFwaToke2tleS5uYW1lfWAsXG4gICAgICApO1xuICAgICAgaWYgKCFyZXN1bHQuc3VjY2Vzcykge1xuICAgICAgICByZXR1cm4gcmVzcG9uc2UuYmFkUmVxdWVzdCh7IGJvZHk6IHsgbWVzc2FnZTogcmVzdWx0LmVycm9yIH0gfSk7XG4gICAgICB9XG4gICAgICByZXR1cm4gcmVzcG9uc2Uub2soeyBib2R5OiByZXN1bHQuY2FzZSB9KTtcbiAgICB9KSxcbiAgKTtcblxuICAvLyDilIDilIDilIAgQVNTSUdOIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICByb3V0ZXIucG9zdChcbiAgICB7XG4gICAgICBwYXRoOiBgJHtFWFRFUk5BTF9BUElfUFJFRklYfS9jYXNlcy97aWR9L2Fzc2lnbmAsXG4gICAgICB2YWxpZGF0ZToge1xuICAgICAgICBwYXJhbXM6IHNjaGVtYS5vYmplY3QoeyBpZDogc2NoZW1hLnN0cmluZygpIH0pLFxuICAgICAgICBib2R5OiBzY2hlbWEub2JqZWN0KHsgYXNzaWduZWU6IHNjaGVtYS5udWxsYWJsZShzY2hlbWEuc3RyaW5nKCkpIH0pLFxuICAgICAgfSxcbiAgICAgIG9wdGlvbnM6IEVYVEVSTkFMX1dSSVRFX09QVElPTlMsXG4gICAgfSxcbiAgICB3aXRoQXV0aCgnd3JpdGUnLCBhc3luYyAoX2N0eCwgcmVxdWVzdCwgcmVzcG9uc2UsIGNsaWVudCwga2V5KSA9PiB7XG4gICAgICBjb25zdCB1cGRhdGVkID0gYXdhaXQgQ2FzZVNlcnZpY2UuYXNzaWduQ2FzZShcbiAgICAgICAgY2xpZW50LFxuICAgICAgICByZXF1ZXN0LnBhcmFtcy5pZCxcbiAgICAgICAgcmVxdWVzdC5ib2R5LmFzc2lnbmVlLFxuICAgICAgICBgYXBpOiR7a2V5Lm5hbWV9YCxcbiAgICAgICk7XG4gICAgICBpZiAoIXVwZGF0ZWQpIHJldHVybiByZXNwb25zZS5ub3RGb3VuZCh7IGJvZHk6IHsgbWVzc2FnZTogJ0Nhc2Ugbm90IGZvdW5kJyB9IH0pO1xuICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHsgYm9keTogdXBkYXRlZCB9KTtcbiAgICB9KSxcbiAgKTtcblxuICAvLyDilIDilIDilIAgQUREIENPTU1FTlQg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gIHJvdXRlci5wb3N0KFxuICAgIHtcbiAgICAgIHBhdGg6IGAke0VYVEVSTkFMX0FQSV9QUkVGSVh9L2Nhc2VzL3tpZH0vY29tbWVudHNgLFxuICAgICAgdmFsaWRhdGU6IHtcbiAgICAgICAgcGFyYW1zOiBzY2hlbWEub2JqZWN0KHsgaWQ6IHNjaGVtYS5zdHJpbmcoKSB9KSxcbiAgICAgICAgYm9keTogc2NoZW1hLm9iamVjdCh7XG4gICAgICAgICAgY29udGVudDogc2NoZW1hLnN0cmluZyh7IG1pbkxlbmd0aDogMSB9KSxcbiAgICAgICAgICBhdXRob3I6IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgICBvcHRpb25zOiBFWFRFUk5BTF9XUklURV9PUFRJT05TLFxuICAgIH0sXG4gICAgd2l0aEF1dGgoJ3dyaXRlJywgYXN5bmMgKF9jdHgsIHJlcXVlc3QsIHJlc3BvbnNlLCBjbGllbnQsIGtleSkgPT4ge1xuICAgICAgY29uc3QgYXV0aG9yID0gcmVxdWVzdC5ib2R5LmF1dGhvciB8fCBgYXBpOiR7a2V5Lm5hbWV9YDtcbiAgICAgIGNvbnN0IHVwZGF0ZWQgPSBhd2FpdCBDYXNlU2VydmljZS5hZGRDb21tZW50KFxuICAgICAgICBjbGllbnQsXG4gICAgICAgIHJlcXVlc3QucGFyYW1zLmlkLFxuICAgICAgICByZXF1ZXN0LmJvZHkuY29udGVudCxcbiAgICAgICAgYXV0aG9yLFxuICAgICAgKTtcbiAgICAgIGlmICghdXBkYXRlZCkgcmV0dXJuIHJlc3BvbnNlLm5vdEZvdW5kKHsgYm9keTogeyBtZXNzYWdlOiAnQ2FzZSBub3QgZm91bmQnIH0gfSk7XG4gICAgICByZXR1cm4gcmVzcG9uc2Uub2soeyBib2R5OiB1cGRhdGVkIH0pO1xuICAgIH0pLFxuICApO1xuXG4gIC8vIOKUgOKUgOKUgCBBREQgT0JTRVJWQUJMRSDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgcm91dGVyLnBvc3QoXG4gICAge1xuICAgICAgcGF0aDogYCR7RVhURVJOQUxfQVBJX1BSRUZJWH0vY2FzZXMve2lkfS9vYnNlcnZhYmxlc2AsXG4gICAgICB2YWxpZGF0ZToge1xuICAgICAgICBwYXJhbXM6IHNjaGVtYS5vYmplY3QoeyBpZDogc2NoZW1hLnN0cmluZygpIH0pLFxuICAgICAgICBib2R5OiBzY2hlbWEub2JqZWN0KHtcbiAgICAgICAgICB0eXBlOiBzY2hlbWEuc3RyaW5nKCksXG4gICAgICAgICAgdmFsdWU6IHNjaGVtYS5zdHJpbmcoeyBtaW5MZW5ndGg6IDEgfSksXG4gICAgICAgICAgZGVzY3JpcHRpb246IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICAgICAgICAgIGlzX2lvYzogc2NoZW1hLmJvb2xlYW4oeyBkZWZhdWx0VmFsdWU6IGZhbHNlIH0pLFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgICBvcHRpb25zOiBFWFRFUk5BTF9XUklURV9PUFRJT05TLFxuICAgIH0sXG4gICAgd2l0aEF1dGgoJ3dyaXRlJywgYXN5bmMgKF9jdHgsIHJlcXVlc3QsIHJlc3BvbnNlLCBjbGllbnQsIGtleSkgPT4ge1xuICAgICAgY29uc3QgdXBkYXRlZCA9IGF3YWl0IENhc2VTZXJ2aWNlLmFkZE9ic2VydmFibGUoXG4gICAgICAgIGNsaWVudCxcbiAgICAgICAgcmVxdWVzdC5wYXJhbXMuaWQsXG4gICAgICAgIHJlcXVlc3QuYm9keSBhcyBhbnksXG4gICAgICAgIGBhcGk6JHtrZXkubmFtZX1gLFxuICAgICAgKTtcbiAgICAgIGlmICghdXBkYXRlZCkgcmV0dXJuIHJlc3BvbnNlLm5vdEZvdW5kKHsgYm9keTogeyBtZXNzYWdlOiAnQ2FzZSBub3QgZm91bmQnIH0gfSk7XG4gICAgICByZXR1cm4gcmVzcG9uc2Uub2soeyBib2R5OiB1cGRhdGVkIH0pO1xuICAgIH0pLFxuICApO1xuXG4gIC8vIOKUgOKUgOKUgCBBTkFMWVRJQ1Mg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gIHJvdXRlci5nZXQoXG4gICAge1xuICAgICAgcGF0aDogYCR7RVhURVJOQUxfQVBJX1BSRUZJWH0vYW5hbHl0aWNzL3N1bW1hcnlgLFxuICAgICAgdmFsaWRhdGU6IGZhbHNlLFxuICAgICAgb3B0aW9uczogRVhURVJOQUxfR0VUX09QVElPTlMsXG4gICAgfSxcbiAgICB3aXRoQXV0aCgncmVhZCcsIGFzeW5jIChfY3R4LCBfcmVxdWVzdCwgcmVzcG9uc2UsIGNsaWVudCkgPT4ge1xuICAgICAgY29uc3Qgc3VtbWFyeSA9IGF3YWl0IENhc2VTZXJ2aWNlLmdldEFuYWx5dGljc1N1bW1hcnkoY2xpZW50KTtcbiAgICAgIHJldHVybiByZXNwb25zZS5vayh7IGJvZHk6IHN1bW1hcnkgfSk7XG4gICAgfSksXG4gICk7XG5cbiAgLy8g4pSA4pSA4pSAIElOR0VTVCBBIFJBVyBXQVpVSCBBTEVSVCDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgcm91dGVyLnBvc3QoXG4gICAge1xuICAgICAgcGF0aDogYCR7RVhURVJOQUxfQVBJX1BSRUZJWH0vYWxlcnRzL2luZ2VzdGAsXG4gICAgICB2YWxpZGF0ZTogeyBib2R5OiBzY2hlbWEub2JqZWN0KHt9LCB7IHVua25vd25zOiAnYWxsb3cnIH0pIH0sXG4gICAgICBvcHRpb25zOiBFWFRFUk5BTF9XUklURV9PUFRJT05TLFxuICAgIH0sXG4gICAgd2l0aEF1dGgoJ3dyaXRlJywgYXN5bmMgKF9jdHgsIHJlcXVlc3QsIHJlc3BvbnNlLCBjbGllbnQsIGtleSkgPT4ge1xuICAgICAgY29uc3QgY3JlYXRlZCA9IGF3YWl0IENhc2VTZXJ2aWNlLmhhbmRsZUF1dG9tYXRlZEFsZXJ0KFxuICAgICAgICBjbGllbnQsXG4gICAgICAgIHJlcXVlc3QuYm9keSxcbiAgICAgICAgYGFwaToke2tleS5uYW1lfWAsXG4gICAgICApO1xuICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHsgYm9keTogeyBzdWNjZXNzOiB0cnVlLCBjYXNlOiBjcmVhdGVkIH0gfSk7XG4gICAgfSksXG4gICk7XG5cbiAgbG9nZ2VyLmluZm8oJ0V4dGVybmFsIChBUEkta2V5KSByb3V0ZXMgcmVnaXN0ZXJlZCcpO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFrQkEsSUFBQUEsYUFBQSxHQUFBQyxPQUFBO0FBQ0EsSUFBQUMsYUFBQSxHQUFBRCxPQUFBO0FBQ0EsSUFBQUUsaUJBQUEsR0FBQUYsT0FBQTtBQUVBLElBQUFHLFVBQUEsR0FBQUgsT0FBQTtBQXRCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFTQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxNQUFNSSxvQkFBb0IsR0FBRztFQUMzQkMsWUFBWSxFQUFFO0FBQ2hCLENBQUM7QUFFRCxNQUFNQyxzQkFBc0IsR0FBRztFQUM3QkQsWUFBWSxFQUFFLEtBQWM7RUFDNUJFLFlBQVksRUFBRTtBQUNoQixDQUFDO0FBU0Q7QUFDQSxlQUFlQyxZQUFZQSxDQUN6QkMsTUFBVyxFQUNYQyxPQUFZLEVBQ1pDLFFBQXFCLEVBQ0E7RUFBQSxJQUFBQyxnQkFBQSxFQUFBQyxpQkFBQTtFQUNyQixNQUFNQyxNQUFNLEdBQUcsRUFBQUYsZ0JBQUEsR0FBQUYsT0FBTyxDQUFDSyxPQUFPLGNBQUFILGdCQUFBLHVCQUFmQSxnQkFBQSxDQUFrQkkseUJBQWMsQ0FBQyxPQUFBSCxpQkFBQSxHQUFJSCxPQUFPLENBQUNLLE9BQU8sY0FBQUYsaUJBQUEsdUJBQWZBLGlCQUFBLENBQWtCRyx5QkFBYyxDQUFDQyxXQUFXLENBQUMsQ0FBQyxDQUFDO0VBQ25HLE1BQU1DLEdBQUcsR0FBR0MsS0FBSyxDQUFDQyxPQUFPLENBQUNOLE1BQU0sQ0FBQyxHQUFHQSxNQUFNLENBQUMsQ0FBQyxDQUFDLEdBQUdBLE1BQU07RUFFdEQsSUFBSSxDQUFDSSxHQUFHLEVBQUU7SUFDUixPQUFPO01BQUVHLEVBQUUsRUFBRSxLQUFLO01BQUVDLE1BQU0sRUFBRSxHQUFHO01BQUVDLE9BQU8sRUFBRyxXQUFVUCx5QkFBZTtJQUFTLENBQUM7RUFDaEY7RUFFQSxNQUFNUSxHQUFHLEdBQUcsTUFBTUMsaUNBQWUsQ0FBQ0MsWUFBWSxDQUFDakIsTUFBTSxFQUFFa0IsTUFBTSxDQUFDVCxHQUFHLENBQUMsQ0FBQ1UsSUFBSSxDQUFDLENBQUMsQ0FBQztFQUMxRSxJQUFJLENBQUNKLEdBQUcsRUFBRTtJQUNSLE9BQU87TUFBRUgsRUFBRSxFQUFFLEtBQUs7TUFBRUMsTUFBTSxFQUFFLEdBQUc7TUFBRUMsT0FBTyxFQUFFO0lBQXVDLENBQUM7RUFDcEY7O0VBRUE7RUFDQSxNQUFNTSxRQUFRLEdBQUdMLEdBQUcsQ0FBQ00sTUFBTSxDQUFDQyxRQUFRLENBQUNwQixRQUFRLENBQUMsSUFBS0EsUUFBUSxLQUFLLE1BQU0sSUFBSWEsR0FBRyxDQUFDTSxNQUFNLENBQUNDLFFBQVEsQ0FBQyxPQUFPLENBQUU7RUFDdkcsSUFBSSxDQUFDRixRQUFRLEVBQUU7SUFDYixPQUFPO01BQUVSLEVBQUUsRUFBRSxLQUFLO01BQUVDLE1BQU0sRUFBRSxHQUFHO01BQUVDLE9BQU8sRUFBRyxzQkFBcUJaLFFBQVM7SUFBUyxDQUFDO0VBQ3JGO0VBRUEsT0FBTztJQUFFVSxFQUFFLEVBQUUsSUFBSTtJQUFFRztFQUFJLENBQUM7QUFDMUI7QUFFTyxTQUFTUSxzQkFBc0JBLENBQUNDLE1BQWUsRUFBRUMsTUFBYyxFQUFRO0VBQzVFO0FBQ0Y7QUFDQTtBQUNBO0VBQ0UsTUFBTUMsUUFBUSxHQUNaQSxDQUFDeEIsUUFBcUIsRUFBRXlCLE9BQWlGLEtBQ3pHLE9BQU9DLE9BQVksRUFBRTNCLE9BQVksRUFBRTRCLFFBQWEsS0FBSztJQUNuRCxNQUFNN0IsTUFBTSxHQUFHNEIsT0FBTyxDQUFDRSxJQUFJLENBQUNDLFVBQVUsQ0FBQy9CLE1BQU0sQ0FBQ2dDLGNBQWM7SUFDNUQsTUFBTUMsSUFBSSxHQUFHLE1BQU1sQyxZQUFZLENBQUNDLE1BQU0sRUFBRUMsT0FBTyxFQUFFQyxRQUFRLENBQUM7SUFDMUQsSUFBSSxDQUFDK0IsSUFBSSxDQUFDckIsRUFBRSxFQUFFO01BQ1phLE1BQU0sQ0FBQ1MsSUFBSSxDQUFFLHFDQUFvQ2pDLE9BQU8sQ0FBQ2tDLEtBQUssQ0FBQ0MsSUFBSyxLQUFJSCxJQUFJLENBQUNuQixPQUFRLEVBQUMsQ0FBQztNQUN2RixPQUFPZSxRQUFRLENBQUNRLFdBQVcsQ0FBQztRQUMxQkMsVUFBVSxFQUFFTCxJQUFJLENBQUNwQixNQUFNLElBQUksR0FBRztRQUM5QjBCLElBQUksRUFBRTtVQUFFekIsT0FBTyxFQUFFbUIsSUFBSSxDQUFDbkI7UUFBUTtNQUNoQyxDQUFDLENBQUM7SUFDSjs7SUFFQTtJQUNBRSxpQ0FBZSxDQUFDd0IsV0FBVyxDQUFDeEMsTUFBTSxFQUFFaUMsSUFBSSxDQUFDbEIsR0FBRyxDQUFFMEIsRUFBRSxDQUFDLENBQUNDLEtBQUssQ0FBQyxNQUFNQyxTQUFTLENBQUM7SUFFeEUsSUFBSTtNQUNGLE9BQU8sTUFBTWhCLE9BQU8sQ0FBQ0MsT0FBTyxFQUFFM0IsT0FBTyxFQUFFNEIsUUFBUSxFQUFFN0IsTUFBTSxFQUFFaUMsSUFBSSxDQUFDbEIsR0FBSSxDQUFDO0lBQ3JFLENBQUMsQ0FBQyxPQUFPNkIsS0FBVSxFQUFFO01BQ25CbkIsTUFBTSxDQUFDbUIsS0FBSyxDQUFFLHlCQUF3QjNDLE9BQU8sQ0FBQ2tDLEtBQUssQ0FBQ0MsSUFBSyxLQUFJUSxLQUFLLENBQUM5QixPQUFRLEVBQUMsQ0FBQztNQUM3RSxPQUFPZSxRQUFRLENBQUNRLFdBQVcsQ0FBQztRQUMxQkMsVUFBVSxFQUFFTSxLQUFLLENBQUNOLFVBQVUsSUFBSSxHQUFHO1FBQ25DQyxJQUFJLEVBQUU7VUFBRXpCLE9BQU8sRUFBRThCLEtBQUssQ0FBQzlCO1FBQVE7TUFDakMsQ0FBQyxDQUFDO0lBQ0o7RUFDRixDQUFDOztFQUVIO0VBQ0FVLE1BQU0sQ0FBQ3FCLEdBQUcsQ0FDUjtJQUFFVCxJQUFJLEVBQUcsR0FBRVUsOEJBQW9CLFNBQVE7SUFBRUMsUUFBUSxFQUFFLEtBQUs7SUFBRUMsT0FBTyxFQUFFckQ7RUFBcUIsQ0FBQyxFQUN6RitCLFFBQVEsQ0FBQyxNQUFNLEVBQUUsT0FBT3VCLElBQUksRUFBRUMsSUFBSSxFQUFFckIsUUFBUSxFQUFFc0IsT0FBTyxFQUFFcEMsR0FBRyxLQUN4RGMsUUFBUSxDQUFDakIsRUFBRSxDQUFDO0lBQ1YyQixJQUFJLEVBQUU7TUFDSjFCLE1BQU0sRUFBRSxJQUFJO01BQ1p1QyxHQUFHLEVBQUUsdUJBQXVCO01BQzVCQyxPQUFPLEVBQUUsT0FBTztNQUNoQnRDLEdBQUcsRUFBRTtRQUFFMEIsRUFBRSxFQUFFMUIsR0FBRyxDQUFDMEIsRUFBRTtRQUFFYSxJQUFJLEVBQUV2QyxHQUFHLENBQUN1QyxJQUFJO1FBQUVqQyxNQUFNLEVBQUVOLEdBQUcsQ0FBQ007TUFBTyxDQUFDO01BQ3ZEa0MsV0FBVyxFQUFFLElBQUlDLElBQUksQ0FBQyxDQUFDLENBQUNDLFdBQVcsQ0FBQztJQUN0QztFQUNGLENBQUMsQ0FDSCxDQUNGLENBQUM7O0VBRUQ7RUFDQWpDLE1BQU0sQ0FBQ3FCLEdBQUcsQ0FDUjtJQUNFVCxJQUFJLEVBQUcsR0FBRVUsOEJBQW9CLFFBQU87SUFDcENDLFFBQVEsRUFBRTtNQUNSVyxLQUFLLEVBQUVDLG9CQUFNLENBQUNDLE1BQU0sQ0FDbEI7UUFDRUMsSUFBSSxFQUFFRixvQkFBTSxDQUFDRyxLQUFLLENBQUNILG9CQUFNLENBQUNJLE1BQU0sQ0FBQztVQUFFQyxHQUFHLEVBQUU7UUFBRSxDQUFDLENBQUMsQ0FBQztRQUM3Q0MsUUFBUSxFQUFFTixvQkFBTSxDQUFDRyxLQUFLLENBQUNILG9CQUFNLENBQUNJLE1BQU0sQ0FBQztVQUFFQyxHQUFHLEVBQUUsQ0FBQztVQUFFRSxHQUFHLEVBQUU7UUFBSSxDQUFDLENBQUMsQ0FBQztRQUMzREMsVUFBVSxFQUFFUixvQkFBTSxDQUFDRyxLQUFLLENBQUNILG9CQUFNLENBQUNTLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFDekNDLFVBQVUsRUFBRVYsb0JBQU0sQ0FBQ0csS0FBSyxDQUFDSCxvQkFBTSxDQUFDVyxLQUFLLENBQUMsQ0FBQ1gsb0JBQU0sQ0FBQ1ksT0FBTyxDQUFDLEtBQUssQ0FBQyxFQUFFWixvQkFBTSxDQUFDWSxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3ZGMUQsTUFBTSxFQUFFOEMsb0JBQU0sQ0FBQ0csS0FBSyxDQUFDSCxvQkFBTSxDQUFDUyxNQUFNLENBQUMsQ0FBQyxDQUFDO1FBQ3JDSSxRQUFRLEVBQUViLG9CQUFNLENBQUNHLEtBQUssQ0FBQ0gsb0JBQU0sQ0FBQ1MsTUFBTSxDQUFDLENBQUMsQ0FBQztRQUN2Q0ssUUFBUSxFQUFFZCxvQkFBTSxDQUFDRyxLQUFLLENBQUNILG9CQUFNLENBQUNTLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFDdkNNLFFBQVEsRUFBRWYsb0JBQU0sQ0FBQ0csS0FBSyxDQUFDSCxvQkFBTSxDQUFDUyxNQUFNLENBQUMsQ0FBQyxDQUFDO1FBQ3ZDTyxRQUFRLEVBQUVoQixvQkFBTSxDQUFDRyxLQUFLLENBQUNILG9CQUFNLENBQUNTLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFDdkNRLE1BQU0sRUFBRWpCLG9CQUFNLENBQUNHLEtBQUssQ0FBQ0gsb0JBQU0sQ0FBQ1MsTUFBTSxDQUFDLENBQUMsQ0FBQztRQUNyQ1MsSUFBSSxFQUFFbEIsb0JBQU0sQ0FBQ0csS0FBSyxDQUFDSCxvQkFBTSxDQUFDUyxNQUFNLENBQUMsQ0FBQyxDQUFDO1FBQ25DVSxZQUFZLEVBQUVuQixvQkFBTSxDQUFDRyxLQUFLLENBQUNILG9CQUFNLENBQUNTLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFDM0NXLFVBQVUsRUFBRXBCLG9CQUFNLENBQUNHLEtBQUssQ0FBQ0gsb0JBQU0sQ0FBQ1MsTUFBTSxDQUFDLENBQUM7TUFDMUMsQ0FBQyxFQUNEO1FBQUVZLFFBQVEsRUFBRTtNQUFTLENBQ3ZCO0lBQ0YsQ0FBQztJQUNEaEMsT0FBTyxFQUFFckQ7RUFDWCxDQUFDLEVBQ0QrQixRQUFRLENBQUMsTUFBTSxFQUFFLE9BQU91QixJQUFJLEVBQUVoRCxPQUFPLEVBQUU0QixRQUFRLEVBQUU3QixNQUFNLEtBQUs7SUFDMUQsTUFBTWlGLE1BQU0sR0FBRyxNQUFNQyx5QkFBVyxDQUFDQyxTQUFTLENBQUNuRixNQUFNLEVBQUVDLE9BQU8sQ0FBQ3lELEtBQVksQ0FBQztJQUN4RSxPQUFPN0IsUUFBUSxDQUFDakIsRUFBRSxDQUFDO01BQUUyQixJQUFJLEVBQUUwQztJQUFPLENBQUMsQ0FBQztFQUN0QyxDQUFDLENBQ0gsQ0FBQzs7RUFFRDtFQUNBekQsTUFBTSxDQUFDcUIsR0FBRyxDQUNSO0lBQ0VULElBQUksRUFBRyxHQUFFVSw4QkFBb0IsYUFBWTtJQUN6Q0MsUUFBUSxFQUFFO01BQUVxQyxNQUFNLEVBQUV6QixvQkFBTSxDQUFDQyxNQUFNLENBQUM7UUFBRW5CLEVBQUUsRUFBRWtCLG9CQUFNLENBQUNTLE1BQU0sQ0FBQztNQUFFLENBQUM7SUFBRSxDQUFDO0lBQzVEcEIsT0FBTyxFQUFFckQ7RUFDWCxDQUFDLEVBQ0QrQixRQUFRLENBQUMsTUFBTSxFQUFFLE9BQU91QixJQUFJLEVBQUVoRCxPQUFPLEVBQUU0QixRQUFRLEVBQUU3QixNQUFNLEtBQUs7SUFDMUQsTUFBTXFGLEtBQUssR0FBRyxNQUFNSCx5QkFBVyxDQUFDSSxPQUFPLENBQUN0RixNQUFNLEVBQUVDLE9BQU8sQ0FBQ21GLE1BQU0sQ0FBQzNDLEVBQUUsQ0FBQztJQUNsRSxJQUFJLENBQUM0QyxLQUFLLEVBQUUsT0FBT3hELFFBQVEsQ0FBQzBELFFBQVEsQ0FBQztNQUFFaEQsSUFBSSxFQUFFO1FBQUV6QixPQUFPLEVBQUU7TUFBaUI7SUFBRSxDQUFDLENBQUM7SUFDN0UsT0FBT2UsUUFBUSxDQUFDakIsRUFBRSxDQUFDO01BQUUyQixJQUFJLEVBQUU4QztJQUFNLENBQUMsQ0FBQztFQUNyQyxDQUFDLENBQ0gsQ0FBQzs7RUFFRDtFQUNBN0QsTUFBTSxDQUFDZ0UsSUFBSSxDQUNUO0lBQ0VwRCxJQUFJLEVBQUcsR0FBRVUsOEJBQW9CLFFBQU87SUFDcENDLFFBQVEsRUFBRTtNQUNSUixJQUFJLEVBQUVvQixvQkFBTSxDQUFDQyxNQUFNLENBQUM7UUFDbEI2QixLQUFLLEVBQUU5QixvQkFBTSxDQUFDUyxNQUFNLENBQUM7VUFBRXNCLFNBQVMsRUFBRTtRQUFFLENBQUMsQ0FBQztRQUN0Q0MsV0FBVyxFQUFFaEMsb0JBQU0sQ0FBQ1MsTUFBTSxDQUFDO1VBQUV3QixZQUFZLEVBQUU7UUFBRyxDQUFDLENBQUM7UUFDaERwQixRQUFRLEVBQUViLG9CQUFNLENBQUNTLE1BQU0sQ0FBQztVQUFFd0IsWUFBWSxFQUFFO1FBQVMsQ0FBQyxDQUFDO1FBQ25EbkIsUUFBUSxFQUFFZCxvQkFBTSxDQUFDUyxNQUFNLENBQUM7VUFBRXdCLFlBQVksRUFBRTtRQUFLLENBQUMsQ0FBQztRQUMvQ2xCLFFBQVEsRUFBRWYsb0JBQU0sQ0FBQ1MsTUFBTSxDQUFDO1VBQUV3QixZQUFZLEVBQUU7UUFBUSxDQUFDLENBQUM7UUFDbERDLEdBQUcsRUFBRWxDLG9CQUFNLENBQUNHLEtBQUssQ0FBQ0gsb0JBQU0sQ0FBQ1MsTUFBTSxDQUFDLENBQUMsQ0FBQztRQUNsQ1MsSUFBSSxFQUFFbEIsb0JBQU0sQ0FBQ0csS0FBSyxDQUFDSCxvQkFBTSxDQUFDbUMsT0FBTyxDQUFDbkMsb0JBQU0sQ0FBQ1MsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ25ETyxRQUFRLEVBQUVoQixvQkFBTSxDQUFDRyxLQUFLLENBQUNILG9CQUFNLENBQUNvQyxRQUFRLENBQUNwQyxvQkFBTSxDQUFDUyxNQUFNLENBQUMsQ0FBQyxDQUFDO01BQ3pELENBQUM7SUFDSCxDQUFDO0lBQ0RwQixPQUFPLEVBQUVuRDtFQUNYLENBQUMsRUFDRDZCLFFBQVEsQ0FBQyxPQUFPLEVBQUUsT0FBT3VCLElBQUksRUFBRWhELE9BQU8sRUFBRTRCLFFBQVEsRUFBRTdCLE1BQU0sRUFBRWUsR0FBRyxLQUFLO0lBQ2hFLE1BQU1pRixPQUFPLEdBQUcsTUFBTWQseUJBQVcsQ0FBQ2UsVUFBVSxDQUFDakcsTUFBTSxFQUFFQyxPQUFPLENBQUNzQyxJQUFJLEVBQVUsT0FBTXhCLEdBQUcsQ0FBQ3VDLElBQUssRUFBQyxDQUFDO0lBQzVGN0IsTUFBTSxDQUFDeUUsSUFBSSxDQUFFLHNCQUFxQkYsT0FBTyxDQUFDRyxPQUFRLHFCQUFvQnBGLEdBQUcsQ0FBQ3VDLElBQUssR0FBRSxDQUFDO0lBQ2xGLE9BQU96QixRQUFRLENBQUNqQixFQUFFLENBQUM7TUFBRTJCLElBQUksRUFBRXlEO0lBQVEsQ0FBQyxDQUFDO0VBQ3ZDLENBQUMsQ0FDSCxDQUFDOztFQUVEO0VBQ0F4RSxNQUFNLENBQUM0RSxHQUFHLENBQ1I7SUFDRWhFLElBQUksRUFBRyxHQUFFVSw4QkFBb0IsYUFBWTtJQUN6Q0MsUUFBUSxFQUFFO01BQ1JxQyxNQUFNLEVBQUV6QixvQkFBTSxDQUFDQyxNQUFNLENBQUM7UUFBRW5CLEVBQUUsRUFBRWtCLG9CQUFNLENBQUNTLE1BQU0sQ0FBQztNQUFFLENBQUMsQ0FBQztNQUM5QzdCLElBQUksRUFBRW9CLG9CQUFNLENBQUNDLE1BQU0sQ0FBQztRQUNsQjZCLEtBQUssRUFBRTlCLG9CQUFNLENBQUNHLEtBQUssQ0FBQ0gsb0JBQU0sQ0FBQ1MsTUFBTSxDQUFDLENBQUMsQ0FBQztRQUNwQ3VCLFdBQVcsRUFBRWhDLG9CQUFNLENBQUNHLEtBQUssQ0FBQ0gsb0JBQU0sQ0FBQ1MsTUFBTSxDQUFDLENBQUMsQ0FBQztRQUMxQ0ksUUFBUSxFQUFFYixvQkFBTSxDQUFDRyxLQUFLLENBQUNILG9CQUFNLENBQUNTLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFDdkNLLFFBQVEsRUFBRWQsb0JBQU0sQ0FBQ0csS0FBSyxDQUFDSCxvQkFBTSxDQUFDUyxNQUFNLENBQUMsQ0FBQyxDQUFDO1FBQ3ZDTSxRQUFRLEVBQUVmLG9CQUFNLENBQUNHLEtBQUssQ0FBQ0gsb0JBQU0sQ0FBQ1MsTUFBTSxDQUFDLENBQUMsQ0FBQztRQUN2Q3lCLEdBQUcsRUFBRWxDLG9CQUFNLENBQUNHLEtBQUssQ0FBQ0gsb0JBQU0sQ0FBQ1MsTUFBTSxDQUFDLENBQUMsQ0FBQztRQUNsQ1MsSUFBSSxFQUFFbEIsb0JBQU0sQ0FBQ0csS0FBSyxDQUFDSCxvQkFBTSxDQUFDbUMsT0FBTyxDQUFDbkMsb0JBQU0sQ0FBQ1MsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ25ETyxRQUFRLEVBQUVoQixvQkFBTSxDQUFDRyxLQUFLLENBQUNILG9CQUFNLENBQUNvQyxRQUFRLENBQUNwQyxvQkFBTSxDQUFDUyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDeERpQyxrQkFBa0IsRUFBRTFDLG9CQUFNLENBQUNHLEtBQUssQ0FBQ0gsb0JBQU0sQ0FBQ29DLFFBQVEsQ0FBQ3BDLG9CQUFNLENBQUNTLE1BQU0sQ0FBQyxDQUFDLENBQUM7TUFDbkUsQ0FBQztJQUNILENBQUM7SUFDRHBCLE9BQU8sRUFBRW5EO0VBQ1gsQ0FBQyxFQUNENkIsUUFBUSxDQUFDLE9BQU8sRUFBRSxPQUFPdUIsSUFBSSxFQUFFaEQsT0FBTyxFQUFFNEIsUUFBUSxFQUFFN0IsTUFBTSxFQUFFZSxHQUFHLEtBQUs7SUFDaEUsTUFBTXVGLE9BQU8sR0FBRyxNQUFNcEIseUJBQVcsQ0FBQ3FCLFVBQVUsQ0FDMUN2RyxNQUFNLEVBQ05DLE9BQU8sQ0FBQ21GLE1BQU0sQ0FBQzNDLEVBQUUsRUFDakJ4QyxPQUFPLENBQUNzQyxJQUFJLEVBQ1gsT0FBTXhCLEdBQUcsQ0FBQ3VDLElBQUssRUFDbEIsQ0FBQztJQUNELElBQUksQ0FBQ2dELE9BQU8sRUFBRSxPQUFPekUsUUFBUSxDQUFDMEQsUUFBUSxDQUFDO01BQUVoRCxJQUFJLEVBQUU7UUFBRXpCLE9BQU8sRUFBRTtNQUFpQjtJQUFFLENBQUMsQ0FBQztJQUMvRSxPQUFPZSxRQUFRLENBQUNqQixFQUFFLENBQUM7TUFBRTJCLElBQUksRUFBRStEO0lBQVEsQ0FBQyxDQUFDO0VBQ3ZDLENBQUMsQ0FDSCxDQUFDOztFQUVEO0VBQ0E5RSxNQUFNLENBQUNnRSxJQUFJLENBQ1Q7SUFDRXBELElBQUksRUFBRyxHQUFFVSw4QkFBb0Isb0JBQW1CO0lBQ2hEQyxRQUFRLEVBQUU7TUFDUnFDLE1BQU0sRUFBRXpCLG9CQUFNLENBQUNDLE1BQU0sQ0FBQztRQUFFbkIsRUFBRSxFQUFFa0Isb0JBQU0sQ0FBQ1MsTUFBTSxDQUFDO01BQUUsQ0FBQyxDQUFDO01BQzlDN0IsSUFBSSxFQUFFb0Isb0JBQU0sQ0FBQ0MsTUFBTSxDQUFDO1FBQUUvQyxNQUFNLEVBQUU4QyxvQkFBTSxDQUFDUyxNQUFNLENBQUM7TUFBRSxDQUFDO0lBQ2pELENBQUM7SUFDRHBCLE9BQU8sRUFBRW5EO0VBQ1gsQ0FBQyxFQUNENkIsUUFBUSxDQUFDLE9BQU8sRUFBRSxPQUFPdUIsSUFBSSxFQUFFaEQsT0FBTyxFQUFFNEIsUUFBUSxFQUFFN0IsTUFBTSxFQUFFZSxHQUFHLEtBQUs7SUFDaEUsTUFBTWtFLE1BQU0sR0FBRyxNQUFNQyx5QkFBVyxDQUFDc0IsWUFBWSxDQUMzQ3hHLE1BQU0sRUFDTkMsT0FBTyxDQUFDbUYsTUFBTSxDQUFDM0MsRUFBRSxFQUNqQnhDLE9BQU8sQ0FBQ3NDLElBQUksQ0FBQzFCLE1BQU0sRUFDbEIsT0FBTUUsR0FBRyxDQUFDdUMsSUFBSyxFQUNsQixDQUFDO0lBQ0QsSUFBSSxDQUFDMkIsTUFBTSxDQUFDd0IsT0FBTyxFQUFFO01BQ25CLE9BQU81RSxRQUFRLENBQUM2RSxVQUFVLENBQUM7UUFBRW5FLElBQUksRUFBRTtVQUFFekIsT0FBTyxFQUFFbUUsTUFBTSxDQUFDckM7UUFBTTtNQUFFLENBQUMsQ0FBQztJQUNqRTtJQUNBLE9BQU9mLFFBQVEsQ0FBQ2pCLEVBQUUsQ0FBQztNQUFFMkIsSUFBSSxFQUFFMEMsTUFBTSxDQUFDMEI7SUFBSyxDQUFDLENBQUM7RUFDM0MsQ0FBQyxDQUNILENBQUM7O0VBRUQ7RUFDQW5GLE1BQU0sQ0FBQ2dFLElBQUksQ0FDVDtJQUNFcEQsSUFBSSxFQUFHLEdBQUVVLDhCQUFvQixvQkFBbUI7SUFDaERDLFFBQVEsRUFBRTtNQUNScUMsTUFBTSxFQUFFekIsb0JBQU0sQ0FBQ0MsTUFBTSxDQUFDO1FBQUVuQixFQUFFLEVBQUVrQixvQkFBTSxDQUFDUyxNQUFNLENBQUM7TUFBRSxDQUFDLENBQUM7TUFDOUM3QixJQUFJLEVBQUVvQixvQkFBTSxDQUFDQyxNQUFNLENBQUM7UUFBRWUsUUFBUSxFQUFFaEIsb0JBQU0sQ0FBQ29DLFFBQVEsQ0FBQ3BDLG9CQUFNLENBQUNTLE1BQU0sQ0FBQyxDQUFDO01BQUUsQ0FBQztJQUNwRSxDQUFDO0lBQ0RwQixPQUFPLEVBQUVuRDtFQUNYLENBQUMsRUFDRDZCLFFBQVEsQ0FBQyxPQUFPLEVBQUUsT0FBT3VCLElBQUksRUFBRWhELE9BQU8sRUFBRTRCLFFBQVEsRUFBRTdCLE1BQU0sRUFBRWUsR0FBRyxLQUFLO0lBQ2hFLE1BQU11RixPQUFPLEdBQUcsTUFBTXBCLHlCQUFXLENBQUMwQixVQUFVLENBQzFDNUcsTUFBTSxFQUNOQyxPQUFPLENBQUNtRixNQUFNLENBQUMzQyxFQUFFLEVBQ2pCeEMsT0FBTyxDQUFDc0MsSUFBSSxDQUFDb0MsUUFBUSxFQUNwQixPQUFNNUQsR0FBRyxDQUFDdUMsSUFBSyxFQUNsQixDQUFDO0lBQ0QsSUFBSSxDQUFDZ0QsT0FBTyxFQUFFLE9BQU96RSxRQUFRLENBQUMwRCxRQUFRLENBQUM7TUFBRWhELElBQUksRUFBRTtRQUFFekIsT0FBTyxFQUFFO01BQWlCO0lBQUUsQ0FBQyxDQUFDO0lBQy9FLE9BQU9lLFFBQVEsQ0FBQ2pCLEVBQUUsQ0FBQztNQUFFMkIsSUFBSSxFQUFFK0Q7SUFBUSxDQUFDLENBQUM7RUFDdkMsQ0FBQyxDQUNILENBQUM7O0VBRUQ7RUFDQTlFLE1BQU0sQ0FBQ2dFLElBQUksQ0FDVDtJQUNFcEQsSUFBSSxFQUFHLEdBQUVVLDhCQUFvQixzQkFBcUI7SUFDbERDLFFBQVEsRUFBRTtNQUNScUMsTUFBTSxFQUFFekIsb0JBQU0sQ0FBQ0MsTUFBTSxDQUFDO1FBQUVuQixFQUFFLEVBQUVrQixvQkFBTSxDQUFDUyxNQUFNLENBQUM7TUFBRSxDQUFDLENBQUM7TUFDOUM3QixJQUFJLEVBQUVvQixvQkFBTSxDQUFDQyxNQUFNLENBQUM7UUFDbEJpRCxPQUFPLEVBQUVsRCxvQkFBTSxDQUFDUyxNQUFNLENBQUM7VUFBRXNCLFNBQVMsRUFBRTtRQUFFLENBQUMsQ0FBQztRQUN4Q29CLE1BQU0sRUFBRW5ELG9CQUFNLENBQUNHLEtBQUssQ0FBQ0gsb0JBQU0sQ0FBQ1MsTUFBTSxDQUFDLENBQUM7TUFDdEMsQ0FBQztJQUNILENBQUM7SUFDRHBCLE9BQU8sRUFBRW5EO0VBQ1gsQ0FBQyxFQUNENkIsUUFBUSxDQUFDLE9BQU8sRUFBRSxPQUFPdUIsSUFBSSxFQUFFaEQsT0FBTyxFQUFFNEIsUUFBUSxFQUFFN0IsTUFBTSxFQUFFZSxHQUFHLEtBQUs7SUFDaEUsTUFBTStGLE1BQU0sR0FBRzdHLE9BQU8sQ0FBQ3NDLElBQUksQ0FBQ3VFLE1BQU0sSUFBSyxPQUFNL0YsR0FBRyxDQUFDdUMsSUFBSyxFQUFDO0lBQ3ZELE1BQU1nRCxPQUFPLEdBQUcsTUFBTXBCLHlCQUFXLENBQUM2QixVQUFVLENBQzFDL0csTUFBTSxFQUNOQyxPQUFPLENBQUNtRixNQUFNLENBQUMzQyxFQUFFLEVBQ2pCeEMsT0FBTyxDQUFDc0MsSUFBSSxDQUFDc0UsT0FBTyxFQUNwQkMsTUFDRixDQUFDO0lBQ0QsSUFBSSxDQUFDUixPQUFPLEVBQUUsT0FBT3pFLFFBQVEsQ0FBQzBELFFBQVEsQ0FBQztNQUFFaEQsSUFBSSxFQUFFO1FBQUV6QixPQUFPLEVBQUU7TUFBaUI7SUFBRSxDQUFDLENBQUM7SUFDL0UsT0FBT2UsUUFBUSxDQUFDakIsRUFBRSxDQUFDO01BQUUyQixJQUFJLEVBQUUrRDtJQUFRLENBQUMsQ0FBQztFQUN2QyxDQUFDLENBQ0gsQ0FBQzs7RUFFRDtFQUNBOUUsTUFBTSxDQUFDZ0UsSUFBSSxDQUNUO0lBQ0VwRCxJQUFJLEVBQUcsR0FBRVUsOEJBQW9CLHlCQUF3QjtJQUNyREMsUUFBUSxFQUFFO01BQ1JxQyxNQUFNLEVBQUV6QixvQkFBTSxDQUFDQyxNQUFNLENBQUM7UUFBRW5CLEVBQUUsRUFBRWtCLG9CQUFNLENBQUNTLE1BQU0sQ0FBQztNQUFFLENBQUMsQ0FBQztNQUM5QzdCLElBQUksRUFBRW9CLG9CQUFNLENBQUNDLE1BQU0sQ0FBQztRQUNsQm9ELElBQUksRUFBRXJELG9CQUFNLENBQUNTLE1BQU0sQ0FBQyxDQUFDO1FBQ3JCNkMsS0FBSyxFQUFFdEQsb0JBQU0sQ0FBQ1MsTUFBTSxDQUFDO1VBQUVzQixTQUFTLEVBQUU7UUFBRSxDQUFDLENBQUM7UUFDdENDLFdBQVcsRUFBRWhDLG9CQUFNLENBQUNHLEtBQUssQ0FBQ0gsb0JBQU0sQ0FBQ1MsTUFBTSxDQUFDLENBQUMsQ0FBQztRQUMxQzhDLE1BQU0sRUFBRXZELG9CQUFNLENBQUN3RCxPQUFPLENBQUM7VUFBRXZCLFlBQVksRUFBRTtRQUFNLENBQUM7TUFDaEQsQ0FBQztJQUNILENBQUM7SUFDRDVDLE9BQU8sRUFBRW5EO0VBQ1gsQ0FBQyxFQUNENkIsUUFBUSxDQUFDLE9BQU8sRUFBRSxPQUFPdUIsSUFBSSxFQUFFaEQsT0FBTyxFQUFFNEIsUUFBUSxFQUFFN0IsTUFBTSxFQUFFZSxHQUFHLEtBQUs7SUFDaEUsTUFBTXVGLE9BQU8sR0FBRyxNQUFNcEIseUJBQVcsQ0FBQ2tDLGFBQWEsQ0FDN0NwSCxNQUFNLEVBQ05DLE9BQU8sQ0FBQ21GLE1BQU0sQ0FBQzNDLEVBQUUsRUFDakJ4QyxPQUFPLENBQUNzQyxJQUFJLEVBQ1gsT0FBTXhCLEdBQUcsQ0FBQ3VDLElBQUssRUFDbEIsQ0FBQztJQUNELElBQUksQ0FBQ2dELE9BQU8sRUFBRSxPQUFPekUsUUFBUSxDQUFDMEQsUUFBUSxDQUFDO01BQUVoRCxJQUFJLEVBQUU7UUFBRXpCLE9BQU8sRUFBRTtNQUFpQjtJQUFFLENBQUMsQ0FBQztJQUMvRSxPQUFPZSxRQUFRLENBQUNqQixFQUFFLENBQUM7TUFBRTJCLElBQUksRUFBRStEO0lBQVEsQ0FBQyxDQUFDO0VBQ3ZDLENBQUMsQ0FDSCxDQUFDOztFQUVEO0VBQ0E5RSxNQUFNLENBQUNxQixHQUFHLENBQ1I7SUFDRVQsSUFBSSxFQUFHLEdBQUVVLDhCQUFvQixvQkFBbUI7SUFDaERDLFFBQVEsRUFBRSxLQUFLO0lBQ2ZDLE9BQU8sRUFBRXJEO0VBQ1gsQ0FBQyxFQUNEK0IsUUFBUSxDQUFDLE1BQU0sRUFBRSxPQUFPdUIsSUFBSSxFQUFFb0UsUUFBUSxFQUFFeEYsUUFBUSxFQUFFN0IsTUFBTSxLQUFLO0lBQzNELE1BQU1zSCxPQUFPLEdBQUcsTUFBTXBDLHlCQUFXLENBQUNxQyxtQkFBbUIsQ0FBQ3ZILE1BQU0sQ0FBQztJQUM3RCxPQUFPNkIsUUFBUSxDQUFDakIsRUFBRSxDQUFDO01BQUUyQixJQUFJLEVBQUUrRTtJQUFRLENBQUMsQ0FBQztFQUN2QyxDQUFDLENBQ0gsQ0FBQzs7RUFFRDtFQUNBOUYsTUFBTSxDQUFDZ0UsSUFBSSxDQUNUO0lBQ0VwRCxJQUFJLEVBQUcsR0FBRVUsOEJBQW9CLGdCQUFlO0lBQzVDQyxRQUFRLEVBQUU7TUFBRVIsSUFBSSxFQUFFb0Isb0JBQU0sQ0FBQ0MsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFO1FBQUVvQixRQUFRLEVBQUU7TUFBUSxDQUFDO0lBQUUsQ0FBQztJQUM1RGhDLE9BQU8sRUFBRW5EO0VBQ1gsQ0FBQyxFQUNENkIsUUFBUSxDQUFDLE9BQU8sRUFBRSxPQUFPdUIsSUFBSSxFQUFFaEQsT0FBTyxFQUFFNEIsUUFBUSxFQUFFN0IsTUFBTSxFQUFFZSxHQUFHLEtBQUs7SUFDaEUsTUFBTWlGLE9BQU8sR0FBRyxNQUFNZCx5QkFBVyxDQUFDc0Msb0JBQW9CLENBQ3BEeEgsTUFBTSxFQUNOQyxPQUFPLENBQUNzQyxJQUFJLEVBQ1gsT0FBTXhCLEdBQUcsQ0FBQ3VDLElBQUssRUFDbEIsQ0FBQztJQUNELE9BQU96QixRQUFRLENBQUNqQixFQUFFLENBQUM7TUFBRTJCLElBQUksRUFBRTtRQUFFa0UsT0FBTyxFQUFFLElBQUk7UUFBRUUsSUFBSSxFQUFFWDtNQUFRO0lBQUUsQ0FBQyxDQUFDO0VBQ2hFLENBQUMsQ0FDSCxDQUFDO0VBRUR2RSxNQUFNLENBQUN5RSxJQUFJLENBQUMsc0NBQXNDLENBQUM7QUFDckQifQ==