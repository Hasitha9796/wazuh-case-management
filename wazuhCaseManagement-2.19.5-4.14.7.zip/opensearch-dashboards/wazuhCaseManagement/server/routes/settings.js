"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.registerSettingsRoutes = registerSettingsRoutes;
var _configSchema = require("@osd/config-schema");
var _settings_service = require("../services/settings_service");
var _notification_service = require("../services/notification_service");
var _users = require("./users");
var _types = require("../../common/types");
/*
 * Wazuh Case Management Plugin
 * Settings Routes: plugin configuration and API key management
 */

// ─── Validation schemas ─────────────────────────────────────────
const caseIdSchema = _configSchema.schema.object({
  prefix: _configSchema.schema.string({
    maxLength: 16
  }),
  separator: _configSchema.schema.string({
    maxLength: 3
  }),
  include_year: _configSchema.schema.boolean(),
  padding: _configSchema.schema.number({
    min: 1,
    max: 10
  })
});
const timestampSchema = _configSchema.schema.object({
  clock: _configSchema.schema.oneOf([_configSchema.schema.literal('24h'), _configSchema.schema.literal('12h')]),
  show_seconds: _configSchema.schema.boolean(),
  timezone: _configSchema.schema.string()
});
const channelAuthSchema = _configSchema.schema.object({
  type: _configSchema.schema.oneOf([_configSchema.schema.literal('none'), _configSchema.schema.literal('bearer'), _configSchema.schema.literal('basic'), _configSchema.schema.literal('api_key')]),
  token: _configSchema.schema.maybe(_configSchema.schema.string()),
  username: _configSchema.schema.maybe(_configSchema.schema.string()),
  password: _configSchema.schema.maybe(_configSchema.schema.string()),
  header_name: _configSchema.schema.maybe(_configSchema.schema.string()),
  header_value: _configSchema.schema.maybe(_configSchema.schema.string())
});
const notificationChannelSchema = _configSchema.schema.object({
  id: _configSchema.schema.string(),
  name: _configSchema.schema.string(),
  type: _configSchema.schema.oneOf([_configSchema.schema.literal('webhook'), _configSchema.schema.literal('slack'), _configSchema.schema.literal('teams'), _configSchema.schema.literal('email')]),
  url: _configSchema.schema.string({
    defaultValue: ''
  }),
  enabled: _configSchema.schema.boolean(),
  events: _configSchema.schema.arrayOf(_configSchema.schema.string()),
  recipients: _configSchema.schema.maybe(_configSchema.schema.arrayOf(_configSchema.schema.string())),
  recipient_mode: _configSchema.schema.maybe(_configSchema.schema.oneOf([_configSchema.schema.literal('to'), _configSchema.schema.literal('bcc')])),
  auth: _configSchema.schema.maybe(channelAuthSchema),
  headers: _configSchema.schema.maybe(_configSchema.schema.recordOf(_configSchema.schema.string(), _configSchema.schema.string())),
  verify_tls: _configSchema.schema.maybe(_configSchema.schema.boolean())
});
const smtpSchema = _configSchema.schema.object({
  enabled: _configSchema.schema.boolean(),
  host: _configSchema.schema.string({
    defaultValue: ''
  }),
  port: _configSchema.schema.number({
    min: 1,
    max: 65535,
    defaultValue: 587
  }),
  security: _configSchema.schema.oneOf([_configSchema.schema.literal('none'), _configSchema.schema.literal('starttls'), _configSchema.schema.literal('tls')]),
  auth_type: _configSchema.schema.oneOf([_configSchema.schema.literal('auto'), _configSchema.schema.literal('none'), _configSchema.schema.literal('plain'), _configSchema.schema.literal('login'), _configSchema.schema.literal('cram-md5')]),
  username: _configSchema.schema.string({
    defaultValue: ''
  }),
  password: _configSchema.schema.string({
    defaultValue: ''
  }),
  from_address: _configSchema.schema.string({
    defaultValue: ''
  }),
  from_name: _configSchema.schema.string({
    defaultValue: ''
  }),
  reject_unauthorized: _configSchema.schema.boolean({
    defaultValue: true
  }),
  timeout_ms: _configSchema.schema.number({
    min: 1000,
    max: 120000,
    defaultValue: 15000
  })
});
const notificationsSchema = _configSchema.schema.object({
  in_app_enabled: _configSchema.schema.boolean(),
  in_app_events: _configSchema.schema.arrayOf(_configSchema.schema.string()),
  channels: _configSchema.schema.arrayOf(notificationChannelSchema)
});
const escalationStepSchema = _configSchema.schema.object({
  after_minutes: _configSchema.schema.number({
    min: 1
  }),
  action: _configSchema.schema.string(),
  target: _configSchema.schema.maybe(_configSchema.schema.string())
});
const escalationPolicySchema = _configSchema.schema.object({
  id: _configSchema.schema.string(),
  name: _configSchema.schema.string(),
  enabled: _configSchema.schema.boolean(),
  order: _configSchema.schema.number(),
  match: _configSchema.schema.object({
    priorities: _configSchema.schema.arrayOf(_configSchema.schema.string()),
    severities: _configSchema.schema.arrayOf(_configSchema.schema.string()),
    categories: _configSchema.schema.arrayOf(_configSchema.schema.string()),
    statuses: _configSchema.schema.arrayOf(_configSchema.schema.string()),
    tags: _configSchema.schema.arrayOf(_configSchema.schema.string())
  }),
  base: _configSchema.schema.oneOf([_configSchema.schema.literal('created_at'), _configSchema.schema.literal('updated_at')]),
  steps: _configSchema.schema.arrayOf(escalationStepSchema)
});
const escalationSchema = _configSchema.schema.object({
  enabled: _configSchema.schema.boolean(),
  policies: _configSchema.schema.arrayOf(escalationPolicySchema)
});
function registerSettingsRoutes(router, logger) {
  // ─── GET SETTINGS ───────────────────────────────────────────
  router.get({
    path: '/api/wazuh-case-management/settings',
    validate: false
  }, async (context, _request, response) => {
    try {
      const client = context.core.opensearch.client.asCurrentUser;
      const settings = await _settings_service.SettingsService.getSettings(client);
      return response.ok({
        body: _settings_service.SettingsService.toPublic(settings)
      });
    } catch (error) {
      logger.error(`Error reading settings: ${error.message}`);
      return response.customError({
        statusCode: 500,
        body: {
          message: error.message
        }
      });
    }
  });

  // ─── UPDATE SETTINGS ────────────────────────────────────────
  router.put({
    path: '/api/wazuh-case-management/settings',
    validate: {
      body: _configSchema.schema.object({
        case_id: _configSchema.schema.maybe(caseIdSchema),
        theme: _configSchema.schema.maybe(_configSchema.schema.oneOf([_configSchema.schema.literal('auto'), _configSchema.schema.literal('light'), _configSchema.schema.literal('dark')])),
        timestamp: _configSchema.schema.maybe(timestampSchema),
        notifications: _configSchema.schema.maybe(notificationsSchema),
        escalation: _configSchema.schema.maybe(escalationSchema),
        smtp: _configSchema.schema.maybe(smtpSchema),
        base_url: _configSchema.schema.maybe(_configSchema.schema.string())
      })
    }
  }, async (context, request, response) => {
    try {
      const client = context.core.opensearch.client.asCurrentUser;
      const user = await (0, _users.getCurrentUsername)(client);
      const saved = await _settings_service.SettingsService.saveSettings(client, request.body, user);
      logger.info(`Settings updated by ${user}`);
      return response.ok({
        body: _settings_service.SettingsService.toPublic(saved)
      });
    } catch (error) {
      logger.error(`Error saving settings: ${error.message}`);
      return response.customError({
        statusCode: 500,
        body: {
          message: error.message
        }
      });
    }
  });

  // ─── TEST A NOTIFICATION CHANNEL ────────────────────────────
  router.post({
    path: '/api/wazuh-case-management/settings/notifications/test',
    validate: {
      body: _configSchema.schema.object({
        channel: notificationChannelSchema
      })
    }
  }, async (context, request, response) => {
    try {
      const client = context.core.opensearch.client.asCurrentUser;
      // The UI never holds real secrets, so swap the placeholders back in.
      const channel = await _settings_service.SettingsService.resolveChannelSecrets(client, request.body.channel);
      const settings = await _settings_service.SettingsService.getSettings(client);
      const result = await _notification_service.NotificationService.testChannel(channel, settings);
      logger.info(`Notification channel "${channel.name}" test -> ${result.ok ? 'ok' : 'failed'} (${result.status})`);
      return response.ok({
        body: result
      });
    } catch (error) {
      logger.error(`Channel test failed: ${error.message}`);
      return response.customError({
        statusCode: 500,
        body: {
          message: error.message
        }
      });
    }
  });

  // ─── SEND A TEST EMAIL ──────────────────────────────────────
  router.post({
    path: '/api/wazuh-case-management/settings/smtp/test',
    validate: {
      body: _configSchema.schema.object({
        recipient: _configSchema.schema.string({
          minLength: 3
        }),
        // Unsaved edits can be tested directly; omit to use what is stored.
        smtp: _configSchema.schema.maybe(smtpSchema)
      })
    }
  }, async (context, request, response) => {
    try {
      const client = context.core.opensearch.client.asCurrentUser;
      const stored = await _settings_service.SettingsService.getSettings(client);
      const smtp = request.body.smtp ? {
        ...request.body.smtp,
        password: request.body.smtp.password === _types.SECRET_PLACEHOLDER ? stored.smtp.password : request.body.smtp.password
      } : stored.smtp;

      // A test should work before the operator has flipped the enable switch.
      const settings = {
        ...stored,
        smtp: {
          ...smtp,
          enabled: true
        }
      };
      const result = await _notification_service.NotificationService.testSmtp(settings, request.body.recipient);
      logger.info(`SMTP test to ${request.body.recipient}: ${result.ok ? 'delivered' : `failed (${result.error})`}`);
      return response.ok({
        body: result
      });
    } catch (error) {
      logger.error(`SMTP test failed: ${error.message}`);
      return response.customError({
        statusCode: 500,
        body: {
          message: error.message
        }
      });
    }
  });

  // ─── LIST API KEYS ──────────────────────────────────────────
  router.get({
    path: '/api/wazuh-case-management/settings/api-keys',
    validate: false
  }, async (context, _request, response) => {
    try {
      const client = context.core.opensearch.client.asCurrentUser;
      const settings = await _settings_service.SettingsService.getSettings(client);
      return response.ok({
        body: {
          keys: _settings_service.SettingsService.toPublic(settings).api_keys
        }
      });
    } catch (error) {
      return response.customError({
        statusCode: 500,
        body: {
          message: error.message
        }
      });
    }
  });

  // ─── CREATE API KEY ─────────────────────────────────────────
  router.post({
    path: '/api/wazuh-case-management/settings/api-keys',
    validate: {
      body: _configSchema.schema.object({
        name: _configSchema.schema.string({
          minLength: 1,
          maxLength: 64
        }),
        scopes: _configSchema.schema.arrayOf(_configSchema.schema.oneOf([_configSchema.schema.literal('read'), _configSchema.schema.literal('write')]), {
          defaultValue: ['read']
        }),
        expires_at: _configSchema.schema.maybe(_configSchema.schema.nullable(_configSchema.schema.string()))
      })
    }
  }, async (context, request, response) => {
    try {
      const client = context.core.opensearch.client.asCurrentUser;
      const user = await (0, _users.getCurrentUsername)(client);
      const created = await _settings_service.SettingsService.createApiKey(client, request.body, user);
      logger.info(`API key "${request.body.name}" created by ${user}`);
      // `secret` is returned exactly once: it is stored only as a SHA-256 hash.
      return response.ok({
        body: created
      });
    } catch (error) {
      logger.error(`Error creating API key: ${error.message}`);
      return response.customError({
        statusCode: 500,
        body: {
          message: error.message
        }
      });
    }
  });

  // ─── ENABLE / DISABLE API KEY ───────────────────────────────
  router.patch({
    path: '/api/wazuh-case-management/settings/api-keys/{keyId}',
    validate: {
      params: _configSchema.schema.object({
        keyId: _configSchema.schema.string()
      }),
      body: _configSchema.schema.object({
        enabled: _configSchema.schema.boolean()
      })
    }
  }, async (context, request, response) => {
    try {
      const client = context.core.opensearch.client.asCurrentUser;
      const ok = await _settings_service.SettingsService.setApiKeyEnabled(client, request.params.keyId, request.body.enabled);
      if (!ok) return response.notFound({
        body: {
          message: 'API key not found'
        }
      });
      return response.ok({
        body: {
          success: true
        }
      });
    } catch (error) {
      return response.customError({
        statusCode: 500,
        body: {
          message: error.message
        }
      });
    }
  });

  // ─── REVOKE API KEY ─────────────────────────────────────────
  router.delete({
    path: '/api/wazuh-case-management/settings/api-keys/{keyId}',
    validate: {
      params: _configSchema.schema.object({
        keyId: _configSchema.schema.string()
      })
    }
  }, async (context, request, response) => {
    try {
      const client = context.core.opensearch.client.asCurrentUser;
      const user = await (0, _users.getCurrentUsername)(client);
      const ok = await _settings_service.SettingsService.deleteApiKey(client, request.params.keyId);
      if (!ok) return response.notFound({
        body: {
          message: 'API key not found'
        }
      });
      logger.info(`API key ${request.params.keyId} revoked by ${user}`);
      return response.ok({
        body: {
          success: true
        }
      });
    } catch (error) {
      return response.customError({
        statusCode: 500,
        body: {
          message: error.message
        }
      });
    }
  });
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfY29uZmlnU2NoZW1hIiwicmVxdWlyZSIsIl9zZXR0aW5nc19zZXJ2aWNlIiwiX25vdGlmaWNhdGlvbl9zZXJ2aWNlIiwiX3VzZXJzIiwiX3R5cGVzIiwiY2FzZUlkU2NoZW1hIiwic2NoZW1hIiwib2JqZWN0IiwicHJlZml4Iiwic3RyaW5nIiwibWF4TGVuZ3RoIiwic2VwYXJhdG9yIiwiaW5jbHVkZV95ZWFyIiwiYm9vbGVhbiIsInBhZGRpbmciLCJudW1iZXIiLCJtaW4iLCJtYXgiLCJ0aW1lc3RhbXBTY2hlbWEiLCJjbG9jayIsIm9uZU9mIiwibGl0ZXJhbCIsInNob3dfc2Vjb25kcyIsInRpbWV6b25lIiwiY2hhbm5lbEF1dGhTY2hlbWEiLCJ0eXBlIiwidG9rZW4iLCJtYXliZSIsInVzZXJuYW1lIiwicGFzc3dvcmQiLCJoZWFkZXJfbmFtZSIsImhlYWRlcl92YWx1ZSIsIm5vdGlmaWNhdGlvbkNoYW5uZWxTY2hlbWEiLCJpZCIsIm5hbWUiLCJ1cmwiLCJkZWZhdWx0VmFsdWUiLCJlbmFibGVkIiwiZXZlbnRzIiwiYXJyYXlPZiIsInJlY2lwaWVudHMiLCJyZWNpcGllbnRfbW9kZSIsImF1dGgiLCJoZWFkZXJzIiwicmVjb3JkT2YiLCJ2ZXJpZnlfdGxzIiwic210cFNjaGVtYSIsImhvc3QiLCJwb3J0Iiwic2VjdXJpdHkiLCJhdXRoX3R5cGUiLCJmcm9tX2FkZHJlc3MiLCJmcm9tX25hbWUiLCJyZWplY3RfdW5hdXRob3JpemVkIiwidGltZW91dF9tcyIsIm5vdGlmaWNhdGlvbnNTY2hlbWEiLCJpbl9hcHBfZW5hYmxlZCIsImluX2FwcF9ldmVudHMiLCJjaGFubmVscyIsImVzY2FsYXRpb25TdGVwU2NoZW1hIiwiYWZ0ZXJfbWludXRlcyIsImFjdGlvbiIsInRhcmdldCIsImVzY2FsYXRpb25Qb2xpY3lTY2hlbWEiLCJvcmRlciIsIm1hdGNoIiwicHJpb3JpdGllcyIsInNldmVyaXRpZXMiLCJjYXRlZ29yaWVzIiwic3RhdHVzZXMiLCJ0YWdzIiwiYmFzZSIsInN0ZXBzIiwiZXNjYWxhdGlvblNjaGVtYSIsInBvbGljaWVzIiwicmVnaXN0ZXJTZXR0aW5nc1JvdXRlcyIsInJvdXRlciIsImxvZ2dlciIsImdldCIsInBhdGgiLCJ2YWxpZGF0ZSIsImNvbnRleHQiLCJfcmVxdWVzdCIsInJlc3BvbnNlIiwiY2xpZW50IiwiY29yZSIsIm9wZW5zZWFyY2giLCJhc0N1cnJlbnRVc2VyIiwic2V0dGluZ3MiLCJTZXR0aW5nc1NlcnZpY2UiLCJnZXRTZXR0aW5ncyIsIm9rIiwiYm9keSIsInRvUHVibGljIiwiZXJyb3IiLCJtZXNzYWdlIiwiY3VzdG9tRXJyb3IiLCJzdGF0dXNDb2RlIiwicHV0IiwiY2FzZV9pZCIsInRoZW1lIiwidGltZXN0YW1wIiwibm90aWZpY2F0aW9ucyIsImVzY2FsYXRpb24iLCJzbXRwIiwiYmFzZV91cmwiLCJyZXF1ZXN0IiwidXNlciIsImdldEN1cnJlbnRVc2VybmFtZSIsInNhdmVkIiwic2F2ZVNldHRpbmdzIiwiaW5mbyIsInBvc3QiLCJjaGFubmVsIiwicmVzb2x2ZUNoYW5uZWxTZWNyZXRzIiwicmVzdWx0IiwiTm90aWZpY2F0aW9uU2VydmljZSIsInRlc3RDaGFubmVsIiwic3RhdHVzIiwicmVjaXBpZW50IiwibWluTGVuZ3RoIiwic3RvcmVkIiwiU0VDUkVUX1BMQUNFSE9MREVSIiwidGVzdFNtdHAiLCJrZXlzIiwiYXBpX2tleXMiLCJzY29wZXMiLCJleHBpcmVzX2F0IiwibnVsbGFibGUiLCJjcmVhdGVkIiwiY3JlYXRlQXBpS2V5IiwicGF0Y2giLCJwYXJhbXMiLCJrZXlJZCIsInNldEFwaUtleUVuYWJsZWQiLCJub3RGb3VuZCIsInN1Y2Nlc3MiLCJkZWxldGUiLCJkZWxldGVBcGlLZXkiXSwic291cmNlcyI6WyJzZXR0aW5ncy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogV2F6dWggQ2FzZSBNYW5hZ2VtZW50IFBsdWdpblxuICogU2V0dGluZ3MgUm91dGVzOiBwbHVnaW4gY29uZmlndXJhdGlvbiBhbmQgQVBJIGtleSBtYW5hZ2VtZW50XG4gKi9cblxuaW1wb3J0IHsgSVJvdXRlciwgTG9nZ2VyIH0gZnJvbSAnLi4vLi4vLi4vLi4vc3JjL2NvcmUvc2VydmVyJztcbmltcG9ydCB7IHNjaGVtYSB9IGZyb20gJ0Bvc2QvY29uZmlnLXNjaGVtYSc7XG5pbXBvcnQgeyBTZXR0aW5nc1NlcnZpY2UgfSBmcm9tICcuLi9zZXJ2aWNlcy9zZXR0aW5nc19zZXJ2aWNlJztcbmltcG9ydCB7IE5vdGlmaWNhdGlvblNlcnZpY2UgfSBmcm9tICcuLi9zZXJ2aWNlcy9ub3RpZmljYXRpb25fc2VydmljZSc7XG5pbXBvcnQgeyBnZXRDdXJyZW50VXNlcm5hbWUgfSBmcm9tICcuL3VzZXJzJztcbmltcG9ydCB7IFNFQ1JFVF9QTEFDRUhPTERFUiB9IGZyb20gJy4uLy4uL2NvbW1vbi90eXBlcyc7XG5cbi8vIOKUgOKUgOKUgCBWYWxpZGF0aW9uIHNjaGVtYXMg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5jb25zdCBjYXNlSWRTY2hlbWEgPSBzY2hlbWEub2JqZWN0KHtcbiAgcHJlZml4OiBzY2hlbWEuc3RyaW5nKHsgbWF4TGVuZ3RoOiAxNiB9KSxcbiAgc2VwYXJhdG9yOiBzY2hlbWEuc3RyaW5nKHsgbWF4TGVuZ3RoOiAzIH0pLFxuICBpbmNsdWRlX3llYXI6IHNjaGVtYS5ib29sZWFuKCksXG4gIHBhZGRpbmc6IHNjaGVtYS5udW1iZXIoeyBtaW46IDEsIG1heDogMTAgfSksXG59KTtcblxuY29uc3QgdGltZXN0YW1wU2NoZW1hID0gc2NoZW1hLm9iamVjdCh7XG4gIGNsb2NrOiBzY2hlbWEub25lT2YoW3NjaGVtYS5saXRlcmFsKCcyNGgnKSwgc2NoZW1hLmxpdGVyYWwoJzEyaCcpXSksXG4gIHNob3dfc2Vjb25kczogc2NoZW1hLmJvb2xlYW4oKSxcbiAgdGltZXpvbmU6IHNjaGVtYS5zdHJpbmcoKSxcbn0pO1xuXG5jb25zdCBjaGFubmVsQXV0aFNjaGVtYSA9IHNjaGVtYS5vYmplY3Qoe1xuICB0eXBlOiBzY2hlbWEub25lT2YoW1xuICAgIHNjaGVtYS5saXRlcmFsKCdub25lJyksXG4gICAgc2NoZW1hLmxpdGVyYWwoJ2JlYXJlcicpLFxuICAgIHNjaGVtYS5saXRlcmFsKCdiYXNpYycpLFxuICAgIHNjaGVtYS5saXRlcmFsKCdhcGlfa2V5JyksXG4gIF0pLFxuICB0b2tlbjogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXG4gIHVzZXJuYW1lOiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcbiAgcGFzc3dvcmQ6IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICBoZWFkZXJfbmFtZTogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXG4gIGhlYWRlcl92YWx1ZTogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXG59KTtcblxuY29uc3Qgbm90aWZpY2F0aW9uQ2hhbm5lbFNjaGVtYSA9IHNjaGVtYS5vYmplY3Qoe1xuICBpZDogc2NoZW1hLnN0cmluZygpLFxuICBuYW1lOiBzY2hlbWEuc3RyaW5nKCksXG4gIHR5cGU6IHNjaGVtYS5vbmVPZihbXG4gICAgc2NoZW1hLmxpdGVyYWwoJ3dlYmhvb2snKSxcbiAgICBzY2hlbWEubGl0ZXJhbCgnc2xhY2snKSxcbiAgICBzY2hlbWEubGl0ZXJhbCgndGVhbXMnKSxcbiAgICBzY2hlbWEubGl0ZXJhbCgnZW1haWwnKSxcbiAgXSksXG4gIHVybDogc2NoZW1hLnN0cmluZyh7IGRlZmF1bHRWYWx1ZTogJycgfSksXG4gIGVuYWJsZWQ6IHNjaGVtYS5ib29sZWFuKCksXG4gIGV2ZW50czogc2NoZW1hLmFycmF5T2Yoc2NoZW1hLnN0cmluZygpKSxcbiAgcmVjaXBpZW50czogc2NoZW1hLm1heWJlKHNjaGVtYS5hcnJheU9mKHNjaGVtYS5zdHJpbmcoKSkpLFxuICByZWNpcGllbnRfbW9kZTogc2NoZW1hLm1heWJlKHNjaGVtYS5vbmVPZihbc2NoZW1hLmxpdGVyYWwoJ3RvJyksIHNjaGVtYS5saXRlcmFsKCdiY2MnKV0pKSxcbiAgYXV0aDogc2NoZW1hLm1heWJlKGNoYW5uZWxBdXRoU2NoZW1hKSxcbiAgaGVhZGVyczogc2NoZW1hLm1heWJlKHNjaGVtYS5yZWNvcmRPZihzY2hlbWEuc3RyaW5nKCksIHNjaGVtYS5zdHJpbmcoKSkpLFxuICB2ZXJpZnlfdGxzOiBzY2hlbWEubWF5YmUoc2NoZW1hLmJvb2xlYW4oKSksXG59KTtcblxuY29uc3Qgc210cFNjaGVtYSA9IHNjaGVtYS5vYmplY3Qoe1xuICBlbmFibGVkOiBzY2hlbWEuYm9vbGVhbigpLFxuICBob3N0OiBzY2hlbWEuc3RyaW5nKHsgZGVmYXVsdFZhbHVlOiAnJyB9KSxcbiAgcG9ydDogc2NoZW1hLm51bWJlcih7IG1pbjogMSwgbWF4OiA2NTUzNSwgZGVmYXVsdFZhbHVlOiA1ODcgfSksXG4gIHNlY3VyaXR5OiBzY2hlbWEub25lT2YoW1xuICAgIHNjaGVtYS5saXRlcmFsKCdub25lJyksXG4gICAgc2NoZW1hLmxpdGVyYWwoJ3N0YXJ0dGxzJyksXG4gICAgc2NoZW1hLmxpdGVyYWwoJ3RscycpLFxuICBdKSxcbiAgYXV0aF90eXBlOiBzY2hlbWEub25lT2YoW1xuICAgIHNjaGVtYS5saXRlcmFsKCdhdXRvJyksXG4gICAgc2NoZW1hLmxpdGVyYWwoJ25vbmUnKSxcbiAgICBzY2hlbWEubGl0ZXJhbCgncGxhaW4nKSxcbiAgICBzY2hlbWEubGl0ZXJhbCgnbG9naW4nKSxcbiAgICBzY2hlbWEubGl0ZXJhbCgnY3JhbS1tZDUnKSxcbiAgXSksXG4gIHVzZXJuYW1lOiBzY2hlbWEuc3RyaW5nKHsgZGVmYXVsdFZhbHVlOiAnJyB9KSxcbiAgcGFzc3dvcmQ6IHNjaGVtYS5zdHJpbmcoeyBkZWZhdWx0VmFsdWU6ICcnIH0pLFxuICBmcm9tX2FkZHJlc3M6IHNjaGVtYS5zdHJpbmcoeyBkZWZhdWx0VmFsdWU6ICcnIH0pLFxuICBmcm9tX25hbWU6IHNjaGVtYS5zdHJpbmcoeyBkZWZhdWx0VmFsdWU6ICcnIH0pLFxuICByZWplY3RfdW5hdXRob3JpemVkOiBzY2hlbWEuYm9vbGVhbih7IGRlZmF1bHRWYWx1ZTogdHJ1ZSB9KSxcbiAgdGltZW91dF9tczogc2NoZW1hLm51bWJlcih7IG1pbjogMTAwMCwgbWF4OiAxMjAwMDAsIGRlZmF1bHRWYWx1ZTogMTUwMDAgfSksXG59KTtcblxuY29uc3Qgbm90aWZpY2F0aW9uc1NjaGVtYSA9IHNjaGVtYS5vYmplY3Qoe1xuICBpbl9hcHBfZW5hYmxlZDogc2NoZW1hLmJvb2xlYW4oKSxcbiAgaW5fYXBwX2V2ZW50czogc2NoZW1hLmFycmF5T2Yoc2NoZW1hLnN0cmluZygpKSxcbiAgY2hhbm5lbHM6IHNjaGVtYS5hcnJheU9mKG5vdGlmaWNhdGlvbkNoYW5uZWxTY2hlbWEpLFxufSk7XG5cbmNvbnN0IGVzY2FsYXRpb25TdGVwU2NoZW1hID0gc2NoZW1hLm9iamVjdCh7XG4gIGFmdGVyX21pbnV0ZXM6IHNjaGVtYS5udW1iZXIoeyBtaW46IDEgfSksXG4gIGFjdGlvbjogc2NoZW1hLnN0cmluZygpLFxuICB0YXJnZXQ6IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxufSk7XG5cbmNvbnN0IGVzY2FsYXRpb25Qb2xpY3lTY2hlbWEgPSBzY2hlbWEub2JqZWN0KHtcbiAgaWQ6IHNjaGVtYS5zdHJpbmcoKSxcbiAgbmFtZTogc2NoZW1hLnN0cmluZygpLFxuICBlbmFibGVkOiBzY2hlbWEuYm9vbGVhbigpLFxuICBvcmRlcjogc2NoZW1hLm51bWJlcigpLFxuICBtYXRjaDogc2NoZW1hLm9iamVjdCh7XG4gICAgcHJpb3JpdGllczogc2NoZW1hLmFycmF5T2Yoc2NoZW1hLnN0cmluZygpKSxcbiAgICBzZXZlcml0aWVzOiBzY2hlbWEuYXJyYXlPZihzY2hlbWEuc3RyaW5nKCkpLFxuICAgIGNhdGVnb3JpZXM6IHNjaGVtYS5hcnJheU9mKHNjaGVtYS5zdHJpbmcoKSksXG4gICAgc3RhdHVzZXM6IHNjaGVtYS5hcnJheU9mKHNjaGVtYS5zdHJpbmcoKSksXG4gICAgdGFnczogc2NoZW1hLmFycmF5T2Yoc2NoZW1hLnN0cmluZygpKSxcbiAgfSksXG4gIGJhc2U6IHNjaGVtYS5vbmVPZihbc2NoZW1hLmxpdGVyYWwoJ2NyZWF0ZWRfYXQnKSwgc2NoZW1hLmxpdGVyYWwoJ3VwZGF0ZWRfYXQnKV0pLFxuICBzdGVwczogc2NoZW1hLmFycmF5T2YoZXNjYWxhdGlvblN0ZXBTY2hlbWEpLFxufSk7XG5cbmNvbnN0IGVzY2FsYXRpb25TY2hlbWEgPSBzY2hlbWEub2JqZWN0KHtcbiAgZW5hYmxlZDogc2NoZW1hLmJvb2xlYW4oKSxcbiAgcG9saWNpZXM6IHNjaGVtYS5hcnJheU9mKGVzY2FsYXRpb25Qb2xpY3lTY2hlbWEpLFxufSk7XG5cbmV4cG9ydCBmdW5jdGlvbiByZWdpc3RlclNldHRpbmdzUm91dGVzKHJvdXRlcjogSVJvdXRlciwgbG9nZ2VyOiBMb2dnZXIpOiB2b2lkIHtcbiAgLy8g4pSA4pSA4pSAIEdFVCBTRVRUSU5HUyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgcm91dGVyLmdldChcbiAgICB7IHBhdGg6ICcvYXBpL3dhenVoLWNhc2UtbWFuYWdlbWVudC9zZXR0aW5ncycsIHZhbGlkYXRlOiBmYWxzZSB9LFxuICAgIGFzeW5jIChjb250ZXh0LCBfcmVxdWVzdCwgcmVzcG9uc2UpID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGNsaWVudCA9IGNvbnRleHQuY29yZS5vcGVuc2VhcmNoLmNsaWVudC5hc0N1cnJlbnRVc2VyO1xuICAgICAgICBjb25zdCBzZXR0aW5ncyA9IGF3YWl0IFNldHRpbmdzU2VydmljZS5nZXRTZXR0aW5ncyhjbGllbnQpO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2Uub2soeyBib2R5OiBTZXR0aW5nc1NlcnZpY2UudG9QdWJsaWMoc2V0dGluZ3MpIH0pO1xuICAgICAgfSBjYXRjaCAoZXJyb3I6IGFueSkge1xuICAgICAgICBsb2dnZXIuZXJyb3IoYEVycm9yIHJlYWRpbmcgc2V0dGluZ3M6ICR7ZXJyb3IubWVzc2FnZX1gKTtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmN1c3RvbUVycm9yKHsgc3RhdHVzQ29kZTogNTAwLCBib2R5OiB7IG1lc3NhZ2U6IGVycm9yLm1lc3NhZ2UgfSB9KTtcbiAgICAgIH1cbiAgICB9LFxuICApO1xuXG4gIC8vIOKUgOKUgOKUgCBVUERBVEUgU0VUVElOR1Mg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gIHJvdXRlci5wdXQoXG4gICAge1xuICAgICAgcGF0aDogJy9hcGkvd2F6dWgtY2FzZS1tYW5hZ2VtZW50L3NldHRpbmdzJyxcbiAgICAgIHZhbGlkYXRlOiB7XG4gICAgICAgIGJvZHk6IHNjaGVtYS5vYmplY3Qoe1xuICAgICAgICAgIGNhc2VfaWQ6IHNjaGVtYS5tYXliZShjYXNlSWRTY2hlbWEpLFxuICAgICAgICAgIHRoZW1lOiBzY2hlbWEubWF5YmUoXG4gICAgICAgICAgICBzY2hlbWEub25lT2YoW3NjaGVtYS5saXRlcmFsKCdhdXRvJyksIHNjaGVtYS5saXRlcmFsKCdsaWdodCcpLCBzY2hlbWEubGl0ZXJhbCgnZGFyaycpXSksXG4gICAgICAgICAgKSxcbiAgICAgICAgICB0aW1lc3RhbXA6IHNjaGVtYS5tYXliZSh0aW1lc3RhbXBTY2hlbWEpLFxuICAgICAgICAgIG5vdGlmaWNhdGlvbnM6IHNjaGVtYS5tYXliZShub3RpZmljYXRpb25zU2NoZW1hKSxcbiAgICAgICAgICBlc2NhbGF0aW9uOiBzY2hlbWEubWF5YmUoZXNjYWxhdGlvblNjaGVtYSksXG4gICAgICAgICAgc210cDogc2NoZW1hLm1heWJlKHNtdHBTY2hlbWEpLFxuICAgICAgICAgIGJhc2VfdXJsOiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcXVlc3QsIHJlc3BvbnNlKSA9PiB7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBjbGllbnQgPSBjb250ZXh0LmNvcmUub3BlbnNlYXJjaC5jbGllbnQuYXNDdXJyZW50VXNlcjtcbiAgICAgICAgY29uc3QgdXNlciA9IGF3YWl0IGdldEN1cnJlbnRVc2VybmFtZShjbGllbnQpO1xuICAgICAgICBjb25zdCBzYXZlZCA9IGF3YWl0IFNldHRpbmdzU2VydmljZS5zYXZlU2V0dGluZ3MoY2xpZW50LCByZXF1ZXN0LmJvZHkgYXMgYW55LCB1c2VyKTtcbiAgICAgICAgbG9nZ2VyLmluZm8oYFNldHRpbmdzIHVwZGF0ZWQgYnkgJHt1c2VyfWApO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2Uub2soeyBib2R5OiBTZXR0aW5nc1NlcnZpY2UudG9QdWJsaWMoc2F2ZWQpIH0pO1xuICAgICAgfSBjYXRjaCAoZXJyb3I6IGFueSkge1xuICAgICAgICBsb2dnZXIuZXJyb3IoYEVycm9yIHNhdmluZyBzZXR0aW5nczogJHtlcnJvci5tZXNzYWdlfWApO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2UuY3VzdG9tRXJyb3IoeyBzdGF0dXNDb2RlOiA1MDAsIGJvZHk6IHsgbWVzc2FnZTogZXJyb3IubWVzc2FnZSB9IH0pO1xuICAgICAgfVxuICAgIH0sXG4gICk7XG5cbiAgLy8g4pSA4pSA4pSAIFRFU1QgQSBOT1RJRklDQVRJT04gQ0hBTk5FTCDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgcm91dGVyLnBvc3QoXG4gICAge1xuICAgICAgcGF0aDogJy9hcGkvd2F6dWgtY2FzZS1tYW5hZ2VtZW50L3NldHRpbmdzL25vdGlmaWNhdGlvbnMvdGVzdCcsXG4gICAgICB2YWxpZGF0ZTogeyBib2R5OiBzY2hlbWEub2JqZWN0KHsgY2hhbm5lbDogbm90aWZpY2F0aW9uQ2hhbm5lbFNjaGVtYSB9KSB9LFxuICAgIH0sXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcXVlc3QsIHJlc3BvbnNlKSA9PiB7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBjbGllbnQgPSBjb250ZXh0LmNvcmUub3BlbnNlYXJjaC5jbGllbnQuYXNDdXJyZW50VXNlcjtcbiAgICAgICAgLy8gVGhlIFVJIG5ldmVyIGhvbGRzIHJlYWwgc2VjcmV0cywgc28gc3dhcCB0aGUgcGxhY2Vob2xkZXJzIGJhY2sgaW4uXG4gICAgICAgIGNvbnN0IGNoYW5uZWwgPSBhd2FpdCBTZXR0aW5nc1NlcnZpY2UucmVzb2x2ZUNoYW5uZWxTZWNyZXRzKFxuICAgICAgICAgIGNsaWVudCxcbiAgICAgICAgICByZXF1ZXN0LmJvZHkuY2hhbm5lbCBhcyBhbnksXG4gICAgICAgICk7XG4gICAgICAgIGNvbnN0IHNldHRpbmdzID0gYXdhaXQgU2V0dGluZ3NTZXJ2aWNlLmdldFNldHRpbmdzKGNsaWVudCk7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IE5vdGlmaWNhdGlvblNlcnZpY2UudGVzdENoYW5uZWwoY2hhbm5lbCwgc2V0dGluZ3MpO1xuICAgICAgICBsb2dnZXIuaW5mbyhcbiAgICAgICAgICBgTm90aWZpY2F0aW9uIGNoYW5uZWwgXCIke2NoYW5uZWwubmFtZX1cIiB0ZXN0IC0+ICR7cmVzdWx0Lm9rID8gJ29rJyA6ICdmYWlsZWQnfSAoJHtyZXN1bHQuc3RhdHVzfSlgLFxuICAgICAgICApO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2Uub2soeyBib2R5OiByZXN1bHQgfSk7XG4gICAgICB9IGNhdGNoIChlcnJvcjogYW55KSB7XG4gICAgICAgIGxvZ2dlci5lcnJvcihgQ2hhbm5lbCB0ZXN0IGZhaWxlZDogJHtlcnJvci5tZXNzYWdlfWApO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2UuY3VzdG9tRXJyb3IoeyBzdGF0dXNDb2RlOiA1MDAsIGJvZHk6IHsgbWVzc2FnZTogZXJyb3IubWVzc2FnZSB9IH0pO1xuICAgICAgfVxuICAgIH0sXG4gICk7XG5cbiAgLy8g4pSA4pSA4pSAIFNFTkQgQSBURVNUIEVNQUlMIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICByb3V0ZXIucG9zdChcbiAgICB7XG4gICAgICBwYXRoOiAnL2FwaS93YXp1aC1jYXNlLW1hbmFnZW1lbnQvc2V0dGluZ3Mvc210cC90ZXN0JyxcbiAgICAgIHZhbGlkYXRlOiB7XG4gICAgICAgIGJvZHk6IHNjaGVtYS5vYmplY3Qoe1xuICAgICAgICAgIHJlY2lwaWVudDogc2NoZW1hLnN0cmluZyh7IG1pbkxlbmd0aDogMyB9KSxcbiAgICAgICAgICAvLyBVbnNhdmVkIGVkaXRzIGNhbiBiZSB0ZXN0ZWQgZGlyZWN0bHk7IG9taXQgdG8gdXNlIHdoYXQgaXMgc3RvcmVkLlxuICAgICAgICAgIHNtdHA6IHNjaGVtYS5tYXliZShzbXRwU2NoZW1hKSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcXVlc3QsIHJlc3BvbnNlKSA9PiB7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBjbGllbnQgPSBjb250ZXh0LmNvcmUub3BlbnNlYXJjaC5jbGllbnQuYXNDdXJyZW50VXNlcjtcbiAgICAgICAgY29uc3Qgc3RvcmVkID0gYXdhaXQgU2V0dGluZ3NTZXJ2aWNlLmdldFNldHRpbmdzKGNsaWVudCk7XG5cbiAgICAgICAgY29uc3Qgc210cCA9IHJlcXVlc3QuYm9keS5zbXRwXG4gICAgICAgICAgPyB7XG4gICAgICAgICAgICAgIC4uLnJlcXVlc3QuYm9keS5zbXRwLFxuICAgICAgICAgICAgICBwYXNzd29yZDpcbiAgICAgICAgICAgICAgICByZXF1ZXN0LmJvZHkuc210cC5wYXNzd29yZCA9PT0gU0VDUkVUX1BMQUNFSE9MREVSXG4gICAgICAgICAgICAgICAgICA/IHN0b3JlZC5zbXRwLnBhc3N3b3JkXG4gICAgICAgICAgICAgICAgICA6IHJlcXVlc3QuYm9keS5zbXRwLnBhc3N3b3JkLFxuICAgICAgICAgICAgfVxuICAgICAgICAgIDogc3RvcmVkLnNtdHA7XG5cbiAgICAgICAgLy8gQSB0ZXN0IHNob3VsZCB3b3JrIGJlZm9yZSB0aGUgb3BlcmF0b3IgaGFzIGZsaXBwZWQgdGhlIGVuYWJsZSBzd2l0Y2guXG4gICAgICAgIGNvbnN0IHNldHRpbmdzID0geyAuLi5zdG9yZWQsIHNtdHA6IHsgLi4uc210cCwgZW5hYmxlZDogdHJ1ZSB9IH07XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IE5vdGlmaWNhdGlvblNlcnZpY2UudGVzdFNtdHAoc2V0dGluZ3MgYXMgYW55LCByZXF1ZXN0LmJvZHkucmVjaXBpZW50KTtcbiAgICAgICAgbG9nZ2VyLmluZm8oXG4gICAgICAgICAgYFNNVFAgdGVzdCB0byAke3JlcXVlc3QuYm9keS5yZWNpcGllbnR9OiAke3Jlc3VsdC5vayA/ICdkZWxpdmVyZWQnIDogYGZhaWxlZCAoJHtyZXN1bHQuZXJyb3J9KWB9YCxcbiAgICAgICAgKTtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHsgYm9keTogcmVzdWx0IH0pO1xuICAgICAgfSBjYXRjaCAoZXJyb3I6IGFueSkge1xuICAgICAgICBsb2dnZXIuZXJyb3IoYFNNVFAgdGVzdCBmYWlsZWQ6ICR7ZXJyb3IubWVzc2FnZX1gKTtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmN1c3RvbUVycm9yKHsgc3RhdHVzQ29kZTogNTAwLCBib2R5OiB7IG1lc3NhZ2U6IGVycm9yLm1lc3NhZ2UgfSB9KTtcbiAgICAgIH1cbiAgICB9LFxuICApO1xuXG4gIC8vIOKUgOKUgOKUgCBMSVNUIEFQSSBLRVlTIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICByb3V0ZXIuZ2V0KFxuICAgIHsgcGF0aDogJy9hcGkvd2F6dWgtY2FzZS1tYW5hZ2VtZW50L3NldHRpbmdzL2FwaS1rZXlzJywgdmFsaWRhdGU6IGZhbHNlIH0sXG4gICAgYXN5bmMgKGNvbnRleHQsIF9yZXF1ZXN0LCByZXNwb25zZSkgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgY2xpZW50ID0gY29udGV4dC5jb3JlLm9wZW5zZWFyY2guY2xpZW50LmFzQ3VycmVudFVzZXI7XG4gICAgICAgIGNvbnN0IHNldHRpbmdzID0gYXdhaXQgU2V0dGluZ3NTZXJ2aWNlLmdldFNldHRpbmdzKGNsaWVudCk7XG4gICAgICAgIHJldHVybiByZXNwb25zZS5vayh7IGJvZHk6IHsga2V5czogU2V0dGluZ3NTZXJ2aWNlLnRvUHVibGljKHNldHRpbmdzKS5hcGlfa2V5cyB9IH0pO1xuICAgICAgfSBjYXRjaCAoZXJyb3I6IGFueSkge1xuICAgICAgICByZXR1cm4gcmVzcG9uc2UuY3VzdG9tRXJyb3IoeyBzdGF0dXNDb2RlOiA1MDAsIGJvZHk6IHsgbWVzc2FnZTogZXJyb3IubWVzc2FnZSB9IH0pO1xuICAgICAgfVxuICAgIH0sXG4gICk7XG5cbiAgLy8g4pSA4pSA4pSAIENSRUFURSBBUEkgS0VZIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICByb3V0ZXIucG9zdChcbiAgICB7XG4gICAgICBwYXRoOiAnL2FwaS93YXp1aC1jYXNlLW1hbmFnZW1lbnQvc2V0dGluZ3MvYXBpLWtleXMnLFxuICAgICAgdmFsaWRhdGU6IHtcbiAgICAgICAgYm9keTogc2NoZW1hLm9iamVjdCh7XG4gICAgICAgICAgbmFtZTogc2NoZW1hLnN0cmluZyh7IG1pbkxlbmd0aDogMSwgbWF4TGVuZ3RoOiA2NCB9KSxcbiAgICAgICAgICBzY29wZXM6IHNjaGVtYS5hcnJheU9mKFxuICAgICAgICAgICAgc2NoZW1hLm9uZU9mKFtzY2hlbWEubGl0ZXJhbCgncmVhZCcpLCBzY2hlbWEubGl0ZXJhbCgnd3JpdGUnKV0pLFxuICAgICAgICAgICAgeyBkZWZhdWx0VmFsdWU6IFsncmVhZCddIH0sXG4gICAgICAgICAgKSxcbiAgICAgICAgICBleHBpcmVzX2F0OiBzY2hlbWEubWF5YmUoc2NoZW1hLm51bGxhYmxlKHNjaGVtYS5zdHJpbmcoKSkpLFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBhc3luYyAoY29udGV4dCwgcmVxdWVzdCwgcmVzcG9uc2UpID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGNsaWVudCA9IGNvbnRleHQuY29yZS5vcGVuc2VhcmNoLmNsaWVudC5hc0N1cnJlbnRVc2VyO1xuICAgICAgICBjb25zdCB1c2VyID0gYXdhaXQgZ2V0Q3VycmVudFVzZXJuYW1lKGNsaWVudCk7XG4gICAgICAgIGNvbnN0IGNyZWF0ZWQgPSBhd2FpdCBTZXR0aW5nc1NlcnZpY2UuY3JlYXRlQXBpS2V5KGNsaWVudCwgcmVxdWVzdC5ib2R5IGFzIGFueSwgdXNlcik7XG4gICAgICAgIGxvZ2dlci5pbmZvKGBBUEkga2V5IFwiJHtyZXF1ZXN0LmJvZHkubmFtZX1cIiBjcmVhdGVkIGJ5ICR7dXNlcn1gKTtcbiAgICAgICAgLy8gYHNlY3JldGAgaXMgcmV0dXJuZWQgZXhhY3RseSBvbmNlOiBpdCBpcyBzdG9yZWQgb25seSBhcyBhIFNIQS0yNTYgaGFzaC5cbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHsgYm9keTogY3JlYXRlZCB9KTtcbiAgICAgIH0gY2F0Y2ggKGVycm9yOiBhbnkpIHtcbiAgICAgICAgbG9nZ2VyLmVycm9yKGBFcnJvciBjcmVhdGluZyBBUEkga2V5OiAke2Vycm9yLm1lc3NhZ2V9YCk7XG4gICAgICAgIHJldHVybiByZXNwb25zZS5jdXN0b21FcnJvcih7IHN0YXR1c0NvZGU6IDUwMCwgYm9keTogeyBtZXNzYWdlOiBlcnJvci5tZXNzYWdlIH0gfSk7XG4gICAgICB9XG4gICAgfSxcbiAgKTtcblxuICAvLyDilIDilIDilIAgRU5BQkxFIC8gRElTQUJMRSBBUEkgS0VZIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICByb3V0ZXIucGF0Y2goXG4gICAge1xuICAgICAgcGF0aDogJy9hcGkvd2F6dWgtY2FzZS1tYW5hZ2VtZW50L3NldHRpbmdzL2FwaS1rZXlzL3trZXlJZH0nLFxuICAgICAgdmFsaWRhdGU6IHtcbiAgICAgICAgcGFyYW1zOiBzY2hlbWEub2JqZWN0KHsga2V5SWQ6IHNjaGVtYS5zdHJpbmcoKSB9KSxcbiAgICAgICAgYm9keTogc2NoZW1hLm9iamVjdCh7IGVuYWJsZWQ6IHNjaGVtYS5ib29sZWFuKCkgfSksXG4gICAgICB9LFxuICAgIH0sXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcXVlc3QsIHJlc3BvbnNlKSA9PiB7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBjbGllbnQgPSBjb250ZXh0LmNvcmUub3BlbnNlYXJjaC5jbGllbnQuYXNDdXJyZW50VXNlcjtcbiAgICAgICAgY29uc3Qgb2sgPSBhd2FpdCBTZXR0aW5nc1NlcnZpY2Uuc2V0QXBpS2V5RW5hYmxlZChcbiAgICAgICAgICBjbGllbnQsXG4gICAgICAgICAgcmVxdWVzdC5wYXJhbXMua2V5SWQsXG4gICAgICAgICAgcmVxdWVzdC5ib2R5LmVuYWJsZWQsXG4gICAgICAgICk7XG4gICAgICAgIGlmICghb2spIHJldHVybiByZXNwb25zZS5ub3RGb3VuZCh7IGJvZHk6IHsgbWVzc2FnZTogJ0FQSSBrZXkgbm90IGZvdW5kJyB9IH0pO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2Uub2soeyBib2R5OiB7IHN1Y2Nlc3M6IHRydWUgfSB9KTtcbiAgICAgIH0gY2F0Y2ggKGVycm9yOiBhbnkpIHtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmN1c3RvbUVycm9yKHsgc3RhdHVzQ29kZTogNTAwLCBib2R5OiB7IG1lc3NhZ2U6IGVycm9yLm1lc3NhZ2UgfSB9KTtcbiAgICAgIH1cbiAgICB9LFxuICApO1xuXG4gIC8vIOKUgOKUgOKUgCBSRVZPS0UgQVBJIEtFWSDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgcm91dGVyLmRlbGV0ZShcbiAgICB7XG4gICAgICBwYXRoOiAnL2FwaS93YXp1aC1jYXNlLW1hbmFnZW1lbnQvc2V0dGluZ3MvYXBpLWtleXMve2tleUlkfScsXG4gICAgICB2YWxpZGF0ZTogeyBwYXJhbXM6IHNjaGVtYS5vYmplY3QoeyBrZXlJZDogc2NoZW1hLnN0cmluZygpIH0pIH0sXG4gICAgfSxcbiAgICBhc3luYyAoY29udGV4dCwgcmVxdWVzdCwgcmVzcG9uc2UpID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGNsaWVudCA9IGNvbnRleHQuY29yZS5vcGVuc2VhcmNoLmNsaWVudC5hc0N1cnJlbnRVc2VyO1xuICAgICAgICBjb25zdCB1c2VyID0gYXdhaXQgZ2V0Q3VycmVudFVzZXJuYW1lKGNsaWVudCk7XG4gICAgICAgIGNvbnN0IG9rID0gYXdhaXQgU2V0dGluZ3NTZXJ2aWNlLmRlbGV0ZUFwaUtleShjbGllbnQsIHJlcXVlc3QucGFyYW1zLmtleUlkKTtcbiAgICAgICAgaWYgKCFvaykgcmV0dXJuIHJlc3BvbnNlLm5vdEZvdW5kKHsgYm9keTogeyBtZXNzYWdlOiAnQVBJIGtleSBub3QgZm91bmQnIH0gfSk7XG4gICAgICAgIGxvZ2dlci5pbmZvKGBBUEkga2V5ICR7cmVxdWVzdC5wYXJhbXMua2V5SWR9IHJldm9rZWQgYnkgJHt1c2VyfWApO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2Uub2soeyBib2R5OiB7IHN1Y2Nlc3M6IHRydWUgfSB9KTtcbiAgICAgIH0gY2F0Y2ggKGVycm9yOiBhbnkpIHtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmN1c3RvbUVycm9yKHsgc3RhdHVzQ29kZTogNTAwLCBib2R5OiB7IG1lc3NhZ2U6IGVycm9yLm1lc3NhZ2UgfSB9KTtcbiAgICAgIH1cbiAgICB9LFxuICApO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFNQSxJQUFBQSxhQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxpQkFBQSxHQUFBRCxPQUFBO0FBQ0EsSUFBQUUscUJBQUEsR0FBQUYsT0FBQTtBQUNBLElBQUFHLE1BQUEsR0FBQUgsT0FBQTtBQUNBLElBQUFJLE1BQUEsR0FBQUosT0FBQTtBQVZBO0FBQ0E7QUFDQTtBQUNBOztBQVNBO0FBQ0EsTUFBTUssWUFBWSxHQUFHQyxvQkFBTSxDQUFDQyxNQUFNLENBQUM7RUFDakNDLE1BQU0sRUFBRUYsb0JBQU0sQ0FBQ0csTUFBTSxDQUFDO0lBQUVDLFNBQVMsRUFBRTtFQUFHLENBQUMsQ0FBQztFQUN4Q0MsU0FBUyxFQUFFTCxvQkFBTSxDQUFDRyxNQUFNLENBQUM7SUFBRUMsU0FBUyxFQUFFO0VBQUUsQ0FBQyxDQUFDO0VBQzFDRSxZQUFZLEVBQUVOLG9CQUFNLENBQUNPLE9BQU8sQ0FBQyxDQUFDO0VBQzlCQyxPQUFPLEVBQUVSLG9CQUFNLENBQUNTLE1BQU0sQ0FBQztJQUFFQyxHQUFHLEVBQUUsQ0FBQztJQUFFQyxHQUFHLEVBQUU7RUFBRyxDQUFDO0FBQzVDLENBQUMsQ0FBQztBQUVGLE1BQU1DLGVBQWUsR0FBR1osb0JBQU0sQ0FBQ0MsTUFBTSxDQUFDO0VBQ3BDWSxLQUFLLEVBQUViLG9CQUFNLENBQUNjLEtBQUssQ0FBQyxDQUFDZCxvQkFBTSxDQUFDZSxPQUFPLENBQUMsS0FBSyxDQUFDLEVBQUVmLG9CQUFNLENBQUNlLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO0VBQ25FQyxZQUFZLEVBQUVoQixvQkFBTSxDQUFDTyxPQUFPLENBQUMsQ0FBQztFQUM5QlUsUUFBUSxFQUFFakIsb0JBQU0sQ0FBQ0csTUFBTSxDQUFDO0FBQzFCLENBQUMsQ0FBQztBQUVGLE1BQU1lLGlCQUFpQixHQUFHbEIsb0JBQU0sQ0FBQ0MsTUFBTSxDQUFDO0VBQ3RDa0IsSUFBSSxFQUFFbkIsb0JBQU0sQ0FBQ2MsS0FBSyxDQUFDLENBQ2pCZCxvQkFBTSxDQUFDZSxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQ3RCZixvQkFBTSxDQUFDZSxPQUFPLENBQUMsUUFBUSxDQUFDLEVBQ3hCZixvQkFBTSxDQUFDZSxPQUFPLENBQUMsT0FBTyxDQUFDLEVBQ3ZCZixvQkFBTSxDQUFDZSxPQUFPLENBQUMsU0FBUyxDQUFDLENBQzFCLENBQUM7RUFDRkssS0FBSyxFQUFFcEIsb0JBQU0sQ0FBQ3FCLEtBQUssQ0FBQ3JCLG9CQUFNLENBQUNHLE1BQU0sQ0FBQyxDQUFDLENBQUM7RUFDcENtQixRQUFRLEVBQUV0QixvQkFBTSxDQUFDcUIsS0FBSyxDQUFDckIsb0JBQU0sQ0FBQ0csTUFBTSxDQUFDLENBQUMsQ0FBQztFQUN2Q29CLFFBQVEsRUFBRXZCLG9CQUFNLENBQUNxQixLQUFLLENBQUNyQixvQkFBTSxDQUFDRyxNQUFNLENBQUMsQ0FBQyxDQUFDO0VBQ3ZDcUIsV0FBVyxFQUFFeEIsb0JBQU0sQ0FBQ3FCLEtBQUssQ0FBQ3JCLG9CQUFNLENBQUNHLE1BQU0sQ0FBQyxDQUFDLENBQUM7RUFDMUNzQixZQUFZLEVBQUV6QixvQkFBTSxDQUFDcUIsS0FBSyxDQUFDckIsb0JBQU0sQ0FBQ0csTUFBTSxDQUFDLENBQUM7QUFDNUMsQ0FBQyxDQUFDO0FBRUYsTUFBTXVCLHlCQUF5QixHQUFHMUIsb0JBQU0sQ0FBQ0MsTUFBTSxDQUFDO0VBQzlDMEIsRUFBRSxFQUFFM0Isb0JBQU0sQ0FBQ0csTUFBTSxDQUFDLENBQUM7RUFDbkJ5QixJQUFJLEVBQUU1QixvQkFBTSxDQUFDRyxNQUFNLENBQUMsQ0FBQztFQUNyQmdCLElBQUksRUFBRW5CLG9CQUFNLENBQUNjLEtBQUssQ0FBQyxDQUNqQmQsb0JBQU0sQ0FBQ2UsT0FBTyxDQUFDLFNBQVMsQ0FBQyxFQUN6QmYsb0JBQU0sQ0FBQ2UsT0FBTyxDQUFDLE9BQU8sQ0FBQyxFQUN2QmYsb0JBQU0sQ0FBQ2UsT0FBTyxDQUFDLE9BQU8sQ0FBQyxFQUN2QmYsb0JBQU0sQ0FBQ2UsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUN4QixDQUFDO0VBQ0ZjLEdBQUcsRUFBRTdCLG9CQUFNLENBQUNHLE1BQU0sQ0FBQztJQUFFMkIsWUFBWSxFQUFFO0VBQUcsQ0FBQyxDQUFDO0VBQ3hDQyxPQUFPLEVBQUUvQixvQkFBTSxDQUFDTyxPQUFPLENBQUMsQ0FBQztFQUN6QnlCLE1BQU0sRUFBRWhDLG9CQUFNLENBQUNpQyxPQUFPLENBQUNqQyxvQkFBTSxDQUFDRyxNQUFNLENBQUMsQ0FBQyxDQUFDO0VBQ3ZDK0IsVUFBVSxFQUFFbEMsb0JBQU0sQ0FBQ3FCLEtBQUssQ0FBQ3JCLG9CQUFNLENBQUNpQyxPQUFPLENBQUNqQyxvQkFBTSxDQUFDRyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7RUFDekRnQyxjQUFjLEVBQUVuQyxvQkFBTSxDQUFDcUIsS0FBSyxDQUFDckIsb0JBQU0sQ0FBQ2MsS0FBSyxDQUFDLENBQUNkLG9CQUFNLENBQUNlLE9BQU8sQ0FBQyxJQUFJLENBQUMsRUFBRWYsb0JBQU0sQ0FBQ2UsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztFQUN6RnFCLElBQUksRUFBRXBDLG9CQUFNLENBQUNxQixLQUFLLENBQUNILGlCQUFpQixDQUFDO0VBQ3JDbUIsT0FBTyxFQUFFckMsb0JBQU0sQ0FBQ3FCLEtBQUssQ0FBQ3JCLG9CQUFNLENBQUNzQyxRQUFRLENBQUN0QyxvQkFBTSxDQUFDRyxNQUFNLENBQUMsQ0FBQyxFQUFFSCxvQkFBTSxDQUFDRyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7RUFDeEVvQyxVQUFVLEVBQUV2QyxvQkFBTSxDQUFDcUIsS0FBSyxDQUFDckIsb0JBQU0sQ0FBQ08sT0FBTyxDQUFDLENBQUM7QUFDM0MsQ0FBQyxDQUFDO0FBRUYsTUFBTWlDLFVBQVUsR0FBR3hDLG9CQUFNLENBQUNDLE1BQU0sQ0FBQztFQUMvQjhCLE9BQU8sRUFBRS9CLG9CQUFNLENBQUNPLE9BQU8sQ0FBQyxDQUFDO0VBQ3pCa0MsSUFBSSxFQUFFekMsb0JBQU0sQ0FBQ0csTUFBTSxDQUFDO0lBQUUyQixZQUFZLEVBQUU7RUFBRyxDQUFDLENBQUM7RUFDekNZLElBQUksRUFBRTFDLG9CQUFNLENBQUNTLE1BQU0sQ0FBQztJQUFFQyxHQUFHLEVBQUUsQ0FBQztJQUFFQyxHQUFHLEVBQUUsS0FBSztJQUFFbUIsWUFBWSxFQUFFO0VBQUksQ0FBQyxDQUFDO0VBQzlEYSxRQUFRLEVBQUUzQyxvQkFBTSxDQUFDYyxLQUFLLENBQUMsQ0FDckJkLG9CQUFNLENBQUNlLE9BQU8sQ0FBQyxNQUFNLENBQUMsRUFDdEJmLG9CQUFNLENBQUNlLE9BQU8sQ0FBQyxVQUFVLENBQUMsRUFDMUJmLG9CQUFNLENBQUNlLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FDdEIsQ0FBQztFQUNGNkIsU0FBUyxFQUFFNUMsb0JBQU0sQ0FBQ2MsS0FBSyxDQUFDLENBQ3RCZCxvQkFBTSxDQUFDZSxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQ3RCZixvQkFBTSxDQUFDZSxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQ3RCZixvQkFBTSxDQUFDZSxPQUFPLENBQUMsT0FBTyxDQUFDLEVBQ3ZCZixvQkFBTSxDQUFDZSxPQUFPLENBQUMsT0FBTyxDQUFDLEVBQ3ZCZixvQkFBTSxDQUFDZSxPQUFPLENBQUMsVUFBVSxDQUFDLENBQzNCLENBQUM7RUFDRk8sUUFBUSxFQUFFdEIsb0JBQU0sQ0FBQ0csTUFBTSxDQUFDO0lBQUUyQixZQUFZLEVBQUU7RUFBRyxDQUFDLENBQUM7RUFDN0NQLFFBQVEsRUFBRXZCLG9CQUFNLENBQUNHLE1BQU0sQ0FBQztJQUFFMkIsWUFBWSxFQUFFO0VBQUcsQ0FBQyxDQUFDO0VBQzdDZSxZQUFZLEVBQUU3QyxvQkFBTSxDQUFDRyxNQUFNLENBQUM7SUFBRTJCLFlBQVksRUFBRTtFQUFHLENBQUMsQ0FBQztFQUNqRGdCLFNBQVMsRUFBRTlDLG9CQUFNLENBQUNHLE1BQU0sQ0FBQztJQUFFMkIsWUFBWSxFQUFFO0VBQUcsQ0FBQyxDQUFDO0VBQzlDaUIsbUJBQW1CLEVBQUUvQyxvQkFBTSxDQUFDTyxPQUFPLENBQUM7SUFBRXVCLFlBQVksRUFBRTtFQUFLLENBQUMsQ0FBQztFQUMzRGtCLFVBQVUsRUFBRWhELG9CQUFNLENBQUNTLE1BQU0sQ0FBQztJQUFFQyxHQUFHLEVBQUUsSUFBSTtJQUFFQyxHQUFHLEVBQUUsTUFBTTtJQUFFbUIsWUFBWSxFQUFFO0VBQU0sQ0FBQztBQUMzRSxDQUFDLENBQUM7QUFFRixNQUFNbUIsbUJBQW1CLEdBQUdqRCxvQkFBTSxDQUFDQyxNQUFNLENBQUM7RUFDeENpRCxjQUFjLEVBQUVsRCxvQkFBTSxDQUFDTyxPQUFPLENBQUMsQ0FBQztFQUNoQzRDLGFBQWEsRUFBRW5ELG9CQUFNLENBQUNpQyxPQUFPLENBQUNqQyxvQkFBTSxDQUFDRyxNQUFNLENBQUMsQ0FBQyxDQUFDO0VBQzlDaUQsUUFBUSxFQUFFcEQsb0JBQU0sQ0FBQ2lDLE9BQU8sQ0FBQ1AseUJBQXlCO0FBQ3BELENBQUMsQ0FBQztBQUVGLE1BQU0yQixvQkFBb0IsR0FBR3JELG9CQUFNLENBQUNDLE1BQU0sQ0FBQztFQUN6Q3FELGFBQWEsRUFBRXRELG9CQUFNLENBQUNTLE1BQU0sQ0FBQztJQUFFQyxHQUFHLEVBQUU7RUFBRSxDQUFDLENBQUM7RUFDeEM2QyxNQUFNLEVBQUV2RCxvQkFBTSxDQUFDRyxNQUFNLENBQUMsQ0FBQztFQUN2QnFELE1BQU0sRUFBRXhELG9CQUFNLENBQUNxQixLQUFLLENBQUNyQixvQkFBTSxDQUFDRyxNQUFNLENBQUMsQ0FBQztBQUN0QyxDQUFDLENBQUM7QUFFRixNQUFNc0Qsc0JBQXNCLEdBQUd6RCxvQkFBTSxDQUFDQyxNQUFNLENBQUM7RUFDM0MwQixFQUFFLEVBQUUzQixvQkFBTSxDQUFDRyxNQUFNLENBQUMsQ0FBQztFQUNuQnlCLElBQUksRUFBRTVCLG9CQUFNLENBQUNHLE1BQU0sQ0FBQyxDQUFDO0VBQ3JCNEIsT0FBTyxFQUFFL0Isb0JBQU0sQ0FBQ08sT0FBTyxDQUFDLENBQUM7RUFDekJtRCxLQUFLLEVBQUUxRCxvQkFBTSxDQUFDUyxNQUFNLENBQUMsQ0FBQztFQUN0QmtELEtBQUssRUFBRTNELG9CQUFNLENBQUNDLE1BQU0sQ0FBQztJQUNuQjJELFVBQVUsRUFBRTVELG9CQUFNLENBQUNpQyxPQUFPLENBQUNqQyxvQkFBTSxDQUFDRyxNQUFNLENBQUMsQ0FBQyxDQUFDO0lBQzNDMEQsVUFBVSxFQUFFN0Qsb0JBQU0sQ0FBQ2lDLE9BQU8sQ0FBQ2pDLG9CQUFNLENBQUNHLE1BQU0sQ0FBQyxDQUFDLENBQUM7SUFDM0MyRCxVQUFVLEVBQUU5RCxvQkFBTSxDQUFDaUMsT0FBTyxDQUFDakMsb0JBQU0sQ0FBQ0csTUFBTSxDQUFDLENBQUMsQ0FBQztJQUMzQzRELFFBQVEsRUFBRS9ELG9CQUFNLENBQUNpQyxPQUFPLENBQUNqQyxvQkFBTSxDQUFDRyxNQUFNLENBQUMsQ0FBQyxDQUFDO0lBQ3pDNkQsSUFBSSxFQUFFaEUsb0JBQU0sQ0FBQ2lDLE9BQU8sQ0FBQ2pDLG9CQUFNLENBQUNHLE1BQU0sQ0FBQyxDQUFDO0VBQ3RDLENBQUMsQ0FBQztFQUNGOEQsSUFBSSxFQUFFakUsb0JBQU0sQ0FBQ2MsS0FBSyxDQUFDLENBQUNkLG9CQUFNLENBQUNlLE9BQU8sQ0FBQyxZQUFZLENBQUMsRUFBRWYsb0JBQU0sQ0FBQ2UsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUM7RUFDaEZtRCxLQUFLLEVBQUVsRSxvQkFBTSxDQUFDaUMsT0FBTyxDQUFDb0Isb0JBQW9CO0FBQzVDLENBQUMsQ0FBQztBQUVGLE1BQU1jLGdCQUFnQixHQUFHbkUsb0JBQU0sQ0FBQ0MsTUFBTSxDQUFDO0VBQ3JDOEIsT0FBTyxFQUFFL0Isb0JBQU0sQ0FBQ08sT0FBTyxDQUFDLENBQUM7RUFDekI2RCxRQUFRLEVBQUVwRSxvQkFBTSxDQUFDaUMsT0FBTyxDQUFDd0Isc0JBQXNCO0FBQ2pELENBQUMsQ0FBQztBQUVLLFNBQVNZLHNCQUFzQkEsQ0FBQ0MsTUFBZSxFQUFFQyxNQUFjLEVBQVE7RUFDNUU7RUFDQUQsTUFBTSxDQUFDRSxHQUFHLENBQ1I7SUFBRUMsSUFBSSxFQUFFLHFDQUFxQztJQUFFQyxRQUFRLEVBQUU7RUFBTSxDQUFDLEVBQ2hFLE9BQU9DLE9BQU8sRUFBRUMsUUFBUSxFQUFFQyxRQUFRLEtBQUs7SUFDckMsSUFBSTtNQUNGLE1BQU1DLE1BQU0sR0FBR0gsT0FBTyxDQUFDSSxJQUFJLENBQUNDLFVBQVUsQ0FBQ0YsTUFBTSxDQUFDRyxhQUFhO01BQzNELE1BQU1DLFFBQVEsR0FBRyxNQUFNQyxpQ0FBZSxDQUFDQyxXQUFXLENBQUNOLE1BQU0sQ0FBQztNQUMxRCxPQUFPRCxRQUFRLENBQUNRLEVBQUUsQ0FBQztRQUFFQyxJQUFJLEVBQUVILGlDQUFlLENBQUNJLFFBQVEsQ0FBQ0wsUUFBUTtNQUFFLENBQUMsQ0FBQztJQUNsRSxDQUFDLENBQUMsT0FBT00sS0FBVSxFQUFFO01BQ25CakIsTUFBTSxDQUFDaUIsS0FBSyxDQUFFLDJCQUEwQkEsS0FBSyxDQUFDQyxPQUFRLEVBQUMsQ0FBQztNQUN4RCxPQUFPWixRQUFRLENBQUNhLFdBQVcsQ0FBQztRQUFFQyxVQUFVLEVBQUUsR0FBRztRQUFFTCxJQUFJLEVBQUU7VUFBRUcsT0FBTyxFQUFFRCxLQUFLLENBQUNDO1FBQVE7TUFBRSxDQUFDLENBQUM7SUFDcEY7RUFDRixDQUNGLENBQUM7O0VBRUQ7RUFDQW5CLE1BQU0sQ0FBQ3NCLEdBQUcsQ0FDUjtJQUNFbkIsSUFBSSxFQUFFLHFDQUFxQztJQUMzQ0MsUUFBUSxFQUFFO01BQ1JZLElBQUksRUFBRXRGLG9CQUFNLENBQUNDLE1BQU0sQ0FBQztRQUNsQjRGLE9BQU8sRUFBRTdGLG9CQUFNLENBQUNxQixLQUFLLENBQUN0QixZQUFZLENBQUM7UUFDbkMrRixLQUFLLEVBQUU5RixvQkFBTSxDQUFDcUIsS0FBSyxDQUNqQnJCLG9CQUFNLENBQUNjLEtBQUssQ0FBQyxDQUFDZCxvQkFBTSxDQUFDZSxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQUVmLG9CQUFNLENBQUNlLE9BQU8sQ0FBQyxPQUFPLENBQUMsRUFBRWYsb0JBQU0sQ0FBQ2UsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQ3hGLENBQUM7UUFDRGdGLFNBQVMsRUFBRS9GLG9CQUFNLENBQUNxQixLQUFLLENBQUNULGVBQWUsQ0FBQztRQUN4Q29GLGFBQWEsRUFBRWhHLG9CQUFNLENBQUNxQixLQUFLLENBQUM0QixtQkFBbUIsQ0FBQztRQUNoRGdELFVBQVUsRUFBRWpHLG9CQUFNLENBQUNxQixLQUFLLENBQUM4QyxnQkFBZ0IsQ0FBQztRQUMxQytCLElBQUksRUFBRWxHLG9CQUFNLENBQUNxQixLQUFLLENBQUNtQixVQUFVLENBQUM7UUFDOUIyRCxRQUFRLEVBQUVuRyxvQkFBTSxDQUFDcUIsS0FBSyxDQUFDckIsb0JBQU0sQ0FBQ0csTUFBTSxDQUFDLENBQUM7TUFDeEMsQ0FBQztJQUNIO0VBQ0YsQ0FBQyxFQUNELE9BQU93RSxPQUFPLEVBQUV5QixPQUFPLEVBQUV2QixRQUFRLEtBQUs7SUFDcEMsSUFBSTtNQUNGLE1BQU1DLE1BQU0sR0FBR0gsT0FBTyxDQUFDSSxJQUFJLENBQUNDLFVBQVUsQ0FBQ0YsTUFBTSxDQUFDRyxhQUFhO01BQzNELE1BQU1vQixJQUFJLEdBQUcsTUFBTSxJQUFBQyx5QkFBa0IsRUFBQ3hCLE1BQU0sQ0FBQztNQUM3QyxNQUFNeUIsS0FBSyxHQUFHLE1BQU1wQixpQ0FBZSxDQUFDcUIsWUFBWSxDQUFDMUIsTUFBTSxFQUFFc0IsT0FBTyxDQUFDZCxJQUFJLEVBQVNlLElBQUksQ0FBQztNQUNuRjlCLE1BQU0sQ0FBQ2tDLElBQUksQ0FBRSx1QkFBc0JKLElBQUssRUFBQyxDQUFDO01BQzFDLE9BQU94QixRQUFRLENBQUNRLEVBQUUsQ0FBQztRQUFFQyxJQUFJLEVBQUVILGlDQUFlLENBQUNJLFFBQVEsQ0FBQ2dCLEtBQUs7TUFBRSxDQUFDLENBQUM7SUFDL0QsQ0FBQyxDQUFDLE9BQU9mLEtBQVUsRUFBRTtNQUNuQmpCLE1BQU0sQ0FBQ2lCLEtBQUssQ0FBRSwwQkFBeUJBLEtBQUssQ0FBQ0MsT0FBUSxFQUFDLENBQUM7TUFDdkQsT0FBT1osUUFBUSxDQUFDYSxXQUFXLENBQUM7UUFBRUMsVUFBVSxFQUFFLEdBQUc7UUFBRUwsSUFBSSxFQUFFO1VBQUVHLE9BQU8sRUFBRUQsS0FBSyxDQUFDQztRQUFRO01BQUUsQ0FBQyxDQUFDO0lBQ3BGO0VBQ0YsQ0FDRixDQUFDOztFQUVEO0VBQ0FuQixNQUFNLENBQUNvQyxJQUFJLENBQ1Q7SUFDRWpDLElBQUksRUFBRSx3REFBd0Q7SUFDOURDLFFBQVEsRUFBRTtNQUFFWSxJQUFJLEVBQUV0RixvQkFBTSxDQUFDQyxNQUFNLENBQUM7UUFBRTBHLE9BQU8sRUFBRWpGO01BQTBCLENBQUM7SUFBRTtFQUMxRSxDQUFDLEVBQ0QsT0FBT2lELE9BQU8sRUFBRXlCLE9BQU8sRUFBRXZCLFFBQVEsS0FBSztJQUNwQyxJQUFJO01BQ0YsTUFBTUMsTUFBTSxHQUFHSCxPQUFPLENBQUNJLElBQUksQ0FBQ0MsVUFBVSxDQUFDRixNQUFNLENBQUNHLGFBQWE7TUFDM0Q7TUFDQSxNQUFNMEIsT0FBTyxHQUFHLE1BQU14QixpQ0FBZSxDQUFDeUIscUJBQXFCLENBQ3pEOUIsTUFBTSxFQUNOc0IsT0FBTyxDQUFDZCxJQUFJLENBQUNxQixPQUNmLENBQUM7TUFDRCxNQUFNekIsUUFBUSxHQUFHLE1BQU1DLGlDQUFlLENBQUNDLFdBQVcsQ0FBQ04sTUFBTSxDQUFDO01BQzFELE1BQU0rQixNQUFNLEdBQUcsTUFBTUMseUNBQW1CLENBQUNDLFdBQVcsQ0FBQ0osT0FBTyxFQUFFekIsUUFBUSxDQUFDO01BQ3ZFWCxNQUFNLENBQUNrQyxJQUFJLENBQ1IseUJBQXdCRSxPQUFPLENBQUMvRSxJQUFLLGFBQVlpRixNQUFNLENBQUN4QixFQUFFLEdBQUcsSUFBSSxHQUFHLFFBQVMsS0FBSXdCLE1BQU0sQ0FBQ0csTUFBTyxHQUNsRyxDQUFDO01BQ0QsT0FBT25DLFFBQVEsQ0FBQ1EsRUFBRSxDQUFDO1FBQUVDLElBQUksRUFBRXVCO01BQU8sQ0FBQyxDQUFDO0lBQ3RDLENBQUMsQ0FBQyxPQUFPckIsS0FBVSxFQUFFO01BQ25CakIsTUFBTSxDQUFDaUIsS0FBSyxDQUFFLHdCQUF1QkEsS0FBSyxDQUFDQyxPQUFRLEVBQUMsQ0FBQztNQUNyRCxPQUFPWixRQUFRLENBQUNhLFdBQVcsQ0FBQztRQUFFQyxVQUFVLEVBQUUsR0FBRztRQUFFTCxJQUFJLEVBQUU7VUFBRUcsT0FBTyxFQUFFRCxLQUFLLENBQUNDO1FBQVE7TUFBRSxDQUFDLENBQUM7SUFDcEY7RUFDRixDQUNGLENBQUM7O0VBRUQ7RUFDQW5CLE1BQU0sQ0FBQ29DLElBQUksQ0FDVDtJQUNFakMsSUFBSSxFQUFFLCtDQUErQztJQUNyREMsUUFBUSxFQUFFO01BQ1JZLElBQUksRUFBRXRGLG9CQUFNLENBQUNDLE1BQU0sQ0FBQztRQUNsQmdILFNBQVMsRUFBRWpILG9CQUFNLENBQUNHLE1BQU0sQ0FBQztVQUFFK0csU0FBUyxFQUFFO1FBQUUsQ0FBQyxDQUFDO1FBQzFDO1FBQ0FoQixJQUFJLEVBQUVsRyxvQkFBTSxDQUFDcUIsS0FBSyxDQUFDbUIsVUFBVTtNQUMvQixDQUFDO0lBQ0g7RUFDRixDQUFDLEVBQ0QsT0FBT21DLE9BQU8sRUFBRXlCLE9BQU8sRUFBRXZCLFFBQVEsS0FBSztJQUNwQyxJQUFJO01BQ0YsTUFBTUMsTUFBTSxHQUFHSCxPQUFPLENBQUNJLElBQUksQ0FBQ0MsVUFBVSxDQUFDRixNQUFNLENBQUNHLGFBQWE7TUFDM0QsTUFBTWtDLE1BQU0sR0FBRyxNQUFNaEMsaUNBQWUsQ0FBQ0MsV0FBVyxDQUFDTixNQUFNLENBQUM7TUFFeEQsTUFBTW9CLElBQUksR0FBR0UsT0FBTyxDQUFDZCxJQUFJLENBQUNZLElBQUksR0FDMUI7UUFDRSxHQUFHRSxPQUFPLENBQUNkLElBQUksQ0FBQ1ksSUFBSTtRQUNwQjNFLFFBQVEsRUFDTjZFLE9BQU8sQ0FBQ2QsSUFBSSxDQUFDWSxJQUFJLENBQUMzRSxRQUFRLEtBQUs2Rix5QkFBa0IsR0FDN0NELE1BQU0sQ0FBQ2pCLElBQUksQ0FBQzNFLFFBQVEsR0FDcEI2RSxPQUFPLENBQUNkLElBQUksQ0FBQ1ksSUFBSSxDQUFDM0U7TUFDMUIsQ0FBQyxHQUNENEYsTUFBTSxDQUFDakIsSUFBSTs7TUFFZjtNQUNBLE1BQU1oQixRQUFRLEdBQUc7UUFBRSxHQUFHaUMsTUFBTTtRQUFFakIsSUFBSSxFQUFFO1VBQUUsR0FBR0EsSUFBSTtVQUFFbkUsT0FBTyxFQUFFO1FBQUs7TUFBRSxDQUFDO01BQ2hFLE1BQU04RSxNQUFNLEdBQUcsTUFBTUMseUNBQW1CLENBQUNPLFFBQVEsQ0FBQ25DLFFBQVEsRUFBU2tCLE9BQU8sQ0FBQ2QsSUFBSSxDQUFDMkIsU0FBUyxDQUFDO01BQzFGMUMsTUFBTSxDQUFDa0MsSUFBSSxDQUNSLGdCQUFlTCxPQUFPLENBQUNkLElBQUksQ0FBQzJCLFNBQVUsS0FBSUosTUFBTSxDQUFDeEIsRUFBRSxHQUFHLFdBQVcsR0FBSSxXQUFVd0IsTUFBTSxDQUFDckIsS0FBTSxHQUFHLEVBQ2xHLENBQUM7TUFDRCxPQUFPWCxRQUFRLENBQUNRLEVBQUUsQ0FBQztRQUFFQyxJQUFJLEVBQUV1QjtNQUFPLENBQUMsQ0FBQztJQUN0QyxDQUFDLENBQUMsT0FBT3JCLEtBQVUsRUFBRTtNQUNuQmpCLE1BQU0sQ0FBQ2lCLEtBQUssQ0FBRSxxQkFBb0JBLEtBQUssQ0FBQ0MsT0FBUSxFQUFDLENBQUM7TUFDbEQsT0FBT1osUUFBUSxDQUFDYSxXQUFXLENBQUM7UUFBRUMsVUFBVSxFQUFFLEdBQUc7UUFBRUwsSUFBSSxFQUFFO1VBQUVHLE9BQU8sRUFBRUQsS0FBSyxDQUFDQztRQUFRO01BQUUsQ0FBQyxDQUFDO0lBQ3BGO0VBQ0YsQ0FDRixDQUFDOztFQUVEO0VBQ0FuQixNQUFNLENBQUNFLEdBQUcsQ0FDUjtJQUFFQyxJQUFJLEVBQUUsOENBQThDO0lBQUVDLFFBQVEsRUFBRTtFQUFNLENBQUMsRUFDekUsT0FBT0MsT0FBTyxFQUFFQyxRQUFRLEVBQUVDLFFBQVEsS0FBSztJQUNyQyxJQUFJO01BQ0YsTUFBTUMsTUFBTSxHQUFHSCxPQUFPLENBQUNJLElBQUksQ0FBQ0MsVUFBVSxDQUFDRixNQUFNLENBQUNHLGFBQWE7TUFDM0QsTUFBTUMsUUFBUSxHQUFHLE1BQU1DLGlDQUFlLENBQUNDLFdBQVcsQ0FBQ04sTUFBTSxDQUFDO01BQzFELE9BQU9ELFFBQVEsQ0FBQ1EsRUFBRSxDQUFDO1FBQUVDLElBQUksRUFBRTtVQUFFZ0MsSUFBSSxFQUFFbkMsaUNBQWUsQ0FBQ0ksUUFBUSxDQUFDTCxRQUFRLENBQUMsQ0FBQ3FDO1FBQVM7TUFBRSxDQUFDLENBQUM7SUFDckYsQ0FBQyxDQUFDLE9BQU8vQixLQUFVLEVBQUU7TUFDbkIsT0FBT1gsUUFBUSxDQUFDYSxXQUFXLENBQUM7UUFBRUMsVUFBVSxFQUFFLEdBQUc7UUFBRUwsSUFBSSxFQUFFO1VBQUVHLE9BQU8sRUFBRUQsS0FBSyxDQUFDQztRQUFRO01BQUUsQ0FBQyxDQUFDO0lBQ3BGO0VBQ0YsQ0FDRixDQUFDOztFQUVEO0VBQ0FuQixNQUFNLENBQUNvQyxJQUFJLENBQ1Q7SUFDRWpDLElBQUksRUFBRSw4Q0FBOEM7SUFDcERDLFFBQVEsRUFBRTtNQUNSWSxJQUFJLEVBQUV0RixvQkFBTSxDQUFDQyxNQUFNLENBQUM7UUFDbEIyQixJQUFJLEVBQUU1QixvQkFBTSxDQUFDRyxNQUFNLENBQUM7VUFBRStHLFNBQVMsRUFBRSxDQUFDO1VBQUU5RyxTQUFTLEVBQUU7UUFBRyxDQUFDLENBQUM7UUFDcERvSCxNQUFNLEVBQUV4SCxvQkFBTSxDQUFDaUMsT0FBTyxDQUNwQmpDLG9CQUFNLENBQUNjLEtBQUssQ0FBQyxDQUFDZCxvQkFBTSxDQUFDZSxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQUVmLG9CQUFNLENBQUNlLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQy9EO1VBQUVlLFlBQVksRUFBRSxDQUFDLE1BQU07UUFBRSxDQUMzQixDQUFDO1FBQ0QyRixVQUFVLEVBQUV6SCxvQkFBTSxDQUFDcUIsS0FBSyxDQUFDckIsb0JBQU0sQ0FBQzBILFFBQVEsQ0FBQzFILG9CQUFNLENBQUNHLE1BQU0sQ0FBQyxDQUFDLENBQUM7TUFDM0QsQ0FBQztJQUNIO0VBQ0YsQ0FBQyxFQUNELE9BQU93RSxPQUFPLEVBQUV5QixPQUFPLEVBQUV2QixRQUFRLEtBQUs7SUFDcEMsSUFBSTtNQUNGLE1BQU1DLE1BQU0sR0FBR0gsT0FBTyxDQUFDSSxJQUFJLENBQUNDLFVBQVUsQ0FBQ0YsTUFBTSxDQUFDRyxhQUFhO01BQzNELE1BQU1vQixJQUFJLEdBQUcsTUFBTSxJQUFBQyx5QkFBa0IsRUFBQ3hCLE1BQU0sQ0FBQztNQUM3QyxNQUFNNkMsT0FBTyxHQUFHLE1BQU14QyxpQ0FBZSxDQUFDeUMsWUFBWSxDQUFDOUMsTUFBTSxFQUFFc0IsT0FBTyxDQUFDZCxJQUFJLEVBQVNlLElBQUksQ0FBQztNQUNyRjlCLE1BQU0sQ0FBQ2tDLElBQUksQ0FBRSxZQUFXTCxPQUFPLENBQUNkLElBQUksQ0FBQzFELElBQUssZ0JBQWV5RSxJQUFLLEVBQUMsQ0FBQztNQUNoRTtNQUNBLE9BQU94QixRQUFRLENBQUNRLEVBQUUsQ0FBQztRQUFFQyxJQUFJLEVBQUVxQztNQUFRLENBQUMsQ0FBQztJQUN2QyxDQUFDLENBQUMsT0FBT25DLEtBQVUsRUFBRTtNQUNuQmpCLE1BQU0sQ0FBQ2lCLEtBQUssQ0FBRSwyQkFBMEJBLEtBQUssQ0FBQ0MsT0FBUSxFQUFDLENBQUM7TUFDeEQsT0FBT1osUUFBUSxDQUFDYSxXQUFXLENBQUM7UUFBRUMsVUFBVSxFQUFFLEdBQUc7UUFBRUwsSUFBSSxFQUFFO1VBQUVHLE9BQU8sRUFBRUQsS0FBSyxDQUFDQztRQUFRO01BQUUsQ0FBQyxDQUFDO0lBQ3BGO0VBQ0YsQ0FDRixDQUFDOztFQUVEO0VBQ0FuQixNQUFNLENBQUN1RCxLQUFLLENBQ1Y7SUFDRXBELElBQUksRUFBRSxzREFBc0Q7SUFDNURDLFFBQVEsRUFBRTtNQUNSb0QsTUFBTSxFQUFFOUgsb0JBQU0sQ0FBQ0MsTUFBTSxDQUFDO1FBQUU4SCxLQUFLLEVBQUUvSCxvQkFBTSxDQUFDRyxNQUFNLENBQUM7TUFBRSxDQUFDLENBQUM7TUFDakRtRixJQUFJLEVBQUV0RixvQkFBTSxDQUFDQyxNQUFNLENBQUM7UUFBRThCLE9BQU8sRUFBRS9CLG9CQUFNLENBQUNPLE9BQU8sQ0FBQztNQUFFLENBQUM7SUFDbkQ7RUFDRixDQUFDLEVBQ0QsT0FBT29FLE9BQU8sRUFBRXlCLE9BQU8sRUFBRXZCLFFBQVEsS0FBSztJQUNwQyxJQUFJO01BQ0YsTUFBTUMsTUFBTSxHQUFHSCxPQUFPLENBQUNJLElBQUksQ0FBQ0MsVUFBVSxDQUFDRixNQUFNLENBQUNHLGFBQWE7TUFDM0QsTUFBTUksRUFBRSxHQUFHLE1BQU1GLGlDQUFlLENBQUM2QyxnQkFBZ0IsQ0FDL0NsRCxNQUFNLEVBQ05zQixPQUFPLENBQUMwQixNQUFNLENBQUNDLEtBQUssRUFDcEIzQixPQUFPLENBQUNkLElBQUksQ0FBQ3ZELE9BQ2YsQ0FBQztNQUNELElBQUksQ0FBQ3NELEVBQUUsRUFBRSxPQUFPUixRQUFRLENBQUNvRCxRQUFRLENBQUM7UUFBRTNDLElBQUksRUFBRTtVQUFFRyxPQUFPLEVBQUU7UUFBb0I7TUFBRSxDQUFDLENBQUM7TUFDN0UsT0FBT1osUUFBUSxDQUFDUSxFQUFFLENBQUM7UUFBRUMsSUFBSSxFQUFFO1VBQUU0QyxPQUFPLEVBQUU7UUFBSztNQUFFLENBQUMsQ0FBQztJQUNqRCxDQUFDLENBQUMsT0FBTzFDLEtBQVUsRUFBRTtNQUNuQixPQUFPWCxRQUFRLENBQUNhLFdBQVcsQ0FBQztRQUFFQyxVQUFVLEVBQUUsR0FBRztRQUFFTCxJQUFJLEVBQUU7VUFBRUcsT0FBTyxFQUFFRCxLQUFLLENBQUNDO1FBQVE7TUFBRSxDQUFDLENBQUM7SUFDcEY7RUFDRixDQUNGLENBQUM7O0VBRUQ7RUFDQW5CLE1BQU0sQ0FBQzZELE1BQU0sQ0FDWDtJQUNFMUQsSUFBSSxFQUFFLHNEQUFzRDtJQUM1REMsUUFBUSxFQUFFO01BQUVvRCxNQUFNLEVBQUU5SCxvQkFBTSxDQUFDQyxNQUFNLENBQUM7UUFBRThILEtBQUssRUFBRS9ILG9CQUFNLENBQUNHLE1BQU0sQ0FBQztNQUFFLENBQUM7SUFBRTtFQUNoRSxDQUFDLEVBQ0QsT0FBT3dFLE9BQU8sRUFBRXlCLE9BQU8sRUFBRXZCLFFBQVEsS0FBSztJQUNwQyxJQUFJO01BQ0YsTUFBTUMsTUFBTSxHQUFHSCxPQUFPLENBQUNJLElBQUksQ0FBQ0MsVUFBVSxDQUFDRixNQUFNLENBQUNHLGFBQWE7TUFDM0QsTUFBTW9CLElBQUksR0FBRyxNQUFNLElBQUFDLHlCQUFrQixFQUFDeEIsTUFBTSxDQUFDO01BQzdDLE1BQU1PLEVBQUUsR0FBRyxNQUFNRixpQ0FBZSxDQUFDaUQsWUFBWSxDQUFDdEQsTUFBTSxFQUFFc0IsT0FBTyxDQUFDMEIsTUFBTSxDQUFDQyxLQUFLLENBQUM7TUFDM0UsSUFBSSxDQUFDMUMsRUFBRSxFQUFFLE9BQU9SLFFBQVEsQ0FBQ29ELFFBQVEsQ0FBQztRQUFFM0MsSUFBSSxFQUFFO1VBQUVHLE9BQU8sRUFBRTtRQUFvQjtNQUFFLENBQUMsQ0FBQztNQUM3RWxCLE1BQU0sQ0FBQ2tDLElBQUksQ0FBRSxXQUFVTCxPQUFPLENBQUMwQixNQUFNLENBQUNDLEtBQU0sZUFBYzFCLElBQUssRUFBQyxDQUFDO01BQ2pFLE9BQU94QixRQUFRLENBQUNRLEVBQUUsQ0FBQztRQUFFQyxJQUFJLEVBQUU7VUFBRTRDLE9BQU8sRUFBRTtRQUFLO01BQUUsQ0FBQyxDQUFDO0lBQ2pELENBQUMsQ0FBQyxPQUFPMUMsS0FBVSxFQUFFO01BQ25CLE9BQU9YLFFBQVEsQ0FBQ2EsV0FBVyxDQUFDO1FBQUVDLFVBQVUsRUFBRSxHQUFHO1FBQUVMLElBQUksRUFBRTtVQUFFRyxPQUFPLEVBQUVELEtBQUssQ0FBQ0M7UUFBUTtNQUFFLENBQUMsQ0FBQztJQUNwRjtFQUNGLENBQ0YsQ0FBQztBQUNIIn0=