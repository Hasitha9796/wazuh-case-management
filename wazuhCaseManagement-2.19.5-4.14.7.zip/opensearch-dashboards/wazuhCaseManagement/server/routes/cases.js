"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.registerCaseRoutes = registerCaseRoutes;
var _configSchema = require("@osd/config-schema");
var _case_service = require("../services/case_service");
var _users = require("./users");
/*
 * Wazuh Case Management Plugin
 * Case Routes: CRUD operations for cases
 */

function registerCaseRoutes(router, logger) {
  // ─── LIST CASES ─────────────────────────────────────────────
  router.get({
    path: '/api/wazuh-case-management/cases',
    validate: {
      query: _configSchema.schema.object({
        page: _configSchema.schema.maybe(_configSchema.schema.number({
          min: 1,
          defaultValue: 1
        })),
        per_page: _configSchema.schema.maybe(_configSchema.schema.number({
          min: 1,
          max: 100,
          defaultValue: 20
        })),
        sort_field: _configSchema.schema.maybe(_configSchema.schema.string({
          defaultValue: 'created_at'
        })),
        sort_order: _configSchema.schema.maybe(_configSchema.schema.oneOf([_configSchema.schema.literal('asc'), _configSchema.schema.literal('desc')], {
          defaultValue: 'desc'
        })),
        status: _configSchema.schema.maybe(_configSchema.schema.string()),
        severity: _configSchema.schema.maybe(_configSchema.schema.string()),
        priority: _configSchema.schema.maybe(_configSchema.schema.string()),
        category: _configSchema.schema.maybe(_configSchema.schema.string()),
        assignee: _configSchema.schema.maybe(_configSchema.schema.string()),
        search: _configSchema.schema.maybe(_configSchema.schema.string()),
        tags: _configSchema.schema.maybe(_configSchema.schema.string()),
        created_from: _configSchema.schema.maybe(_configSchema.schema.string()),
        created_to: _configSchema.schema.maybe(_configSchema.schema.string())
      })
    }
  }, async (context, request, response) => {
    try {
      const client = context.core.opensearch.client.asCurrentUser;
      const result = await _case_service.CaseService.listCases(client, request.query);
      return response.ok({
        body: result
      });
    } catch (error) {
      logger.error(`Error listing cases: ${error.message}`);
      return response.customError({
        statusCode: error.statusCode || 500,
        body: {
          message: error.message || 'Failed to list cases'
        }
      });
    }
  });

  // ─── GET CASE BY ID ─────────────────────────────────────────
  router.get({
    path: '/api/wazuh-case-management/cases/{id}',
    validate: {
      params: _configSchema.schema.object({
        id: _configSchema.schema.string()
      })
    }
  }, async (context, request, response) => {
    try {
      const client = context.core.opensearch.client.asCurrentUser;
      const caseDoc = await _case_service.CaseService.getCase(client, request.params.id);
      if (!caseDoc) {
        return response.notFound({
          body: {
            message: 'Case not found'
          }
        });
      }
      return response.ok({
        body: caseDoc
      });
    } catch (error) {
      logger.error(`Error getting case: ${error.message}`);
      return response.customError({
        statusCode: error.statusCode || 500,
        body: {
          message: error.message || 'Failed to get case'
        }
      });
    }
  });

  // ─── CREATE CASE ────────────────────────────────────────────
  router.post({
    path: '/api/wazuh-case-management/cases',
    validate: {
      body: _configSchema.schema.object({
        title: _configSchema.schema.string({
          minLength: 1,
          maxLength: 500
        }),
        description: _configSchema.schema.maybe(_configSchema.schema.string()),
        severity: _configSchema.schema.string(),
        priority: _configSchema.schema.string(),
        category: _configSchema.schema.string(),
        tlp: _configSchema.schema.maybe(_configSchema.schema.string()),
        tags: _configSchema.schema.maybe(_configSchema.schema.arrayOf(_configSchema.schema.string())),
        assignee: _configSchema.schema.maybe(_configSchema.schema.nullable(_configSchema.schema.string()))
      }, {
        unknowns: 'allow'
      })
    }
  }, async (context, request, response) => {
    try {
      const client = context.core.opensearch.client.asCurrentUser;
      const user = await (0, _users.getCurrentUsername)(client);
      const newCase = await _case_service.CaseService.createCase(client, request.body, user);
      return response.ok({
        body: newCase
      });
    } catch (error) {
      var _ref, _error$statusCode, _error$meta, _error$meta2;
      const status = (_ref = (_error$statusCode = error.statusCode) !== null && _error$statusCode !== void 0 ? _error$statusCode : (_error$meta = error.meta) === null || _error$meta === void 0 ? void 0 : _error$meta.statusCode) !== null && _ref !== void 0 ? _ref : 500;
      const detail = (_error$meta2 = error.meta) !== null && _error$meta2 !== void 0 && _error$meta2.body ? JSON.stringify(error.meta.body) : '';
      logger.error(`Error creating case [${status}]: ${error.message} ${detail}`);
      return response.customError({
        statusCode: status >= 400 && status < 600 ? status : 500,
        body: {
          message: `${error.message}${detail ? `: ${detail}` : ''}`
        }
      });
    }
  });

  // ─── UPDATE CASE ────────────────────────────────────────────
  router.put({
    path: '/api/wazuh-case-management/cases/{id}',
    validate: {
      params: _configSchema.schema.object({
        id: _configSchema.schema.string()
      }),
      body: _configSchema.schema.object({
        title: _configSchema.schema.maybe(_configSchema.schema.string({
          minLength: 1,
          maxLength: 500
        })),
        description: _configSchema.schema.maybe(_configSchema.schema.string()),
        severity: _configSchema.schema.maybe(_configSchema.schema.string()),
        priority: _configSchema.schema.maybe(_configSchema.schema.string()),
        category: _configSchema.schema.maybe(_configSchema.schema.string()),
        tlp: _configSchema.schema.maybe(_configSchema.schema.string()),
        tags: _configSchema.schema.maybe(_configSchema.schema.arrayOf(_configSchema.schema.string())),
        assignee: _configSchema.schema.maybe(_configSchema.schema.nullable(_configSchema.schema.string())),
        resolution_summary: _configSchema.schema.maybe(_configSchema.schema.nullable(_configSchema.schema.string()))
      }, {
        unknowns: 'allow'
      })
    }
  }, async (context, request, response) => {
    try {
      const client = context.core.opensearch.client.asCurrentUser;
      const user = await (0, _users.getCurrentUsername)(client);
      const updated = await _case_service.CaseService.updateCase(client, request.params.id, request.body, user);
      if (!updated) {
        return response.notFound({
          body: {
            message: 'Case not found'
          }
        });
      }
      return response.ok({
        body: updated
      });
    } catch (error) {
      logger.error(`Error updating case: ${error.message}`);
      return response.customError({
        statusCode: error.statusCode || 500,
        body: {
          message: error.message || 'Failed to update case'
        }
      });
    }
  });

  // ─── DELETE CASE ────────────────────────────────────────────
  router.delete({
    path: '/api/wazuh-case-management/cases/{id}',
    validate: {
      params: _configSchema.schema.object({
        id: _configSchema.schema.string()
      })
    }
  }, async (context, request, response) => {
    try {
      const client = context.core.opensearch.client.asCurrentUser;
      const user = await (0, _users.getCurrentUsername)(client);
      if (user !== 'admin') {
        return response.forbidden({
          body: {
            message: 'Only admin users can delete cases'
          }
        });
      }
      const deleted = await _case_service.CaseService.deleteCase(client, request.params.id);
      if (!deleted) {
        return response.notFound({
          body: {
            message: 'Case not found'
          }
        });
      }
      return response.ok({
        body: {
          message: 'Case deleted successfully'
        }
      });
    } catch (error) {
      logger.error(`Error deleting case: ${error.message}`);
      return response.customError({
        statusCode: error.statusCode || 500,
        body: {
          message: error.message || 'Failed to delete case'
        }
      });
    }
  });

  // ─── CHANGE STATUS ──────────────────────────────────────────
  router.post({
    path: '/api/wazuh-case-management/cases/{id}/status',
    validate: {
      params: _configSchema.schema.object({
        id: _configSchema.schema.string()
      }),
      body: _configSchema.schema.object({
        status: _configSchema.schema.string()
      })
    }
  }, async (context, request, response) => {
    try {
      const client = context.core.opensearch.client.asCurrentUser;
      const user = await (0, _users.getCurrentUsername)(client);
      const result = await _case_service.CaseService.changeStatus(client, request.params.id, request.body.status, user);
      if (!result.success) {
        return response.badRequest({
          body: {
            message: result.error
          }
        });
      }
      return response.ok({
        body: result.case
      });
    } catch (error) {
      logger.error(`Error changing case status: ${error.message}`);
      return response.customError({
        statusCode: error.statusCode || 500,
        body: {
          message: error.message || 'Failed to change status'
        }
      });
    }
  });

  // ─── ASSIGN CASE ────────────────────────────────────────────
  router.post({
    path: '/api/wazuh-case-management/cases/{id}/assign',
    validate: {
      params: _configSchema.schema.object({
        id: _configSchema.schema.string()
      }),
      body: _configSchema.schema.object({
        assignee: _configSchema.schema.nullable(_configSchema.schema.string())
      })
    }
  }, async (context, request, response) => {
    try {
      const client = context.core.opensearch.client.asCurrentUser;
      const user = await (0, _users.getCurrentUsername)(client);
      const updated = await _case_service.CaseService.assignCase(client, request.params.id, request.body.assignee, user);
      if (!updated) {
        return response.notFound({
          body: {
            message: 'Case not found'
          }
        });
      }
      return response.ok({
        body: updated
      });
    } catch (error) {
      logger.error(`Error assigning case: ${error.message}`);
      return response.customError({
        statusCode: error.statusCode || 500,
        body: {
          message: error.message || 'Failed to assign case'
        }
      });
    }
  });

  // ─── ADD TASK ────────────────────────────────────────────────
  router.post({
    path: '/api/wazuh-case-management/cases/{id}/tasks',
    validate: {
      params: _configSchema.schema.object({
        id: _configSchema.schema.string()
      }),
      body: _configSchema.schema.object({
        title: _configSchema.schema.string(),
        assigned_to: _configSchema.schema.maybe(_configSchema.schema.nullable(_configSchema.schema.string())),
        due_date: _configSchema.schema.maybe(_configSchema.schema.nullable(_configSchema.schema.string()))
      })
    }
  }, async (context, request, response) => {
    try {
      const client = context.core.opensearch.client.asCurrentUser;
      const user = await (0, _users.getCurrentUsername)(client);
      const updated = await _case_service.CaseService.addTask(client, request.params.id, {
        title: request.body.title,
        assigned_to: request.body.assigned_to,
        due_date: request.body.due_date
      }, user);
      return response.ok({
        body: updated
      });
    } catch (error) {
      return response.customError({
        statusCode: 500,
        body: {
          message: error.message
        }
      });
    }
  });

  // ─── UPDATE TASK (toggle, assign, due date, rename) ──────────
  router.patch({
    path: '/api/wazuh-case-management/cases/{id}/tasks/{taskId}',
    validate: {
      params: _configSchema.schema.object({
        id: _configSchema.schema.string(),
        taskId: _configSchema.schema.string()
      }),
      body: _configSchema.schema.object({
        completed: _configSchema.schema.maybe(_configSchema.schema.boolean()),
        title: _configSchema.schema.maybe(_configSchema.schema.string()),
        assigned_to: _configSchema.schema.maybe(_configSchema.schema.nullable(_configSchema.schema.string())),
        due_date: _configSchema.schema.maybe(_configSchema.schema.nullable(_configSchema.schema.string()))
      })
    }
  }, async (context, request, response) => {
    try {
      const client = context.core.opensearch.client.asCurrentUser;
      const user = await (0, _users.getCurrentUsername)(client);
      const {
        completed,
        ...fields
      } = request.body;

      // A request may toggle completion, change the task's fields, or both.
      let updated;
      if (Object.keys(fields).some(k => fields[k] !== undefined)) {
        updated = await _case_service.CaseService.updateTask(client, request.params.id, request.params.taskId, fields, user);
      }
      if (completed !== undefined) {
        updated = await _case_service.CaseService.toggleTask(client, request.params.id, request.params.taskId, completed, user);
      }
      if (!updated) {
        updated = await _case_service.CaseService.getCase(client, request.params.id);
      }
      return response.ok({
        body: updated
      });
    } catch (error) {
      return response.customError({
        statusCode: 500,
        body: {
          message: error.message
        }
      });
    }
  });

  // ─── REMOVE TASK ─────────────────────────────────────────────
  router.delete({
    path: '/api/wazuh-case-management/cases/{id}/tasks/{taskId}',
    validate: {
      params: _configSchema.schema.object({
        id: _configSchema.schema.string(),
        taskId: _configSchema.schema.string()
      })
    }
  }, async (context, request, response) => {
    try {
      const client = context.core.opensearch.client.asCurrentUser;
      const user = await (0, _users.getCurrentUsername)(client);
      const updated = await _case_service.CaseService.removeTask(client, request.params.id, request.params.taskId, user);
      return response.ok({
        body: updated
      });
    } catch (error) {
      return response.customError({
        statusCode: 500,
        body: {
          message: error.message
        }
      });
    }
  });

  // ─── SAVE NOTES ──────────────────────────────────────────────
  router.patch({
    path: '/api/wazuh-case-management/cases/{id}/notes',
    validate: {
      params: _configSchema.schema.object({
        id: _configSchema.schema.string()
      }),
      body: _configSchema.schema.object({
        notes: _configSchema.schema.string({
          defaultValue: ''
        })
      })
    }
  }, async (context, request, response) => {
    try {
      const client = context.core.opensearch.client.asCurrentUser;
      const user = await (0, _users.getCurrentUsername)(client);
      const updated = await _case_service.CaseService.updateNotes(client, request.params.id, request.body.notes, user);
      return response.ok({
        body: updated
      });
    } catch (error) {
      return response.customError({
        statusCode: 500,
        body: {
          message: error.message
        }
      });
    }
  });
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfY29uZmlnU2NoZW1hIiwicmVxdWlyZSIsIl9jYXNlX3NlcnZpY2UiLCJfdXNlcnMiLCJyZWdpc3RlckNhc2VSb3V0ZXMiLCJyb3V0ZXIiLCJsb2dnZXIiLCJnZXQiLCJwYXRoIiwidmFsaWRhdGUiLCJxdWVyeSIsInNjaGVtYSIsIm9iamVjdCIsInBhZ2UiLCJtYXliZSIsIm51bWJlciIsIm1pbiIsImRlZmF1bHRWYWx1ZSIsInBlcl9wYWdlIiwibWF4Iiwic29ydF9maWVsZCIsInN0cmluZyIsInNvcnRfb3JkZXIiLCJvbmVPZiIsImxpdGVyYWwiLCJzdGF0dXMiLCJzZXZlcml0eSIsInByaW9yaXR5IiwiY2F0ZWdvcnkiLCJhc3NpZ25lZSIsInNlYXJjaCIsInRhZ3MiLCJjcmVhdGVkX2Zyb20iLCJjcmVhdGVkX3RvIiwiY29udGV4dCIsInJlcXVlc3QiLCJyZXNwb25zZSIsImNsaWVudCIsImNvcmUiLCJvcGVuc2VhcmNoIiwiYXNDdXJyZW50VXNlciIsInJlc3VsdCIsIkNhc2VTZXJ2aWNlIiwibGlzdENhc2VzIiwib2siLCJib2R5IiwiZXJyb3IiLCJtZXNzYWdlIiwiY3VzdG9tRXJyb3IiLCJzdGF0dXNDb2RlIiwicGFyYW1zIiwiaWQiLCJjYXNlRG9jIiwiZ2V0Q2FzZSIsIm5vdEZvdW5kIiwicG9zdCIsInRpdGxlIiwibWluTGVuZ3RoIiwibWF4TGVuZ3RoIiwiZGVzY3JpcHRpb24iLCJ0bHAiLCJhcnJheU9mIiwibnVsbGFibGUiLCJ1bmtub3ducyIsInVzZXIiLCJnZXRDdXJyZW50VXNlcm5hbWUiLCJuZXdDYXNlIiwiY3JlYXRlQ2FzZSIsIl9yZWYiLCJfZXJyb3Ikc3RhdHVzQ29kZSIsIl9lcnJvciRtZXRhIiwiX2Vycm9yJG1ldGEyIiwibWV0YSIsImRldGFpbCIsIkpTT04iLCJzdHJpbmdpZnkiLCJwdXQiLCJyZXNvbHV0aW9uX3N1bW1hcnkiLCJ1cGRhdGVkIiwidXBkYXRlQ2FzZSIsImRlbGV0ZSIsImZvcmJpZGRlbiIsImRlbGV0ZWQiLCJkZWxldGVDYXNlIiwiY2hhbmdlU3RhdHVzIiwic3VjY2VzcyIsImJhZFJlcXVlc3QiLCJjYXNlIiwiYXNzaWduQ2FzZSIsImFzc2lnbmVkX3RvIiwiZHVlX2RhdGUiLCJhZGRUYXNrIiwicGF0Y2giLCJ0YXNrSWQiLCJjb21wbGV0ZWQiLCJib29sZWFuIiwiZmllbGRzIiwiT2JqZWN0Iiwia2V5cyIsInNvbWUiLCJrIiwidW5kZWZpbmVkIiwidXBkYXRlVGFzayIsInRvZ2dsZVRhc2siLCJyZW1vdmVUYXNrIiwibm90ZXMiLCJ1cGRhdGVOb3RlcyJdLCJzb3VyY2VzIjpbImNhc2VzLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qXG4gKiBXYXp1aCBDYXNlIE1hbmFnZW1lbnQgUGx1Z2luXG4gKiBDYXNlIFJvdXRlczogQ1JVRCBvcGVyYXRpb25zIGZvciBjYXNlc1xuICovXG5cbmltcG9ydCB7IElSb3V0ZXIsIExvZ2dlciB9IGZyb20gJy4uLy4uLy4uLy4uL3NyYy9jb3JlL3NlcnZlcic7XG5pbXBvcnQgeyBzY2hlbWEgfSBmcm9tICdAb3NkL2NvbmZpZy1zY2hlbWEnO1xuaW1wb3J0IHsgQ2FzZVNlcnZpY2UgfSBmcm9tICcuLi9zZXJ2aWNlcy9jYXNlX3NlcnZpY2UnO1xuaW1wb3J0IHsgZ2V0Q3VycmVudFVzZXJuYW1lIH0gZnJvbSAnLi91c2Vycyc7XG5cbmV4cG9ydCBmdW5jdGlvbiByZWdpc3RlckNhc2VSb3V0ZXMocm91dGVyOiBJUm91dGVyLCBsb2dnZXI6IExvZ2dlcik6IHZvaWQge1xuICAvLyDilIDilIDilIAgTElTVCBDQVNFUyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgcm91dGVyLmdldChcbiAgICB7XG4gICAgICBwYXRoOiAnL2FwaS93YXp1aC1jYXNlLW1hbmFnZW1lbnQvY2FzZXMnLFxuICAgICAgdmFsaWRhdGU6IHtcbiAgICAgICAgcXVlcnk6IHNjaGVtYS5vYmplY3Qoe1xuICAgICAgICAgIHBhZ2U6IHNjaGVtYS5tYXliZShzY2hlbWEubnVtYmVyKHsgbWluOiAxLCBkZWZhdWx0VmFsdWU6IDEgfSkpLFxuICAgICAgICAgIHBlcl9wYWdlOiBzY2hlbWEubWF5YmUoc2NoZW1hLm51bWJlcih7IG1pbjogMSwgbWF4OiAxMDAsIGRlZmF1bHRWYWx1ZTogMjAgfSkpLFxuICAgICAgICAgIHNvcnRfZmllbGQ6IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKHsgZGVmYXVsdFZhbHVlOiAnY3JlYXRlZF9hdCcgfSkpLFxuICAgICAgICAgIHNvcnRfb3JkZXI6IHNjaGVtYS5tYXliZShzY2hlbWEub25lT2YoW3NjaGVtYS5saXRlcmFsKCdhc2MnKSwgc2NoZW1hLmxpdGVyYWwoJ2Rlc2MnKV0sIHsgZGVmYXVsdFZhbHVlOiAnZGVzYycgfSkpLFxuICAgICAgICAgIHN0YXR1czogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXG4gICAgICAgICAgc2V2ZXJpdHk6IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICAgICAgICAgIHByaW9yaXR5OiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcbiAgICAgICAgICBjYXRlZ29yeTogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXG4gICAgICAgICAgYXNzaWduZWU6IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICAgICAgICAgIHNlYXJjaDogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXG4gICAgICAgICAgdGFnczogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXG4gICAgICAgICAgY3JlYXRlZF9mcm9tOiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcbiAgICAgICAgICBjcmVhdGVkX3RvOiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcXVlc3QsIHJlc3BvbnNlKSA9PiB7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBjbGllbnQgPSBjb250ZXh0LmNvcmUub3BlbnNlYXJjaC5jbGllbnQuYXNDdXJyZW50VXNlcjtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgQ2FzZVNlcnZpY2UubGlzdENhc2VzKGNsaWVudCwgcmVxdWVzdC5xdWVyeSk7XG4gICAgICAgIHJldHVybiByZXNwb25zZS5vayh7IGJvZHk6IHJlc3VsdCB9KTtcbiAgICAgIH0gY2F0Y2ggKGVycm9yOiBhbnkpIHtcbiAgICAgICAgbG9nZ2VyLmVycm9yKGBFcnJvciBsaXN0aW5nIGNhc2VzOiAke2Vycm9yLm1lc3NhZ2V9YCk7XG4gICAgICAgIHJldHVybiByZXNwb25zZS5jdXN0b21FcnJvcih7XG4gICAgICAgICAgc3RhdHVzQ29kZTogZXJyb3Iuc3RhdHVzQ29kZSB8fCA1MDAsXG4gICAgICAgICAgYm9keTogeyBtZXNzYWdlOiBlcnJvci5tZXNzYWdlIHx8ICdGYWlsZWQgdG8gbGlzdCBjYXNlcycgfSxcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfSxcbiAgKTtcblxuICAvLyDilIDilIDilIAgR0VUIENBU0UgQlkgSUQg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gIHJvdXRlci5nZXQoXG4gICAge1xuICAgICAgcGF0aDogJy9hcGkvd2F6dWgtY2FzZS1tYW5hZ2VtZW50L2Nhc2VzL3tpZH0nLFxuICAgICAgdmFsaWRhdGU6IHtcbiAgICAgICAgcGFyYW1zOiBzY2hlbWEub2JqZWN0KHtcbiAgICAgICAgICBpZDogc2NoZW1hLnN0cmluZygpLFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBhc3luYyAoY29udGV4dCwgcmVxdWVzdCwgcmVzcG9uc2UpID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGNsaWVudCA9IGNvbnRleHQuY29yZS5vcGVuc2VhcmNoLmNsaWVudC5hc0N1cnJlbnRVc2VyO1xuICAgICAgICBjb25zdCBjYXNlRG9jID0gYXdhaXQgQ2FzZVNlcnZpY2UuZ2V0Q2FzZShjbGllbnQsIHJlcXVlc3QucGFyYW1zLmlkKTtcbiAgICAgICAgaWYgKCFjYXNlRG9jKSB7XG4gICAgICAgICAgcmV0dXJuIHJlc3BvbnNlLm5vdEZvdW5kKHsgYm9keTogeyBtZXNzYWdlOiAnQ2FzZSBub3QgZm91bmQnIH0gfSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHsgYm9keTogY2FzZURvYyB9KTtcbiAgICAgIH0gY2F0Y2ggKGVycm9yOiBhbnkpIHtcbiAgICAgICAgbG9nZ2VyLmVycm9yKGBFcnJvciBnZXR0aW5nIGNhc2U6ICR7ZXJyb3IubWVzc2FnZX1gKTtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmN1c3RvbUVycm9yKHtcbiAgICAgICAgICBzdGF0dXNDb2RlOiBlcnJvci5zdGF0dXNDb2RlIHx8IDUwMCxcbiAgICAgICAgICBib2R5OiB7IG1lc3NhZ2U6IGVycm9yLm1lc3NhZ2UgfHwgJ0ZhaWxlZCB0byBnZXQgY2FzZScgfSxcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfSxcbiAgKTtcblxuICAvLyDilIDilIDilIAgQ1JFQVRFIENBU0Ug4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gIHJvdXRlci5wb3N0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL3dhenVoLWNhc2UtbWFuYWdlbWVudC9jYXNlcycsXG4gICAgICB2YWxpZGF0ZToge1xuICAgICAgICBib2R5OiBzY2hlbWEub2JqZWN0KHtcbiAgICAgICAgICB0aXRsZTogc2NoZW1hLnN0cmluZyh7IG1pbkxlbmd0aDogMSwgbWF4TGVuZ3RoOiA1MDAgfSksXG4gICAgICAgICAgZGVzY3JpcHRpb246IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICAgICAgICAgIHNldmVyaXR5OiBzY2hlbWEuc3RyaW5nKCksXG4gICAgICAgICAgcHJpb3JpdHk6IHNjaGVtYS5zdHJpbmcoKSxcbiAgICAgICAgICBjYXRlZ29yeTogc2NoZW1hLnN0cmluZygpLFxuICAgICAgICAgIHRscDogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXG4gICAgICAgICAgdGFnczogc2NoZW1hLm1heWJlKHNjaGVtYS5hcnJheU9mKHNjaGVtYS5zdHJpbmcoKSkpLFxuICAgICAgICAgIGFzc2lnbmVlOiBzY2hlbWEubWF5YmUoc2NoZW1hLm51bGxhYmxlKHNjaGVtYS5zdHJpbmcoKSkpLFxuICAgICAgICB9LCB7IHVua25vd25zOiAnYWxsb3cnIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIGFzeW5jIChjb250ZXh0LCByZXF1ZXN0LCByZXNwb25zZSkgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgY2xpZW50ID0gY29udGV4dC5jb3JlLm9wZW5zZWFyY2guY2xpZW50LmFzQ3VycmVudFVzZXI7XG4gICAgICAgIGNvbnN0IHVzZXIgPSBhd2FpdCBnZXRDdXJyZW50VXNlcm5hbWUoY2xpZW50KTtcbiAgICAgICAgY29uc3QgbmV3Q2FzZSA9IGF3YWl0IENhc2VTZXJ2aWNlLmNyZWF0ZUNhc2UoY2xpZW50LCByZXF1ZXN0LmJvZHksIHVzZXIpO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2Uub2soeyBib2R5OiBuZXdDYXNlIH0pO1xuICAgICAgfSBjYXRjaCAoZXJyb3I6IGFueSkge1xuICAgICAgICBjb25zdCBzdGF0dXMgPSBlcnJvci5zdGF0dXNDb2RlID8/IGVycm9yLm1ldGE/LnN0YXR1c0NvZGUgPz8gNTAwO1xuICAgICAgICBjb25zdCBkZXRhaWwgPSBlcnJvci5tZXRhPy5ib2R5ID8gSlNPTi5zdHJpbmdpZnkoZXJyb3IubWV0YS5ib2R5KSA6ICcnO1xuICAgICAgICBsb2dnZXIuZXJyb3IoYEVycm9yIGNyZWF0aW5nIGNhc2UgWyR7c3RhdHVzfV06ICR7ZXJyb3IubWVzc2FnZX0gJHtkZXRhaWx9YCk7XG4gICAgICAgIHJldHVybiByZXNwb25zZS5jdXN0b21FcnJvcih7XG4gICAgICAgICAgc3RhdHVzQ29kZTogc3RhdHVzID49IDQwMCAmJiBzdGF0dXMgPCA2MDAgPyBzdGF0dXMgOiA1MDAsXG4gICAgICAgICAgYm9keTogeyBtZXNzYWdlOiBgJHtlcnJvci5tZXNzYWdlfSR7ZGV0YWlsID8gYDogJHtkZXRhaWx9YCA6ICcnfWAgfSxcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfSxcbiAgKTtcblxuICAvLyDilIDilIDilIAgVVBEQVRFIENBU0Ug4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gIHJvdXRlci5wdXQoXG4gICAge1xuICAgICAgcGF0aDogJy9hcGkvd2F6dWgtY2FzZS1tYW5hZ2VtZW50L2Nhc2VzL3tpZH0nLFxuICAgICAgdmFsaWRhdGU6IHtcbiAgICAgICAgcGFyYW1zOiBzY2hlbWEub2JqZWN0KHtcbiAgICAgICAgICBpZDogc2NoZW1hLnN0cmluZygpLFxuICAgICAgICB9KSxcbiAgICAgICAgYm9keTogc2NoZW1hLm9iamVjdCh7XG4gICAgICAgICAgdGl0bGU6IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKHsgbWluTGVuZ3RoOiAxLCBtYXhMZW5ndGg6IDUwMCB9KSksXG4gICAgICAgICAgZGVzY3JpcHRpb246IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICAgICAgICAgIHNldmVyaXR5OiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcbiAgICAgICAgICBwcmlvcml0eTogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXG4gICAgICAgICAgY2F0ZWdvcnk6IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICAgICAgICAgIHRscDogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXG4gICAgICAgICAgdGFnczogc2NoZW1hLm1heWJlKHNjaGVtYS5hcnJheU9mKHNjaGVtYS5zdHJpbmcoKSkpLFxuICAgICAgICAgIGFzc2lnbmVlOiBzY2hlbWEubWF5YmUoc2NoZW1hLm51bGxhYmxlKHNjaGVtYS5zdHJpbmcoKSkpLFxuICAgICAgICAgIHJlc29sdXRpb25fc3VtbWFyeTogc2NoZW1hLm1heWJlKHNjaGVtYS5udWxsYWJsZShzY2hlbWEuc3RyaW5nKCkpKSxcbiAgICAgICAgfSwgeyB1bmtub3duczogJ2FsbG93JyB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBhc3luYyAoY29udGV4dCwgcmVxdWVzdCwgcmVzcG9uc2UpID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGNsaWVudCA9IGNvbnRleHQuY29yZS5vcGVuc2VhcmNoLmNsaWVudC5hc0N1cnJlbnRVc2VyO1xuICAgICAgICBjb25zdCB1c2VyID0gYXdhaXQgZ2V0Q3VycmVudFVzZXJuYW1lKGNsaWVudCk7XG4gICAgICAgIGNvbnN0IHVwZGF0ZWQgPSBhd2FpdCBDYXNlU2VydmljZS51cGRhdGVDYXNlKGNsaWVudCwgcmVxdWVzdC5wYXJhbXMuaWQsIHJlcXVlc3QuYm9keSwgdXNlcik7XG4gICAgICAgIGlmICghdXBkYXRlZCkge1xuICAgICAgICAgIHJldHVybiByZXNwb25zZS5ub3RGb3VuZCh7IGJvZHk6IHsgbWVzc2FnZTogJ0Nhc2Ugbm90IGZvdW5kJyB9IH0pO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXNwb25zZS5vayh7IGJvZHk6IHVwZGF0ZWQgfSk7XG4gICAgICB9IGNhdGNoIChlcnJvcjogYW55KSB7XG4gICAgICAgIGxvZ2dlci5lcnJvcihgRXJyb3IgdXBkYXRpbmcgY2FzZTogJHtlcnJvci5tZXNzYWdlfWApO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2UuY3VzdG9tRXJyb3Ioe1xuICAgICAgICAgIHN0YXR1c0NvZGU6IGVycm9yLnN0YXR1c0NvZGUgfHwgNTAwLFxuICAgICAgICAgIGJvZHk6IHsgbWVzc2FnZTogZXJyb3IubWVzc2FnZSB8fCAnRmFpbGVkIHRvIHVwZGF0ZSBjYXNlJyB9LFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9LFxuICApO1xuXG4gIC8vIOKUgOKUgOKUgCBERUxFVEUgQ0FTRSDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgcm91dGVyLmRlbGV0ZShcbiAgICB7XG4gICAgICBwYXRoOiAnL2FwaS93YXp1aC1jYXNlLW1hbmFnZW1lbnQvY2FzZXMve2lkfScsXG4gICAgICB2YWxpZGF0ZToge1xuICAgICAgICBwYXJhbXM6IHNjaGVtYS5vYmplY3Qoe1xuICAgICAgICAgIGlkOiBzY2hlbWEuc3RyaW5nKCksXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIGFzeW5jIChjb250ZXh0LCByZXF1ZXN0LCByZXNwb25zZSkgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgY2xpZW50ID0gY29udGV4dC5jb3JlLm9wZW5zZWFyY2guY2xpZW50LmFzQ3VycmVudFVzZXI7XG4gICAgICAgIGNvbnN0IHVzZXIgPSBhd2FpdCBnZXRDdXJyZW50VXNlcm5hbWUoY2xpZW50KTtcbiAgICAgICAgaWYgKHVzZXIgIT09ICdhZG1pbicpIHtcbiAgICAgICAgICByZXR1cm4gcmVzcG9uc2UuZm9yYmlkZGVuKHsgYm9keTogeyBtZXNzYWdlOiAnT25seSBhZG1pbiB1c2VycyBjYW4gZGVsZXRlIGNhc2VzJyB9IH0pO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGRlbGV0ZWQgPSBhd2FpdCBDYXNlU2VydmljZS5kZWxldGVDYXNlKGNsaWVudCwgcmVxdWVzdC5wYXJhbXMuaWQpO1xuICAgICAgICBpZiAoIWRlbGV0ZWQpIHtcbiAgICAgICAgICByZXR1cm4gcmVzcG9uc2Uubm90Rm91bmQoeyBib2R5OiB7IG1lc3NhZ2U6ICdDYXNlIG5vdCBmb3VuZCcgfSB9KTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzcG9uc2Uub2soeyBib2R5OiB7IG1lc3NhZ2U6ICdDYXNlIGRlbGV0ZWQgc3VjY2Vzc2Z1bGx5JyB9IH0pO1xuICAgICAgfSBjYXRjaCAoZXJyb3I6IGFueSkge1xuICAgICAgICBsb2dnZXIuZXJyb3IoYEVycm9yIGRlbGV0aW5nIGNhc2U6ICR7ZXJyb3IubWVzc2FnZX1gKTtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmN1c3RvbUVycm9yKHtcbiAgICAgICAgICBzdGF0dXNDb2RlOiBlcnJvci5zdGF0dXNDb2RlIHx8IDUwMCxcbiAgICAgICAgICBib2R5OiB7IG1lc3NhZ2U6IGVycm9yLm1lc3NhZ2UgfHwgJ0ZhaWxlZCB0byBkZWxldGUgY2FzZScgfSxcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfSxcbiAgKTtcblxuICAvLyDilIDilIDilIAgQ0hBTkdFIFNUQVRVUyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgcm91dGVyLnBvc3QoXG4gICAge1xuICAgICAgcGF0aDogJy9hcGkvd2F6dWgtY2FzZS1tYW5hZ2VtZW50L2Nhc2VzL3tpZH0vc3RhdHVzJyxcbiAgICAgIHZhbGlkYXRlOiB7XG4gICAgICAgIHBhcmFtczogc2NoZW1hLm9iamVjdCh7XG4gICAgICAgICAgaWQ6IHNjaGVtYS5zdHJpbmcoKSxcbiAgICAgICAgfSksXG4gICAgICAgIGJvZHk6IHNjaGVtYS5vYmplY3Qoe1xuICAgICAgICAgIHN0YXR1czogc2NoZW1hLnN0cmluZygpLFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBhc3luYyAoY29udGV4dCwgcmVxdWVzdCwgcmVzcG9uc2UpID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGNsaWVudCA9IGNvbnRleHQuY29yZS5vcGVuc2VhcmNoLmNsaWVudC5hc0N1cnJlbnRVc2VyO1xuICAgICAgICBjb25zdCB1c2VyID0gYXdhaXQgZ2V0Q3VycmVudFVzZXJuYW1lKGNsaWVudCk7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IENhc2VTZXJ2aWNlLmNoYW5nZVN0YXR1cyhcbiAgICAgICAgICBjbGllbnQsXG4gICAgICAgICAgcmVxdWVzdC5wYXJhbXMuaWQsXG4gICAgICAgICAgcmVxdWVzdC5ib2R5LnN0YXR1cyxcbiAgICAgICAgICB1c2VyLFxuICAgICAgICApO1xuICAgICAgICBpZiAoIXJlc3VsdC5zdWNjZXNzKSB7XG4gICAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmJhZFJlcXVlc3QoeyBib2R5OiB7IG1lc3NhZ2U6IHJlc3VsdC5lcnJvciB9IH0pO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXNwb25zZS5vayh7IGJvZHk6IHJlc3VsdC5jYXNlIH0pO1xuICAgICAgfSBjYXRjaCAoZXJyb3I6IGFueSkge1xuICAgICAgICBsb2dnZXIuZXJyb3IoYEVycm9yIGNoYW5naW5nIGNhc2Ugc3RhdHVzOiAke2Vycm9yLm1lc3NhZ2V9YCk7XG4gICAgICAgIHJldHVybiByZXNwb25zZS5jdXN0b21FcnJvcih7XG4gICAgICAgICAgc3RhdHVzQ29kZTogZXJyb3Iuc3RhdHVzQ29kZSB8fCA1MDAsXG4gICAgICAgICAgYm9keTogeyBtZXNzYWdlOiBlcnJvci5tZXNzYWdlIHx8ICdGYWlsZWQgdG8gY2hhbmdlIHN0YXR1cycgfSxcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfSxcbiAgKTtcblxuICAvLyDilIDilIDilIAgQVNTSUdOIENBU0Ug4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gIHJvdXRlci5wb3N0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL3dhenVoLWNhc2UtbWFuYWdlbWVudC9jYXNlcy97aWR9L2Fzc2lnbicsXG4gICAgICB2YWxpZGF0ZToge1xuICAgICAgICBwYXJhbXM6IHNjaGVtYS5vYmplY3Qoe1xuICAgICAgICAgIGlkOiBzY2hlbWEuc3RyaW5nKCksXG4gICAgICAgIH0pLFxuICAgICAgICBib2R5OiBzY2hlbWEub2JqZWN0KHtcbiAgICAgICAgICBhc3NpZ25lZTogc2NoZW1hLm51bGxhYmxlKHNjaGVtYS5zdHJpbmcoKSksXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIGFzeW5jIChjb250ZXh0LCByZXF1ZXN0LCByZXNwb25zZSkgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgY2xpZW50ID0gY29udGV4dC5jb3JlLm9wZW5zZWFyY2guY2xpZW50LmFzQ3VycmVudFVzZXI7XG4gICAgICAgIGNvbnN0IHVzZXIgPSBhd2FpdCBnZXRDdXJyZW50VXNlcm5hbWUoY2xpZW50KTtcbiAgICAgICAgY29uc3QgdXBkYXRlZCA9IGF3YWl0IENhc2VTZXJ2aWNlLmFzc2lnbkNhc2UoXG4gICAgICAgICAgY2xpZW50LFxuICAgICAgICAgIHJlcXVlc3QucGFyYW1zLmlkLFxuICAgICAgICAgIHJlcXVlc3QuYm9keS5hc3NpZ25lZSxcbiAgICAgICAgICB1c2VyLFxuICAgICAgICApO1xuICAgICAgICBpZiAoIXVwZGF0ZWQpIHtcbiAgICAgICAgICByZXR1cm4gcmVzcG9uc2Uubm90Rm91bmQoeyBib2R5OiB7IG1lc3NhZ2U6ICdDYXNlIG5vdCBmb3VuZCcgfSB9KTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzcG9uc2Uub2soeyBib2R5OiB1cGRhdGVkIH0pO1xuICAgICAgfSBjYXRjaCAoZXJyb3I6IGFueSkge1xuICAgICAgICBsb2dnZXIuZXJyb3IoYEVycm9yIGFzc2lnbmluZyBjYXNlOiAke2Vycm9yLm1lc3NhZ2V9YCk7XG4gICAgICAgIHJldHVybiByZXNwb25zZS5jdXN0b21FcnJvcih7XG4gICAgICAgICAgc3RhdHVzQ29kZTogZXJyb3Iuc3RhdHVzQ29kZSB8fCA1MDAsXG4gICAgICAgICAgYm9keTogeyBtZXNzYWdlOiBlcnJvci5tZXNzYWdlIHx8ICdGYWlsZWQgdG8gYXNzaWduIGNhc2UnIH0sXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH0sXG4gICk7XG5cbiAgLy8g4pSA4pSA4pSAIEFERCBUQVNLIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICByb3V0ZXIucG9zdChcbiAgICB7XG4gICAgICBwYXRoOiAnL2FwaS93YXp1aC1jYXNlLW1hbmFnZW1lbnQvY2FzZXMve2lkfS90YXNrcycsXG4gICAgICB2YWxpZGF0ZToge1xuICAgICAgICBwYXJhbXM6IHNjaGVtYS5vYmplY3Qoe1xuICAgICAgICAgIGlkOiBzY2hlbWEuc3RyaW5nKCksXG4gICAgICAgIH0pLFxuICAgICAgICBib2R5OiBzY2hlbWEub2JqZWN0KHtcbiAgICAgICAgICB0aXRsZTogc2NoZW1hLnN0cmluZygpLFxuICAgICAgICAgIGFzc2lnbmVkX3RvOiBzY2hlbWEubWF5YmUoc2NoZW1hLm51bGxhYmxlKHNjaGVtYS5zdHJpbmcoKSkpLFxuICAgICAgICAgIGR1ZV9kYXRlOiBzY2hlbWEubWF5YmUoc2NoZW1hLm51bGxhYmxlKHNjaGVtYS5zdHJpbmcoKSkpLFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBhc3luYyAoY29udGV4dCwgcmVxdWVzdCwgcmVzcG9uc2UpID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGNsaWVudCA9IGNvbnRleHQuY29yZS5vcGVuc2VhcmNoLmNsaWVudC5hc0N1cnJlbnRVc2VyO1xuICAgICAgICBjb25zdCB1c2VyID0gYXdhaXQgZ2V0Q3VycmVudFVzZXJuYW1lKGNsaWVudCk7XG4gICAgICAgIGNvbnN0IHVwZGF0ZWQgPSBhd2FpdCBDYXNlU2VydmljZS5hZGRUYXNrKFxuICAgICAgICAgIGNsaWVudCxcbiAgICAgICAgICByZXF1ZXN0LnBhcmFtcy5pZCxcbiAgICAgICAgICB7XG4gICAgICAgICAgICB0aXRsZTogcmVxdWVzdC5ib2R5LnRpdGxlLFxuICAgICAgICAgICAgYXNzaWduZWRfdG86IHJlcXVlc3QuYm9keS5hc3NpZ25lZF90byxcbiAgICAgICAgICAgIGR1ZV9kYXRlOiByZXF1ZXN0LmJvZHkuZHVlX2RhdGUsXG4gICAgICAgICAgfSxcbiAgICAgICAgICB1c2VyLFxuICAgICAgICApO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2Uub2soeyBib2R5OiB1cGRhdGVkIH0pO1xuICAgICAgfSBjYXRjaCAoZXJyb3I6IGFueSkge1xuICAgICAgICByZXR1cm4gcmVzcG9uc2UuY3VzdG9tRXJyb3IoeyBzdGF0dXNDb2RlOiA1MDAsIGJvZHk6IHsgbWVzc2FnZTogZXJyb3IubWVzc2FnZSB9IH0pO1xuICAgICAgfVxuICAgIH1cbiAgKTtcblxuICAvLyDilIDilIDilIAgVVBEQVRFIFRBU0sgKHRvZ2dsZSwgYXNzaWduLCBkdWUgZGF0ZSwgcmVuYW1lKSDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgcm91dGVyLnBhdGNoKFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL3dhenVoLWNhc2UtbWFuYWdlbWVudC9jYXNlcy97aWR9L3Rhc2tzL3t0YXNrSWR9JyxcbiAgICAgIHZhbGlkYXRlOiB7XG4gICAgICAgIHBhcmFtczogc2NoZW1hLm9iamVjdCh7XG4gICAgICAgICAgaWQ6IHNjaGVtYS5zdHJpbmcoKSxcbiAgICAgICAgICB0YXNrSWQ6IHNjaGVtYS5zdHJpbmcoKSxcbiAgICAgICAgfSksXG4gICAgICAgIGJvZHk6IHNjaGVtYS5vYmplY3Qoe1xuICAgICAgICAgIGNvbXBsZXRlZDogc2NoZW1hLm1heWJlKHNjaGVtYS5ib29sZWFuKCkpLFxuICAgICAgICAgIHRpdGxlOiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcbiAgICAgICAgICBhc3NpZ25lZF90bzogc2NoZW1hLm1heWJlKHNjaGVtYS5udWxsYWJsZShzY2hlbWEuc3RyaW5nKCkpKSxcbiAgICAgICAgICBkdWVfZGF0ZTogc2NoZW1hLm1heWJlKHNjaGVtYS5udWxsYWJsZShzY2hlbWEuc3RyaW5nKCkpKSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcXVlc3QsIHJlc3BvbnNlKSA9PiB7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBjbGllbnQgPSBjb250ZXh0LmNvcmUub3BlbnNlYXJjaC5jbGllbnQuYXNDdXJyZW50VXNlcjtcbiAgICAgICAgY29uc3QgdXNlciA9IGF3YWl0IGdldEN1cnJlbnRVc2VybmFtZShjbGllbnQpO1xuICAgICAgICBjb25zdCB7IGNvbXBsZXRlZCwgLi4uZmllbGRzIH0gPSByZXF1ZXN0LmJvZHk7XG5cbiAgICAgICAgLy8gQSByZXF1ZXN0IG1heSB0b2dnbGUgY29tcGxldGlvbiwgY2hhbmdlIHRoZSB0YXNrJ3MgZmllbGRzLCBvciBib3RoLlxuICAgICAgICBsZXQgdXBkYXRlZDtcbiAgICAgICAgaWYgKE9iamVjdC5rZXlzKGZpZWxkcykuc29tZSgoaykgPT4gKGZpZWxkcyBhcyBhbnkpW2tdICE9PSB1bmRlZmluZWQpKSB7XG4gICAgICAgICAgdXBkYXRlZCA9IGF3YWl0IENhc2VTZXJ2aWNlLnVwZGF0ZVRhc2soXG4gICAgICAgICAgICBjbGllbnQsXG4gICAgICAgICAgICByZXF1ZXN0LnBhcmFtcy5pZCxcbiAgICAgICAgICAgIHJlcXVlc3QucGFyYW1zLnRhc2tJZCxcbiAgICAgICAgICAgIGZpZWxkcyxcbiAgICAgICAgICAgIHVzZXIsXG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoY29tcGxldGVkICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICB1cGRhdGVkID0gYXdhaXQgQ2FzZVNlcnZpY2UudG9nZ2xlVGFzayhcbiAgICAgICAgICAgIGNsaWVudCxcbiAgICAgICAgICAgIHJlcXVlc3QucGFyYW1zLmlkLFxuICAgICAgICAgICAgcmVxdWVzdC5wYXJhbXMudGFza0lkLFxuICAgICAgICAgICAgY29tcGxldGVkLFxuICAgICAgICAgICAgdXNlcixcbiAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgICAgIGlmICghdXBkYXRlZCkge1xuICAgICAgICAgIHVwZGF0ZWQgPSBhd2FpdCBDYXNlU2VydmljZS5nZXRDYXNlKGNsaWVudCwgcmVxdWVzdC5wYXJhbXMuaWQpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXNwb25zZS5vayh7IGJvZHk6IHVwZGF0ZWQgfSk7XG4gICAgICB9IGNhdGNoIChlcnJvcjogYW55KSB7XG4gICAgICAgIHJldHVybiByZXNwb25zZS5jdXN0b21FcnJvcih7IHN0YXR1c0NvZGU6IDUwMCwgYm9keTogeyBtZXNzYWdlOiBlcnJvci5tZXNzYWdlIH0gfSk7XG4gICAgICB9XG4gICAgfVxuICApO1xuXG4gIC8vIOKUgOKUgOKUgCBSRU1PVkUgVEFTSyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgcm91dGVyLmRlbGV0ZShcbiAgICB7XG4gICAgICBwYXRoOiAnL2FwaS93YXp1aC1jYXNlLW1hbmFnZW1lbnQvY2FzZXMve2lkfS90YXNrcy97dGFza0lkfScsXG4gICAgICB2YWxpZGF0ZToge1xuICAgICAgICBwYXJhbXM6IHNjaGVtYS5vYmplY3Qoe1xuICAgICAgICAgIGlkOiBzY2hlbWEuc3RyaW5nKCksXG4gICAgICAgICAgdGFza0lkOiBzY2hlbWEuc3RyaW5nKCksXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIGFzeW5jIChjb250ZXh0LCByZXF1ZXN0LCByZXNwb25zZSkgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgY2xpZW50ID0gY29udGV4dC5jb3JlLm9wZW5zZWFyY2guY2xpZW50LmFzQ3VycmVudFVzZXI7XG4gICAgICAgIGNvbnN0IHVzZXIgPSBhd2FpdCBnZXRDdXJyZW50VXNlcm5hbWUoY2xpZW50KTtcbiAgICAgICAgY29uc3QgdXBkYXRlZCA9IGF3YWl0IENhc2VTZXJ2aWNlLnJlbW92ZVRhc2soY2xpZW50LCByZXF1ZXN0LnBhcmFtcy5pZCwgcmVxdWVzdC5wYXJhbXMudGFza0lkLCB1c2VyKTtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHsgYm9keTogdXBkYXRlZCB9KTtcbiAgICAgIH0gY2F0Y2ggKGVycm9yOiBhbnkpIHtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmN1c3RvbUVycm9yKHsgc3RhdHVzQ29kZTogNTAwLCBib2R5OiB7IG1lc3NhZ2U6IGVycm9yLm1lc3NhZ2UgfSB9KTtcbiAgICAgIH1cbiAgICB9XG4gICk7XG5cbiAgLy8g4pSA4pSA4pSAIFNBVkUgTk9URVMg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gIHJvdXRlci5wYXRjaChcbiAgICB7XG4gICAgICBwYXRoOiAnL2FwaS93YXp1aC1jYXNlLW1hbmFnZW1lbnQvY2FzZXMve2lkfS9ub3RlcycsXG4gICAgICB2YWxpZGF0ZToge1xuICAgICAgICBwYXJhbXM6IHNjaGVtYS5vYmplY3Qoe1xuICAgICAgICAgIGlkOiBzY2hlbWEuc3RyaW5nKCksXG4gICAgICAgIH0pLFxuICAgICAgICBib2R5OiBzY2hlbWEub2JqZWN0KHtcbiAgICAgICAgICBub3Rlczogc2NoZW1hLnN0cmluZyh7IGRlZmF1bHRWYWx1ZTogJycgfSksXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIGFzeW5jIChjb250ZXh0LCByZXF1ZXN0LCByZXNwb25zZSkgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgY2xpZW50ID0gY29udGV4dC5jb3JlLm9wZW5zZWFyY2guY2xpZW50LmFzQ3VycmVudFVzZXI7XG4gICAgICAgIGNvbnN0IHVzZXIgPSBhd2FpdCBnZXRDdXJyZW50VXNlcm5hbWUoY2xpZW50KTtcbiAgICAgICAgY29uc3QgdXBkYXRlZCA9IGF3YWl0IENhc2VTZXJ2aWNlLnVwZGF0ZU5vdGVzKGNsaWVudCwgcmVxdWVzdC5wYXJhbXMuaWQsIHJlcXVlc3QuYm9keS5ub3RlcywgdXNlcik7XG4gICAgICAgIHJldHVybiByZXNwb25zZS5vayh7IGJvZHk6IHVwZGF0ZWQgfSk7XG4gICAgICB9IGNhdGNoIChlcnJvcjogYW55KSB7XG4gICAgICAgIHJldHVybiByZXNwb25zZS5jdXN0b21FcnJvcih7IHN0YXR1c0NvZGU6IDUwMCwgYm9keTogeyBtZXNzYWdlOiBlcnJvci5tZXNzYWdlIH0gfSk7XG4gICAgICB9XG4gICAgfVxuICApO1xufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFNQSxJQUFBQSxhQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxhQUFBLEdBQUFELE9BQUE7QUFDQSxJQUFBRSxNQUFBLEdBQUFGLE9BQUE7QUFSQTtBQUNBO0FBQ0E7QUFDQTs7QUFPTyxTQUFTRyxrQkFBa0JBLENBQUNDLE1BQWUsRUFBRUMsTUFBYyxFQUFRO0VBQ3hFO0VBQ0FELE1BQU0sQ0FBQ0UsR0FBRyxDQUNSO0lBQ0VDLElBQUksRUFBRSxrQ0FBa0M7SUFDeENDLFFBQVEsRUFBRTtNQUNSQyxLQUFLLEVBQUVDLG9CQUFNLENBQUNDLE1BQU0sQ0FBQztRQUNuQkMsSUFBSSxFQUFFRixvQkFBTSxDQUFDRyxLQUFLLENBQUNILG9CQUFNLENBQUNJLE1BQU0sQ0FBQztVQUFFQyxHQUFHLEVBQUUsQ0FBQztVQUFFQyxZQUFZLEVBQUU7UUFBRSxDQUFDLENBQUMsQ0FBQztRQUM5REMsUUFBUSxFQUFFUCxvQkFBTSxDQUFDRyxLQUFLLENBQUNILG9CQUFNLENBQUNJLE1BQU0sQ0FBQztVQUFFQyxHQUFHLEVBQUUsQ0FBQztVQUFFRyxHQUFHLEVBQUUsR0FBRztVQUFFRixZQUFZLEVBQUU7UUFBRyxDQUFDLENBQUMsQ0FBQztRQUM3RUcsVUFBVSxFQUFFVCxvQkFBTSxDQUFDRyxLQUFLLENBQUNILG9CQUFNLENBQUNVLE1BQU0sQ0FBQztVQUFFSixZQUFZLEVBQUU7UUFBYSxDQUFDLENBQUMsQ0FBQztRQUN2RUssVUFBVSxFQUFFWCxvQkFBTSxDQUFDRyxLQUFLLENBQUNILG9CQUFNLENBQUNZLEtBQUssQ0FBQyxDQUFDWixvQkFBTSxDQUFDYSxPQUFPLENBQUMsS0FBSyxDQUFDLEVBQUViLG9CQUFNLENBQUNhLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFO1VBQUVQLFlBQVksRUFBRTtRQUFPLENBQUMsQ0FBQyxDQUFDO1FBQ2pIUSxNQUFNLEVBQUVkLG9CQUFNLENBQUNHLEtBQUssQ0FBQ0gsb0JBQU0sQ0FBQ1UsTUFBTSxDQUFDLENBQUMsQ0FBQztRQUNyQ0ssUUFBUSxFQUFFZixvQkFBTSxDQUFDRyxLQUFLLENBQUNILG9CQUFNLENBQUNVLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFDdkNNLFFBQVEsRUFBRWhCLG9CQUFNLENBQUNHLEtBQUssQ0FBQ0gsb0JBQU0sQ0FBQ1UsTUFBTSxDQUFDLENBQUMsQ0FBQztRQUN2Q08sUUFBUSxFQUFFakIsb0JBQU0sQ0FBQ0csS0FBSyxDQUFDSCxvQkFBTSxDQUFDVSxNQUFNLENBQUMsQ0FBQyxDQUFDO1FBQ3ZDUSxRQUFRLEVBQUVsQixvQkFBTSxDQUFDRyxLQUFLLENBQUNILG9CQUFNLENBQUNVLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFDdkNTLE1BQU0sRUFBRW5CLG9CQUFNLENBQUNHLEtBQUssQ0FBQ0gsb0JBQU0sQ0FBQ1UsTUFBTSxDQUFDLENBQUMsQ0FBQztRQUNyQ1UsSUFBSSxFQUFFcEIsb0JBQU0sQ0FBQ0csS0FBSyxDQUFDSCxvQkFBTSxDQUFDVSxNQUFNLENBQUMsQ0FBQyxDQUFDO1FBQ25DVyxZQUFZLEVBQUVyQixvQkFBTSxDQUFDRyxLQUFLLENBQUNILG9CQUFNLENBQUNVLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFDM0NZLFVBQVUsRUFBRXRCLG9CQUFNLENBQUNHLEtBQUssQ0FBQ0gsb0JBQU0sQ0FBQ1UsTUFBTSxDQUFDLENBQUM7TUFDMUMsQ0FBQztJQUNIO0VBQ0YsQ0FBQyxFQUNELE9BQU9hLE9BQU8sRUFBRUMsT0FBTyxFQUFFQyxRQUFRLEtBQUs7SUFDcEMsSUFBSTtNQUNGLE1BQU1DLE1BQU0sR0FBR0gsT0FBTyxDQUFDSSxJQUFJLENBQUNDLFVBQVUsQ0FBQ0YsTUFBTSxDQUFDRyxhQUFhO01BQzNELE1BQU1DLE1BQU0sR0FBRyxNQUFNQyx5QkFBVyxDQUFDQyxTQUFTLENBQUNOLE1BQU0sRUFBRUYsT0FBTyxDQUFDekIsS0FBSyxDQUFDO01BQ2pFLE9BQU8wQixRQUFRLENBQUNRLEVBQUUsQ0FBQztRQUFFQyxJQUFJLEVBQUVKO01BQU8sQ0FBQyxDQUFDO0lBQ3RDLENBQUMsQ0FBQyxPQUFPSyxLQUFVLEVBQUU7TUFDbkJ4QyxNQUFNLENBQUN3QyxLQUFLLENBQUUsd0JBQXVCQSxLQUFLLENBQUNDLE9BQVEsRUFBQyxDQUFDO01BQ3JELE9BQU9YLFFBQVEsQ0FBQ1ksV0FBVyxDQUFDO1FBQzFCQyxVQUFVLEVBQUVILEtBQUssQ0FBQ0csVUFBVSxJQUFJLEdBQUc7UUFDbkNKLElBQUksRUFBRTtVQUFFRSxPQUFPLEVBQUVELEtBQUssQ0FBQ0MsT0FBTyxJQUFJO1FBQXVCO01BQzNELENBQUMsQ0FBQztJQUNKO0VBQ0YsQ0FDRixDQUFDOztFQUVEO0VBQ0ExQyxNQUFNLENBQUNFLEdBQUcsQ0FDUjtJQUNFQyxJQUFJLEVBQUUsdUNBQXVDO0lBQzdDQyxRQUFRLEVBQUU7TUFDUnlDLE1BQU0sRUFBRXZDLG9CQUFNLENBQUNDLE1BQU0sQ0FBQztRQUNwQnVDLEVBQUUsRUFBRXhDLG9CQUFNLENBQUNVLE1BQU0sQ0FBQztNQUNwQixDQUFDO0lBQ0g7RUFDRixDQUFDLEVBQ0QsT0FBT2EsT0FBTyxFQUFFQyxPQUFPLEVBQUVDLFFBQVEsS0FBSztJQUNwQyxJQUFJO01BQ0YsTUFBTUMsTUFBTSxHQUFHSCxPQUFPLENBQUNJLElBQUksQ0FBQ0MsVUFBVSxDQUFDRixNQUFNLENBQUNHLGFBQWE7TUFDM0QsTUFBTVksT0FBTyxHQUFHLE1BQU1WLHlCQUFXLENBQUNXLE9BQU8sQ0FBQ2hCLE1BQU0sRUFBRUYsT0FBTyxDQUFDZSxNQUFNLENBQUNDLEVBQUUsQ0FBQztNQUNwRSxJQUFJLENBQUNDLE9BQU8sRUFBRTtRQUNaLE9BQU9oQixRQUFRLENBQUNrQixRQUFRLENBQUM7VUFBRVQsSUFBSSxFQUFFO1lBQUVFLE9BQU8sRUFBRTtVQUFpQjtRQUFFLENBQUMsQ0FBQztNQUNuRTtNQUNBLE9BQU9YLFFBQVEsQ0FBQ1EsRUFBRSxDQUFDO1FBQUVDLElBQUksRUFBRU87TUFBUSxDQUFDLENBQUM7SUFDdkMsQ0FBQyxDQUFDLE9BQU9OLEtBQVUsRUFBRTtNQUNuQnhDLE1BQU0sQ0FBQ3dDLEtBQUssQ0FBRSx1QkFBc0JBLEtBQUssQ0FBQ0MsT0FBUSxFQUFDLENBQUM7TUFDcEQsT0FBT1gsUUFBUSxDQUFDWSxXQUFXLENBQUM7UUFDMUJDLFVBQVUsRUFBRUgsS0FBSyxDQUFDRyxVQUFVLElBQUksR0FBRztRQUNuQ0osSUFBSSxFQUFFO1VBQUVFLE9BQU8sRUFBRUQsS0FBSyxDQUFDQyxPQUFPLElBQUk7UUFBcUI7TUFDekQsQ0FBQyxDQUFDO0lBQ0o7RUFDRixDQUNGLENBQUM7O0VBRUQ7RUFDQTFDLE1BQU0sQ0FBQ2tELElBQUksQ0FDVDtJQUNFL0MsSUFBSSxFQUFFLGtDQUFrQztJQUN4Q0MsUUFBUSxFQUFFO01BQ1JvQyxJQUFJLEVBQUVsQyxvQkFBTSxDQUFDQyxNQUFNLENBQUM7UUFDbEI0QyxLQUFLLEVBQUU3QyxvQkFBTSxDQUFDVSxNQUFNLENBQUM7VUFBRW9DLFNBQVMsRUFBRSxDQUFDO1VBQUVDLFNBQVMsRUFBRTtRQUFJLENBQUMsQ0FBQztRQUN0REMsV0FBVyxFQUFFaEQsb0JBQU0sQ0FBQ0csS0FBSyxDQUFDSCxvQkFBTSxDQUFDVSxNQUFNLENBQUMsQ0FBQyxDQUFDO1FBQzFDSyxRQUFRLEVBQUVmLG9CQUFNLENBQUNVLE1BQU0sQ0FBQyxDQUFDO1FBQ3pCTSxRQUFRLEVBQUVoQixvQkFBTSxDQUFDVSxNQUFNLENBQUMsQ0FBQztRQUN6Qk8sUUFBUSxFQUFFakIsb0JBQU0sQ0FBQ1UsTUFBTSxDQUFDLENBQUM7UUFDekJ1QyxHQUFHLEVBQUVqRCxvQkFBTSxDQUFDRyxLQUFLLENBQUNILG9CQUFNLENBQUNVLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFDbENVLElBQUksRUFBRXBCLG9CQUFNLENBQUNHLEtBQUssQ0FBQ0gsb0JBQU0sQ0FBQ2tELE9BQU8sQ0FBQ2xELG9CQUFNLENBQUNVLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUNuRFEsUUFBUSxFQUFFbEIsb0JBQU0sQ0FBQ0csS0FBSyxDQUFDSCxvQkFBTSxDQUFDbUQsUUFBUSxDQUFDbkQsb0JBQU0sQ0FBQ1UsTUFBTSxDQUFDLENBQUMsQ0FBQztNQUN6RCxDQUFDLEVBQUU7UUFBRTBDLFFBQVEsRUFBRTtNQUFRLENBQUM7SUFDMUI7RUFDRixDQUFDLEVBQ0QsT0FBTzdCLE9BQU8sRUFBRUMsT0FBTyxFQUFFQyxRQUFRLEtBQUs7SUFDcEMsSUFBSTtNQUNGLE1BQU1DLE1BQU0sR0FBR0gsT0FBTyxDQUFDSSxJQUFJLENBQUNDLFVBQVUsQ0FBQ0YsTUFBTSxDQUFDRyxhQUFhO01BQzNELE1BQU13QixJQUFJLEdBQUcsTUFBTSxJQUFBQyx5QkFBa0IsRUFBQzVCLE1BQU0sQ0FBQztNQUM3QyxNQUFNNkIsT0FBTyxHQUFHLE1BQU14Qix5QkFBVyxDQUFDeUIsVUFBVSxDQUFDOUIsTUFBTSxFQUFFRixPQUFPLENBQUNVLElBQUksRUFBRW1CLElBQUksQ0FBQztNQUN4RSxPQUFPNUIsUUFBUSxDQUFDUSxFQUFFLENBQUM7UUFBRUMsSUFBSSxFQUFFcUI7TUFBUSxDQUFDLENBQUM7SUFDdkMsQ0FBQyxDQUFDLE9BQU9wQixLQUFVLEVBQUU7TUFBQSxJQUFBc0IsSUFBQSxFQUFBQyxpQkFBQSxFQUFBQyxXQUFBLEVBQUFDLFlBQUE7TUFDbkIsTUFBTTlDLE1BQU0sSUFBQTJDLElBQUEsSUFBQUMsaUJBQUEsR0FBR3ZCLEtBQUssQ0FBQ0csVUFBVSxjQUFBb0IsaUJBQUEsY0FBQUEsaUJBQUEsSUFBQUMsV0FBQSxHQUFJeEIsS0FBSyxDQUFDMEIsSUFBSSxjQUFBRixXQUFBLHVCQUFWQSxXQUFBLENBQVlyQixVQUFVLGNBQUFtQixJQUFBLGNBQUFBLElBQUEsR0FBSSxHQUFHO01BQ2hFLE1BQU1LLE1BQU0sR0FBRyxDQUFBRixZQUFBLEdBQUF6QixLQUFLLENBQUMwQixJQUFJLGNBQUFELFlBQUEsZUFBVkEsWUFBQSxDQUFZMUIsSUFBSSxHQUFHNkIsSUFBSSxDQUFDQyxTQUFTLENBQUM3QixLQUFLLENBQUMwQixJQUFJLENBQUMzQixJQUFJLENBQUMsR0FBRyxFQUFFO01BQ3RFdkMsTUFBTSxDQUFDd0MsS0FBSyxDQUFFLHdCQUF1QnJCLE1BQU8sTUFBS3FCLEtBQUssQ0FBQ0MsT0FBUSxJQUFHMEIsTUFBTyxFQUFDLENBQUM7TUFDM0UsT0FBT3JDLFFBQVEsQ0FBQ1ksV0FBVyxDQUFDO1FBQzFCQyxVQUFVLEVBQUV4QixNQUFNLElBQUksR0FBRyxJQUFJQSxNQUFNLEdBQUcsR0FBRyxHQUFHQSxNQUFNLEdBQUcsR0FBRztRQUN4RG9CLElBQUksRUFBRTtVQUFFRSxPQUFPLEVBQUcsR0FBRUQsS0FBSyxDQUFDQyxPQUFRLEdBQUUwQixNQUFNLEdBQUksS0FBSUEsTUFBTyxFQUFDLEdBQUcsRUFBRztRQUFFO01BQ3BFLENBQUMsQ0FBQztJQUNKO0VBQ0YsQ0FDRixDQUFDOztFQUVEO0VBQ0FwRSxNQUFNLENBQUN1RSxHQUFHLENBQ1I7SUFDRXBFLElBQUksRUFBRSx1Q0FBdUM7SUFDN0NDLFFBQVEsRUFBRTtNQUNSeUMsTUFBTSxFQUFFdkMsb0JBQU0sQ0FBQ0MsTUFBTSxDQUFDO1FBQ3BCdUMsRUFBRSxFQUFFeEMsb0JBQU0sQ0FBQ1UsTUFBTSxDQUFDO01BQ3BCLENBQUMsQ0FBQztNQUNGd0IsSUFBSSxFQUFFbEMsb0JBQU0sQ0FBQ0MsTUFBTSxDQUFDO1FBQ2xCNEMsS0FBSyxFQUFFN0Msb0JBQU0sQ0FBQ0csS0FBSyxDQUFDSCxvQkFBTSxDQUFDVSxNQUFNLENBQUM7VUFBRW9DLFNBQVMsRUFBRSxDQUFDO1VBQUVDLFNBQVMsRUFBRTtRQUFJLENBQUMsQ0FBQyxDQUFDO1FBQ3BFQyxXQUFXLEVBQUVoRCxvQkFBTSxDQUFDRyxLQUFLLENBQUNILG9CQUFNLENBQUNVLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFDMUNLLFFBQVEsRUFBRWYsb0JBQU0sQ0FBQ0csS0FBSyxDQUFDSCxvQkFBTSxDQUFDVSxNQUFNLENBQUMsQ0FBQyxDQUFDO1FBQ3ZDTSxRQUFRLEVBQUVoQixvQkFBTSxDQUFDRyxLQUFLLENBQUNILG9CQUFNLENBQUNVLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFDdkNPLFFBQVEsRUFBRWpCLG9CQUFNLENBQUNHLEtBQUssQ0FBQ0gsb0JBQU0sQ0FBQ1UsTUFBTSxDQUFDLENBQUMsQ0FBQztRQUN2Q3VDLEdBQUcsRUFBRWpELG9CQUFNLENBQUNHLEtBQUssQ0FBQ0gsb0JBQU0sQ0FBQ1UsTUFBTSxDQUFDLENBQUMsQ0FBQztRQUNsQ1UsSUFBSSxFQUFFcEIsb0JBQU0sQ0FBQ0csS0FBSyxDQUFDSCxvQkFBTSxDQUFDa0QsT0FBTyxDQUFDbEQsb0JBQU0sQ0FBQ1UsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ25EUSxRQUFRLEVBQUVsQixvQkFBTSxDQUFDRyxLQUFLLENBQUNILG9CQUFNLENBQUNtRCxRQUFRLENBQUNuRCxvQkFBTSxDQUFDVSxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDeER3RCxrQkFBa0IsRUFBRWxFLG9CQUFNLENBQUNHLEtBQUssQ0FBQ0gsb0JBQU0sQ0FBQ21ELFFBQVEsQ0FBQ25ELG9CQUFNLENBQUNVLE1BQU0sQ0FBQyxDQUFDLENBQUM7TUFDbkUsQ0FBQyxFQUFFO1FBQUUwQyxRQUFRLEVBQUU7TUFBUSxDQUFDO0lBQzFCO0VBQ0YsQ0FBQyxFQUNELE9BQU83QixPQUFPLEVBQUVDLE9BQU8sRUFBRUMsUUFBUSxLQUFLO0lBQ3BDLElBQUk7TUFDRixNQUFNQyxNQUFNLEdBQUdILE9BQU8sQ0FBQ0ksSUFBSSxDQUFDQyxVQUFVLENBQUNGLE1BQU0sQ0FBQ0csYUFBYTtNQUMzRCxNQUFNd0IsSUFBSSxHQUFHLE1BQU0sSUFBQUMseUJBQWtCLEVBQUM1QixNQUFNLENBQUM7TUFDN0MsTUFBTXlDLE9BQU8sR0FBRyxNQUFNcEMseUJBQVcsQ0FBQ3FDLFVBQVUsQ0FBQzFDLE1BQU0sRUFBRUYsT0FBTyxDQUFDZSxNQUFNLENBQUNDLEVBQUUsRUFBRWhCLE9BQU8sQ0FBQ1UsSUFBSSxFQUFFbUIsSUFBSSxDQUFDO01BQzNGLElBQUksQ0FBQ2MsT0FBTyxFQUFFO1FBQ1osT0FBTzFDLFFBQVEsQ0FBQ2tCLFFBQVEsQ0FBQztVQUFFVCxJQUFJLEVBQUU7WUFBRUUsT0FBTyxFQUFFO1VBQWlCO1FBQUUsQ0FBQyxDQUFDO01BQ25FO01BQ0EsT0FBT1gsUUFBUSxDQUFDUSxFQUFFLENBQUM7UUFBRUMsSUFBSSxFQUFFaUM7TUFBUSxDQUFDLENBQUM7SUFDdkMsQ0FBQyxDQUFDLE9BQU9oQyxLQUFVLEVBQUU7TUFDbkJ4QyxNQUFNLENBQUN3QyxLQUFLLENBQUUsd0JBQXVCQSxLQUFLLENBQUNDLE9BQVEsRUFBQyxDQUFDO01BQ3JELE9BQU9YLFFBQVEsQ0FBQ1ksV0FBVyxDQUFDO1FBQzFCQyxVQUFVLEVBQUVILEtBQUssQ0FBQ0csVUFBVSxJQUFJLEdBQUc7UUFDbkNKLElBQUksRUFBRTtVQUFFRSxPQUFPLEVBQUVELEtBQUssQ0FBQ0MsT0FBTyxJQUFJO1FBQXdCO01BQzVELENBQUMsQ0FBQztJQUNKO0VBQ0YsQ0FDRixDQUFDOztFQUVEO0VBQ0ExQyxNQUFNLENBQUMyRSxNQUFNLENBQ1g7SUFDRXhFLElBQUksRUFBRSx1Q0FBdUM7SUFDN0NDLFFBQVEsRUFBRTtNQUNSeUMsTUFBTSxFQUFFdkMsb0JBQU0sQ0FBQ0MsTUFBTSxDQUFDO1FBQ3BCdUMsRUFBRSxFQUFFeEMsb0JBQU0sQ0FBQ1UsTUFBTSxDQUFDO01BQ3BCLENBQUM7SUFDSDtFQUNGLENBQUMsRUFDRCxPQUFPYSxPQUFPLEVBQUVDLE9BQU8sRUFBRUMsUUFBUSxLQUFLO0lBQ3BDLElBQUk7TUFDRixNQUFNQyxNQUFNLEdBQUdILE9BQU8sQ0FBQ0ksSUFBSSxDQUFDQyxVQUFVLENBQUNGLE1BQU0sQ0FBQ0csYUFBYTtNQUMzRCxNQUFNd0IsSUFBSSxHQUFHLE1BQU0sSUFBQUMseUJBQWtCLEVBQUM1QixNQUFNLENBQUM7TUFDN0MsSUFBSTJCLElBQUksS0FBSyxPQUFPLEVBQUU7UUFDcEIsT0FBTzVCLFFBQVEsQ0FBQzZDLFNBQVMsQ0FBQztVQUFFcEMsSUFBSSxFQUFFO1lBQUVFLE9BQU8sRUFBRTtVQUFvQztRQUFFLENBQUMsQ0FBQztNQUN2RjtNQUNBLE1BQU1tQyxPQUFPLEdBQUcsTUFBTXhDLHlCQUFXLENBQUN5QyxVQUFVLENBQUM5QyxNQUFNLEVBQUVGLE9BQU8sQ0FBQ2UsTUFBTSxDQUFDQyxFQUFFLENBQUM7TUFDdkUsSUFBSSxDQUFDK0IsT0FBTyxFQUFFO1FBQ1osT0FBTzlDLFFBQVEsQ0FBQ2tCLFFBQVEsQ0FBQztVQUFFVCxJQUFJLEVBQUU7WUFBRUUsT0FBTyxFQUFFO1VBQWlCO1FBQUUsQ0FBQyxDQUFDO01BQ25FO01BQ0EsT0FBT1gsUUFBUSxDQUFDUSxFQUFFLENBQUM7UUFBRUMsSUFBSSxFQUFFO1VBQUVFLE9BQU8sRUFBRTtRQUE0QjtNQUFFLENBQUMsQ0FBQztJQUN4RSxDQUFDLENBQUMsT0FBT0QsS0FBVSxFQUFFO01BQ25CeEMsTUFBTSxDQUFDd0MsS0FBSyxDQUFFLHdCQUF1QkEsS0FBSyxDQUFDQyxPQUFRLEVBQUMsQ0FBQztNQUNyRCxPQUFPWCxRQUFRLENBQUNZLFdBQVcsQ0FBQztRQUMxQkMsVUFBVSxFQUFFSCxLQUFLLENBQUNHLFVBQVUsSUFBSSxHQUFHO1FBQ25DSixJQUFJLEVBQUU7VUFBRUUsT0FBTyxFQUFFRCxLQUFLLENBQUNDLE9BQU8sSUFBSTtRQUF3QjtNQUM1RCxDQUFDLENBQUM7SUFDSjtFQUNGLENBQ0YsQ0FBQzs7RUFFRDtFQUNBMUMsTUFBTSxDQUFDa0QsSUFBSSxDQUNUO0lBQ0UvQyxJQUFJLEVBQUUsOENBQThDO0lBQ3BEQyxRQUFRLEVBQUU7TUFDUnlDLE1BQU0sRUFBRXZDLG9CQUFNLENBQUNDLE1BQU0sQ0FBQztRQUNwQnVDLEVBQUUsRUFBRXhDLG9CQUFNLENBQUNVLE1BQU0sQ0FBQztNQUNwQixDQUFDLENBQUM7TUFDRndCLElBQUksRUFBRWxDLG9CQUFNLENBQUNDLE1BQU0sQ0FBQztRQUNsQmEsTUFBTSxFQUFFZCxvQkFBTSxDQUFDVSxNQUFNLENBQUM7TUFDeEIsQ0FBQztJQUNIO0VBQ0YsQ0FBQyxFQUNELE9BQU9hLE9BQU8sRUFBRUMsT0FBTyxFQUFFQyxRQUFRLEtBQUs7SUFDcEMsSUFBSTtNQUNGLE1BQU1DLE1BQU0sR0FBR0gsT0FBTyxDQUFDSSxJQUFJLENBQUNDLFVBQVUsQ0FBQ0YsTUFBTSxDQUFDRyxhQUFhO01BQzNELE1BQU13QixJQUFJLEdBQUcsTUFBTSxJQUFBQyx5QkFBa0IsRUFBQzVCLE1BQU0sQ0FBQztNQUM3QyxNQUFNSSxNQUFNLEdBQUcsTUFBTUMseUJBQVcsQ0FBQzBDLFlBQVksQ0FDM0MvQyxNQUFNLEVBQ05GLE9BQU8sQ0FBQ2UsTUFBTSxDQUFDQyxFQUFFLEVBQ2pCaEIsT0FBTyxDQUFDVSxJQUFJLENBQUNwQixNQUFNLEVBQ25CdUMsSUFDRixDQUFDO01BQ0QsSUFBSSxDQUFDdkIsTUFBTSxDQUFDNEMsT0FBTyxFQUFFO1FBQ25CLE9BQU9qRCxRQUFRLENBQUNrRCxVQUFVLENBQUM7VUFBRXpDLElBQUksRUFBRTtZQUFFRSxPQUFPLEVBQUVOLE1BQU0sQ0FBQ0s7VUFBTTtRQUFFLENBQUMsQ0FBQztNQUNqRTtNQUNBLE9BQU9WLFFBQVEsQ0FBQ1EsRUFBRSxDQUFDO1FBQUVDLElBQUksRUFBRUosTUFBTSxDQUFDOEM7TUFBSyxDQUFDLENBQUM7SUFDM0MsQ0FBQyxDQUFDLE9BQU96QyxLQUFVLEVBQUU7TUFDbkJ4QyxNQUFNLENBQUN3QyxLQUFLLENBQUUsK0JBQThCQSxLQUFLLENBQUNDLE9BQVEsRUFBQyxDQUFDO01BQzVELE9BQU9YLFFBQVEsQ0FBQ1ksV0FBVyxDQUFDO1FBQzFCQyxVQUFVLEVBQUVILEtBQUssQ0FBQ0csVUFBVSxJQUFJLEdBQUc7UUFDbkNKLElBQUksRUFBRTtVQUFFRSxPQUFPLEVBQUVELEtBQUssQ0FBQ0MsT0FBTyxJQUFJO1FBQTBCO01BQzlELENBQUMsQ0FBQztJQUNKO0VBQ0YsQ0FDRixDQUFDOztFQUVEO0VBQ0ExQyxNQUFNLENBQUNrRCxJQUFJLENBQ1Q7SUFDRS9DLElBQUksRUFBRSw4Q0FBOEM7SUFDcERDLFFBQVEsRUFBRTtNQUNSeUMsTUFBTSxFQUFFdkMsb0JBQU0sQ0FBQ0MsTUFBTSxDQUFDO1FBQ3BCdUMsRUFBRSxFQUFFeEMsb0JBQU0sQ0FBQ1UsTUFBTSxDQUFDO01BQ3BCLENBQUMsQ0FBQztNQUNGd0IsSUFBSSxFQUFFbEMsb0JBQU0sQ0FBQ0MsTUFBTSxDQUFDO1FBQ2xCaUIsUUFBUSxFQUFFbEIsb0JBQU0sQ0FBQ21ELFFBQVEsQ0FBQ25ELG9CQUFNLENBQUNVLE1BQU0sQ0FBQyxDQUFDO01BQzNDLENBQUM7SUFDSDtFQUNGLENBQUMsRUFDRCxPQUFPYSxPQUFPLEVBQUVDLE9BQU8sRUFBRUMsUUFBUSxLQUFLO0lBQ3BDLElBQUk7TUFDRixNQUFNQyxNQUFNLEdBQUdILE9BQU8sQ0FBQ0ksSUFBSSxDQUFDQyxVQUFVLENBQUNGLE1BQU0sQ0FBQ0csYUFBYTtNQUMzRCxNQUFNd0IsSUFBSSxHQUFHLE1BQU0sSUFBQUMseUJBQWtCLEVBQUM1QixNQUFNLENBQUM7TUFDN0MsTUFBTXlDLE9BQU8sR0FBRyxNQUFNcEMseUJBQVcsQ0FBQzhDLFVBQVUsQ0FDMUNuRCxNQUFNLEVBQ05GLE9BQU8sQ0FBQ2UsTUFBTSxDQUFDQyxFQUFFLEVBQ2pCaEIsT0FBTyxDQUFDVSxJQUFJLENBQUNoQixRQUFRLEVBQ3JCbUMsSUFDRixDQUFDO01BQ0QsSUFBSSxDQUFDYyxPQUFPLEVBQUU7UUFDWixPQUFPMUMsUUFBUSxDQUFDa0IsUUFBUSxDQUFDO1VBQUVULElBQUksRUFBRTtZQUFFRSxPQUFPLEVBQUU7VUFBaUI7UUFBRSxDQUFDLENBQUM7TUFDbkU7TUFDQSxPQUFPWCxRQUFRLENBQUNRLEVBQUUsQ0FBQztRQUFFQyxJQUFJLEVBQUVpQztNQUFRLENBQUMsQ0FBQztJQUN2QyxDQUFDLENBQUMsT0FBT2hDLEtBQVUsRUFBRTtNQUNuQnhDLE1BQU0sQ0FBQ3dDLEtBQUssQ0FBRSx5QkFBd0JBLEtBQUssQ0FBQ0MsT0FBUSxFQUFDLENBQUM7TUFDdEQsT0FBT1gsUUFBUSxDQUFDWSxXQUFXLENBQUM7UUFDMUJDLFVBQVUsRUFBRUgsS0FBSyxDQUFDRyxVQUFVLElBQUksR0FBRztRQUNuQ0osSUFBSSxFQUFFO1VBQUVFLE9BQU8sRUFBRUQsS0FBSyxDQUFDQyxPQUFPLElBQUk7UUFBd0I7TUFDNUQsQ0FBQyxDQUFDO0lBQ0o7RUFDRixDQUNGLENBQUM7O0VBRUQ7RUFDQTFDLE1BQU0sQ0FBQ2tELElBQUksQ0FDVDtJQUNFL0MsSUFBSSxFQUFFLDZDQUE2QztJQUNuREMsUUFBUSxFQUFFO01BQ1J5QyxNQUFNLEVBQUV2QyxvQkFBTSxDQUFDQyxNQUFNLENBQUM7UUFDcEJ1QyxFQUFFLEVBQUV4QyxvQkFBTSxDQUFDVSxNQUFNLENBQUM7TUFDcEIsQ0FBQyxDQUFDO01BQ0Z3QixJQUFJLEVBQUVsQyxvQkFBTSxDQUFDQyxNQUFNLENBQUM7UUFDbEI0QyxLQUFLLEVBQUU3QyxvQkFBTSxDQUFDVSxNQUFNLENBQUMsQ0FBQztRQUN0Qm9FLFdBQVcsRUFBRTlFLG9CQUFNLENBQUNHLEtBQUssQ0FBQ0gsb0JBQU0sQ0FBQ21ELFFBQVEsQ0FBQ25ELG9CQUFNLENBQUNVLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUMzRHFFLFFBQVEsRUFBRS9FLG9CQUFNLENBQUNHLEtBQUssQ0FBQ0gsb0JBQU0sQ0FBQ21ELFFBQVEsQ0FBQ25ELG9CQUFNLENBQUNVLE1BQU0sQ0FBQyxDQUFDLENBQUM7TUFDekQsQ0FBQztJQUNIO0VBQ0YsQ0FBQyxFQUNELE9BQU9hLE9BQU8sRUFBRUMsT0FBTyxFQUFFQyxRQUFRLEtBQUs7SUFDcEMsSUFBSTtNQUNGLE1BQU1DLE1BQU0sR0FBR0gsT0FBTyxDQUFDSSxJQUFJLENBQUNDLFVBQVUsQ0FBQ0YsTUFBTSxDQUFDRyxhQUFhO01BQzNELE1BQU13QixJQUFJLEdBQUcsTUFBTSxJQUFBQyx5QkFBa0IsRUFBQzVCLE1BQU0sQ0FBQztNQUM3QyxNQUFNeUMsT0FBTyxHQUFHLE1BQU1wQyx5QkFBVyxDQUFDaUQsT0FBTyxDQUN2Q3RELE1BQU0sRUFDTkYsT0FBTyxDQUFDZSxNQUFNLENBQUNDLEVBQUUsRUFDakI7UUFDRUssS0FBSyxFQUFFckIsT0FBTyxDQUFDVSxJQUFJLENBQUNXLEtBQUs7UUFDekJpQyxXQUFXLEVBQUV0RCxPQUFPLENBQUNVLElBQUksQ0FBQzRDLFdBQVc7UUFDckNDLFFBQVEsRUFBRXZELE9BQU8sQ0FBQ1UsSUFBSSxDQUFDNkM7TUFDekIsQ0FBQyxFQUNEMUIsSUFDRixDQUFDO01BQ0QsT0FBTzVCLFFBQVEsQ0FBQ1EsRUFBRSxDQUFDO1FBQUVDLElBQUksRUFBRWlDO01BQVEsQ0FBQyxDQUFDO0lBQ3ZDLENBQUMsQ0FBQyxPQUFPaEMsS0FBVSxFQUFFO01BQ25CLE9BQU9WLFFBQVEsQ0FBQ1ksV0FBVyxDQUFDO1FBQUVDLFVBQVUsRUFBRSxHQUFHO1FBQUVKLElBQUksRUFBRTtVQUFFRSxPQUFPLEVBQUVELEtBQUssQ0FBQ0M7UUFBUTtNQUFFLENBQUMsQ0FBQztJQUNwRjtFQUNGLENBQ0YsQ0FBQzs7RUFFRDtFQUNBMUMsTUFBTSxDQUFDdUYsS0FBSyxDQUNWO0lBQ0VwRixJQUFJLEVBQUUsc0RBQXNEO0lBQzVEQyxRQUFRLEVBQUU7TUFDUnlDLE1BQU0sRUFBRXZDLG9CQUFNLENBQUNDLE1BQU0sQ0FBQztRQUNwQnVDLEVBQUUsRUFBRXhDLG9CQUFNLENBQUNVLE1BQU0sQ0FBQyxDQUFDO1FBQ25Cd0UsTUFBTSxFQUFFbEYsb0JBQU0sQ0FBQ1UsTUFBTSxDQUFDO01BQ3hCLENBQUMsQ0FBQztNQUNGd0IsSUFBSSxFQUFFbEMsb0JBQU0sQ0FBQ0MsTUFBTSxDQUFDO1FBQ2xCa0YsU0FBUyxFQUFFbkYsb0JBQU0sQ0FBQ0csS0FBSyxDQUFDSCxvQkFBTSxDQUFDb0YsT0FBTyxDQUFDLENBQUMsQ0FBQztRQUN6Q3ZDLEtBQUssRUFBRTdDLG9CQUFNLENBQUNHLEtBQUssQ0FBQ0gsb0JBQU0sQ0FBQ1UsTUFBTSxDQUFDLENBQUMsQ0FBQztRQUNwQ29FLFdBQVcsRUFBRTlFLG9CQUFNLENBQUNHLEtBQUssQ0FBQ0gsb0JBQU0sQ0FBQ21ELFFBQVEsQ0FBQ25ELG9CQUFNLENBQUNVLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUMzRHFFLFFBQVEsRUFBRS9FLG9CQUFNLENBQUNHLEtBQUssQ0FBQ0gsb0JBQU0sQ0FBQ21ELFFBQVEsQ0FBQ25ELG9CQUFNLENBQUNVLE1BQU0sQ0FBQyxDQUFDLENBQUM7TUFDekQsQ0FBQztJQUNIO0VBQ0YsQ0FBQyxFQUNELE9BQU9hLE9BQU8sRUFBRUMsT0FBTyxFQUFFQyxRQUFRLEtBQUs7SUFDcEMsSUFBSTtNQUNGLE1BQU1DLE1BQU0sR0FBR0gsT0FBTyxDQUFDSSxJQUFJLENBQUNDLFVBQVUsQ0FBQ0YsTUFBTSxDQUFDRyxhQUFhO01BQzNELE1BQU13QixJQUFJLEdBQUcsTUFBTSxJQUFBQyx5QkFBa0IsRUFBQzVCLE1BQU0sQ0FBQztNQUM3QyxNQUFNO1FBQUV5RCxTQUFTO1FBQUUsR0FBR0U7TUFBTyxDQUFDLEdBQUc3RCxPQUFPLENBQUNVLElBQUk7O01BRTdDO01BQ0EsSUFBSWlDLE9BQU87TUFDWCxJQUFJbUIsTUFBTSxDQUFDQyxJQUFJLENBQUNGLE1BQU0sQ0FBQyxDQUFDRyxJQUFJLENBQUVDLENBQUMsSUFBTUosTUFBTSxDQUFTSSxDQUFDLENBQUMsS0FBS0MsU0FBUyxDQUFDLEVBQUU7UUFDckV2QixPQUFPLEdBQUcsTUFBTXBDLHlCQUFXLENBQUM0RCxVQUFVLENBQ3BDakUsTUFBTSxFQUNORixPQUFPLENBQUNlLE1BQU0sQ0FBQ0MsRUFBRSxFQUNqQmhCLE9BQU8sQ0FBQ2UsTUFBTSxDQUFDMkMsTUFBTSxFQUNyQkcsTUFBTSxFQUNOaEMsSUFDRixDQUFDO01BQ0g7TUFDQSxJQUFJOEIsU0FBUyxLQUFLTyxTQUFTLEVBQUU7UUFDM0J2QixPQUFPLEdBQUcsTUFBTXBDLHlCQUFXLENBQUM2RCxVQUFVLENBQ3BDbEUsTUFBTSxFQUNORixPQUFPLENBQUNlLE1BQU0sQ0FBQ0MsRUFBRSxFQUNqQmhCLE9BQU8sQ0FBQ2UsTUFBTSxDQUFDMkMsTUFBTSxFQUNyQkMsU0FBUyxFQUNUOUIsSUFDRixDQUFDO01BQ0g7TUFDQSxJQUFJLENBQUNjLE9BQU8sRUFBRTtRQUNaQSxPQUFPLEdBQUcsTUFBTXBDLHlCQUFXLENBQUNXLE9BQU8sQ0FBQ2hCLE1BQU0sRUFBRUYsT0FBTyxDQUFDZSxNQUFNLENBQUNDLEVBQUUsQ0FBQztNQUNoRTtNQUNBLE9BQU9mLFFBQVEsQ0FBQ1EsRUFBRSxDQUFDO1FBQUVDLElBQUksRUFBRWlDO01BQVEsQ0FBQyxDQUFDO0lBQ3ZDLENBQUMsQ0FBQyxPQUFPaEMsS0FBVSxFQUFFO01BQ25CLE9BQU9WLFFBQVEsQ0FBQ1ksV0FBVyxDQUFDO1FBQUVDLFVBQVUsRUFBRSxHQUFHO1FBQUVKLElBQUksRUFBRTtVQUFFRSxPQUFPLEVBQUVELEtBQUssQ0FBQ0M7UUFBUTtNQUFFLENBQUMsQ0FBQztJQUNwRjtFQUNGLENBQ0YsQ0FBQzs7RUFFRDtFQUNBMUMsTUFBTSxDQUFDMkUsTUFBTSxDQUNYO0lBQ0V4RSxJQUFJLEVBQUUsc0RBQXNEO0lBQzVEQyxRQUFRLEVBQUU7TUFDUnlDLE1BQU0sRUFBRXZDLG9CQUFNLENBQUNDLE1BQU0sQ0FBQztRQUNwQnVDLEVBQUUsRUFBRXhDLG9CQUFNLENBQUNVLE1BQU0sQ0FBQyxDQUFDO1FBQ25Cd0UsTUFBTSxFQUFFbEYsb0JBQU0sQ0FBQ1UsTUFBTSxDQUFDO01BQ3hCLENBQUM7SUFDSDtFQUNGLENBQUMsRUFDRCxPQUFPYSxPQUFPLEVBQUVDLE9BQU8sRUFBRUMsUUFBUSxLQUFLO0lBQ3BDLElBQUk7TUFDRixNQUFNQyxNQUFNLEdBQUdILE9BQU8sQ0FBQ0ksSUFBSSxDQUFDQyxVQUFVLENBQUNGLE1BQU0sQ0FBQ0csYUFBYTtNQUMzRCxNQUFNd0IsSUFBSSxHQUFHLE1BQU0sSUFBQUMseUJBQWtCLEVBQUM1QixNQUFNLENBQUM7TUFDN0MsTUFBTXlDLE9BQU8sR0FBRyxNQUFNcEMseUJBQVcsQ0FBQzhELFVBQVUsQ0FBQ25FLE1BQU0sRUFBRUYsT0FBTyxDQUFDZSxNQUFNLENBQUNDLEVBQUUsRUFBRWhCLE9BQU8sQ0FBQ2UsTUFBTSxDQUFDMkMsTUFBTSxFQUFFN0IsSUFBSSxDQUFDO01BQ3BHLE9BQU81QixRQUFRLENBQUNRLEVBQUUsQ0FBQztRQUFFQyxJQUFJLEVBQUVpQztNQUFRLENBQUMsQ0FBQztJQUN2QyxDQUFDLENBQUMsT0FBT2hDLEtBQVUsRUFBRTtNQUNuQixPQUFPVixRQUFRLENBQUNZLFdBQVcsQ0FBQztRQUFFQyxVQUFVLEVBQUUsR0FBRztRQUFFSixJQUFJLEVBQUU7VUFBRUUsT0FBTyxFQUFFRCxLQUFLLENBQUNDO1FBQVE7TUFBRSxDQUFDLENBQUM7SUFDcEY7RUFDRixDQUNGLENBQUM7O0VBRUQ7RUFDQTFDLE1BQU0sQ0FBQ3VGLEtBQUssQ0FDVjtJQUNFcEYsSUFBSSxFQUFFLDZDQUE2QztJQUNuREMsUUFBUSxFQUFFO01BQ1J5QyxNQUFNLEVBQUV2QyxvQkFBTSxDQUFDQyxNQUFNLENBQUM7UUFDcEJ1QyxFQUFFLEVBQUV4QyxvQkFBTSxDQUFDVSxNQUFNLENBQUM7TUFDcEIsQ0FBQyxDQUFDO01BQ0Z3QixJQUFJLEVBQUVsQyxvQkFBTSxDQUFDQyxNQUFNLENBQUM7UUFDbEI2RixLQUFLLEVBQUU5RixvQkFBTSxDQUFDVSxNQUFNLENBQUM7VUFBRUosWUFBWSxFQUFFO1FBQUcsQ0FBQztNQUMzQyxDQUFDO0lBQ0g7RUFDRixDQUFDLEVBQ0QsT0FBT2lCLE9BQU8sRUFBRUMsT0FBTyxFQUFFQyxRQUFRLEtBQUs7SUFDcEMsSUFBSTtNQUNGLE1BQU1DLE1BQU0sR0FBR0gsT0FBTyxDQUFDSSxJQUFJLENBQUNDLFVBQVUsQ0FBQ0YsTUFBTSxDQUFDRyxhQUFhO01BQzNELE1BQU13QixJQUFJLEdBQUcsTUFBTSxJQUFBQyx5QkFBa0IsRUFBQzVCLE1BQU0sQ0FBQztNQUM3QyxNQUFNeUMsT0FBTyxHQUFHLE1BQU1wQyx5QkFBVyxDQUFDZ0UsV0FBVyxDQUFDckUsTUFBTSxFQUFFRixPQUFPLENBQUNlLE1BQU0sQ0FBQ0MsRUFBRSxFQUFFaEIsT0FBTyxDQUFDVSxJQUFJLENBQUM0RCxLQUFLLEVBQUV6QyxJQUFJLENBQUM7TUFDbEcsT0FBTzVCLFFBQVEsQ0FBQ1EsRUFBRSxDQUFDO1FBQUVDLElBQUksRUFBRWlDO01BQVEsQ0FBQyxDQUFDO0lBQ3ZDLENBQUMsQ0FBQyxPQUFPaEMsS0FBVSxFQUFFO01BQ25CLE9BQU9WLFFBQVEsQ0FBQ1ksV0FBVyxDQUFDO1FBQUVDLFVBQVUsRUFBRSxHQUFHO1FBQUVKLElBQUksRUFBRTtVQUFFRSxPQUFPLEVBQUVELEtBQUssQ0FBQ0M7UUFBUTtNQUFFLENBQUMsQ0FBQztJQUNwRjtFQUNGLENBQ0YsQ0FBQztBQUNIIn0=