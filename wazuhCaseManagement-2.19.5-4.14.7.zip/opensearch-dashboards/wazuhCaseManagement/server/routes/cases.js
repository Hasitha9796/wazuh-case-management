"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.registerCaseRoutes = registerCaseRoutes;
var _configSchema = require("@osd/config-schema");
var _case_service = require("../services/case_service");
var _users = require("./users");
/*
 * Wazuh Case Management Plugin
 * Case Routes — CRUD operations for cases
 */

function registerCaseRoutes(router, logger) {
  // ─── LIST CASES ─────────────────────────────────────────────
  router.get({
    path: '/api/wazuh-case-management/cases',
    validate: {
      query: _configSchema.schema.object({
        page: _configSchema.schema.maybe(_configSchema.schema.number({
          min: 1,
          defaultValue: 1
        })),
        per_page: _configSchema.schema.maybe(_configSchema.schema.number({
          min: 1,
          max: 100,
          defaultValue: 20
        })),
        sort_field: _configSchema.schema.maybe(_configSchema.schema.string({
          defaultValue: 'created_at'
        })),
        sort_order: _configSchema.schema.maybe(_configSchema.schema.oneOf([_configSchema.schema.literal('asc'), _configSchema.schema.literal('desc')], {
          defaultValue: 'desc'
        })),
        status: _configSchema.schema.maybe(_configSchema.schema.string()),
        severity: _configSchema.schema.maybe(_configSchema.schema.string()),
        priority: _configSchema.schema.maybe(_configSchema.schema.string()),
        category: _configSchema.schema.maybe(_configSchema.schema.string()),
        assignee: _configSchema.schema.maybe(_configSchema.schema.string()),
        search: _configSchema.schema.maybe(_configSchema.schema.string()),
        tags: _configSchema.schema.maybe(_configSchema.schema.string()),
        created_from: _configSchema.schema.maybe(_configSchema.schema.string()),
        created_to: _configSchema.schema.maybe(_configSchema.schema.string())
      })
    }
  }, async (context, request, response) => {
    try {
      const client = context.core.opensearch.client.asCurrentUser;
      const result = await _case_service.CaseService.listCases(client, request.query);
      return response.ok({
        body: result
      });
    } catch (error) {
      logger.error(`Error listing cases: ${error.message}`);
      return response.customError({
        statusCode: error.statusCode || 500,
        body: {
          message: error.message || 'Failed to list cases'
        }
      });
    }
  });

  // ─── GET CASE BY ID ─────────────────────────────────────────
  router.get({
    path: '/api/wazuh-case-management/cases/{id}',
    validate: {
      params: _configSchema.schema.object({
        id: _configSchema.schema.string()
      })
    }
  }, async (context, request, response) => {
    try {
      const client = context.core.opensearch.client.asCurrentUser;
      const caseDoc = await _case_service.CaseService.getCase(client, request.params.id);
      if (!caseDoc) {
        return response.notFound({
          body: {
            message: 'Case not found'
          }
        });
      }
      return response.ok({
        body: caseDoc
      });
    } catch (error) {
      logger.error(`Error getting case: ${error.message}`);
      return response.customError({
        statusCode: error.statusCode || 500,
        body: {
          message: error.message || 'Failed to get case'
        }
      });
    }
  });

  // ─── CREATE CASE ────────────────────────────────────────────
  router.post({
    path: '/api/wazuh-case-management/cases',
    validate: {
      body: _configSchema.schema.object({
        title: _configSchema.schema.string({
          minLength: 1,
          maxLength: 500
        }),
        description: _configSchema.schema.maybe(_configSchema.schema.string()),
        severity: _configSchema.schema.string(),
        priority: _configSchema.schema.string(),
        category: _configSchema.schema.string(),
        tlp: _configSchema.schema.maybe(_configSchema.schema.string()),
        tags: _configSchema.schema.maybe(_configSchema.schema.arrayOf(_configSchema.schema.string())),
        assignee: _configSchema.schema.maybe(_configSchema.schema.nullable(_configSchema.schema.string()))
      }, {
        unknowns: 'allow'
      })
    }
  }, async (context, request, response) => {
    try {
      const client = context.core.opensearch.client.asCurrentUser;
      const user = await (0, _users.getCurrentUsername)(client);
      const newCase = await _case_service.CaseService.createCase(client, request.body, user);
      return response.ok({
        body: newCase
      });
    } catch (error) {
      var _ref, _error$statusCode, _error$meta, _error$meta2;
      const status = (_ref = (_error$statusCode = error.statusCode) !== null && _error$statusCode !== void 0 ? _error$statusCode : (_error$meta = error.meta) === null || _error$meta === void 0 ? void 0 : _error$meta.statusCode) !== null && _ref !== void 0 ? _ref : 500;
      const detail = (_error$meta2 = error.meta) !== null && _error$meta2 !== void 0 && _error$meta2.body ? JSON.stringify(error.meta.body) : '';
      logger.error(`Error creating case [${status}]: ${error.message} ${detail}`);
      return response.customError({
        statusCode: status >= 400 && status < 600 ? status : 500,
        body: {
          message: `${error.message}${detail ? ` — ${detail}` : ''}`
        }
      });
    }
  });

  // ─── UPDATE CASE ────────────────────────────────────────────
  router.put({
    path: '/api/wazuh-case-management/cases/{id}',
    validate: {
      params: _configSchema.schema.object({
        id: _configSchema.schema.string()
      }),
      body: _configSchema.schema.object({
        title: _configSchema.schema.maybe(_configSchema.schema.string({
          minLength: 1,
          maxLength: 500
        })),
        description: _configSchema.schema.maybe(_configSchema.schema.string()),
        severity: _configSchema.schema.maybe(_configSchema.schema.string()),
        priority: _configSchema.schema.maybe(_configSchema.schema.string()),
        category: _configSchema.schema.maybe(_configSchema.schema.string()),
        tlp: _configSchema.schema.maybe(_configSchema.schema.string()),
        tags: _configSchema.schema.maybe(_configSchema.schema.arrayOf(_configSchema.schema.string())),
        assignee: _configSchema.schema.maybe(_configSchema.schema.nullable(_configSchema.schema.string())),
        resolution_summary: _configSchema.schema.maybe(_configSchema.schema.nullable(_configSchema.schema.string()))
      }, {
        unknowns: 'allow'
      })
    }
  }, async (context, request, response) => {
    try {
      const client = context.core.opensearch.client.asCurrentUser;
      const user = await (0, _users.getCurrentUsername)(client);
      const updated = await _case_service.CaseService.updateCase(client, request.params.id, request.body, user);
      if (!updated) {
        return response.notFound({
          body: {
            message: 'Case not found'
          }
        });
      }
      return response.ok({
        body: updated
      });
    } catch (error) {
      logger.error(`Error updating case: ${error.message}`);
      return response.customError({
        statusCode: error.statusCode || 500,
        body: {
          message: error.message || 'Failed to update case'
        }
      });
    }
  });

  // ─── DELETE CASE ────────────────────────────────────────────
  router.delete({
    path: '/api/wazuh-case-management/cases/{id}',
    validate: {
      params: _configSchema.schema.object({
        id: _configSchema.schema.string()
      })
    }
  }, async (context, request, response) => {
    try {
      const client = context.core.opensearch.client.asCurrentUser;
      const user = await (0, _users.getCurrentUsername)(client);
      if (user !== 'admin') {
        return response.forbidden({
          body: {
            message: 'Only admin users can delete cases'
          }
        });
      }
      const deleted = await _case_service.CaseService.deleteCase(client, request.params.id);
      if (!deleted) {
        return response.notFound({
          body: {
            message: 'Case not found'
          }
        });
      }
      return response.ok({
        body: {
          message: 'Case deleted successfully'
        }
      });
    } catch (error) {
      logger.error(`Error deleting case: ${error.message}`);
      return response.customError({
        statusCode: error.statusCode || 500,
        body: {
          message: error.message || 'Failed to delete case'
        }
      });
    }
  });

  // ─── CHANGE STATUS ──────────────────────────────────────────
  router.post({
    path: '/api/wazuh-case-management/cases/{id}/status',
    validate: {
      params: _configSchema.schema.object({
        id: _configSchema.schema.string()
      }),
      body: _configSchema.schema.object({
        status: _configSchema.schema.string()
      })
    }
  }, async (context, request, response) => {
    try {
      const client = context.core.opensearch.client.asCurrentUser;
      const user = await (0, _users.getCurrentUsername)(client);
      const result = await _case_service.CaseService.changeStatus(client, request.params.id, request.body.status, user);
      if (!result.success) {
        return response.badRequest({
          body: {
            message: result.error
          }
        });
      }
      return response.ok({
        body: result.case
      });
    } catch (error) {
      logger.error(`Error changing case status: ${error.message}`);
      return response.customError({
        statusCode: error.statusCode || 500,
        body: {
          message: error.message || 'Failed to change status'
        }
      });
    }
  });

  // ─── ASSIGN CASE ────────────────────────────────────────────
  router.post({
    path: '/api/wazuh-case-management/cases/{id}/assign',
    validate: {
      params: _configSchema.schema.object({
        id: _configSchema.schema.string()
      }),
      body: _configSchema.schema.object({
        assignee: _configSchema.schema.nullable(_configSchema.schema.string())
      })
    }
  }, async (context, request, response) => {
    try {
      const client = context.core.opensearch.client.asCurrentUser;
      const user = await (0, _users.getCurrentUsername)(client);
      const updated = await _case_service.CaseService.assignCase(client, request.params.id, request.body.assignee, user);
      if (!updated) {
        return response.notFound({
          body: {
            message: 'Case not found'
          }
        });
      }
      return response.ok({
        body: updated
      });
    } catch (error) {
      logger.error(`Error assigning case: ${error.message}`);
      return response.customError({
        statusCode: error.statusCode || 500,
        body: {
          message: error.message || 'Failed to assign case'
        }
      });
    }
  });

  // ─── ADD TASK ────────────────────────────────────────────────
  router.post({
    path: '/api/wazuh-case-management/cases/{id}/tasks',
    validate: {
      params: _configSchema.schema.object({
        id: _configSchema.schema.string()
      }),
      body: _configSchema.schema.object({
        title: _configSchema.schema.string()
      })
    }
  }, async (context, request, response) => {
    try {
      const client = context.core.opensearch.client.asCurrentUser;
      const user = await (0, _users.getCurrentUsername)(client);
      const updated = await _case_service.CaseService.addTask(client, request.params.id, request.body.title, user);
      return response.ok({
        body: updated
      });
    } catch (error) {
      return response.customError({
        statusCode: 500,
        body: {
          message: error.message
        }
      });
    }
  });

  // ─── TOGGLE TASK ─────────────────────────────────────────────
  router.patch({
    path: '/api/wazuh-case-management/cases/{id}/tasks/{taskId}',
    validate: {
      params: _configSchema.schema.object({
        id: _configSchema.schema.string(),
        taskId: _configSchema.schema.string()
      }),
      body: _configSchema.schema.object({
        completed: _configSchema.schema.boolean()
      })
    }
  }, async (context, request, response) => {
    try {
      const client = context.core.opensearch.client.asCurrentUser;
      const user = await (0, _users.getCurrentUsername)(client);
      const updated = await _case_service.CaseService.toggleTask(client, request.params.id, request.params.taskId, request.body.completed, user);
      return response.ok({
        body: updated
      });
    } catch (error) {
      return response.customError({
        statusCode: 500,
        body: {
          message: error.message
        }
      });
    }
  });

  // ─── REMOVE TASK ─────────────────────────────────────────────
  router.delete({
    path: '/api/wazuh-case-management/cases/{id}/tasks/{taskId}',
    validate: {
      params: _configSchema.schema.object({
        id: _configSchema.schema.string(),
        taskId: _configSchema.schema.string()
      })
    }
  }, async (context, request, response) => {
    try {
      const client = context.core.opensearch.client.asCurrentUser;
      const user = await (0, _users.getCurrentUsername)(client);
      const updated = await _case_service.CaseService.removeTask(client, request.params.id, request.params.taskId, user);
      return response.ok({
        body: updated
      });
    } catch (error) {
      return response.customError({
        statusCode: 500,
        body: {
          message: error.message
        }
      });
    }
  });

  // ─── SAVE NOTES ──────────────────────────────────────────────
  router.patch({
    path: '/api/wazuh-case-management/cases/{id}/notes',
    validate: {
      params: _configSchema.schema.object({
        id: _configSchema.schema.string()
      }),
      body: _configSchema.schema.object({
        notes: _configSchema.schema.string({
          defaultValue: ''
        })
      })
    }
  }, async (context, request, response) => {
    try {
      const client = context.core.opensearch.client.asCurrentUser;
      const user = await (0, _users.getCurrentUsername)(client);
      const updated = await _case_service.CaseService.updateNotes(client, request.params.id, request.body.notes, user);
      return response.ok({
        body: updated
      });
    } catch (error) {
      return response.customError({
        statusCode: 500,
        body: {
          message: error.message
        }
      });
    }
  });
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfY29uZmlnU2NoZW1hIiwicmVxdWlyZSIsIl9jYXNlX3NlcnZpY2UiLCJfdXNlcnMiLCJyZWdpc3RlckNhc2VSb3V0ZXMiLCJyb3V0ZXIiLCJsb2dnZXIiLCJnZXQiLCJwYXRoIiwidmFsaWRhdGUiLCJxdWVyeSIsInNjaGVtYSIsIm9iamVjdCIsInBhZ2UiLCJtYXliZSIsIm51bWJlciIsIm1pbiIsImRlZmF1bHRWYWx1ZSIsInBlcl9wYWdlIiwibWF4Iiwic29ydF9maWVsZCIsInN0cmluZyIsInNvcnRfb3JkZXIiLCJvbmVPZiIsImxpdGVyYWwiLCJzdGF0dXMiLCJzZXZlcml0eSIsInByaW9yaXR5IiwiY2F0ZWdvcnkiLCJhc3NpZ25lZSIsInNlYXJjaCIsInRhZ3MiLCJjcmVhdGVkX2Zyb20iLCJjcmVhdGVkX3RvIiwiY29udGV4dCIsInJlcXVlc3QiLCJyZXNwb25zZSIsImNsaWVudCIsImNvcmUiLCJvcGVuc2VhcmNoIiwiYXNDdXJyZW50VXNlciIsInJlc3VsdCIsIkNhc2VTZXJ2aWNlIiwibGlzdENhc2VzIiwib2siLCJib2R5IiwiZXJyb3IiLCJtZXNzYWdlIiwiY3VzdG9tRXJyb3IiLCJzdGF0dXNDb2RlIiwicGFyYW1zIiwiaWQiLCJjYXNlRG9jIiwiZ2V0Q2FzZSIsIm5vdEZvdW5kIiwicG9zdCIsInRpdGxlIiwibWluTGVuZ3RoIiwibWF4TGVuZ3RoIiwiZGVzY3JpcHRpb24iLCJ0bHAiLCJhcnJheU9mIiwibnVsbGFibGUiLCJ1bmtub3ducyIsInVzZXIiLCJnZXRDdXJyZW50VXNlcm5hbWUiLCJuZXdDYXNlIiwiY3JlYXRlQ2FzZSIsIl9yZWYiLCJfZXJyb3Ikc3RhdHVzQ29kZSIsIl9lcnJvciRtZXRhIiwiX2Vycm9yJG1ldGEyIiwibWV0YSIsImRldGFpbCIsIkpTT04iLCJzdHJpbmdpZnkiLCJwdXQiLCJyZXNvbHV0aW9uX3N1bW1hcnkiLCJ1cGRhdGVkIiwidXBkYXRlQ2FzZSIsImRlbGV0ZSIsImZvcmJpZGRlbiIsImRlbGV0ZWQiLCJkZWxldGVDYXNlIiwiY2hhbmdlU3RhdHVzIiwic3VjY2VzcyIsImJhZFJlcXVlc3QiLCJjYXNlIiwiYXNzaWduQ2FzZSIsImFkZFRhc2siLCJwYXRjaCIsInRhc2tJZCIsImNvbXBsZXRlZCIsImJvb2xlYW4iLCJ0b2dnbGVUYXNrIiwicmVtb3ZlVGFzayIsIm5vdGVzIiwidXBkYXRlTm90ZXMiXSwic291cmNlcyI6WyJjYXNlcy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogV2F6dWggQ2FzZSBNYW5hZ2VtZW50IFBsdWdpblxuICogQ2FzZSBSb3V0ZXMg4oCUIENSVUQgb3BlcmF0aW9ucyBmb3IgY2FzZXNcbiAqL1xuXG5pbXBvcnQgeyBJUm91dGVyLCBMb2dnZXIgfSBmcm9tICcuLi8uLi8uLi8uLi9zcmMvY29yZS9zZXJ2ZXInO1xuaW1wb3J0IHsgc2NoZW1hIH0gZnJvbSAnQG9zZC9jb25maWctc2NoZW1hJztcbmltcG9ydCB7IENhc2VTZXJ2aWNlIH0gZnJvbSAnLi4vc2VydmljZXMvY2FzZV9zZXJ2aWNlJztcbmltcG9ydCB7IGdldEN1cnJlbnRVc2VybmFtZSB9IGZyb20gJy4vdXNlcnMnO1xuXG5leHBvcnQgZnVuY3Rpb24gcmVnaXN0ZXJDYXNlUm91dGVzKHJvdXRlcjogSVJvdXRlciwgbG9nZ2VyOiBMb2dnZXIpOiB2b2lkIHtcbiAgLy8g4pSA4pSA4pSAIExJU1QgQ0FTRVMg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gIHJvdXRlci5nZXQoXG4gICAge1xuICAgICAgcGF0aDogJy9hcGkvd2F6dWgtY2FzZS1tYW5hZ2VtZW50L2Nhc2VzJyxcbiAgICAgIHZhbGlkYXRlOiB7XG4gICAgICAgIHF1ZXJ5OiBzY2hlbWEub2JqZWN0KHtcbiAgICAgICAgICBwYWdlOiBzY2hlbWEubWF5YmUoc2NoZW1hLm51bWJlcih7IG1pbjogMSwgZGVmYXVsdFZhbHVlOiAxIH0pKSxcbiAgICAgICAgICBwZXJfcGFnZTogc2NoZW1hLm1heWJlKHNjaGVtYS5udW1iZXIoeyBtaW46IDEsIG1heDogMTAwLCBkZWZhdWx0VmFsdWU6IDIwIH0pKSxcbiAgICAgICAgICBzb3J0X2ZpZWxkOiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZyh7IGRlZmF1bHRWYWx1ZTogJ2NyZWF0ZWRfYXQnIH0pKSxcbiAgICAgICAgICBzb3J0X29yZGVyOiBzY2hlbWEubWF5YmUoc2NoZW1hLm9uZU9mKFtzY2hlbWEubGl0ZXJhbCgnYXNjJyksIHNjaGVtYS5saXRlcmFsKCdkZXNjJyldLCB7IGRlZmF1bHRWYWx1ZTogJ2Rlc2MnIH0pKSxcbiAgICAgICAgICBzdGF0dXM6IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICAgICAgICAgIHNldmVyaXR5OiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcbiAgICAgICAgICBwcmlvcml0eTogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXG4gICAgICAgICAgY2F0ZWdvcnk6IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICAgICAgICAgIGFzc2lnbmVlOiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcbiAgICAgICAgICBzZWFyY2g6IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICAgICAgICAgIHRhZ3M6IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICAgICAgICAgIGNyZWF0ZWRfZnJvbTogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXG4gICAgICAgICAgY3JlYXRlZF90bzogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIGFzeW5jIChjb250ZXh0LCByZXF1ZXN0LCByZXNwb25zZSkgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgY2xpZW50ID0gY29udGV4dC5jb3JlLm9wZW5zZWFyY2guY2xpZW50LmFzQ3VycmVudFVzZXI7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IENhc2VTZXJ2aWNlLmxpc3RDYXNlcyhjbGllbnQsIHJlcXVlc3QucXVlcnkpO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2Uub2soeyBib2R5OiByZXN1bHQgfSk7XG4gICAgICB9IGNhdGNoIChlcnJvcjogYW55KSB7XG4gICAgICAgIGxvZ2dlci5lcnJvcihgRXJyb3IgbGlzdGluZyBjYXNlczogJHtlcnJvci5tZXNzYWdlfWApO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2UuY3VzdG9tRXJyb3Ioe1xuICAgICAgICAgIHN0YXR1c0NvZGU6IGVycm9yLnN0YXR1c0NvZGUgfHwgNTAwLFxuICAgICAgICAgIGJvZHk6IHsgbWVzc2FnZTogZXJyb3IubWVzc2FnZSB8fCAnRmFpbGVkIHRvIGxpc3QgY2FzZXMnIH0sXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH0sXG4gICk7XG5cbiAgLy8g4pSA4pSA4pSAIEdFVCBDQVNFIEJZIElEIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICByb3V0ZXIuZ2V0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL3dhenVoLWNhc2UtbWFuYWdlbWVudC9jYXNlcy97aWR9JyxcbiAgICAgIHZhbGlkYXRlOiB7XG4gICAgICAgIHBhcmFtczogc2NoZW1hLm9iamVjdCh7XG4gICAgICAgICAgaWQ6IHNjaGVtYS5zdHJpbmcoKSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcXVlc3QsIHJlc3BvbnNlKSA9PiB7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBjbGllbnQgPSBjb250ZXh0LmNvcmUub3BlbnNlYXJjaC5jbGllbnQuYXNDdXJyZW50VXNlcjtcbiAgICAgICAgY29uc3QgY2FzZURvYyA9IGF3YWl0IENhc2VTZXJ2aWNlLmdldENhc2UoY2xpZW50LCByZXF1ZXN0LnBhcmFtcy5pZCk7XG4gICAgICAgIGlmICghY2FzZURvYykge1xuICAgICAgICAgIHJldHVybiByZXNwb25zZS5ub3RGb3VuZCh7IGJvZHk6IHsgbWVzc2FnZTogJ0Nhc2Ugbm90IGZvdW5kJyB9IH0pO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXNwb25zZS5vayh7IGJvZHk6IGNhc2VEb2MgfSk7XG4gICAgICB9IGNhdGNoIChlcnJvcjogYW55KSB7XG4gICAgICAgIGxvZ2dlci5lcnJvcihgRXJyb3IgZ2V0dGluZyBjYXNlOiAke2Vycm9yLm1lc3NhZ2V9YCk7XG4gICAgICAgIHJldHVybiByZXNwb25zZS5jdXN0b21FcnJvcih7XG4gICAgICAgICAgc3RhdHVzQ29kZTogZXJyb3Iuc3RhdHVzQ29kZSB8fCA1MDAsXG4gICAgICAgICAgYm9keTogeyBtZXNzYWdlOiBlcnJvci5tZXNzYWdlIHx8ICdGYWlsZWQgdG8gZ2V0IGNhc2UnIH0sXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH0sXG4gICk7XG5cbiAgLy8g4pSA4pSA4pSAIENSRUFURSBDQVNFIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICByb3V0ZXIucG9zdChcbiAgICB7XG4gICAgICBwYXRoOiAnL2FwaS93YXp1aC1jYXNlLW1hbmFnZW1lbnQvY2FzZXMnLFxuICAgICAgdmFsaWRhdGU6IHtcbiAgICAgICAgYm9keTogc2NoZW1hLm9iamVjdCh7XG4gICAgICAgICAgdGl0bGU6IHNjaGVtYS5zdHJpbmcoeyBtaW5MZW5ndGg6IDEsIG1heExlbmd0aDogNTAwIH0pLFxuICAgICAgICAgIGRlc2NyaXB0aW9uOiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcbiAgICAgICAgICBzZXZlcml0eTogc2NoZW1hLnN0cmluZygpLFxuICAgICAgICAgIHByaW9yaXR5OiBzY2hlbWEuc3RyaW5nKCksXG4gICAgICAgICAgY2F0ZWdvcnk6IHNjaGVtYS5zdHJpbmcoKSxcbiAgICAgICAgICB0bHA6IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICAgICAgICAgIHRhZ3M6IHNjaGVtYS5tYXliZShzY2hlbWEuYXJyYXlPZihzY2hlbWEuc3RyaW5nKCkpKSxcbiAgICAgICAgICBhc3NpZ25lZTogc2NoZW1hLm1heWJlKHNjaGVtYS5udWxsYWJsZShzY2hlbWEuc3RyaW5nKCkpKSxcbiAgICAgICAgfSwgeyB1bmtub3duczogJ2FsbG93JyB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBhc3luYyAoY29udGV4dCwgcmVxdWVzdCwgcmVzcG9uc2UpID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGNsaWVudCA9IGNvbnRleHQuY29yZS5vcGVuc2VhcmNoLmNsaWVudC5hc0N1cnJlbnRVc2VyO1xuICAgICAgICBjb25zdCB1c2VyID0gYXdhaXQgZ2V0Q3VycmVudFVzZXJuYW1lKGNsaWVudCk7XG4gICAgICAgIGNvbnN0IG5ld0Nhc2UgPSBhd2FpdCBDYXNlU2VydmljZS5jcmVhdGVDYXNlKGNsaWVudCwgcmVxdWVzdC5ib2R5LCB1c2VyKTtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHsgYm9keTogbmV3Q2FzZSB9KTtcbiAgICAgIH0gY2F0Y2ggKGVycm9yOiBhbnkpIHtcbiAgICAgICAgY29uc3Qgc3RhdHVzID0gZXJyb3Iuc3RhdHVzQ29kZSA/PyBlcnJvci5tZXRhPy5zdGF0dXNDb2RlID8/IDUwMDtcbiAgICAgICAgY29uc3QgZGV0YWlsID0gZXJyb3IubWV0YT8uYm9keSA/IEpTT04uc3RyaW5naWZ5KGVycm9yLm1ldGEuYm9keSkgOiAnJztcbiAgICAgICAgbG9nZ2VyLmVycm9yKGBFcnJvciBjcmVhdGluZyBjYXNlIFske3N0YXR1c31dOiAke2Vycm9yLm1lc3NhZ2V9ICR7ZGV0YWlsfWApO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2UuY3VzdG9tRXJyb3Ioe1xuICAgICAgICAgIHN0YXR1c0NvZGU6IHN0YXR1cyA+PSA0MDAgJiYgc3RhdHVzIDwgNjAwID8gc3RhdHVzIDogNTAwLFxuICAgICAgICAgIGJvZHk6IHsgbWVzc2FnZTogYCR7ZXJyb3IubWVzc2FnZX0ke2RldGFpbCA/IGAg4oCUICR7ZGV0YWlsfWAgOiAnJ31gIH0sXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH0sXG4gICk7XG5cbiAgLy8g4pSA4pSA4pSAIFVQREFURSBDQVNFIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICByb3V0ZXIucHV0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL3dhenVoLWNhc2UtbWFuYWdlbWVudC9jYXNlcy97aWR9JyxcbiAgICAgIHZhbGlkYXRlOiB7XG4gICAgICAgIHBhcmFtczogc2NoZW1hLm9iamVjdCh7XG4gICAgICAgICAgaWQ6IHNjaGVtYS5zdHJpbmcoKSxcbiAgICAgICAgfSksXG4gICAgICAgIGJvZHk6IHNjaGVtYS5vYmplY3Qoe1xuICAgICAgICAgIHRpdGxlOiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZyh7IG1pbkxlbmd0aDogMSwgbWF4TGVuZ3RoOiA1MDAgfSkpLFxuICAgICAgICAgIGRlc2NyaXB0aW9uOiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcbiAgICAgICAgICBzZXZlcml0eTogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXG4gICAgICAgICAgcHJpb3JpdHk6IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICAgICAgICAgIGNhdGVnb3J5OiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcbiAgICAgICAgICB0bHA6IHNjaGVtYS5tYXliZShzY2hlbWEuc3RyaW5nKCkpLFxuICAgICAgICAgIHRhZ3M6IHNjaGVtYS5tYXliZShzY2hlbWEuYXJyYXlPZihzY2hlbWEuc3RyaW5nKCkpKSxcbiAgICAgICAgICBhc3NpZ25lZTogc2NoZW1hLm1heWJlKHNjaGVtYS5udWxsYWJsZShzY2hlbWEuc3RyaW5nKCkpKSxcbiAgICAgICAgICByZXNvbHV0aW9uX3N1bW1hcnk6IHNjaGVtYS5tYXliZShzY2hlbWEubnVsbGFibGUoc2NoZW1hLnN0cmluZygpKSksXG4gICAgICAgIH0sIHsgdW5rbm93bnM6ICdhbGxvdycgfSksXG4gICAgICB9LFxuICAgIH0sXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcXVlc3QsIHJlc3BvbnNlKSA9PiB7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBjbGllbnQgPSBjb250ZXh0LmNvcmUub3BlbnNlYXJjaC5jbGllbnQuYXNDdXJyZW50VXNlcjtcbiAgICAgICAgY29uc3QgdXNlciA9IGF3YWl0IGdldEN1cnJlbnRVc2VybmFtZShjbGllbnQpO1xuICAgICAgICBjb25zdCB1cGRhdGVkID0gYXdhaXQgQ2FzZVNlcnZpY2UudXBkYXRlQ2FzZShjbGllbnQsIHJlcXVlc3QucGFyYW1zLmlkLCByZXF1ZXN0LmJvZHksIHVzZXIpO1xuICAgICAgICBpZiAoIXVwZGF0ZWQpIHtcbiAgICAgICAgICByZXR1cm4gcmVzcG9uc2Uubm90Rm91bmQoeyBib2R5OiB7IG1lc3NhZ2U6ICdDYXNlIG5vdCBmb3VuZCcgfSB9KTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzcG9uc2Uub2soeyBib2R5OiB1cGRhdGVkIH0pO1xuICAgICAgfSBjYXRjaCAoZXJyb3I6IGFueSkge1xuICAgICAgICBsb2dnZXIuZXJyb3IoYEVycm9yIHVwZGF0aW5nIGNhc2U6ICR7ZXJyb3IubWVzc2FnZX1gKTtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmN1c3RvbUVycm9yKHtcbiAgICAgICAgICBzdGF0dXNDb2RlOiBlcnJvci5zdGF0dXNDb2RlIHx8IDUwMCxcbiAgICAgICAgICBib2R5OiB7IG1lc3NhZ2U6IGVycm9yLm1lc3NhZ2UgfHwgJ0ZhaWxlZCB0byB1cGRhdGUgY2FzZScgfSxcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfSxcbiAgKTtcblxuICAvLyDilIDilIDilIAgREVMRVRFIENBU0Ug4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gIHJvdXRlci5kZWxldGUoXG4gICAge1xuICAgICAgcGF0aDogJy9hcGkvd2F6dWgtY2FzZS1tYW5hZ2VtZW50L2Nhc2VzL3tpZH0nLFxuICAgICAgdmFsaWRhdGU6IHtcbiAgICAgICAgcGFyYW1zOiBzY2hlbWEub2JqZWN0KHtcbiAgICAgICAgICBpZDogc2NoZW1hLnN0cmluZygpLFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBhc3luYyAoY29udGV4dCwgcmVxdWVzdCwgcmVzcG9uc2UpID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGNsaWVudCA9IGNvbnRleHQuY29yZS5vcGVuc2VhcmNoLmNsaWVudC5hc0N1cnJlbnRVc2VyO1xuICAgICAgICBjb25zdCB1c2VyID0gYXdhaXQgZ2V0Q3VycmVudFVzZXJuYW1lKGNsaWVudCk7XG4gICAgICAgIGlmICh1c2VyICE9PSAnYWRtaW4nKSB7XG4gICAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmZvcmJpZGRlbih7IGJvZHk6IHsgbWVzc2FnZTogJ09ubHkgYWRtaW4gdXNlcnMgY2FuIGRlbGV0ZSBjYXNlcycgfSB9KTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBkZWxldGVkID0gYXdhaXQgQ2FzZVNlcnZpY2UuZGVsZXRlQ2FzZShjbGllbnQsIHJlcXVlc3QucGFyYW1zLmlkKTtcbiAgICAgICAgaWYgKCFkZWxldGVkKSB7XG4gICAgICAgICAgcmV0dXJuIHJlc3BvbnNlLm5vdEZvdW5kKHsgYm9keTogeyBtZXNzYWdlOiAnQ2FzZSBub3QgZm91bmQnIH0gfSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHsgYm9keTogeyBtZXNzYWdlOiAnQ2FzZSBkZWxldGVkIHN1Y2Nlc3NmdWxseScgfSB9KTtcbiAgICAgIH0gY2F0Y2ggKGVycm9yOiBhbnkpIHtcbiAgICAgICAgbG9nZ2VyLmVycm9yKGBFcnJvciBkZWxldGluZyBjYXNlOiAke2Vycm9yLm1lc3NhZ2V9YCk7XG4gICAgICAgIHJldHVybiByZXNwb25zZS5jdXN0b21FcnJvcih7XG4gICAgICAgICAgc3RhdHVzQ29kZTogZXJyb3Iuc3RhdHVzQ29kZSB8fCA1MDAsXG4gICAgICAgICAgYm9keTogeyBtZXNzYWdlOiBlcnJvci5tZXNzYWdlIHx8ICdGYWlsZWQgdG8gZGVsZXRlIGNhc2UnIH0sXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH0sXG4gICk7XG5cbiAgLy8g4pSA4pSA4pSAIENIQU5HRSBTVEFUVVMg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gIHJvdXRlci5wb3N0KFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL3dhenVoLWNhc2UtbWFuYWdlbWVudC9jYXNlcy97aWR9L3N0YXR1cycsXG4gICAgICB2YWxpZGF0ZToge1xuICAgICAgICBwYXJhbXM6IHNjaGVtYS5vYmplY3Qoe1xuICAgICAgICAgIGlkOiBzY2hlbWEuc3RyaW5nKCksXG4gICAgICAgIH0pLFxuICAgICAgICBib2R5OiBzY2hlbWEub2JqZWN0KHtcbiAgICAgICAgICBzdGF0dXM6IHNjaGVtYS5zdHJpbmcoKSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcXVlc3QsIHJlc3BvbnNlKSA9PiB7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBjbGllbnQgPSBjb250ZXh0LmNvcmUub3BlbnNlYXJjaC5jbGllbnQuYXNDdXJyZW50VXNlcjtcbiAgICAgICAgY29uc3QgdXNlciA9IGF3YWl0IGdldEN1cnJlbnRVc2VybmFtZShjbGllbnQpO1xuICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBDYXNlU2VydmljZS5jaGFuZ2VTdGF0dXMoXG4gICAgICAgICAgY2xpZW50LFxuICAgICAgICAgIHJlcXVlc3QucGFyYW1zLmlkLFxuICAgICAgICAgIHJlcXVlc3QuYm9keS5zdGF0dXMsXG4gICAgICAgICAgdXNlcixcbiAgICAgICAgKTtcbiAgICAgICAgaWYgKCFyZXN1bHQuc3VjY2Vzcykge1xuICAgICAgICAgIHJldHVybiByZXNwb25zZS5iYWRSZXF1ZXN0KHsgYm9keTogeyBtZXNzYWdlOiByZXN1bHQuZXJyb3IgfSB9KTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzcG9uc2Uub2soeyBib2R5OiByZXN1bHQuY2FzZSB9KTtcbiAgICAgIH0gY2F0Y2ggKGVycm9yOiBhbnkpIHtcbiAgICAgICAgbG9nZ2VyLmVycm9yKGBFcnJvciBjaGFuZ2luZyBjYXNlIHN0YXR1czogJHtlcnJvci5tZXNzYWdlfWApO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2UuY3VzdG9tRXJyb3Ioe1xuICAgICAgICAgIHN0YXR1c0NvZGU6IGVycm9yLnN0YXR1c0NvZGUgfHwgNTAwLFxuICAgICAgICAgIGJvZHk6IHsgbWVzc2FnZTogZXJyb3IubWVzc2FnZSB8fCAnRmFpbGVkIHRvIGNoYW5nZSBzdGF0dXMnIH0sXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH0sXG4gICk7XG5cbiAgLy8g4pSA4pSA4pSAIEFTU0lHTiBDQVNFIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICByb3V0ZXIucG9zdChcbiAgICB7XG4gICAgICBwYXRoOiAnL2FwaS93YXp1aC1jYXNlLW1hbmFnZW1lbnQvY2FzZXMve2lkfS9hc3NpZ24nLFxuICAgICAgdmFsaWRhdGU6IHtcbiAgICAgICAgcGFyYW1zOiBzY2hlbWEub2JqZWN0KHtcbiAgICAgICAgICBpZDogc2NoZW1hLnN0cmluZygpLFxuICAgICAgICB9KSxcbiAgICAgICAgYm9keTogc2NoZW1hLm9iamVjdCh7XG4gICAgICAgICAgYXNzaWduZWU6IHNjaGVtYS5udWxsYWJsZShzY2hlbWEuc3RyaW5nKCkpLFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBhc3luYyAoY29udGV4dCwgcmVxdWVzdCwgcmVzcG9uc2UpID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGNsaWVudCA9IGNvbnRleHQuY29yZS5vcGVuc2VhcmNoLmNsaWVudC5hc0N1cnJlbnRVc2VyO1xuICAgICAgICBjb25zdCB1c2VyID0gYXdhaXQgZ2V0Q3VycmVudFVzZXJuYW1lKGNsaWVudCk7XG4gICAgICAgIGNvbnN0IHVwZGF0ZWQgPSBhd2FpdCBDYXNlU2VydmljZS5hc3NpZ25DYXNlKFxuICAgICAgICAgIGNsaWVudCxcbiAgICAgICAgICByZXF1ZXN0LnBhcmFtcy5pZCxcbiAgICAgICAgICByZXF1ZXN0LmJvZHkuYXNzaWduZWUsXG4gICAgICAgICAgdXNlcixcbiAgICAgICAgKTtcbiAgICAgICAgaWYgKCF1cGRhdGVkKSB7XG4gICAgICAgICAgcmV0dXJuIHJlc3BvbnNlLm5vdEZvdW5kKHsgYm9keTogeyBtZXNzYWdlOiAnQ2FzZSBub3QgZm91bmQnIH0gfSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHsgYm9keTogdXBkYXRlZCB9KTtcbiAgICAgIH0gY2F0Y2ggKGVycm9yOiBhbnkpIHtcbiAgICAgICAgbG9nZ2VyLmVycm9yKGBFcnJvciBhc3NpZ25pbmcgY2FzZTogJHtlcnJvci5tZXNzYWdlfWApO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2UuY3VzdG9tRXJyb3Ioe1xuICAgICAgICAgIHN0YXR1c0NvZGU6IGVycm9yLnN0YXR1c0NvZGUgfHwgNTAwLFxuICAgICAgICAgIGJvZHk6IHsgbWVzc2FnZTogZXJyb3IubWVzc2FnZSB8fCAnRmFpbGVkIHRvIGFzc2lnbiBjYXNlJyB9LFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9LFxuICApO1xuXG4gIC8vIOKUgOKUgOKUgCBBREQgVEFTSyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgcm91dGVyLnBvc3QoXG4gICAge1xuICAgICAgcGF0aDogJy9hcGkvd2F6dWgtY2FzZS1tYW5hZ2VtZW50L2Nhc2VzL3tpZH0vdGFza3MnLFxuICAgICAgdmFsaWRhdGU6IHtcbiAgICAgICAgcGFyYW1zOiBzY2hlbWEub2JqZWN0KHtcbiAgICAgICAgICBpZDogc2NoZW1hLnN0cmluZygpLFxuICAgICAgICB9KSxcbiAgICAgICAgYm9keTogc2NoZW1hLm9iamVjdCh7XG4gICAgICAgICAgdGl0bGU6IHNjaGVtYS5zdHJpbmcoKSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcXVlc3QsIHJlc3BvbnNlKSA9PiB7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBjbGllbnQgPSBjb250ZXh0LmNvcmUub3BlbnNlYXJjaC5jbGllbnQuYXNDdXJyZW50VXNlcjtcbiAgICAgICAgY29uc3QgdXNlciA9IGF3YWl0IGdldEN1cnJlbnRVc2VybmFtZShjbGllbnQpO1xuICAgICAgICBjb25zdCB1cGRhdGVkID0gYXdhaXQgQ2FzZVNlcnZpY2UuYWRkVGFzayhjbGllbnQsIHJlcXVlc3QucGFyYW1zLmlkLCByZXF1ZXN0LmJvZHkudGl0bGUsIHVzZXIpO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2Uub2soeyBib2R5OiB1cGRhdGVkIH0pO1xuICAgICAgfSBjYXRjaCAoZXJyb3I6IGFueSkge1xuICAgICAgICByZXR1cm4gcmVzcG9uc2UuY3VzdG9tRXJyb3IoeyBzdGF0dXNDb2RlOiA1MDAsIGJvZHk6IHsgbWVzc2FnZTogZXJyb3IubWVzc2FnZSB9IH0pO1xuICAgICAgfVxuICAgIH1cbiAgKTtcblxuICAvLyDilIDilIDilIAgVE9HR0xFIFRBU0sg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gIHJvdXRlci5wYXRjaChcbiAgICB7XG4gICAgICBwYXRoOiAnL2FwaS93YXp1aC1jYXNlLW1hbmFnZW1lbnQvY2FzZXMve2lkfS90YXNrcy97dGFza0lkfScsXG4gICAgICB2YWxpZGF0ZToge1xuICAgICAgICBwYXJhbXM6IHNjaGVtYS5vYmplY3Qoe1xuICAgICAgICAgIGlkOiBzY2hlbWEuc3RyaW5nKCksXG4gICAgICAgICAgdGFza0lkOiBzY2hlbWEuc3RyaW5nKCksXG4gICAgICAgIH0pLFxuICAgICAgICBib2R5OiBzY2hlbWEub2JqZWN0KHtcbiAgICAgICAgICBjb21wbGV0ZWQ6IHNjaGVtYS5ib29sZWFuKCksXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIGFzeW5jIChjb250ZXh0LCByZXF1ZXN0LCByZXNwb25zZSkgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgY2xpZW50ID0gY29udGV4dC5jb3JlLm9wZW5zZWFyY2guY2xpZW50LmFzQ3VycmVudFVzZXI7XG4gICAgICAgIGNvbnN0IHVzZXIgPSBhd2FpdCBnZXRDdXJyZW50VXNlcm5hbWUoY2xpZW50KTtcbiAgICAgICAgY29uc3QgdXBkYXRlZCA9IGF3YWl0IENhc2VTZXJ2aWNlLnRvZ2dsZVRhc2soY2xpZW50LCByZXF1ZXN0LnBhcmFtcy5pZCwgcmVxdWVzdC5wYXJhbXMudGFza0lkLCByZXF1ZXN0LmJvZHkuY29tcGxldGVkLCB1c2VyKTtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHsgYm9keTogdXBkYXRlZCB9KTtcbiAgICAgIH0gY2F0Y2ggKGVycm9yOiBhbnkpIHtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmN1c3RvbUVycm9yKHsgc3RhdHVzQ29kZTogNTAwLCBib2R5OiB7IG1lc3NhZ2U6IGVycm9yLm1lc3NhZ2UgfSB9KTtcbiAgICAgIH1cbiAgICB9XG4gICk7XG5cbiAgLy8g4pSA4pSA4pSAIFJFTU9WRSBUQVNLIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICByb3V0ZXIuZGVsZXRlKFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL3dhenVoLWNhc2UtbWFuYWdlbWVudC9jYXNlcy97aWR9L3Rhc2tzL3t0YXNrSWR9JyxcbiAgICAgIHZhbGlkYXRlOiB7XG4gICAgICAgIHBhcmFtczogc2NoZW1hLm9iamVjdCh7XG4gICAgICAgICAgaWQ6IHNjaGVtYS5zdHJpbmcoKSxcbiAgICAgICAgICB0YXNrSWQ6IHNjaGVtYS5zdHJpbmcoKSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcXVlc3QsIHJlc3BvbnNlKSA9PiB7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBjbGllbnQgPSBjb250ZXh0LmNvcmUub3BlbnNlYXJjaC5jbGllbnQuYXNDdXJyZW50VXNlcjtcbiAgICAgICAgY29uc3QgdXNlciA9IGF3YWl0IGdldEN1cnJlbnRVc2VybmFtZShjbGllbnQpO1xuICAgICAgICBjb25zdCB1cGRhdGVkID0gYXdhaXQgQ2FzZVNlcnZpY2UucmVtb3ZlVGFzayhjbGllbnQsIHJlcXVlc3QucGFyYW1zLmlkLCByZXF1ZXN0LnBhcmFtcy50YXNrSWQsIHVzZXIpO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2Uub2soeyBib2R5OiB1cGRhdGVkIH0pO1xuICAgICAgfSBjYXRjaCAoZXJyb3I6IGFueSkge1xuICAgICAgICByZXR1cm4gcmVzcG9uc2UuY3VzdG9tRXJyb3IoeyBzdGF0dXNDb2RlOiA1MDAsIGJvZHk6IHsgbWVzc2FnZTogZXJyb3IubWVzc2FnZSB9IH0pO1xuICAgICAgfVxuICAgIH1cbiAgKTtcblxuICAvLyDilIDilIDilIAgU0FWRSBOT1RFUyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgcm91dGVyLnBhdGNoKFxuICAgIHtcbiAgICAgIHBhdGg6ICcvYXBpL3dhenVoLWNhc2UtbWFuYWdlbWVudC9jYXNlcy97aWR9L25vdGVzJyxcbiAgICAgIHZhbGlkYXRlOiB7XG4gICAgICAgIHBhcmFtczogc2NoZW1hLm9iamVjdCh7XG4gICAgICAgICAgaWQ6IHNjaGVtYS5zdHJpbmcoKSxcbiAgICAgICAgfSksXG4gICAgICAgIGJvZHk6IHNjaGVtYS5vYmplY3Qoe1xuICAgICAgICAgIG5vdGVzOiBzY2hlbWEuc3RyaW5nKHsgZGVmYXVsdFZhbHVlOiAnJyB9KSxcbiAgICAgICAgfSksXG4gICAgICB9LFxuICAgIH0sXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcXVlc3QsIHJlc3BvbnNlKSA9PiB7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBjbGllbnQgPSBjb250ZXh0LmNvcmUub3BlbnNlYXJjaC5jbGllbnQuYXNDdXJyZW50VXNlcjtcbiAgICAgICAgY29uc3QgdXNlciA9IGF3YWl0IGdldEN1cnJlbnRVc2VybmFtZShjbGllbnQpO1xuICAgICAgICBjb25zdCB1cGRhdGVkID0gYXdhaXQgQ2FzZVNlcnZpY2UudXBkYXRlTm90ZXMoY2xpZW50LCByZXF1ZXN0LnBhcmFtcy5pZCwgcmVxdWVzdC5ib2R5Lm5vdGVzLCB1c2VyKTtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHsgYm9keTogdXBkYXRlZCB9KTtcbiAgICAgIH0gY2F0Y2ggKGVycm9yOiBhbnkpIHtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmN1c3RvbUVycm9yKHsgc3RhdHVzQ29kZTogNTAwLCBib2R5OiB7IG1lc3NhZ2U6IGVycm9yLm1lc3NhZ2UgfSB9KTtcbiAgICAgIH1cbiAgICB9XG4gICk7XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQU1BLElBQUFBLGFBQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLGFBQUEsR0FBQUQsT0FBQTtBQUNBLElBQUFFLE1BQUEsR0FBQUYsT0FBQTtBQVJBO0FBQ0E7QUFDQTtBQUNBOztBQU9PLFNBQVNHLGtCQUFrQkEsQ0FBQ0MsTUFBZSxFQUFFQyxNQUFjLEVBQVE7RUFDeEU7RUFDQUQsTUFBTSxDQUFDRSxHQUFHLENBQ1I7SUFDRUMsSUFBSSxFQUFFLGtDQUFrQztJQUN4Q0MsUUFBUSxFQUFFO01BQ1JDLEtBQUssRUFBRUMsb0JBQU0sQ0FBQ0MsTUFBTSxDQUFDO1FBQ25CQyxJQUFJLEVBQUVGLG9CQUFNLENBQUNHLEtBQUssQ0FBQ0gsb0JBQU0sQ0FBQ0ksTUFBTSxDQUFDO1VBQUVDLEdBQUcsRUFBRSxDQUFDO1VBQUVDLFlBQVksRUFBRTtRQUFFLENBQUMsQ0FBQyxDQUFDO1FBQzlEQyxRQUFRLEVBQUVQLG9CQUFNLENBQUNHLEtBQUssQ0FBQ0gsb0JBQU0sQ0FBQ0ksTUFBTSxDQUFDO1VBQUVDLEdBQUcsRUFBRSxDQUFDO1VBQUVHLEdBQUcsRUFBRSxHQUFHO1VBQUVGLFlBQVksRUFBRTtRQUFHLENBQUMsQ0FBQyxDQUFDO1FBQzdFRyxVQUFVLEVBQUVULG9CQUFNLENBQUNHLEtBQUssQ0FBQ0gsb0JBQU0sQ0FBQ1UsTUFBTSxDQUFDO1VBQUVKLFlBQVksRUFBRTtRQUFhLENBQUMsQ0FBQyxDQUFDO1FBQ3ZFSyxVQUFVLEVBQUVYLG9CQUFNLENBQUNHLEtBQUssQ0FBQ0gsb0JBQU0sQ0FBQ1ksS0FBSyxDQUFDLENBQUNaLG9CQUFNLENBQUNhLE9BQU8sQ0FBQyxLQUFLLENBQUMsRUFBRWIsb0JBQU0sQ0FBQ2EsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUU7VUFBRVAsWUFBWSxFQUFFO1FBQU8sQ0FBQyxDQUFDLENBQUM7UUFDakhRLE1BQU0sRUFBRWQsb0JBQU0sQ0FBQ0csS0FBSyxDQUFDSCxvQkFBTSxDQUFDVSxNQUFNLENBQUMsQ0FBQyxDQUFDO1FBQ3JDSyxRQUFRLEVBQUVmLG9CQUFNLENBQUNHLEtBQUssQ0FBQ0gsb0JBQU0sQ0FBQ1UsTUFBTSxDQUFDLENBQUMsQ0FBQztRQUN2Q00sUUFBUSxFQUFFaEIsb0JBQU0sQ0FBQ0csS0FBSyxDQUFDSCxvQkFBTSxDQUFDVSxNQUFNLENBQUMsQ0FBQyxDQUFDO1FBQ3ZDTyxRQUFRLEVBQUVqQixvQkFBTSxDQUFDRyxLQUFLLENBQUNILG9CQUFNLENBQUNVLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFDdkNRLFFBQVEsRUFBRWxCLG9CQUFNLENBQUNHLEtBQUssQ0FBQ0gsb0JBQU0sQ0FBQ1UsTUFBTSxDQUFDLENBQUMsQ0FBQztRQUN2Q1MsTUFBTSxFQUFFbkIsb0JBQU0sQ0FBQ0csS0FBSyxDQUFDSCxvQkFBTSxDQUFDVSxNQUFNLENBQUMsQ0FBQyxDQUFDO1FBQ3JDVSxJQUFJLEVBQUVwQixvQkFBTSxDQUFDRyxLQUFLLENBQUNILG9CQUFNLENBQUNVLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFDbkNXLFlBQVksRUFBRXJCLG9CQUFNLENBQUNHLEtBQUssQ0FBQ0gsb0JBQU0sQ0FBQ1UsTUFBTSxDQUFDLENBQUMsQ0FBQztRQUMzQ1ksVUFBVSxFQUFFdEIsb0JBQU0sQ0FBQ0csS0FBSyxDQUFDSCxvQkFBTSxDQUFDVSxNQUFNLENBQUMsQ0FBQztNQUMxQyxDQUFDO0lBQ0g7RUFDRixDQUFDLEVBQ0QsT0FBT2EsT0FBTyxFQUFFQyxPQUFPLEVBQUVDLFFBQVEsS0FBSztJQUNwQyxJQUFJO01BQ0YsTUFBTUMsTUFBTSxHQUFHSCxPQUFPLENBQUNJLElBQUksQ0FBQ0MsVUFBVSxDQUFDRixNQUFNLENBQUNHLGFBQWE7TUFDM0QsTUFBTUMsTUFBTSxHQUFHLE1BQU1DLHlCQUFXLENBQUNDLFNBQVMsQ0FBQ04sTUFBTSxFQUFFRixPQUFPLENBQUN6QixLQUFLLENBQUM7TUFDakUsT0FBTzBCLFFBQVEsQ0FBQ1EsRUFBRSxDQUFDO1FBQUVDLElBQUksRUFBRUo7TUFBTyxDQUFDLENBQUM7SUFDdEMsQ0FBQyxDQUFDLE9BQU9LLEtBQVUsRUFBRTtNQUNuQnhDLE1BQU0sQ0FBQ3dDLEtBQUssQ0FBRSx3QkFBdUJBLEtBQUssQ0FBQ0MsT0FBUSxFQUFDLENBQUM7TUFDckQsT0FBT1gsUUFBUSxDQUFDWSxXQUFXLENBQUM7UUFDMUJDLFVBQVUsRUFBRUgsS0FBSyxDQUFDRyxVQUFVLElBQUksR0FBRztRQUNuQ0osSUFBSSxFQUFFO1VBQUVFLE9BQU8sRUFBRUQsS0FBSyxDQUFDQyxPQUFPLElBQUk7UUFBdUI7TUFDM0QsQ0FBQyxDQUFDO0lBQ0o7RUFDRixDQUNGLENBQUM7O0VBRUQ7RUFDQTFDLE1BQU0sQ0FBQ0UsR0FBRyxDQUNSO0lBQ0VDLElBQUksRUFBRSx1Q0FBdUM7SUFDN0NDLFFBQVEsRUFBRTtNQUNSeUMsTUFBTSxFQUFFdkMsb0JBQU0sQ0FBQ0MsTUFBTSxDQUFDO1FBQ3BCdUMsRUFBRSxFQUFFeEMsb0JBQU0sQ0FBQ1UsTUFBTSxDQUFDO01BQ3BCLENBQUM7SUFDSDtFQUNGLENBQUMsRUFDRCxPQUFPYSxPQUFPLEVBQUVDLE9BQU8sRUFBRUMsUUFBUSxLQUFLO0lBQ3BDLElBQUk7TUFDRixNQUFNQyxNQUFNLEdBQUdILE9BQU8sQ0FBQ0ksSUFBSSxDQUFDQyxVQUFVLENBQUNGLE1BQU0sQ0FBQ0csYUFBYTtNQUMzRCxNQUFNWSxPQUFPLEdBQUcsTUFBTVYseUJBQVcsQ0FBQ1csT0FBTyxDQUFDaEIsTUFBTSxFQUFFRixPQUFPLENBQUNlLE1BQU0sQ0FBQ0MsRUFBRSxDQUFDO01BQ3BFLElBQUksQ0FBQ0MsT0FBTyxFQUFFO1FBQ1osT0FBT2hCLFFBQVEsQ0FBQ2tCLFFBQVEsQ0FBQztVQUFFVCxJQUFJLEVBQUU7WUFBRUUsT0FBTyxFQUFFO1VBQWlCO1FBQUUsQ0FBQyxDQUFDO01BQ25FO01BQ0EsT0FBT1gsUUFBUSxDQUFDUSxFQUFFLENBQUM7UUFBRUMsSUFBSSxFQUFFTztNQUFRLENBQUMsQ0FBQztJQUN2QyxDQUFDLENBQUMsT0FBT04sS0FBVSxFQUFFO01BQ25CeEMsTUFBTSxDQUFDd0MsS0FBSyxDQUFFLHVCQUFzQkEsS0FBSyxDQUFDQyxPQUFRLEVBQUMsQ0FBQztNQUNwRCxPQUFPWCxRQUFRLENBQUNZLFdBQVcsQ0FBQztRQUMxQkMsVUFBVSxFQUFFSCxLQUFLLENBQUNHLFVBQVUsSUFBSSxHQUFHO1FBQ25DSixJQUFJLEVBQUU7VUFBRUUsT0FBTyxFQUFFRCxLQUFLLENBQUNDLE9BQU8sSUFBSTtRQUFxQjtNQUN6RCxDQUFDLENBQUM7SUFDSjtFQUNGLENBQ0YsQ0FBQzs7RUFFRDtFQUNBMUMsTUFBTSxDQUFDa0QsSUFBSSxDQUNUO0lBQ0UvQyxJQUFJLEVBQUUsa0NBQWtDO0lBQ3hDQyxRQUFRLEVBQUU7TUFDUm9DLElBQUksRUFBRWxDLG9CQUFNLENBQUNDLE1BQU0sQ0FBQztRQUNsQjRDLEtBQUssRUFBRTdDLG9CQUFNLENBQUNVLE1BQU0sQ0FBQztVQUFFb0MsU0FBUyxFQUFFLENBQUM7VUFBRUMsU0FBUyxFQUFFO1FBQUksQ0FBQyxDQUFDO1FBQ3REQyxXQUFXLEVBQUVoRCxvQkFBTSxDQUFDRyxLQUFLLENBQUNILG9CQUFNLENBQUNVLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFDMUNLLFFBQVEsRUFBRWYsb0JBQU0sQ0FBQ1UsTUFBTSxDQUFDLENBQUM7UUFDekJNLFFBQVEsRUFBRWhCLG9CQUFNLENBQUNVLE1BQU0sQ0FBQyxDQUFDO1FBQ3pCTyxRQUFRLEVBQUVqQixvQkFBTSxDQUFDVSxNQUFNLENBQUMsQ0FBQztRQUN6QnVDLEdBQUcsRUFBRWpELG9CQUFNLENBQUNHLEtBQUssQ0FBQ0gsb0JBQU0sQ0FBQ1UsTUFBTSxDQUFDLENBQUMsQ0FBQztRQUNsQ1UsSUFBSSxFQUFFcEIsb0JBQU0sQ0FBQ0csS0FBSyxDQUFDSCxvQkFBTSxDQUFDa0QsT0FBTyxDQUFDbEQsb0JBQU0sQ0FBQ1UsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ25EUSxRQUFRLEVBQUVsQixvQkFBTSxDQUFDRyxLQUFLLENBQUNILG9CQUFNLENBQUNtRCxRQUFRLENBQUNuRCxvQkFBTSxDQUFDVSxNQUFNLENBQUMsQ0FBQyxDQUFDO01BQ3pELENBQUMsRUFBRTtRQUFFMEMsUUFBUSxFQUFFO01BQVEsQ0FBQztJQUMxQjtFQUNGLENBQUMsRUFDRCxPQUFPN0IsT0FBTyxFQUFFQyxPQUFPLEVBQUVDLFFBQVEsS0FBSztJQUNwQyxJQUFJO01BQ0YsTUFBTUMsTUFBTSxHQUFHSCxPQUFPLENBQUNJLElBQUksQ0FBQ0MsVUFBVSxDQUFDRixNQUFNLENBQUNHLGFBQWE7TUFDM0QsTUFBTXdCLElBQUksR0FBRyxNQUFNLElBQUFDLHlCQUFrQixFQUFDNUIsTUFBTSxDQUFDO01BQzdDLE1BQU02QixPQUFPLEdBQUcsTUFBTXhCLHlCQUFXLENBQUN5QixVQUFVLENBQUM5QixNQUFNLEVBQUVGLE9BQU8sQ0FBQ1UsSUFBSSxFQUFFbUIsSUFBSSxDQUFDO01BQ3hFLE9BQU81QixRQUFRLENBQUNRLEVBQUUsQ0FBQztRQUFFQyxJQUFJLEVBQUVxQjtNQUFRLENBQUMsQ0FBQztJQUN2QyxDQUFDLENBQUMsT0FBT3BCLEtBQVUsRUFBRTtNQUFBLElBQUFzQixJQUFBLEVBQUFDLGlCQUFBLEVBQUFDLFdBQUEsRUFBQUMsWUFBQTtNQUNuQixNQUFNOUMsTUFBTSxJQUFBMkMsSUFBQSxJQUFBQyxpQkFBQSxHQUFHdkIsS0FBSyxDQUFDRyxVQUFVLGNBQUFvQixpQkFBQSxjQUFBQSxpQkFBQSxJQUFBQyxXQUFBLEdBQUl4QixLQUFLLENBQUMwQixJQUFJLGNBQUFGLFdBQUEsdUJBQVZBLFdBQUEsQ0FBWXJCLFVBQVUsY0FBQW1CLElBQUEsY0FBQUEsSUFBQSxHQUFJLEdBQUc7TUFDaEUsTUFBTUssTUFBTSxHQUFHLENBQUFGLFlBQUEsR0FBQXpCLEtBQUssQ0FBQzBCLElBQUksY0FBQUQsWUFBQSxlQUFWQSxZQUFBLENBQVkxQixJQUFJLEdBQUc2QixJQUFJLENBQUNDLFNBQVMsQ0FBQzdCLEtBQUssQ0FBQzBCLElBQUksQ0FBQzNCLElBQUksQ0FBQyxHQUFHLEVBQUU7TUFDdEV2QyxNQUFNLENBQUN3QyxLQUFLLENBQUUsd0JBQXVCckIsTUFBTyxNQUFLcUIsS0FBSyxDQUFDQyxPQUFRLElBQUcwQixNQUFPLEVBQUMsQ0FBQztNQUMzRSxPQUFPckMsUUFBUSxDQUFDWSxXQUFXLENBQUM7UUFDMUJDLFVBQVUsRUFBRXhCLE1BQU0sSUFBSSxHQUFHLElBQUlBLE1BQU0sR0FBRyxHQUFHLEdBQUdBLE1BQU0sR0FBRyxHQUFHO1FBQ3hEb0IsSUFBSSxFQUFFO1VBQUVFLE9BQU8sRUFBRyxHQUFFRCxLQUFLLENBQUNDLE9BQVEsR0FBRTBCLE1BQU0sR0FBSSxNQUFLQSxNQUFPLEVBQUMsR0FBRyxFQUFHO1FBQUU7TUFDckUsQ0FBQyxDQUFDO0lBQ0o7RUFDRixDQUNGLENBQUM7O0VBRUQ7RUFDQXBFLE1BQU0sQ0FBQ3VFLEdBQUcsQ0FDUjtJQUNFcEUsSUFBSSxFQUFFLHVDQUF1QztJQUM3Q0MsUUFBUSxFQUFFO01BQ1J5QyxNQUFNLEVBQUV2QyxvQkFBTSxDQUFDQyxNQUFNLENBQUM7UUFDcEJ1QyxFQUFFLEVBQUV4QyxvQkFBTSxDQUFDVSxNQUFNLENBQUM7TUFDcEIsQ0FBQyxDQUFDO01BQ0Z3QixJQUFJLEVBQUVsQyxvQkFBTSxDQUFDQyxNQUFNLENBQUM7UUFDbEI0QyxLQUFLLEVBQUU3QyxvQkFBTSxDQUFDRyxLQUFLLENBQUNILG9CQUFNLENBQUNVLE1BQU0sQ0FBQztVQUFFb0MsU0FBUyxFQUFFLENBQUM7VUFBRUMsU0FBUyxFQUFFO1FBQUksQ0FBQyxDQUFDLENBQUM7UUFDcEVDLFdBQVcsRUFBRWhELG9CQUFNLENBQUNHLEtBQUssQ0FBQ0gsb0JBQU0sQ0FBQ1UsTUFBTSxDQUFDLENBQUMsQ0FBQztRQUMxQ0ssUUFBUSxFQUFFZixvQkFBTSxDQUFDRyxLQUFLLENBQUNILG9CQUFNLENBQUNVLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFDdkNNLFFBQVEsRUFBRWhCLG9CQUFNLENBQUNHLEtBQUssQ0FBQ0gsb0JBQU0sQ0FBQ1UsTUFBTSxDQUFDLENBQUMsQ0FBQztRQUN2Q08sUUFBUSxFQUFFakIsb0JBQU0sQ0FBQ0csS0FBSyxDQUFDSCxvQkFBTSxDQUFDVSxNQUFNLENBQUMsQ0FBQyxDQUFDO1FBQ3ZDdUMsR0FBRyxFQUFFakQsb0JBQU0sQ0FBQ0csS0FBSyxDQUFDSCxvQkFBTSxDQUFDVSxNQUFNLENBQUMsQ0FBQyxDQUFDO1FBQ2xDVSxJQUFJLEVBQUVwQixvQkFBTSxDQUFDRyxLQUFLLENBQUNILG9CQUFNLENBQUNrRCxPQUFPLENBQUNsRCxvQkFBTSxDQUFDVSxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDbkRRLFFBQVEsRUFBRWxCLG9CQUFNLENBQUNHLEtBQUssQ0FBQ0gsb0JBQU0sQ0FBQ21ELFFBQVEsQ0FBQ25ELG9CQUFNLENBQUNVLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUN4RHdELGtCQUFrQixFQUFFbEUsb0JBQU0sQ0FBQ0csS0FBSyxDQUFDSCxvQkFBTSxDQUFDbUQsUUFBUSxDQUFDbkQsb0JBQU0sQ0FBQ1UsTUFBTSxDQUFDLENBQUMsQ0FBQztNQUNuRSxDQUFDLEVBQUU7UUFBRTBDLFFBQVEsRUFBRTtNQUFRLENBQUM7SUFDMUI7RUFDRixDQUFDLEVBQ0QsT0FBTzdCLE9BQU8sRUFBRUMsT0FBTyxFQUFFQyxRQUFRLEtBQUs7SUFDcEMsSUFBSTtNQUNGLE1BQU1DLE1BQU0sR0FBR0gsT0FBTyxDQUFDSSxJQUFJLENBQUNDLFVBQVUsQ0FBQ0YsTUFBTSxDQUFDRyxhQUFhO01BQzNELE1BQU13QixJQUFJLEdBQUcsTUFBTSxJQUFBQyx5QkFBa0IsRUFBQzVCLE1BQU0sQ0FBQztNQUM3QyxNQUFNeUMsT0FBTyxHQUFHLE1BQU1wQyx5QkFBVyxDQUFDcUMsVUFBVSxDQUFDMUMsTUFBTSxFQUFFRixPQUFPLENBQUNlLE1BQU0sQ0FBQ0MsRUFBRSxFQUFFaEIsT0FBTyxDQUFDVSxJQUFJLEVBQUVtQixJQUFJLENBQUM7TUFDM0YsSUFBSSxDQUFDYyxPQUFPLEVBQUU7UUFDWixPQUFPMUMsUUFBUSxDQUFDa0IsUUFBUSxDQUFDO1VBQUVULElBQUksRUFBRTtZQUFFRSxPQUFPLEVBQUU7VUFBaUI7UUFBRSxDQUFDLENBQUM7TUFDbkU7TUFDQSxPQUFPWCxRQUFRLENBQUNRLEVBQUUsQ0FBQztRQUFFQyxJQUFJLEVBQUVpQztNQUFRLENBQUMsQ0FBQztJQUN2QyxDQUFDLENBQUMsT0FBT2hDLEtBQVUsRUFBRTtNQUNuQnhDLE1BQU0sQ0FBQ3dDLEtBQUssQ0FBRSx3QkFBdUJBLEtBQUssQ0FBQ0MsT0FBUSxFQUFDLENBQUM7TUFDckQsT0FBT1gsUUFBUSxDQUFDWSxXQUFXLENBQUM7UUFDMUJDLFVBQVUsRUFBRUgsS0FBSyxDQUFDRyxVQUFVLElBQUksR0FBRztRQUNuQ0osSUFBSSxFQUFFO1VBQUVFLE9BQU8sRUFBRUQsS0FBSyxDQUFDQyxPQUFPLElBQUk7UUFBd0I7TUFDNUQsQ0FBQyxDQUFDO0lBQ0o7RUFDRixDQUNGLENBQUM7O0VBRUQ7RUFDQTFDLE1BQU0sQ0FBQzJFLE1BQU0sQ0FDWDtJQUNFeEUsSUFBSSxFQUFFLHVDQUF1QztJQUM3Q0MsUUFBUSxFQUFFO01BQ1J5QyxNQUFNLEVBQUV2QyxvQkFBTSxDQUFDQyxNQUFNLENBQUM7UUFDcEJ1QyxFQUFFLEVBQUV4QyxvQkFBTSxDQUFDVSxNQUFNLENBQUM7TUFDcEIsQ0FBQztJQUNIO0VBQ0YsQ0FBQyxFQUNELE9BQU9hLE9BQU8sRUFBRUMsT0FBTyxFQUFFQyxRQUFRLEtBQUs7SUFDcEMsSUFBSTtNQUNGLE1BQU1DLE1BQU0sR0FBR0gsT0FBTyxDQUFDSSxJQUFJLENBQUNDLFVBQVUsQ0FBQ0YsTUFBTSxDQUFDRyxhQUFhO01BQzNELE1BQU13QixJQUFJLEdBQUcsTUFBTSxJQUFBQyx5QkFBa0IsRUFBQzVCLE1BQU0sQ0FBQztNQUM3QyxJQUFJMkIsSUFBSSxLQUFLLE9BQU8sRUFBRTtRQUNwQixPQUFPNUIsUUFBUSxDQUFDNkMsU0FBUyxDQUFDO1VBQUVwQyxJQUFJLEVBQUU7WUFBRUUsT0FBTyxFQUFFO1VBQW9DO1FBQUUsQ0FBQyxDQUFDO01BQ3ZGO01BQ0EsTUFBTW1DLE9BQU8sR0FBRyxNQUFNeEMseUJBQVcsQ0FBQ3lDLFVBQVUsQ0FBQzlDLE1BQU0sRUFBRUYsT0FBTyxDQUFDZSxNQUFNLENBQUNDLEVBQUUsQ0FBQztNQUN2RSxJQUFJLENBQUMrQixPQUFPLEVBQUU7UUFDWixPQUFPOUMsUUFBUSxDQUFDa0IsUUFBUSxDQUFDO1VBQUVULElBQUksRUFBRTtZQUFFRSxPQUFPLEVBQUU7VUFBaUI7UUFBRSxDQUFDLENBQUM7TUFDbkU7TUFDQSxPQUFPWCxRQUFRLENBQUNRLEVBQUUsQ0FBQztRQUFFQyxJQUFJLEVBQUU7VUFBRUUsT0FBTyxFQUFFO1FBQTRCO01BQUUsQ0FBQyxDQUFDO0lBQ3hFLENBQUMsQ0FBQyxPQUFPRCxLQUFVLEVBQUU7TUFDbkJ4QyxNQUFNLENBQUN3QyxLQUFLLENBQUUsd0JBQXVCQSxLQUFLLENBQUNDLE9BQVEsRUFBQyxDQUFDO01BQ3JELE9BQU9YLFFBQVEsQ0FBQ1ksV0FBVyxDQUFDO1FBQzFCQyxVQUFVLEVBQUVILEtBQUssQ0FBQ0csVUFBVSxJQUFJLEdBQUc7UUFDbkNKLElBQUksRUFBRTtVQUFFRSxPQUFPLEVBQUVELEtBQUssQ0FBQ0MsT0FBTyxJQUFJO1FBQXdCO01BQzVELENBQUMsQ0FBQztJQUNKO0VBQ0YsQ0FDRixDQUFDOztFQUVEO0VBQ0ExQyxNQUFNLENBQUNrRCxJQUFJLENBQ1Q7SUFDRS9DLElBQUksRUFBRSw4Q0FBOEM7SUFDcERDLFFBQVEsRUFBRTtNQUNSeUMsTUFBTSxFQUFFdkMsb0JBQU0sQ0FBQ0MsTUFBTSxDQUFDO1FBQ3BCdUMsRUFBRSxFQUFFeEMsb0JBQU0sQ0FBQ1UsTUFBTSxDQUFDO01BQ3BCLENBQUMsQ0FBQztNQUNGd0IsSUFBSSxFQUFFbEMsb0JBQU0sQ0FBQ0MsTUFBTSxDQUFDO1FBQ2xCYSxNQUFNLEVBQUVkLG9CQUFNLENBQUNVLE1BQU0sQ0FBQztNQUN4QixDQUFDO0lBQ0g7RUFDRixDQUFDLEVBQ0QsT0FBT2EsT0FBTyxFQUFFQyxPQUFPLEVBQUVDLFFBQVEsS0FBSztJQUNwQyxJQUFJO01BQ0YsTUFBTUMsTUFBTSxHQUFHSCxPQUFPLENBQUNJLElBQUksQ0FBQ0MsVUFBVSxDQUFDRixNQUFNLENBQUNHLGFBQWE7TUFDM0QsTUFBTXdCLElBQUksR0FBRyxNQUFNLElBQUFDLHlCQUFrQixFQUFDNUIsTUFBTSxDQUFDO01BQzdDLE1BQU1JLE1BQU0sR0FBRyxNQUFNQyx5QkFBVyxDQUFDMEMsWUFBWSxDQUMzQy9DLE1BQU0sRUFDTkYsT0FBTyxDQUFDZSxNQUFNLENBQUNDLEVBQUUsRUFDakJoQixPQUFPLENBQUNVLElBQUksQ0FBQ3BCLE1BQU0sRUFDbkJ1QyxJQUNGLENBQUM7TUFDRCxJQUFJLENBQUN2QixNQUFNLENBQUM0QyxPQUFPLEVBQUU7UUFDbkIsT0FBT2pELFFBQVEsQ0FBQ2tELFVBQVUsQ0FBQztVQUFFekMsSUFBSSxFQUFFO1lBQUVFLE9BQU8sRUFBRU4sTUFBTSxDQUFDSztVQUFNO1FBQUUsQ0FBQyxDQUFDO01BQ2pFO01BQ0EsT0FBT1YsUUFBUSxDQUFDUSxFQUFFLENBQUM7UUFBRUMsSUFBSSxFQUFFSixNQUFNLENBQUM4QztNQUFLLENBQUMsQ0FBQztJQUMzQyxDQUFDLENBQUMsT0FBT3pDLEtBQVUsRUFBRTtNQUNuQnhDLE1BQU0sQ0FBQ3dDLEtBQUssQ0FBRSwrQkFBOEJBLEtBQUssQ0FBQ0MsT0FBUSxFQUFDLENBQUM7TUFDNUQsT0FBT1gsUUFBUSxDQUFDWSxXQUFXLENBQUM7UUFDMUJDLFVBQVUsRUFBRUgsS0FBSyxDQUFDRyxVQUFVLElBQUksR0FBRztRQUNuQ0osSUFBSSxFQUFFO1VBQUVFLE9BQU8sRUFBRUQsS0FBSyxDQUFDQyxPQUFPLElBQUk7UUFBMEI7TUFDOUQsQ0FBQyxDQUFDO0lBQ0o7RUFDRixDQUNGLENBQUM7O0VBRUQ7RUFDQTFDLE1BQU0sQ0FBQ2tELElBQUksQ0FDVDtJQUNFL0MsSUFBSSxFQUFFLDhDQUE4QztJQUNwREMsUUFBUSxFQUFFO01BQ1J5QyxNQUFNLEVBQUV2QyxvQkFBTSxDQUFDQyxNQUFNLENBQUM7UUFDcEJ1QyxFQUFFLEVBQUV4QyxvQkFBTSxDQUFDVSxNQUFNLENBQUM7TUFDcEIsQ0FBQyxDQUFDO01BQ0Z3QixJQUFJLEVBQUVsQyxvQkFBTSxDQUFDQyxNQUFNLENBQUM7UUFDbEJpQixRQUFRLEVBQUVsQixvQkFBTSxDQUFDbUQsUUFBUSxDQUFDbkQsb0JBQU0sQ0FBQ1UsTUFBTSxDQUFDLENBQUM7TUFDM0MsQ0FBQztJQUNIO0VBQ0YsQ0FBQyxFQUNELE9BQU9hLE9BQU8sRUFBRUMsT0FBTyxFQUFFQyxRQUFRLEtBQUs7SUFDcEMsSUFBSTtNQUNGLE1BQU1DLE1BQU0sR0FBR0gsT0FBTyxDQUFDSSxJQUFJLENBQUNDLFVBQVUsQ0FBQ0YsTUFBTSxDQUFDRyxhQUFhO01BQzNELE1BQU13QixJQUFJLEdBQUcsTUFBTSxJQUFBQyx5QkFBa0IsRUFBQzVCLE1BQU0sQ0FBQztNQUM3QyxNQUFNeUMsT0FBTyxHQUFHLE1BQU1wQyx5QkFBVyxDQUFDOEMsVUFBVSxDQUMxQ25ELE1BQU0sRUFDTkYsT0FBTyxDQUFDZSxNQUFNLENBQUNDLEVBQUUsRUFDakJoQixPQUFPLENBQUNVLElBQUksQ0FBQ2hCLFFBQVEsRUFDckJtQyxJQUNGLENBQUM7TUFDRCxJQUFJLENBQUNjLE9BQU8sRUFBRTtRQUNaLE9BQU8xQyxRQUFRLENBQUNrQixRQUFRLENBQUM7VUFBRVQsSUFBSSxFQUFFO1lBQUVFLE9BQU8sRUFBRTtVQUFpQjtRQUFFLENBQUMsQ0FBQztNQUNuRTtNQUNBLE9BQU9YLFFBQVEsQ0FBQ1EsRUFBRSxDQUFDO1FBQUVDLElBQUksRUFBRWlDO01BQVEsQ0FBQyxDQUFDO0lBQ3ZDLENBQUMsQ0FBQyxPQUFPaEMsS0FBVSxFQUFFO01BQ25CeEMsTUFBTSxDQUFDd0MsS0FBSyxDQUFFLHlCQUF3QkEsS0FBSyxDQUFDQyxPQUFRLEVBQUMsQ0FBQztNQUN0RCxPQUFPWCxRQUFRLENBQUNZLFdBQVcsQ0FBQztRQUMxQkMsVUFBVSxFQUFFSCxLQUFLLENBQUNHLFVBQVUsSUFBSSxHQUFHO1FBQ25DSixJQUFJLEVBQUU7VUFBRUUsT0FBTyxFQUFFRCxLQUFLLENBQUNDLE9BQU8sSUFBSTtRQUF3QjtNQUM1RCxDQUFDLENBQUM7SUFDSjtFQUNGLENBQ0YsQ0FBQzs7RUFFRDtFQUNBMUMsTUFBTSxDQUFDa0QsSUFBSSxDQUNUO0lBQ0UvQyxJQUFJLEVBQUUsNkNBQTZDO0lBQ25EQyxRQUFRLEVBQUU7TUFDUnlDLE1BQU0sRUFBRXZDLG9CQUFNLENBQUNDLE1BQU0sQ0FBQztRQUNwQnVDLEVBQUUsRUFBRXhDLG9CQUFNLENBQUNVLE1BQU0sQ0FBQztNQUNwQixDQUFDLENBQUM7TUFDRndCLElBQUksRUFBRWxDLG9CQUFNLENBQUNDLE1BQU0sQ0FBQztRQUNsQjRDLEtBQUssRUFBRTdDLG9CQUFNLENBQUNVLE1BQU0sQ0FBQztNQUN2QixDQUFDO0lBQ0g7RUFDRixDQUFDLEVBQ0QsT0FBT2EsT0FBTyxFQUFFQyxPQUFPLEVBQUVDLFFBQVEsS0FBSztJQUNwQyxJQUFJO01BQ0YsTUFBTUMsTUFBTSxHQUFHSCxPQUFPLENBQUNJLElBQUksQ0FBQ0MsVUFBVSxDQUFDRixNQUFNLENBQUNHLGFBQWE7TUFDM0QsTUFBTXdCLElBQUksR0FBRyxNQUFNLElBQUFDLHlCQUFrQixFQUFDNUIsTUFBTSxDQUFDO01BQzdDLE1BQU15QyxPQUFPLEdBQUcsTUFBTXBDLHlCQUFXLENBQUMrQyxPQUFPLENBQUNwRCxNQUFNLEVBQUVGLE9BQU8sQ0FBQ2UsTUFBTSxDQUFDQyxFQUFFLEVBQUVoQixPQUFPLENBQUNVLElBQUksQ0FBQ1csS0FBSyxFQUFFUSxJQUFJLENBQUM7TUFDOUYsT0FBTzVCLFFBQVEsQ0FBQ1EsRUFBRSxDQUFDO1FBQUVDLElBQUksRUFBRWlDO01BQVEsQ0FBQyxDQUFDO0lBQ3ZDLENBQUMsQ0FBQyxPQUFPaEMsS0FBVSxFQUFFO01BQ25CLE9BQU9WLFFBQVEsQ0FBQ1ksV0FBVyxDQUFDO1FBQUVDLFVBQVUsRUFBRSxHQUFHO1FBQUVKLElBQUksRUFBRTtVQUFFRSxPQUFPLEVBQUVELEtBQUssQ0FBQ0M7UUFBUTtNQUFFLENBQUMsQ0FBQztJQUNwRjtFQUNGLENBQ0YsQ0FBQzs7RUFFRDtFQUNBMUMsTUFBTSxDQUFDcUYsS0FBSyxDQUNWO0lBQ0VsRixJQUFJLEVBQUUsc0RBQXNEO0lBQzVEQyxRQUFRLEVBQUU7TUFDUnlDLE1BQU0sRUFBRXZDLG9CQUFNLENBQUNDLE1BQU0sQ0FBQztRQUNwQnVDLEVBQUUsRUFBRXhDLG9CQUFNLENBQUNVLE1BQU0sQ0FBQyxDQUFDO1FBQ25Cc0UsTUFBTSxFQUFFaEYsb0JBQU0sQ0FBQ1UsTUFBTSxDQUFDO01BQ3hCLENBQUMsQ0FBQztNQUNGd0IsSUFBSSxFQUFFbEMsb0JBQU0sQ0FBQ0MsTUFBTSxDQUFDO1FBQ2xCZ0YsU0FBUyxFQUFFakYsb0JBQU0sQ0FBQ2tGLE9BQU8sQ0FBQztNQUM1QixDQUFDO0lBQ0g7RUFDRixDQUFDLEVBQ0QsT0FBTzNELE9BQU8sRUFBRUMsT0FBTyxFQUFFQyxRQUFRLEtBQUs7SUFDcEMsSUFBSTtNQUNGLE1BQU1DLE1BQU0sR0FBR0gsT0FBTyxDQUFDSSxJQUFJLENBQUNDLFVBQVUsQ0FBQ0YsTUFBTSxDQUFDRyxhQUFhO01BQzNELE1BQU13QixJQUFJLEdBQUcsTUFBTSxJQUFBQyx5QkFBa0IsRUFBQzVCLE1BQU0sQ0FBQztNQUM3QyxNQUFNeUMsT0FBTyxHQUFHLE1BQU1wQyx5QkFBVyxDQUFDb0QsVUFBVSxDQUFDekQsTUFBTSxFQUFFRixPQUFPLENBQUNlLE1BQU0sQ0FBQ0MsRUFBRSxFQUFFaEIsT0FBTyxDQUFDZSxNQUFNLENBQUN5QyxNQUFNLEVBQUV4RCxPQUFPLENBQUNVLElBQUksQ0FBQytDLFNBQVMsRUFBRTVCLElBQUksQ0FBQztNQUM1SCxPQUFPNUIsUUFBUSxDQUFDUSxFQUFFLENBQUM7UUFBRUMsSUFBSSxFQUFFaUM7TUFBUSxDQUFDLENBQUM7SUFDdkMsQ0FBQyxDQUFDLE9BQU9oQyxLQUFVLEVBQUU7TUFDbkIsT0FBT1YsUUFBUSxDQUFDWSxXQUFXLENBQUM7UUFBRUMsVUFBVSxFQUFFLEdBQUc7UUFBRUosSUFBSSxFQUFFO1VBQUVFLE9BQU8sRUFBRUQsS0FBSyxDQUFDQztRQUFRO01BQUUsQ0FBQyxDQUFDO0lBQ3BGO0VBQ0YsQ0FDRixDQUFDOztFQUVEO0VBQ0ExQyxNQUFNLENBQUMyRSxNQUFNLENBQ1g7SUFDRXhFLElBQUksRUFBRSxzREFBc0Q7SUFDNURDLFFBQVEsRUFBRTtNQUNSeUMsTUFBTSxFQUFFdkMsb0JBQU0sQ0FBQ0MsTUFBTSxDQUFDO1FBQ3BCdUMsRUFBRSxFQUFFeEMsb0JBQU0sQ0FBQ1UsTUFBTSxDQUFDLENBQUM7UUFDbkJzRSxNQUFNLEVBQUVoRixvQkFBTSxDQUFDVSxNQUFNLENBQUM7TUFDeEIsQ0FBQztJQUNIO0VBQ0YsQ0FBQyxFQUNELE9BQU9hLE9BQU8sRUFBRUMsT0FBTyxFQUFFQyxRQUFRLEtBQUs7SUFDcEMsSUFBSTtNQUNGLE1BQU1DLE1BQU0sR0FBR0gsT0FBTyxDQUFDSSxJQUFJLENBQUNDLFVBQVUsQ0FBQ0YsTUFBTSxDQUFDRyxhQUFhO01BQzNELE1BQU13QixJQUFJLEdBQUcsTUFBTSxJQUFBQyx5QkFBa0IsRUFBQzVCLE1BQU0sQ0FBQztNQUM3QyxNQUFNeUMsT0FBTyxHQUFHLE1BQU1wQyx5QkFBVyxDQUFDcUQsVUFBVSxDQUFDMUQsTUFBTSxFQUFFRixPQUFPLENBQUNlLE1BQU0sQ0FBQ0MsRUFBRSxFQUFFaEIsT0FBTyxDQUFDZSxNQUFNLENBQUN5QyxNQUFNLEVBQUUzQixJQUFJLENBQUM7TUFDcEcsT0FBTzVCLFFBQVEsQ0FBQ1EsRUFBRSxDQUFDO1FBQUVDLElBQUksRUFBRWlDO01BQVEsQ0FBQyxDQUFDO0lBQ3ZDLENBQUMsQ0FBQyxPQUFPaEMsS0FBVSxFQUFFO01BQ25CLE9BQU9WLFFBQVEsQ0FBQ1ksV0FBVyxDQUFDO1FBQUVDLFVBQVUsRUFBRSxHQUFHO1FBQUVKLElBQUksRUFBRTtVQUFFRSxPQUFPLEVBQUVELEtBQUssQ0FBQ0M7UUFBUTtNQUFFLENBQUMsQ0FBQztJQUNwRjtFQUNGLENBQ0YsQ0FBQzs7RUFFRDtFQUNBMUMsTUFBTSxDQUFDcUYsS0FBSyxDQUNWO0lBQ0VsRixJQUFJLEVBQUUsNkNBQTZDO0lBQ25EQyxRQUFRLEVBQUU7TUFDUnlDLE1BQU0sRUFBRXZDLG9CQUFNLENBQUNDLE1BQU0sQ0FBQztRQUNwQnVDLEVBQUUsRUFBRXhDLG9CQUFNLENBQUNVLE1BQU0sQ0FBQztNQUNwQixDQUFDLENBQUM7TUFDRndCLElBQUksRUFBRWxDLG9CQUFNLENBQUNDLE1BQU0sQ0FBQztRQUNsQm9GLEtBQUssRUFBRXJGLG9CQUFNLENBQUNVLE1BQU0sQ0FBQztVQUFFSixZQUFZLEVBQUU7UUFBRyxDQUFDO01BQzNDLENBQUM7SUFDSDtFQUNGLENBQUMsRUFDRCxPQUFPaUIsT0FBTyxFQUFFQyxPQUFPLEVBQUVDLFFBQVEsS0FBSztJQUNwQyxJQUFJO01BQ0YsTUFBTUMsTUFBTSxHQUFHSCxPQUFPLENBQUNJLElBQUksQ0FBQ0MsVUFBVSxDQUFDRixNQUFNLENBQUNHLGFBQWE7TUFDM0QsTUFBTXdCLElBQUksR0FBRyxNQUFNLElBQUFDLHlCQUFrQixFQUFDNUIsTUFBTSxDQUFDO01BQzdDLE1BQU15QyxPQUFPLEdBQUcsTUFBTXBDLHlCQUFXLENBQUN1RCxXQUFXLENBQUM1RCxNQUFNLEVBQUVGLE9BQU8sQ0FBQ2UsTUFBTSxDQUFDQyxFQUFFLEVBQUVoQixPQUFPLENBQUNVLElBQUksQ0FBQ21ELEtBQUssRUFBRWhDLElBQUksQ0FBQztNQUNsRyxPQUFPNUIsUUFBUSxDQUFDUSxFQUFFLENBQUM7UUFBRUMsSUFBSSxFQUFFaUM7TUFBUSxDQUFDLENBQUM7SUFDdkMsQ0FBQyxDQUFDLE9BQU9oQyxLQUFVLEVBQUU7TUFDbkIsT0FBT1YsUUFBUSxDQUFDWSxXQUFXLENBQUM7UUFBRUMsVUFBVSxFQUFFLEdBQUc7UUFBRUosSUFBSSxFQUFFO1VBQUVFLE9BQU8sRUFBRUQsS0FBSyxDQUFDQztRQUFRO01BQUUsQ0FBQyxDQUFDO0lBQ3BGO0VBQ0YsQ0FDRixDQUFDO0FBQ0gifQ==