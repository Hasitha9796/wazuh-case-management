"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.counterMappings = exports.caseMappings = void 0;
/*
 * Wazuh Case Management Plugin
 * OpenSearch index mappings for case management indices
 *
 * Defines the index settings and field mappings for:
 * - The main cases index (wazuh-case-management-cases)
 * - The counter index (wazuh-case-management-counter) for auto-incrementing IDs
 */

/**
 * Mappings for the main cases index.
 * Every field from the Case interface is mapped with an appropriate OpenSearch type.
 * Nested objects (linked_alerts, observables, comments, activity_log) use the
 * "nested" type so they can be queried independently.
 */
const caseMappings = exports.caseMappings = {
  settings: {
    number_of_shards: 1,
    number_of_replicas: 1,
    'index.mapping.total_fields.limit': 2000
  },
  mappings: {
    properties: {
      // ─── Core fields ──────────────────────────────────
      case_id: {
        type: 'keyword'
      },
      title: {
        type: 'text',
        fields: {
          keyword: {
            type: 'keyword'
          }
        }
      },
      description: {
        type: 'text'
      },
      status: {
        type: 'keyword'
      },
      severity: {
        type: 'keyword'
      },
      priority: {
        type: 'keyword'
      },
      category: {
        type: 'keyword'
      },
      tags: {
        type: 'keyword'
      },
      assignee: {
        type: 'keyword'
      },
      tlp: {
        type: 'keyword'
      },
      notes: {
        type: 'text'
      },
      // ─── Audit fields ────────────────────────────────
      created_by: {
        type: 'keyword'
      },
      created_at: {
        type: 'date'
      },
      updated_at: {
        type: 'date'
      },
      closed_at: {
        type: 'date'
      },
      // ─── Resolution ───────────────────────────────────
      resolution_summary: {
        type: 'text'
      },
      time_to_resolve_ms: {
        type: 'long'
      },
      // ─── Related cases ────────────────────────────────
      related_cases: {
        type: 'keyword'
      },
      // ─── Custom fields ────────────────────────────────
      custom_fields: {
        type: 'object',
        enabled: false
      },
      // ─── Tasks ────────────────────────────────────────
      tasks: {
        type: 'nested',
        properties: {
          task_id: {
            type: 'keyword'
          },
          title: {
            type: 'text',
            fields: {
              keyword: {
                type: 'keyword'
              }
            }
          },
          completed: {
            type: 'boolean'
          },
          assigned_to: {
            type: 'keyword'
          },
          due_date: {
            type: 'date'
          },
          created_at: {
            type: 'date'
          },
          created_by: {
            type: 'keyword'
          },
          completed_at: {
            type: 'date'
          },
          completed_by: {
            type: 'keyword'
          }
        }
      },
      // ─── Escalation state ─────────────────────────────
      escalation_state: {
        properties: {
          policy_id: {
            type: 'keyword'
          },
          level: {
            type: 'integer'
          },
          last_escalated_at: {
            type: 'date'
          },
          // Free-form audit trail: stored, not queried.
          history: {
            type: 'object',
            enabled: false
          }
        }
      },
      // ─── Linked Alerts (nested for independent queries) ─
      linked_alerts: {
        type: 'nested',
        properties: {
          alert_id: {
            type: 'keyword'
          },
          index: {
            type: 'keyword'
          },
          rule_id: {
            type: 'integer'
          },
          rule_description: {
            type: 'text',
            fields: {
              keyword: {
                type: 'keyword'
              }
            }
          },
          rule_level: {
            type: 'integer'
          },
          rule_groups: {
            type: 'keyword'
          },
          agent_id: {
            type: 'keyword'
          },
          agent_name: {
            type: 'keyword'
          },
          timestamp: {
            type: 'date'
          },
          manager_name: {
            type: 'keyword'
          },
          full_log: {
            type: 'text'
          }
        }
      },
      // ─── Observables (nested) ─────────────────────────
      observables: {
        type: 'nested',
        properties: {
          id: {
            type: 'keyword'
          },
          type: {
            type: 'keyword'
          },
          value: {
            type: 'keyword'
          },
          description: {
            type: 'text'
          },
          is_ioc: {
            type: 'boolean'
          },
          added_at: {
            type: 'date'
          },
          added_by: {
            type: 'keyword'
          }
        }
      },
      // ─── Comments (nested) ────────────────────────────
      comments: {
        type: 'nested',
        properties: {
          comment_id: {
            type: 'keyword'
          },
          author: {
            type: 'keyword'
          },
          content: {
            type: 'text'
          },
          created_at: {
            type: 'date'
          },
          updated_at: {
            type: 'date'
          }
        }
      },
      // ─── Activity Log (nested) ────────────────────────
      activity_log: {
        type: 'nested',
        properties: {
          id: {
            type: 'keyword'
          },
          action: {
            type: 'keyword'
          },
          user: {
            type: 'keyword'
          },
          timestamp: {
            type: 'date'
          },
          details: {
            type: 'object',
            enabled: false
          }
        }
      }
    }
  }
};

/**
 * Mappings for the counter index.
 * Stores a single document with the current counter value,
 * used to generate monotonically increasing case IDs.
 */
const counterMappings = exports.counterMappings = {
  settings: {
    number_of_shards: 1,
    number_of_replicas: 1
  },
  mappings: {
    properties: {
      counter_name: {
        type: 'keyword'
      },
      current_value: {
        type: 'long'
      }
    }
  }
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJjYXNlTWFwcGluZ3MiLCJleHBvcnRzIiwic2V0dGluZ3MiLCJudW1iZXJfb2Zfc2hhcmRzIiwibnVtYmVyX29mX3JlcGxpY2FzIiwibWFwcGluZ3MiLCJwcm9wZXJ0aWVzIiwiY2FzZV9pZCIsInR5cGUiLCJ0aXRsZSIsImZpZWxkcyIsImtleXdvcmQiLCJkZXNjcmlwdGlvbiIsInN0YXR1cyIsInNldmVyaXR5IiwicHJpb3JpdHkiLCJjYXRlZ29yeSIsInRhZ3MiLCJhc3NpZ25lZSIsInRscCIsIm5vdGVzIiwiY3JlYXRlZF9ieSIsImNyZWF0ZWRfYXQiLCJ1cGRhdGVkX2F0IiwiY2xvc2VkX2F0IiwicmVzb2x1dGlvbl9zdW1tYXJ5IiwidGltZV90b19yZXNvbHZlX21zIiwicmVsYXRlZF9jYXNlcyIsImN1c3RvbV9maWVsZHMiLCJlbmFibGVkIiwidGFza3MiLCJ0YXNrX2lkIiwiY29tcGxldGVkIiwiYXNzaWduZWRfdG8iLCJkdWVfZGF0ZSIsImNvbXBsZXRlZF9hdCIsImNvbXBsZXRlZF9ieSIsImVzY2FsYXRpb25fc3RhdGUiLCJwb2xpY3lfaWQiLCJsZXZlbCIsImxhc3RfZXNjYWxhdGVkX2F0IiwiaGlzdG9yeSIsImxpbmtlZF9hbGVydHMiLCJhbGVydF9pZCIsImluZGV4IiwicnVsZV9pZCIsInJ1bGVfZGVzY3JpcHRpb24iLCJydWxlX2xldmVsIiwicnVsZV9ncm91cHMiLCJhZ2VudF9pZCIsImFnZW50X25hbWUiLCJ0aW1lc3RhbXAiLCJtYW5hZ2VyX25hbWUiLCJmdWxsX2xvZyIsIm9ic2VydmFibGVzIiwiaWQiLCJ2YWx1ZSIsImlzX2lvYyIsImFkZGVkX2F0IiwiYWRkZWRfYnkiLCJjb21tZW50cyIsImNvbW1lbnRfaWQiLCJhdXRob3IiLCJjb250ZW50IiwiYWN0aXZpdHlfbG9nIiwiYWN0aW9uIiwidXNlciIsImRldGFpbHMiLCJjb3VudGVyTWFwcGluZ3MiLCJjb3VudGVyX25hbWUiLCJjdXJyZW50X3ZhbHVlIl0sInNvdXJjZXMiOlsiY2FzZV9tYXBwaW5ncy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogV2F6dWggQ2FzZSBNYW5hZ2VtZW50IFBsdWdpblxuICogT3BlblNlYXJjaCBpbmRleCBtYXBwaW5ncyBmb3IgY2FzZSBtYW5hZ2VtZW50IGluZGljZXNcbiAqXG4gKiBEZWZpbmVzIHRoZSBpbmRleCBzZXR0aW5ncyBhbmQgZmllbGQgbWFwcGluZ3MgZm9yOlxuICogLSBUaGUgbWFpbiBjYXNlcyBpbmRleCAod2F6dWgtY2FzZS1tYW5hZ2VtZW50LWNhc2VzKVxuICogLSBUaGUgY291bnRlciBpbmRleCAod2F6dWgtY2FzZS1tYW5hZ2VtZW50LWNvdW50ZXIpIGZvciBhdXRvLWluY3JlbWVudGluZyBJRHNcbiAqL1xuXG4vKipcbiAqIE1hcHBpbmdzIGZvciB0aGUgbWFpbiBjYXNlcyBpbmRleC5cbiAqIEV2ZXJ5IGZpZWxkIGZyb20gdGhlIENhc2UgaW50ZXJmYWNlIGlzIG1hcHBlZCB3aXRoIGFuIGFwcHJvcHJpYXRlIE9wZW5TZWFyY2ggdHlwZS5cbiAqIE5lc3RlZCBvYmplY3RzIChsaW5rZWRfYWxlcnRzLCBvYnNlcnZhYmxlcywgY29tbWVudHMsIGFjdGl2aXR5X2xvZykgdXNlIHRoZVxuICogXCJuZXN0ZWRcIiB0eXBlIHNvIHRoZXkgY2FuIGJlIHF1ZXJpZWQgaW5kZXBlbmRlbnRseS5cbiAqL1xuZXhwb3J0IGNvbnN0IGNhc2VNYXBwaW5ncyA9IHtcbiAgc2V0dGluZ3M6IHtcbiAgICBudW1iZXJfb2Zfc2hhcmRzOiAxLFxuICAgIG51bWJlcl9vZl9yZXBsaWNhczogMSxcbiAgICAnaW5kZXgubWFwcGluZy50b3RhbF9maWVsZHMubGltaXQnOiAyMDAwLFxuICB9LFxuICBtYXBwaW5nczoge1xuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgIC8vIOKUgOKUgOKUgCBDb3JlIGZpZWxkcyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgICAgIGNhc2VfaWQ6IHsgdHlwZTogJ2tleXdvcmQnIH0sXG4gICAgICB0aXRsZTogeyB0eXBlOiAndGV4dCcsIGZpZWxkczogeyBrZXl3b3JkOiB7IHR5cGU6ICdrZXl3b3JkJyB9IH0gfSxcbiAgICAgIGRlc2NyaXB0aW9uOiB7IHR5cGU6ICd0ZXh0JyB9LFxuICAgICAgc3RhdHVzOiB7IHR5cGU6ICdrZXl3b3JkJyB9LFxuICAgICAgc2V2ZXJpdHk6IHsgdHlwZTogJ2tleXdvcmQnIH0sXG4gICAgICBwcmlvcml0eTogeyB0eXBlOiAna2V5d29yZCcgfSxcbiAgICAgIGNhdGVnb3J5OiB7IHR5cGU6ICdrZXl3b3JkJyB9LFxuICAgICAgdGFnczogeyB0eXBlOiAna2V5d29yZCcgfSxcbiAgICAgIGFzc2lnbmVlOiB7IHR5cGU6ICdrZXl3b3JkJyB9LFxuICAgICAgdGxwOiB7IHR5cGU6ICdrZXl3b3JkJyB9LFxuICAgICAgbm90ZXM6IHsgdHlwZTogJ3RleHQnIH0sXG5cbiAgICAgIC8vIOKUgOKUgOKUgCBBdWRpdCBmaWVsZHMg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gICAgICBjcmVhdGVkX2J5OiB7IHR5cGU6ICdrZXl3b3JkJyB9LFxuICAgICAgY3JlYXRlZF9hdDogeyB0eXBlOiAnZGF0ZScgfSxcbiAgICAgIHVwZGF0ZWRfYXQ6IHsgdHlwZTogJ2RhdGUnIH0sXG4gICAgICBjbG9zZWRfYXQ6IHsgdHlwZTogJ2RhdGUnIH0sXG5cbiAgICAgIC8vIOKUgOKUgOKUgCBSZXNvbHV0aW9uIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICAgICAgcmVzb2x1dGlvbl9zdW1tYXJ5OiB7IHR5cGU6ICd0ZXh0JyB9LFxuICAgICAgdGltZV90b19yZXNvbHZlX21zOiB7IHR5cGU6ICdsb25nJyB9LFxuXG4gICAgICAvLyDilIDilIDilIAgUmVsYXRlZCBjYXNlcyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgICAgIHJlbGF0ZWRfY2FzZXM6IHsgdHlwZTogJ2tleXdvcmQnIH0sXG5cbiAgICAgIC8vIOKUgOKUgOKUgCBDdXN0b20gZmllbGRzIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICAgICAgY3VzdG9tX2ZpZWxkczogeyB0eXBlOiAnb2JqZWN0JywgZW5hYmxlZDogZmFsc2UgfSxcblxuICAgICAgLy8g4pSA4pSA4pSAIFRhc2tzIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICAgICAgdGFza3M6IHtcbiAgICAgICAgdHlwZTogJ25lc3RlZCcsXG4gICAgICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgICB0YXNrX2lkOiB7IHR5cGU6ICdrZXl3b3JkJyB9LFxuICAgICAgICAgIHRpdGxlOiB7IHR5cGU6ICd0ZXh0JywgZmllbGRzOiB7IGtleXdvcmQ6IHsgdHlwZTogJ2tleXdvcmQnIH0gfSB9LFxuICAgICAgICAgIGNvbXBsZXRlZDogeyB0eXBlOiAnYm9vbGVhbicgfSxcbiAgICAgICAgICBhc3NpZ25lZF90bzogeyB0eXBlOiAna2V5d29yZCcgfSxcbiAgICAgICAgICBkdWVfZGF0ZTogeyB0eXBlOiAnZGF0ZScgfSxcbiAgICAgICAgICBjcmVhdGVkX2F0OiB7IHR5cGU6ICdkYXRlJyB9LFxuICAgICAgICAgIGNyZWF0ZWRfYnk6IHsgdHlwZTogJ2tleXdvcmQnIH0sXG4gICAgICAgICAgY29tcGxldGVkX2F0OiB7IHR5cGU6ICdkYXRlJyB9LFxuICAgICAgICAgIGNvbXBsZXRlZF9ieTogeyB0eXBlOiAna2V5d29yZCcgfSxcbiAgICAgICAgfSxcbiAgICAgIH0sXG5cbiAgICAgIC8vIOKUgOKUgOKUgCBFc2NhbGF0aW9uIHN0YXRlIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICAgICAgZXNjYWxhdGlvbl9zdGF0ZToge1xuICAgICAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgICAgcG9saWN5X2lkOiB7IHR5cGU6ICdrZXl3b3JkJyB9LFxuICAgICAgICAgIGxldmVsOiB7IHR5cGU6ICdpbnRlZ2VyJyB9LFxuICAgICAgICAgIGxhc3RfZXNjYWxhdGVkX2F0OiB7IHR5cGU6ICdkYXRlJyB9LFxuICAgICAgICAgIC8vIEZyZWUtZm9ybSBhdWRpdCB0cmFpbDogc3RvcmVkLCBub3QgcXVlcmllZC5cbiAgICAgICAgICBoaXN0b3J5OiB7IHR5cGU6ICdvYmplY3QnLCBlbmFibGVkOiBmYWxzZSB9LFxuICAgICAgICB9LFxuICAgICAgfSxcblxuICAgICAgLy8g4pSA4pSA4pSAIExpbmtlZCBBbGVydHMgKG5lc3RlZCBmb3IgaW5kZXBlbmRlbnQgcXVlcmllcykg4pSAXG4gICAgICBsaW5rZWRfYWxlcnRzOiB7XG4gICAgICAgIHR5cGU6ICduZXN0ZWQnLFxuICAgICAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgICAgYWxlcnRfaWQ6IHsgdHlwZTogJ2tleXdvcmQnIH0sXG4gICAgICAgICAgaW5kZXg6IHsgdHlwZTogJ2tleXdvcmQnIH0sXG4gICAgICAgICAgcnVsZV9pZDogeyB0eXBlOiAnaW50ZWdlcicgfSxcbiAgICAgICAgICBydWxlX2Rlc2NyaXB0aW9uOiB7IHR5cGU6ICd0ZXh0JywgZmllbGRzOiB7IGtleXdvcmQ6IHsgdHlwZTogJ2tleXdvcmQnIH0gfSB9LFxuICAgICAgICAgIHJ1bGVfbGV2ZWw6IHsgdHlwZTogJ2ludGVnZXInIH0sXG4gICAgICAgICAgcnVsZV9ncm91cHM6IHsgdHlwZTogJ2tleXdvcmQnIH0sXG4gICAgICAgICAgYWdlbnRfaWQ6IHsgdHlwZTogJ2tleXdvcmQnIH0sXG4gICAgICAgICAgYWdlbnRfbmFtZTogeyB0eXBlOiAna2V5d29yZCcgfSxcbiAgICAgICAgICB0aW1lc3RhbXA6IHsgdHlwZTogJ2RhdGUnIH0sXG4gICAgICAgICAgbWFuYWdlcl9uYW1lOiB7IHR5cGU6ICdrZXl3b3JkJyB9LFxuICAgICAgICAgIGZ1bGxfbG9nOiB7IHR5cGU6ICd0ZXh0JyB9LFxuICAgICAgICB9LFxuICAgICAgfSxcblxuICAgICAgLy8g4pSA4pSA4pSAIE9ic2VydmFibGVzIChuZXN0ZWQpIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICAgICAgb2JzZXJ2YWJsZXM6IHtcbiAgICAgICAgdHlwZTogJ25lc3RlZCcsXG4gICAgICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgICBpZDogeyB0eXBlOiAna2V5d29yZCcgfSxcbiAgICAgICAgICB0eXBlOiB7IHR5cGU6ICdrZXl3b3JkJyB9LFxuICAgICAgICAgIHZhbHVlOiB7IHR5cGU6ICdrZXl3b3JkJyB9LFxuICAgICAgICAgIGRlc2NyaXB0aW9uOiB7IHR5cGU6ICd0ZXh0JyB9LFxuICAgICAgICAgIGlzX2lvYzogeyB0eXBlOiAnYm9vbGVhbicgfSxcbiAgICAgICAgICBhZGRlZF9hdDogeyB0eXBlOiAnZGF0ZScgfSxcbiAgICAgICAgICBhZGRlZF9ieTogeyB0eXBlOiAna2V5d29yZCcgfSxcbiAgICAgICAgfSxcbiAgICAgIH0sXG5cbiAgICAgIC8vIOKUgOKUgOKUgCBDb21tZW50cyAobmVzdGVkKSDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgICAgIGNvbW1lbnRzOiB7XG4gICAgICAgIHR5cGU6ICduZXN0ZWQnLFxuICAgICAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgICAgY29tbWVudF9pZDogeyB0eXBlOiAna2V5d29yZCcgfSxcbiAgICAgICAgICBhdXRob3I6IHsgdHlwZTogJ2tleXdvcmQnIH0sXG4gICAgICAgICAgY29udGVudDogeyB0eXBlOiAndGV4dCcgfSxcbiAgICAgICAgICBjcmVhdGVkX2F0OiB7IHR5cGU6ICdkYXRlJyB9LFxuICAgICAgICAgIHVwZGF0ZWRfYXQ6IHsgdHlwZTogJ2RhdGUnIH0sXG4gICAgICAgIH0sXG4gICAgICB9LFxuXG4gICAgICAvLyDilIDilIDilIAgQWN0aXZpdHkgTG9nIChuZXN0ZWQpIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICAgICAgYWN0aXZpdHlfbG9nOiB7XG4gICAgICAgIHR5cGU6ICduZXN0ZWQnLFxuICAgICAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgICAgaWQ6IHsgdHlwZTogJ2tleXdvcmQnIH0sXG4gICAgICAgICAgYWN0aW9uOiB7IHR5cGU6ICdrZXl3b3JkJyB9LFxuICAgICAgICAgIHVzZXI6IHsgdHlwZTogJ2tleXdvcmQnIH0sXG4gICAgICAgICAgdGltZXN0YW1wOiB7IHR5cGU6ICdkYXRlJyB9LFxuICAgICAgICAgIGRldGFpbHM6IHsgdHlwZTogJ29iamVjdCcsIGVuYWJsZWQ6IGZhbHNlIH0sXG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgIH0sXG4gIH0sXG59O1xuXG4vKipcbiAqIE1hcHBpbmdzIGZvciB0aGUgY291bnRlciBpbmRleC5cbiAqIFN0b3JlcyBhIHNpbmdsZSBkb2N1bWVudCB3aXRoIHRoZSBjdXJyZW50IGNvdW50ZXIgdmFsdWUsXG4gKiB1c2VkIHRvIGdlbmVyYXRlIG1vbm90b25pY2FsbHkgaW5jcmVhc2luZyBjYXNlIElEcy5cbiAqL1xuZXhwb3J0IGNvbnN0IGNvdW50ZXJNYXBwaW5ncyA9IHtcbiAgc2V0dGluZ3M6IHtcbiAgICBudW1iZXJfb2Zfc2hhcmRzOiAxLFxuICAgIG51bWJlcl9vZl9yZXBsaWNhczogMSxcbiAgfSxcbiAgbWFwcGluZ3M6IHtcbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICBjb3VudGVyX25hbWU6IHsgdHlwZTogJ2tleXdvcmQnIH0sXG4gICAgICBjdXJyZW50X3ZhbHVlOiB7IHR5cGU6ICdsb25nJyB9LFxuICAgIH0sXG4gIH0sXG59O1xuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLE1BQU1BLFlBQVksR0FBQUMsT0FBQSxDQUFBRCxZQUFBLEdBQUc7RUFDMUJFLFFBQVEsRUFBRTtJQUNSQyxnQkFBZ0IsRUFBRSxDQUFDO0lBQ25CQyxrQkFBa0IsRUFBRSxDQUFDO0lBQ3JCLGtDQUFrQyxFQUFFO0VBQ3RDLENBQUM7RUFDREMsUUFBUSxFQUFFO0lBQ1JDLFVBQVUsRUFBRTtNQUNWO01BQ0FDLE9BQU8sRUFBRTtRQUFFQyxJQUFJLEVBQUU7TUFBVSxDQUFDO01BQzVCQyxLQUFLLEVBQUU7UUFBRUQsSUFBSSxFQUFFLE1BQU07UUFBRUUsTUFBTSxFQUFFO1VBQUVDLE9BQU8sRUFBRTtZQUFFSCxJQUFJLEVBQUU7VUFBVTtRQUFFO01BQUUsQ0FBQztNQUNqRUksV0FBVyxFQUFFO1FBQUVKLElBQUksRUFBRTtNQUFPLENBQUM7TUFDN0JLLE1BQU0sRUFBRTtRQUFFTCxJQUFJLEVBQUU7TUFBVSxDQUFDO01BQzNCTSxRQUFRLEVBQUU7UUFBRU4sSUFBSSxFQUFFO01BQVUsQ0FBQztNQUM3Qk8sUUFBUSxFQUFFO1FBQUVQLElBQUksRUFBRTtNQUFVLENBQUM7TUFDN0JRLFFBQVEsRUFBRTtRQUFFUixJQUFJLEVBQUU7TUFBVSxDQUFDO01BQzdCUyxJQUFJLEVBQUU7UUFBRVQsSUFBSSxFQUFFO01BQVUsQ0FBQztNQUN6QlUsUUFBUSxFQUFFO1FBQUVWLElBQUksRUFBRTtNQUFVLENBQUM7TUFDN0JXLEdBQUcsRUFBRTtRQUFFWCxJQUFJLEVBQUU7TUFBVSxDQUFDO01BQ3hCWSxLQUFLLEVBQUU7UUFBRVosSUFBSSxFQUFFO01BQU8sQ0FBQztNQUV2QjtNQUNBYSxVQUFVLEVBQUU7UUFBRWIsSUFBSSxFQUFFO01BQVUsQ0FBQztNQUMvQmMsVUFBVSxFQUFFO1FBQUVkLElBQUksRUFBRTtNQUFPLENBQUM7TUFDNUJlLFVBQVUsRUFBRTtRQUFFZixJQUFJLEVBQUU7TUFBTyxDQUFDO01BQzVCZ0IsU0FBUyxFQUFFO1FBQUVoQixJQUFJLEVBQUU7TUFBTyxDQUFDO01BRTNCO01BQ0FpQixrQkFBa0IsRUFBRTtRQUFFakIsSUFBSSxFQUFFO01BQU8sQ0FBQztNQUNwQ2tCLGtCQUFrQixFQUFFO1FBQUVsQixJQUFJLEVBQUU7TUFBTyxDQUFDO01BRXBDO01BQ0FtQixhQUFhLEVBQUU7UUFBRW5CLElBQUksRUFBRTtNQUFVLENBQUM7TUFFbEM7TUFDQW9CLGFBQWEsRUFBRTtRQUFFcEIsSUFBSSxFQUFFLFFBQVE7UUFBRXFCLE9BQU8sRUFBRTtNQUFNLENBQUM7TUFFakQ7TUFDQUMsS0FBSyxFQUFFO1FBQ0x0QixJQUFJLEVBQUUsUUFBUTtRQUNkRixVQUFVLEVBQUU7VUFDVnlCLE9BQU8sRUFBRTtZQUFFdkIsSUFBSSxFQUFFO1VBQVUsQ0FBQztVQUM1QkMsS0FBSyxFQUFFO1lBQUVELElBQUksRUFBRSxNQUFNO1lBQUVFLE1BQU0sRUFBRTtjQUFFQyxPQUFPLEVBQUU7Z0JBQUVILElBQUksRUFBRTtjQUFVO1lBQUU7VUFBRSxDQUFDO1VBQ2pFd0IsU0FBUyxFQUFFO1lBQUV4QixJQUFJLEVBQUU7VUFBVSxDQUFDO1VBQzlCeUIsV0FBVyxFQUFFO1lBQUV6QixJQUFJLEVBQUU7VUFBVSxDQUFDO1VBQ2hDMEIsUUFBUSxFQUFFO1lBQUUxQixJQUFJLEVBQUU7VUFBTyxDQUFDO1VBQzFCYyxVQUFVLEVBQUU7WUFBRWQsSUFBSSxFQUFFO1VBQU8sQ0FBQztVQUM1QmEsVUFBVSxFQUFFO1lBQUViLElBQUksRUFBRTtVQUFVLENBQUM7VUFDL0IyQixZQUFZLEVBQUU7WUFBRTNCLElBQUksRUFBRTtVQUFPLENBQUM7VUFDOUI0QixZQUFZLEVBQUU7WUFBRTVCLElBQUksRUFBRTtVQUFVO1FBQ2xDO01BQ0YsQ0FBQztNQUVEO01BQ0E2QixnQkFBZ0IsRUFBRTtRQUNoQi9CLFVBQVUsRUFBRTtVQUNWZ0MsU0FBUyxFQUFFO1lBQUU5QixJQUFJLEVBQUU7VUFBVSxDQUFDO1VBQzlCK0IsS0FBSyxFQUFFO1lBQUUvQixJQUFJLEVBQUU7VUFBVSxDQUFDO1VBQzFCZ0MsaUJBQWlCLEVBQUU7WUFBRWhDLElBQUksRUFBRTtVQUFPLENBQUM7VUFDbkM7VUFDQWlDLE9BQU8sRUFBRTtZQUFFakMsSUFBSSxFQUFFLFFBQVE7WUFBRXFCLE9BQU8sRUFBRTtVQUFNO1FBQzVDO01BQ0YsQ0FBQztNQUVEO01BQ0FhLGFBQWEsRUFBRTtRQUNibEMsSUFBSSxFQUFFLFFBQVE7UUFDZEYsVUFBVSxFQUFFO1VBQ1ZxQyxRQUFRLEVBQUU7WUFBRW5DLElBQUksRUFBRTtVQUFVLENBQUM7VUFDN0JvQyxLQUFLLEVBQUU7WUFBRXBDLElBQUksRUFBRTtVQUFVLENBQUM7VUFDMUJxQyxPQUFPLEVBQUU7WUFBRXJDLElBQUksRUFBRTtVQUFVLENBQUM7VUFDNUJzQyxnQkFBZ0IsRUFBRTtZQUFFdEMsSUFBSSxFQUFFLE1BQU07WUFBRUUsTUFBTSxFQUFFO2NBQUVDLE9BQU8sRUFBRTtnQkFBRUgsSUFBSSxFQUFFO2NBQVU7WUFBRTtVQUFFLENBQUM7VUFDNUV1QyxVQUFVLEVBQUU7WUFBRXZDLElBQUksRUFBRTtVQUFVLENBQUM7VUFDL0J3QyxXQUFXLEVBQUU7WUFBRXhDLElBQUksRUFBRTtVQUFVLENBQUM7VUFDaEN5QyxRQUFRLEVBQUU7WUFBRXpDLElBQUksRUFBRTtVQUFVLENBQUM7VUFDN0IwQyxVQUFVLEVBQUU7WUFBRTFDLElBQUksRUFBRTtVQUFVLENBQUM7VUFDL0IyQyxTQUFTLEVBQUU7WUFBRTNDLElBQUksRUFBRTtVQUFPLENBQUM7VUFDM0I0QyxZQUFZLEVBQUU7WUFBRTVDLElBQUksRUFBRTtVQUFVLENBQUM7VUFDakM2QyxRQUFRLEVBQUU7WUFBRTdDLElBQUksRUFBRTtVQUFPO1FBQzNCO01BQ0YsQ0FBQztNQUVEO01BQ0E4QyxXQUFXLEVBQUU7UUFDWDlDLElBQUksRUFBRSxRQUFRO1FBQ2RGLFVBQVUsRUFBRTtVQUNWaUQsRUFBRSxFQUFFO1lBQUUvQyxJQUFJLEVBQUU7VUFBVSxDQUFDO1VBQ3ZCQSxJQUFJLEVBQUU7WUFBRUEsSUFBSSxFQUFFO1VBQVUsQ0FBQztVQUN6QmdELEtBQUssRUFBRTtZQUFFaEQsSUFBSSxFQUFFO1VBQVUsQ0FBQztVQUMxQkksV0FBVyxFQUFFO1lBQUVKLElBQUksRUFBRTtVQUFPLENBQUM7VUFDN0JpRCxNQUFNLEVBQUU7WUFBRWpELElBQUksRUFBRTtVQUFVLENBQUM7VUFDM0JrRCxRQUFRLEVBQUU7WUFBRWxELElBQUksRUFBRTtVQUFPLENBQUM7VUFDMUJtRCxRQUFRLEVBQUU7WUFBRW5ELElBQUksRUFBRTtVQUFVO1FBQzlCO01BQ0YsQ0FBQztNQUVEO01BQ0FvRCxRQUFRLEVBQUU7UUFDUnBELElBQUksRUFBRSxRQUFRO1FBQ2RGLFVBQVUsRUFBRTtVQUNWdUQsVUFBVSxFQUFFO1lBQUVyRCxJQUFJLEVBQUU7VUFBVSxDQUFDO1VBQy9Cc0QsTUFBTSxFQUFFO1lBQUV0RCxJQUFJLEVBQUU7VUFBVSxDQUFDO1VBQzNCdUQsT0FBTyxFQUFFO1lBQUV2RCxJQUFJLEVBQUU7VUFBTyxDQUFDO1VBQ3pCYyxVQUFVLEVBQUU7WUFBRWQsSUFBSSxFQUFFO1VBQU8sQ0FBQztVQUM1QmUsVUFBVSxFQUFFO1lBQUVmLElBQUksRUFBRTtVQUFPO1FBQzdCO01BQ0YsQ0FBQztNQUVEO01BQ0F3RCxZQUFZLEVBQUU7UUFDWnhELElBQUksRUFBRSxRQUFRO1FBQ2RGLFVBQVUsRUFBRTtVQUNWaUQsRUFBRSxFQUFFO1lBQUUvQyxJQUFJLEVBQUU7VUFBVSxDQUFDO1VBQ3ZCeUQsTUFBTSxFQUFFO1lBQUV6RCxJQUFJLEVBQUU7VUFBVSxDQUFDO1VBQzNCMEQsSUFBSSxFQUFFO1lBQUUxRCxJQUFJLEVBQUU7VUFBVSxDQUFDO1VBQ3pCMkMsU0FBUyxFQUFFO1lBQUUzQyxJQUFJLEVBQUU7VUFBTyxDQUFDO1VBQzNCMkQsT0FBTyxFQUFFO1lBQUUzRCxJQUFJLEVBQUUsUUFBUTtZQUFFcUIsT0FBTyxFQUFFO1VBQU07UUFDNUM7TUFDRjtJQUNGO0VBQ0Y7QUFDRixDQUFDOztBQUVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxNQUFNdUMsZUFBZSxHQUFBbkUsT0FBQSxDQUFBbUUsZUFBQSxHQUFHO0VBQzdCbEUsUUFBUSxFQUFFO0lBQ1JDLGdCQUFnQixFQUFFLENBQUM7SUFDbkJDLGtCQUFrQixFQUFFO0VBQ3RCLENBQUM7RUFDREMsUUFBUSxFQUFFO0lBQ1JDLFVBQVUsRUFBRTtNQUNWK0QsWUFBWSxFQUFFO1FBQUU3RCxJQUFJLEVBQUU7TUFBVSxDQUFDO01BQ2pDOEQsYUFBYSxFQUFFO1FBQUU5RCxJQUFJLEVBQUU7TUFBTztJQUNoQztFQUNGO0FBQ0YsQ0FBQyJ9