"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.counterMappings = exports.caseMappings = void 0;
/*
 * Wazuh Case Management Plugin
 * OpenSearch index mappings for case management indices
 *
 * Defines the index settings and field mappings for:
 * - The main cases index (wazuh-case-management-cases)
 * - The counter index (wazuh-case-management-counter) for auto-incrementing IDs
 */

/**
 * Mappings for the main cases index.
 * Every field from the Case interface is mapped with an appropriate OpenSearch type.
 * Nested objects (linked_alerts, observables, comments, activity_log) use the
 * "nested" type so they can be queried independently.
 */
const caseMappings = exports.caseMappings = {
  settings: {
    number_of_shards: 1,
    number_of_replicas: 1,
    'index.mapping.total_fields.limit': 2000
  },
  mappings: {
    properties: {
      // ─── Core fields ──────────────────────────────────
      case_id: {
        type: 'keyword'
      },
      title: {
        type: 'text',
        fields: {
          keyword: {
            type: 'keyword'
          }
        }
      },
      description: {
        type: 'text'
      },
      status: {
        type: 'keyword'
      },
      severity: {
        type: 'keyword'
      },
      priority: {
        type: 'keyword'
      },
      category: {
        type: 'keyword'
      },
      tags: {
        type: 'keyword'
      },
      assignee: {
        type: 'keyword'
      },
      tlp: {
        type: 'keyword'
      },
      notes: {
        type: 'text'
      },
      // ─── Audit fields ────────────────────────────────
      created_by: {
        type: 'keyword'
      },
      created_at: {
        type: 'date'
      },
      updated_at: {
        type: 'date'
      },
      closed_at: {
        type: 'date'
      },
      // ─── Resolution ───────────────────────────────────
      resolution_summary: {
        type: 'text'
      },
      time_to_resolve_ms: {
        type: 'long'
      },
      // ─── Related cases ────────────────────────────────
      related_cases: {
        type: 'keyword'
      },
      // ─── Custom fields ────────────────────────────────
      custom_fields: {
        type: 'object',
        enabled: false
      },
      // ─── Linked Alerts (nested for independent queries) ─
      linked_alerts: {
        type: 'nested',
        properties: {
          alert_id: {
            type: 'keyword'
          },
          index: {
            type: 'keyword'
          },
          rule_id: {
            type: 'integer'
          },
          rule_description: {
            type: 'text',
            fields: {
              keyword: {
                type: 'keyword'
              }
            }
          },
          rule_level: {
            type: 'integer'
          },
          rule_groups: {
            type: 'keyword'
          },
          agent_id: {
            type: 'keyword'
          },
          agent_name: {
            type: 'keyword'
          },
          timestamp: {
            type: 'date'
          },
          manager_name: {
            type: 'keyword'
          },
          full_log: {
            type: 'text'
          }
        }
      },
      // ─── Observables (nested) ─────────────────────────
      observables: {
        type: 'nested',
        properties: {
          id: {
            type: 'keyword'
          },
          type: {
            type: 'keyword'
          },
          value: {
            type: 'keyword'
          },
          description: {
            type: 'text'
          },
          is_ioc: {
            type: 'boolean'
          },
          added_at: {
            type: 'date'
          },
          added_by: {
            type: 'keyword'
          }
        }
      },
      // ─── Comments (nested) ────────────────────────────
      comments: {
        type: 'nested',
        properties: {
          comment_id: {
            type: 'keyword'
          },
          author: {
            type: 'keyword'
          },
          content: {
            type: 'text'
          },
          created_at: {
            type: 'date'
          },
          updated_at: {
            type: 'date'
          }
        }
      },
      // ─── Activity Log (nested) ────────────────────────
      activity_log: {
        type: 'nested',
        properties: {
          id: {
            type: 'keyword'
          },
          action: {
            type: 'keyword'
          },
          user: {
            type: 'keyword'
          },
          timestamp: {
            type: 'date'
          },
          details: {
            type: 'object',
            enabled: false
          }
        }
      }
    }
  }
};

/**
 * Mappings for the counter index.
 * Stores a single document with the current counter value,
 * used to generate monotonically increasing case IDs.
 */
const counterMappings = exports.counterMappings = {
  settings: {
    number_of_shards: 1,
    number_of_replicas: 1
  },
  mappings: {
    properties: {
      counter_name: {
        type: 'keyword'
      },
      current_value: {
        type: 'long'
      }
    }
  }
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJjYXNlTWFwcGluZ3MiLCJleHBvcnRzIiwic2V0dGluZ3MiLCJudW1iZXJfb2Zfc2hhcmRzIiwibnVtYmVyX29mX3JlcGxpY2FzIiwibWFwcGluZ3MiLCJwcm9wZXJ0aWVzIiwiY2FzZV9pZCIsInR5cGUiLCJ0aXRsZSIsImZpZWxkcyIsImtleXdvcmQiLCJkZXNjcmlwdGlvbiIsInN0YXR1cyIsInNldmVyaXR5IiwicHJpb3JpdHkiLCJjYXRlZ29yeSIsInRhZ3MiLCJhc3NpZ25lZSIsInRscCIsIm5vdGVzIiwiY3JlYXRlZF9ieSIsImNyZWF0ZWRfYXQiLCJ1cGRhdGVkX2F0IiwiY2xvc2VkX2F0IiwicmVzb2x1dGlvbl9zdW1tYXJ5IiwidGltZV90b19yZXNvbHZlX21zIiwicmVsYXRlZF9jYXNlcyIsImN1c3RvbV9maWVsZHMiLCJlbmFibGVkIiwibGlua2VkX2FsZXJ0cyIsImFsZXJ0X2lkIiwiaW5kZXgiLCJydWxlX2lkIiwicnVsZV9kZXNjcmlwdGlvbiIsInJ1bGVfbGV2ZWwiLCJydWxlX2dyb3VwcyIsImFnZW50X2lkIiwiYWdlbnRfbmFtZSIsInRpbWVzdGFtcCIsIm1hbmFnZXJfbmFtZSIsImZ1bGxfbG9nIiwib2JzZXJ2YWJsZXMiLCJpZCIsInZhbHVlIiwiaXNfaW9jIiwiYWRkZWRfYXQiLCJhZGRlZF9ieSIsImNvbW1lbnRzIiwiY29tbWVudF9pZCIsImF1dGhvciIsImNvbnRlbnQiLCJhY3Rpdml0eV9sb2ciLCJhY3Rpb24iLCJ1c2VyIiwiZGV0YWlscyIsImNvdW50ZXJNYXBwaW5ncyIsImNvdW50ZXJfbmFtZSIsImN1cnJlbnRfdmFsdWUiXSwic291cmNlcyI6WyJjYXNlX21hcHBpbmdzLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qXG4gKiBXYXp1aCBDYXNlIE1hbmFnZW1lbnQgUGx1Z2luXG4gKiBPcGVuU2VhcmNoIGluZGV4IG1hcHBpbmdzIGZvciBjYXNlIG1hbmFnZW1lbnQgaW5kaWNlc1xuICpcbiAqIERlZmluZXMgdGhlIGluZGV4IHNldHRpbmdzIGFuZCBmaWVsZCBtYXBwaW5ncyBmb3I6XG4gKiAtIFRoZSBtYWluIGNhc2VzIGluZGV4ICh3YXp1aC1jYXNlLW1hbmFnZW1lbnQtY2FzZXMpXG4gKiAtIFRoZSBjb3VudGVyIGluZGV4ICh3YXp1aC1jYXNlLW1hbmFnZW1lbnQtY291bnRlcikgZm9yIGF1dG8taW5jcmVtZW50aW5nIElEc1xuICovXG5cbi8qKlxuICogTWFwcGluZ3MgZm9yIHRoZSBtYWluIGNhc2VzIGluZGV4LlxuICogRXZlcnkgZmllbGQgZnJvbSB0aGUgQ2FzZSBpbnRlcmZhY2UgaXMgbWFwcGVkIHdpdGggYW4gYXBwcm9wcmlhdGUgT3BlblNlYXJjaCB0eXBlLlxuICogTmVzdGVkIG9iamVjdHMgKGxpbmtlZF9hbGVydHMsIG9ic2VydmFibGVzLCBjb21tZW50cywgYWN0aXZpdHlfbG9nKSB1c2UgdGhlXG4gKiBcIm5lc3RlZFwiIHR5cGUgc28gdGhleSBjYW4gYmUgcXVlcmllZCBpbmRlcGVuZGVudGx5LlxuICovXG5leHBvcnQgY29uc3QgY2FzZU1hcHBpbmdzID0ge1xuICBzZXR0aW5nczoge1xuICAgIG51bWJlcl9vZl9zaGFyZHM6IDEsXG4gICAgbnVtYmVyX29mX3JlcGxpY2FzOiAxLFxuICAgICdpbmRleC5tYXBwaW5nLnRvdGFsX2ZpZWxkcy5saW1pdCc6IDIwMDAsXG4gIH0sXG4gIG1hcHBpbmdzOiB7XG4gICAgcHJvcGVydGllczoge1xuICAgICAgLy8g4pSA4pSA4pSAIENvcmUgZmllbGRzIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICAgICAgY2FzZV9pZDogeyB0eXBlOiAna2V5d29yZCcgfSxcbiAgICAgIHRpdGxlOiB7IHR5cGU6ICd0ZXh0JywgZmllbGRzOiB7IGtleXdvcmQ6IHsgdHlwZTogJ2tleXdvcmQnIH0gfSB9LFxuICAgICAgZGVzY3JpcHRpb246IHsgdHlwZTogJ3RleHQnIH0sXG4gICAgICBzdGF0dXM6IHsgdHlwZTogJ2tleXdvcmQnIH0sXG4gICAgICBzZXZlcml0eTogeyB0eXBlOiAna2V5d29yZCcgfSxcbiAgICAgIHByaW9yaXR5OiB7IHR5cGU6ICdrZXl3b3JkJyB9LFxuICAgICAgY2F0ZWdvcnk6IHsgdHlwZTogJ2tleXdvcmQnIH0sXG4gICAgICB0YWdzOiB7IHR5cGU6ICdrZXl3b3JkJyB9LFxuICAgICAgYXNzaWduZWU6IHsgdHlwZTogJ2tleXdvcmQnIH0sXG4gICAgICB0bHA6IHsgdHlwZTogJ2tleXdvcmQnIH0sXG4gICAgICBub3RlczogeyB0eXBlOiAndGV4dCcgfSxcblxuICAgICAgLy8g4pSA4pSA4pSAIEF1ZGl0IGZpZWxkcyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgICAgIGNyZWF0ZWRfYnk6IHsgdHlwZTogJ2tleXdvcmQnIH0sXG4gICAgICBjcmVhdGVkX2F0OiB7IHR5cGU6ICdkYXRlJyB9LFxuICAgICAgdXBkYXRlZF9hdDogeyB0eXBlOiAnZGF0ZScgfSxcbiAgICAgIGNsb3NlZF9hdDogeyB0eXBlOiAnZGF0ZScgfSxcblxuICAgICAgLy8g4pSA4pSA4pSAIFJlc29sdXRpb24g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gICAgICByZXNvbHV0aW9uX3N1bW1hcnk6IHsgdHlwZTogJ3RleHQnIH0sXG4gICAgICB0aW1lX3RvX3Jlc29sdmVfbXM6IHsgdHlwZTogJ2xvbmcnIH0sXG5cbiAgICAgIC8vIOKUgOKUgOKUgCBSZWxhdGVkIGNhc2VzIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICAgICAgcmVsYXRlZF9jYXNlczogeyB0eXBlOiAna2V5d29yZCcgfSxcblxuICAgICAgLy8g4pSA4pSA4pSAIEN1c3RvbSBmaWVsZHMg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gICAgICBjdXN0b21fZmllbGRzOiB7IHR5cGU6ICdvYmplY3QnLCBlbmFibGVkOiBmYWxzZSB9LFxuXG4gICAgICAvLyDilIDilIDilIAgTGlua2VkIEFsZXJ0cyAobmVzdGVkIGZvciBpbmRlcGVuZGVudCBxdWVyaWVzKSDilIBcbiAgICAgIGxpbmtlZF9hbGVydHM6IHtcbiAgICAgICAgdHlwZTogJ25lc3RlZCcsXG4gICAgICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgICBhbGVydF9pZDogeyB0eXBlOiAna2V5d29yZCcgfSxcbiAgICAgICAgICBpbmRleDogeyB0eXBlOiAna2V5d29yZCcgfSxcbiAgICAgICAgICBydWxlX2lkOiB7IHR5cGU6ICdpbnRlZ2VyJyB9LFxuICAgICAgICAgIHJ1bGVfZGVzY3JpcHRpb246IHsgdHlwZTogJ3RleHQnLCBmaWVsZHM6IHsga2V5d29yZDogeyB0eXBlOiAna2V5d29yZCcgfSB9IH0sXG4gICAgICAgICAgcnVsZV9sZXZlbDogeyB0eXBlOiAnaW50ZWdlcicgfSxcbiAgICAgICAgICBydWxlX2dyb3VwczogeyB0eXBlOiAna2V5d29yZCcgfSxcbiAgICAgICAgICBhZ2VudF9pZDogeyB0eXBlOiAna2V5d29yZCcgfSxcbiAgICAgICAgICBhZ2VudF9uYW1lOiB7IHR5cGU6ICdrZXl3b3JkJyB9LFxuICAgICAgICAgIHRpbWVzdGFtcDogeyB0eXBlOiAnZGF0ZScgfSxcbiAgICAgICAgICBtYW5hZ2VyX25hbWU6IHsgdHlwZTogJ2tleXdvcmQnIH0sXG4gICAgICAgICAgZnVsbF9sb2c6IHsgdHlwZTogJ3RleHQnIH0sXG4gICAgICAgIH0sXG4gICAgICB9LFxuXG4gICAgICAvLyDilIDilIDilIAgT2JzZXJ2YWJsZXMgKG5lc3RlZCkg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gICAgICBvYnNlcnZhYmxlczoge1xuICAgICAgICB0eXBlOiAnbmVzdGVkJyxcbiAgICAgICAgcHJvcGVydGllczoge1xuICAgICAgICAgIGlkOiB7IHR5cGU6ICdrZXl3b3JkJyB9LFxuICAgICAgICAgIHR5cGU6IHsgdHlwZTogJ2tleXdvcmQnIH0sXG4gICAgICAgICAgdmFsdWU6IHsgdHlwZTogJ2tleXdvcmQnIH0sXG4gICAgICAgICAgZGVzY3JpcHRpb246IHsgdHlwZTogJ3RleHQnIH0sXG4gICAgICAgICAgaXNfaW9jOiB7IHR5cGU6ICdib29sZWFuJyB9LFxuICAgICAgICAgIGFkZGVkX2F0OiB7IHR5cGU6ICdkYXRlJyB9LFxuICAgICAgICAgIGFkZGVkX2J5OiB7IHR5cGU6ICdrZXl3b3JkJyB9LFxuICAgICAgICB9LFxuICAgICAgfSxcblxuICAgICAgLy8g4pSA4pSA4pSAIENvbW1lbnRzIChuZXN0ZWQpIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICAgICAgY29tbWVudHM6IHtcbiAgICAgICAgdHlwZTogJ25lc3RlZCcsXG4gICAgICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgICBjb21tZW50X2lkOiB7IHR5cGU6ICdrZXl3b3JkJyB9LFxuICAgICAgICAgIGF1dGhvcjogeyB0eXBlOiAna2V5d29yZCcgfSxcbiAgICAgICAgICBjb250ZW50OiB7IHR5cGU6ICd0ZXh0JyB9LFxuICAgICAgICAgIGNyZWF0ZWRfYXQ6IHsgdHlwZTogJ2RhdGUnIH0sXG4gICAgICAgICAgdXBkYXRlZF9hdDogeyB0eXBlOiAnZGF0ZScgfSxcbiAgICAgICAgfSxcbiAgICAgIH0sXG5cbiAgICAgIC8vIOKUgOKUgOKUgCBBY3Rpdml0eSBMb2cgKG5lc3RlZCkg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gICAgICBhY3Rpdml0eV9sb2c6IHtcbiAgICAgICAgdHlwZTogJ25lc3RlZCcsXG4gICAgICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgICBpZDogeyB0eXBlOiAna2V5d29yZCcgfSxcbiAgICAgICAgICBhY3Rpb246IHsgdHlwZTogJ2tleXdvcmQnIH0sXG4gICAgICAgICAgdXNlcjogeyB0eXBlOiAna2V5d29yZCcgfSxcbiAgICAgICAgICB0aW1lc3RhbXA6IHsgdHlwZTogJ2RhdGUnIH0sXG4gICAgICAgICAgZGV0YWlsczogeyB0eXBlOiAnb2JqZWN0JywgZW5hYmxlZDogZmFsc2UgfSxcbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgfSxcbiAgfSxcbn07XG5cbi8qKlxuICogTWFwcGluZ3MgZm9yIHRoZSBjb3VudGVyIGluZGV4LlxuICogU3RvcmVzIGEgc2luZ2xlIGRvY3VtZW50IHdpdGggdGhlIGN1cnJlbnQgY291bnRlciB2YWx1ZSxcbiAqIHVzZWQgdG8gZ2VuZXJhdGUgbW9ub3RvbmljYWxseSBpbmNyZWFzaW5nIGNhc2UgSURzLlxuICovXG5leHBvcnQgY29uc3QgY291bnRlck1hcHBpbmdzID0ge1xuICBzZXR0aW5nczoge1xuICAgIG51bWJlcl9vZl9zaGFyZHM6IDEsXG4gICAgbnVtYmVyX29mX3JlcGxpY2FzOiAxLFxuICB9LFxuICBtYXBwaW5nczoge1xuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgIGNvdW50ZXJfbmFtZTogeyB0eXBlOiAna2V5d29yZCcgfSxcbiAgICAgIGN1cnJlbnRfdmFsdWU6IHsgdHlwZTogJ2xvbmcnIH0sXG4gICAgfSxcbiAgfSxcbn07XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sTUFBTUEsWUFBWSxHQUFBQyxPQUFBLENBQUFELFlBQUEsR0FBRztFQUMxQkUsUUFBUSxFQUFFO0lBQ1JDLGdCQUFnQixFQUFFLENBQUM7SUFDbkJDLGtCQUFrQixFQUFFLENBQUM7SUFDckIsa0NBQWtDLEVBQUU7RUFDdEMsQ0FBQztFQUNEQyxRQUFRLEVBQUU7SUFDUkMsVUFBVSxFQUFFO01BQ1Y7TUFDQUMsT0FBTyxFQUFFO1FBQUVDLElBQUksRUFBRTtNQUFVLENBQUM7TUFDNUJDLEtBQUssRUFBRTtRQUFFRCxJQUFJLEVBQUUsTUFBTTtRQUFFRSxNQUFNLEVBQUU7VUFBRUMsT0FBTyxFQUFFO1lBQUVILElBQUksRUFBRTtVQUFVO1FBQUU7TUFBRSxDQUFDO01BQ2pFSSxXQUFXLEVBQUU7UUFBRUosSUFBSSxFQUFFO01BQU8sQ0FBQztNQUM3QkssTUFBTSxFQUFFO1FBQUVMLElBQUksRUFBRTtNQUFVLENBQUM7TUFDM0JNLFFBQVEsRUFBRTtRQUFFTixJQUFJLEVBQUU7TUFBVSxDQUFDO01BQzdCTyxRQUFRLEVBQUU7UUFBRVAsSUFBSSxFQUFFO01BQVUsQ0FBQztNQUM3QlEsUUFBUSxFQUFFO1FBQUVSLElBQUksRUFBRTtNQUFVLENBQUM7TUFDN0JTLElBQUksRUFBRTtRQUFFVCxJQUFJLEVBQUU7TUFBVSxDQUFDO01BQ3pCVSxRQUFRLEVBQUU7UUFBRVYsSUFBSSxFQUFFO01BQVUsQ0FBQztNQUM3QlcsR0FBRyxFQUFFO1FBQUVYLElBQUksRUFBRTtNQUFVLENBQUM7TUFDeEJZLEtBQUssRUFBRTtRQUFFWixJQUFJLEVBQUU7TUFBTyxDQUFDO01BRXZCO01BQ0FhLFVBQVUsRUFBRTtRQUFFYixJQUFJLEVBQUU7TUFBVSxDQUFDO01BQy9CYyxVQUFVLEVBQUU7UUFBRWQsSUFBSSxFQUFFO01BQU8sQ0FBQztNQUM1QmUsVUFBVSxFQUFFO1FBQUVmLElBQUksRUFBRTtNQUFPLENBQUM7TUFDNUJnQixTQUFTLEVBQUU7UUFBRWhCLElBQUksRUFBRTtNQUFPLENBQUM7TUFFM0I7TUFDQWlCLGtCQUFrQixFQUFFO1FBQUVqQixJQUFJLEVBQUU7TUFBTyxDQUFDO01BQ3BDa0Isa0JBQWtCLEVBQUU7UUFBRWxCLElBQUksRUFBRTtNQUFPLENBQUM7TUFFcEM7TUFDQW1CLGFBQWEsRUFBRTtRQUFFbkIsSUFBSSxFQUFFO01BQVUsQ0FBQztNQUVsQztNQUNBb0IsYUFBYSxFQUFFO1FBQUVwQixJQUFJLEVBQUUsUUFBUTtRQUFFcUIsT0FBTyxFQUFFO01BQU0sQ0FBQztNQUVqRDtNQUNBQyxhQUFhLEVBQUU7UUFDYnRCLElBQUksRUFBRSxRQUFRO1FBQ2RGLFVBQVUsRUFBRTtVQUNWeUIsUUFBUSxFQUFFO1lBQUV2QixJQUFJLEVBQUU7VUFBVSxDQUFDO1VBQzdCd0IsS0FBSyxFQUFFO1lBQUV4QixJQUFJLEVBQUU7VUFBVSxDQUFDO1VBQzFCeUIsT0FBTyxFQUFFO1lBQUV6QixJQUFJLEVBQUU7VUFBVSxDQUFDO1VBQzVCMEIsZ0JBQWdCLEVBQUU7WUFBRTFCLElBQUksRUFBRSxNQUFNO1lBQUVFLE1BQU0sRUFBRTtjQUFFQyxPQUFPLEVBQUU7Z0JBQUVILElBQUksRUFBRTtjQUFVO1lBQUU7VUFBRSxDQUFDO1VBQzVFMkIsVUFBVSxFQUFFO1lBQUUzQixJQUFJLEVBQUU7VUFBVSxDQUFDO1VBQy9CNEIsV0FBVyxFQUFFO1lBQUU1QixJQUFJLEVBQUU7VUFBVSxDQUFDO1VBQ2hDNkIsUUFBUSxFQUFFO1lBQUU3QixJQUFJLEVBQUU7VUFBVSxDQUFDO1VBQzdCOEIsVUFBVSxFQUFFO1lBQUU5QixJQUFJLEVBQUU7VUFBVSxDQUFDO1VBQy9CK0IsU0FBUyxFQUFFO1lBQUUvQixJQUFJLEVBQUU7VUFBTyxDQUFDO1VBQzNCZ0MsWUFBWSxFQUFFO1lBQUVoQyxJQUFJLEVBQUU7VUFBVSxDQUFDO1VBQ2pDaUMsUUFBUSxFQUFFO1lBQUVqQyxJQUFJLEVBQUU7VUFBTztRQUMzQjtNQUNGLENBQUM7TUFFRDtNQUNBa0MsV0FBVyxFQUFFO1FBQ1hsQyxJQUFJLEVBQUUsUUFBUTtRQUNkRixVQUFVLEVBQUU7VUFDVnFDLEVBQUUsRUFBRTtZQUFFbkMsSUFBSSxFQUFFO1VBQVUsQ0FBQztVQUN2QkEsSUFBSSxFQUFFO1lBQUVBLElBQUksRUFBRTtVQUFVLENBQUM7VUFDekJvQyxLQUFLLEVBQUU7WUFBRXBDLElBQUksRUFBRTtVQUFVLENBQUM7VUFDMUJJLFdBQVcsRUFBRTtZQUFFSixJQUFJLEVBQUU7VUFBTyxDQUFDO1VBQzdCcUMsTUFBTSxFQUFFO1lBQUVyQyxJQUFJLEVBQUU7VUFBVSxDQUFDO1VBQzNCc0MsUUFBUSxFQUFFO1lBQUV0QyxJQUFJLEVBQUU7VUFBTyxDQUFDO1VBQzFCdUMsUUFBUSxFQUFFO1lBQUV2QyxJQUFJLEVBQUU7VUFBVTtRQUM5QjtNQUNGLENBQUM7TUFFRDtNQUNBd0MsUUFBUSxFQUFFO1FBQ1J4QyxJQUFJLEVBQUUsUUFBUTtRQUNkRixVQUFVLEVBQUU7VUFDVjJDLFVBQVUsRUFBRTtZQUFFekMsSUFBSSxFQUFFO1VBQVUsQ0FBQztVQUMvQjBDLE1BQU0sRUFBRTtZQUFFMUMsSUFBSSxFQUFFO1VBQVUsQ0FBQztVQUMzQjJDLE9BQU8sRUFBRTtZQUFFM0MsSUFBSSxFQUFFO1VBQU8sQ0FBQztVQUN6QmMsVUFBVSxFQUFFO1lBQUVkLElBQUksRUFBRTtVQUFPLENBQUM7VUFDNUJlLFVBQVUsRUFBRTtZQUFFZixJQUFJLEVBQUU7VUFBTztRQUM3QjtNQUNGLENBQUM7TUFFRDtNQUNBNEMsWUFBWSxFQUFFO1FBQ1o1QyxJQUFJLEVBQUUsUUFBUTtRQUNkRixVQUFVLEVBQUU7VUFDVnFDLEVBQUUsRUFBRTtZQUFFbkMsSUFBSSxFQUFFO1VBQVUsQ0FBQztVQUN2QjZDLE1BQU0sRUFBRTtZQUFFN0MsSUFBSSxFQUFFO1VBQVUsQ0FBQztVQUMzQjhDLElBQUksRUFBRTtZQUFFOUMsSUFBSSxFQUFFO1VBQVUsQ0FBQztVQUN6QitCLFNBQVMsRUFBRTtZQUFFL0IsSUFBSSxFQUFFO1VBQU8sQ0FBQztVQUMzQitDLE9BQU8sRUFBRTtZQUFFL0MsSUFBSSxFQUFFLFFBQVE7WUFBRXFCLE9BQU8sRUFBRTtVQUFNO1FBQzVDO01BQ0Y7SUFDRjtFQUNGO0FBQ0YsQ0FBQzs7QUFFRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sTUFBTTJCLGVBQWUsR0FBQXZELE9BQUEsQ0FBQXVELGVBQUEsR0FBRztFQUM3QnRELFFBQVEsRUFBRTtJQUNSQyxnQkFBZ0IsRUFBRSxDQUFDO0lBQ25CQyxrQkFBa0IsRUFBRTtFQUN0QixDQUFDO0VBQ0RDLFFBQVEsRUFBRTtJQUNSQyxVQUFVLEVBQUU7TUFDVm1ELFlBQVksRUFBRTtRQUFFakQsSUFBSSxFQUFFO01BQVUsQ0FBQztNQUNqQ2tELGFBQWEsRUFBRTtRQUFFbEQsSUFBSSxFQUFFO01BQU87SUFDaEM7RUFDRjtBQUNGLENBQUMifQ==