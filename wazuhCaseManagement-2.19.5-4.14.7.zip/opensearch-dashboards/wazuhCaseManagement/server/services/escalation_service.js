"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.EscalationService = void 0;
var _constants = require("../../common/constants");
var _opensearch_service = require("./opensearch_service");
var _settings_service = require("./settings_service");
var _notification_service = require("./notification_service");
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); } /*
 * Wazuh Case Management Plugin
 * Escalation Service: time- and priority-based escalation trees
 *
 * A policy matches a set of cases (by priority / severity / category / status /
 * tag) and defines an ordered ladder of steps. Each step fires once the case has
 * been open for `after_minutes`, and can notify someone, raise or set the
 * priority, reassign the case, or tag it.
 *
 * Progress is recorded on the case itself (`escalation_state`), so a step never
 * fires twice and the ladder survives restarts.
 */
/** Priority ladder, most urgent first. */
const PRIORITY_LADDER = ['P1', 'P2', 'P3', 'P4'];

/** Statuses considered "still needs attention" when a policy names none. */
const DEFAULT_ACTIVE_STATUSES = ['open', 'in_progress', 'waiting'];
const EMPTY_STATE = {
  policy_id: null,
  level: 0,
  last_escalated_at: null,
  history: []
};
class EscalationService {
  // ── Background job ───────────────────────────────────────────

  static start(client, logger) {
    if (EscalationService.intervalHandle) return;
    EscalationService.intervalHandle = setInterval(async () => {
      try {
        await EscalationService.run(client, logger);
      } catch (e) {
        logger.warn(`Escalation tick error: ${e.message}`);
      }
    }, 60_000);
    logger.info('Escalation background job started (checking every 60s)');
  }
  static stop() {
    if (EscalationService.intervalHandle) {
      clearInterval(EscalationService.intervalHandle);
      EscalationService.intervalHandle = null;
    }
  }

  // ── Evaluation ───────────────────────────────────────────────

  /**
   * Evaluate every active case against the configured policies and apply any
   * steps that have come due. Returns the number of steps applied.
   */
  static async run(client, logger) {
    if (EscalationService.running) return {
      escalated: 0,
      steps: 0
    };
    EscalationService.running = true;
    try {
      const settings = await _settings_service.SettingsService.getSettings(client);
      if (!settings.escalation.enabled) return {
        escalated: 0,
        steps: 0
      };
      const policies = [...settings.escalation.policies].filter(p => p.enabled && p.steps.length > 0).sort((a, b) => {
        var _a$order, _b$order;
        return ((_a$order = a.order) !== null && _a$order !== void 0 ? _a$order : 0) - ((_b$order = b.order) !== null && _b$order !== void 0 ? _b$order : 0);
      });
      if (policies.length === 0) return {
        escalated: 0,
        steps: 0
      };
      const cases = await EscalationService.fetchActiveCases(client, logger);
      let escalated = 0;
      let steps = 0;
      for (const caseItem of cases) {
        const policy = policies.find(p => EscalationService.policyMatches(p, caseItem));
        if (!policy) continue;
        const applied = await EscalationService.applyDuePolicySteps(client, caseItem, policy, logger);
        if (applied > 0) {
          escalated++;
          steps += applied;
        }
      }
      if (steps > 0) logger.info(`Escalation: applied ${steps} step(s) across ${escalated} case(s)`);
      return {
        escalated,
        steps
      };
    } finally {
      EscalationService.running = false;
    }
  }
  static async fetchActiveCases(client, logger) {
    try {
      var _body$hits;
      const {
        body
      } = await client.search({
        index: _constants.CASE_INDEX,
        body: {
          query: {
            bool: {
              must_not: [{
                terms: {
                  status: ['closed', 'resolved']
                }
              }]
            }
          },
          sort: [{
            created_at: {
              order: 'asc'
            }
          }],
          size: 1000
        }
      });
      return (((_body$hits = body.hits) === null || _body$hits === void 0 ? void 0 : _body$hits.hits) || []).map(h => ({
        id: h._id,
        ...h._source
      }));
    } catch (e) {
      logger.warn(`Escalation: could not list active cases: ${e.message}`);
      return [];
    }
  }

  /** Does this policy apply to this case? Empty criteria lists mean "any". */
  static policyMatches(policy, caseItem) {
    var _m$statuses, _m$priorities, _m$severities, _m$categories, _m$tags;
    const m = policy.match || {};
    const statuses = (_m$statuses = m.statuses) !== null && _m$statuses !== void 0 && _m$statuses.length ? m.statuses : DEFAULT_ACTIVE_STATUSES;
    if (!statuses.includes(caseItem.status)) return false;
    if ((_m$priorities = m.priorities) !== null && _m$priorities !== void 0 && _m$priorities.length && !m.priorities.includes(caseItem.priority)) return false;
    if ((_m$severities = m.severities) !== null && _m$severities !== void 0 && _m$severities.length && !m.severities.includes(caseItem.severity)) return false;
    if ((_m$categories = m.categories) !== null && _m$categories !== void 0 && _m$categories.length && !m.categories.includes(caseItem.category)) return false;
    if ((_m$tags = m.tags) !== null && _m$tags !== void 0 && _m$tags.length && !m.tags.some(tag => (caseItem.tags || []).includes(tag))) {
      return false;
    }
    return true;
  }

  /** How many steps of this policy are due for this case, given its age. */
  static dueStepCount(policy, caseItem, now = Date.now()) {
    const baseField = policy.base === 'updated_at' ? caseItem.updated_at : caseItem.created_at;
    const baseTime = new Date(baseField).getTime();
    if (Number.isNaN(baseTime)) return 0;
    const elapsedMinutes = (now - baseTime) / 60_000;
    const ordered = [...policy.steps].sort((a, b) => a.after_minutes - b.after_minutes);
    return ordered.filter(s => elapsedMinutes >= s.after_minutes).length;
  }
  static async applyDuePolicySteps(client, caseItem, policy, logger) {
    const state = {
      ...EMPTY_STATE,
      ...(caseItem.escalation_state || {})
    };

    // Switching policies restarts the ladder for this case.
    const currentLevel = state.policy_id === policy.id ? state.level || 0 : 0;
    const due = EscalationService.dueStepCount(policy, caseItem);
    if (due <= currentLevel) return 0;
    const ordered = [...policy.steps].sort((a, b) => a.after_minutes - b.after_minutes);
    const now = new Date().toISOString();
    const updateDoc = {
      updated_at: now
    };
    const history = [...(state.history || [])];
    let working = {
      ...caseItem
    };
    let applied = 0;
    for (let i = currentLevel; i < due && i < ordered.length; i++) {
      const step = ordered[i];
      try {
        const detail = await EscalationService.applyStep(client, working, policy, step, i, updateDoc, logger);
        // Keep the working copy in sync so a later step sees earlier changes.
        working = {
          ...working,
          ...updateDoc
        };
        history.push({
          policy_id: policy.id,
          step_index: i,
          action: step.action,
          detail,
          at: now
        });
        applied++;
      } catch (e) {
        logger.warn(`Escalation: step ${i} of "${policy.name}" failed on ${caseItem.case_id}: ${e.message}`);
      }
    }
    if (applied === 0) return 0;
    updateDoc.escalation_state = {
      policy_id: policy.id,
      level: currentLevel + applied,
      last_escalated_at: now,
      // Cap the trail so a long-lived case can't grow the document without bound.
      history: history.slice(-50)
    };

    // Escalation is a system action, recorded in the case timeline like any other.
    updateDoc.activity_log = [...(caseItem.activity_log || []), {
      id: `esc-${Date.now().toString(36)}`,
      action: 'priority_changed',
      user: 'escalation',
      timestamp: now,
      details: {
        policy: policy.name,
        steps_applied: applied,
        level: currentLevel + applied
      }
    }];
    await _opensearch_service.OpenSearchService.updateDocument(client, _constants.CASE_INDEX, caseItem.id, updateDoc);
    await _notification_service.NotificationService.dispatch(client, {
      event: 'case_escalated',
      recipients: [working.assignee, caseItem.created_by],
      title: `Case ${caseItem.case_id} escalated`,
      message: `Policy "${policy.name}" applied ${applied} step(s). The case is now at level ${currentLevel + applied}.`,
      caseRef: {
        ...caseItem,
        ...updateDoc
      },
      actor: 'escalation',
      context: {
        policy: policy.name,
        level: currentLevel + applied
      }
    }, logger);
    return applied;
  }

  /**
   * Apply one step, accumulating field changes into `updateDoc`.
   * Returns a short human-readable description of what happened.
   */
  static async applyStep(client, caseItem, policy, step, index, updateDoc, logger) {
    switch (step.action) {
      case 'raise_priority':
        {
          const current = updateDoc.priority || caseItem.priority;
          const pos = PRIORITY_LADDER.indexOf(current);
          // Index 0 is P1: already the most urgent.
          if (pos <= 0) return `priority already at ${current}`;
          const next = PRIORITY_LADDER[pos - 1];
          updateDoc.priority = next;
          return `priority raised from ${current} to ${next}`;
        }
      case 'set_priority':
        {
          const target = (step.target || '').toUpperCase();
          if (!PRIORITY_LADDER.includes(target)) {
            return `invalid target priority "${step.target}"`;
          }
          updateDoc.priority = target;
          return `priority set to ${target}`;
        }
      case 'reassign':
        {
          if (!step.target) return 'no reassign target configured';
          updateDoc.assignee = step.target;
          await _notification_service.NotificationService.dispatch(client, {
            event: 'case_assigned',
            recipients: [step.target],
            title: `Case ${caseItem.case_id} escalated to you`,
            message: `Escalation policy "${policy.name}" reassigned this case to you.`,
            caseRef: caseItem,
            actor: 'escalation'
          }, logger);
          return `reassigned to ${step.target}`;
        }
      case 'add_tag':
        {
          if (!step.target) return 'no tag configured';
          const tags = new Set([...(updateDoc.tags || caseItem.tags || []), step.target]);
          updateDoc.tags = Array.from(tags);
          return `tagged "${step.target}"`;
        }
      case 'notify':
      default:
        {
          const recipients = step.target ? [step.target] : [updateDoc.assignee || caseItem.assignee, caseItem.created_by];
          await _notification_service.NotificationService.dispatch(client, {
            event: 'case_escalated',
            recipients,
            title: `Escalation: ${caseItem.case_id}`,
            message: `Step ${index + 1} of "${policy.name}". The case has been open ${step.after_minutes} minute(s) without resolution.`,
            caseRef: caseItem,
            actor: 'escalation',
            context: {
              policy: policy.name,
              step: index + 1
            }
          }, logger);
          return `notified ${recipients.filter(Boolean).join(', ') || 'nobody'}`;
        }
    }
  }
}
exports.EscalationService = EscalationService;
_defineProperty(EscalationService, "intervalHandle", null);
_defineProperty(EscalationService, "running", false);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfY29uc3RhbnRzIiwicmVxdWlyZSIsIl9vcGVuc2VhcmNoX3NlcnZpY2UiLCJfc2V0dGluZ3Nfc2VydmljZSIsIl9ub3RpZmljYXRpb25fc2VydmljZSIsIl9kZWZpbmVQcm9wZXJ0eSIsImUiLCJyIiwidCIsIl90b1Byb3BlcnR5S2V5IiwiT2JqZWN0IiwiZGVmaW5lUHJvcGVydHkiLCJ2YWx1ZSIsImVudW1lcmFibGUiLCJjb25maWd1cmFibGUiLCJ3cml0YWJsZSIsImkiLCJfdG9QcmltaXRpdmUiLCJTeW1ib2wiLCJ0b1ByaW1pdGl2ZSIsImNhbGwiLCJUeXBlRXJyb3IiLCJTdHJpbmciLCJOdW1iZXIiLCJQUklPUklUWV9MQURERVIiLCJERUZBVUxUX0FDVElWRV9TVEFUVVNFUyIsIkVNUFRZX1NUQVRFIiwicG9saWN5X2lkIiwibGV2ZWwiLCJsYXN0X2VzY2FsYXRlZF9hdCIsImhpc3RvcnkiLCJFc2NhbGF0aW9uU2VydmljZSIsInN0YXJ0IiwiY2xpZW50IiwibG9nZ2VyIiwiaW50ZXJ2YWxIYW5kbGUiLCJzZXRJbnRlcnZhbCIsInJ1biIsIndhcm4iLCJtZXNzYWdlIiwiaW5mbyIsInN0b3AiLCJjbGVhckludGVydmFsIiwicnVubmluZyIsImVzY2FsYXRlZCIsInN0ZXBzIiwic2V0dGluZ3MiLCJTZXR0aW5nc1NlcnZpY2UiLCJnZXRTZXR0aW5ncyIsImVzY2FsYXRpb24iLCJlbmFibGVkIiwicG9saWNpZXMiLCJmaWx0ZXIiLCJwIiwibGVuZ3RoIiwic29ydCIsImEiLCJiIiwiX2Ekb3JkZXIiLCJfYiRvcmRlciIsIm9yZGVyIiwiY2FzZXMiLCJmZXRjaEFjdGl2ZUNhc2VzIiwiY2FzZUl0ZW0iLCJwb2xpY3kiLCJmaW5kIiwicG9saWN5TWF0Y2hlcyIsImFwcGxpZWQiLCJhcHBseUR1ZVBvbGljeVN0ZXBzIiwiX2JvZHkkaGl0cyIsImJvZHkiLCJzZWFyY2giLCJpbmRleCIsIkNBU0VfSU5ERVgiLCJxdWVyeSIsImJvb2wiLCJtdXN0X25vdCIsInRlcm1zIiwic3RhdHVzIiwiY3JlYXRlZF9hdCIsInNpemUiLCJoaXRzIiwibWFwIiwiaCIsImlkIiwiX2lkIiwiX3NvdXJjZSIsIl9tJHN0YXR1c2VzIiwiX20kcHJpb3JpdGllcyIsIl9tJHNldmVyaXRpZXMiLCJfbSRjYXRlZ29yaWVzIiwiX20kdGFncyIsIm0iLCJtYXRjaCIsInN0YXR1c2VzIiwiaW5jbHVkZXMiLCJwcmlvcml0aWVzIiwicHJpb3JpdHkiLCJzZXZlcml0aWVzIiwic2V2ZXJpdHkiLCJjYXRlZ29yaWVzIiwiY2F0ZWdvcnkiLCJ0YWdzIiwic29tZSIsInRhZyIsImR1ZVN0ZXBDb3VudCIsIm5vdyIsIkRhdGUiLCJiYXNlRmllbGQiLCJiYXNlIiwidXBkYXRlZF9hdCIsImJhc2VUaW1lIiwiZ2V0VGltZSIsImlzTmFOIiwiZWxhcHNlZE1pbnV0ZXMiLCJvcmRlcmVkIiwiYWZ0ZXJfbWludXRlcyIsInMiLCJzdGF0ZSIsImVzY2FsYXRpb25fc3RhdGUiLCJjdXJyZW50TGV2ZWwiLCJkdWUiLCJ0b0lTT1N0cmluZyIsInVwZGF0ZURvYyIsIndvcmtpbmciLCJzdGVwIiwiZGV0YWlsIiwiYXBwbHlTdGVwIiwicHVzaCIsInN0ZXBfaW5kZXgiLCJhY3Rpb24iLCJhdCIsIm5hbWUiLCJjYXNlX2lkIiwic2xpY2UiLCJhY3Rpdml0eV9sb2ciLCJ0b1N0cmluZyIsInVzZXIiLCJ0aW1lc3RhbXAiLCJkZXRhaWxzIiwic3RlcHNfYXBwbGllZCIsIk9wZW5TZWFyY2hTZXJ2aWNlIiwidXBkYXRlRG9jdW1lbnQiLCJOb3RpZmljYXRpb25TZXJ2aWNlIiwiZGlzcGF0Y2giLCJldmVudCIsInJlY2lwaWVudHMiLCJhc3NpZ25lZSIsImNyZWF0ZWRfYnkiLCJ0aXRsZSIsImNhc2VSZWYiLCJhY3RvciIsImNvbnRleHQiLCJjdXJyZW50IiwicG9zIiwiaW5kZXhPZiIsIm5leHQiLCJ0YXJnZXQiLCJ0b1VwcGVyQ2FzZSIsIlNldCIsIkFycmF5IiwiZnJvbSIsIkJvb2xlYW4iLCJqb2luIiwiZXhwb3J0cyJdLCJzb3VyY2VzIjpbImVzY2FsYXRpb25fc2VydmljZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogV2F6dWggQ2FzZSBNYW5hZ2VtZW50IFBsdWdpblxuICogRXNjYWxhdGlvbiBTZXJ2aWNlOiB0aW1lLSBhbmQgcHJpb3JpdHktYmFzZWQgZXNjYWxhdGlvbiB0cmVlc1xuICpcbiAqIEEgcG9saWN5IG1hdGNoZXMgYSBzZXQgb2YgY2FzZXMgKGJ5IHByaW9yaXR5IC8gc2V2ZXJpdHkgLyBjYXRlZ29yeSAvIHN0YXR1cyAvXG4gKiB0YWcpIGFuZCBkZWZpbmVzIGFuIG9yZGVyZWQgbGFkZGVyIG9mIHN0ZXBzLiBFYWNoIHN0ZXAgZmlyZXMgb25jZSB0aGUgY2FzZSBoYXNcbiAqIGJlZW4gb3BlbiBmb3IgYGFmdGVyX21pbnV0ZXNgLCBhbmQgY2FuIG5vdGlmeSBzb21lb25lLCByYWlzZSBvciBzZXQgdGhlXG4gKiBwcmlvcml0eSwgcmVhc3NpZ24gdGhlIGNhc2UsIG9yIHRhZyBpdC5cbiAqXG4gKiBQcm9ncmVzcyBpcyByZWNvcmRlZCBvbiB0aGUgY2FzZSBpdHNlbGYgKGBlc2NhbGF0aW9uX3N0YXRlYCksIHNvIGEgc3RlcCBuZXZlclxuICogZmlyZXMgdHdpY2UgYW5kIHRoZSBsYWRkZXIgc3Vydml2ZXMgcmVzdGFydHMuXG4gKi9cblxuaW1wb3J0IHsgTG9nZ2VyIH0gZnJvbSAnLi4vLi4vLi4vLi4vc3JjL2NvcmUvc2VydmVyJztcbmltcG9ydCB7XG4gIENhc2UsXG4gIENhc2VFc2NhbGF0aW9uU3RhdGUsXG4gIEVzY2FsYXRpb25Qb2xpY3ksXG4gIEVzY2FsYXRpb25TdGVwLFxuICBDYXNlUHJpb3JpdHksXG59IGZyb20gJy4uLy4uL2NvbW1vbi90eXBlcyc7XG5pbXBvcnQgeyBDQVNFX0lOREVYIH0gZnJvbSAnLi4vLi4vY29tbW9uL2NvbnN0YW50cyc7XG5pbXBvcnQgeyBPcGVuU2VhcmNoU2VydmljZSB9IGZyb20gJy4vb3BlbnNlYXJjaF9zZXJ2aWNlJztcbmltcG9ydCB7IFNldHRpbmdzU2VydmljZSB9IGZyb20gJy4vc2V0dGluZ3Nfc2VydmljZSc7XG5pbXBvcnQgeyBOb3RpZmljYXRpb25TZXJ2aWNlIH0gZnJvbSAnLi9ub3RpZmljYXRpb25fc2VydmljZSc7XG5cbi8qKiBQcmlvcml0eSBsYWRkZXIsIG1vc3QgdXJnZW50IGZpcnN0LiAqL1xuY29uc3QgUFJJT1JJVFlfTEFEREVSOiBDYXNlUHJpb3JpdHlbXSA9IFsnUDEnLCAnUDInLCAnUDMnLCAnUDQnXTtcblxuLyoqIFN0YXR1c2VzIGNvbnNpZGVyZWQgXCJzdGlsbCBuZWVkcyBhdHRlbnRpb25cIiB3aGVuIGEgcG9saWN5IG5hbWVzIG5vbmUuICovXG5jb25zdCBERUZBVUxUX0FDVElWRV9TVEFUVVNFUyA9IFsnb3BlbicsICdpbl9wcm9ncmVzcycsICd3YWl0aW5nJ107XG5cbmNvbnN0IEVNUFRZX1NUQVRFOiBDYXNlRXNjYWxhdGlvblN0YXRlID0ge1xuICBwb2xpY3lfaWQ6IG51bGwsXG4gIGxldmVsOiAwLFxuICBsYXN0X2VzY2FsYXRlZF9hdDogbnVsbCxcbiAgaGlzdG9yeTogW10sXG59O1xuXG5leHBvcnQgY2xhc3MgRXNjYWxhdGlvblNlcnZpY2Uge1xuICBwcml2YXRlIHN0YXRpYyBpbnRlcnZhbEhhbmRsZTogUmV0dXJuVHlwZTx0eXBlb2Ygc2V0SW50ZXJ2YWw+IHwgbnVsbCA9IG51bGw7XG4gIHByaXZhdGUgc3RhdGljIHJ1bm5pbmcgPSBmYWxzZTtcblxuICAvLyDilIDilIAgQmFja2dyb3VuZCBqb2Ig4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbiAgc3RhdGljIHN0YXJ0KGNsaWVudDogYW55LCBsb2dnZXI6IExvZ2dlcik6IHZvaWQge1xuICAgIGlmIChFc2NhbGF0aW9uU2VydmljZS5pbnRlcnZhbEhhbmRsZSkgcmV0dXJuO1xuICAgIEVzY2FsYXRpb25TZXJ2aWNlLmludGVydmFsSGFuZGxlID0gc2V0SW50ZXJ2YWwoYXN5bmMgKCkgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgYXdhaXQgRXNjYWxhdGlvblNlcnZpY2UucnVuKGNsaWVudCwgbG9nZ2VyKTtcbiAgICAgIH0gY2F0Y2ggKGU6IGFueSkge1xuICAgICAgICBsb2dnZXIud2FybihgRXNjYWxhdGlvbiB0aWNrIGVycm9yOiAke2UubWVzc2FnZX1gKTtcbiAgICAgIH1cbiAgICB9LCA2MF8wMDApO1xuICAgIGxvZ2dlci5pbmZvKCdFc2NhbGF0aW9uIGJhY2tncm91bmQgam9iIHN0YXJ0ZWQgKGNoZWNraW5nIGV2ZXJ5IDYwcyknKTtcbiAgfVxuXG4gIHN0YXRpYyBzdG9wKCk6IHZvaWQge1xuICAgIGlmIChFc2NhbGF0aW9uU2VydmljZS5pbnRlcnZhbEhhbmRsZSkge1xuICAgICAgY2xlYXJJbnRlcnZhbChFc2NhbGF0aW9uU2VydmljZS5pbnRlcnZhbEhhbmRsZSk7XG4gICAgICBFc2NhbGF0aW9uU2VydmljZS5pbnRlcnZhbEhhbmRsZSA9IG51bGw7XG4gICAgfVxuICB9XG5cbiAgLy8g4pSA4pSAIEV2YWx1YXRpb24g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbiAgLyoqXG4gICAqIEV2YWx1YXRlIGV2ZXJ5IGFjdGl2ZSBjYXNlIGFnYWluc3QgdGhlIGNvbmZpZ3VyZWQgcG9saWNpZXMgYW5kIGFwcGx5IGFueVxuICAgKiBzdGVwcyB0aGF0IGhhdmUgY29tZSBkdWUuIFJldHVybnMgdGhlIG51bWJlciBvZiBzdGVwcyBhcHBsaWVkLlxuICAgKi9cbiAgc3RhdGljIGFzeW5jIHJ1bihjbGllbnQ6IGFueSwgbG9nZ2VyOiBMb2dnZXIpOiBQcm9taXNlPHsgZXNjYWxhdGVkOiBudW1iZXI7IHN0ZXBzOiBudW1iZXIgfT4ge1xuICAgIGlmIChFc2NhbGF0aW9uU2VydmljZS5ydW5uaW5nKSByZXR1cm4geyBlc2NhbGF0ZWQ6IDAsIHN0ZXBzOiAwIH07XG4gICAgRXNjYWxhdGlvblNlcnZpY2UucnVubmluZyA9IHRydWU7XG5cbiAgICB0cnkge1xuICAgICAgY29uc3Qgc2V0dGluZ3MgPSBhd2FpdCBTZXR0aW5nc1NlcnZpY2UuZ2V0U2V0dGluZ3MoY2xpZW50KTtcbiAgICAgIGlmICghc2V0dGluZ3MuZXNjYWxhdGlvbi5lbmFibGVkKSByZXR1cm4geyBlc2NhbGF0ZWQ6IDAsIHN0ZXBzOiAwIH07XG5cbiAgICAgIGNvbnN0IHBvbGljaWVzID0gWy4uLnNldHRpbmdzLmVzY2FsYXRpb24ucG9saWNpZXNdXG4gICAgICAgIC5maWx0ZXIoKHApID0+IHAuZW5hYmxlZCAmJiBwLnN0ZXBzLmxlbmd0aCA+IDApXG4gICAgICAgIC5zb3J0KChhLCBiKSA9PiAoYS5vcmRlciA/PyAwKSAtIChiLm9yZGVyID8/IDApKTtcblxuICAgICAgaWYgKHBvbGljaWVzLmxlbmd0aCA9PT0gMCkgcmV0dXJuIHsgZXNjYWxhdGVkOiAwLCBzdGVwczogMCB9O1xuXG4gICAgICBjb25zdCBjYXNlcyA9IGF3YWl0IEVzY2FsYXRpb25TZXJ2aWNlLmZldGNoQWN0aXZlQ2FzZXMoY2xpZW50LCBsb2dnZXIpO1xuICAgICAgbGV0IGVzY2FsYXRlZCA9IDA7XG4gICAgICBsZXQgc3RlcHMgPSAwO1xuXG4gICAgICBmb3IgKGNvbnN0IGNhc2VJdGVtIG9mIGNhc2VzKSB7XG4gICAgICAgIGNvbnN0IHBvbGljeSA9IHBvbGljaWVzLmZpbmQoKHApID0+IEVzY2FsYXRpb25TZXJ2aWNlLnBvbGljeU1hdGNoZXMocCwgY2FzZUl0ZW0pKTtcbiAgICAgICAgaWYgKCFwb2xpY3kpIGNvbnRpbnVlO1xuXG4gICAgICAgIGNvbnN0IGFwcGxpZWQgPSBhd2FpdCBFc2NhbGF0aW9uU2VydmljZS5hcHBseUR1ZVBvbGljeVN0ZXBzKFxuICAgICAgICAgIGNsaWVudCxcbiAgICAgICAgICBjYXNlSXRlbSxcbiAgICAgICAgICBwb2xpY3ksXG4gICAgICAgICAgbG9nZ2VyLFxuICAgICAgICApO1xuICAgICAgICBpZiAoYXBwbGllZCA+IDApIHtcbiAgICAgICAgICBlc2NhbGF0ZWQrKztcbiAgICAgICAgICBzdGVwcyArPSBhcHBsaWVkO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIGlmIChzdGVwcyA+IDApIGxvZ2dlci5pbmZvKGBFc2NhbGF0aW9uOiBhcHBsaWVkICR7c3RlcHN9IHN0ZXAocykgYWNyb3NzICR7ZXNjYWxhdGVkfSBjYXNlKHMpYCk7XG4gICAgICByZXR1cm4geyBlc2NhbGF0ZWQsIHN0ZXBzIH07XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIEVzY2FsYXRpb25TZXJ2aWNlLnJ1bm5pbmcgPSBmYWxzZTtcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIHN0YXRpYyBhc3luYyBmZXRjaEFjdGl2ZUNhc2VzKGNsaWVudDogYW55LCBsb2dnZXI6IExvZ2dlcik6IFByb21pc2U8Q2FzZVtdPiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHsgYm9keSB9ID0gYXdhaXQgY2xpZW50LnNlYXJjaCh7XG4gICAgICAgIGluZGV4OiBDQVNFX0lOREVYLFxuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgcXVlcnk6IHsgYm9vbDogeyBtdXN0X25vdDogW3sgdGVybXM6IHsgc3RhdHVzOiBbJ2Nsb3NlZCcsICdyZXNvbHZlZCddIH0gfV0gfSB9LFxuICAgICAgICAgIHNvcnQ6IFt7IGNyZWF0ZWRfYXQ6IHsgb3JkZXI6ICdhc2MnIH0gfV0sXG4gICAgICAgICAgc2l6ZTogMTAwMCxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgICAgcmV0dXJuIChib2R5LmhpdHM/LmhpdHMgfHwgW10pLm1hcCgoaDogYW55KSA9PiAoeyBpZDogaC5faWQsIC4uLmguX3NvdXJjZSB9KSkgYXMgQ2FzZVtdO1xuICAgIH0gY2F0Y2ggKGU6IGFueSkge1xuICAgICAgbG9nZ2VyLndhcm4oYEVzY2FsYXRpb246IGNvdWxkIG5vdCBsaXN0IGFjdGl2ZSBjYXNlczogJHtlLm1lc3NhZ2V9YCk7XG4gICAgICByZXR1cm4gW107XG4gICAgfVxuICB9XG5cbiAgLyoqIERvZXMgdGhpcyBwb2xpY3kgYXBwbHkgdG8gdGhpcyBjYXNlPyBFbXB0eSBjcml0ZXJpYSBsaXN0cyBtZWFuIFwiYW55XCIuICovXG4gIHN0YXRpYyBwb2xpY3lNYXRjaGVzKHBvbGljeTogRXNjYWxhdGlvblBvbGljeSwgY2FzZUl0ZW06IENhc2UpOiBib29sZWFuIHtcbiAgICBjb25zdCBtID0gcG9saWN5Lm1hdGNoIHx8ICh7fSBhcyBhbnkpO1xuXG4gICAgY29uc3Qgc3RhdHVzZXMgPSBtLnN0YXR1c2VzPy5sZW5ndGggPyBtLnN0YXR1c2VzIDogREVGQVVMVF9BQ1RJVkVfU1RBVFVTRVM7XG4gICAgaWYgKCFzdGF0dXNlcy5pbmNsdWRlcyhjYXNlSXRlbS5zdGF0dXMpKSByZXR1cm4gZmFsc2U7XG5cbiAgICBpZiAobS5wcmlvcml0aWVzPy5sZW5ndGggJiYgIW0ucHJpb3JpdGllcy5pbmNsdWRlcyhjYXNlSXRlbS5wcmlvcml0eSkpIHJldHVybiBmYWxzZTtcbiAgICBpZiAobS5zZXZlcml0aWVzPy5sZW5ndGggJiYgIW0uc2V2ZXJpdGllcy5pbmNsdWRlcyhjYXNlSXRlbS5zZXZlcml0eSkpIHJldHVybiBmYWxzZTtcbiAgICBpZiAobS5jYXRlZ29yaWVzPy5sZW5ndGggJiYgIW0uY2F0ZWdvcmllcy5pbmNsdWRlcyhjYXNlSXRlbS5jYXRlZ29yeSkpIHJldHVybiBmYWxzZTtcbiAgICBpZiAobS50YWdzPy5sZW5ndGggJiYgIW0udGFncy5zb21lKCh0YWc6IHN0cmluZykgPT4gKGNhc2VJdGVtLnRhZ3MgfHwgW10pLmluY2x1ZGVzKHRhZykpKSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuXG4gICAgcmV0dXJuIHRydWU7XG4gIH1cblxuICAvKiogSG93IG1hbnkgc3RlcHMgb2YgdGhpcyBwb2xpY3kgYXJlIGR1ZSBmb3IgdGhpcyBjYXNlLCBnaXZlbiBpdHMgYWdlLiAqL1xuICBzdGF0aWMgZHVlU3RlcENvdW50KHBvbGljeTogRXNjYWxhdGlvblBvbGljeSwgY2FzZUl0ZW06IENhc2UsIG5vdyA9IERhdGUubm93KCkpOiBudW1iZXIge1xuICAgIGNvbnN0IGJhc2VGaWVsZCA9IHBvbGljeS5iYXNlID09PSAndXBkYXRlZF9hdCcgPyBjYXNlSXRlbS51cGRhdGVkX2F0IDogY2FzZUl0ZW0uY3JlYXRlZF9hdDtcbiAgICBjb25zdCBiYXNlVGltZSA9IG5ldyBEYXRlKGJhc2VGaWVsZCkuZ2V0VGltZSgpO1xuICAgIGlmIChOdW1iZXIuaXNOYU4oYmFzZVRpbWUpKSByZXR1cm4gMDtcblxuICAgIGNvbnN0IGVsYXBzZWRNaW51dGVzID0gKG5vdyAtIGJhc2VUaW1lKSAvIDYwXzAwMDtcbiAgICBjb25zdCBvcmRlcmVkID0gWy4uLnBvbGljeS5zdGVwc10uc29ydCgoYSwgYikgPT4gYS5hZnRlcl9taW51dGVzIC0gYi5hZnRlcl9taW51dGVzKTtcbiAgICByZXR1cm4gb3JkZXJlZC5maWx0ZXIoKHMpID0+IGVsYXBzZWRNaW51dGVzID49IHMuYWZ0ZXJfbWludXRlcykubGVuZ3RoO1xuICB9XG5cbiAgcHJpdmF0ZSBzdGF0aWMgYXN5bmMgYXBwbHlEdWVQb2xpY3lTdGVwcyhcbiAgICBjbGllbnQ6IGFueSxcbiAgICBjYXNlSXRlbTogQ2FzZSxcbiAgICBwb2xpY3k6IEVzY2FsYXRpb25Qb2xpY3ksXG4gICAgbG9nZ2VyOiBMb2dnZXIsXG4gICk6IFByb21pc2U8bnVtYmVyPiB7XG4gICAgY29uc3Qgc3RhdGU6IENhc2VFc2NhbGF0aW9uU3RhdGUgPSB7XG4gICAgICAuLi5FTVBUWV9TVEFURSxcbiAgICAgIC4uLigoY2FzZUl0ZW0gYXMgYW55KS5lc2NhbGF0aW9uX3N0YXRlIHx8IHt9KSxcbiAgICB9O1xuXG4gICAgLy8gU3dpdGNoaW5nIHBvbGljaWVzIHJlc3RhcnRzIHRoZSBsYWRkZXIgZm9yIHRoaXMgY2FzZS5cbiAgICBjb25zdCBjdXJyZW50TGV2ZWwgPSBzdGF0ZS5wb2xpY3lfaWQgPT09IHBvbGljeS5pZCA/IHN0YXRlLmxldmVsIHx8IDAgOiAwO1xuICAgIGNvbnN0IGR1ZSA9IEVzY2FsYXRpb25TZXJ2aWNlLmR1ZVN0ZXBDb3VudChwb2xpY3ksIGNhc2VJdGVtKTtcbiAgICBpZiAoZHVlIDw9IGN1cnJlbnRMZXZlbCkgcmV0dXJuIDA7XG5cbiAgICBjb25zdCBvcmRlcmVkID0gWy4uLnBvbGljeS5zdGVwc10uc29ydCgoYSwgYikgPT4gYS5hZnRlcl9taW51dGVzIC0gYi5hZnRlcl9taW51dGVzKTtcbiAgICBjb25zdCBub3cgPSBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCk7XG4gICAgY29uc3QgdXBkYXRlRG9jOiBhbnkgPSB7IHVwZGF0ZWRfYXQ6IG5vdyB9O1xuICAgIGNvbnN0IGhpc3RvcnkgPSBbLi4uKHN0YXRlLmhpc3RvcnkgfHwgW10pXTtcbiAgICBsZXQgd29ya2luZzogQ2FzZSA9IHsgLi4uY2FzZUl0ZW0gfTtcbiAgICBsZXQgYXBwbGllZCA9IDA7XG5cbiAgICBmb3IgKGxldCBpID0gY3VycmVudExldmVsOyBpIDwgZHVlICYmIGkgPCBvcmRlcmVkLmxlbmd0aDsgaSsrKSB7XG4gICAgICBjb25zdCBzdGVwID0gb3JkZXJlZFtpXTtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGRldGFpbCA9IGF3YWl0IEVzY2FsYXRpb25TZXJ2aWNlLmFwcGx5U3RlcChcbiAgICAgICAgICBjbGllbnQsXG4gICAgICAgICAgd29ya2luZyxcbiAgICAgICAgICBwb2xpY3ksXG4gICAgICAgICAgc3RlcCxcbiAgICAgICAgICBpLFxuICAgICAgICAgIHVwZGF0ZURvYyxcbiAgICAgICAgICBsb2dnZXIsXG4gICAgICAgICk7XG4gICAgICAgIC8vIEtlZXAgdGhlIHdvcmtpbmcgY29weSBpbiBzeW5jIHNvIGEgbGF0ZXIgc3RlcCBzZWVzIGVhcmxpZXIgY2hhbmdlcy5cbiAgICAgICAgd29ya2luZyA9IHsgLi4ud29ya2luZywgLi4udXBkYXRlRG9jIH07XG4gICAgICAgIGhpc3RvcnkucHVzaCh7XG4gICAgICAgICAgcG9saWN5X2lkOiBwb2xpY3kuaWQsXG4gICAgICAgICAgc3RlcF9pbmRleDogaSxcbiAgICAgICAgICBhY3Rpb246IHN0ZXAuYWN0aW9uLFxuICAgICAgICAgIGRldGFpbCxcbiAgICAgICAgICBhdDogbm93LFxuICAgICAgICB9KTtcbiAgICAgICAgYXBwbGllZCsrO1xuICAgICAgfSBjYXRjaCAoZTogYW55KSB7XG4gICAgICAgIGxvZ2dlci53YXJuKFxuICAgICAgICAgIGBFc2NhbGF0aW9uOiBzdGVwICR7aX0gb2YgXCIke3BvbGljeS5uYW1lfVwiIGZhaWxlZCBvbiAke2Nhc2VJdGVtLmNhc2VfaWR9OiAke2UubWVzc2FnZX1gLFxuICAgICAgICApO1xuICAgICAgfVxuICAgIH1cblxuICAgIGlmIChhcHBsaWVkID09PSAwKSByZXR1cm4gMDtcblxuICAgIHVwZGF0ZURvYy5lc2NhbGF0aW9uX3N0YXRlID0ge1xuICAgICAgcG9saWN5X2lkOiBwb2xpY3kuaWQsXG4gICAgICBsZXZlbDogY3VycmVudExldmVsICsgYXBwbGllZCxcbiAgICAgIGxhc3RfZXNjYWxhdGVkX2F0OiBub3csXG4gICAgICAvLyBDYXAgdGhlIHRyYWlsIHNvIGEgbG9uZy1saXZlZCBjYXNlIGNhbid0IGdyb3cgdGhlIGRvY3VtZW50IHdpdGhvdXQgYm91bmQuXG4gICAgICBoaXN0b3J5OiBoaXN0b3J5LnNsaWNlKC01MCksXG4gICAgfTtcblxuICAgIC8vIEVzY2FsYXRpb24gaXMgYSBzeXN0ZW0gYWN0aW9uLCByZWNvcmRlZCBpbiB0aGUgY2FzZSB0aW1lbGluZSBsaWtlIGFueSBvdGhlci5cbiAgICB1cGRhdGVEb2MuYWN0aXZpdHlfbG9nID0gW1xuICAgICAgLi4uKGNhc2VJdGVtLmFjdGl2aXR5X2xvZyB8fCBbXSksXG4gICAgICB7XG4gICAgICAgIGlkOiBgZXNjLSR7RGF0ZS5ub3coKS50b1N0cmluZygzNil9YCxcbiAgICAgICAgYWN0aW9uOiAncHJpb3JpdHlfY2hhbmdlZCcsXG4gICAgICAgIHVzZXI6ICdlc2NhbGF0aW9uJyxcbiAgICAgICAgdGltZXN0YW1wOiBub3csXG4gICAgICAgIGRldGFpbHM6IHtcbiAgICAgICAgICBwb2xpY3k6IHBvbGljeS5uYW1lLFxuICAgICAgICAgIHN0ZXBzX2FwcGxpZWQ6IGFwcGxpZWQsXG4gICAgICAgICAgbGV2ZWw6IGN1cnJlbnRMZXZlbCArIGFwcGxpZWQsXG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgIF07XG5cbiAgICBhd2FpdCBPcGVuU2VhcmNoU2VydmljZS51cGRhdGVEb2N1bWVudChjbGllbnQsIENBU0VfSU5ERVgsIGNhc2VJdGVtLmlkISwgdXBkYXRlRG9jKTtcblxuICAgIGF3YWl0IE5vdGlmaWNhdGlvblNlcnZpY2UuZGlzcGF0Y2goXG4gICAgICBjbGllbnQsXG4gICAgICB7XG4gICAgICAgIGV2ZW50OiAnY2FzZV9lc2NhbGF0ZWQnLFxuICAgICAgICByZWNpcGllbnRzOiBbd29ya2luZy5hc3NpZ25lZSwgY2FzZUl0ZW0uY3JlYXRlZF9ieV0sXG4gICAgICAgIHRpdGxlOiBgQ2FzZSAke2Nhc2VJdGVtLmNhc2VfaWR9IGVzY2FsYXRlZGAsXG4gICAgICAgIG1lc3NhZ2U6IGBQb2xpY3kgXCIke3BvbGljeS5uYW1lfVwiIGFwcGxpZWQgJHthcHBsaWVkfSBzdGVwKHMpLiBUaGUgY2FzZSBpcyBub3cgYXQgbGV2ZWwgJHtjdXJyZW50TGV2ZWwgKyBhcHBsaWVkfS5gLFxuICAgICAgICBjYXNlUmVmOiB7IC4uLmNhc2VJdGVtLCAuLi51cGRhdGVEb2MgfSxcbiAgICAgICAgYWN0b3I6ICdlc2NhbGF0aW9uJyxcbiAgICAgICAgY29udGV4dDogeyBwb2xpY3k6IHBvbGljeS5uYW1lLCBsZXZlbDogY3VycmVudExldmVsICsgYXBwbGllZCB9LFxuICAgICAgfSxcbiAgICAgIGxvZ2dlcixcbiAgICApO1xuXG4gICAgcmV0dXJuIGFwcGxpZWQ7XG4gIH1cblxuICAvKipcbiAgICogQXBwbHkgb25lIHN0ZXAsIGFjY3VtdWxhdGluZyBmaWVsZCBjaGFuZ2VzIGludG8gYHVwZGF0ZURvY2AuXG4gICAqIFJldHVybnMgYSBzaG9ydCBodW1hbi1yZWFkYWJsZSBkZXNjcmlwdGlvbiBvZiB3aGF0IGhhcHBlbmVkLlxuICAgKi9cbiAgcHJpdmF0ZSBzdGF0aWMgYXN5bmMgYXBwbHlTdGVwKFxuICAgIGNsaWVudDogYW55LFxuICAgIGNhc2VJdGVtOiBDYXNlLFxuICAgIHBvbGljeTogRXNjYWxhdGlvblBvbGljeSxcbiAgICBzdGVwOiBFc2NhbGF0aW9uU3RlcCxcbiAgICBpbmRleDogbnVtYmVyLFxuICAgIHVwZGF0ZURvYzogYW55LFxuICAgIGxvZ2dlcjogTG9nZ2VyLFxuICApOiBQcm9taXNlPHN0cmluZz4ge1xuICAgIHN3aXRjaCAoc3RlcC5hY3Rpb24pIHtcbiAgICAgIGNhc2UgJ3JhaXNlX3ByaW9yaXR5Jzoge1xuICAgICAgICBjb25zdCBjdXJyZW50ID0gdXBkYXRlRG9jLnByaW9yaXR5IHx8IGNhc2VJdGVtLnByaW9yaXR5O1xuICAgICAgICBjb25zdCBwb3MgPSBQUklPUklUWV9MQURERVIuaW5kZXhPZihjdXJyZW50IGFzIENhc2VQcmlvcml0eSk7XG4gICAgICAgIC8vIEluZGV4IDAgaXMgUDE6IGFscmVhZHkgdGhlIG1vc3QgdXJnZW50LlxuICAgICAgICBpZiAocG9zIDw9IDApIHJldHVybiBgcHJpb3JpdHkgYWxyZWFkeSBhdCAke2N1cnJlbnR9YDtcbiAgICAgICAgY29uc3QgbmV4dCA9IFBSSU9SSVRZX0xBRERFUltwb3MgLSAxXTtcbiAgICAgICAgdXBkYXRlRG9jLnByaW9yaXR5ID0gbmV4dDtcbiAgICAgICAgcmV0dXJuIGBwcmlvcml0eSByYWlzZWQgZnJvbSAke2N1cnJlbnR9IHRvICR7bmV4dH1gO1xuICAgICAgfVxuXG4gICAgICBjYXNlICdzZXRfcHJpb3JpdHknOiB7XG4gICAgICAgIGNvbnN0IHRhcmdldCA9IChzdGVwLnRhcmdldCB8fCAnJykudG9VcHBlckNhc2UoKTtcbiAgICAgICAgaWYgKCFQUklPUklUWV9MQURERVIuaW5jbHVkZXModGFyZ2V0IGFzIENhc2VQcmlvcml0eSkpIHtcbiAgICAgICAgICByZXR1cm4gYGludmFsaWQgdGFyZ2V0IHByaW9yaXR5IFwiJHtzdGVwLnRhcmdldH1cImA7XG4gICAgICAgIH1cbiAgICAgICAgdXBkYXRlRG9jLnByaW9yaXR5ID0gdGFyZ2V0O1xuICAgICAgICByZXR1cm4gYHByaW9yaXR5IHNldCB0byAke3RhcmdldH1gO1xuICAgICAgfVxuXG4gICAgICBjYXNlICdyZWFzc2lnbic6IHtcbiAgICAgICAgaWYgKCFzdGVwLnRhcmdldCkgcmV0dXJuICdubyByZWFzc2lnbiB0YXJnZXQgY29uZmlndXJlZCc7XG4gICAgICAgIHVwZGF0ZURvYy5hc3NpZ25lZSA9IHN0ZXAudGFyZ2V0O1xuICAgICAgICBhd2FpdCBOb3RpZmljYXRpb25TZXJ2aWNlLmRpc3BhdGNoKFxuICAgICAgICAgIGNsaWVudCxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBldmVudDogJ2Nhc2VfYXNzaWduZWQnLFxuICAgICAgICAgICAgcmVjaXBpZW50czogW3N0ZXAudGFyZ2V0XSxcbiAgICAgICAgICAgIHRpdGxlOiBgQ2FzZSAke2Nhc2VJdGVtLmNhc2VfaWR9IGVzY2FsYXRlZCB0byB5b3VgLFxuICAgICAgICAgICAgbWVzc2FnZTogYEVzY2FsYXRpb24gcG9saWN5IFwiJHtwb2xpY3kubmFtZX1cIiByZWFzc2lnbmVkIHRoaXMgY2FzZSB0byB5b3UuYCxcbiAgICAgICAgICAgIGNhc2VSZWY6IGNhc2VJdGVtLFxuICAgICAgICAgICAgYWN0b3I6ICdlc2NhbGF0aW9uJyxcbiAgICAgICAgICB9LFxuICAgICAgICAgIGxvZ2dlcixcbiAgICAgICAgKTtcbiAgICAgICAgcmV0dXJuIGByZWFzc2lnbmVkIHRvICR7c3RlcC50YXJnZXR9YDtcbiAgICAgIH1cblxuICAgICAgY2FzZSAnYWRkX3RhZyc6IHtcbiAgICAgICAgaWYgKCFzdGVwLnRhcmdldCkgcmV0dXJuICdubyB0YWcgY29uZmlndXJlZCc7XG4gICAgICAgIGNvbnN0IHRhZ3MgPSBuZXcgU2V0KFsuLi4odXBkYXRlRG9jLnRhZ3MgfHwgY2FzZUl0ZW0udGFncyB8fCBbXSksIHN0ZXAudGFyZ2V0XSk7XG4gICAgICAgIHVwZGF0ZURvYy50YWdzID0gQXJyYXkuZnJvbSh0YWdzKTtcbiAgICAgICAgcmV0dXJuIGB0YWdnZWQgXCIke3N0ZXAudGFyZ2V0fVwiYDtcbiAgICAgIH1cblxuICAgICAgY2FzZSAnbm90aWZ5JzpcbiAgICAgIGRlZmF1bHQ6IHtcbiAgICAgICAgY29uc3QgcmVjaXBpZW50cyA9IHN0ZXAudGFyZ2V0XG4gICAgICAgICAgPyBbc3RlcC50YXJnZXRdXG4gICAgICAgICAgOiBbdXBkYXRlRG9jLmFzc2lnbmVlIHx8IGNhc2VJdGVtLmFzc2lnbmVlLCBjYXNlSXRlbS5jcmVhdGVkX2J5XTtcbiAgICAgICAgYXdhaXQgTm90aWZpY2F0aW9uU2VydmljZS5kaXNwYXRjaChcbiAgICAgICAgICBjbGllbnQsXG4gICAgICAgICAge1xuICAgICAgICAgICAgZXZlbnQ6ICdjYXNlX2VzY2FsYXRlZCcsXG4gICAgICAgICAgICByZWNpcGllbnRzLFxuICAgICAgICAgICAgdGl0bGU6IGBFc2NhbGF0aW9uOiAke2Nhc2VJdGVtLmNhc2VfaWR9YCxcbiAgICAgICAgICAgIG1lc3NhZ2U6IGBTdGVwICR7aW5kZXggKyAxfSBvZiBcIiR7cG9saWN5Lm5hbWV9XCIuIFRoZSBjYXNlIGhhcyBiZWVuIG9wZW4gJHtzdGVwLmFmdGVyX21pbnV0ZXN9IG1pbnV0ZShzKSB3aXRob3V0IHJlc29sdXRpb24uYCxcbiAgICAgICAgICAgIGNhc2VSZWY6IGNhc2VJdGVtLFxuICAgICAgICAgICAgYWN0b3I6ICdlc2NhbGF0aW9uJyxcbiAgICAgICAgICAgIGNvbnRleHQ6IHsgcG9saWN5OiBwb2xpY3kubmFtZSwgc3RlcDogaW5kZXggKyAxIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgICBsb2dnZXIsXG4gICAgICAgICk7XG4gICAgICAgIHJldHVybiBgbm90aWZpZWQgJHtyZWNpcGllbnRzLmZpbHRlcihCb29sZWFuKS5qb2luKCcsICcpIHx8ICdub2JvZHknfWA7XG4gICAgICB9XG4gICAgfVxuICB9XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQXFCQSxJQUFBQSxVQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxtQkFBQSxHQUFBRCxPQUFBO0FBQ0EsSUFBQUUsaUJBQUEsR0FBQUYsT0FBQTtBQUNBLElBQUFHLHFCQUFBLEdBQUFILE9BQUE7QUFBNkQsU0FBQUksZ0JBQUFDLENBQUEsRUFBQUMsQ0FBQSxFQUFBQyxDQUFBLFlBQUFELENBQUEsR0FBQUUsY0FBQSxDQUFBRixDQUFBLE1BQUFELENBQUEsR0FBQUksTUFBQSxDQUFBQyxjQUFBLENBQUFMLENBQUEsRUFBQUMsQ0FBQSxJQUFBSyxLQUFBLEVBQUFKLENBQUEsRUFBQUssVUFBQSxNQUFBQyxZQUFBLE1BQUFDLFFBQUEsVUFBQVQsQ0FBQSxDQUFBQyxDQUFBLElBQUFDLENBQUEsRUFBQUYsQ0FBQTtBQUFBLFNBQUFHLGVBQUFELENBQUEsUUFBQVEsQ0FBQSxHQUFBQyxZQUFBLENBQUFULENBQUEsdUNBQUFRLENBQUEsR0FBQUEsQ0FBQSxHQUFBQSxDQUFBO0FBQUEsU0FBQUMsYUFBQVQsQ0FBQSxFQUFBRCxDQUFBLDJCQUFBQyxDQUFBLEtBQUFBLENBQUEsU0FBQUEsQ0FBQSxNQUFBRixDQUFBLEdBQUFFLENBQUEsQ0FBQVUsTUFBQSxDQUFBQyxXQUFBLGtCQUFBYixDQUFBLFFBQUFVLENBQUEsR0FBQVYsQ0FBQSxDQUFBYyxJQUFBLENBQUFaLENBQUEsRUFBQUQsQ0FBQSx1Q0FBQVMsQ0FBQSxTQUFBQSxDQUFBLFlBQUFLLFNBQUEseUVBQUFkLENBQUEsR0FBQWUsTUFBQSxHQUFBQyxNQUFBLEVBQUFmLENBQUEsS0F4QjdEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQWVBO0FBQ0EsTUFBTWdCLGVBQStCLEdBQUcsQ0FBQyxJQUFJLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxJQUFJLENBQUM7O0FBRWhFO0FBQ0EsTUFBTUMsdUJBQXVCLEdBQUcsQ0FBQyxNQUFNLEVBQUUsYUFBYSxFQUFFLFNBQVMsQ0FBQztBQUVsRSxNQUFNQyxXQUFnQyxHQUFHO0VBQ3ZDQyxTQUFTLEVBQUUsSUFBSTtFQUNmQyxLQUFLLEVBQUUsQ0FBQztFQUNSQyxpQkFBaUIsRUFBRSxJQUFJO0VBQ3ZCQyxPQUFPLEVBQUU7QUFDWCxDQUFDO0FBRU0sTUFBTUMsaUJBQWlCLENBQUM7RUFJN0I7O0VBRUEsT0FBT0MsS0FBS0EsQ0FBQ0MsTUFBVyxFQUFFQyxNQUFjLEVBQVE7SUFDOUMsSUFBSUgsaUJBQWlCLENBQUNJLGNBQWMsRUFBRTtJQUN0Q0osaUJBQWlCLENBQUNJLGNBQWMsR0FBR0MsV0FBVyxDQUFDLFlBQVk7TUFDekQsSUFBSTtRQUNGLE1BQU1MLGlCQUFpQixDQUFDTSxHQUFHLENBQUNKLE1BQU0sRUFBRUMsTUFBTSxDQUFDO01BQzdDLENBQUMsQ0FBQyxPQUFPNUIsQ0FBTSxFQUFFO1FBQ2Y0QixNQUFNLENBQUNJLElBQUksQ0FBRSwwQkFBeUJoQyxDQUFDLENBQUNpQyxPQUFRLEVBQUMsQ0FBQztNQUNwRDtJQUNGLENBQUMsRUFBRSxNQUFNLENBQUM7SUFDVkwsTUFBTSxDQUFDTSxJQUFJLENBQUMsd0RBQXdELENBQUM7RUFDdkU7RUFFQSxPQUFPQyxJQUFJQSxDQUFBLEVBQVM7SUFDbEIsSUFBSVYsaUJBQWlCLENBQUNJLGNBQWMsRUFBRTtNQUNwQ08sYUFBYSxDQUFDWCxpQkFBaUIsQ0FBQ0ksY0FBYyxDQUFDO01BQy9DSixpQkFBaUIsQ0FBQ0ksY0FBYyxHQUFHLElBQUk7SUFDekM7RUFDRjs7RUFFQTs7RUFFQTtBQUNGO0FBQ0E7QUFDQTtFQUNFLGFBQWFFLEdBQUdBLENBQUNKLE1BQVcsRUFBRUMsTUFBYyxFQUFpRDtJQUMzRixJQUFJSCxpQkFBaUIsQ0FBQ1ksT0FBTyxFQUFFLE9BQU87TUFBRUMsU0FBUyxFQUFFLENBQUM7TUFBRUMsS0FBSyxFQUFFO0lBQUUsQ0FBQztJQUNoRWQsaUJBQWlCLENBQUNZLE9BQU8sR0FBRyxJQUFJO0lBRWhDLElBQUk7TUFDRixNQUFNRyxRQUFRLEdBQUcsTUFBTUMsaUNBQWUsQ0FBQ0MsV0FBVyxDQUFDZixNQUFNLENBQUM7TUFDMUQsSUFBSSxDQUFDYSxRQUFRLENBQUNHLFVBQVUsQ0FBQ0MsT0FBTyxFQUFFLE9BQU87UUFBRU4sU0FBUyxFQUFFLENBQUM7UUFBRUMsS0FBSyxFQUFFO01BQUUsQ0FBQztNQUVuRSxNQUFNTSxRQUFRLEdBQUcsQ0FBQyxHQUFHTCxRQUFRLENBQUNHLFVBQVUsQ0FBQ0UsUUFBUSxDQUFDLENBQy9DQyxNQUFNLENBQUVDLENBQUMsSUFBS0EsQ0FBQyxDQUFDSCxPQUFPLElBQUlHLENBQUMsQ0FBQ1IsS0FBSyxDQUFDUyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQzlDQyxJQUFJLENBQUMsQ0FBQ0MsQ0FBQyxFQUFFQyxDQUFDO1FBQUEsSUFBQUMsUUFBQSxFQUFBQyxRQUFBO1FBQUEsT0FBSyxFQUFBRCxRQUFBLEdBQUNGLENBQUMsQ0FBQ0ksS0FBSyxjQUFBRixRQUFBLGNBQUFBLFFBQUEsR0FBSSxDQUFDLE1BQUFDLFFBQUEsR0FBS0YsQ0FBQyxDQUFDRyxLQUFLLGNBQUFELFFBQUEsY0FBQUEsUUFBQSxHQUFJLENBQUMsQ0FBQztNQUFBLEVBQUM7TUFFbEQsSUFBSVIsUUFBUSxDQUFDRyxNQUFNLEtBQUssQ0FBQyxFQUFFLE9BQU87UUFBRVYsU0FBUyxFQUFFLENBQUM7UUFBRUMsS0FBSyxFQUFFO01BQUUsQ0FBQztNQUU1RCxNQUFNZ0IsS0FBSyxHQUFHLE1BQU05QixpQkFBaUIsQ0FBQytCLGdCQUFnQixDQUFDN0IsTUFBTSxFQUFFQyxNQUFNLENBQUM7TUFDdEUsSUFBSVUsU0FBUyxHQUFHLENBQUM7TUFDakIsSUFBSUMsS0FBSyxHQUFHLENBQUM7TUFFYixLQUFLLE1BQU1rQixRQUFRLElBQUlGLEtBQUssRUFBRTtRQUM1QixNQUFNRyxNQUFNLEdBQUdiLFFBQVEsQ0FBQ2MsSUFBSSxDQUFFWixDQUFDLElBQUt0QixpQkFBaUIsQ0FBQ21DLGFBQWEsQ0FBQ2IsQ0FBQyxFQUFFVSxRQUFRLENBQUMsQ0FBQztRQUNqRixJQUFJLENBQUNDLE1BQU0sRUFBRTtRQUViLE1BQU1HLE9BQU8sR0FBRyxNQUFNcEMsaUJBQWlCLENBQUNxQyxtQkFBbUIsQ0FDekRuQyxNQUFNLEVBQ044QixRQUFRLEVBQ1JDLE1BQU0sRUFDTjlCLE1BQ0YsQ0FBQztRQUNELElBQUlpQyxPQUFPLEdBQUcsQ0FBQyxFQUFFO1VBQ2Z2QixTQUFTLEVBQUU7VUFDWEMsS0FBSyxJQUFJc0IsT0FBTztRQUNsQjtNQUNGO01BRUEsSUFBSXRCLEtBQUssR0FBRyxDQUFDLEVBQUVYLE1BQU0sQ0FBQ00sSUFBSSxDQUFFLHVCQUFzQkssS0FBTSxtQkFBa0JELFNBQVUsVUFBUyxDQUFDO01BQzlGLE9BQU87UUFBRUEsU0FBUztRQUFFQztNQUFNLENBQUM7SUFDN0IsQ0FBQyxTQUFTO01BQ1JkLGlCQUFpQixDQUFDWSxPQUFPLEdBQUcsS0FBSztJQUNuQztFQUNGO0VBRUEsYUFBcUJtQixnQkFBZ0JBLENBQUM3QixNQUFXLEVBQUVDLE1BQWMsRUFBbUI7SUFDbEYsSUFBSTtNQUFBLElBQUFtQyxVQUFBO01BQ0YsTUFBTTtRQUFFQztNQUFLLENBQUMsR0FBRyxNQUFNckMsTUFBTSxDQUFDc0MsTUFBTSxDQUFDO1FBQ25DQyxLQUFLLEVBQUVDLHFCQUFVO1FBQ2pCSCxJQUFJLEVBQUU7VUFDSkksS0FBSyxFQUFFO1lBQUVDLElBQUksRUFBRTtjQUFFQyxRQUFRLEVBQUUsQ0FBQztnQkFBRUMsS0FBSyxFQUFFO2tCQUFFQyxNQUFNLEVBQUUsQ0FBQyxRQUFRLEVBQUUsVUFBVTtnQkFBRTtjQUFFLENBQUM7WUFBRTtVQUFFLENBQUM7VUFDOUV2QixJQUFJLEVBQUUsQ0FBQztZQUFFd0IsVUFBVSxFQUFFO2NBQUVuQixLQUFLLEVBQUU7WUFBTTtVQUFFLENBQUMsQ0FBQztVQUN4Q29CLElBQUksRUFBRTtRQUNSO01BQ0YsQ0FBQyxDQUFDO01BQ0YsT0FBTyxDQUFDLEVBQUFYLFVBQUEsR0FBQUMsSUFBSSxDQUFDVyxJQUFJLGNBQUFaLFVBQUEsdUJBQVRBLFVBQUEsQ0FBV1ksSUFBSSxLQUFJLEVBQUUsRUFBRUMsR0FBRyxDQUFFQyxDQUFNLEtBQU07UUFBRUMsRUFBRSxFQUFFRCxDQUFDLENBQUNFLEdBQUc7UUFBRSxHQUFHRixDQUFDLENBQUNHO01BQVEsQ0FBQyxDQUFDLENBQUM7SUFDL0UsQ0FBQyxDQUFDLE9BQU9oRixDQUFNLEVBQUU7TUFDZjRCLE1BQU0sQ0FBQ0ksSUFBSSxDQUFFLDRDQUEyQ2hDLENBQUMsQ0FBQ2lDLE9BQVEsRUFBQyxDQUFDO01BQ3BFLE9BQU8sRUFBRTtJQUNYO0VBQ0Y7O0VBRUE7RUFDQSxPQUFPMkIsYUFBYUEsQ0FBQ0YsTUFBd0IsRUFBRUQsUUFBYyxFQUFXO0lBQUEsSUFBQXdCLFdBQUEsRUFBQUMsYUFBQSxFQUFBQyxhQUFBLEVBQUFDLGFBQUEsRUFBQUMsT0FBQTtJQUN0RSxNQUFNQyxDQUFDLEdBQUc1QixNQUFNLENBQUM2QixLQUFLLElBQUssQ0FBQyxDQUFTO0lBRXJDLE1BQU1DLFFBQVEsR0FBRyxDQUFBUCxXQUFBLEdBQUFLLENBQUMsQ0FBQ0UsUUFBUSxjQUFBUCxXQUFBLGVBQVZBLFdBQUEsQ0FBWWpDLE1BQU0sR0FBR3NDLENBQUMsQ0FBQ0UsUUFBUSxHQUFHckUsdUJBQXVCO0lBQzFFLElBQUksQ0FBQ3FFLFFBQVEsQ0FBQ0MsUUFBUSxDQUFDaEMsUUFBUSxDQUFDZSxNQUFNLENBQUMsRUFBRSxPQUFPLEtBQUs7SUFFckQsSUFBSSxDQUFBVSxhQUFBLEdBQUFJLENBQUMsQ0FBQ0ksVUFBVSxjQUFBUixhQUFBLGVBQVpBLGFBQUEsQ0FBY2xDLE1BQU0sSUFBSSxDQUFDc0MsQ0FBQyxDQUFDSSxVQUFVLENBQUNELFFBQVEsQ0FBQ2hDLFFBQVEsQ0FBQ2tDLFFBQVEsQ0FBQyxFQUFFLE9BQU8sS0FBSztJQUNuRixJQUFJLENBQUFSLGFBQUEsR0FBQUcsQ0FBQyxDQUFDTSxVQUFVLGNBQUFULGFBQUEsZUFBWkEsYUFBQSxDQUFjbkMsTUFBTSxJQUFJLENBQUNzQyxDQUFDLENBQUNNLFVBQVUsQ0FBQ0gsUUFBUSxDQUFDaEMsUUFBUSxDQUFDb0MsUUFBUSxDQUFDLEVBQUUsT0FBTyxLQUFLO0lBQ25GLElBQUksQ0FBQVQsYUFBQSxHQUFBRSxDQUFDLENBQUNRLFVBQVUsY0FBQVYsYUFBQSxlQUFaQSxhQUFBLENBQWNwQyxNQUFNLElBQUksQ0FBQ3NDLENBQUMsQ0FBQ1EsVUFBVSxDQUFDTCxRQUFRLENBQUNoQyxRQUFRLENBQUNzQyxRQUFRLENBQUMsRUFBRSxPQUFPLEtBQUs7SUFDbkYsSUFBSSxDQUFBVixPQUFBLEdBQUFDLENBQUMsQ0FBQ1UsSUFBSSxjQUFBWCxPQUFBLGVBQU5BLE9BQUEsQ0FBUXJDLE1BQU0sSUFBSSxDQUFDc0MsQ0FBQyxDQUFDVSxJQUFJLENBQUNDLElBQUksQ0FBRUMsR0FBVyxJQUFLLENBQUN6QyxRQUFRLENBQUN1QyxJQUFJLElBQUksRUFBRSxFQUFFUCxRQUFRLENBQUNTLEdBQUcsQ0FBQyxDQUFDLEVBQUU7TUFDeEYsT0FBTyxLQUFLO0lBQ2Q7SUFFQSxPQUFPLElBQUk7RUFDYjs7RUFFQTtFQUNBLE9BQU9DLFlBQVlBLENBQUN6QyxNQUF3QixFQUFFRCxRQUFjLEVBQUUyQyxHQUFHLEdBQUdDLElBQUksQ0FBQ0QsR0FBRyxDQUFDLENBQUMsRUFBVTtJQUN0RixNQUFNRSxTQUFTLEdBQUc1QyxNQUFNLENBQUM2QyxJQUFJLEtBQUssWUFBWSxHQUFHOUMsUUFBUSxDQUFDK0MsVUFBVSxHQUFHL0MsUUFBUSxDQUFDZ0IsVUFBVTtJQUMxRixNQUFNZ0MsUUFBUSxHQUFHLElBQUlKLElBQUksQ0FBQ0MsU0FBUyxDQUFDLENBQUNJLE9BQU8sQ0FBQyxDQUFDO0lBQzlDLElBQUl6RixNQUFNLENBQUMwRixLQUFLLENBQUNGLFFBQVEsQ0FBQyxFQUFFLE9BQU8sQ0FBQztJQUVwQyxNQUFNRyxjQUFjLEdBQUcsQ0FBQ1IsR0FBRyxHQUFHSyxRQUFRLElBQUksTUFBTTtJQUNoRCxNQUFNSSxPQUFPLEdBQUcsQ0FBQyxHQUFHbkQsTUFBTSxDQUFDbkIsS0FBSyxDQUFDLENBQUNVLElBQUksQ0FBQyxDQUFDQyxDQUFDLEVBQUVDLENBQUMsS0FBS0QsQ0FBQyxDQUFDNEQsYUFBYSxHQUFHM0QsQ0FBQyxDQUFDMkQsYUFBYSxDQUFDO0lBQ25GLE9BQU9ELE9BQU8sQ0FBQy9ELE1BQU0sQ0FBRWlFLENBQUMsSUFBS0gsY0FBYyxJQUFJRyxDQUFDLENBQUNELGFBQWEsQ0FBQyxDQUFDOUQsTUFBTTtFQUN4RTtFQUVBLGFBQXFCYyxtQkFBbUJBLENBQ3RDbkMsTUFBVyxFQUNYOEIsUUFBYyxFQUNkQyxNQUF3QixFQUN4QjlCLE1BQWMsRUFDRztJQUNqQixNQUFNb0YsS0FBMEIsR0FBRztNQUNqQyxHQUFHNUYsV0FBVztNQUNkLElBQUtxQyxRQUFRLENBQVN3RCxnQkFBZ0IsSUFBSSxDQUFDLENBQUM7SUFDOUMsQ0FBQzs7SUFFRDtJQUNBLE1BQU1DLFlBQVksR0FBR0YsS0FBSyxDQUFDM0YsU0FBUyxLQUFLcUMsTUFBTSxDQUFDb0IsRUFBRSxHQUFHa0MsS0FBSyxDQUFDMUYsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDO0lBQ3pFLE1BQU02RixHQUFHLEdBQUcxRixpQkFBaUIsQ0FBQzBFLFlBQVksQ0FBQ3pDLE1BQU0sRUFBRUQsUUFBUSxDQUFDO0lBQzVELElBQUkwRCxHQUFHLElBQUlELFlBQVksRUFBRSxPQUFPLENBQUM7SUFFakMsTUFBTUwsT0FBTyxHQUFHLENBQUMsR0FBR25ELE1BQU0sQ0FBQ25CLEtBQUssQ0FBQyxDQUFDVSxJQUFJLENBQUMsQ0FBQ0MsQ0FBQyxFQUFFQyxDQUFDLEtBQUtELENBQUMsQ0FBQzRELGFBQWEsR0FBRzNELENBQUMsQ0FBQzJELGFBQWEsQ0FBQztJQUNuRixNQUFNVixHQUFHLEdBQUcsSUFBSUMsSUFBSSxDQUFDLENBQUMsQ0FBQ2UsV0FBVyxDQUFDLENBQUM7SUFDcEMsTUFBTUMsU0FBYyxHQUFHO01BQUViLFVBQVUsRUFBRUo7SUFBSSxDQUFDO0lBQzFDLE1BQU01RSxPQUFPLEdBQUcsQ0FBQyxJQUFJd0YsS0FBSyxDQUFDeEYsT0FBTyxJQUFJLEVBQUUsQ0FBQyxDQUFDO0lBQzFDLElBQUk4RixPQUFhLEdBQUc7TUFBRSxHQUFHN0Q7SUFBUyxDQUFDO0lBQ25DLElBQUlJLE9BQU8sR0FBRyxDQUFDO0lBRWYsS0FBSyxJQUFJbkQsQ0FBQyxHQUFHd0csWUFBWSxFQUFFeEcsQ0FBQyxHQUFHeUcsR0FBRyxJQUFJekcsQ0FBQyxHQUFHbUcsT0FBTyxDQUFDN0QsTUFBTSxFQUFFdEMsQ0FBQyxFQUFFLEVBQUU7TUFDN0QsTUFBTTZHLElBQUksR0FBR1YsT0FBTyxDQUFDbkcsQ0FBQyxDQUFDO01BQ3ZCLElBQUk7UUFDRixNQUFNOEcsTUFBTSxHQUFHLE1BQU0vRixpQkFBaUIsQ0FBQ2dHLFNBQVMsQ0FDOUM5RixNQUFNLEVBQ04yRixPQUFPLEVBQ1A1RCxNQUFNLEVBQ042RCxJQUFJLEVBQ0o3RyxDQUFDLEVBQ0QyRyxTQUFTLEVBQ1R6RixNQUNGLENBQUM7UUFDRDtRQUNBMEYsT0FBTyxHQUFHO1VBQUUsR0FBR0EsT0FBTztVQUFFLEdBQUdEO1FBQVUsQ0FBQztRQUN0QzdGLE9BQU8sQ0FBQ2tHLElBQUksQ0FBQztVQUNYckcsU0FBUyxFQUFFcUMsTUFBTSxDQUFDb0IsRUFBRTtVQUNwQjZDLFVBQVUsRUFBRWpILENBQUM7VUFDYmtILE1BQU0sRUFBRUwsSUFBSSxDQUFDSyxNQUFNO1VBQ25CSixNQUFNO1VBQ05LLEVBQUUsRUFBRXpCO1FBQ04sQ0FBQyxDQUFDO1FBQ0Z2QyxPQUFPLEVBQUU7TUFDWCxDQUFDLENBQUMsT0FBTzdELENBQU0sRUFBRTtRQUNmNEIsTUFBTSxDQUFDSSxJQUFJLENBQ1Isb0JBQW1CdEIsQ0FBRSxRQUFPZ0QsTUFBTSxDQUFDb0UsSUFBSyxlQUFjckUsUUFBUSxDQUFDc0UsT0FBUSxLQUFJL0gsQ0FBQyxDQUFDaUMsT0FBUSxFQUN4RixDQUFDO01BQ0g7SUFDRjtJQUVBLElBQUk0QixPQUFPLEtBQUssQ0FBQyxFQUFFLE9BQU8sQ0FBQztJQUUzQndELFNBQVMsQ0FBQ0osZ0JBQWdCLEdBQUc7TUFDM0I1RixTQUFTLEVBQUVxQyxNQUFNLENBQUNvQixFQUFFO01BQ3BCeEQsS0FBSyxFQUFFNEYsWUFBWSxHQUFHckQsT0FBTztNQUM3QnRDLGlCQUFpQixFQUFFNkUsR0FBRztNQUN0QjtNQUNBNUUsT0FBTyxFQUFFQSxPQUFPLENBQUN3RyxLQUFLLENBQUMsQ0FBQyxFQUFFO0lBQzVCLENBQUM7O0lBRUQ7SUFDQVgsU0FBUyxDQUFDWSxZQUFZLEdBQUcsQ0FDdkIsSUFBSXhFLFFBQVEsQ0FBQ3dFLFlBQVksSUFBSSxFQUFFLENBQUMsRUFDaEM7TUFDRW5ELEVBQUUsRUFBRyxPQUFNdUIsSUFBSSxDQUFDRCxHQUFHLENBQUMsQ0FBQyxDQUFDOEIsUUFBUSxDQUFDLEVBQUUsQ0FBRSxFQUFDO01BQ3BDTixNQUFNLEVBQUUsa0JBQWtCO01BQzFCTyxJQUFJLEVBQUUsWUFBWTtNQUNsQkMsU0FBUyxFQUFFaEMsR0FBRztNQUNkaUMsT0FBTyxFQUFFO1FBQ1AzRSxNQUFNLEVBQUVBLE1BQU0sQ0FBQ29FLElBQUk7UUFDbkJRLGFBQWEsRUFBRXpFLE9BQU87UUFDdEJ2QyxLQUFLLEVBQUU0RixZQUFZLEdBQUdyRDtNQUN4QjtJQUNGLENBQUMsQ0FDRjtJQUVELE1BQU0wRSxxQ0FBaUIsQ0FBQ0MsY0FBYyxDQUFDN0csTUFBTSxFQUFFd0MscUJBQVUsRUFBRVYsUUFBUSxDQUFDcUIsRUFBRSxFQUFHdUMsU0FBUyxDQUFDO0lBRW5GLE1BQU1vQix5Q0FBbUIsQ0FBQ0MsUUFBUSxDQUNoQy9HLE1BQU0sRUFDTjtNQUNFZ0gsS0FBSyxFQUFFLGdCQUFnQjtNQUN2QkMsVUFBVSxFQUFFLENBQUN0QixPQUFPLENBQUN1QixRQUFRLEVBQUVwRixRQUFRLENBQUNxRixVQUFVLENBQUM7TUFDbkRDLEtBQUssRUFBRyxRQUFPdEYsUUFBUSxDQUFDc0UsT0FBUSxZQUFXO01BQzNDOUYsT0FBTyxFQUFHLFdBQVV5QixNQUFNLENBQUNvRSxJQUFLLGFBQVlqRSxPQUFRLHNDQUFxQ3FELFlBQVksR0FBR3JELE9BQVEsR0FBRTtNQUNsSG1GLE9BQU8sRUFBRTtRQUFFLEdBQUd2RixRQUFRO1FBQUUsR0FBRzREO01BQVUsQ0FBQztNQUN0QzRCLEtBQUssRUFBRSxZQUFZO01BQ25CQyxPQUFPLEVBQUU7UUFBRXhGLE1BQU0sRUFBRUEsTUFBTSxDQUFDb0UsSUFBSTtRQUFFeEcsS0FBSyxFQUFFNEYsWUFBWSxHQUFHckQ7TUFBUTtJQUNoRSxDQUFDLEVBQ0RqQyxNQUNGLENBQUM7SUFFRCxPQUFPaUMsT0FBTztFQUNoQjs7RUFFQTtBQUNGO0FBQ0E7QUFDQTtFQUNFLGFBQXFCNEQsU0FBU0EsQ0FDNUI5RixNQUFXLEVBQ1g4QixRQUFjLEVBQ2RDLE1BQXdCLEVBQ3hCNkQsSUFBb0IsRUFDcEJyRCxLQUFhLEVBQ2JtRCxTQUFjLEVBQ2R6RixNQUFjLEVBQ0c7SUFDakIsUUFBUTJGLElBQUksQ0FBQ0ssTUFBTTtNQUNqQixLQUFLLGdCQUFnQjtRQUFFO1VBQ3JCLE1BQU11QixPQUFPLEdBQUc5QixTQUFTLENBQUMxQixRQUFRLElBQUlsQyxRQUFRLENBQUNrQyxRQUFRO1VBQ3ZELE1BQU15RCxHQUFHLEdBQUdsSSxlQUFlLENBQUNtSSxPQUFPLENBQUNGLE9BQXVCLENBQUM7VUFDNUQ7VUFDQSxJQUFJQyxHQUFHLElBQUksQ0FBQyxFQUFFLE9BQVEsdUJBQXNCRCxPQUFRLEVBQUM7VUFDckQsTUFBTUcsSUFBSSxHQUFHcEksZUFBZSxDQUFDa0ksR0FBRyxHQUFHLENBQUMsQ0FBQztVQUNyQy9CLFNBQVMsQ0FBQzFCLFFBQVEsR0FBRzJELElBQUk7VUFDekIsT0FBUSx3QkFBdUJILE9BQVEsT0FBTUcsSUFBSyxFQUFDO1FBQ3JEO01BRUEsS0FBSyxjQUFjO1FBQUU7VUFDbkIsTUFBTUMsTUFBTSxHQUFHLENBQUNoQyxJQUFJLENBQUNnQyxNQUFNLElBQUksRUFBRSxFQUFFQyxXQUFXLENBQUMsQ0FBQztVQUNoRCxJQUFJLENBQUN0SSxlQUFlLENBQUN1RSxRQUFRLENBQUM4RCxNQUFzQixDQUFDLEVBQUU7WUFDckQsT0FBUSw0QkFBMkJoQyxJQUFJLENBQUNnQyxNQUFPLEdBQUU7VUFDbkQ7VUFDQWxDLFNBQVMsQ0FBQzFCLFFBQVEsR0FBRzRELE1BQU07VUFDM0IsT0FBUSxtQkFBa0JBLE1BQU8sRUFBQztRQUNwQztNQUVBLEtBQUssVUFBVTtRQUFFO1VBQ2YsSUFBSSxDQUFDaEMsSUFBSSxDQUFDZ0MsTUFBTSxFQUFFLE9BQU8sK0JBQStCO1VBQ3hEbEMsU0FBUyxDQUFDd0IsUUFBUSxHQUFHdEIsSUFBSSxDQUFDZ0MsTUFBTTtVQUNoQyxNQUFNZCx5Q0FBbUIsQ0FBQ0MsUUFBUSxDQUNoQy9HLE1BQU0sRUFDTjtZQUNFZ0gsS0FBSyxFQUFFLGVBQWU7WUFDdEJDLFVBQVUsRUFBRSxDQUFDckIsSUFBSSxDQUFDZ0MsTUFBTSxDQUFDO1lBQ3pCUixLQUFLLEVBQUcsUUFBT3RGLFFBQVEsQ0FBQ3NFLE9BQVEsbUJBQWtCO1lBQ2xEOUYsT0FBTyxFQUFHLHNCQUFxQnlCLE1BQU0sQ0FBQ29FLElBQUssZ0NBQStCO1lBQzFFa0IsT0FBTyxFQUFFdkYsUUFBUTtZQUNqQndGLEtBQUssRUFBRTtVQUNULENBQUMsRUFDRHJILE1BQ0YsQ0FBQztVQUNELE9BQVEsaUJBQWdCMkYsSUFBSSxDQUFDZ0MsTUFBTyxFQUFDO1FBQ3ZDO01BRUEsS0FBSyxTQUFTO1FBQUU7VUFDZCxJQUFJLENBQUNoQyxJQUFJLENBQUNnQyxNQUFNLEVBQUUsT0FBTyxtQkFBbUI7VUFDNUMsTUFBTXZELElBQUksR0FBRyxJQUFJeUQsR0FBRyxDQUFDLENBQUMsSUFBSXBDLFNBQVMsQ0FBQ3JCLElBQUksSUFBSXZDLFFBQVEsQ0FBQ3VDLElBQUksSUFBSSxFQUFFLENBQUMsRUFBRXVCLElBQUksQ0FBQ2dDLE1BQU0sQ0FBQyxDQUFDO1VBQy9FbEMsU0FBUyxDQUFDckIsSUFBSSxHQUFHMEQsS0FBSyxDQUFDQyxJQUFJLENBQUMzRCxJQUFJLENBQUM7VUFDakMsT0FBUSxXQUFVdUIsSUFBSSxDQUFDZ0MsTUFBTyxHQUFFO1FBQ2xDO01BRUEsS0FBSyxRQUFRO01BQ2I7UUFBUztVQUNQLE1BQU1YLFVBQVUsR0FBR3JCLElBQUksQ0FBQ2dDLE1BQU0sR0FDMUIsQ0FBQ2hDLElBQUksQ0FBQ2dDLE1BQU0sQ0FBQyxHQUNiLENBQUNsQyxTQUFTLENBQUN3QixRQUFRLElBQUlwRixRQUFRLENBQUNvRixRQUFRLEVBQUVwRixRQUFRLENBQUNxRixVQUFVLENBQUM7VUFDbEUsTUFBTUwseUNBQW1CLENBQUNDLFFBQVEsQ0FDaEMvRyxNQUFNLEVBQ047WUFDRWdILEtBQUssRUFBRSxnQkFBZ0I7WUFDdkJDLFVBQVU7WUFDVkcsS0FBSyxFQUFHLGVBQWN0RixRQUFRLENBQUNzRSxPQUFRLEVBQUM7WUFDeEM5RixPQUFPLEVBQUcsUUFBT2lDLEtBQUssR0FBRyxDQUFFLFFBQU9SLE1BQU0sQ0FBQ29FLElBQUssNkJBQTRCUCxJQUFJLENBQUNULGFBQWMsZ0NBQStCO1lBQzVIa0MsT0FBTyxFQUFFdkYsUUFBUTtZQUNqQndGLEtBQUssRUFBRSxZQUFZO1lBQ25CQyxPQUFPLEVBQUU7Y0FBRXhGLE1BQU0sRUFBRUEsTUFBTSxDQUFDb0UsSUFBSTtjQUFFUCxJQUFJLEVBQUVyRCxLQUFLLEdBQUc7WUFBRTtVQUNsRCxDQUFDLEVBQ0R0QyxNQUNGLENBQUM7VUFDRCxPQUFRLFlBQVdnSCxVQUFVLENBQUM5RixNQUFNLENBQUM4RyxPQUFPLENBQUMsQ0FBQ0MsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLFFBQVMsRUFBQztRQUN4RTtJQUNGO0VBQ0Y7QUFDRjtBQUFDQyxPQUFBLENBQUFySSxpQkFBQSxHQUFBQSxpQkFBQTtBQUFBMUIsZUFBQSxDQXRTWTBCLGlCQUFpQixvQkFDMkMsSUFBSTtBQUFBMUIsZUFBQSxDQURoRTBCLGlCQUFpQixhQUVILEtBQUsifQ==