"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.SmtpService = void 0;
exports.buildMimeMessage = buildMimeMessage;
var _net = require("net");
var _tls = require("tls");
var _crypto = require("crypto");
var _constants = require("../../common/constants");
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); } /*
 * Wazuh Case Management Plugin
 * SMTP Service: a minimal, dependency-free SMTP client
 *
 * Implemented directly on Node's built-in `net` and `tls` so the plugin can
 * send mail without pulling in a third-party library. It covers what a Wazuh
 * deployment realistically needs:
 *
 *   Transport   plain, STARTTLS upgrade, or implicit TLS
 *   Auth        PLAIN, LOGIN, CRAM-MD5, or none, negotiated from EHLO
 *   Body        multipart/alternative with a plain-text and an HTML part
 *
 * Every send returns a redacted transcript of the dialogue, which is what makes
 * a misconfigured relay diagnosable from the Settings page.
 */
/** Thrown for a protocol-level failure so the caller can report the stage. */
class SmtpError extends Error {
  constructor(message, code) {
    super(message);
    this.code = code;
    this.name = 'SmtpError';
  }
}

/**
 * A single SMTP conversation. One instance handles one connection, then the
 * socket is closed; SMTP connection pooling is not worth the complexity for the
 * volume of mail a case-management plugin sends.
 */
class SmtpSession {
  constructor(settings) {
    this.settings = settings;
    _defineProperty(this, "socket", null);
    _defineProperty(this, "buffer", '');
    _defineProperty(this, "pending", null);
    _defineProperty(this, "pendingError", null);
    _defineProperty(this, "closed", false);
    _defineProperty(this, "transcript", []);
  }
  get timeout() {
    return this.settings.timeout_ms || _constants.SMTP_DEFAULT_TIMEOUT_MS;
  }
  log(direction, text, redact = false) {
    // Cap the transcript so a chatty server cannot balloon the response.
    if (this.transcript.length > 80) return;
    this.transcript.push(`${direction}: ${redact ? '********' : text}`);
  }

  // ── Connection ─────────────────────────────────────────────

  async connect() {
    const {
      host,
      port,
      security,
      reject_unauthorized
    } = this.settings;
    await new Promise((resolve, reject) => {
      const onError = err => reject(new SmtpError(`Connection failed: ${err.message}`));
      if (security === 'tls') {
        const socket = (0, _tls.connect)({
          host,
          port,
          rejectUnauthorized: reject_unauthorized !== false,
          servername: host
        }, () => {
          socket.removeListener('error', onError);
          this.attach(socket);
          resolve();
        });
        socket.once('error', onError);
        socket.setTimeout(this.timeout);
      } else {
        const socket = (0, _net.connect)({
          host,
          port
        }, () => {
          socket.removeListener('error', onError);
          this.attach(socket);
          resolve();
        });
        socket.once('error', onError);
        socket.setTimeout(this.timeout);
      }
    });
    const greeting = await this.readResponse();
    if (greeting.code !== 220) {
      throw new SmtpError(`Unexpected greeting: ${greeting.raw}`, greeting.code);
    }
  }
  attach(socket) {
    this.socket = socket;
    socket.setEncoding('utf8');
    socket.on('data', chunk => this.onData(chunk));
    socket.on('error', err => this.failPending(err));
    socket.on('timeout', () => this.failPending(new SmtpError('Timed out waiting for the server')));
    socket.on('close', () => {
      this.closed = true;
      this.failPending(new SmtpError('Server closed the connection'));
    });
  }
  failPending(err) {
    const reject = this.pendingError;
    this.pending = null;
    this.pendingError = null;
    if (reject) reject(err);
  }
  onData(chunk) {
    this.buffer += chunk;

    // A response is complete when a line's 4th character is a space rather than
    // a hyphen, which is how SMTP marks the last line of a multiline reply.
    const lines = this.buffer.split('\r\n');
    for (let i = 0; i < lines.length - 1; i++) {
      const line = lines[i];
      if (/^\d{3} /.test(line)) {
        const consumed = lines.slice(0, i + 1);
        this.buffer = lines.slice(i + 1).join('\r\n');
        const raw = consumed.join('\n');
        const response = {
          code: parseInt(line.substring(0, 3), 10),
          lines: consumed,
          raw
        };
        this.log('S', raw);
        const resolve = this.pending;
        this.pending = null;
        this.pendingError = null;
        if (resolve) resolve(response);
        return;
      }
    }
  }
  readResponse() {
    if (this.closed) return Promise.reject(new SmtpError('Connection is closed'));
    return new Promise((resolve, reject) => {
      this.pending = resolve;
      this.pendingError = reject;
    });
  }

  /** Send a command and wait for its reply. `redact` keeps secrets out of the transcript. */
  async command(text, redact = false) {
    if (!this.socket) throw new SmtpError('Not connected');
    this.log('C', text, redact);
    this.socket.write(`${text}\r\n`);
    return this.readResponse();
  }
  expect(response, codes, stage) {
    if (!codes.includes(response.code)) {
      throw new SmtpError(`${stage} failed: ${response.raw}`, response.code);
    }
  }

  // ── Handshake ──────────────────────────────────────────────

  /** EHLO, upgrading to TLS first if the transport calls for it. */
  async handshake() {
    const clientName = 'wazuh-case-management';
    let ehlo = await this.command(`EHLO ${clientName}`);
    if (ehlo.code !== 250) {
      // Fall back to HELO for servers that predate ESMTP.
      const helo = await this.command(`HELO ${clientName}`);
      this.expect(helo, [250], 'HELO');
      return [];
    }
    let capabilities = SmtpSession.parseCapabilities(ehlo);
    if (this.settings.security === 'starttls') {
      if (!capabilities.some(c => c.startsWith('STARTTLS'))) {
        throw new SmtpError('The server does not advertise STARTTLS');
      }
      const start = await this.command('STARTTLS');
      this.expect(start, [220], 'STARTTLS');
      await this.upgradeToTls();
      // The capability list must be re-fetched over the encrypted channel,
      // because AUTH is commonly only offered after the upgrade.
      ehlo = await this.command(`EHLO ${clientName}`);
      this.expect(ehlo, [250], 'EHLO after STARTTLS');
      capabilities = SmtpSession.parseCapabilities(ehlo);
    }
    return capabilities;
  }
  static parseCapabilities(response) {
    return response.lines.map(line => line.substring(4).trim()).filter(line => line.length > 0);
  }
  async upgradeToTls() {
    const plain = this.socket;
    if (!plain) throw new SmtpError('Not connected');

    // Detach our handlers before handing the socket to the TLS layer.
    plain.removeAllListeners('data');
    plain.removeAllListeners('error');
    plain.removeAllListeners('close');
    plain.removeAllListeners('timeout');
    this.buffer = '';
    const secure = await new Promise((resolve, reject) => {
      let upgraded;
      upgraded = (0, _tls.connect)({
        socket: plain,
        servername: this.settings.host,
        rejectUnauthorized: this.settings.reject_unauthorized !== false
      }, () => resolve(upgraded));
      upgraded.once('error', err => reject(new SmtpError(`TLS upgrade failed: ${err.message}`)));
    });
    secure.setTimeout(this.timeout);
    this.attach(secure);
    this.log('C', '<TLS negotiated>');
  }

  // ── Authentication ─────────────────────────────────────────

  async authenticate(capabilities) {
    const {
      auth_type,
      username,
      password
    } = this.settings;
    if (auth_type === 'none') return;
    if (!username && auth_type === 'auto') return;
    const advertised = (capabilities.find(c => c.startsWith('AUTH')) || '').substring(4).trim().toUpperCase().split(/\s+/).filter(Boolean);
    let mechanism = auth_type;
    if (mechanism === 'auto') {
      if (advertised.includes('PLAIN')) mechanism = 'plain';else if (advertised.includes('LOGIN')) mechanism = 'login';else if (advertised.includes('CRAM-MD5')) mechanism = 'cram-md5';else if (advertised.length === 0) mechanism = 'login';else {
        throw new SmtpError(`The server offers no supported authentication mechanism (advertised: ${advertised.join(', ')})`);
      }
    }
    switch (mechanism) {
      case 'plain':
        {
          const token = Buffer.from(`\0${username}\0${password}`).toString('base64');
          const res = await this.command(`AUTH PLAIN ${token}`, true);
          this.expect(res, [235], 'AUTH PLAIN');
          break;
        }
      case 'login':
        {
          const start = await this.command('AUTH LOGIN');
          this.expect(start, [334], 'AUTH LOGIN');
          const user = await this.command(Buffer.from(username).toString('base64'), true);
          this.expect(user, [334], 'AUTH LOGIN username');
          const pass = await this.command(Buffer.from(password).toString('base64'), true);
          this.expect(pass, [235], 'AUTH LOGIN password');
          break;
        }
      case 'cram-md5':
        {
          const start = await this.command('AUTH CRAM-MD5');
          this.expect(start, [334], 'AUTH CRAM-MD5');
          const challenge = Buffer.from(start.lines[0].substring(4).trim(), 'base64').toString();
          const digest = (0, _crypto.createHmac)('md5', password).update(challenge).digest('hex');
          const answer = Buffer.from(`${username} ${digest}`).toString('base64');
          const res = await this.command(answer, true);
          this.expect(res, [235], 'AUTH CRAM-MD5');
          break;
        }
      default:
        break;
    }
  }

  // ── Envelope and body ──────────────────────────────────────

  async send(message) {
    const from = this.settings.from_address;
    const mailFrom = await this.command(`MAIL FROM:<${from}>`);
    this.expect(mailFrom, [250], 'MAIL FROM');
    const accepted = [];
    const rejected = [];
    for (const recipient of message.to) {
      const rcpt = await this.command(`RCPT TO:<${recipient}>`);
      if (rcpt.code === 250 || rcpt.code === 251) accepted.push(recipient);else rejected.push(recipient);
    }
    if (accepted.length === 0) {
      throw new SmtpError('Every recipient was rejected by the server');
    }
    const data = await this.command('DATA');
    this.expect(data, [354], 'DATA');
    const body = buildMimeMessage(this.settings, message);
    if (!this.socket) throw new SmtpError('Not connected');
    this.socket.write(dotStuff(body));
    this.socket.write('\r\n.\r\n');
    this.log('C', `<message body, ${body.length} bytes>`);
    const done = await this.readResponse();
    this.expect(done, [250], 'Message delivery');
    return {
      accepted,
      rejected
    };
  }
  async quit() {
    try {
      if (this.socket && !this.closed) {
        this.log('C', 'QUIT');
        this.socket.write('QUIT\r\n');
      }
    } catch (_e) {
      /* the message is already delivered; a failed QUIT is not worth reporting */
    } finally {
      this.destroy();
    }
  }
  destroy() {
    try {
      var _this$socket;
      (_this$socket = this.socket) === null || _this$socket === void 0 || _this$socket.destroy();
    } catch (_e) {
      /* nothing useful to do */
    }
    this.closed = true;
  }
}

// ── Message construction ─────────────────────────────────────

/**
 * RFC 2047 encoding for header values that contain non-ASCII characters,
 * so a subject like "Case escalated: café server" survives transport.
 */
function encodeHeader(value) {
  // eslint-disable-next-line no-control-regex
  if (/^[\x00-\x7F]*$/.test(value)) return value;
  return `=?UTF-8?B?${Buffer.from(value, 'utf8').toString('base64')}?=`;
}

/** Base64 with the 76-character line wrapping that MIME requires. */
function base64Wrapped(value) {
  const encoded = Buffer.from(value, 'utf8').toString('base64');
  return (encoded.match(/.{1,76}/g) || []).join('\r\n');
}

/** A line starting with "." would terminate DATA early, so it must be doubled. */
function dotStuff(body) {
  return body.replace(/\r\n\./g, '\r\n..');
}
function formatAddress(address, name) {
  return name ? `${encodeHeader(name)} <${address}>` : address;
}
function buildMimeMessage(settings, message) {
  const boundary = `----wazuh-case-${(0, _crypto.randomBytes)(12).toString('hex')}`;
  const messageId = `<${(0, _crypto.randomBytes)(16).toString('hex')}@wazuh-case-management>`;
  const headers = [`From: ${formatAddress(settings.from_address, settings.from_name)}`, `To: ${message.headerTo || message.to.join(', ')}`, `Subject: ${encodeHeader(message.subject)}`, `Date: ${new Date().toUTCString()}`, `Message-ID: ${messageId}`, 'MIME-Version: 1.0', 'X-Mailer: Wazuh Case Management', 'Auto-Submitted: auto-generated'];
  if (!message.html) {
    headers.push('Content-Type: text/plain; charset=UTF-8', 'Content-Transfer-Encoding: base64');
    return `${headers.join('\r\n')}\r\n\r\n${base64Wrapped(message.text)}`;
  }
  headers.push(`Content-Type: multipart/alternative; boundary="${boundary}"`);
  const parts = [`--${boundary}`, 'Content-Type: text/plain; charset=UTF-8', 'Content-Transfer-Encoding: base64', '', base64Wrapped(message.text), '', `--${boundary}`, 'Content-Type: text/html; charset=UTF-8', 'Content-Transfer-Encoding: base64', '', base64Wrapped(message.html), '', `--${boundary}--`];
  return `${headers.join('\r\n')}\r\n\r\n${parts.join('\r\n')}`;
}

// ── Public API ───────────────────────────────────────────────

class SmtpService {
  /**
   * Deliver one message. Never throws: the outcome, including the redacted
   * dialogue, comes back in the result so the caller can surface it.
   */
  static async send(settings, message) {
    const session = new SmtpSession(settings);
    if (!settings.host) {
      return {
        ok: false,
        error: 'No SMTP host configured',
        transcript: [],
        accepted: [],
        rejected: []
      };
    }
    if (!settings.from_address) {
      return {
        ok: false,
        error: 'No sender address configured',
        transcript: [],
        accepted: [],
        rejected: []
      };
    }
    const recipients = (message.to || []).map(r => r.trim()).filter(Boolean);
    if (recipients.length === 0) {
      return {
        ok: false,
        error: 'No recipients',
        transcript: [],
        accepted: [],
        rejected: []
      };
    }
    try {
      await session.connect();
      const capabilities = await session.handshake();
      await session.authenticate(capabilities);
      const {
        accepted,
        rejected
      } = await session.send({
        ...message,
        to: recipients
      });
      await session.quit();
      return {
        ok: true,
        transcript: session.transcript,
        accepted,
        rejected
      };
    } catch (e) {
      session.destroy();
      return {
        ok: false,
        error: (e === null || e === void 0 ? void 0 : e.message) || String(e),
        transcript: session.transcript,
        accepted: [],
        rejected: recipients
      };
    }
  }

  /** Default port for a given transport, used to keep the UI in step. */
  static defaultPort(security) {
    if (security === 'tls') return 465;
    if (security === 'none') return 25;
    return 587;
  }
}
exports.SmtpService = SmtpService;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfbmV0IiwicmVxdWlyZSIsIl90bHMiLCJfY3J5cHRvIiwiX2NvbnN0YW50cyIsIl9kZWZpbmVQcm9wZXJ0eSIsImUiLCJyIiwidCIsIl90b1Byb3BlcnR5S2V5IiwiT2JqZWN0IiwiZGVmaW5lUHJvcGVydHkiLCJ2YWx1ZSIsImVudW1lcmFibGUiLCJjb25maWd1cmFibGUiLCJ3cml0YWJsZSIsImkiLCJfdG9QcmltaXRpdmUiLCJTeW1ib2wiLCJ0b1ByaW1pdGl2ZSIsImNhbGwiLCJUeXBlRXJyb3IiLCJTdHJpbmciLCJOdW1iZXIiLCJTbXRwRXJyb3IiLCJFcnJvciIsImNvbnN0cnVjdG9yIiwibWVzc2FnZSIsImNvZGUiLCJuYW1lIiwiU210cFNlc3Npb24iLCJzZXR0aW5ncyIsInRpbWVvdXQiLCJ0aW1lb3V0X21zIiwiU01UUF9ERUZBVUxUX1RJTUVPVVRfTVMiLCJsb2ciLCJkaXJlY3Rpb24iLCJ0ZXh0IiwicmVkYWN0IiwidHJhbnNjcmlwdCIsImxlbmd0aCIsInB1c2giLCJjb25uZWN0IiwiaG9zdCIsInBvcnQiLCJzZWN1cml0eSIsInJlamVjdF91bmF1dGhvcml6ZWQiLCJQcm9taXNlIiwicmVzb2x2ZSIsInJlamVjdCIsIm9uRXJyb3IiLCJlcnIiLCJzb2NrZXQiLCJ0bHNDb25uZWN0IiwicmVqZWN0VW5hdXRob3JpemVkIiwic2VydmVybmFtZSIsInJlbW92ZUxpc3RlbmVyIiwiYXR0YWNoIiwib25jZSIsInNldFRpbWVvdXQiLCJuZXRDb25uZWN0IiwiZ3JlZXRpbmciLCJyZWFkUmVzcG9uc2UiLCJyYXciLCJzZXRFbmNvZGluZyIsIm9uIiwiY2h1bmsiLCJvbkRhdGEiLCJmYWlsUGVuZGluZyIsImNsb3NlZCIsInBlbmRpbmdFcnJvciIsInBlbmRpbmciLCJidWZmZXIiLCJsaW5lcyIsInNwbGl0IiwibGluZSIsInRlc3QiLCJjb25zdW1lZCIsInNsaWNlIiwiam9pbiIsInJlc3BvbnNlIiwicGFyc2VJbnQiLCJzdWJzdHJpbmciLCJjb21tYW5kIiwid3JpdGUiLCJleHBlY3QiLCJjb2RlcyIsInN0YWdlIiwiaW5jbHVkZXMiLCJoYW5kc2hha2UiLCJjbGllbnROYW1lIiwiZWhsbyIsImhlbG8iLCJjYXBhYmlsaXRpZXMiLCJwYXJzZUNhcGFiaWxpdGllcyIsInNvbWUiLCJjIiwic3RhcnRzV2l0aCIsInN0YXJ0IiwidXBncmFkZVRvVGxzIiwibWFwIiwidHJpbSIsImZpbHRlciIsInBsYWluIiwicmVtb3ZlQWxsTGlzdGVuZXJzIiwic2VjdXJlIiwidXBncmFkZWQiLCJhdXRoZW50aWNhdGUiLCJhdXRoX3R5cGUiLCJ1c2VybmFtZSIsInBhc3N3b3JkIiwiYWR2ZXJ0aXNlZCIsImZpbmQiLCJ0b1VwcGVyQ2FzZSIsIkJvb2xlYW4iLCJtZWNoYW5pc20iLCJ0b2tlbiIsIkJ1ZmZlciIsImZyb20iLCJ0b1N0cmluZyIsInJlcyIsInVzZXIiLCJwYXNzIiwiY2hhbGxlbmdlIiwiZGlnZXN0IiwiY3JlYXRlSG1hYyIsInVwZGF0ZSIsImFuc3dlciIsInNlbmQiLCJmcm9tX2FkZHJlc3MiLCJtYWlsRnJvbSIsImFjY2VwdGVkIiwicmVqZWN0ZWQiLCJyZWNpcGllbnQiLCJ0byIsInJjcHQiLCJkYXRhIiwiYm9keSIsImJ1aWxkTWltZU1lc3NhZ2UiLCJkb3RTdHVmZiIsImRvbmUiLCJxdWl0IiwiX2UiLCJkZXN0cm95IiwiX3RoaXMkc29ja2V0IiwiZW5jb2RlSGVhZGVyIiwiYmFzZTY0V3JhcHBlZCIsImVuY29kZWQiLCJtYXRjaCIsInJlcGxhY2UiLCJmb3JtYXRBZGRyZXNzIiwiYWRkcmVzcyIsImJvdW5kYXJ5IiwicmFuZG9tQnl0ZXMiLCJtZXNzYWdlSWQiLCJoZWFkZXJzIiwiZnJvbV9uYW1lIiwiaGVhZGVyVG8iLCJzdWJqZWN0IiwiRGF0ZSIsInRvVVRDU3RyaW5nIiwiaHRtbCIsInBhcnRzIiwiU210cFNlcnZpY2UiLCJzZXNzaW9uIiwib2siLCJlcnJvciIsInJlY2lwaWVudHMiLCJkZWZhdWx0UG9ydCIsImV4cG9ydHMiXSwic291cmNlcyI6WyJzbXRwX3NlcnZpY2UudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLypcbiAqIFdhenVoIENhc2UgTWFuYWdlbWVudCBQbHVnaW5cbiAqIFNNVFAgU2VydmljZTogYSBtaW5pbWFsLCBkZXBlbmRlbmN5LWZyZWUgU01UUCBjbGllbnRcbiAqXG4gKiBJbXBsZW1lbnRlZCBkaXJlY3RseSBvbiBOb2RlJ3MgYnVpbHQtaW4gYG5ldGAgYW5kIGB0bHNgIHNvIHRoZSBwbHVnaW4gY2FuXG4gKiBzZW5kIG1haWwgd2l0aG91dCBwdWxsaW5nIGluIGEgdGhpcmQtcGFydHkgbGlicmFyeS4gSXQgY292ZXJzIHdoYXQgYSBXYXp1aFxuICogZGVwbG95bWVudCByZWFsaXN0aWNhbGx5IG5lZWRzOlxuICpcbiAqICAgVHJhbnNwb3J0ICAgcGxhaW4sIFNUQVJUVExTIHVwZ3JhZGUsIG9yIGltcGxpY2l0IFRMU1xuICogICBBdXRoICAgICAgICBQTEFJTiwgTE9HSU4sIENSQU0tTUQ1LCBvciBub25lLCBuZWdvdGlhdGVkIGZyb20gRUhMT1xuICogICBCb2R5ICAgICAgICBtdWx0aXBhcnQvYWx0ZXJuYXRpdmUgd2l0aCBhIHBsYWluLXRleHQgYW5kIGFuIEhUTUwgcGFydFxuICpcbiAqIEV2ZXJ5IHNlbmQgcmV0dXJucyBhIHJlZGFjdGVkIHRyYW5zY3JpcHQgb2YgdGhlIGRpYWxvZ3VlLCB3aGljaCBpcyB3aGF0IG1ha2VzXG4gKiBhIG1pc2NvbmZpZ3VyZWQgcmVsYXkgZGlhZ25vc2FibGUgZnJvbSB0aGUgU2V0dGluZ3MgcGFnZS5cbiAqL1xuXG5pbXBvcnQgeyBjb25uZWN0IGFzIG5ldENvbm5lY3QsIFNvY2tldCB9IGZyb20gJ25ldCc7XG5pbXBvcnQgeyBjb25uZWN0IGFzIHRsc0Nvbm5lY3QsIFRMU1NvY2tldCB9IGZyb20gJ3Rscyc7XG5pbXBvcnQgeyBjcmVhdGVIbWFjLCByYW5kb21CeXRlcyB9IGZyb20gJ2NyeXB0byc7XG5pbXBvcnQgeyBTbXRwU2V0dGluZ3MsIFNtdHBTZW5kUmVzdWx0IH0gZnJvbSAnLi4vLi4vY29tbW9uL3R5cGVzJztcbmltcG9ydCB7IFNNVFBfREVGQVVMVF9USU1FT1VUX01TIH0gZnJvbSAnLi4vLi4vY29tbW9uL2NvbnN0YW50cyc7XG5cbmV4cG9ydCBpbnRlcmZhY2UgTWFpbE1lc3NhZ2Uge1xuICAvKiogRW52ZWxvcGUgcmVjaXBpZW50cy4gRXZlcnkgYWRkcmVzcyBoZXJlIHJlY2VpdmVzIHRoZSBtZXNzYWdlLiAqL1xuICB0bzogc3RyaW5nW107XG4gIHN1YmplY3Q6IHN0cmluZztcbiAgdGV4dDogc3RyaW5nO1xuICBodG1sPzogc3RyaW5nO1xuICAvKipcbiAgICogT3ZlcnJpZGVzIHRoZSBUbyBoZWFkZXIgd2l0aG91dCBjaGFuZ2luZyB0aGUgZW52ZWxvcGUuIFVzZWQgZm9yIGJsaW5kXG4gICAqIGRlbGl2ZXJ5LCB3aGVyZSB0aGUgaGVhZGVyIG11c3Qgbm90IGRpc2Nsb3NlIHRoZSByZWNpcGllbnQgbGlzdC5cbiAgICovXG4gIGhlYWRlclRvPzogc3RyaW5nO1xufVxuXG5pbnRlcmZhY2UgU210cFJlc3BvbnNlIHtcbiAgY29kZTogbnVtYmVyO1xuICBsaW5lczogc3RyaW5nW107XG4gIHJhdzogc3RyaW5nO1xufVxuXG4vKiogVGhyb3duIGZvciBhIHByb3RvY29sLWxldmVsIGZhaWx1cmUgc28gdGhlIGNhbGxlciBjYW4gcmVwb3J0IHRoZSBzdGFnZS4gKi9cbmNsYXNzIFNtdHBFcnJvciBleHRlbmRzIEVycm9yIHtcbiAgY29uc3RydWN0b3IobWVzc2FnZTogc3RyaW5nLCBwdWJsaWMgcmVhZG9ubHkgY29kZT86IG51bWJlcikge1xuICAgIHN1cGVyKG1lc3NhZ2UpO1xuICAgIHRoaXMubmFtZSA9ICdTbXRwRXJyb3InO1xuICB9XG59XG5cbi8qKlxuICogQSBzaW5nbGUgU01UUCBjb252ZXJzYXRpb24uIE9uZSBpbnN0YW5jZSBoYW5kbGVzIG9uZSBjb25uZWN0aW9uLCB0aGVuIHRoZVxuICogc29ja2V0IGlzIGNsb3NlZDsgU01UUCBjb25uZWN0aW9uIHBvb2xpbmcgaXMgbm90IHdvcnRoIHRoZSBjb21wbGV4aXR5IGZvciB0aGVcbiAqIHZvbHVtZSBvZiBtYWlsIGEgY2FzZS1tYW5hZ2VtZW50IHBsdWdpbiBzZW5kcy5cbiAqL1xuY2xhc3MgU210cFNlc3Npb24ge1xuICBwcml2YXRlIHNvY2tldDogU29ja2V0IHwgVExTU29ja2V0IHwgbnVsbCA9IG51bGw7XG4gIHByaXZhdGUgYnVmZmVyID0gJyc7XG4gIHByaXZhdGUgcGVuZGluZzogKChyZXNwb25zZTogU210cFJlc3BvbnNlKSA9PiB2b2lkKSB8IG51bGwgPSBudWxsO1xuICBwcml2YXRlIHBlbmRpbmdFcnJvcjogKChlcnJvcjogRXJyb3IpID0+IHZvaWQpIHwgbnVsbCA9IG51bGw7XG4gIHByaXZhdGUgY2xvc2VkID0gZmFsc2U7XG5cbiAgcmVhZG9ubHkgdHJhbnNjcmlwdDogc3RyaW5nW10gPSBbXTtcblxuICBjb25zdHJ1Y3Rvcihwcml2YXRlIHJlYWRvbmx5IHNldHRpbmdzOiBTbXRwU2V0dGluZ3MpIHt9XG5cbiAgcHJpdmF0ZSBnZXQgdGltZW91dCgpOiBudW1iZXIge1xuICAgIHJldHVybiB0aGlzLnNldHRpbmdzLnRpbWVvdXRfbXMgfHwgU01UUF9ERUZBVUxUX1RJTUVPVVRfTVM7XG4gIH1cblxuICBwcml2YXRlIGxvZyhkaXJlY3Rpb246ICdDJyB8ICdTJywgdGV4dDogc3RyaW5nLCByZWRhY3QgPSBmYWxzZSk6IHZvaWQge1xuICAgIC8vIENhcCB0aGUgdHJhbnNjcmlwdCBzbyBhIGNoYXR0eSBzZXJ2ZXIgY2Fubm90IGJhbGxvb24gdGhlIHJlc3BvbnNlLlxuICAgIGlmICh0aGlzLnRyYW5zY3JpcHQubGVuZ3RoID4gODApIHJldHVybjtcbiAgICB0aGlzLnRyYW5zY3JpcHQucHVzaChgJHtkaXJlY3Rpb259OiAke3JlZGFjdCA/ICcqKioqKioqKicgOiB0ZXh0fWApO1xuICB9XG5cbiAgLy8g4pSA4pSAIENvbm5lY3Rpb24g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbiAgYXN5bmMgY29ubmVjdCgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBjb25zdCB7IGhvc3QsIHBvcnQsIHNlY3VyaXR5LCByZWplY3RfdW5hdXRob3JpemVkIH0gPSB0aGlzLnNldHRpbmdzO1xuXG4gICAgYXdhaXQgbmV3IFByb21pc2U8dm9pZD4oKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgY29uc3Qgb25FcnJvciA9IChlcnI6IEVycm9yKSA9PiByZWplY3QobmV3IFNtdHBFcnJvcihgQ29ubmVjdGlvbiBmYWlsZWQ6ICR7ZXJyLm1lc3NhZ2V9YCkpO1xuXG4gICAgICBpZiAoc2VjdXJpdHkgPT09ICd0bHMnKSB7XG4gICAgICAgIGNvbnN0IHNvY2tldCA9IHRsc0Nvbm5lY3QoXG4gICAgICAgICAgeyBob3N0LCBwb3J0LCByZWplY3RVbmF1dGhvcml6ZWQ6IHJlamVjdF91bmF1dGhvcml6ZWQgIT09IGZhbHNlLCBzZXJ2ZXJuYW1lOiBob3N0IH0sXG4gICAgICAgICAgKCkgPT4ge1xuICAgICAgICAgICAgc29ja2V0LnJlbW92ZUxpc3RlbmVyKCdlcnJvcicsIG9uRXJyb3IpO1xuICAgICAgICAgICAgdGhpcy5hdHRhY2goc29ja2V0KTtcbiAgICAgICAgICAgIHJlc29sdmUoKTtcbiAgICAgICAgICB9LFxuICAgICAgICApO1xuICAgICAgICBzb2NrZXQub25jZSgnZXJyb3InLCBvbkVycm9yKTtcbiAgICAgICAgc29ja2V0LnNldFRpbWVvdXQodGhpcy50aW1lb3V0KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnN0IHNvY2tldCA9IG5ldENvbm5lY3QoeyBob3N0LCBwb3J0IH0sICgpID0+IHtcbiAgICAgICAgICBzb2NrZXQucmVtb3ZlTGlzdGVuZXIoJ2Vycm9yJywgb25FcnJvcik7XG4gICAgICAgICAgdGhpcy5hdHRhY2goc29ja2V0KTtcbiAgICAgICAgICByZXNvbHZlKCk7XG4gICAgICAgIH0pO1xuICAgICAgICBzb2NrZXQub25jZSgnZXJyb3InLCBvbkVycm9yKTtcbiAgICAgICAgc29ja2V0LnNldFRpbWVvdXQodGhpcy50aW1lb3V0KTtcbiAgICAgIH1cbiAgICB9KTtcblxuICAgIGNvbnN0IGdyZWV0aW5nID0gYXdhaXQgdGhpcy5yZWFkUmVzcG9uc2UoKTtcbiAgICBpZiAoZ3JlZXRpbmcuY29kZSAhPT0gMjIwKSB7XG4gICAgICB0aHJvdyBuZXcgU210cEVycm9yKGBVbmV4cGVjdGVkIGdyZWV0aW5nOiAke2dyZWV0aW5nLnJhd31gLCBncmVldGluZy5jb2RlKTtcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGF0dGFjaChzb2NrZXQ6IFNvY2tldCB8IFRMU1NvY2tldCk6IHZvaWQge1xuICAgIHRoaXMuc29ja2V0ID0gc29ja2V0O1xuICAgIHNvY2tldC5zZXRFbmNvZGluZygndXRmOCcpO1xuICAgIHNvY2tldC5vbignZGF0YScsIChjaHVuazogc3RyaW5nKSA9PiB0aGlzLm9uRGF0YShjaHVuaykpO1xuICAgIHNvY2tldC5vbignZXJyb3InLCAoZXJyOiBFcnJvcikgPT4gdGhpcy5mYWlsUGVuZGluZyhlcnIpKTtcbiAgICBzb2NrZXQub24oJ3RpbWVvdXQnLCAoKSA9PiB0aGlzLmZhaWxQZW5kaW5nKG5ldyBTbXRwRXJyb3IoJ1RpbWVkIG91dCB3YWl0aW5nIGZvciB0aGUgc2VydmVyJykpKTtcbiAgICBzb2NrZXQub24oJ2Nsb3NlJywgKCkgPT4ge1xuICAgICAgdGhpcy5jbG9zZWQgPSB0cnVlO1xuICAgICAgdGhpcy5mYWlsUGVuZGluZyhuZXcgU210cEVycm9yKCdTZXJ2ZXIgY2xvc2VkIHRoZSBjb25uZWN0aW9uJykpO1xuICAgIH0pO1xuICB9XG5cbiAgcHJpdmF0ZSBmYWlsUGVuZGluZyhlcnI6IEVycm9yKTogdm9pZCB7XG4gICAgY29uc3QgcmVqZWN0ID0gdGhpcy5wZW5kaW5nRXJyb3I7XG4gICAgdGhpcy5wZW5kaW5nID0gbnVsbDtcbiAgICB0aGlzLnBlbmRpbmdFcnJvciA9IG51bGw7XG4gICAgaWYgKHJlamVjdCkgcmVqZWN0KGVycik7XG4gIH1cblxuICBwcml2YXRlIG9uRGF0YShjaHVuazogc3RyaW5nKTogdm9pZCB7XG4gICAgdGhpcy5idWZmZXIgKz0gY2h1bms7XG5cbiAgICAvLyBBIHJlc3BvbnNlIGlzIGNvbXBsZXRlIHdoZW4gYSBsaW5lJ3MgNHRoIGNoYXJhY3RlciBpcyBhIHNwYWNlIHJhdGhlciB0aGFuXG4gICAgLy8gYSBoeXBoZW4sIHdoaWNoIGlzIGhvdyBTTVRQIG1hcmtzIHRoZSBsYXN0IGxpbmUgb2YgYSBtdWx0aWxpbmUgcmVwbHkuXG4gICAgY29uc3QgbGluZXMgPSB0aGlzLmJ1ZmZlci5zcGxpdCgnXFxyXFxuJyk7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBsaW5lcy5sZW5ndGggLSAxOyBpKyspIHtcbiAgICAgIGNvbnN0IGxpbmUgPSBsaW5lc1tpXTtcbiAgICAgIGlmICgvXlxcZHszfSAvLnRlc3QobGluZSkpIHtcbiAgICAgICAgY29uc3QgY29uc3VtZWQgPSBsaW5lcy5zbGljZSgwLCBpICsgMSk7XG4gICAgICAgIHRoaXMuYnVmZmVyID0gbGluZXMuc2xpY2UoaSArIDEpLmpvaW4oJ1xcclxcbicpO1xuICAgICAgICBjb25zdCByYXcgPSBjb25zdW1lZC5qb2luKCdcXG4nKTtcbiAgICAgICAgY29uc3QgcmVzcG9uc2U6IFNtdHBSZXNwb25zZSA9IHtcbiAgICAgICAgICBjb2RlOiBwYXJzZUludChsaW5lLnN1YnN0cmluZygwLCAzKSwgMTApLFxuICAgICAgICAgIGxpbmVzOiBjb25zdW1lZCxcbiAgICAgICAgICByYXcsXG4gICAgICAgIH07XG4gICAgICAgIHRoaXMubG9nKCdTJywgcmF3KTtcbiAgICAgICAgY29uc3QgcmVzb2x2ZSA9IHRoaXMucGVuZGluZztcbiAgICAgICAgdGhpcy5wZW5kaW5nID0gbnVsbDtcbiAgICAgICAgdGhpcy5wZW5kaW5nRXJyb3IgPSBudWxsO1xuICAgICAgICBpZiAocmVzb2x2ZSkgcmVzb2x2ZShyZXNwb25zZSk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICBwcml2YXRlIHJlYWRSZXNwb25zZSgpOiBQcm9taXNlPFNtdHBSZXNwb25zZT4ge1xuICAgIGlmICh0aGlzLmNsb3NlZCkgcmV0dXJuIFByb21pc2UucmVqZWN0KG5ldyBTbXRwRXJyb3IoJ0Nvbm5lY3Rpb24gaXMgY2xvc2VkJykpO1xuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICB0aGlzLnBlbmRpbmcgPSByZXNvbHZlO1xuICAgICAgdGhpcy5wZW5kaW5nRXJyb3IgPSByZWplY3Q7XG4gICAgfSk7XG4gIH1cblxuICAvKiogU2VuZCBhIGNvbW1hbmQgYW5kIHdhaXQgZm9yIGl0cyByZXBseS4gYHJlZGFjdGAga2VlcHMgc2VjcmV0cyBvdXQgb2YgdGhlIHRyYW5zY3JpcHQuICovXG4gIHByaXZhdGUgYXN5bmMgY29tbWFuZCh0ZXh0OiBzdHJpbmcsIHJlZGFjdCA9IGZhbHNlKTogUHJvbWlzZTxTbXRwUmVzcG9uc2U+IHtcbiAgICBpZiAoIXRoaXMuc29ja2V0KSB0aHJvdyBuZXcgU210cEVycm9yKCdOb3QgY29ubmVjdGVkJyk7XG4gICAgdGhpcy5sb2coJ0MnLCB0ZXh0LCByZWRhY3QpO1xuICAgIHRoaXMuc29ja2V0LndyaXRlKGAke3RleHR9XFxyXFxuYCk7XG4gICAgcmV0dXJuIHRoaXMucmVhZFJlc3BvbnNlKCk7XG4gIH1cblxuICBwcml2YXRlIGV4cGVjdChyZXNwb25zZTogU210cFJlc3BvbnNlLCBjb2RlczogbnVtYmVyW10sIHN0YWdlOiBzdHJpbmcpOiB2b2lkIHtcbiAgICBpZiAoIWNvZGVzLmluY2x1ZGVzKHJlc3BvbnNlLmNvZGUpKSB7XG4gICAgICB0aHJvdyBuZXcgU210cEVycm9yKGAke3N0YWdlfSBmYWlsZWQ6ICR7cmVzcG9uc2UucmF3fWAsIHJlc3BvbnNlLmNvZGUpO1xuICAgIH1cbiAgfVxuXG4gIC8vIOKUgOKUgCBIYW5kc2hha2Ug4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbiAgLyoqIEVITE8sIHVwZ3JhZGluZyB0byBUTFMgZmlyc3QgaWYgdGhlIHRyYW5zcG9ydCBjYWxscyBmb3IgaXQuICovXG4gIGFzeW5jIGhhbmRzaGFrZSgpOiBQcm9taXNlPHN0cmluZ1tdPiB7XG4gICAgY29uc3QgY2xpZW50TmFtZSA9ICd3YXp1aC1jYXNlLW1hbmFnZW1lbnQnO1xuICAgIGxldCBlaGxvID0gYXdhaXQgdGhpcy5jb21tYW5kKGBFSExPICR7Y2xpZW50TmFtZX1gKTtcblxuICAgIGlmIChlaGxvLmNvZGUgIT09IDI1MCkge1xuICAgICAgLy8gRmFsbCBiYWNrIHRvIEhFTE8gZm9yIHNlcnZlcnMgdGhhdCBwcmVkYXRlIEVTTVRQLlxuICAgICAgY29uc3QgaGVsbyA9IGF3YWl0IHRoaXMuY29tbWFuZChgSEVMTyAke2NsaWVudE5hbWV9YCk7XG4gICAgICB0aGlzLmV4cGVjdChoZWxvLCBbMjUwXSwgJ0hFTE8nKTtcbiAgICAgIHJldHVybiBbXTtcbiAgICB9XG5cbiAgICBsZXQgY2FwYWJpbGl0aWVzID0gU210cFNlc3Npb24ucGFyc2VDYXBhYmlsaXRpZXMoZWhsbyk7XG5cbiAgICBpZiAodGhpcy5zZXR0aW5ncy5zZWN1cml0eSA9PT0gJ3N0YXJ0dGxzJykge1xuICAgICAgaWYgKCFjYXBhYmlsaXRpZXMuc29tZSgoYykgPT4gYy5zdGFydHNXaXRoKCdTVEFSVFRMUycpKSkge1xuICAgICAgICB0aHJvdyBuZXcgU210cEVycm9yKCdUaGUgc2VydmVyIGRvZXMgbm90IGFkdmVydGlzZSBTVEFSVFRMUycpO1xuICAgICAgfVxuICAgICAgY29uc3Qgc3RhcnQgPSBhd2FpdCB0aGlzLmNvbW1hbmQoJ1NUQVJUVExTJyk7XG4gICAgICB0aGlzLmV4cGVjdChzdGFydCwgWzIyMF0sICdTVEFSVFRMUycpO1xuICAgICAgYXdhaXQgdGhpcy51cGdyYWRlVG9UbHMoKTtcbiAgICAgIC8vIFRoZSBjYXBhYmlsaXR5IGxpc3QgbXVzdCBiZSByZS1mZXRjaGVkIG92ZXIgdGhlIGVuY3J5cHRlZCBjaGFubmVsLFxuICAgICAgLy8gYmVjYXVzZSBBVVRIIGlzIGNvbW1vbmx5IG9ubHkgb2ZmZXJlZCBhZnRlciB0aGUgdXBncmFkZS5cbiAgICAgIGVobG8gPSBhd2FpdCB0aGlzLmNvbW1hbmQoYEVITE8gJHtjbGllbnROYW1lfWApO1xuICAgICAgdGhpcy5leHBlY3QoZWhsbywgWzI1MF0sICdFSExPIGFmdGVyIFNUQVJUVExTJyk7XG4gICAgICBjYXBhYmlsaXRpZXMgPSBTbXRwU2Vzc2lvbi5wYXJzZUNhcGFiaWxpdGllcyhlaGxvKTtcbiAgICB9XG5cbiAgICByZXR1cm4gY2FwYWJpbGl0aWVzO1xuICB9XG5cbiAgcHJpdmF0ZSBzdGF0aWMgcGFyc2VDYXBhYmlsaXRpZXMocmVzcG9uc2U6IFNtdHBSZXNwb25zZSk6IHN0cmluZ1tdIHtcbiAgICByZXR1cm4gcmVzcG9uc2UubGluZXNcbiAgICAgIC5tYXAoKGxpbmUpID0+IGxpbmUuc3Vic3RyaW5nKDQpLnRyaW0oKSlcbiAgICAgIC5maWx0ZXIoKGxpbmUpID0+IGxpbmUubGVuZ3RoID4gMCk7XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIHVwZ3JhZGVUb1RscygpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBjb25zdCBwbGFpbiA9IHRoaXMuc29ja2V0IGFzIFNvY2tldDtcbiAgICBpZiAoIXBsYWluKSB0aHJvdyBuZXcgU210cEVycm9yKCdOb3QgY29ubmVjdGVkJyk7XG5cbiAgICAvLyBEZXRhY2ggb3VyIGhhbmRsZXJzIGJlZm9yZSBoYW5kaW5nIHRoZSBzb2NrZXQgdG8gdGhlIFRMUyBsYXllci5cbiAgICBwbGFpbi5yZW1vdmVBbGxMaXN0ZW5lcnMoJ2RhdGEnKTtcbiAgICBwbGFpbi5yZW1vdmVBbGxMaXN0ZW5lcnMoJ2Vycm9yJyk7XG4gICAgcGxhaW4ucmVtb3ZlQWxsTGlzdGVuZXJzKCdjbG9zZScpO1xuICAgIHBsYWluLnJlbW92ZUFsbExpc3RlbmVycygndGltZW91dCcpO1xuICAgIHRoaXMuYnVmZmVyID0gJyc7XG5cbiAgICBjb25zdCBzZWN1cmUgPSBhd2FpdCBuZXcgUHJvbWlzZTxUTFNTb2NrZXQ+KChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgIGxldCB1cGdyYWRlZDogVExTU29ja2V0O1xuICAgICAgdXBncmFkZWQgPSB0bHNDb25uZWN0KFxuICAgICAgICB7XG4gICAgICAgICAgc29ja2V0OiBwbGFpbixcbiAgICAgICAgICBzZXJ2ZXJuYW1lOiB0aGlzLnNldHRpbmdzLmhvc3QsXG4gICAgICAgICAgcmVqZWN0VW5hdXRob3JpemVkOiB0aGlzLnNldHRpbmdzLnJlamVjdF91bmF1dGhvcml6ZWQgIT09IGZhbHNlLFxuICAgICAgICB9LFxuICAgICAgICAoKSA9PiByZXNvbHZlKHVwZ3JhZGVkKSxcbiAgICAgICk7XG4gICAgICB1cGdyYWRlZC5vbmNlKCdlcnJvcicsIChlcnI6IEVycm9yKSA9PlxuICAgICAgICByZWplY3QobmV3IFNtdHBFcnJvcihgVExTIHVwZ3JhZGUgZmFpbGVkOiAke2Vyci5tZXNzYWdlfWApKSxcbiAgICAgICk7XG4gICAgfSk7XG5cbiAgICBzZWN1cmUuc2V0VGltZW91dCh0aGlzLnRpbWVvdXQpO1xuICAgIHRoaXMuYXR0YWNoKHNlY3VyZSk7XG4gICAgdGhpcy5sb2coJ0MnLCAnPFRMUyBuZWdvdGlhdGVkPicpO1xuICB9XG5cbiAgLy8g4pSA4pSAIEF1dGhlbnRpY2F0aW9uIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG4gIGFzeW5jIGF1dGhlbnRpY2F0ZShjYXBhYmlsaXRpZXM6IHN0cmluZ1tdKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgY29uc3QgeyBhdXRoX3R5cGUsIHVzZXJuYW1lLCBwYXNzd29yZCB9ID0gdGhpcy5zZXR0aW5ncztcbiAgICBpZiAoYXV0aF90eXBlID09PSAnbm9uZScpIHJldHVybjtcbiAgICBpZiAoIXVzZXJuYW1lICYmIGF1dGhfdHlwZSA9PT0gJ2F1dG8nKSByZXR1cm47XG5cbiAgICBjb25zdCBhZHZlcnRpc2VkID0gKGNhcGFiaWxpdGllcy5maW5kKChjKSA9PiBjLnN0YXJ0c1dpdGgoJ0FVVEgnKSkgfHwgJycpXG4gICAgICAuc3Vic3RyaW5nKDQpXG4gICAgICAudHJpbSgpXG4gICAgICAudG9VcHBlckNhc2UoKVxuICAgICAgLnNwbGl0KC9cXHMrLylcbiAgICAgIC5maWx0ZXIoQm9vbGVhbik7XG5cbiAgICBsZXQgbWVjaGFuaXNtID0gYXV0aF90eXBlO1xuICAgIGlmIChtZWNoYW5pc20gPT09ICdhdXRvJykge1xuICAgICAgaWYgKGFkdmVydGlzZWQuaW5jbHVkZXMoJ1BMQUlOJykpIG1lY2hhbmlzbSA9ICdwbGFpbic7XG4gICAgICBlbHNlIGlmIChhZHZlcnRpc2VkLmluY2x1ZGVzKCdMT0dJTicpKSBtZWNoYW5pc20gPSAnbG9naW4nO1xuICAgICAgZWxzZSBpZiAoYWR2ZXJ0aXNlZC5pbmNsdWRlcygnQ1JBTS1NRDUnKSkgbWVjaGFuaXNtID0gJ2NyYW0tbWQ1JztcbiAgICAgIGVsc2UgaWYgKGFkdmVydGlzZWQubGVuZ3RoID09PSAwKSBtZWNoYW5pc20gPSAnbG9naW4nO1xuICAgICAgZWxzZSB7XG4gICAgICAgIHRocm93IG5ldyBTbXRwRXJyb3IoXG4gICAgICAgICAgYFRoZSBzZXJ2ZXIgb2ZmZXJzIG5vIHN1cHBvcnRlZCBhdXRoZW50aWNhdGlvbiBtZWNoYW5pc20gKGFkdmVydGlzZWQ6ICR7YWR2ZXJ0aXNlZC5qb2luKCcsICcpfSlgLFxuICAgICAgICApO1xuICAgICAgfVxuICAgIH1cblxuICAgIHN3aXRjaCAobWVjaGFuaXNtKSB7XG4gICAgICBjYXNlICdwbGFpbic6IHtcbiAgICAgICAgY29uc3QgdG9rZW4gPSBCdWZmZXIuZnJvbShgXFwwJHt1c2VybmFtZX1cXDAke3Bhc3N3b3JkfWApLnRvU3RyaW5nKCdiYXNlNjQnKTtcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgdGhpcy5jb21tYW5kKGBBVVRIIFBMQUlOICR7dG9rZW59YCwgdHJ1ZSk7XG4gICAgICAgIHRoaXMuZXhwZWN0KHJlcywgWzIzNV0sICdBVVRIIFBMQUlOJyk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgICAgY2FzZSAnbG9naW4nOiB7XG4gICAgICAgIGNvbnN0IHN0YXJ0ID0gYXdhaXQgdGhpcy5jb21tYW5kKCdBVVRIIExPR0lOJyk7XG4gICAgICAgIHRoaXMuZXhwZWN0KHN0YXJ0LCBbMzM0XSwgJ0FVVEggTE9HSU4nKTtcbiAgICAgICAgY29uc3QgdXNlciA9IGF3YWl0IHRoaXMuY29tbWFuZChCdWZmZXIuZnJvbSh1c2VybmFtZSkudG9TdHJpbmcoJ2Jhc2U2NCcpLCB0cnVlKTtcbiAgICAgICAgdGhpcy5leHBlY3QodXNlciwgWzMzNF0sICdBVVRIIExPR0lOIHVzZXJuYW1lJyk7XG4gICAgICAgIGNvbnN0IHBhc3MgPSBhd2FpdCB0aGlzLmNvbW1hbmQoQnVmZmVyLmZyb20ocGFzc3dvcmQpLnRvU3RyaW5nKCdiYXNlNjQnKSwgdHJ1ZSk7XG4gICAgICAgIHRoaXMuZXhwZWN0KHBhc3MsIFsyMzVdLCAnQVVUSCBMT0dJTiBwYXNzd29yZCcpO1xuICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICAgIGNhc2UgJ2NyYW0tbWQ1Jzoge1xuICAgICAgICBjb25zdCBzdGFydCA9IGF3YWl0IHRoaXMuY29tbWFuZCgnQVVUSCBDUkFNLU1ENScpO1xuICAgICAgICB0aGlzLmV4cGVjdChzdGFydCwgWzMzNF0sICdBVVRIIENSQU0tTUQ1Jyk7XG4gICAgICAgIGNvbnN0IGNoYWxsZW5nZSA9IEJ1ZmZlci5mcm9tKHN0YXJ0LmxpbmVzWzBdLnN1YnN0cmluZyg0KS50cmltKCksICdiYXNlNjQnKS50b1N0cmluZygpO1xuICAgICAgICBjb25zdCBkaWdlc3QgPSBjcmVhdGVIbWFjKCdtZDUnLCBwYXNzd29yZCkudXBkYXRlKGNoYWxsZW5nZSkuZGlnZXN0KCdoZXgnKTtcbiAgICAgICAgY29uc3QgYW5zd2VyID0gQnVmZmVyLmZyb20oYCR7dXNlcm5hbWV9ICR7ZGlnZXN0fWApLnRvU3RyaW5nKCdiYXNlNjQnKTtcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgdGhpcy5jb21tYW5kKGFuc3dlciwgdHJ1ZSk7XG4gICAgICAgIHRoaXMuZXhwZWN0KHJlcywgWzIzNV0sICdBVVRIIENSQU0tTUQ1Jyk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgICAgZGVmYXVsdDpcbiAgICAgICAgYnJlYWs7XG4gICAgfVxuICB9XG5cbiAgLy8g4pSA4pSAIEVudmVsb3BlIGFuZCBib2R5IOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG4gIGFzeW5jIHNlbmQobWVzc2FnZTogTWFpbE1lc3NhZ2UpOiBQcm9taXNlPHsgYWNjZXB0ZWQ6IHN0cmluZ1tdOyByZWplY3RlZDogc3RyaW5nW10gfT4ge1xuICAgIGNvbnN0IGZyb20gPSB0aGlzLnNldHRpbmdzLmZyb21fYWRkcmVzcztcbiAgICBjb25zdCBtYWlsRnJvbSA9IGF3YWl0IHRoaXMuY29tbWFuZChgTUFJTCBGUk9NOjwke2Zyb219PmApO1xuICAgIHRoaXMuZXhwZWN0KG1haWxGcm9tLCBbMjUwXSwgJ01BSUwgRlJPTScpO1xuXG4gICAgY29uc3QgYWNjZXB0ZWQ6IHN0cmluZ1tdID0gW107XG4gICAgY29uc3QgcmVqZWN0ZWQ6IHN0cmluZ1tdID0gW107XG4gICAgZm9yIChjb25zdCByZWNpcGllbnQgb2YgbWVzc2FnZS50bykge1xuICAgICAgY29uc3QgcmNwdCA9IGF3YWl0IHRoaXMuY29tbWFuZChgUkNQVCBUTzo8JHtyZWNpcGllbnR9PmApO1xuICAgICAgaWYgKHJjcHQuY29kZSA9PT0gMjUwIHx8IHJjcHQuY29kZSA9PT0gMjUxKSBhY2NlcHRlZC5wdXNoKHJlY2lwaWVudCk7XG4gICAgICBlbHNlIHJlamVjdGVkLnB1c2gocmVjaXBpZW50KTtcbiAgICB9XG5cbiAgICBpZiAoYWNjZXB0ZWQubGVuZ3RoID09PSAwKSB7XG4gICAgICB0aHJvdyBuZXcgU210cEVycm9yKCdFdmVyeSByZWNpcGllbnQgd2FzIHJlamVjdGVkIGJ5IHRoZSBzZXJ2ZXInKTtcbiAgICB9XG5cbiAgICBjb25zdCBkYXRhID0gYXdhaXQgdGhpcy5jb21tYW5kKCdEQVRBJyk7XG4gICAgdGhpcy5leHBlY3QoZGF0YSwgWzM1NF0sICdEQVRBJyk7XG5cbiAgICBjb25zdCBib2R5ID0gYnVpbGRNaW1lTWVzc2FnZSh0aGlzLnNldHRpbmdzLCBtZXNzYWdlKTtcbiAgICBpZiAoIXRoaXMuc29ja2V0KSB0aHJvdyBuZXcgU210cEVycm9yKCdOb3QgY29ubmVjdGVkJyk7XG4gICAgdGhpcy5zb2NrZXQud3JpdGUoZG90U3R1ZmYoYm9keSkpO1xuICAgIHRoaXMuc29ja2V0LndyaXRlKCdcXHJcXG4uXFxyXFxuJyk7XG4gICAgdGhpcy5sb2coJ0MnLCBgPG1lc3NhZ2UgYm9keSwgJHtib2R5Lmxlbmd0aH0gYnl0ZXM+YCk7XG5cbiAgICBjb25zdCBkb25lID0gYXdhaXQgdGhpcy5yZWFkUmVzcG9uc2UoKTtcbiAgICB0aGlzLmV4cGVjdChkb25lLCBbMjUwXSwgJ01lc3NhZ2UgZGVsaXZlcnknKTtcblxuICAgIHJldHVybiB7IGFjY2VwdGVkLCByZWplY3RlZCB9O1xuICB9XG5cbiAgYXN5bmMgcXVpdCgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICB0cnkge1xuICAgICAgaWYgKHRoaXMuc29ja2V0ICYmICF0aGlzLmNsb3NlZCkge1xuICAgICAgICB0aGlzLmxvZygnQycsICdRVUlUJyk7XG4gICAgICAgIHRoaXMuc29ja2V0LndyaXRlKCdRVUlUXFxyXFxuJyk7XG4gICAgICB9XG4gICAgfSBjYXRjaCAoX2UpIHtcbiAgICAgIC8qIHRoZSBtZXNzYWdlIGlzIGFscmVhZHkgZGVsaXZlcmVkOyBhIGZhaWxlZCBRVUlUIGlzIG5vdCB3b3J0aCByZXBvcnRpbmcgKi9cbiAgICB9IGZpbmFsbHkge1xuICAgICAgdGhpcy5kZXN0cm95KCk7XG4gICAgfVxuICB9XG5cbiAgZGVzdHJveSgpOiB2b2lkIHtcbiAgICB0cnkge1xuICAgICAgdGhpcy5zb2NrZXQ/LmRlc3Ryb3koKTtcbiAgICB9IGNhdGNoIChfZSkge1xuICAgICAgLyogbm90aGluZyB1c2VmdWwgdG8gZG8gKi9cbiAgICB9XG4gICAgdGhpcy5jbG9zZWQgPSB0cnVlO1xuICB9XG59XG5cbi8vIOKUgOKUgCBNZXNzYWdlIGNvbnN0cnVjdGlvbiDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuLyoqXG4gKiBSRkMgMjA0NyBlbmNvZGluZyBmb3IgaGVhZGVyIHZhbHVlcyB0aGF0IGNvbnRhaW4gbm9uLUFTQ0lJIGNoYXJhY3RlcnMsXG4gKiBzbyBhIHN1YmplY3QgbGlrZSBcIkNhc2UgZXNjYWxhdGVkOiBjYWbDqSBzZXJ2ZXJcIiBzdXJ2aXZlcyB0cmFuc3BvcnQuXG4gKi9cbmZ1bmN0aW9uIGVuY29kZUhlYWRlcih2YWx1ZTogc3RyaW5nKTogc3RyaW5nIHtcbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLWNvbnRyb2wtcmVnZXhcbiAgaWYgKC9eW1xceDAwLVxceDdGXSokLy50ZXN0KHZhbHVlKSkgcmV0dXJuIHZhbHVlO1xuICByZXR1cm4gYD0/VVRGLTg/Qj8ke0J1ZmZlci5mcm9tKHZhbHVlLCAndXRmOCcpLnRvU3RyaW5nKCdiYXNlNjQnKX0/PWA7XG59XG5cbi8qKiBCYXNlNjQgd2l0aCB0aGUgNzYtY2hhcmFjdGVyIGxpbmUgd3JhcHBpbmcgdGhhdCBNSU1FIHJlcXVpcmVzLiAqL1xuZnVuY3Rpb24gYmFzZTY0V3JhcHBlZCh2YWx1ZTogc3RyaW5nKTogc3RyaW5nIHtcbiAgY29uc3QgZW5jb2RlZCA9IEJ1ZmZlci5mcm9tKHZhbHVlLCAndXRmOCcpLnRvU3RyaW5nKCdiYXNlNjQnKTtcbiAgcmV0dXJuIChlbmNvZGVkLm1hdGNoKC8uezEsNzZ9L2cpIHx8IFtdKS5qb2luKCdcXHJcXG4nKTtcbn1cblxuLyoqIEEgbGluZSBzdGFydGluZyB3aXRoIFwiLlwiIHdvdWxkIHRlcm1pbmF0ZSBEQVRBIGVhcmx5LCBzbyBpdCBtdXN0IGJlIGRvdWJsZWQuICovXG5mdW5jdGlvbiBkb3RTdHVmZihib2R5OiBzdHJpbmcpOiBzdHJpbmcge1xuICByZXR1cm4gYm9keS5yZXBsYWNlKC9cXHJcXG5cXC4vZywgJ1xcclxcbi4uJyk7XG59XG5cbmZ1bmN0aW9uIGZvcm1hdEFkZHJlc3MoYWRkcmVzczogc3RyaW5nLCBuYW1lOiBzdHJpbmcpOiBzdHJpbmcge1xuICByZXR1cm4gbmFtZSA/IGAke2VuY29kZUhlYWRlcihuYW1lKX0gPCR7YWRkcmVzc30+YCA6IGFkZHJlc3M7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBidWlsZE1pbWVNZXNzYWdlKHNldHRpbmdzOiBTbXRwU2V0dGluZ3MsIG1lc3NhZ2U6IE1haWxNZXNzYWdlKTogc3RyaW5nIHtcbiAgY29uc3QgYm91bmRhcnkgPSBgLS0tLXdhenVoLWNhc2UtJHtyYW5kb21CeXRlcygxMikudG9TdHJpbmcoJ2hleCcpfWA7XG4gIGNvbnN0IG1lc3NhZ2VJZCA9IGA8JHtyYW5kb21CeXRlcygxNikudG9TdHJpbmcoJ2hleCcpfUB3YXp1aC1jYXNlLW1hbmFnZW1lbnQ+YDtcblxuICBjb25zdCBoZWFkZXJzID0gW1xuICAgIGBGcm9tOiAke2Zvcm1hdEFkZHJlc3Moc2V0dGluZ3MuZnJvbV9hZGRyZXNzLCBzZXR0aW5ncy5mcm9tX25hbWUpfWAsXG4gICAgYFRvOiAke21lc3NhZ2UuaGVhZGVyVG8gfHwgbWVzc2FnZS50by5qb2luKCcsICcpfWAsXG4gICAgYFN1YmplY3Q6ICR7ZW5jb2RlSGVhZGVyKG1lc3NhZ2Uuc3ViamVjdCl9YCxcbiAgICBgRGF0ZTogJHtuZXcgRGF0ZSgpLnRvVVRDU3RyaW5nKCl9YCxcbiAgICBgTWVzc2FnZS1JRDogJHttZXNzYWdlSWR9YCxcbiAgICAnTUlNRS1WZXJzaW9uOiAxLjAnLFxuICAgICdYLU1haWxlcjogV2F6dWggQ2FzZSBNYW5hZ2VtZW50JyxcbiAgICAnQXV0by1TdWJtaXR0ZWQ6IGF1dG8tZ2VuZXJhdGVkJyxcbiAgXTtcblxuICBpZiAoIW1lc3NhZ2UuaHRtbCkge1xuICAgIGhlYWRlcnMucHVzaCgnQ29udGVudC1UeXBlOiB0ZXh0L3BsYWluOyBjaGFyc2V0PVVURi04JywgJ0NvbnRlbnQtVHJhbnNmZXItRW5jb2Rpbmc6IGJhc2U2NCcpO1xuICAgIHJldHVybiBgJHtoZWFkZXJzLmpvaW4oJ1xcclxcbicpfVxcclxcblxcclxcbiR7YmFzZTY0V3JhcHBlZChtZXNzYWdlLnRleHQpfWA7XG4gIH1cblxuICBoZWFkZXJzLnB1c2goYENvbnRlbnQtVHlwZTogbXVsdGlwYXJ0L2FsdGVybmF0aXZlOyBib3VuZGFyeT1cIiR7Ym91bmRhcnl9XCJgKTtcblxuICBjb25zdCBwYXJ0cyA9IFtcbiAgICBgLS0ke2JvdW5kYXJ5fWAsXG4gICAgJ0NvbnRlbnQtVHlwZTogdGV4dC9wbGFpbjsgY2hhcnNldD1VVEYtOCcsXG4gICAgJ0NvbnRlbnQtVHJhbnNmZXItRW5jb2Rpbmc6IGJhc2U2NCcsXG4gICAgJycsXG4gICAgYmFzZTY0V3JhcHBlZChtZXNzYWdlLnRleHQpLFxuICAgICcnLFxuICAgIGAtLSR7Ym91bmRhcnl9YCxcbiAgICAnQ29udGVudC1UeXBlOiB0ZXh0L2h0bWw7IGNoYXJzZXQ9VVRGLTgnLFxuICAgICdDb250ZW50LVRyYW5zZmVyLUVuY29kaW5nOiBiYXNlNjQnLFxuICAgICcnLFxuICAgIGJhc2U2NFdyYXBwZWQobWVzc2FnZS5odG1sKSxcbiAgICAnJyxcbiAgICBgLS0ke2JvdW5kYXJ5fS0tYCxcbiAgXTtcblxuICByZXR1cm4gYCR7aGVhZGVycy5qb2luKCdcXHJcXG4nKX1cXHJcXG5cXHJcXG4ke3BhcnRzLmpvaW4oJ1xcclxcbicpfWA7XG59XG5cbi8vIOKUgOKUgCBQdWJsaWMgQVBJIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG5leHBvcnQgY2xhc3MgU210cFNlcnZpY2Uge1xuICAvKipcbiAgICogRGVsaXZlciBvbmUgbWVzc2FnZS4gTmV2ZXIgdGhyb3dzOiB0aGUgb3V0Y29tZSwgaW5jbHVkaW5nIHRoZSByZWRhY3RlZFxuICAgKiBkaWFsb2d1ZSwgY29tZXMgYmFjayBpbiB0aGUgcmVzdWx0IHNvIHRoZSBjYWxsZXIgY2FuIHN1cmZhY2UgaXQuXG4gICAqL1xuICBzdGF0aWMgYXN5bmMgc2VuZChzZXR0aW5nczogU210cFNldHRpbmdzLCBtZXNzYWdlOiBNYWlsTWVzc2FnZSk6IFByb21pc2U8U210cFNlbmRSZXN1bHQ+IHtcbiAgICBjb25zdCBzZXNzaW9uID0gbmV3IFNtdHBTZXNzaW9uKHNldHRpbmdzKTtcblxuICAgIGlmICghc2V0dGluZ3MuaG9zdCkge1xuICAgICAgcmV0dXJuIHsgb2s6IGZhbHNlLCBlcnJvcjogJ05vIFNNVFAgaG9zdCBjb25maWd1cmVkJywgdHJhbnNjcmlwdDogW10sIGFjY2VwdGVkOiBbXSwgcmVqZWN0ZWQ6IFtdIH07XG4gICAgfVxuICAgIGlmICghc2V0dGluZ3MuZnJvbV9hZGRyZXNzKSB7XG4gICAgICByZXR1cm4geyBvazogZmFsc2UsIGVycm9yOiAnTm8gc2VuZGVyIGFkZHJlc3MgY29uZmlndXJlZCcsIHRyYW5zY3JpcHQ6IFtdLCBhY2NlcHRlZDogW10sIHJlamVjdGVkOiBbXSB9O1xuICAgIH1cbiAgICBjb25zdCByZWNpcGllbnRzID0gKG1lc3NhZ2UudG8gfHwgW10pLm1hcCgocikgPT4gci50cmltKCkpLmZpbHRlcihCb29sZWFuKTtcbiAgICBpZiAocmVjaXBpZW50cy5sZW5ndGggPT09IDApIHtcbiAgICAgIHJldHVybiB7IG9rOiBmYWxzZSwgZXJyb3I6ICdObyByZWNpcGllbnRzJywgdHJhbnNjcmlwdDogW10sIGFjY2VwdGVkOiBbXSwgcmVqZWN0ZWQ6IFtdIH07XG4gICAgfVxuXG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IHNlc3Npb24uY29ubmVjdCgpO1xuICAgICAgY29uc3QgY2FwYWJpbGl0aWVzID0gYXdhaXQgc2Vzc2lvbi5oYW5kc2hha2UoKTtcbiAgICAgIGF3YWl0IHNlc3Npb24uYXV0aGVudGljYXRlKGNhcGFiaWxpdGllcyk7XG4gICAgICBjb25zdCB7IGFjY2VwdGVkLCByZWplY3RlZCB9ID0gYXdhaXQgc2Vzc2lvbi5zZW5kKHsgLi4ubWVzc2FnZSwgdG86IHJlY2lwaWVudHMgfSk7XG4gICAgICBhd2FpdCBzZXNzaW9uLnF1aXQoKTtcbiAgICAgIHJldHVybiB7IG9rOiB0cnVlLCB0cmFuc2NyaXB0OiBzZXNzaW9uLnRyYW5zY3JpcHQsIGFjY2VwdGVkLCByZWplY3RlZCB9O1xuICAgIH0gY2F0Y2ggKGU6IGFueSkge1xuICAgICAgc2Vzc2lvbi5kZXN0cm95KCk7XG4gICAgICByZXR1cm4ge1xuICAgICAgICBvazogZmFsc2UsXG4gICAgICAgIGVycm9yOiBlPy5tZXNzYWdlIHx8IFN0cmluZyhlKSxcbiAgICAgICAgdHJhbnNjcmlwdDogc2Vzc2lvbi50cmFuc2NyaXB0LFxuICAgICAgICBhY2NlcHRlZDogW10sXG4gICAgICAgIHJlamVjdGVkOiByZWNpcGllbnRzLFxuICAgICAgfTtcbiAgICB9XG4gIH1cblxuICAvKiogRGVmYXVsdCBwb3J0IGZvciBhIGdpdmVuIHRyYW5zcG9ydCwgdXNlZCB0byBrZWVwIHRoZSBVSSBpbiBzdGVwLiAqL1xuICBzdGF0aWMgZGVmYXVsdFBvcnQoc2VjdXJpdHk6IHN0cmluZyk6IG51bWJlciB7XG4gICAgaWYgKHNlY3VyaXR5ID09PSAndGxzJykgcmV0dXJuIDQ2NTtcbiAgICBpZiAoc2VjdXJpdHkgPT09ICdub25lJykgcmV0dXJuIDI1O1xuICAgIHJldHVybiA1ODc7XG4gIH1cbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQWdCQSxJQUFBQSxJQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxJQUFBLEdBQUFELE9BQUE7QUFDQSxJQUFBRSxPQUFBLEdBQUFGLE9BQUE7QUFFQSxJQUFBRyxVQUFBLEdBQUFILE9BQUE7QUFBaUUsU0FBQUksZ0JBQUFDLENBQUEsRUFBQUMsQ0FBQSxFQUFBQyxDQUFBLFlBQUFELENBQUEsR0FBQUUsY0FBQSxDQUFBRixDQUFBLE1BQUFELENBQUEsR0FBQUksTUFBQSxDQUFBQyxjQUFBLENBQUFMLENBQUEsRUFBQUMsQ0FBQSxJQUFBSyxLQUFBLEVBQUFKLENBQUEsRUFBQUssVUFBQSxNQUFBQyxZQUFBLE1BQUFDLFFBQUEsVUFBQVQsQ0FBQSxDQUFBQyxDQUFBLElBQUFDLENBQUEsRUFBQUYsQ0FBQTtBQUFBLFNBQUFHLGVBQUFELENBQUEsUUFBQVEsQ0FBQSxHQUFBQyxZQUFBLENBQUFULENBQUEsdUNBQUFRLENBQUEsR0FBQUEsQ0FBQSxHQUFBQSxDQUFBO0FBQUEsU0FBQUMsYUFBQVQsQ0FBQSxFQUFBRCxDQUFBLDJCQUFBQyxDQUFBLEtBQUFBLENBQUEsU0FBQUEsQ0FBQSxNQUFBRixDQUFBLEdBQUFFLENBQUEsQ0FBQVUsTUFBQSxDQUFBQyxXQUFBLGtCQUFBYixDQUFBLFFBQUFVLENBQUEsR0FBQVYsQ0FBQSxDQUFBYyxJQUFBLENBQUFaLENBQUEsRUFBQUQsQ0FBQSx1Q0FBQVMsQ0FBQSxTQUFBQSxDQUFBLFlBQUFLLFNBQUEseUVBQUFkLENBQUEsR0FBQWUsTUFBQSxHQUFBQyxNQUFBLEVBQUFmLENBQUEsS0FwQmpFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQTJCQTtBQUNBLE1BQU1nQixTQUFTLFNBQVNDLEtBQUssQ0FBQztFQUM1QkMsV0FBV0EsQ0FBQ0MsT0FBZSxFQUFrQkMsSUFBYSxFQUFFO0lBQzFELEtBQUssQ0FBQ0QsT0FBTyxDQUFDO0lBQUMsS0FENEJDLElBQWEsR0FBYkEsSUFBYTtJQUV4RCxJQUFJLENBQUNDLElBQUksR0FBRyxXQUFXO0VBQ3pCO0FBQ0Y7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU1DLFdBQVcsQ0FBQztFQVNoQkosV0FBV0EsQ0FBa0JLLFFBQXNCLEVBQUU7SUFBQSxLQUF4QkEsUUFBc0IsR0FBdEJBLFFBQXNCO0lBQUExQixlQUFBLGlCQVJQLElBQUk7SUFBQUEsZUFBQSxpQkFDL0IsRUFBRTtJQUFBQSxlQUFBLGtCQUMwQyxJQUFJO0lBQUFBLGVBQUEsdUJBQ1QsSUFBSTtJQUFBQSxlQUFBLGlCQUMzQyxLQUFLO0lBQUFBLGVBQUEscUJBRVUsRUFBRTtFQUVvQjtFQUV0RCxJQUFZMkIsT0FBT0EsQ0FBQSxFQUFXO0lBQzVCLE9BQU8sSUFBSSxDQUFDRCxRQUFRLENBQUNFLFVBQVUsSUFBSUMsa0NBQXVCO0VBQzVEO0VBRVFDLEdBQUdBLENBQUNDLFNBQW9CLEVBQUVDLElBQVksRUFBRUMsTUFBTSxHQUFHLEtBQUssRUFBUTtJQUNwRTtJQUNBLElBQUksSUFBSSxDQUFDQyxVQUFVLENBQUNDLE1BQU0sR0FBRyxFQUFFLEVBQUU7SUFDakMsSUFBSSxDQUFDRCxVQUFVLENBQUNFLElBQUksQ0FBRSxHQUFFTCxTQUFVLEtBQUlFLE1BQU0sR0FBRyxVQUFVLEdBQUdELElBQUssRUFBQyxDQUFDO0VBQ3JFOztFQUVBOztFQUVBLE1BQU1LLE9BQU9BLENBQUEsRUFBa0I7SUFDN0IsTUFBTTtNQUFFQyxJQUFJO01BQUVDLElBQUk7TUFBRUMsUUFBUTtNQUFFQztJQUFvQixDQUFDLEdBQUcsSUFBSSxDQUFDZixRQUFRO0lBRW5FLE1BQU0sSUFBSWdCLE9BQU8sQ0FBTyxDQUFDQyxPQUFPLEVBQUVDLE1BQU0sS0FBSztNQUMzQyxNQUFNQyxPQUFPLEdBQUlDLEdBQVUsSUFBS0YsTUFBTSxDQUFDLElBQUl6QixTQUFTLENBQUUsc0JBQXFCMkIsR0FBRyxDQUFDeEIsT0FBUSxFQUFDLENBQUMsQ0FBQztNQUUxRixJQUFJa0IsUUFBUSxLQUFLLEtBQUssRUFBRTtRQUN0QixNQUFNTyxNQUFNLEdBQUcsSUFBQUMsWUFBVSxFQUN2QjtVQUFFVixJQUFJO1VBQUVDLElBQUk7VUFBRVUsa0JBQWtCLEVBQUVSLG1CQUFtQixLQUFLLEtBQUs7VUFBRVMsVUFBVSxFQUFFWjtRQUFLLENBQUMsRUFDbkYsTUFBTTtVQUNKUyxNQUFNLENBQUNJLGNBQWMsQ0FBQyxPQUFPLEVBQUVOLE9BQU8sQ0FBQztVQUN2QyxJQUFJLENBQUNPLE1BQU0sQ0FBQ0wsTUFBTSxDQUFDO1VBQ25CSixPQUFPLENBQUMsQ0FBQztRQUNYLENBQ0YsQ0FBQztRQUNESSxNQUFNLENBQUNNLElBQUksQ0FBQyxPQUFPLEVBQUVSLE9BQU8sQ0FBQztRQUM3QkUsTUFBTSxDQUFDTyxVQUFVLENBQUMsSUFBSSxDQUFDM0IsT0FBTyxDQUFDO01BQ2pDLENBQUMsTUFBTTtRQUNMLE1BQU1vQixNQUFNLEdBQUcsSUFBQVEsWUFBVSxFQUFDO1VBQUVqQixJQUFJO1VBQUVDO1FBQUssQ0FBQyxFQUFFLE1BQU07VUFDOUNRLE1BQU0sQ0FBQ0ksY0FBYyxDQUFDLE9BQU8sRUFBRU4sT0FBTyxDQUFDO1VBQ3ZDLElBQUksQ0FBQ08sTUFBTSxDQUFDTCxNQUFNLENBQUM7VUFDbkJKLE9BQU8sQ0FBQyxDQUFDO1FBQ1gsQ0FBQyxDQUFDO1FBQ0ZJLE1BQU0sQ0FBQ00sSUFBSSxDQUFDLE9BQU8sRUFBRVIsT0FBTyxDQUFDO1FBQzdCRSxNQUFNLENBQUNPLFVBQVUsQ0FBQyxJQUFJLENBQUMzQixPQUFPLENBQUM7TUFDakM7SUFDRixDQUFDLENBQUM7SUFFRixNQUFNNkIsUUFBUSxHQUFHLE1BQU0sSUFBSSxDQUFDQyxZQUFZLENBQUMsQ0FBQztJQUMxQyxJQUFJRCxRQUFRLENBQUNqQyxJQUFJLEtBQUssR0FBRyxFQUFFO01BQ3pCLE1BQU0sSUFBSUosU0FBUyxDQUFFLHdCQUF1QnFDLFFBQVEsQ0FBQ0UsR0FBSSxFQUFDLEVBQUVGLFFBQVEsQ0FBQ2pDLElBQUksQ0FBQztJQUM1RTtFQUNGO0VBRVE2QixNQUFNQSxDQUFDTCxNQUEwQixFQUFRO0lBQy9DLElBQUksQ0FBQ0EsTUFBTSxHQUFHQSxNQUFNO0lBQ3BCQSxNQUFNLENBQUNZLFdBQVcsQ0FBQyxNQUFNLENBQUM7SUFDMUJaLE1BQU0sQ0FBQ2EsRUFBRSxDQUFDLE1BQU0sRUFBR0MsS0FBYSxJQUFLLElBQUksQ0FBQ0MsTUFBTSxDQUFDRCxLQUFLLENBQUMsQ0FBQztJQUN4RGQsTUFBTSxDQUFDYSxFQUFFLENBQUMsT0FBTyxFQUFHZCxHQUFVLElBQUssSUFBSSxDQUFDaUIsV0FBVyxDQUFDakIsR0FBRyxDQUFDLENBQUM7SUFDekRDLE1BQU0sQ0FBQ2EsRUFBRSxDQUFDLFNBQVMsRUFBRSxNQUFNLElBQUksQ0FBQ0csV0FBVyxDQUFDLElBQUk1QyxTQUFTLENBQUMsa0NBQWtDLENBQUMsQ0FBQyxDQUFDO0lBQy9GNEIsTUFBTSxDQUFDYSxFQUFFLENBQUMsT0FBTyxFQUFFLE1BQU07TUFDdkIsSUFBSSxDQUFDSSxNQUFNLEdBQUcsSUFBSTtNQUNsQixJQUFJLENBQUNELFdBQVcsQ0FBQyxJQUFJNUMsU0FBUyxDQUFDLDhCQUE4QixDQUFDLENBQUM7SUFDakUsQ0FBQyxDQUFDO0VBQ0o7RUFFUTRDLFdBQVdBLENBQUNqQixHQUFVLEVBQVE7SUFDcEMsTUFBTUYsTUFBTSxHQUFHLElBQUksQ0FBQ3FCLFlBQVk7SUFDaEMsSUFBSSxDQUFDQyxPQUFPLEdBQUcsSUFBSTtJQUNuQixJQUFJLENBQUNELFlBQVksR0FBRyxJQUFJO0lBQ3hCLElBQUlyQixNQUFNLEVBQUVBLE1BQU0sQ0FBQ0UsR0FBRyxDQUFDO0VBQ3pCO0VBRVFnQixNQUFNQSxDQUFDRCxLQUFhLEVBQVE7SUFDbEMsSUFBSSxDQUFDTSxNQUFNLElBQUlOLEtBQUs7O0lBRXBCO0lBQ0E7SUFDQSxNQUFNTyxLQUFLLEdBQUcsSUFBSSxDQUFDRCxNQUFNLENBQUNFLEtBQUssQ0FBQyxNQUFNLENBQUM7SUFDdkMsS0FBSyxJQUFJMUQsQ0FBQyxHQUFHLENBQUMsRUFBRUEsQ0FBQyxHQUFHeUQsS0FBSyxDQUFDakMsTUFBTSxHQUFHLENBQUMsRUFBRXhCLENBQUMsRUFBRSxFQUFFO01BQ3pDLE1BQU0yRCxJQUFJLEdBQUdGLEtBQUssQ0FBQ3pELENBQUMsQ0FBQztNQUNyQixJQUFJLFNBQVMsQ0FBQzRELElBQUksQ0FBQ0QsSUFBSSxDQUFDLEVBQUU7UUFDeEIsTUFBTUUsUUFBUSxHQUFHSixLQUFLLENBQUNLLEtBQUssQ0FBQyxDQUFDLEVBQUU5RCxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ3RDLElBQUksQ0FBQ3dELE1BQU0sR0FBR0MsS0FBSyxDQUFDSyxLQUFLLENBQUM5RCxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMrRCxJQUFJLENBQUMsTUFBTSxDQUFDO1FBQzdDLE1BQU1oQixHQUFHLEdBQUdjLFFBQVEsQ0FBQ0UsSUFBSSxDQUFDLElBQUksQ0FBQztRQUMvQixNQUFNQyxRQUFzQixHQUFHO1VBQzdCcEQsSUFBSSxFQUFFcUQsUUFBUSxDQUFDTixJQUFJLENBQUNPLFNBQVMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDO1VBQ3hDVCxLQUFLLEVBQUVJLFFBQVE7VUFDZmQ7UUFDRixDQUFDO1FBQ0QsSUFBSSxDQUFDNUIsR0FBRyxDQUFDLEdBQUcsRUFBRTRCLEdBQUcsQ0FBQztRQUNsQixNQUFNZixPQUFPLEdBQUcsSUFBSSxDQUFDdUIsT0FBTztRQUM1QixJQUFJLENBQUNBLE9BQU8sR0FBRyxJQUFJO1FBQ25CLElBQUksQ0FBQ0QsWUFBWSxHQUFHLElBQUk7UUFDeEIsSUFBSXRCLE9BQU8sRUFBRUEsT0FBTyxDQUFDZ0MsUUFBUSxDQUFDO1FBQzlCO01BQ0Y7SUFDRjtFQUNGO0VBRVFsQixZQUFZQSxDQUFBLEVBQTBCO0lBQzVDLElBQUksSUFBSSxDQUFDTyxNQUFNLEVBQUUsT0FBT3RCLE9BQU8sQ0FBQ0UsTUFBTSxDQUFDLElBQUl6QixTQUFTLENBQUMsc0JBQXNCLENBQUMsQ0FBQztJQUM3RSxPQUFPLElBQUl1QixPQUFPLENBQUMsQ0FBQ0MsT0FBTyxFQUFFQyxNQUFNLEtBQUs7TUFDdEMsSUFBSSxDQUFDc0IsT0FBTyxHQUFHdkIsT0FBTztNQUN0QixJQUFJLENBQUNzQixZQUFZLEdBQUdyQixNQUFNO0lBQzVCLENBQUMsQ0FBQztFQUNKOztFQUVBO0VBQ0EsTUFBY2tDLE9BQU9BLENBQUM5QyxJQUFZLEVBQUVDLE1BQU0sR0FBRyxLQUFLLEVBQXlCO0lBQ3pFLElBQUksQ0FBQyxJQUFJLENBQUNjLE1BQU0sRUFBRSxNQUFNLElBQUk1QixTQUFTLENBQUMsZUFBZSxDQUFDO0lBQ3RELElBQUksQ0FBQ1csR0FBRyxDQUFDLEdBQUcsRUFBRUUsSUFBSSxFQUFFQyxNQUFNLENBQUM7SUFDM0IsSUFBSSxDQUFDYyxNQUFNLENBQUNnQyxLQUFLLENBQUUsR0FBRS9DLElBQUssTUFBSyxDQUFDO0lBQ2hDLE9BQU8sSUFBSSxDQUFDeUIsWUFBWSxDQUFDLENBQUM7RUFDNUI7RUFFUXVCLE1BQU1BLENBQUNMLFFBQXNCLEVBQUVNLEtBQWUsRUFBRUMsS0FBYSxFQUFRO0lBQzNFLElBQUksQ0FBQ0QsS0FBSyxDQUFDRSxRQUFRLENBQUNSLFFBQVEsQ0FBQ3BELElBQUksQ0FBQyxFQUFFO01BQ2xDLE1BQU0sSUFBSUosU0FBUyxDQUFFLEdBQUUrRCxLQUFNLFlBQVdQLFFBQVEsQ0FBQ2pCLEdBQUksRUFBQyxFQUFFaUIsUUFBUSxDQUFDcEQsSUFBSSxDQUFDO0lBQ3hFO0VBQ0Y7O0VBRUE7O0VBRUE7RUFDQSxNQUFNNkQsU0FBU0EsQ0FBQSxFQUFzQjtJQUNuQyxNQUFNQyxVQUFVLEdBQUcsdUJBQXVCO0lBQzFDLElBQUlDLElBQUksR0FBRyxNQUFNLElBQUksQ0FBQ1IsT0FBTyxDQUFFLFFBQU9PLFVBQVcsRUFBQyxDQUFDO0lBRW5ELElBQUlDLElBQUksQ0FBQy9ELElBQUksS0FBSyxHQUFHLEVBQUU7TUFDckI7TUFDQSxNQUFNZ0UsSUFBSSxHQUFHLE1BQU0sSUFBSSxDQUFDVCxPQUFPLENBQUUsUUFBT08sVUFBVyxFQUFDLENBQUM7TUFDckQsSUFBSSxDQUFDTCxNQUFNLENBQUNPLElBQUksRUFBRSxDQUFDLEdBQUcsQ0FBQyxFQUFFLE1BQU0sQ0FBQztNQUNoQyxPQUFPLEVBQUU7SUFDWDtJQUVBLElBQUlDLFlBQVksR0FBRy9ELFdBQVcsQ0FBQ2dFLGlCQUFpQixDQUFDSCxJQUFJLENBQUM7SUFFdEQsSUFBSSxJQUFJLENBQUM1RCxRQUFRLENBQUNjLFFBQVEsS0FBSyxVQUFVLEVBQUU7TUFDekMsSUFBSSxDQUFDZ0QsWUFBWSxDQUFDRSxJQUFJLENBQUVDLENBQUMsSUFBS0EsQ0FBQyxDQUFDQyxVQUFVLENBQUMsVUFBVSxDQUFDLENBQUMsRUFBRTtRQUN2RCxNQUFNLElBQUl6RSxTQUFTLENBQUMsd0NBQXdDLENBQUM7TUFDL0Q7TUFDQSxNQUFNMEUsS0FBSyxHQUFHLE1BQU0sSUFBSSxDQUFDZixPQUFPLENBQUMsVUFBVSxDQUFDO01BQzVDLElBQUksQ0FBQ0UsTUFBTSxDQUFDYSxLQUFLLEVBQUUsQ0FBQyxHQUFHLENBQUMsRUFBRSxVQUFVLENBQUM7TUFDckMsTUFBTSxJQUFJLENBQUNDLFlBQVksQ0FBQyxDQUFDO01BQ3pCO01BQ0E7TUFDQVIsSUFBSSxHQUFHLE1BQU0sSUFBSSxDQUFDUixPQUFPLENBQUUsUUFBT08sVUFBVyxFQUFDLENBQUM7TUFDL0MsSUFBSSxDQUFDTCxNQUFNLENBQUNNLElBQUksRUFBRSxDQUFDLEdBQUcsQ0FBQyxFQUFFLHFCQUFxQixDQUFDO01BQy9DRSxZQUFZLEdBQUcvRCxXQUFXLENBQUNnRSxpQkFBaUIsQ0FBQ0gsSUFBSSxDQUFDO0lBQ3BEO0lBRUEsT0FBT0UsWUFBWTtFQUNyQjtFQUVBLE9BQWVDLGlCQUFpQkEsQ0FBQ2QsUUFBc0IsRUFBWTtJQUNqRSxPQUFPQSxRQUFRLENBQUNQLEtBQUssQ0FDbEIyQixHQUFHLENBQUV6QixJQUFJLElBQUtBLElBQUksQ0FBQ08sU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDbUIsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUN2Q0MsTUFBTSxDQUFFM0IsSUFBSSxJQUFLQSxJQUFJLENBQUNuQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO0VBQ3RDO0VBRUEsTUFBYzJELFlBQVlBLENBQUEsRUFBa0I7SUFDMUMsTUFBTUksS0FBSyxHQUFHLElBQUksQ0FBQ25ELE1BQWdCO0lBQ25DLElBQUksQ0FBQ21ELEtBQUssRUFBRSxNQUFNLElBQUkvRSxTQUFTLENBQUMsZUFBZSxDQUFDOztJQUVoRDtJQUNBK0UsS0FBSyxDQUFDQyxrQkFBa0IsQ0FBQyxNQUFNLENBQUM7SUFDaENELEtBQUssQ0FBQ0Msa0JBQWtCLENBQUMsT0FBTyxDQUFDO0lBQ2pDRCxLQUFLLENBQUNDLGtCQUFrQixDQUFDLE9BQU8sQ0FBQztJQUNqQ0QsS0FBSyxDQUFDQyxrQkFBa0IsQ0FBQyxTQUFTLENBQUM7SUFDbkMsSUFBSSxDQUFDaEMsTUFBTSxHQUFHLEVBQUU7SUFFaEIsTUFBTWlDLE1BQU0sR0FBRyxNQUFNLElBQUkxRCxPQUFPLENBQVksQ0FBQ0MsT0FBTyxFQUFFQyxNQUFNLEtBQUs7TUFDL0QsSUFBSXlELFFBQW1CO01BQ3ZCQSxRQUFRLEdBQUcsSUFBQXJELFlBQVUsRUFDbkI7UUFDRUQsTUFBTSxFQUFFbUQsS0FBSztRQUNiaEQsVUFBVSxFQUFFLElBQUksQ0FBQ3hCLFFBQVEsQ0FBQ1ksSUFBSTtRQUM5Qlcsa0JBQWtCLEVBQUUsSUFBSSxDQUFDdkIsUUFBUSxDQUFDZSxtQkFBbUIsS0FBSztNQUM1RCxDQUFDLEVBQ0QsTUFBTUUsT0FBTyxDQUFDMEQsUUFBUSxDQUN4QixDQUFDO01BQ0RBLFFBQVEsQ0FBQ2hELElBQUksQ0FBQyxPQUFPLEVBQUdQLEdBQVUsSUFDaENGLE1BQU0sQ0FBQyxJQUFJekIsU0FBUyxDQUFFLHVCQUFzQjJCLEdBQUcsQ0FBQ3hCLE9BQVEsRUFBQyxDQUFDLENBQzVELENBQUM7SUFDSCxDQUFDLENBQUM7SUFFRjhFLE1BQU0sQ0FBQzlDLFVBQVUsQ0FBQyxJQUFJLENBQUMzQixPQUFPLENBQUM7SUFDL0IsSUFBSSxDQUFDeUIsTUFBTSxDQUFDZ0QsTUFBTSxDQUFDO0lBQ25CLElBQUksQ0FBQ3RFLEdBQUcsQ0FBQyxHQUFHLEVBQUUsa0JBQWtCLENBQUM7RUFDbkM7O0VBRUE7O0VBRUEsTUFBTXdFLFlBQVlBLENBQUNkLFlBQXNCLEVBQWlCO0lBQ3hELE1BQU07TUFBRWUsU0FBUztNQUFFQyxRQUFRO01BQUVDO0lBQVMsQ0FBQyxHQUFHLElBQUksQ0FBQy9FLFFBQVE7SUFDdkQsSUFBSTZFLFNBQVMsS0FBSyxNQUFNLEVBQUU7SUFDMUIsSUFBSSxDQUFDQyxRQUFRLElBQUlELFNBQVMsS0FBSyxNQUFNLEVBQUU7SUFFdkMsTUFBTUcsVUFBVSxHQUFHLENBQUNsQixZQUFZLENBQUNtQixJQUFJLENBQUVoQixDQUFDLElBQUtBLENBQUMsQ0FBQ0MsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksRUFBRSxFQUNyRWYsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUNabUIsSUFBSSxDQUFDLENBQUMsQ0FDTlksV0FBVyxDQUFDLENBQUMsQ0FDYnZDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FDWjRCLE1BQU0sQ0FBQ1ksT0FBTyxDQUFDO0lBRWxCLElBQUlDLFNBQVMsR0FBR1AsU0FBUztJQUN6QixJQUFJTyxTQUFTLEtBQUssTUFBTSxFQUFFO01BQ3hCLElBQUlKLFVBQVUsQ0FBQ3ZCLFFBQVEsQ0FBQyxPQUFPLENBQUMsRUFBRTJCLFNBQVMsR0FBRyxPQUFPLENBQUMsS0FDakQsSUFBSUosVUFBVSxDQUFDdkIsUUFBUSxDQUFDLE9BQU8sQ0FBQyxFQUFFMkIsU0FBUyxHQUFHLE9BQU8sQ0FBQyxLQUN0RCxJQUFJSixVQUFVLENBQUN2QixRQUFRLENBQUMsVUFBVSxDQUFDLEVBQUUyQixTQUFTLEdBQUcsVUFBVSxDQUFDLEtBQzVELElBQUlKLFVBQVUsQ0FBQ3ZFLE1BQU0sS0FBSyxDQUFDLEVBQUUyRSxTQUFTLEdBQUcsT0FBTyxDQUFDLEtBQ2pEO1FBQ0gsTUFBTSxJQUFJM0YsU0FBUyxDQUNoQix3RUFBdUV1RixVQUFVLENBQUNoQyxJQUFJLENBQUMsSUFBSSxDQUFFLEdBQ2hHLENBQUM7TUFDSDtJQUNGO0lBRUEsUUFBUW9DLFNBQVM7TUFDZixLQUFLLE9BQU87UUFBRTtVQUNaLE1BQU1DLEtBQUssR0FBR0MsTUFBTSxDQUFDQyxJQUFJLENBQUUsS0FBSVQsUUFBUyxLQUFJQyxRQUFTLEVBQUMsQ0FBQyxDQUFDUyxRQUFRLENBQUMsUUFBUSxDQUFDO1VBQzFFLE1BQU1DLEdBQUcsR0FBRyxNQUFNLElBQUksQ0FBQ3JDLE9BQU8sQ0FBRSxjQUFhaUMsS0FBTSxFQUFDLEVBQUUsSUFBSSxDQUFDO1VBQzNELElBQUksQ0FBQy9CLE1BQU0sQ0FBQ21DLEdBQUcsRUFBRSxDQUFDLEdBQUcsQ0FBQyxFQUFFLFlBQVksQ0FBQztVQUNyQztRQUNGO01BQ0EsS0FBSyxPQUFPO1FBQUU7VUFDWixNQUFNdEIsS0FBSyxHQUFHLE1BQU0sSUFBSSxDQUFDZixPQUFPLENBQUMsWUFBWSxDQUFDO1VBQzlDLElBQUksQ0FBQ0UsTUFBTSxDQUFDYSxLQUFLLEVBQUUsQ0FBQyxHQUFHLENBQUMsRUFBRSxZQUFZLENBQUM7VUFDdkMsTUFBTXVCLElBQUksR0FBRyxNQUFNLElBQUksQ0FBQ3RDLE9BQU8sQ0FBQ2tDLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDVCxRQUFRLENBQUMsQ0FBQ1UsUUFBUSxDQUFDLFFBQVEsQ0FBQyxFQUFFLElBQUksQ0FBQztVQUMvRSxJQUFJLENBQUNsQyxNQUFNLENBQUNvQyxJQUFJLEVBQUUsQ0FBQyxHQUFHLENBQUMsRUFBRSxxQkFBcUIsQ0FBQztVQUMvQyxNQUFNQyxJQUFJLEdBQUcsTUFBTSxJQUFJLENBQUN2QyxPQUFPLENBQUNrQyxNQUFNLENBQUNDLElBQUksQ0FBQ1IsUUFBUSxDQUFDLENBQUNTLFFBQVEsQ0FBQyxRQUFRLENBQUMsRUFBRSxJQUFJLENBQUM7VUFDL0UsSUFBSSxDQUFDbEMsTUFBTSxDQUFDcUMsSUFBSSxFQUFFLENBQUMsR0FBRyxDQUFDLEVBQUUscUJBQXFCLENBQUM7VUFDL0M7UUFDRjtNQUNBLEtBQUssVUFBVTtRQUFFO1VBQ2YsTUFBTXhCLEtBQUssR0FBRyxNQUFNLElBQUksQ0FBQ2YsT0FBTyxDQUFDLGVBQWUsQ0FBQztVQUNqRCxJQUFJLENBQUNFLE1BQU0sQ0FBQ2EsS0FBSyxFQUFFLENBQUMsR0FBRyxDQUFDLEVBQUUsZUFBZSxDQUFDO1VBQzFDLE1BQU15QixTQUFTLEdBQUdOLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDcEIsS0FBSyxDQUFDekIsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDUyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUNtQixJQUFJLENBQUMsQ0FBQyxFQUFFLFFBQVEsQ0FBQyxDQUFDa0IsUUFBUSxDQUFDLENBQUM7VUFDdEYsTUFBTUssTUFBTSxHQUFHLElBQUFDLGtCQUFVLEVBQUMsS0FBSyxFQUFFZixRQUFRLENBQUMsQ0FBQ2dCLE1BQU0sQ0FBQ0gsU0FBUyxDQUFDLENBQUNDLE1BQU0sQ0FBQyxLQUFLLENBQUM7VUFDMUUsTUFBTUcsTUFBTSxHQUFHVixNQUFNLENBQUNDLElBQUksQ0FBRSxHQUFFVCxRQUFTLElBQUdlLE1BQU8sRUFBQyxDQUFDLENBQUNMLFFBQVEsQ0FBQyxRQUFRLENBQUM7VUFDdEUsTUFBTUMsR0FBRyxHQUFHLE1BQU0sSUFBSSxDQUFDckMsT0FBTyxDQUFDNEMsTUFBTSxFQUFFLElBQUksQ0FBQztVQUM1QyxJQUFJLENBQUMxQyxNQUFNLENBQUNtQyxHQUFHLEVBQUUsQ0FBQyxHQUFHLENBQUMsRUFBRSxlQUFlLENBQUM7VUFDeEM7UUFDRjtNQUNBO1FBQ0U7SUFDSjtFQUNGOztFQUVBOztFQUVBLE1BQU1RLElBQUlBLENBQUNyRyxPQUFvQixFQUF1RDtJQUNwRixNQUFNMkYsSUFBSSxHQUFHLElBQUksQ0FBQ3ZGLFFBQVEsQ0FBQ2tHLFlBQVk7SUFDdkMsTUFBTUMsUUFBUSxHQUFHLE1BQU0sSUFBSSxDQUFDL0MsT0FBTyxDQUFFLGNBQWFtQyxJQUFLLEdBQUUsQ0FBQztJQUMxRCxJQUFJLENBQUNqQyxNQUFNLENBQUM2QyxRQUFRLEVBQUUsQ0FBQyxHQUFHLENBQUMsRUFBRSxXQUFXLENBQUM7SUFFekMsTUFBTUMsUUFBa0IsR0FBRyxFQUFFO0lBQzdCLE1BQU1DLFFBQWtCLEdBQUcsRUFBRTtJQUM3QixLQUFLLE1BQU1DLFNBQVMsSUFBSTFHLE9BQU8sQ0FBQzJHLEVBQUUsRUFBRTtNQUNsQyxNQUFNQyxJQUFJLEdBQUcsTUFBTSxJQUFJLENBQUNwRCxPQUFPLENBQUUsWUFBV2tELFNBQVUsR0FBRSxDQUFDO01BQ3pELElBQUlFLElBQUksQ0FBQzNHLElBQUksS0FBSyxHQUFHLElBQUkyRyxJQUFJLENBQUMzRyxJQUFJLEtBQUssR0FBRyxFQUFFdUcsUUFBUSxDQUFDMUYsSUFBSSxDQUFDNEYsU0FBUyxDQUFDLENBQUMsS0FDaEVELFFBQVEsQ0FBQzNGLElBQUksQ0FBQzRGLFNBQVMsQ0FBQztJQUMvQjtJQUVBLElBQUlGLFFBQVEsQ0FBQzNGLE1BQU0sS0FBSyxDQUFDLEVBQUU7TUFDekIsTUFBTSxJQUFJaEIsU0FBUyxDQUFDLDRDQUE0QyxDQUFDO0lBQ25FO0lBRUEsTUFBTWdILElBQUksR0FBRyxNQUFNLElBQUksQ0FBQ3JELE9BQU8sQ0FBQyxNQUFNLENBQUM7SUFDdkMsSUFBSSxDQUFDRSxNQUFNLENBQUNtRCxJQUFJLEVBQUUsQ0FBQyxHQUFHLENBQUMsRUFBRSxNQUFNLENBQUM7SUFFaEMsTUFBTUMsSUFBSSxHQUFHQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMzRyxRQUFRLEVBQUVKLE9BQU8sQ0FBQztJQUNyRCxJQUFJLENBQUMsSUFBSSxDQUFDeUIsTUFBTSxFQUFFLE1BQU0sSUFBSTVCLFNBQVMsQ0FBQyxlQUFlLENBQUM7SUFDdEQsSUFBSSxDQUFDNEIsTUFBTSxDQUFDZ0MsS0FBSyxDQUFDdUQsUUFBUSxDQUFDRixJQUFJLENBQUMsQ0FBQztJQUNqQyxJQUFJLENBQUNyRixNQUFNLENBQUNnQyxLQUFLLENBQUMsV0FBVyxDQUFDO0lBQzlCLElBQUksQ0FBQ2pELEdBQUcsQ0FBQyxHQUFHLEVBQUcsa0JBQWlCc0csSUFBSSxDQUFDakcsTUFBTyxTQUFRLENBQUM7SUFFckQsTUFBTW9HLElBQUksR0FBRyxNQUFNLElBQUksQ0FBQzlFLFlBQVksQ0FBQyxDQUFDO0lBQ3RDLElBQUksQ0FBQ3VCLE1BQU0sQ0FBQ3VELElBQUksRUFBRSxDQUFDLEdBQUcsQ0FBQyxFQUFFLGtCQUFrQixDQUFDO0lBRTVDLE9BQU87TUFBRVQsUUFBUTtNQUFFQztJQUFTLENBQUM7RUFDL0I7RUFFQSxNQUFNUyxJQUFJQSxDQUFBLEVBQWtCO0lBQzFCLElBQUk7TUFDRixJQUFJLElBQUksQ0FBQ3pGLE1BQU0sSUFBSSxDQUFDLElBQUksQ0FBQ2lCLE1BQU0sRUFBRTtRQUMvQixJQUFJLENBQUNsQyxHQUFHLENBQUMsR0FBRyxFQUFFLE1BQU0sQ0FBQztRQUNyQixJQUFJLENBQUNpQixNQUFNLENBQUNnQyxLQUFLLENBQUMsVUFBVSxDQUFDO01BQy9CO0lBQ0YsQ0FBQyxDQUFDLE9BQU8wRCxFQUFFLEVBQUU7TUFDWDtJQUFBLENBQ0QsU0FBUztNQUNSLElBQUksQ0FBQ0MsT0FBTyxDQUFDLENBQUM7SUFDaEI7RUFDRjtFQUVBQSxPQUFPQSxDQUFBLEVBQVM7SUFDZCxJQUFJO01BQUEsSUFBQUMsWUFBQTtNQUNGLENBQUFBLFlBQUEsT0FBSSxDQUFDNUYsTUFBTSxjQUFBNEYsWUFBQSxlQUFYQSxZQUFBLENBQWFELE9BQU8sQ0FBQyxDQUFDO0lBQ3hCLENBQUMsQ0FBQyxPQUFPRCxFQUFFLEVBQUU7TUFDWDtJQUFBO0lBRUYsSUFBSSxDQUFDekUsTUFBTSxHQUFHLElBQUk7RUFDcEI7QUFDRjs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVM0RSxZQUFZQSxDQUFDckksS0FBYSxFQUFVO0VBQzNDO0VBQ0EsSUFBSSxnQkFBZ0IsQ0FBQ2dFLElBQUksQ0FBQ2hFLEtBQUssQ0FBQyxFQUFFLE9BQU9BLEtBQUs7RUFDOUMsT0FBUSxhQUFZeUcsTUFBTSxDQUFDQyxJQUFJLENBQUMxRyxLQUFLLEVBQUUsTUFBTSxDQUFDLENBQUMyRyxRQUFRLENBQUMsUUFBUSxDQUFFLElBQUc7QUFDdkU7O0FBRUE7QUFDQSxTQUFTMkIsYUFBYUEsQ0FBQ3RJLEtBQWEsRUFBVTtFQUM1QyxNQUFNdUksT0FBTyxHQUFHOUIsTUFBTSxDQUFDQyxJQUFJLENBQUMxRyxLQUFLLEVBQUUsTUFBTSxDQUFDLENBQUMyRyxRQUFRLENBQUMsUUFBUSxDQUFDO0VBQzdELE9BQU8sQ0FBQzRCLE9BQU8sQ0FBQ0MsS0FBSyxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsRUFBRXJFLElBQUksQ0FBQyxNQUFNLENBQUM7QUFDdkQ7O0FBRUE7QUFDQSxTQUFTNEQsUUFBUUEsQ0FBQ0YsSUFBWSxFQUFVO0VBQ3RDLE9BQU9BLElBQUksQ0FBQ1ksT0FBTyxDQUFDLFNBQVMsRUFBRSxRQUFRLENBQUM7QUFDMUM7QUFFQSxTQUFTQyxhQUFhQSxDQUFDQyxPQUFlLEVBQUUxSCxJQUFZLEVBQVU7RUFDNUQsT0FBT0EsSUFBSSxHQUFJLEdBQUVvSCxZQUFZLENBQUNwSCxJQUFJLENBQUUsS0FBSTBILE9BQVEsR0FBRSxHQUFHQSxPQUFPO0FBQzlEO0FBRU8sU0FBU2IsZ0JBQWdCQSxDQUFDM0csUUFBc0IsRUFBRUosT0FBb0IsRUFBVTtFQUNyRixNQUFNNkgsUUFBUSxHQUFJLGtCQUFpQixJQUFBQyxtQkFBVyxFQUFDLEVBQUUsQ0FBQyxDQUFDbEMsUUFBUSxDQUFDLEtBQUssQ0FBRSxFQUFDO0VBQ3BFLE1BQU1tQyxTQUFTLEdBQUksSUFBRyxJQUFBRCxtQkFBVyxFQUFDLEVBQUUsQ0FBQyxDQUFDbEMsUUFBUSxDQUFDLEtBQUssQ0FBRSx5QkFBd0I7RUFFOUUsTUFBTW9DLE9BQU8sR0FBRyxDQUNiLFNBQVFMLGFBQWEsQ0FBQ3ZILFFBQVEsQ0FBQ2tHLFlBQVksRUFBRWxHLFFBQVEsQ0FBQzZILFNBQVMsQ0FBRSxFQUFDLEVBQ2xFLE9BQU1qSSxPQUFPLENBQUNrSSxRQUFRLElBQUlsSSxPQUFPLENBQUMyRyxFQUFFLENBQUN2RCxJQUFJLENBQUMsSUFBSSxDQUFFLEVBQUMsRUFDakQsWUFBV2tFLFlBQVksQ0FBQ3RILE9BQU8sQ0FBQ21JLE9BQU8sQ0FBRSxFQUFDLEVBQzFDLFNBQVEsSUFBSUMsSUFBSSxDQUFDLENBQUMsQ0FBQ0MsV0FBVyxDQUFDLENBQUUsRUFBQyxFQUNsQyxlQUFjTixTQUFVLEVBQUMsRUFDMUIsbUJBQW1CLEVBQ25CLGlDQUFpQyxFQUNqQyxnQ0FBZ0MsQ0FDakM7RUFFRCxJQUFJLENBQUMvSCxPQUFPLENBQUNzSSxJQUFJLEVBQUU7SUFDakJOLE9BQU8sQ0FBQ2xILElBQUksQ0FBQyx5Q0FBeUMsRUFBRSxtQ0FBbUMsQ0FBQztJQUM1RixPQUFRLEdBQUVrSCxPQUFPLENBQUM1RSxJQUFJLENBQUMsTUFBTSxDQUFFLFdBQVVtRSxhQUFhLENBQUN2SCxPQUFPLENBQUNVLElBQUksQ0FBRSxFQUFDO0VBQ3hFO0VBRUFzSCxPQUFPLENBQUNsSCxJQUFJLENBQUUsa0RBQWlEK0csUUFBUyxHQUFFLENBQUM7RUFFM0UsTUFBTVUsS0FBSyxHQUFHLENBQ1gsS0FBSVYsUUFBUyxFQUFDLEVBQ2YseUNBQXlDLEVBQ3pDLG1DQUFtQyxFQUNuQyxFQUFFLEVBQ0ZOLGFBQWEsQ0FBQ3ZILE9BQU8sQ0FBQ1UsSUFBSSxDQUFDLEVBQzNCLEVBQUUsRUFDRCxLQUFJbUgsUUFBUyxFQUFDLEVBQ2Ysd0NBQXdDLEVBQ3hDLG1DQUFtQyxFQUNuQyxFQUFFLEVBQ0ZOLGFBQWEsQ0FBQ3ZILE9BQU8sQ0FBQ3NJLElBQUksQ0FBQyxFQUMzQixFQUFFLEVBQ0QsS0FBSVQsUUFBUyxJQUFHLENBQ2xCO0VBRUQsT0FBUSxHQUFFRyxPQUFPLENBQUM1RSxJQUFJLENBQUMsTUFBTSxDQUFFLFdBQVVtRixLQUFLLENBQUNuRixJQUFJLENBQUMsTUFBTSxDQUFFLEVBQUM7QUFDL0Q7O0FBRUE7O0FBRU8sTUFBTW9GLFdBQVcsQ0FBQztFQUN2QjtBQUNGO0FBQ0E7QUFDQTtFQUNFLGFBQWFuQyxJQUFJQSxDQUFDakcsUUFBc0IsRUFBRUosT0FBb0IsRUFBMkI7SUFDdkYsTUFBTXlJLE9BQU8sR0FBRyxJQUFJdEksV0FBVyxDQUFDQyxRQUFRLENBQUM7SUFFekMsSUFBSSxDQUFDQSxRQUFRLENBQUNZLElBQUksRUFBRTtNQUNsQixPQUFPO1FBQUUwSCxFQUFFLEVBQUUsS0FBSztRQUFFQyxLQUFLLEVBQUUseUJBQXlCO1FBQUUvSCxVQUFVLEVBQUUsRUFBRTtRQUFFNEYsUUFBUSxFQUFFLEVBQUU7UUFBRUMsUUFBUSxFQUFFO01BQUcsQ0FBQztJQUNwRztJQUNBLElBQUksQ0FBQ3JHLFFBQVEsQ0FBQ2tHLFlBQVksRUFBRTtNQUMxQixPQUFPO1FBQUVvQyxFQUFFLEVBQUUsS0FBSztRQUFFQyxLQUFLLEVBQUUsOEJBQThCO1FBQUUvSCxVQUFVLEVBQUUsRUFBRTtRQUFFNEYsUUFBUSxFQUFFLEVBQUU7UUFBRUMsUUFBUSxFQUFFO01BQUcsQ0FBQztJQUN6RztJQUNBLE1BQU1tQyxVQUFVLEdBQUcsQ0FBQzVJLE9BQU8sQ0FBQzJHLEVBQUUsSUFBSSxFQUFFLEVBQUVsQyxHQUFHLENBQUU3RixDQUFDLElBQUtBLENBQUMsQ0FBQzhGLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQ0MsTUFBTSxDQUFDWSxPQUFPLENBQUM7SUFDMUUsSUFBSXFELFVBQVUsQ0FBQy9ILE1BQU0sS0FBSyxDQUFDLEVBQUU7TUFDM0IsT0FBTztRQUFFNkgsRUFBRSxFQUFFLEtBQUs7UUFBRUMsS0FBSyxFQUFFLGVBQWU7UUFBRS9ILFVBQVUsRUFBRSxFQUFFO1FBQUU0RixRQUFRLEVBQUUsRUFBRTtRQUFFQyxRQUFRLEVBQUU7TUFBRyxDQUFDO0lBQzFGO0lBRUEsSUFBSTtNQUNGLE1BQU1nQyxPQUFPLENBQUMxSCxPQUFPLENBQUMsQ0FBQztNQUN2QixNQUFNbUQsWUFBWSxHQUFHLE1BQU11RSxPQUFPLENBQUMzRSxTQUFTLENBQUMsQ0FBQztNQUM5QyxNQUFNMkUsT0FBTyxDQUFDekQsWUFBWSxDQUFDZCxZQUFZLENBQUM7TUFDeEMsTUFBTTtRQUFFc0MsUUFBUTtRQUFFQztNQUFTLENBQUMsR0FBRyxNQUFNZ0MsT0FBTyxDQUFDcEMsSUFBSSxDQUFDO1FBQUUsR0FBR3JHLE9BQU87UUFBRTJHLEVBQUUsRUFBRWlDO01BQVcsQ0FBQyxDQUFDO01BQ2pGLE1BQU1ILE9BQU8sQ0FBQ3ZCLElBQUksQ0FBQyxDQUFDO01BQ3BCLE9BQU87UUFBRXdCLEVBQUUsRUFBRSxJQUFJO1FBQUU5SCxVQUFVLEVBQUU2SCxPQUFPLENBQUM3SCxVQUFVO1FBQUU0RixRQUFRO1FBQUVDO01BQVMsQ0FBQztJQUN6RSxDQUFDLENBQUMsT0FBTzlILENBQU0sRUFBRTtNQUNmOEosT0FBTyxDQUFDckIsT0FBTyxDQUFDLENBQUM7TUFDakIsT0FBTztRQUNMc0IsRUFBRSxFQUFFLEtBQUs7UUFDVEMsS0FBSyxFQUFFLENBQUFoSyxDQUFDLGFBQURBLENBQUMsdUJBQURBLENBQUMsQ0FBRXFCLE9BQU8sS0FBSUwsTUFBTSxDQUFDaEIsQ0FBQyxDQUFDO1FBQzlCaUMsVUFBVSxFQUFFNkgsT0FBTyxDQUFDN0gsVUFBVTtRQUM5QjRGLFFBQVEsRUFBRSxFQUFFO1FBQ1pDLFFBQVEsRUFBRW1DO01BQ1osQ0FBQztJQUNIO0VBQ0Y7O0VBRUE7RUFDQSxPQUFPQyxXQUFXQSxDQUFDM0gsUUFBZ0IsRUFBVTtJQUMzQyxJQUFJQSxRQUFRLEtBQUssS0FBSyxFQUFFLE9BQU8sR0FBRztJQUNsQyxJQUFJQSxRQUFRLEtBQUssTUFBTSxFQUFFLE9BQU8sRUFBRTtJQUNsQyxPQUFPLEdBQUc7RUFDWjtBQUNGO0FBQUM0SCxPQUFBLENBQUFOLFdBQUEsR0FBQUEsV0FBQSJ9