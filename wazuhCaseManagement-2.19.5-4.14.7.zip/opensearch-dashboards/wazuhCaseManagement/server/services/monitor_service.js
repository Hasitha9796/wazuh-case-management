"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.MonitorService = void 0;
var _constants = require("../../common/constants");
var _case_service = require("./case_service");
var _notification_service = require("./notification_service");
var _rule_engine = require("./rule_engine");
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); } /*
 * Wazuh Case Management Plugin
 * Monitor Service: background polling for automatic case creation
 *
 * Alerts are matched against an ordered set of user-defined rules. Each rule
 * carries its own boolean criteria (rule.level, rule.id, rule.groups, agent,
 * MITRE, …) plus the priority / severity / category / tags / assignee applied
 * to the case it produces, so different conditions can yield different default
 * priorities. The first matching rule wins.
 *
 * A config with no rules falls back to the legacy single `min_level` threshold,
 * so upgrades keep working untouched.
 */
const CONFIG_DOC_ID = 'monitor_config';

/** Hard ceiling on alerts pulled per scan, regardless of configuration. */
const MAX_SCAN_HITS = 500;
const DEFAULT_CONFIG = {
  enabled: false,
  min_level: 10,
  interval_minutes: 5,
  default_priority: 'P2',
  default_category: 'other',
  rules: [],
  dedupe_enabled: true,
  max_cases_per_scan: 50,
  last_run_at: null,
  last_processed_timestamp: null,
  cases_created: 0,
  updated_at: new Date().toISOString()
};
class MonitorService {
  // ── Config CRUD ──────────────────────────────────────────────

  static async ensureConfigIndex(client) {
    try {
      const {
        body
      } = await client.indices.exists({
        index: _constants.MONITOR_CONFIG_INDEX
      });
      if (!body) {
        await client.indices.create({
          index: _constants.MONITOR_CONFIG_INDEX,
          body: {
            settings: {
              number_of_shards: 1,
              number_of_replicas: 1
            },
            mappings: {
              // `rules` is a free-form nested structure that is only ever read
              // back by document ID, so leave it unindexed to avoid mapping
              // churn as the rule schema evolves.
              dynamic: false,
              properties: {
                enabled: {
                  type: 'boolean'
                },
                min_level: {
                  type: 'integer'
                },
                interval_minutes: {
                  type: 'integer'
                },
                default_priority: {
                  type: 'keyword'
                },
                default_category: {
                  type: 'keyword'
                },
                dedupe_enabled: {
                  type: 'boolean'
                },
                max_cases_per_scan: {
                  type: 'integer'
                },
                last_run_at: {
                  type: 'date'
                },
                last_processed_timestamp: {
                  type: 'date'
                },
                cases_created: {
                  type: 'long'
                },
                updated_at: {
                  type: 'date'
                }
              }
            }
          }
        });
      }
    } catch (e) {}
  }
  static async getConfig(client) {
    try {
      var _body$_source;
      const {
        body
      } = await client.get({
        index: _constants.MONITOR_CONFIG_INDEX,
        id: CONFIG_DOC_ID
      });
      // Merge over defaults so configs written by earlier versions gain the new
      // fields (rules, dedupe_enabled, …) instead of coming back undefined.
      return {
        ...DEFAULT_CONFIG,
        ...(body._source || {}),
        rules: ((_body$_source = body._source) === null || _body$_source === void 0 ? void 0 : _body$_source.rules) || []
      };
    } catch (e) {
      var _e$meta;
      if ((e === null || e === void 0 ? void 0 : e.statusCode) === 404 || (e === null || e === void 0 || (_e$meta = e.meta) === null || _e$meta === void 0 ? void 0 : _e$meta.statusCode) === 404) {
        return {
          ...DEFAULT_CONFIG
        };
      }
      throw e;
    }
  }
  static async saveConfig(client, updates) {
    const existing = await MonitorService.getConfig(client);
    const merged = {
      ...existing,
      ...updates,
      updated_at: new Date().toISOString()
    };
    await client.index({
      index: _constants.MONITOR_CONFIG_INDEX,
      id: CONFIG_DOC_ID,
      body: merged,
      refresh: 'wait_for'
    });
    return merged;
  }

  /**
   * The rules actually used by a scan. When the user hasn't defined any, the
   * legacy `min_level` threshold is presented as one implicit rule.
   */
  static effectiveRules(config) {
    if (config.rules && config.rules.length > 0) {
      return config.rules.filter(r => r.enabled);
    }
    return [{
      id: 'legacy-threshold',
      name: `Alert level ≥ ${config.min_level}`,
      enabled: true,
      order: 0,
      criteria: (0, _rule_engine.levelThresholdCriteria)(config.min_level),
      priority: config.default_priority || 'P2',
      severity: 'auto',
      category: config.default_category || 'other',
      tags: [],
      stop_on_match: true
    }];
  }

  // ── Background Polling ───────────────────────────────────────

  static start(client, logger) {
    if (MonitorService.intervalHandle) return;
    MonitorService.intervalHandle = setInterval(async () => {
      try {
        await MonitorService.tick(client, logger);
      } catch (e) {
        logger.warn(`Monitor tick error: ${e.message}`);
      }
    }, 60_000);
    logger.info('Auto-monitor background job started (checking every 60s)');
  }
  static stop() {
    if (MonitorService.intervalHandle) {
      clearInterval(MonitorService.intervalHandle);
      MonitorService.intervalHandle = null;
    }
  }
  static async tick(client, logger) {
    const config = await MonitorService.getConfig(client);
    if (!config.enabled) return;
    const now = Date.now();
    const intervalMs = (config.interval_minutes || 5) * 60_000;
    const lastRun = config.last_run_at ? new Date(config.last_run_at).getTime() : 0;
    if (now - lastRun < intervalMs) return;
    if (MonitorService.running) return;
    MonitorService.running = true;
    try {
      const rules = MonitorService.effectiveRules(config);
      logger.info(`Auto-monitor: scanning with ${rules.length} rule(s), since=${config.last_processed_timestamp || 'beginning'}`);
      const result = await MonitorService.scanAndCreateCases(client, config, logger);
      await MonitorService.saveConfig(client, {
        last_run_at: new Date().toISOString(),
        cases_created: (config.cases_created || 0) + result.created
      });
      logger.info(`Auto-monitor: scan done, created=${result.created}`);
    } finally {
      MonitorService.running = false;
    }
  }

  // ── Alert scanning ───────────────────────────────────────────

  /**
   * Fetch alerts since the last processed timestamp, match them against the
   * rule set, and create one case per matched alert.
   */
  static async scanAndCreateCases(client, config, logger) {
    const rules = MonitorService.effectiveRules(config);
    const perRule = {};
    if (rules.length === 0) {
      logger.info('Auto-monitor: no enabled rules, nothing to do');
      return {
        created: 0,
        per_rule: perRule
      };
    }
    const hits = await MonitorService.fetchCandidateAlerts(client, config, rules, logger);
    if (hits.length === 0) {
      await MonitorService.saveConfig(client, {
        last_processed_timestamp: new Date().toISOString()
      });
      return {
        created: 0,
        per_rule: perRule
      };
    }
    const since = MonitorService.sinceTimestamp(config);
    let created = 0;
    let latestTimestamp = since;
    const maxCases = Math.max(1, config.max_cases_per_scan || 50);
    const perRuleCreated = {};

    // Alert IDs already linked to a non-closed case, so a repeated alert doesn't
    // spawn a duplicate case.
    const linkedAlertIds = config.dedupe_enabled ? await MonitorService.getLinkedAlertIdsFromOpenCases(client, logger) : new Set();
    for (const hit of hits) {
      const alert = hit._source;
      const alertId = hit._id;
      const alertTimestamp = (alert === null || alert === void 0 ? void 0 : alert.timestamp) || (alert === null || alert === void 0 ? void 0 : alert['@timestamp']) || new Date().toISOString();
      if (alertTimestamp > latestTimestamp) latestTimestamp = alertTimestamp;
      if (created >= maxCases) {
        logger.info(`Auto-monitor: reached max_cases_per_scan (${maxCases}), stopping`);
        break;
      }
      if (linkedAlertIds.has(alertId)) continue;
      const rule = (0, _rule_engine.findMatchingRule)(alert, rules);
      if (!rule) continue;
      const ruleCount = perRuleCreated[rule.id] || 0;
      if (rule.max_cases_per_scan && ruleCount >= rule.max_cases_per_scan) continue;
      try {
        const newCase = await MonitorService.createCaseFromAlert(client, hit, rule, logger);
        linkedAlertIds.add(alertId);
        created++;
        perRuleCreated[rule.id] = ruleCount + 1;
        perRule[rule.name] = (perRule[rule.name] || 0) + 1;
        logger.info(`Auto-monitor: created ${newCase.case_id} via rule "${rule.name}"`);
      } catch (e) {
        logger.warn(`Auto-monitor: failed to process alert ${alertId}: ${e.message}`);
      }
    }

    // Persist per-rule counters so the UI can show which rules are firing.
    if (config.rules && config.rules.length > 0 && Object.keys(perRuleCreated).length > 0) {
      const updatedRules = config.rules.map(r => perRuleCreated[r.id] ? {
        ...r,
        cases_created: (r.cases_created || 0) + perRuleCreated[r.id]
      } : r);
      await MonitorService.saveConfig(client, {
        rules: updatedRules,
        last_processed_timestamp: latestTimestamp
      });
    } else {
      await MonitorService.saveConfig(client, {
        last_processed_timestamp: latestTimestamp
      });
    }
    return {
      created,
      per_rule: perRule
    };
  }

  /** First run looks back 24 hours so pre-existing alerts are picked up. */
  static sinceTimestamp(config) {
    return config.last_processed_timestamp || new Date(Date.now() - 24 * 60 * 60_000).toISOString();
  }
  static async fetchCandidateAlerts(client, config, rules, logger) {
    const since = MonitorService.sinceTimestamp(config);

    // Wazuh alerts carry either "timestamp" or "@timestamp" depending on the
    // version, so accept whichever is present.
    const timeWindow = {
      bool: {
        should: [{
          range: {
            timestamp: {
              gt: since
            }
          }
        }, {
          range: {
            '@timestamp': {
              gt: since
            }
          }
        }],
        minimum_should_match: 1
      }
    };
    const filter = [timeWindow];
    const preFilter = (0, _rule_engine.buildRuleSetQuery)(rules);
    if (preFilter) {
      filter.push(preFilter);
    } else {
      logger.info('Auto-monitor: rule set cannot be pre-filtered in OpenSearch, so the full window is evaluated in memory');
    }
    const size = Math.min(MAX_SCAN_HITS, Math.max(50, (config.max_cases_per_scan || 50) * 5));
    try {
      var _result$hits;
      const {
        body: result
      } = await client.search({
        index: _constants.WAZUH_ALERTS_INDEX_PATTERN,
        body: {
          query: {
            bool: {
              filter
            }
          },
          sort: [{
            timestamp: {
              order: 'asc',
              unmapped_type: 'date'
            }
          }],
          size
        },
        ignore_unavailable: true
      });
      const hits = ((_result$hits = result.hits) === null || _result$hits === void 0 ? void 0 : _result$hits.hits) || [];
      logger.info(`Auto-monitor: fetched ${hits.length} candidate alert(s) since ${since}`);
      return hits;
    } catch (e) {
      logger.warn(`Auto-monitor: alert search failed: ${e.message}`);
      return [];
    }
  }

  /** Create a case for one alert using the matched rule's case attributes. */
  static async createCaseFromAlert(client, hit, rule, logger) {
    var _alert$rule, _alert$rule2, _alert$rule3;
    const alert = hit._source;
    const alertId = hit._id;
    const ruleDescription = (alert === null || alert === void 0 || (_alert$rule = alert.rule) === null || _alert$rule === void 0 ? void 0 : _alert$rule.description) || 'Security Alert';
    const ruleLevel = Number(alert === null || alert === void 0 || (_alert$rule2 = alert.rule) === null || _alert$rule2 === void 0 ? void 0 : _alert$rule2.level) || 0;
    const wazuhRuleId = String((alert === null || alert === void 0 || (_alert$rule3 = alert.rule) === null || _alert$rule3 === void 0 ? void 0 : _alert$rule3.id) || '');
    const tags = Array.from(new Set(['auto-created', `level-${ruleLevel}`, ...(wazuhRuleId ? [`rule-${wazuhRuleId}`] : []), ...(rule.tags || []), `monitor-rule-${rule.id}`]));
    const newCase = await _case_service.CaseService.createCase(client, {
      title: 'PLACEHOLDER',
      description: MonitorService.buildDescription(alert, rule),
      severity: (0, _rule_engine.resolveSeverity)(rule, alert),
      priority: rule.priority,
      category: rule.category,
      tlp: rule.tlp,
      tags,
      assignee: rule.assignee || null
    }, 'auto-monitor');
    const prettyTitle = `${newCase.case_id}: ${ruleDescription}`;
    const linkedAlert = MonitorService.buildLinkedAlert(hit);
    await client.update({
      index: _constants.CASE_INDEX,
      id: newCase.id,
      body: {
        doc: {
          title: prettyTitle,
          linked_alerts: [linkedAlert],
          // Indexed dedup key: custom_fields is mapped with enabled:false.
          tags: [...tags, `auto-alert-${alertId}`],
          updated_at: new Date().toISOString()
        }
      },
      retry_on_conflict: 3
    });
    const caseRef = {
      ...newCase,
      title: prettyTitle
    };
    await _notification_service.NotificationService.dispatch(client, {
      event: rule.assignee ? 'case_assigned' : 'case_created',
      recipients: [rule.assignee],
      title: `Case ${newCase.case_id} auto-created`,
      message: `${ruleDescription} (rule "${rule.name}", priority ${rule.priority})`,
      caseRef,
      actor: 'auto-monitor',
      context: {
        monitor_rule: rule.name,
        alert_id: alertId,
        rule_level: ruleLevel
      }
    }, logger);
    return caseRef;
  }

  /**
   * Returns the set of alert IDs already linked inside any open/in-progress/waiting case.
   * Used for deduplication instead of custom_fields (which is not indexed).
   */
  static async getLinkedAlertIdsFromOpenCases(client, logger) {
    const ids = new Set();
    try {
      const {
        body: result
      } = await client.search({
        index: _constants.CASE_INDEX,
        body: {
          query: {
            bool: {
              must: [{
                terms: {
                  status: ['open', 'in_progress', 'waiting']
                }
              }, {
                term: {
                  tags: 'auto-created'
                }
              }]
            }
          },
          _source: ['linked_alerts'],
          size: 500
        }
      });
      for (const hit of ((_result$hits2 = result.hits) === null || _result$hits2 === void 0 ? void 0 : _result$hits2.hits) || []) {
        var _result$hits2;
        for (const la of ((_hit$_source = hit._source) === null || _hit$_source === void 0 ? void 0 : _hit$_source.linked_alerts) || []) {
          var _hit$_source;
          if (la.alert_id) ids.add(la.alert_id);
        }
      }
    } catch (e) {
      logger.warn(`Auto-monitor: could not fetch open case alert IDs: ${e.message}`);
    }
    return ids;
  }
  static buildLinkedAlert(hit) {
    var _alert$rule4, _alert$rule5, _alert$rule6, _alert$rule7, _alert$agent, _alert$agent2;
    const alert = hit._source;
    return {
      alert_id: hit._id,
      index: hit._index || _constants.WAZUH_ALERTS_INDEX_PATTERN,
      rule_id: parseInt((alert === null || alert === void 0 || (_alert$rule4 = alert.rule) === null || _alert$rule4 === void 0 ? void 0 : _alert$rule4.id) || '0', 10),
      rule_description: (alert === null || alert === void 0 || (_alert$rule5 = alert.rule) === null || _alert$rule5 === void 0 ? void 0 : _alert$rule5.description) || '',
      rule_level: (alert === null || alert === void 0 || (_alert$rule6 = alert.rule) === null || _alert$rule6 === void 0 ? void 0 : _alert$rule6.level) || 0,
      rule_groups: (alert === null || alert === void 0 || (_alert$rule7 = alert.rule) === null || _alert$rule7 === void 0 ? void 0 : _alert$rule7.groups) || [],
      agent_id: (alert === null || alert === void 0 || (_alert$agent = alert.agent) === null || _alert$agent === void 0 ? void 0 : _alert$agent.id) || '',
      agent_name: (alert === null || alert === void 0 || (_alert$agent2 = alert.agent) === null || _alert$agent2 === void 0 ? void 0 : _alert$agent2.name) || '',
      timestamp: (alert === null || alert === void 0 ? void 0 : alert.timestamp) || (alert === null || alert === void 0 ? void 0 : alert['@timestamp']) || new Date().toISOString(),
      full_log: (alert === null || alert === void 0 ? void 0 : alert.full_log) || ''
    };
  }
  static buildDescription(alert, rule) {
    var _alert$rule8, _alert$rule9, _alert$rule$level, _alert$rule10, _alert$agent3, _alert$agent4, _alert$rule11;
    const ruleId = (alert === null || alert === void 0 || (_alert$rule8 = alert.rule) === null || _alert$rule8 === void 0 ? void 0 : _alert$rule8.id) || 'N/A';
    const ruleDesc = (alert === null || alert === void 0 || (_alert$rule9 = alert.rule) === null || _alert$rule9 === void 0 ? void 0 : _alert$rule9.description) || 'N/A';
    const ruleLevel = (_alert$rule$level = alert === null || alert === void 0 || (_alert$rule10 = alert.rule) === null || _alert$rule10 === void 0 ? void 0 : _alert$rule10.level) !== null && _alert$rule$level !== void 0 ? _alert$rule$level : 'N/A';
    const agentName = (alert === null || alert === void 0 || (_alert$agent3 = alert.agent) === null || _alert$agent3 === void 0 ? void 0 : _alert$agent3.name) || 'Unknown';
    const agentId = (alert === null || alert === void 0 || (_alert$agent4 = alert.agent) === null || _alert$agent4 === void 0 ? void 0 : _alert$agent4.id) || 'N/A';
    const groups = ((alert === null || alert === void 0 || (_alert$rule11 = alert.rule) === null || _alert$rule11 === void 0 ? void 0 : _alert$rule11.groups) || []).join(', ') || 'N/A';
    const rawTs = (alert === null || alert === void 0 ? void 0 : alert.timestamp) || (alert === null || alert === void 0 ? void 0 : alert['@timestamp']);
    const timestamp = rawTs ? new Date(rawTs).toISOString().replace('T', ' ').replace(/\..*$/, ' UTC') : 'N/A';
    const lines = [`This case was automatically created by the Wazuh Case Monitor.`, ``, `## Matched Monitor Rule`, ``, `- **Rule name:** ${rule.name}`, `- **Criteria:** \`${(0, _rule_engine.describeNode)(rule.criteria) || 'any alert'}\``, `- **Assigned priority:** ${rule.priority}`, ``, `## Alert Details`, ``, `- **Rule ID:** ${ruleId}`, `- **Description:** ${ruleDesc}`, `- **Level:** ${ruleLevel}`, `- **Groups:** ${groups}`, `- **Agent:** ${agentName} (ID: ${agentId})`, `- **Detected:** ${timestamp}`];
    if (alert !== null && alert !== void 0 && alert.full_log) {
      const log = String(alert.full_log).trim().substring(0, 600);
      lines.push(``, `## Raw Log`, ``, `\`\`\``, log, `\`\`\``);
    }
    return lines.join('\n');
  }

  // ── Rule testing ─────────────────────────────────────────────

  /**
   * Dry-run a rule set against recent alerts without creating any cases.
   * Powers the "Test rules" button in the Auto Monitor UI.
   */
  static async testRules(client, rules, opts = {}) {
    var _result$hits3;
    const hours = Math.min(opts.hours || 24, 168);
    const size = Math.min(opts.size || 200, MAX_SCAN_HITS);
    const since = new Date(Date.now() - hours * 60 * 60_000).toISOString();
    const filter = [{
      bool: {
        should: [{
          range: {
            timestamp: {
              gt: since
            }
          }
        }, {
          range: {
            '@timestamp': {
              gt: since
            }
          }
        }],
        minimum_should_match: 1
      }
    }];
    const preFilter = (0, _rule_engine.buildRuleSetQuery)(rules);
    if (preFilter) filter.push(preFilter);
    const {
      body: result
    } = await client.search({
      index: _constants.WAZUH_ALERTS_INDEX_PATTERN,
      body: {
        query: {
          bool: {
            filter
          }
        },
        sort: [{
          timestamp: {
            order: 'desc',
            unmapped_type: 'date'
          }
        }],
        size
      },
      ignore_unavailable: true
    });
    const hits = ((_result$hits3 = result.hits) === null || _result$hits3 === void 0 ? void 0 : _result$hits3.hits) || [];
    const matches = [];
    const perRule = {};
    for (const hit of hits) {
      const alert = hit._source;
      const rule = (0, _rule_engine.findMatchingRule)(alert, rules);
      if (!rule) continue;
      perRule[rule.name] = (perRule[rule.name] || 0) + 1;
      if (matches.length < 50) {
        var _alert$rule12, _alert$rule13, _alert$rule14, _alert$agent5;
        matches.push({
          alert_id: hit._id,
          timestamp: (alert === null || alert === void 0 ? void 0 : alert.timestamp) || (alert === null || alert === void 0 ? void 0 : alert['@timestamp']) || '',
          rule_id: String((alert === null || alert === void 0 || (_alert$rule12 = alert.rule) === null || _alert$rule12 === void 0 ? void 0 : _alert$rule12.id) || ''),
          rule_description: (alert === null || alert === void 0 || (_alert$rule13 = alert.rule) === null || _alert$rule13 === void 0 ? void 0 : _alert$rule13.description) || '',
          rule_level: Number(alert === null || alert === void 0 || (_alert$rule14 = alert.rule) === null || _alert$rule14 === void 0 ? void 0 : _alert$rule14.level) || 0,
          agent_name: (alert === null || alert === void 0 || (_alert$agent5 = alert.agent) === null || _alert$agent5 === void 0 ? void 0 : _alert$agent5.name) || '',
          matched_rule: rule.name,
          priority: rule.priority,
          severity: (0, _rule_engine.resolveSeverity)(rule, alert)
        });
      }
    }
    return {
      scanned: hits.length,
      matches,
      per_rule: perRule
    };
  }
}
exports.MonitorService = MonitorService;
_defineProperty(MonitorService, "intervalHandle", null);
_defineProperty(MonitorService, "running", false);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfY29uc3RhbnRzIiwicmVxdWlyZSIsIl9jYXNlX3NlcnZpY2UiLCJfbm90aWZpY2F0aW9uX3NlcnZpY2UiLCJfcnVsZV9lbmdpbmUiLCJfZGVmaW5lUHJvcGVydHkiLCJlIiwiciIsInQiLCJfdG9Qcm9wZXJ0eUtleSIsIk9iamVjdCIsImRlZmluZVByb3BlcnR5IiwidmFsdWUiLCJlbnVtZXJhYmxlIiwiY29uZmlndXJhYmxlIiwid3JpdGFibGUiLCJpIiwiX3RvUHJpbWl0aXZlIiwiU3ltYm9sIiwidG9QcmltaXRpdmUiLCJjYWxsIiwiVHlwZUVycm9yIiwiU3RyaW5nIiwiTnVtYmVyIiwiQ09ORklHX0RPQ19JRCIsIk1BWF9TQ0FOX0hJVFMiLCJERUZBVUxUX0NPTkZJRyIsImVuYWJsZWQiLCJtaW5fbGV2ZWwiLCJpbnRlcnZhbF9taW51dGVzIiwiZGVmYXVsdF9wcmlvcml0eSIsImRlZmF1bHRfY2F0ZWdvcnkiLCJydWxlcyIsImRlZHVwZV9lbmFibGVkIiwibWF4X2Nhc2VzX3Blcl9zY2FuIiwibGFzdF9ydW5fYXQiLCJsYXN0X3Byb2Nlc3NlZF90aW1lc3RhbXAiLCJjYXNlc19jcmVhdGVkIiwidXBkYXRlZF9hdCIsIkRhdGUiLCJ0b0lTT1N0cmluZyIsIk1vbml0b3JTZXJ2aWNlIiwiZW5zdXJlQ29uZmlnSW5kZXgiLCJjbGllbnQiLCJib2R5IiwiaW5kaWNlcyIsImV4aXN0cyIsImluZGV4IiwiTU9OSVRPUl9DT05GSUdfSU5ERVgiLCJjcmVhdGUiLCJzZXR0aW5ncyIsIm51bWJlcl9vZl9zaGFyZHMiLCJudW1iZXJfb2ZfcmVwbGljYXMiLCJtYXBwaW5ncyIsImR5bmFtaWMiLCJwcm9wZXJ0aWVzIiwidHlwZSIsImdldENvbmZpZyIsIl9ib2R5JF9zb3VyY2UiLCJnZXQiLCJpZCIsIl9zb3VyY2UiLCJfZSRtZXRhIiwic3RhdHVzQ29kZSIsIm1ldGEiLCJzYXZlQ29uZmlnIiwidXBkYXRlcyIsImV4aXN0aW5nIiwibWVyZ2VkIiwicmVmcmVzaCIsImVmZmVjdGl2ZVJ1bGVzIiwiY29uZmlnIiwibGVuZ3RoIiwiZmlsdGVyIiwibmFtZSIsIm9yZGVyIiwiY3JpdGVyaWEiLCJsZXZlbFRocmVzaG9sZENyaXRlcmlhIiwicHJpb3JpdHkiLCJzZXZlcml0eSIsImNhdGVnb3J5IiwidGFncyIsInN0b3Bfb25fbWF0Y2giLCJzdGFydCIsImxvZ2dlciIsImludGVydmFsSGFuZGxlIiwic2V0SW50ZXJ2YWwiLCJ0aWNrIiwid2FybiIsIm1lc3NhZ2UiLCJpbmZvIiwic3RvcCIsImNsZWFySW50ZXJ2YWwiLCJub3ciLCJpbnRlcnZhbE1zIiwibGFzdFJ1biIsImdldFRpbWUiLCJydW5uaW5nIiwicmVzdWx0Iiwic2NhbkFuZENyZWF0ZUNhc2VzIiwiY3JlYXRlZCIsInBlclJ1bGUiLCJwZXJfcnVsZSIsImhpdHMiLCJmZXRjaENhbmRpZGF0ZUFsZXJ0cyIsInNpbmNlIiwic2luY2VUaW1lc3RhbXAiLCJsYXRlc3RUaW1lc3RhbXAiLCJtYXhDYXNlcyIsIk1hdGgiLCJtYXgiLCJwZXJSdWxlQ3JlYXRlZCIsImxpbmtlZEFsZXJ0SWRzIiwiZ2V0TGlua2VkQWxlcnRJZHNGcm9tT3BlbkNhc2VzIiwiU2V0IiwiaGl0IiwiYWxlcnQiLCJhbGVydElkIiwiX2lkIiwiYWxlcnRUaW1lc3RhbXAiLCJ0aW1lc3RhbXAiLCJoYXMiLCJydWxlIiwiZmluZE1hdGNoaW5nUnVsZSIsInJ1bGVDb3VudCIsIm5ld0Nhc2UiLCJjcmVhdGVDYXNlRnJvbUFsZXJ0IiwiYWRkIiwiY2FzZV9pZCIsImtleXMiLCJ1cGRhdGVkUnVsZXMiLCJtYXAiLCJ0aW1lV2luZG93IiwiYm9vbCIsInNob3VsZCIsInJhbmdlIiwiZ3QiLCJtaW5pbXVtX3Nob3VsZF9tYXRjaCIsInByZUZpbHRlciIsImJ1aWxkUnVsZVNldFF1ZXJ5IiwicHVzaCIsInNpemUiLCJtaW4iLCJfcmVzdWx0JGhpdHMiLCJzZWFyY2giLCJXQVpVSF9BTEVSVFNfSU5ERVhfUEFUVEVSTiIsInF1ZXJ5Iiwic29ydCIsInVubWFwcGVkX3R5cGUiLCJpZ25vcmVfdW5hdmFpbGFibGUiLCJfYWxlcnQkcnVsZSIsIl9hbGVydCRydWxlMiIsIl9hbGVydCRydWxlMyIsInJ1bGVEZXNjcmlwdGlvbiIsImRlc2NyaXB0aW9uIiwicnVsZUxldmVsIiwibGV2ZWwiLCJ3YXp1aFJ1bGVJZCIsIkFycmF5IiwiZnJvbSIsIkNhc2VTZXJ2aWNlIiwiY3JlYXRlQ2FzZSIsInRpdGxlIiwiYnVpbGREZXNjcmlwdGlvbiIsInJlc29sdmVTZXZlcml0eSIsInRscCIsImFzc2lnbmVlIiwicHJldHR5VGl0bGUiLCJsaW5rZWRBbGVydCIsImJ1aWxkTGlua2VkQWxlcnQiLCJ1cGRhdGUiLCJDQVNFX0lOREVYIiwiZG9jIiwibGlua2VkX2FsZXJ0cyIsInJldHJ5X29uX2NvbmZsaWN0IiwiY2FzZVJlZiIsIk5vdGlmaWNhdGlvblNlcnZpY2UiLCJkaXNwYXRjaCIsImV2ZW50IiwicmVjaXBpZW50cyIsImFjdG9yIiwiY29udGV4dCIsIm1vbml0b3JfcnVsZSIsImFsZXJ0X2lkIiwicnVsZV9sZXZlbCIsImlkcyIsIm11c3QiLCJ0ZXJtcyIsInN0YXR1cyIsInRlcm0iLCJfcmVzdWx0JGhpdHMyIiwibGEiLCJfaGl0JF9zb3VyY2UiLCJfYWxlcnQkcnVsZTQiLCJfYWxlcnQkcnVsZTUiLCJfYWxlcnQkcnVsZTYiLCJfYWxlcnQkcnVsZTciLCJfYWxlcnQkYWdlbnQiLCJfYWxlcnQkYWdlbnQyIiwiX2luZGV4IiwicnVsZV9pZCIsInBhcnNlSW50IiwicnVsZV9kZXNjcmlwdGlvbiIsInJ1bGVfZ3JvdXBzIiwiZ3JvdXBzIiwiYWdlbnRfaWQiLCJhZ2VudCIsImFnZW50X25hbWUiLCJmdWxsX2xvZyIsIl9hbGVydCRydWxlOCIsIl9hbGVydCRydWxlOSIsIl9hbGVydCRydWxlJGxldmVsIiwiX2FsZXJ0JHJ1bGUxMCIsIl9hbGVydCRhZ2VudDMiLCJfYWxlcnQkYWdlbnQ0IiwiX2FsZXJ0JHJ1bGUxMSIsInJ1bGVJZCIsInJ1bGVEZXNjIiwiYWdlbnROYW1lIiwiYWdlbnRJZCIsImpvaW4iLCJyYXdUcyIsInJlcGxhY2UiLCJsaW5lcyIsImRlc2NyaWJlTm9kZSIsImxvZyIsInRyaW0iLCJzdWJzdHJpbmciLCJ0ZXN0UnVsZXMiLCJvcHRzIiwiX3Jlc3VsdCRoaXRzMyIsImhvdXJzIiwibWF0Y2hlcyIsIl9hbGVydCRydWxlMTIiLCJfYWxlcnQkcnVsZTEzIiwiX2FsZXJ0JHJ1bGUxNCIsIl9hbGVydCRhZ2VudDUiLCJtYXRjaGVkX3J1bGUiLCJzY2FubmVkIiwiZXhwb3J0cyJdLCJzb3VyY2VzIjpbIm1vbml0b3Jfc2VydmljZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogV2F6dWggQ2FzZSBNYW5hZ2VtZW50IFBsdWdpblxuICogTW9uaXRvciBTZXJ2aWNlOiBiYWNrZ3JvdW5kIHBvbGxpbmcgZm9yIGF1dG9tYXRpYyBjYXNlIGNyZWF0aW9uXG4gKlxuICogQWxlcnRzIGFyZSBtYXRjaGVkIGFnYWluc3QgYW4gb3JkZXJlZCBzZXQgb2YgdXNlci1kZWZpbmVkIHJ1bGVzLiBFYWNoIHJ1bGVcbiAqIGNhcnJpZXMgaXRzIG93biBib29sZWFuIGNyaXRlcmlhIChydWxlLmxldmVsLCBydWxlLmlkLCBydWxlLmdyb3VwcywgYWdlbnQsXG4gKiBNSVRSRSwg4oCmKSBwbHVzIHRoZSBwcmlvcml0eSAvIHNldmVyaXR5IC8gY2F0ZWdvcnkgLyB0YWdzIC8gYXNzaWduZWUgYXBwbGllZFxuICogdG8gdGhlIGNhc2UgaXQgcHJvZHVjZXMsIHNvIGRpZmZlcmVudCBjb25kaXRpb25zIGNhbiB5aWVsZCBkaWZmZXJlbnQgZGVmYXVsdFxuICogcHJpb3JpdGllcy4gVGhlIGZpcnN0IG1hdGNoaW5nIHJ1bGUgd2lucy5cbiAqXG4gKiBBIGNvbmZpZyB3aXRoIG5vIHJ1bGVzIGZhbGxzIGJhY2sgdG8gdGhlIGxlZ2FjeSBzaW5nbGUgYG1pbl9sZXZlbGAgdGhyZXNob2xkLFxuICogc28gdXBncmFkZXMga2VlcCB3b3JraW5nIHVudG91Y2hlZC5cbiAqL1xuXG5pbXBvcnQgeyBMb2dnZXIgfSBmcm9tICcuLi8uLi8uLi8uLi9zcmMvY29yZS9zZXJ2ZXInO1xuaW1wb3J0IHtcbiAgTU9OSVRPUl9DT05GSUdfSU5ERVgsXG4gIFdBWlVIX0FMRVJUU19JTkRFWF9QQVRURVJOLFxuICBDQVNFX0lOREVYLFxufSBmcm9tICcuLi8uLi9jb21tb24vY29uc3RhbnRzJztcbmltcG9ydCB7IE1vbml0b3JDb25maWcsIE1vbml0b3JSdWxlLCBDYXNlUHJpb3JpdHksIENhc2VDYXRlZ29yeSB9IGZyb20gJy4uLy4uL2NvbW1vbi90eXBlcyc7XG5pbXBvcnQgeyBDYXNlU2VydmljZSB9IGZyb20gJy4vY2FzZV9zZXJ2aWNlJztcbmltcG9ydCB7IE5vdGlmaWNhdGlvblNlcnZpY2UgfSBmcm9tICcuL25vdGlmaWNhdGlvbl9zZXJ2aWNlJztcbmltcG9ydCB7XG4gIGJ1aWxkUnVsZVNldFF1ZXJ5LFxuICBmaW5kTWF0Y2hpbmdSdWxlLFxuICByZXNvbHZlU2V2ZXJpdHksXG4gIGRlc2NyaWJlTm9kZSxcbiAgbGV2ZWxUaHJlc2hvbGRDcml0ZXJpYSxcbn0gZnJvbSAnLi9ydWxlX2VuZ2luZSc7XG5cbmV4cG9ydCB0eXBlIHsgTW9uaXRvckNvbmZpZyB9IGZyb20gJy4uLy4uL2NvbW1vbi90eXBlcyc7XG5cbmNvbnN0IENPTkZJR19ET0NfSUQgPSAnbW9uaXRvcl9jb25maWcnO1xuXG4vKiogSGFyZCBjZWlsaW5nIG9uIGFsZXJ0cyBwdWxsZWQgcGVyIHNjYW4sIHJlZ2FyZGxlc3Mgb2YgY29uZmlndXJhdGlvbi4gKi9cbmNvbnN0IE1BWF9TQ0FOX0hJVFMgPSA1MDA7XG5cbmNvbnN0IERFRkFVTFRfQ09ORklHOiBNb25pdG9yQ29uZmlnID0ge1xuICBlbmFibGVkOiBmYWxzZSxcbiAgbWluX2xldmVsOiAxMCxcbiAgaW50ZXJ2YWxfbWludXRlczogNSxcbiAgZGVmYXVsdF9wcmlvcml0eTogJ1AyJyxcbiAgZGVmYXVsdF9jYXRlZ29yeTogJ290aGVyJyxcbiAgcnVsZXM6IFtdLFxuICBkZWR1cGVfZW5hYmxlZDogdHJ1ZSxcbiAgbWF4X2Nhc2VzX3Blcl9zY2FuOiA1MCxcbiAgbGFzdF9ydW5fYXQ6IG51bGwsXG4gIGxhc3RfcHJvY2Vzc2VkX3RpbWVzdGFtcDogbnVsbCxcbiAgY2FzZXNfY3JlYXRlZDogMCxcbiAgdXBkYXRlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxufTtcblxuZXhwb3J0IGNsYXNzIE1vbml0b3JTZXJ2aWNlIHtcbiAgcHJpdmF0ZSBzdGF0aWMgaW50ZXJ2YWxIYW5kbGU6IFJldHVyblR5cGU8dHlwZW9mIHNldEludGVydmFsPiB8IG51bGwgPSBudWxsO1xuICBwcml2YXRlIHN0YXRpYyBydW5uaW5nID0gZmFsc2U7XG5cbiAgLy8g4pSA4pSAIENvbmZpZyBDUlVEIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG4gIHN0YXRpYyBhc3luYyBlbnN1cmVDb25maWdJbmRleChjbGllbnQ6IGFueSk6IFByb21pc2U8dm9pZD4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB7IGJvZHkgfSA9IGF3YWl0IGNsaWVudC5pbmRpY2VzLmV4aXN0cyh7IGluZGV4OiBNT05JVE9SX0NPTkZJR19JTkRFWCB9KTtcbiAgICAgIGlmICghYm9keSkge1xuICAgICAgICBhd2FpdCBjbGllbnQuaW5kaWNlcy5jcmVhdGUoe1xuICAgICAgICAgIGluZGV4OiBNT05JVE9SX0NPTkZJR19JTkRFWCxcbiAgICAgICAgICBib2R5OiB7XG4gICAgICAgICAgICBzZXR0aW5nczogeyBudW1iZXJfb2Zfc2hhcmRzOiAxLCBudW1iZXJfb2ZfcmVwbGljYXM6IDEgfSxcbiAgICAgICAgICAgIG1hcHBpbmdzOiB7XG4gICAgICAgICAgICAgIC8vIGBydWxlc2AgaXMgYSBmcmVlLWZvcm0gbmVzdGVkIHN0cnVjdHVyZSB0aGF0IGlzIG9ubHkgZXZlciByZWFkXG4gICAgICAgICAgICAgIC8vIGJhY2sgYnkgZG9jdW1lbnQgSUQsIHNvIGxlYXZlIGl0IHVuaW5kZXhlZCB0byBhdm9pZCBtYXBwaW5nXG4gICAgICAgICAgICAgIC8vIGNodXJuIGFzIHRoZSBydWxlIHNjaGVtYSBldm9sdmVzLlxuICAgICAgICAgICAgICBkeW5hbWljOiBmYWxzZSxcbiAgICAgICAgICAgICAgcHJvcGVydGllczoge1xuICAgICAgICAgICAgICAgIGVuYWJsZWQ6IHsgdHlwZTogJ2Jvb2xlYW4nIH0sXG4gICAgICAgICAgICAgICAgbWluX2xldmVsOiB7IHR5cGU6ICdpbnRlZ2VyJyB9LFxuICAgICAgICAgICAgICAgIGludGVydmFsX21pbnV0ZXM6IHsgdHlwZTogJ2ludGVnZXInIH0sXG4gICAgICAgICAgICAgICAgZGVmYXVsdF9wcmlvcml0eTogeyB0eXBlOiAna2V5d29yZCcgfSxcbiAgICAgICAgICAgICAgICBkZWZhdWx0X2NhdGVnb3J5OiB7IHR5cGU6ICdrZXl3b3JkJyB9LFxuICAgICAgICAgICAgICAgIGRlZHVwZV9lbmFibGVkOiB7IHR5cGU6ICdib29sZWFuJyB9LFxuICAgICAgICAgICAgICAgIG1heF9jYXNlc19wZXJfc2NhbjogeyB0eXBlOiAnaW50ZWdlcicgfSxcbiAgICAgICAgICAgICAgICBsYXN0X3J1bl9hdDogeyB0eXBlOiAnZGF0ZScgfSxcbiAgICAgICAgICAgICAgICBsYXN0X3Byb2Nlc3NlZF90aW1lc3RhbXA6IHsgdHlwZTogJ2RhdGUnIH0sXG4gICAgICAgICAgICAgICAgY2FzZXNfY3JlYXRlZDogeyB0eXBlOiAnbG9uZycgfSxcbiAgICAgICAgICAgICAgICB1cGRhdGVkX2F0OiB7IHR5cGU6ICdkYXRlJyB9LFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlKSB7fVxuICB9XG5cbiAgc3RhdGljIGFzeW5jIGdldENvbmZpZyhjbGllbnQ6IGFueSk6IFByb21pc2U8TW9uaXRvckNvbmZpZz4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB7IGJvZHkgfSA9IGF3YWl0IGNsaWVudC5nZXQoeyBpbmRleDogTU9OSVRPUl9DT05GSUdfSU5ERVgsIGlkOiBDT05GSUdfRE9DX0lEIH0pO1xuICAgICAgLy8gTWVyZ2Ugb3ZlciBkZWZhdWx0cyBzbyBjb25maWdzIHdyaXR0ZW4gYnkgZWFybGllciB2ZXJzaW9ucyBnYWluIHRoZSBuZXdcbiAgICAgIC8vIGZpZWxkcyAocnVsZXMsIGRlZHVwZV9lbmFibGVkLCDigKYpIGluc3RlYWQgb2YgY29taW5nIGJhY2sgdW5kZWZpbmVkLlxuICAgICAgcmV0dXJuIHsgLi4uREVGQVVMVF9DT05GSUcsIC4uLihib2R5Ll9zb3VyY2UgfHwge30pLCBydWxlczogYm9keS5fc291cmNlPy5ydWxlcyB8fCBbXSB9O1xuICAgIH0gY2F0Y2ggKGU6IGFueSkge1xuICAgICAgaWYgKGU/LnN0YXR1c0NvZGUgPT09IDQwNCB8fCBlPy5tZXRhPy5zdGF0dXNDb2RlID09PSA0MDQpIHtcbiAgICAgICAgcmV0dXJuIHsgLi4uREVGQVVMVF9DT05GSUcgfTtcbiAgICAgIH1cbiAgICAgIHRocm93IGU7XG4gICAgfVxuICB9XG5cbiAgc3RhdGljIGFzeW5jIHNhdmVDb25maWcoY2xpZW50OiBhbnksIHVwZGF0ZXM6IFBhcnRpYWw8TW9uaXRvckNvbmZpZz4pOiBQcm9taXNlPE1vbml0b3JDb25maWc+IHtcbiAgICBjb25zdCBleGlzdGluZyA9IGF3YWl0IE1vbml0b3JTZXJ2aWNlLmdldENvbmZpZyhjbGllbnQpO1xuICAgIGNvbnN0IG1lcmdlZDogTW9uaXRvckNvbmZpZyA9IHsgLi4uZXhpc3RpbmcsIC4uLnVwZGF0ZXMsIHVwZGF0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSB9O1xuICAgIGF3YWl0IGNsaWVudC5pbmRleCh7XG4gICAgICBpbmRleDogTU9OSVRPUl9DT05GSUdfSU5ERVgsXG4gICAgICBpZDogQ09ORklHX0RPQ19JRCxcbiAgICAgIGJvZHk6IG1lcmdlZCxcbiAgICAgIHJlZnJlc2g6ICd3YWl0X2ZvcicsXG4gICAgfSk7XG4gICAgcmV0dXJuIG1lcmdlZDtcbiAgfVxuXG4gIC8qKlxuICAgKiBUaGUgcnVsZXMgYWN0dWFsbHkgdXNlZCBieSBhIHNjYW4uIFdoZW4gdGhlIHVzZXIgaGFzbid0IGRlZmluZWQgYW55LCB0aGVcbiAgICogbGVnYWN5IGBtaW5fbGV2ZWxgIHRocmVzaG9sZCBpcyBwcmVzZW50ZWQgYXMgb25lIGltcGxpY2l0IHJ1bGUuXG4gICAqL1xuICBzdGF0aWMgZWZmZWN0aXZlUnVsZXMoY29uZmlnOiBNb25pdG9yQ29uZmlnKTogTW9uaXRvclJ1bGVbXSB7XG4gICAgaWYgKGNvbmZpZy5ydWxlcyAmJiBjb25maWcucnVsZXMubGVuZ3RoID4gMCkge1xuICAgICAgcmV0dXJuIGNvbmZpZy5ydWxlcy5maWx0ZXIoKHIpID0+IHIuZW5hYmxlZCk7XG4gICAgfVxuICAgIHJldHVybiBbXG4gICAgICB7XG4gICAgICAgIGlkOiAnbGVnYWN5LXRocmVzaG9sZCcsXG4gICAgICAgIG5hbWU6IGBBbGVydCBsZXZlbCDiiaUgJHtjb25maWcubWluX2xldmVsfWAsXG4gICAgICAgIGVuYWJsZWQ6IHRydWUsXG4gICAgICAgIG9yZGVyOiAwLFxuICAgICAgICBjcml0ZXJpYTogbGV2ZWxUaHJlc2hvbGRDcml0ZXJpYShjb25maWcubWluX2xldmVsKSxcbiAgICAgICAgcHJpb3JpdHk6IChjb25maWcuZGVmYXVsdF9wcmlvcml0eSB8fCAnUDInKSBhcyBDYXNlUHJpb3JpdHksXG4gICAgICAgIHNldmVyaXR5OiAnYXV0bycsXG4gICAgICAgIGNhdGVnb3J5OiAoY29uZmlnLmRlZmF1bHRfY2F0ZWdvcnkgfHwgJ290aGVyJykgYXMgQ2FzZUNhdGVnb3J5LFxuICAgICAgICB0YWdzOiBbXSxcbiAgICAgICAgc3RvcF9vbl9tYXRjaDogdHJ1ZSxcbiAgICAgIH0sXG4gICAgXTtcbiAgfVxuXG4gIC8vIOKUgOKUgCBCYWNrZ3JvdW5kIFBvbGxpbmcg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbiAgc3RhdGljIHN0YXJ0KGNsaWVudDogYW55LCBsb2dnZXI6IExvZ2dlcik6IHZvaWQge1xuICAgIGlmIChNb25pdG9yU2VydmljZS5pbnRlcnZhbEhhbmRsZSkgcmV0dXJuO1xuICAgIE1vbml0b3JTZXJ2aWNlLmludGVydmFsSGFuZGxlID0gc2V0SW50ZXJ2YWwoYXN5bmMgKCkgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgYXdhaXQgTW9uaXRvclNlcnZpY2UudGljayhjbGllbnQsIGxvZ2dlcik7XG4gICAgICB9IGNhdGNoIChlOiBhbnkpIHtcbiAgICAgICAgbG9nZ2VyLndhcm4oYE1vbml0b3IgdGljayBlcnJvcjogJHtlLm1lc3NhZ2V9YCk7XG4gICAgICB9XG4gICAgfSwgNjBfMDAwKTtcbiAgICBsb2dnZXIuaW5mbygnQXV0by1tb25pdG9yIGJhY2tncm91bmQgam9iIHN0YXJ0ZWQgKGNoZWNraW5nIGV2ZXJ5IDYwcyknKTtcbiAgfVxuXG4gIHN0YXRpYyBzdG9wKCk6IHZvaWQge1xuICAgIGlmIChNb25pdG9yU2VydmljZS5pbnRlcnZhbEhhbmRsZSkge1xuICAgICAgY2xlYXJJbnRlcnZhbChNb25pdG9yU2VydmljZS5pbnRlcnZhbEhhbmRsZSk7XG4gICAgICBNb25pdG9yU2VydmljZS5pbnRlcnZhbEhhbmRsZSA9IG51bGw7XG4gICAgfVxuICB9XG5cbiAgc3RhdGljIGFzeW5jIHRpY2soY2xpZW50OiBhbnksIGxvZ2dlcjogTG9nZ2VyKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgY29uc3QgY29uZmlnID0gYXdhaXQgTW9uaXRvclNlcnZpY2UuZ2V0Q29uZmlnKGNsaWVudCk7XG4gICAgaWYgKCFjb25maWcuZW5hYmxlZCkgcmV0dXJuO1xuXG4gICAgY29uc3Qgbm93ID0gRGF0ZS5ub3coKTtcbiAgICBjb25zdCBpbnRlcnZhbE1zID0gKGNvbmZpZy5pbnRlcnZhbF9taW51dGVzIHx8IDUpICogNjBfMDAwO1xuICAgIGNvbnN0IGxhc3RSdW4gPSBjb25maWcubGFzdF9ydW5fYXQgPyBuZXcgRGF0ZShjb25maWcubGFzdF9ydW5fYXQpLmdldFRpbWUoKSA6IDA7XG4gICAgaWYgKG5vdyAtIGxhc3RSdW4gPCBpbnRlcnZhbE1zKSByZXR1cm47XG5cbiAgICBpZiAoTW9uaXRvclNlcnZpY2UucnVubmluZykgcmV0dXJuO1xuICAgIE1vbml0b3JTZXJ2aWNlLnJ1bm5pbmcgPSB0cnVlO1xuXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJ1bGVzID0gTW9uaXRvclNlcnZpY2UuZWZmZWN0aXZlUnVsZXMoY29uZmlnKTtcbiAgICAgIGxvZ2dlci5pbmZvKFxuICAgICAgICBgQXV0by1tb25pdG9yOiBzY2FubmluZyB3aXRoICR7cnVsZXMubGVuZ3RofSBydWxlKHMpLCBzaW5jZT0ke2NvbmZpZy5sYXN0X3Byb2Nlc3NlZF90aW1lc3RhbXAgfHwgJ2JlZ2lubmluZyd9YCxcbiAgICAgICk7XG4gICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBNb25pdG9yU2VydmljZS5zY2FuQW5kQ3JlYXRlQ2FzZXMoY2xpZW50LCBjb25maWcsIGxvZ2dlcik7XG4gICAgICBhd2FpdCBNb25pdG9yU2VydmljZS5zYXZlQ29uZmlnKGNsaWVudCwge1xuICAgICAgICBsYXN0X3J1bl9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgICBjYXNlc19jcmVhdGVkOiAoY29uZmlnLmNhc2VzX2NyZWF0ZWQgfHwgMCkgKyByZXN1bHQuY3JlYXRlZCxcbiAgICAgIH0pO1xuICAgICAgbG9nZ2VyLmluZm8oYEF1dG8tbW9uaXRvcjogc2NhbiBkb25lLCBjcmVhdGVkPSR7cmVzdWx0LmNyZWF0ZWR9YCk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIE1vbml0b3JTZXJ2aWNlLnJ1bm5pbmcgPSBmYWxzZTtcbiAgICB9XG4gIH1cblxuICAvLyDilIDilIAgQWxlcnQgc2Nhbm5pbmcg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbiAgLyoqXG4gICAqIEZldGNoIGFsZXJ0cyBzaW5jZSB0aGUgbGFzdCBwcm9jZXNzZWQgdGltZXN0YW1wLCBtYXRjaCB0aGVtIGFnYWluc3QgdGhlXG4gICAqIHJ1bGUgc2V0LCBhbmQgY3JlYXRlIG9uZSBjYXNlIHBlciBtYXRjaGVkIGFsZXJ0LlxuICAgKi9cbiAgc3RhdGljIGFzeW5jIHNjYW5BbmRDcmVhdGVDYXNlcyhcbiAgICBjbGllbnQ6IGFueSxcbiAgICBjb25maWc6IE1vbml0b3JDb25maWcsXG4gICAgbG9nZ2VyOiBMb2dnZXIsXG4gICk6IFByb21pc2U8eyBjcmVhdGVkOiBudW1iZXI7IHBlcl9ydWxlOiBSZWNvcmQ8c3RyaW5nLCBudW1iZXI+IH0+IHtcbiAgICBjb25zdCBydWxlcyA9IE1vbml0b3JTZXJ2aWNlLmVmZmVjdGl2ZVJ1bGVzKGNvbmZpZyk7XG4gICAgY29uc3QgcGVyUnVsZTogUmVjb3JkPHN0cmluZywgbnVtYmVyPiA9IHt9O1xuICAgIGlmIChydWxlcy5sZW5ndGggPT09IDApIHtcbiAgICAgIGxvZ2dlci5pbmZvKCdBdXRvLW1vbml0b3I6IG5vIGVuYWJsZWQgcnVsZXMsIG5vdGhpbmcgdG8gZG8nKTtcbiAgICAgIHJldHVybiB7IGNyZWF0ZWQ6IDAsIHBlcl9ydWxlOiBwZXJSdWxlIH07XG4gICAgfVxuXG4gICAgY29uc3QgaGl0cyA9IGF3YWl0IE1vbml0b3JTZXJ2aWNlLmZldGNoQ2FuZGlkYXRlQWxlcnRzKGNsaWVudCwgY29uZmlnLCBydWxlcywgbG9nZ2VyKTtcblxuICAgIGlmIChoaXRzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgYXdhaXQgTW9uaXRvclNlcnZpY2Uuc2F2ZUNvbmZpZyhjbGllbnQsIHtcbiAgICAgICAgbGFzdF9wcm9jZXNzZWRfdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICB9KTtcbiAgICAgIHJldHVybiB7IGNyZWF0ZWQ6IDAsIHBlcl9ydWxlOiBwZXJSdWxlIH07XG4gICAgfVxuXG4gICAgY29uc3Qgc2luY2UgPSBNb25pdG9yU2VydmljZS5zaW5jZVRpbWVzdGFtcChjb25maWcpO1xuICAgIGxldCBjcmVhdGVkID0gMDtcbiAgICBsZXQgbGF0ZXN0VGltZXN0YW1wID0gc2luY2U7XG4gICAgY29uc3QgbWF4Q2FzZXMgPSBNYXRoLm1heCgxLCBjb25maWcubWF4X2Nhc2VzX3Blcl9zY2FuIHx8IDUwKTtcbiAgICBjb25zdCBwZXJSdWxlQ3JlYXRlZDogUmVjb3JkPHN0cmluZywgbnVtYmVyPiA9IHt9O1xuXG4gICAgLy8gQWxlcnQgSURzIGFscmVhZHkgbGlua2VkIHRvIGEgbm9uLWNsb3NlZCBjYXNlLCBzbyBhIHJlcGVhdGVkIGFsZXJ0IGRvZXNuJ3RcbiAgICAvLyBzcGF3biBhIGR1cGxpY2F0ZSBjYXNlLlxuICAgIGNvbnN0IGxpbmtlZEFsZXJ0SWRzID0gY29uZmlnLmRlZHVwZV9lbmFibGVkXG4gICAgICA/IGF3YWl0IE1vbml0b3JTZXJ2aWNlLmdldExpbmtlZEFsZXJ0SWRzRnJvbU9wZW5DYXNlcyhjbGllbnQsIGxvZ2dlcilcbiAgICAgIDogbmV3IFNldDxzdHJpbmc+KCk7XG5cbiAgICBmb3IgKGNvbnN0IGhpdCBvZiBoaXRzKSB7XG4gICAgICBjb25zdCBhbGVydCA9IGhpdC5fc291cmNlO1xuICAgICAgY29uc3QgYWxlcnRJZCA9IGhpdC5faWQ7XG5cbiAgICAgIGNvbnN0IGFsZXJ0VGltZXN0YW1wOiBzdHJpbmcgPVxuICAgICAgICBhbGVydD8udGltZXN0YW1wIHx8IGFsZXJ0Py5bJ0B0aW1lc3RhbXAnXSB8fCBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCk7XG4gICAgICBpZiAoYWxlcnRUaW1lc3RhbXAgPiBsYXRlc3RUaW1lc3RhbXApIGxhdGVzdFRpbWVzdGFtcCA9IGFsZXJ0VGltZXN0YW1wO1xuXG4gICAgICBpZiAoY3JlYXRlZCA+PSBtYXhDYXNlcykge1xuICAgICAgICBsb2dnZXIuaW5mbyhgQXV0by1tb25pdG9yOiByZWFjaGVkIG1heF9jYXNlc19wZXJfc2NhbiAoJHttYXhDYXNlc30pLCBzdG9wcGluZ2ApO1xuICAgICAgICBicmVhaztcbiAgICAgIH1cblxuICAgICAgaWYgKGxpbmtlZEFsZXJ0SWRzLmhhcyhhbGVydElkKSkgY29udGludWU7XG5cbiAgICAgIGNvbnN0IHJ1bGUgPSBmaW5kTWF0Y2hpbmdSdWxlKGFsZXJ0LCBydWxlcyk7XG4gICAgICBpZiAoIXJ1bGUpIGNvbnRpbnVlO1xuXG4gICAgICBjb25zdCBydWxlQ291bnQgPSBwZXJSdWxlQ3JlYXRlZFtydWxlLmlkXSB8fCAwO1xuICAgICAgaWYgKHJ1bGUubWF4X2Nhc2VzX3Blcl9zY2FuICYmIHJ1bGVDb3VudCA+PSBydWxlLm1heF9jYXNlc19wZXJfc2NhbikgY29udGludWU7XG5cbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IG5ld0Nhc2UgPSBhd2FpdCBNb25pdG9yU2VydmljZS5jcmVhdGVDYXNlRnJvbUFsZXJ0KGNsaWVudCwgaGl0LCBydWxlLCBsb2dnZXIpO1xuICAgICAgICBsaW5rZWRBbGVydElkcy5hZGQoYWxlcnRJZCk7XG4gICAgICAgIGNyZWF0ZWQrKztcbiAgICAgICAgcGVyUnVsZUNyZWF0ZWRbcnVsZS5pZF0gPSBydWxlQ291bnQgKyAxO1xuICAgICAgICBwZXJSdWxlW3J1bGUubmFtZV0gPSAocGVyUnVsZVtydWxlLm5hbWVdIHx8IDApICsgMTtcbiAgICAgICAgbG9nZ2VyLmluZm8oYEF1dG8tbW9uaXRvcjogY3JlYXRlZCAke25ld0Nhc2UuY2FzZV9pZH0gdmlhIHJ1bGUgXCIke3J1bGUubmFtZX1cImApO1xuICAgICAgfSBjYXRjaCAoZTogYW55KSB7XG4gICAgICAgIGxvZ2dlci53YXJuKGBBdXRvLW1vbml0b3I6IGZhaWxlZCB0byBwcm9jZXNzIGFsZXJ0ICR7YWxlcnRJZH06ICR7ZS5tZXNzYWdlfWApO1xuICAgICAgfVxuICAgIH1cblxuICAgIC8vIFBlcnNpc3QgcGVyLXJ1bGUgY291bnRlcnMgc28gdGhlIFVJIGNhbiBzaG93IHdoaWNoIHJ1bGVzIGFyZSBmaXJpbmcuXG4gICAgaWYgKGNvbmZpZy5ydWxlcyAmJiBjb25maWcucnVsZXMubGVuZ3RoID4gMCAmJiBPYmplY3Qua2V5cyhwZXJSdWxlQ3JlYXRlZCkubGVuZ3RoID4gMCkge1xuICAgICAgY29uc3QgdXBkYXRlZFJ1bGVzID0gY29uZmlnLnJ1bGVzLm1hcCgocikgPT5cbiAgICAgICAgcGVyUnVsZUNyZWF0ZWRbci5pZF1cbiAgICAgICAgICA/IHsgLi4uciwgY2FzZXNfY3JlYXRlZDogKHIuY2FzZXNfY3JlYXRlZCB8fCAwKSArIHBlclJ1bGVDcmVhdGVkW3IuaWRdIH1cbiAgICAgICAgICA6IHIsXG4gICAgICApO1xuICAgICAgYXdhaXQgTW9uaXRvclNlcnZpY2Uuc2F2ZUNvbmZpZyhjbGllbnQsIHtcbiAgICAgICAgcnVsZXM6IHVwZGF0ZWRSdWxlcyxcbiAgICAgICAgbGFzdF9wcm9jZXNzZWRfdGltZXN0YW1wOiBsYXRlc3RUaW1lc3RhbXAsXG4gICAgICB9KTtcbiAgICB9IGVsc2Uge1xuICAgICAgYXdhaXQgTW9uaXRvclNlcnZpY2Uuc2F2ZUNvbmZpZyhjbGllbnQsIHsgbGFzdF9wcm9jZXNzZWRfdGltZXN0YW1wOiBsYXRlc3RUaW1lc3RhbXAgfSk7XG4gICAgfVxuXG4gICAgcmV0dXJuIHsgY3JlYXRlZCwgcGVyX3J1bGU6IHBlclJ1bGUgfTtcbiAgfVxuXG4gIC8qKiBGaXJzdCBydW4gbG9va3MgYmFjayAyNCBob3VycyBzbyBwcmUtZXhpc3RpbmcgYWxlcnRzIGFyZSBwaWNrZWQgdXAuICovXG4gIHByaXZhdGUgc3RhdGljIHNpbmNlVGltZXN0YW1wKGNvbmZpZzogTW9uaXRvckNvbmZpZyk6IHN0cmluZyB7XG4gICAgcmV0dXJuIChcbiAgICAgIGNvbmZpZy5sYXN0X3Byb2Nlc3NlZF90aW1lc3RhbXAgfHwgbmV3IERhdGUoRGF0ZS5ub3coKSAtIDI0ICogNjAgKiA2MF8wMDApLnRvSVNPU3RyaW5nKClcbiAgICApO1xuICB9XG5cbiAgcHJpdmF0ZSBzdGF0aWMgYXN5bmMgZmV0Y2hDYW5kaWRhdGVBbGVydHMoXG4gICAgY2xpZW50OiBhbnksXG4gICAgY29uZmlnOiBNb25pdG9yQ29uZmlnLFxuICAgIHJ1bGVzOiBNb25pdG9yUnVsZVtdLFxuICAgIGxvZ2dlcjogTG9nZ2VyLFxuICApOiBQcm9taXNlPGFueVtdPiB7XG4gICAgY29uc3Qgc2luY2UgPSBNb25pdG9yU2VydmljZS5zaW5jZVRpbWVzdGFtcChjb25maWcpO1xuXG4gICAgLy8gV2F6dWggYWxlcnRzIGNhcnJ5IGVpdGhlciBcInRpbWVzdGFtcFwiIG9yIFwiQHRpbWVzdGFtcFwiIGRlcGVuZGluZyBvbiB0aGVcbiAgICAvLyB2ZXJzaW9uLCBzbyBhY2NlcHQgd2hpY2hldmVyIGlzIHByZXNlbnQuXG4gICAgY29uc3QgdGltZVdpbmRvdyA9IHtcbiAgICAgIGJvb2w6IHtcbiAgICAgICAgc2hvdWxkOiBbXG4gICAgICAgICAgeyByYW5nZTogeyB0aW1lc3RhbXA6IHsgZ3Q6IHNpbmNlIH0gfSB9LFxuICAgICAgICAgIHsgcmFuZ2U6IHsgJ0B0aW1lc3RhbXAnOiB7IGd0OiBzaW5jZSB9IH0gfSxcbiAgICAgICAgXSxcbiAgICAgICAgbWluaW11bV9zaG91bGRfbWF0Y2g6IDEsXG4gICAgICB9LFxuICAgIH07XG5cbiAgICBjb25zdCBmaWx0ZXI6IGFueVtdID0gW3RpbWVXaW5kb3ddO1xuICAgIGNvbnN0IHByZUZpbHRlciA9IGJ1aWxkUnVsZVNldFF1ZXJ5KHJ1bGVzKTtcbiAgICBpZiAocHJlRmlsdGVyKSB7XG4gICAgICBmaWx0ZXIucHVzaChwcmVGaWx0ZXIpO1xuICAgIH0gZWxzZSB7XG4gICAgICBsb2dnZXIuaW5mbyhcbiAgICAgICAgJ0F1dG8tbW9uaXRvcjogcnVsZSBzZXQgY2Fubm90IGJlIHByZS1maWx0ZXJlZCBpbiBPcGVuU2VhcmNoLCBzbyB0aGUgZnVsbCB3aW5kb3cgaXMgZXZhbHVhdGVkIGluIG1lbW9yeScsXG4gICAgICApO1xuICAgIH1cblxuICAgIGNvbnN0IHNpemUgPSBNYXRoLm1pbihNQVhfU0NBTl9ISVRTLCBNYXRoLm1heCg1MCwgKGNvbmZpZy5tYXhfY2FzZXNfcGVyX3NjYW4gfHwgNTApICogNSkpO1xuXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHsgYm9keTogcmVzdWx0IH0gPSBhd2FpdCBjbGllbnQuc2VhcmNoKHtcbiAgICAgICAgaW5kZXg6IFdBWlVIX0FMRVJUU19JTkRFWF9QQVRURVJOLFxuICAgICAgICBib2R5OiB7XG4gICAgICAgICAgcXVlcnk6IHsgYm9vbDogeyBmaWx0ZXIgfSB9LFxuICAgICAgICAgIHNvcnQ6IFt7IHRpbWVzdGFtcDogeyBvcmRlcjogJ2FzYycsIHVubWFwcGVkX3R5cGU6ICdkYXRlJyB9IH1dLFxuICAgICAgICAgIHNpemUsXG4gICAgICAgIH0sXG4gICAgICAgIGlnbm9yZV91bmF2YWlsYWJsZTogdHJ1ZSxcbiAgICAgIH0pO1xuICAgICAgY29uc3QgaGl0cyA9IHJlc3VsdC5oaXRzPy5oaXRzIHx8IFtdO1xuICAgICAgbG9nZ2VyLmluZm8oYEF1dG8tbW9uaXRvcjogZmV0Y2hlZCAke2hpdHMubGVuZ3RofSBjYW5kaWRhdGUgYWxlcnQocykgc2luY2UgJHtzaW5jZX1gKTtcbiAgICAgIHJldHVybiBoaXRzO1xuICAgIH0gY2F0Y2ggKGU6IGFueSkge1xuICAgICAgbG9nZ2VyLndhcm4oYEF1dG8tbW9uaXRvcjogYWxlcnQgc2VhcmNoIGZhaWxlZDogJHtlLm1lc3NhZ2V9YCk7XG4gICAgICByZXR1cm4gW107XG4gICAgfVxuICB9XG5cbiAgLyoqIENyZWF0ZSBhIGNhc2UgZm9yIG9uZSBhbGVydCB1c2luZyB0aGUgbWF0Y2hlZCBydWxlJ3MgY2FzZSBhdHRyaWJ1dGVzLiAqL1xuICBwcml2YXRlIHN0YXRpYyBhc3luYyBjcmVhdGVDYXNlRnJvbUFsZXJ0KFxuICAgIGNsaWVudDogYW55LFxuICAgIGhpdDogYW55LFxuICAgIHJ1bGU6IE1vbml0b3JSdWxlLFxuICAgIGxvZ2dlcjogTG9nZ2VyLFxuICApOiBQcm9taXNlPGFueT4ge1xuICAgIGNvbnN0IGFsZXJ0ID0gaGl0Ll9zb3VyY2U7XG4gICAgY29uc3QgYWxlcnRJZCA9IGhpdC5faWQ7XG4gICAgY29uc3QgcnVsZURlc2NyaXB0aW9uID0gYWxlcnQ/LnJ1bGU/LmRlc2NyaXB0aW9uIHx8ICdTZWN1cml0eSBBbGVydCc7XG4gICAgY29uc3QgcnVsZUxldmVsID0gTnVtYmVyKGFsZXJ0Py5ydWxlPy5sZXZlbCkgfHwgMDtcbiAgICBjb25zdCB3YXp1aFJ1bGVJZCA9IFN0cmluZyhhbGVydD8ucnVsZT8uaWQgfHwgJycpO1xuXG4gICAgY29uc3QgdGFncyA9IEFycmF5LmZyb20oXG4gICAgICBuZXcgU2V0KFtcbiAgICAgICAgJ2F1dG8tY3JlYXRlZCcsXG4gICAgICAgIGBsZXZlbC0ke3J1bGVMZXZlbH1gLFxuICAgICAgICAuLi4od2F6dWhSdWxlSWQgPyBbYHJ1bGUtJHt3YXp1aFJ1bGVJZH1gXSA6IFtdKSxcbiAgICAgICAgLi4uKHJ1bGUudGFncyB8fCBbXSksXG4gICAgICAgIGBtb25pdG9yLXJ1bGUtJHtydWxlLmlkfWAsXG4gICAgICBdKSxcbiAgICApO1xuXG4gICAgY29uc3QgbmV3Q2FzZSA9IGF3YWl0IENhc2VTZXJ2aWNlLmNyZWF0ZUNhc2UoXG4gICAgICBjbGllbnQsXG4gICAgICB7XG4gICAgICAgIHRpdGxlOiAnUExBQ0VIT0xERVInLFxuICAgICAgICBkZXNjcmlwdGlvbjogTW9uaXRvclNlcnZpY2UuYnVpbGREZXNjcmlwdGlvbihhbGVydCwgcnVsZSksXG4gICAgICAgIHNldmVyaXR5OiByZXNvbHZlU2V2ZXJpdHkocnVsZSwgYWxlcnQpLFxuICAgICAgICBwcmlvcml0eTogcnVsZS5wcmlvcml0eSxcbiAgICAgICAgY2F0ZWdvcnk6IHJ1bGUuY2F0ZWdvcnksXG4gICAgICAgIHRscDogcnVsZS50bHAsXG4gICAgICAgIHRhZ3MsXG4gICAgICAgIGFzc2lnbmVlOiBydWxlLmFzc2lnbmVlIHx8IG51bGwsXG4gICAgICB9LFxuICAgICAgJ2F1dG8tbW9uaXRvcicsXG4gICAgKTtcblxuICAgIGNvbnN0IHByZXR0eVRpdGxlID0gYCR7bmV3Q2FzZS5jYXNlX2lkfTogJHtydWxlRGVzY3JpcHRpb259YDtcbiAgICBjb25zdCBsaW5rZWRBbGVydCA9IE1vbml0b3JTZXJ2aWNlLmJ1aWxkTGlua2VkQWxlcnQoaGl0KTtcblxuICAgIGF3YWl0IGNsaWVudC51cGRhdGUoe1xuICAgICAgaW5kZXg6IENBU0VfSU5ERVgsXG4gICAgICBpZDogbmV3Q2FzZS5pZCEsXG4gICAgICBib2R5OiB7XG4gICAgICAgIGRvYzoge1xuICAgICAgICAgIHRpdGxlOiBwcmV0dHlUaXRsZSxcbiAgICAgICAgICBsaW5rZWRfYWxlcnRzOiBbbGlua2VkQWxlcnRdLFxuICAgICAgICAgIC8vIEluZGV4ZWQgZGVkdXAga2V5OiBjdXN0b21fZmllbGRzIGlzIG1hcHBlZCB3aXRoIGVuYWJsZWQ6ZmFsc2UuXG4gICAgICAgICAgdGFnczogWy4uLnRhZ3MsIGBhdXRvLWFsZXJ0LSR7YWxlcnRJZH1gXSxcbiAgICAgICAgICB1cGRhdGVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgICAgcmV0cnlfb25fY29uZmxpY3Q6IDMsXG4gICAgfSk7XG5cbiAgICBjb25zdCBjYXNlUmVmID0geyAuLi5uZXdDYXNlLCB0aXRsZTogcHJldHR5VGl0bGUgfTtcblxuICAgIGF3YWl0IE5vdGlmaWNhdGlvblNlcnZpY2UuZGlzcGF0Y2goXG4gICAgICBjbGllbnQsXG4gICAgICB7XG4gICAgICAgIGV2ZW50OiBydWxlLmFzc2lnbmVlID8gJ2Nhc2VfYXNzaWduZWQnIDogJ2Nhc2VfY3JlYXRlZCcsXG4gICAgICAgIHJlY2lwaWVudHM6IFtydWxlLmFzc2lnbmVlXSxcbiAgICAgICAgdGl0bGU6IGBDYXNlICR7bmV3Q2FzZS5jYXNlX2lkfSBhdXRvLWNyZWF0ZWRgLFxuICAgICAgICBtZXNzYWdlOiBgJHtydWxlRGVzY3JpcHRpb259IChydWxlIFwiJHtydWxlLm5hbWV9XCIsIHByaW9yaXR5ICR7cnVsZS5wcmlvcml0eX0pYCxcbiAgICAgICAgY2FzZVJlZixcbiAgICAgICAgYWN0b3I6ICdhdXRvLW1vbml0b3InLFxuICAgICAgICBjb250ZXh0OiB7IG1vbml0b3JfcnVsZTogcnVsZS5uYW1lLCBhbGVydF9pZDogYWxlcnRJZCwgcnVsZV9sZXZlbDogcnVsZUxldmVsIH0sXG4gICAgICB9LFxuICAgICAgbG9nZ2VyLFxuICAgICk7XG5cbiAgICByZXR1cm4gY2FzZVJlZjtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIHRoZSBzZXQgb2YgYWxlcnQgSURzIGFscmVhZHkgbGlua2VkIGluc2lkZSBhbnkgb3Blbi9pbi1wcm9ncmVzcy93YWl0aW5nIGNhc2UuXG4gICAqIFVzZWQgZm9yIGRlZHVwbGljYXRpb24gaW5zdGVhZCBvZiBjdXN0b21fZmllbGRzICh3aGljaCBpcyBub3QgaW5kZXhlZCkuXG4gICAqL1xuICBwcml2YXRlIHN0YXRpYyBhc3luYyBnZXRMaW5rZWRBbGVydElkc0Zyb21PcGVuQ2FzZXMoXG4gICAgY2xpZW50OiBhbnksXG4gICAgbG9nZ2VyOiBMb2dnZXIsXG4gICk6IFByb21pc2U8U2V0PHN0cmluZz4+IHtcbiAgICBjb25zdCBpZHMgPSBuZXcgU2V0PHN0cmluZz4oKTtcbiAgICB0cnkge1xuICAgICAgY29uc3QgeyBib2R5OiByZXN1bHQgfSA9IGF3YWl0IGNsaWVudC5zZWFyY2goe1xuICAgICAgICBpbmRleDogQ0FTRV9JTkRFWCxcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIHF1ZXJ5OiB7XG4gICAgICAgICAgICBib29sOiB7XG4gICAgICAgICAgICAgIG11c3Q6IFtcbiAgICAgICAgICAgICAgICB7IHRlcm1zOiB7IHN0YXR1czogWydvcGVuJywgJ2luX3Byb2dyZXNzJywgJ3dhaXRpbmcnXSB9IH0sXG4gICAgICAgICAgICAgICAgeyB0ZXJtOiB7IHRhZ3M6ICdhdXRvLWNyZWF0ZWQnIH0gfSxcbiAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgICBfc291cmNlOiBbJ2xpbmtlZF9hbGVydHMnXSxcbiAgICAgICAgICBzaXplOiA1MDAsXG4gICAgICAgIH0sXG4gICAgICB9KTtcbiAgICAgIGZvciAoY29uc3QgaGl0IG9mIHJlc3VsdC5oaXRzPy5oaXRzIHx8IFtdKSB7XG4gICAgICAgIGZvciAoY29uc3QgbGEgb2YgaGl0Ll9zb3VyY2U/LmxpbmtlZF9hbGVydHMgfHwgW10pIHtcbiAgICAgICAgICBpZiAobGEuYWxlcnRfaWQpIGlkcy5hZGQobGEuYWxlcnRfaWQpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZTogYW55KSB7XG4gICAgICBsb2dnZXIud2FybihgQXV0by1tb25pdG9yOiBjb3VsZCBub3QgZmV0Y2ggb3BlbiBjYXNlIGFsZXJ0IElEczogJHtlLm1lc3NhZ2V9YCk7XG4gICAgfVxuICAgIHJldHVybiBpZHM7XG4gIH1cblxuICBwcml2YXRlIHN0YXRpYyBidWlsZExpbmtlZEFsZXJ0KGhpdDogYW55KTogYW55IHtcbiAgICBjb25zdCBhbGVydCA9IGhpdC5fc291cmNlO1xuICAgIHJldHVybiB7XG4gICAgICBhbGVydF9pZDogaGl0Ll9pZCxcbiAgICAgIGluZGV4OiBoaXQuX2luZGV4IHx8IFdBWlVIX0FMRVJUU19JTkRFWF9QQVRURVJOLFxuICAgICAgcnVsZV9pZDogcGFyc2VJbnQoYWxlcnQ/LnJ1bGU/LmlkIHx8ICcwJywgMTApLFxuICAgICAgcnVsZV9kZXNjcmlwdGlvbjogYWxlcnQ/LnJ1bGU/LmRlc2NyaXB0aW9uIHx8ICcnLFxuICAgICAgcnVsZV9sZXZlbDogYWxlcnQ/LnJ1bGU/LmxldmVsIHx8IDAsXG4gICAgICBydWxlX2dyb3VwczogYWxlcnQ/LnJ1bGU/Lmdyb3VwcyB8fCBbXSxcbiAgICAgIGFnZW50X2lkOiBhbGVydD8uYWdlbnQ/LmlkIHx8ICcnLFxuICAgICAgYWdlbnRfbmFtZTogYWxlcnQ/LmFnZW50Py5uYW1lIHx8ICcnLFxuICAgICAgdGltZXN0YW1wOiBhbGVydD8udGltZXN0YW1wIHx8IGFsZXJ0Py5bJ0B0aW1lc3RhbXAnXSB8fCBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICBmdWxsX2xvZzogYWxlcnQ/LmZ1bGxfbG9nIHx8ICcnLFxuICAgIH07XG4gIH1cblxuICBwcml2YXRlIHN0YXRpYyBidWlsZERlc2NyaXB0aW9uKGFsZXJ0OiBhbnksIHJ1bGU6IE1vbml0b3JSdWxlKTogc3RyaW5nIHtcbiAgICBjb25zdCBydWxlSWQgPSBhbGVydD8ucnVsZT8uaWQgfHwgJ04vQSc7XG4gICAgY29uc3QgcnVsZURlc2MgPSBhbGVydD8ucnVsZT8uZGVzY3JpcHRpb24gfHwgJ04vQSc7XG4gICAgY29uc3QgcnVsZUxldmVsID0gYWxlcnQ/LnJ1bGU/LmxldmVsID8/ICdOL0EnO1xuICAgIGNvbnN0IGFnZW50TmFtZSA9IGFsZXJ0Py5hZ2VudD8ubmFtZSB8fCAnVW5rbm93bic7XG4gICAgY29uc3QgYWdlbnRJZCA9IGFsZXJ0Py5hZ2VudD8uaWQgfHwgJ04vQSc7XG4gICAgY29uc3QgZ3JvdXBzID0gKGFsZXJ0Py5ydWxlPy5ncm91cHMgfHwgW10pLmpvaW4oJywgJykgfHwgJ04vQSc7XG4gICAgY29uc3QgcmF3VHMgPSBhbGVydD8udGltZXN0YW1wIHx8IGFsZXJ0Py5bJ0B0aW1lc3RhbXAnXTtcbiAgICBjb25zdCB0aW1lc3RhbXAgPSByYXdUc1xuICAgICAgPyBuZXcgRGF0ZShyYXdUcykudG9JU09TdHJpbmcoKS5yZXBsYWNlKCdUJywgJyAnKS5yZXBsYWNlKC9cXC4uKiQvLCAnIFVUQycpXG4gICAgICA6ICdOL0EnO1xuXG4gICAgY29uc3QgbGluZXM6IHN0cmluZ1tdID0gW1xuICAgICAgYFRoaXMgY2FzZSB3YXMgYXV0b21hdGljYWxseSBjcmVhdGVkIGJ5IHRoZSBXYXp1aCBDYXNlIE1vbml0b3IuYCxcbiAgICAgIGBgLFxuICAgICAgYCMjIE1hdGNoZWQgTW9uaXRvciBSdWxlYCxcbiAgICAgIGBgLFxuICAgICAgYC0gKipSdWxlIG5hbWU6KiogJHtydWxlLm5hbWV9YCxcbiAgICAgIGAtICoqQ3JpdGVyaWE6KiogXFxgJHtkZXNjcmliZU5vZGUocnVsZS5jcml0ZXJpYSkgfHwgJ2FueSBhbGVydCd9XFxgYCxcbiAgICAgIGAtICoqQXNzaWduZWQgcHJpb3JpdHk6KiogJHtydWxlLnByaW9yaXR5fWAsXG4gICAgICBgYCxcbiAgICAgIGAjIyBBbGVydCBEZXRhaWxzYCxcbiAgICAgIGBgLFxuICAgICAgYC0gKipSdWxlIElEOioqICR7cnVsZUlkfWAsXG4gICAgICBgLSAqKkRlc2NyaXB0aW9uOioqICR7cnVsZURlc2N9YCxcbiAgICAgIGAtICoqTGV2ZWw6KiogJHtydWxlTGV2ZWx9YCxcbiAgICAgIGAtICoqR3JvdXBzOioqICR7Z3JvdXBzfWAsXG4gICAgICBgLSAqKkFnZW50OioqICR7YWdlbnROYW1lfSAoSUQ6ICR7YWdlbnRJZH0pYCxcbiAgICAgIGAtICoqRGV0ZWN0ZWQ6KiogJHt0aW1lc3RhbXB9YCxcbiAgICBdO1xuXG4gICAgaWYgKGFsZXJ0Py5mdWxsX2xvZykge1xuICAgICAgY29uc3QgbG9nID0gU3RyaW5nKGFsZXJ0LmZ1bGxfbG9nKS50cmltKCkuc3Vic3RyaW5nKDAsIDYwMCk7XG4gICAgICBsaW5lcy5wdXNoKGBgLCBgIyMgUmF3IExvZ2AsIGBgLCBgXFxgXFxgXFxgYCwgbG9nLCBgXFxgXFxgXFxgYCk7XG4gICAgfVxuXG4gICAgcmV0dXJuIGxpbmVzLmpvaW4oJ1xcbicpO1xuICB9XG5cbiAgLy8g4pSA4pSAIFJ1bGUgdGVzdGluZyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuICAvKipcbiAgICogRHJ5LXJ1biBhIHJ1bGUgc2V0IGFnYWluc3QgcmVjZW50IGFsZXJ0cyB3aXRob3V0IGNyZWF0aW5nIGFueSBjYXNlcy5cbiAgICogUG93ZXJzIHRoZSBcIlRlc3QgcnVsZXNcIiBidXR0b24gaW4gdGhlIEF1dG8gTW9uaXRvciBVSS5cbiAgICovXG4gIHN0YXRpYyBhc3luYyB0ZXN0UnVsZXMoXG4gICAgY2xpZW50OiBhbnksXG4gICAgcnVsZXM6IE1vbml0b3JSdWxlW10sXG4gICAgb3B0czogeyBob3Vycz86IG51bWJlcjsgc2l6ZT86IG51bWJlciB9ID0ge30sXG4gICk6IFByb21pc2U8e1xuICAgIHNjYW5uZWQ6IG51bWJlcjtcbiAgICBtYXRjaGVzOiBBcnJheTx7XG4gICAgICBhbGVydF9pZDogc3RyaW5nO1xuICAgICAgdGltZXN0YW1wOiBzdHJpbmc7XG4gICAgICBydWxlX2lkOiBzdHJpbmc7XG4gICAgICBydWxlX2Rlc2NyaXB0aW9uOiBzdHJpbmc7XG4gICAgICBydWxlX2xldmVsOiBudW1iZXI7XG4gICAgICBhZ2VudF9uYW1lOiBzdHJpbmc7XG4gICAgICBtYXRjaGVkX3J1bGU6IHN0cmluZztcbiAgICAgIHByaW9yaXR5OiBzdHJpbmc7XG4gICAgICBzZXZlcml0eTogc3RyaW5nO1xuICAgIH0+O1xuICAgIHBlcl9ydWxlOiBSZWNvcmQ8c3RyaW5nLCBudW1iZXI+O1xuICB9PiB7XG4gICAgY29uc3QgaG91cnMgPSBNYXRoLm1pbihvcHRzLmhvdXJzIHx8IDI0LCAxNjgpO1xuICAgIGNvbnN0IHNpemUgPSBNYXRoLm1pbihvcHRzLnNpemUgfHwgMjAwLCBNQVhfU0NBTl9ISVRTKTtcbiAgICBjb25zdCBzaW5jZSA9IG5ldyBEYXRlKERhdGUubm93KCkgLSBob3VycyAqIDYwICogNjBfMDAwKS50b0lTT1N0cmluZygpO1xuXG4gICAgY29uc3QgZmlsdGVyOiBhbnlbXSA9IFtcbiAgICAgIHtcbiAgICAgICAgYm9vbDoge1xuICAgICAgICAgIHNob3VsZDogW1xuICAgICAgICAgICAgeyByYW5nZTogeyB0aW1lc3RhbXA6IHsgZ3Q6IHNpbmNlIH0gfSB9LFxuICAgICAgICAgICAgeyByYW5nZTogeyAnQHRpbWVzdGFtcCc6IHsgZ3Q6IHNpbmNlIH0gfSB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICAgbWluaW11bV9zaG91bGRfbWF0Y2g6IDEsXG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgIF07XG4gICAgY29uc3QgcHJlRmlsdGVyID0gYnVpbGRSdWxlU2V0UXVlcnkocnVsZXMpO1xuICAgIGlmIChwcmVGaWx0ZXIpIGZpbHRlci5wdXNoKHByZUZpbHRlcik7XG5cbiAgICBjb25zdCB7IGJvZHk6IHJlc3VsdCB9ID0gYXdhaXQgY2xpZW50LnNlYXJjaCh7XG4gICAgICBpbmRleDogV0FaVUhfQUxFUlRTX0lOREVYX1BBVFRFUk4sXG4gICAgICBib2R5OiB7XG4gICAgICAgIHF1ZXJ5OiB7IGJvb2w6IHsgZmlsdGVyIH0gfSxcbiAgICAgICAgc29ydDogW3sgdGltZXN0YW1wOiB7IG9yZGVyOiAnZGVzYycsIHVubWFwcGVkX3R5cGU6ICdkYXRlJyB9IH1dLFxuICAgICAgICBzaXplLFxuICAgICAgfSxcbiAgICAgIGlnbm9yZV91bmF2YWlsYWJsZTogdHJ1ZSxcbiAgICB9KTtcblxuICAgIGNvbnN0IGhpdHMgPSByZXN1bHQuaGl0cz8uaGl0cyB8fCBbXTtcbiAgICBjb25zdCBtYXRjaGVzOiBhbnlbXSA9IFtdO1xuICAgIGNvbnN0IHBlclJ1bGU6IFJlY29yZDxzdHJpbmcsIG51bWJlcj4gPSB7fTtcblxuICAgIGZvciAoY29uc3QgaGl0IG9mIGhpdHMpIHtcbiAgICAgIGNvbnN0IGFsZXJ0ID0gaGl0Ll9zb3VyY2U7XG4gICAgICBjb25zdCBydWxlID0gZmluZE1hdGNoaW5nUnVsZShhbGVydCwgcnVsZXMpO1xuICAgICAgaWYgKCFydWxlKSBjb250aW51ZTtcbiAgICAgIHBlclJ1bGVbcnVsZS5uYW1lXSA9IChwZXJSdWxlW3J1bGUubmFtZV0gfHwgMCkgKyAxO1xuICAgICAgaWYgKG1hdGNoZXMubGVuZ3RoIDwgNTApIHtcbiAgICAgICAgbWF0Y2hlcy5wdXNoKHtcbiAgICAgICAgICBhbGVydF9pZDogaGl0Ll9pZCxcbiAgICAgICAgICB0aW1lc3RhbXA6IGFsZXJ0Py50aW1lc3RhbXAgfHwgYWxlcnQ/LlsnQHRpbWVzdGFtcCddIHx8ICcnLFxuICAgICAgICAgIHJ1bGVfaWQ6IFN0cmluZyhhbGVydD8ucnVsZT8uaWQgfHwgJycpLFxuICAgICAgICAgIHJ1bGVfZGVzY3JpcHRpb246IGFsZXJ0Py5ydWxlPy5kZXNjcmlwdGlvbiB8fCAnJyxcbiAgICAgICAgICBydWxlX2xldmVsOiBOdW1iZXIoYWxlcnQ/LnJ1bGU/LmxldmVsKSB8fCAwLFxuICAgICAgICAgIGFnZW50X25hbWU6IGFsZXJ0Py5hZ2VudD8ubmFtZSB8fCAnJyxcbiAgICAgICAgICBtYXRjaGVkX3J1bGU6IHJ1bGUubmFtZSxcbiAgICAgICAgICBwcmlvcml0eTogcnVsZS5wcmlvcml0eSxcbiAgICAgICAgICBzZXZlcml0eTogcmVzb2x2ZVNldmVyaXR5KHJ1bGUsIGFsZXJ0KSxcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIHsgc2Nhbm5lZDogaGl0cy5sZW5ndGgsIG1hdGNoZXMsIHBlcl9ydWxlOiBwZXJSdWxlIH07XG4gIH1cbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBZUEsSUFBQUEsVUFBQSxHQUFBQyxPQUFBO0FBTUEsSUFBQUMsYUFBQSxHQUFBRCxPQUFBO0FBQ0EsSUFBQUUscUJBQUEsR0FBQUYsT0FBQTtBQUNBLElBQUFHLFlBQUEsR0FBQUgsT0FBQTtBQU11QixTQUFBSSxnQkFBQUMsQ0FBQSxFQUFBQyxDQUFBLEVBQUFDLENBQUEsWUFBQUQsQ0FBQSxHQUFBRSxjQUFBLENBQUFGLENBQUEsTUFBQUQsQ0FBQSxHQUFBSSxNQUFBLENBQUFDLGNBQUEsQ0FBQUwsQ0FBQSxFQUFBQyxDQUFBLElBQUFLLEtBQUEsRUFBQUosQ0FBQSxFQUFBSyxVQUFBLE1BQUFDLFlBQUEsTUFBQUMsUUFBQSxVQUFBVCxDQUFBLENBQUFDLENBQUEsSUFBQUMsQ0FBQSxFQUFBRixDQUFBO0FBQUEsU0FBQUcsZUFBQUQsQ0FBQSxRQUFBUSxDQUFBLEdBQUFDLFlBQUEsQ0FBQVQsQ0FBQSx1Q0FBQVEsQ0FBQSxHQUFBQSxDQUFBLEdBQUFBLENBQUE7QUFBQSxTQUFBQyxhQUFBVCxDQUFBLEVBQUFELENBQUEsMkJBQUFDLENBQUEsS0FBQUEsQ0FBQSxTQUFBQSxDQUFBLE1BQUFGLENBQUEsR0FBQUUsQ0FBQSxDQUFBVSxNQUFBLENBQUFDLFdBQUEsa0JBQUFiLENBQUEsUUFBQVUsQ0FBQSxHQUFBVixDQUFBLENBQUFjLElBQUEsQ0FBQVosQ0FBQSxFQUFBRCxDQUFBLHVDQUFBUyxDQUFBLFNBQUFBLENBQUEsWUFBQUssU0FBQSx5RUFBQWQsQ0FBQSxHQUFBZSxNQUFBLEdBQUFDLE1BQUEsRUFBQWYsQ0FBQSxLQTdCdkI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFxQkEsTUFBTWdCLGFBQWEsR0FBRyxnQkFBZ0I7O0FBRXRDO0FBQ0EsTUFBTUMsYUFBYSxHQUFHLEdBQUc7QUFFekIsTUFBTUMsY0FBNkIsR0FBRztFQUNwQ0MsT0FBTyxFQUFFLEtBQUs7RUFDZEMsU0FBUyxFQUFFLEVBQUU7RUFDYkMsZ0JBQWdCLEVBQUUsQ0FBQztFQUNuQkMsZ0JBQWdCLEVBQUUsSUFBSTtFQUN0QkMsZ0JBQWdCLEVBQUUsT0FBTztFQUN6QkMsS0FBSyxFQUFFLEVBQUU7RUFDVEMsY0FBYyxFQUFFLElBQUk7RUFDcEJDLGtCQUFrQixFQUFFLEVBQUU7RUFDdEJDLFdBQVcsRUFBRSxJQUFJO0VBQ2pCQyx3QkFBd0IsRUFBRSxJQUFJO0VBQzlCQyxhQUFhLEVBQUUsQ0FBQztFQUNoQkMsVUFBVSxFQUFFLElBQUlDLElBQUksQ0FBQyxDQUFDLENBQUNDLFdBQVcsQ0FBQztBQUNyQyxDQUFDO0FBRU0sTUFBTUMsY0FBYyxDQUFDO0VBSTFCOztFQUVBLGFBQWFDLGlCQUFpQkEsQ0FBQ0MsTUFBVyxFQUFpQjtJQUN6RCxJQUFJO01BQ0YsTUFBTTtRQUFFQztNQUFLLENBQUMsR0FBRyxNQUFNRCxNQUFNLENBQUNFLE9BQU8sQ0FBQ0MsTUFBTSxDQUFDO1FBQUVDLEtBQUssRUFBRUM7TUFBcUIsQ0FBQyxDQUFDO01BQzdFLElBQUksQ0FBQ0osSUFBSSxFQUFFO1FBQ1QsTUFBTUQsTUFBTSxDQUFDRSxPQUFPLENBQUNJLE1BQU0sQ0FBQztVQUMxQkYsS0FBSyxFQUFFQywrQkFBb0I7VUFDM0JKLElBQUksRUFBRTtZQUNKTSxRQUFRLEVBQUU7Y0FBRUMsZ0JBQWdCLEVBQUUsQ0FBQztjQUFFQyxrQkFBa0IsRUFBRTtZQUFFLENBQUM7WUFDeERDLFFBQVEsRUFBRTtjQUNSO2NBQ0E7Y0FDQTtjQUNBQyxPQUFPLEVBQUUsS0FBSztjQUNkQyxVQUFVLEVBQUU7Z0JBQ1Y1QixPQUFPLEVBQUU7a0JBQUU2QixJQUFJLEVBQUU7Z0JBQVUsQ0FBQztnQkFDNUI1QixTQUFTLEVBQUU7a0JBQUU0QixJQUFJLEVBQUU7Z0JBQVUsQ0FBQztnQkFDOUIzQixnQkFBZ0IsRUFBRTtrQkFBRTJCLElBQUksRUFBRTtnQkFBVSxDQUFDO2dCQUNyQzFCLGdCQUFnQixFQUFFO2tCQUFFMEIsSUFBSSxFQUFFO2dCQUFVLENBQUM7Z0JBQ3JDekIsZ0JBQWdCLEVBQUU7a0JBQUV5QixJQUFJLEVBQUU7Z0JBQVUsQ0FBQztnQkFDckN2QixjQUFjLEVBQUU7a0JBQUV1QixJQUFJLEVBQUU7Z0JBQVUsQ0FBQztnQkFDbkN0QixrQkFBa0IsRUFBRTtrQkFBRXNCLElBQUksRUFBRTtnQkFBVSxDQUFDO2dCQUN2Q3JCLFdBQVcsRUFBRTtrQkFBRXFCLElBQUksRUFBRTtnQkFBTyxDQUFDO2dCQUM3QnBCLHdCQUF3QixFQUFFO2tCQUFFb0IsSUFBSSxFQUFFO2dCQUFPLENBQUM7Z0JBQzFDbkIsYUFBYSxFQUFFO2tCQUFFbUIsSUFBSSxFQUFFO2dCQUFPLENBQUM7Z0JBQy9CbEIsVUFBVSxFQUFFO2tCQUFFa0IsSUFBSSxFQUFFO2dCQUFPO2NBQzdCO1lBQ0Y7VUFDRjtRQUNGLENBQUMsQ0FBQztNQUNKO0lBQ0YsQ0FBQyxDQUFDLE9BQU9sRCxDQUFDLEVBQUUsQ0FBQztFQUNmO0VBRUEsYUFBYW1ELFNBQVNBLENBQUNkLE1BQVcsRUFBMEI7SUFDMUQsSUFBSTtNQUFBLElBQUFlLGFBQUE7TUFDRixNQUFNO1FBQUVkO01BQUssQ0FBQyxHQUFHLE1BQU1ELE1BQU0sQ0FBQ2dCLEdBQUcsQ0FBQztRQUFFWixLQUFLLEVBQUVDLCtCQUFvQjtRQUFFWSxFQUFFLEVBQUVwQztNQUFjLENBQUMsQ0FBQztNQUNyRjtNQUNBO01BQ0EsT0FBTztRQUFFLEdBQUdFLGNBQWM7UUFBRSxJQUFJa0IsSUFBSSxDQUFDaUIsT0FBTyxJQUFJLENBQUMsQ0FBQyxDQUFDO1FBQUU3QixLQUFLLEVBQUUsRUFBQTBCLGFBQUEsR0FBQWQsSUFBSSxDQUFDaUIsT0FBTyxjQUFBSCxhQUFBLHVCQUFaQSxhQUFBLENBQWMxQixLQUFLLEtBQUk7TUFBRyxDQUFDO0lBQ3pGLENBQUMsQ0FBQyxPQUFPMUIsQ0FBTSxFQUFFO01BQUEsSUFBQXdELE9BQUE7TUFDZixJQUFJLENBQUF4RCxDQUFDLGFBQURBLENBQUMsdUJBQURBLENBQUMsQ0FBRXlELFVBQVUsTUFBSyxHQUFHLElBQUksQ0FBQXpELENBQUMsYUFBREEsQ0FBQyxnQkFBQXdELE9BQUEsR0FBRHhELENBQUMsQ0FBRTBELElBQUksY0FBQUYsT0FBQSx1QkFBUEEsT0FBQSxDQUFTQyxVQUFVLE1BQUssR0FBRyxFQUFFO1FBQ3hELE9BQU87VUFBRSxHQUFHckM7UUFBZSxDQUFDO01BQzlCO01BQ0EsTUFBTXBCLENBQUM7SUFDVDtFQUNGO0VBRUEsYUFBYTJELFVBQVVBLENBQUN0QixNQUFXLEVBQUV1QixPQUErQixFQUEwQjtJQUM1RixNQUFNQyxRQUFRLEdBQUcsTUFBTTFCLGNBQWMsQ0FBQ2dCLFNBQVMsQ0FBQ2QsTUFBTSxDQUFDO0lBQ3ZELE1BQU15QixNQUFxQixHQUFHO01BQUUsR0FBR0QsUUFBUTtNQUFFLEdBQUdELE9BQU87TUFBRTVCLFVBQVUsRUFBRSxJQUFJQyxJQUFJLENBQUMsQ0FBQyxDQUFDQyxXQUFXLENBQUM7SUFBRSxDQUFDO0lBQy9GLE1BQU1HLE1BQU0sQ0FBQ0ksS0FBSyxDQUFDO01BQ2pCQSxLQUFLLEVBQUVDLCtCQUFvQjtNQUMzQlksRUFBRSxFQUFFcEMsYUFBYTtNQUNqQm9CLElBQUksRUFBRXdCLE1BQU07TUFDWkMsT0FBTyxFQUFFO0lBQ1gsQ0FBQyxDQUFDO0lBQ0YsT0FBT0QsTUFBTTtFQUNmOztFQUVBO0FBQ0Y7QUFDQTtBQUNBO0VBQ0UsT0FBT0UsY0FBY0EsQ0FBQ0MsTUFBcUIsRUFBaUI7SUFDMUQsSUFBSUEsTUFBTSxDQUFDdkMsS0FBSyxJQUFJdUMsTUFBTSxDQUFDdkMsS0FBSyxDQUFDd0MsTUFBTSxHQUFHLENBQUMsRUFBRTtNQUMzQyxPQUFPRCxNQUFNLENBQUN2QyxLQUFLLENBQUN5QyxNQUFNLENBQUVsRSxDQUFDLElBQUtBLENBQUMsQ0FBQ29CLE9BQU8sQ0FBQztJQUM5QztJQUNBLE9BQU8sQ0FDTDtNQUNFaUMsRUFBRSxFQUFFLGtCQUFrQjtNQUN0QmMsSUFBSSxFQUFHLGlCQUFnQkgsTUFBTSxDQUFDM0MsU0FBVSxFQUFDO01BQ3pDRCxPQUFPLEVBQUUsSUFBSTtNQUNiZ0QsS0FBSyxFQUFFLENBQUM7TUFDUkMsUUFBUSxFQUFFLElBQUFDLG1DQUFzQixFQUFDTixNQUFNLENBQUMzQyxTQUFTLENBQUM7TUFDbERrRCxRQUFRLEVBQUdQLE1BQU0sQ0FBQ3pDLGdCQUFnQixJQUFJLElBQXFCO01BQzNEaUQsUUFBUSxFQUFFLE1BQU07TUFDaEJDLFFBQVEsRUFBR1QsTUFBTSxDQUFDeEMsZ0JBQWdCLElBQUksT0FBd0I7TUFDOURrRCxJQUFJLEVBQUUsRUFBRTtNQUNSQyxhQUFhLEVBQUU7SUFDakIsQ0FBQyxDQUNGO0VBQ0g7O0VBRUE7O0VBRUEsT0FBT0MsS0FBS0EsQ0FBQ3hDLE1BQVcsRUFBRXlDLE1BQWMsRUFBUTtJQUM5QyxJQUFJM0MsY0FBYyxDQUFDNEMsY0FBYyxFQUFFO0lBQ25DNUMsY0FBYyxDQUFDNEMsY0FBYyxHQUFHQyxXQUFXLENBQUMsWUFBWTtNQUN0RCxJQUFJO1FBQ0YsTUFBTTdDLGNBQWMsQ0FBQzhDLElBQUksQ0FBQzVDLE1BQU0sRUFBRXlDLE1BQU0sQ0FBQztNQUMzQyxDQUFDLENBQUMsT0FBTzlFLENBQU0sRUFBRTtRQUNmOEUsTUFBTSxDQUFDSSxJQUFJLENBQUUsdUJBQXNCbEYsQ0FBQyxDQUFDbUYsT0FBUSxFQUFDLENBQUM7TUFDakQ7SUFDRixDQUFDLEVBQUUsTUFBTSxDQUFDO0lBQ1ZMLE1BQU0sQ0FBQ00sSUFBSSxDQUFDLDBEQUEwRCxDQUFDO0VBQ3pFO0VBRUEsT0FBT0MsSUFBSUEsQ0FBQSxFQUFTO0lBQ2xCLElBQUlsRCxjQUFjLENBQUM0QyxjQUFjLEVBQUU7TUFDakNPLGFBQWEsQ0FBQ25ELGNBQWMsQ0FBQzRDLGNBQWMsQ0FBQztNQUM1QzVDLGNBQWMsQ0FBQzRDLGNBQWMsR0FBRyxJQUFJO0lBQ3RDO0VBQ0Y7RUFFQSxhQUFhRSxJQUFJQSxDQUFDNUMsTUFBVyxFQUFFeUMsTUFBYyxFQUFpQjtJQUM1RCxNQUFNYixNQUFNLEdBQUcsTUFBTTlCLGNBQWMsQ0FBQ2dCLFNBQVMsQ0FBQ2QsTUFBTSxDQUFDO0lBQ3JELElBQUksQ0FBQzRCLE1BQU0sQ0FBQzVDLE9BQU8sRUFBRTtJQUVyQixNQUFNa0UsR0FBRyxHQUFHdEQsSUFBSSxDQUFDc0QsR0FBRyxDQUFDLENBQUM7SUFDdEIsTUFBTUMsVUFBVSxHQUFHLENBQUN2QixNQUFNLENBQUMxQyxnQkFBZ0IsSUFBSSxDQUFDLElBQUksTUFBTTtJQUMxRCxNQUFNa0UsT0FBTyxHQUFHeEIsTUFBTSxDQUFDcEMsV0FBVyxHQUFHLElBQUlJLElBQUksQ0FBQ2dDLE1BQU0sQ0FBQ3BDLFdBQVcsQ0FBQyxDQUFDNkQsT0FBTyxDQUFDLENBQUMsR0FBRyxDQUFDO0lBQy9FLElBQUlILEdBQUcsR0FBR0UsT0FBTyxHQUFHRCxVQUFVLEVBQUU7SUFFaEMsSUFBSXJELGNBQWMsQ0FBQ3dELE9BQU8sRUFBRTtJQUM1QnhELGNBQWMsQ0FBQ3dELE9BQU8sR0FBRyxJQUFJO0lBRTdCLElBQUk7TUFDRixNQUFNakUsS0FBSyxHQUFHUyxjQUFjLENBQUM2QixjQUFjLENBQUNDLE1BQU0sQ0FBQztNQUNuRGEsTUFBTSxDQUFDTSxJQUFJLENBQ1IsK0JBQThCMUQsS0FBSyxDQUFDd0MsTUFBTyxtQkFBa0JELE1BQU0sQ0FBQ25DLHdCQUF3QixJQUFJLFdBQVksRUFDL0csQ0FBQztNQUNELE1BQU04RCxNQUFNLEdBQUcsTUFBTXpELGNBQWMsQ0FBQzBELGtCQUFrQixDQUFDeEQsTUFBTSxFQUFFNEIsTUFBTSxFQUFFYSxNQUFNLENBQUM7TUFDOUUsTUFBTTNDLGNBQWMsQ0FBQ3dCLFVBQVUsQ0FBQ3RCLE1BQU0sRUFBRTtRQUN0Q1IsV0FBVyxFQUFFLElBQUlJLElBQUksQ0FBQyxDQUFDLENBQUNDLFdBQVcsQ0FBQyxDQUFDO1FBQ3JDSCxhQUFhLEVBQUUsQ0FBQ2tDLE1BQU0sQ0FBQ2xDLGFBQWEsSUFBSSxDQUFDLElBQUk2RCxNQUFNLENBQUNFO01BQ3RELENBQUMsQ0FBQztNQUNGaEIsTUFBTSxDQUFDTSxJQUFJLENBQUUsb0NBQW1DUSxNQUFNLENBQUNFLE9BQVEsRUFBQyxDQUFDO0lBQ25FLENBQUMsU0FBUztNQUNSM0QsY0FBYyxDQUFDd0QsT0FBTyxHQUFHLEtBQUs7SUFDaEM7RUFDRjs7RUFFQTs7RUFFQTtBQUNGO0FBQ0E7QUFDQTtFQUNFLGFBQWFFLGtCQUFrQkEsQ0FDN0J4RCxNQUFXLEVBQ1g0QixNQUFxQixFQUNyQmEsTUFBYyxFQUNrRDtJQUNoRSxNQUFNcEQsS0FBSyxHQUFHUyxjQUFjLENBQUM2QixjQUFjLENBQUNDLE1BQU0sQ0FBQztJQUNuRCxNQUFNOEIsT0FBK0IsR0FBRyxDQUFDLENBQUM7SUFDMUMsSUFBSXJFLEtBQUssQ0FBQ3dDLE1BQU0sS0FBSyxDQUFDLEVBQUU7TUFDdEJZLE1BQU0sQ0FBQ00sSUFBSSxDQUFDLCtDQUErQyxDQUFDO01BQzVELE9BQU87UUFBRVUsT0FBTyxFQUFFLENBQUM7UUFBRUUsUUFBUSxFQUFFRDtNQUFRLENBQUM7SUFDMUM7SUFFQSxNQUFNRSxJQUFJLEdBQUcsTUFBTTlELGNBQWMsQ0FBQytELG9CQUFvQixDQUFDN0QsTUFBTSxFQUFFNEIsTUFBTSxFQUFFdkMsS0FBSyxFQUFFb0QsTUFBTSxDQUFDO0lBRXJGLElBQUltQixJQUFJLENBQUMvQixNQUFNLEtBQUssQ0FBQyxFQUFFO01BQ3JCLE1BQU0vQixjQUFjLENBQUN3QixVQUFVLENBQUN0QixNQUFNLEVBQUU7UUFDdENQLHdCQUF3QixFQUFFLElBQUlHLElBQUksQ0FBQyxDQUFDLENBQUNDLFdBQVcsQ0FBQztNQUNuRCxDQUFDLENBQUM7TUFDRixPQUFPO1FBQUU0RCxPQUFPLEVBQUUsQ0FBQztRQUFFRSxRQUFRLEVBQUVEO01BQVEsQ0FBQztJQUMxQztJQUVBLE1BQU1JLEtBQUssR0FBR2hFLGNBQWMsQ0FBQ2lFLGNBQWMsQ0FBQ25DLE1BQU0sQ0FBQztJQUNuRCxJQUFJNkIsT0FBTyxHQUFHLENBQUM7SUFDZixJQUFJTyxlQUFlLEdBQUdGLEtBQUs7SUFDM0IsTUFBTUcsUUFBUSxHQUFHQyxJQUFJLENBQUNDLEdBQUcsQ0FBQyxDQUFDLEVBQUV2QyxNQUFNLENBQUNyQyxrQkFBa0IsSUFBSSxFQUFFLENBQUM7SUFDN0QsTUFBTTZFLGNBQXNDLEdBQUcsQ0FBQyxDQUFDOztJQUVqRDtJQUNBO0lBQ0EsTUFBTUMsY0FBYyxHQUFHekMsTUFBTSxDQUFDdEMsY0FBYyxHQUN4QyxNQUFNUSxjQUFjLENBQUN3RSw4QkFBOEIsQ0FBQ3RFLE1BQU0sRUFBRXlDLE1BQU0sQ0FBQyxHQUNuRSxJQUFJOEIsR0FBRyxDQUFTLENBQUM7SUFFckIsS0FBSyxNQUFNQyxHQUFHLElBQUlaLElBQUksRUFBRTtNQUN0QixNQUFNYSxLQUFLLEdBQUdELEdBQUcsQ0FBQ3RELE9BQU87TUFDekIsTUFBTXdELE9BQU8sR0FBR0YsR0FBRyxDQUFDRyxHQUFHO01BRXZCLE1BQU1DLGNBQXNCLEdBQzFCLENBQUFILEtBQUssYUFBTEEsS0FBSyx1QkFBTEEsS0FBSyxDQUFFSSxTQUFTLE1BQUlKLEtBQUssYUFBTEEsS0FBSyx1QkFBTEEsS0FBSyxDQUFHLFlBQVksQ0FBQyxLQUFJLElBQUk3RSxJQUFJLENBQUMsQ0FBQyxDQUFDQyxXQUFXLENBQUMsQ0FBQztNQUN2RSxJQUFJK0UsY0FBYyxHQUFHWixlQUFlLEVBQUVBLGVBQWUsR0FBR1ksY0FBYztNQUV0RSxJQUFJbkIsT0FBTyxJQUFJUSxRQUFRLEVBQUU7UUFDdkJ4QixNQUFNLENBQUNNLElBQUksQ0FBRSw2Q0FBNENrQixRQUFTLGFBQVksQ0FBQztRQUMvRTtNQUNGO01BRUEsSUFBSUksY0FBYyxDQUFDUyxHQUFHLENBQUNKLE9BQU8sQ0FBQyxFQUFFO01BRWpDLE1BQU1LLElBQUksR0FBRyxJQUFBQyw2QkFBZ0IsRUFBQ1AsS0FBSyxFQUFFcEYsS0FBSyxDQUFDO01BQzNDLElBQUksQ0FBQzBGLElBQUksRUFBRTtNQUVYLE1BQU1FLFNBQVMsR0FBR2IsY0FBYyxDQUFDVyxJQUFJLENBQUM5RCxFQUFFLENBQUMsSUFBSSxDQUFDO01BQzlDLElBQUk4RCxJQUFJLENBQUN4RixrQkFBa0IsSUFBSTBGLFNBQVMsSUFBSUYsSUFBSSxDQUFDeEYsa0JBQWtCLEVBQUU7TUFFckUsSUFBSTtRQUNGLE1BQU0yRixPQUFPLEdBQUcsTUFBTXBGLGNBQWMsQ0FBQ3FGLG1CQUFtQixDQUFDbkYsTUFBTSxFQUFFd0UsR0FBRyxFQUFFTyxJQUFJLEVBQUV0QyxNQUFNLENBQUM7UUFDbkY0QixjQUFjLENBQUNlLEdBQUcsQ0FBQ1YsT0FBTyxDQUFDO1FBQzNCakIsT0FBTyxFQUFFO1FBQ1RXLGNBQWMsQ0FBQ1csSUFBSSxDQUFDOUQsRUFBRSxDQUFDLEdBQUdnRSxTQUFTLEdBQUcsQ0FBQztRQUN2Q3ZCLE9BQU8sQ0FBQ3FCLElBQUksQ0FBQ2hELElBQUksQ0FBQyxHQUFHLENBQUMyQixPQUFPLENBQUNxQixJQUFJLENBQUNoRCxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztRQUNsRFUsTUFBTSxDQUFDTSxJQUFJLENBQUUseUJBQXdCbUMsT0FBTyxDQUFDRyxPQUFRLGNBQWFOLElBQUksQ0FBQ2hELElBQUssR0FBRSxDQUFDO01BQ2pGLENBQUMsQ0FBQyxPQUFPcEUsQ0FBTSxFQUFFO1FBQ2Y4RSxNQUFNLENBQUNJLElBQUksQ0FBRSx5Q0FBd0M2QixPQUFRLEtBQUkvRyxDQUFDLENBQUNtRixPQUFRLEVBQUMsQ0FBQztNQUMvRTtJQUNGOztJQUVBO0lBQ0EsSUFBSWxCLE1BQU0sQ0FBQ3ZDLEtBQUssSUFBSXVDLE1BQU0sQ0FBQ3ZDLEtBQUssQ0FBQ3dDLE1BQU0sR0FBRyxDQUFDLElBQUk5RCxNQUFNLENBQUN1SCxJQUFJLENBQUNsQixjQUFjLENBQUMsQ0FBQ3ZDLE1BQU0sR0FBRyxDQUFDLEVBQUU7TUFDckYsTUFBTTBELFlBQVksR0FBRzNELE1BQU0sQ0FBQ3ZDLEtBQUssQ0FBQ21HLEdBQUcsQ0FBRTVILENBQUMsSUFDdEN3RyxjQUFjLENBQUN4RyxDQUFDLENBQUNxRCxFQUFFLENBQUMsR0FDaEI7UUFBRSxHQUFHckQsQ0FBQztRQUFFOEIsYUFBYSxFQUFFLENBQUM5QixDQUFDLENBQUM4QixhQUFhLElBQUksQ0FBQyxJQUFJMEUsY0FBYyxDQUFDeEcsQ0FBQyxDQUFDcUQsRUFBRTtNQUFFLENBQUMsR0FDdEVyRCxDQUNOLENBQUM7TUFDRCxNQUFNa0MsY0FBYyxDQUFDd0IsVUFBVSxDQUFDdEIsTUFBTSxFQUFFO1FBQ3RDWCxLQUFLLEVBQUVrRyxZQUFZO1FBQ25COUYsd0JBQXdCLEVBQUV1RTtNQUM1QixDQUFDLENBQUM7SUFDSixDQUFDLE1BQU07TUFDTCxNQUFNbEUsY0FBYyxDQUFDd0IsVUFBVSxDQUFDdEIsTUFBTSxFQUFFO1FBQUVQLHdCQUF3QixFQUFFdUU7TUFBZ0IsQ0FBQyxDQUFDO0lBQ3hGO0lBRUEsT0FBTztNQUFFUCxPQUFPO01BQUVFLFFBQVEsRUFBRUQ7SUFBUSxDQUFDO0VBQ3ZDOztFQUVBO0VBQ0EsT0FBZUssY0FBY0EsQ0FBQ25DLE1BQXFCLEVBQVU7SUFDM0QsT0FDRUEsTUFBTSxDQUFDbkMsd0JBQXdCLElBQUksSUFBSUcsSUFBSSxDQUFDQSxJQUFJLENBQUNzRCxHQUFHLENBQUMsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsTUFBTSxDQUFDLENBQUNyRCxXQUFXLENBQUMsQ0FBQztFQUU1RjtFQUVBLGFBQXFCZ0Usb0JBQW9CQSxDQUN2QzdELE1BQVcsRUFDWDRCLE1BQXFCLEVBQ3JCdkMsS0FBb0IsRUFDcEJvRCxNQUFjLEVBQ0U7SUFDaEIsTUFBTXFCLEtBQUssR0FBR2hFLGNBQWMsQ0FBQ2lFLGNBQWMsQ0FBQ25DLE1BQU0sQ0FBQzs7SUFFbkQ7SUFDQTtJQUNBLE1BQU02RCxVQUFVLEdBQUc7TUFDakJDLElBQUksRUFBRTtRQUNKQyxNQUFNLEVBQUUsQ0FDTjtVQUFFQyxLQUFLLEVBQUU7WUFBRWYsU0FBUyxFQUFFO2NBQUVnQixFQUFFLEVBQUUvQjtZQUFNO1VBQUU7UUFBRSxDQUFDLEVBQ3ZDO1VBQUU4QixLQUFLLEVBQUU7WUFBRSxZQUFZLEVBQUU7Y0FBRUMsRUFBRSxFQUFFL0I7WUFBTTtVQUFFO1FBQUUsQ0FBQyxDQUMzQztRQUNEZ0Msb0JBQW9CLEVBQUU7TUFDeEI7SUFDRixDQUFDO0lBRUQsTUFBTWhFLE1BQWEsR0FBRyxDQUFDMkQsVUFBVSxDQUFDO0lBQ2xDLE1BQU1NLFNBQVMsR0FBRyxJQUFBQyw4QkFBaUIsRUFBQzNHLEtBQUssQ0FBQztJQUMxQyxJQUFJMEcsU0FBUyxFQUFFO01BQ2JqRSxNQUFNLENBQUNtRSxJQUFJLENBQUNGLFNBQVMsQ0FBQztJQUN4QixDQUFDLE1BQU07TUFDTHRELE1BQU0sQ0FBQ00sSUFBSSxDQUNULHdHQUNGLENBQUM7SUFDSDtJQUVBLE1BQU1tRCxJQUFJLEdBQUdoQyxJQUFJLENBQUNpQyxHQUFHLENBQUNySCxhQUFhLEVBQUVvRixJQUFJLENBQUNDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsQ0FBQ3ZDLE1BQU0sQ0FBQ3JDLGtCQUFrQixJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQztJQUV6RixJQUFJO01BQUEsSUFBQTZHLFlBQUE7TUFDRixNQUFNO1FBQUVuRyxJQUFJLEVBQUVzRDtNQUFPLENBQUMsR0FBRyxNQUFNdkQsTUFBTSxDQUFDcUcsTUFBTSxDQUFDO1FBQzNDakcsS0FBSyxFQUFFa0cscUNBQTBCO1FBQ2pDckcsSUFBSSxFQUFFO1VBQ0pzRyxLQUFLLEVBQUU7WUFBRWIsSUFBSSxFQUFFO2NBQUU1RDtZQUFPO1VBQUUsQ0FBQztVQUMzQjBFLElBQUksRUFBRSxDQUFDO1lBQUUzQixTQUFTLEVBQUU7Y0FBRTdDLEtBQUssRUFBRSxLQUFLO2NBQUV5RSxhQUFhLEVBQUU7WUFBTztVQUFFLENBQUMsQ0FBQztVQUM5RFA7UUFDRixDQUFDO1FBQ0RRLGtCQUFrQixFQUFFO01BQ3RCLENBQUMsQ0FBQztNQUNGLE1BQU05QyxJQUFJLEdBQUcsRUFBQXdDLFlBQUEsR0FBQTdDLE1BQU0sQ0FBQ0ssSUFBSSxjQUFBd0MsWUFBQSx1QkFBWEEsWUFBQSxDQUFheEMsSUFBSSxLQUFJLEVBQUU7TUFDcENuQixNQUFNLENBQUNNLElBQUksQ0FBRSx5QkFBd0JhLElBQUksQ0FBQy9CLE1BQU8sNkJBQTRCaUMsS0FBTSxFQUFDLENBQUM7TUFDckYsT0FBT0YsSUFBSTtJQUNiLENBQUMsQ0FBQyxPQUFPakcsQ0FBTSxFQUFFO01BQ2Y4RSxNQUFNLENBQUNJLElBQUksQ0FBRSxzQ0FBcUNsRixDQUFDLENBQUNtRixPQUFRLEVBQUMsQ0FBQztNQUM5RCxPQUFPLEVBQUU7SUFDWDtFQUNGOztFQUVBO0VBQ0EsYUFBcUJxQyxtQkFBbUJBLENBQ3RDbkYsTUFBVyxFQUNYd0UsR0FBUSxFQUNSTyxJQUFpQixFQUNqQnRDLE1BQWMsRUFDQTtJQUFBLElBQUFrRSxXQUFBLEVBQUFDLFlBQUEsRUFBQUMsWUFBQTtJQUNkLE1BQU1wQyxLQUFLLEdBQUdELEdBQUcsQ0FBQ3RELE9BQU87SUFDekIsTUFBTXdELE9BQU8sR0FBR0YsR0FBRyxDQUFDRyxHQUFHO0lBQ3ZCLE1BQU1tQyxlQUFlLEdBQUcsQ0FBQXJDLEtBQUssYUFBTEEsS0FBSyxnQkFBQWtDLFdBQUEsR0FBTGxDLEtBQUssQ0FBRU0sSUFBSSxjQUFBNEIsV0FBQSx1QkFBWEEsV0FBQSxDQUFhSSxXQUFXLEtBQUksZ0JBQWdCO0lBQ3BFLE1BQU1DLFNBQVMsR0FBR3BJLE1BQU0sQ0FBQzZGLEtBQUssYUFBTEEsS0FBSyxnQkFBQW1DLFlBQUEsR0FBTG5DLEtBQUssQ0FBRU0sSUFBSSxjQUFBNkIsWUFBQSx1QkFBWEEsWUFBQSxDQUFhSyxLQUFLLENBQUMsSUFBSSxDQUFDO0lBQ2pELE1BQU1DLFdBQVcsR0FBR3ZJLE1BQU0sQ0FBQyxDQUFBOEYsS0FBSyxhQUFMQSxLQUFLLGdCQUFBb0MsWUFBQSxHQUFMcEMsS0FBSyxDQUFFTSxJQUFJLGNBQUE4QixZQUFBLHVCQUFYQSxZQUFBLENBQWE1RixFQUFFLEtBQUksRUFBRSxDQUFDO0lBRWpELE1BQU1xQixJQUFJLEdBQUc2RSxLQUFLLENBQUNDLElBQUksQ0FDckIsSUFBSTdDLEdBQUcsQ0FBQyxDQUNOLGNBQWMsRUFDYixTQUFReUMsU0FBVSxFQUFDLEVBQ3BCLElBQUlFLFdBQVcsR0FBRyxDQUFFLFFBQU9BLFdBQVksRUFBQyxDQUFDLEdBQUcsRUFBRSxDQUFDLEVBQy9DLElBQUluQyxJQUFJLENBQUN6QyxJQUFJLElBQUksRUFBRSxDQUFDLEVBQ25CLGdCQUFleUMsSUFBSSxDQUFDOUQsRUFBRyxFQUFDLENBQzFCLENBQ0gsQ0FBQztJQUVELE1BQU1pRSxPQUFPLEdBQUcsTUFBTW1DLHlCQUFXLENBQUNDLFVBQVUsQ0FDMUN0SCxNQUFNLEVBQ047TUFDRXVILEtBQUssRUFBRSxhQUFhO01BQ3BCUixXQUFXLEVBQUVqSCxjQUFjLENBQUMwSCxnQkFBZ0IsQ0FBQy9DLEtBQUssRUFBRU0sSUFBSSxDQUFDO01BQ3pEM0MsUUFBUSxFQUFFLElBQUFxRiw0QkFBZSxFQUFDMUMsSUFBSSxFQUFFTixLQUFLLENBQUM7TUFDdEN0QyxRQUFRLEVBQUU0QyxJQUFJLENBQUM1QyxRQUFRO01BQ3ZCRSxRQUFRLEVBQUUwQyxJQUFJLENBQUMxQyxRQUFRO01BQ3ZCcUYsR0FBRyxFQUFFM0MsSUFBSSxDQUFDMkMsR0FBRztNQUNicEYsSUFBSTtNQUNKcUYsUUFBUSxFQUFFNUMsSUFBSSxDQUFDNEMsUUFBUSxJQUFJO0lBQzdCLENBQUMsRUFDRCxjQUNGLENBQUM7SUFFRCxNQUFNQyxXQUFXLEdBQUksR0FBRTFDLE9BQU8sQ0FBQ0csT0FBUSxLQUFJeUIsZUFBZ0IsRUFBQztJQUM1RCxNQUFNZSxXQUFXLEdBQUcvSCxjQUFjLENBQUNnSSxnQkFBZ0IsQ0FBQ3RELEdBQUcsQ0FBQztJQUV4RCxNQUFNeEUsTUFBTSxDQUFDK0gsTUFBTSxDQUFDO01BQ2xCM0gsS0FBSyxFQUFFNEgscUJBQVU7TUFDakIvRyxFQUFFLEVBQUVpRSxPQUFPLENBQUNqRSxFQUFHO01BQ2ZoQixJQUFJLEVBQUU7UUFDSmdJLEdBQUcsRUFBRTtVQUNIVixLQUFLLEVBQUVLLFdBQVc7VUFDbEJNLGFBQWEsRUFBRSxDQUFDTCxXQUFXLENBQUM7VUFDNUI7VUFDQXZGLElBQUksRUFBRSxDQUFDLEdBQUdBLElBQUksRUFBRyxjQUFhb0MsT0FBUSxFQUFDLENBQUM7VUFDeEMvRSxVQUFVLEVBQUUsSUFBSUMsSUFBSSxDQUFDLENBQUMsQ0FBQ0MsV0FBVyxDQUFDO1FBQ3JDO01BQ0YsQ0FBQztNQUNEc0ksaUJBQWlCLEVBQUU7SUFDckIsQ0FBQyxDQUFDO0lBRUYsTUFBTUMsT0FBTyxHQUFHO01BQUUsR0FBR2xELE9BQU87TUFBRXFDLEtBQUssRUFBRUs7SUFBWSxDQUFDO0lBRWxELE1BQU1TLHlDQUFtQixDQUFDQyxRQUFRLENBQ2hDdEksTUFBTSxFQUNOO01BQ0V1SSxLQUFLLEVBQUV4RCxJQUFJLENBQUM0QyxRQUFRLEdBQUcsZUFBZSxHQUFHLGNBQWM7TUFDdkRhLFVBQVUsRUFBRSxDQUFDekQsSUFBSSxDQUFDNEMsUUFBUSxDQUFDO01BQzNCSixLQUFLLEVBQUcsUUFBT3JDLE9BQU8sQ0FBQ0csT0FBUSxlQUFjO01BQzdDdkMsT0FBTyxFQUFHLEdBQUVnRSxlQUFnQixXQUFVL0IsSUFBSSxDQUFDaEQsSUFBSyxlQUFjZ0QsSUFBSSxDQUFDNUMsUUFBUyxHQUFFO01BQzlFaUcsT0FBTztNQUNQSyxLQUFLLEVBQUUsY0FBYztNQUNyQkMsT0FBTyxFQUFFO1FBQUVDLFlBQVksRUFBRTVELElBQUksQ0FBQ2hELElBQUk7UUFBRTZHLFFBQVEsRUFBRWxFLE9BQU87UUFBRW1FLFVBQVUsRUFBRTdCO01BQVU7SUFDL0UsQ0FBQyxFQUNEdkUsTUFDRixDQUFDO0lBRUQsT0FBTzJGLE9BQU87RUFDaEI7O0VBRUE7QUFDRjtBQUNBO0FBQ0E7RUFDRSxhQUFxQjlELDhCQUE4QkEsQ0FDakR0RSxNQUFXLEVBQ1h5QyxNQUFjLEVBQ1E7SUFDdEIsTUFBTXFHLEdBQUcsR0FBRyxJQUFJdkUsR0FBRyxDQUFTLENBQUM7SUFDN0IsSUFBSTtNQUNGLE1BQU07UUFBRXRFLElBQUksRUFBRXNEO01BQU8sQ0FBQyxHQUFHLE1BQU12RCxNQUFNLENBQUNxRyxNQUFNLENBQUM7UUFDM0NqRyxLQUFLLEVBQUU0SCxxQkFBVTtRQUNqQi9ILElBQUksRUFBRTtVQUNKc0csS0FBSyxFQUFFO1lBQ0xiLElBQUksRUFBRTtjQUNKcUQsSUFBSSxFQUFFLENBQ0o7Z0JBQUVDLEtBQUssRUFBRTtrQkFBRUMsTUFBTSxFQUFFLENBQUMsTUFBTSxFQUFFLGFBQWEsRUFBRSxTQUFTO2dCQUFFO2NBQUUsQ0FBQyxFQUN6RDtnQkFBRUMsSUFBSSxFQUFFO2tCQUFFNUcsSUFBSSxFQUFFO2dCQUFlO2NBQUUsQ0FBQztZQUV0QztVQUNGLENBQUM7VUFDRHBCLE9BQU8sRUFBRSxDQUFDLGVBQWUsQ0FBQztVQUMxQmdGLElBQUksRUFBRTtRQUNSO01BQ0YsQ0FBQyxDQUFDO01BQ0YsS0FBSyxNQUFNMUIsR0FBRyxJQUFJLEVBQUEyRSxhQUFBLEdBQUE1RixNQUFNLENBQUNLLElBQUksY0FBQXVGLGFBQUEsdUJBQVhBLGFBQUEsQ0FBYXZGLElBQUksS0FBSSxFQUFFLEVBQUU7UUFBQSxJQUFBdUYsYUFBQTtRQUN6QyxLQUFLLE1BQU1DLEVBQUUsSUFBSSxFQUFBQyxZQUFBLEdBQUE3RSxHQUFHLENBQUN0RCxPQUFPLGNBQUFtSSxZQUFBLHVCQUFYQSxZQUFBLENBQWFuQixhQUFhLEtBQUksRUFBRSxFQUFFO1VBQUEsSUFBQW1CLFlBQUE7VUFDakQsSUFBSUQsRUFBRSxDQUFDUixRQUFRLEVBQUVFLEdBQUcsQ0FBQzFELEdBQUcsQ0FBQ2dFLEVBQUUsQ0FBQ1IsUUFBUSxDQUFDO1FBQ3ZDO01BQ0Y7SUFDRixDQUFDLENBQUMsT0FBT2pMLENBQU0sRUFBRTtNQUNmOEUsTUFBTSxDQUFDSSxJQUFJLENBQUUsc0RBQXFEbEYsQ0FBQyxDQUFDbUYsT0FBUSxFQUFDLENBQUM7SUFDaEY7SUFDQSxPQUFPZ0csR0FBRztFQUNaO0VBRUEsT0FBZWhCLGdCQUFnQkEsQ0FBQ3RELEdBQVEsRUFBTztJQUFBLElBQUE4RSxZQUFBLEVBQUFDLFlBQUEsRUFBQUMsWUFBQSxFQUFBQyxZQUFBLEVBQUFDLFlBQUEsRUFBQUMsYUFBQTtJQUM3QyxNQUFNbEYsS0FBSyxHQUFHRCxHQUFHLENBQUN0RCxPQUFPO0lBQ3pCLE9BQU87TUFDTDBILFFBQVEsRUFBRXBFLEdBQUcsQ0FBQ0csR0FBRztNQUNqQnZFLEtBQUssRUFBRW9FLEdBQUcsQ0FBQ29GLE1BQU0sSUFBSXRELHFDQUEwQjtNQUMvQ3VELE9BQU8sRUFBRUMsUUFBUSxDQUFDLENBQUFyRixLQUFLLGFBQUxBLEtBQUssZ0JBQUE2RSxZQUFBLEdBQUw3RSxLQUFLLENBQUVNLElBQUksY0FBQXVFLFlBQUEsdUJBQVhBLFlBQUEsQ0FBYXJJLEVBQUUsS0FBSSxHQUFHLEVBQUUsRUFBRSxDQUFDO01BQzdDOEksZ0JBQWdCLEVBQUUsQ0FBQXRGLEtBQUssYUFBTEEsS0FBSyxnQkFBQThFLFlBQUEsR0FBTDlFLEtBQUssQ0FBRU0sSUFBSSxjQUFBd0UsWUFBQSx1QkFBWEEsWUFBQSxDQUFheEMsV0FBVyxLQUFJLEVBQUU7TUFDaEQ4QixVQUFVLEVBQUUsQ0FBQXBFLEtBQUssYUFBTEEsS0FBSyxnQkFBQStFLFlBQUEsR0FBTC9FLEtBQUssQ0FBRU0sSUFBSSxjQUFBeUUsWUFBQSx1QkFBWEEsWUFBQSxDQUFhdkMsS0FBSyxLQUFJLENBQUM7TUFDbkMrQyxXQUFXLEVBQUUsQ0FBQXZGLEtBQUssYUFBTEEsS0FBSyxnQkFBQWdGLFlBQUEsR0FBTGhGLEtBQUssQ0FBRU0sSUFBSSxjQUFBMEUsWUFBQSx1QkFBWEEsWUFBQSxDQUFhUSxNQUFNLEtBQUksRUFBRTtNQUN0Q0MsUUFBUSxFQUFFLENBQUF6RixLQUFLLGFBQUxBLEtBQUssZ0JBQUFpRixZQUFBLEdBQUxqRixLQUFLLENBQUUwRixLQUFLLGNBQUFULFlBQUEsdUJBQVpBLFlBQUEsQ0FBY3pJLEVBQUUsS0FBSSxFQUFFO01BQ2hDbUosVUFBVSxFQUFFLENBQUEzRixLQUFLLGFBQUxBLEtBQUssZ0JBQUFrRixhQUFBLEdBQUxsRixLQUFLLENBQUUwRixLQUFLLGNBQUFSLGFBQUEsdUJBQVpBLGFBQUEsQ0FBYzVILElBQUksS0FBSSxFQUFFO01BQ3BDOEMsU0FBUyxFQUFFLENBQUFKLEtBQUssYUFBTEEsS0FBSyx1QkFBTEEsS0FBSyxDQUFFSSxTQUFTLE1BQUlKLEtBQUssYUFBTEEsS0FBSyx1QkFBTEEsS0FBSyxDQUFHLFlBQVksQ0FBQyxLQUFJLElBQUk3RSxJQUFJLENBQUMsQ0FBQyxDQUFDQyxXQUFXLENBQUMsQ0FBQztNQUNoRndLLFFBQVEsRUFBRSxDQUFBNUYsS0FBSyxhQUFMQSxLQUFLLHVCQUFMQSxLQUFLLENBQUU0RixRQUFRLEtBQUk7SUFDL0IsQ0FBQztFQUNIO0VBRUEsT0FBZTdDLGdCQUFnQkEsQ0FBQy9DLEtBQVUsRUFBRU0sSUFBaUIsRUFBVTtJQUFBLElBQUF1RixZQUFBLEVBQUFDLFlBQUEsRUFBQUMsaUJBQUEsRUFBQUMsYUFBQSxFQUFBQyxhQUFBLEVBQUFDLGFBQUEsRUFBQUMsYUFBQTtJQUNyRSxNQUFNQyxNQUFNLEdBQUcsQ0FBQXBHLEtBQUssYUFBTEEsS0FBSyxnQkFBQTZGLFlBQUEsR0FBTDdGLEtBQUssQ0FBRU0sSUFBSSxjQUFBdUYsWUFBQSx1QkFBWEEsWUFBQSxDQUFhckosRUFBRSxLQUFJLEtBQUs7SUFDdkMsTUFBTTZKLFFBQVEsR0FBRyxDQUFBckcsS0FBSyxhQUFMQSxLQUFLLGdCQUFBOEYsWUFBQSxHQUFMOUYsS0FBSyxDQUFFTSxJQUFJLGNBQUF3RixZQUFBLHVCQUFYQSxZQUFBLENBQWF4RCxXQUFXLEtBQUksS0FBSztJQUNsRCxNQUFNQyxTQUFTLElBQUF3RCxpQkFBQSxHQUFHL0YsS0FBSyxhQUFMQSxLQUFLLGdCQUFBZ0csYUFBQSxHQUFMaEcsS0FBSyxDQUFFTSxJQUFJLGNBQUEwRixhQUFBLHVCQUFYQSxhQUFBLENBQWF4RCxLQUFLLGNBQUF1RCxpQkFBQSxjQUFBQSxpQkFBQSxHQUFJLEtBQUs7SUFDN0MsTUFBTU8sU0FBUyxHQUFHLENBQUF0RyxLQUFLLGFBQUxBLEtBQUssZ0JBQUFpRyxhQUFBLEdBQUxqRyxLQUFLLENBQUUwRixLQUFLLGNBQUFPLGFBQUEsdUJBQVpBLGFBQUEsQ0FBYzNJLElBQUksS0FBSSxTQUFTO0lBQ2pELE1BQU1pSixPQUFPLEdBQUcsQ0FBQXZHLEtBQUssYUFBTEEsS0FBSyxnQkFBQWtHLGFBQUEsR0FBTGxHLEtBQUssQ0FBRTBGLEtBQUssY0FBQVEsYUFBQSx1QkFBWkEsYUFBQSxDQUFjMUosRUFBRSxLQUFJLEtBQUs7SUFDekMsTUFBTWdKLE1BQU0sR0FBRyxDQUFDLENBQUF4RixLQUFLLGFBQUxBLEtBQUssZ0JBQUFtRyxhQUFBLEdBQUxuRyxLQUFLLENBQUVNLElBQUksY0FBQTZGLGFBQUEsdUJBQVhBLGFBQUEsQ0FBYVgsTUFBTSxLQUFJLEVBQUUsRUFBRWdCLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxLQUFLO0lBQzlELE1BQU1DLEtBQUssR0FBRyxDQUFBekcsS0FBSyxhQUFMQSxLQUFLLHVCQUFMQSxLQUFLLENBQUVJLFNBQVMsTUFBSUosS0FBSyxhQUFMQSxLQUFLLHVCQUFMQSxLQUFLLENBQUcsWUFBWSxDQUFDO0lBQ3ZELE1BQU1JLFNBQVMsR0FBR3FHLEtBQUssR0FDbkIsSUFBSXRMLElBQUksQ0FBQ3NMLEtBQUssQ0FBQyxDQUFDckwsV0FBVyxDQUFDLENBQUMsQ0FBQ3NMLE9BQU8sQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUNBLE9BQU8sQ0FBQyxPQUFPLEVBQUUsTUFBTSxDQUFDLEdBQ3hFLEtBQUs7SUFFVCxNQUFNQyxLQUFlLEdBQUcsQ0FDckIsZ0VBQStELEVBQy9ELEVBQUMsRUFDRCx5QkFBd0IsRUFDeEIsRUFBQyxFQUNELG9CQUFtQnJHLElBQUksQ0FBQ2hELElBQUssRUFBQyxFQUM5QixxQkFBb0IsSUFBQXNKLHlCQUFZLEVBQUN0RyxJQUFJLENBQUM5QyxRQUFRLENBQUMsSUFBSSxXQUFZLElBQUcsRUFDbEUsNEJBQTJCOEMsSUFBSSxDQUFDNUMsUUFBUyxFQUFDLEVBQzFDLEVBQUMsRUFDRCxrQkFBaUIsRUFDakIsRUFBQyxFQUNELGtCQUFpQjBJLE1BQU8sRUFBQyxFQUN6QixzQkFBcUJDLFFBQVMsRUFBQyxFQUMvQixnQkFBZTlELFNBQVUsRUFBQyxFQUMxQixpQkFBZ0JpRCxNQUFPLEVBQUMsRUFDeEIsZ0JBQWVjLFNBQVUsU0FBUUMsT0FBUSxHQUFFLEVBQzNDLG1CQUFrQm5HLFNBQVUsRUFBQyxDQUMvQjtJQUVELElBQUlKLEtBQUssYUFBTEEsS0FBSyxlQUFMQSxLQUFLLENBQUU0RixRQUFRLEVBQUU7TUFDbkIsTUFBTWlCLEdBQUcsR0FBRzNNLE1BQU0sQ0FBQzhGLEtBQUssQ0FBQzRGLFFBQVEsQ0FBQyxDQUFDa0IsSUFBSSxDQUFDLENBQUMsQ0FBQ0MsU0FBUyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUM7TUFDM0RKLEtBQUssQ0FBQ25GLElBQUksQ0FBRSxFQUFDLEVBQUcsWUFBVyxFQUFHLEVBQUMsRUFBRyxRQUFPLEVBQUVxRixHQUFHLEVBQUcsUUFBTyxDQUFDO0lBQzNEO0lBRUEsT0FBT0YsS0FBSyxDQUFDSCxJQUFJLENBQUMsSUFBSSxDQUFDO0VBQ3pCOztFQUVBOztFQUVBO0FBQ0Y7QUFDQTtBQUNBO0VBQ0UsYUFBYVEsU0FBU0EsQ0FDcEJ6TCxNQUFXLEVBQ1hYLEtBQW9CLEVBQ3BCcU0sSUFBdUMsR0FBRyxDQUFDLENBQUMsRUFlM0M7SUFBQSxJQUFBQyxhQUFBO0lBQ0QsTUFBTUMsS0FBSyxHQUFHMUgsSUFBSSxDQUFDaUMsR0FBRyxDQUFDdUYsSUFBSSxDQUFDRSxLQUFLLElBQUksRUFBRSxFQUFFLEdBQUcsQ0FBQztJQUM3QyxNQUFNMUYsSUFBSSxHQUFHaEMsSUFBSSxDQUFDaUMsR0FBRyxDQUFDdUYsSUFBSSxDQUFDeEYsSUFBSSxJQUFJLEdBQUcsRUFBRXBILGFBQWEsQ0FBQztJQUN0RCxNQUFNZ0YsS0FBSyxHQUFHLElBQUlsRSxJQUFJLENBQUNBLElBQUksQ0FBQ3NELEdBQUcsQ0FBQyxDQUFDLEdBQUcwSSxLQUFLLEdBQUcsRUFBRSxHQUFHLE1BQU0sQ0FBQyxDQUFDL0wsV0FBVyxDQUFDLENBQUM7SUFFdEUsTUFBTWlDLE1BQWEsR0FBRyxDQUNwQjtNQUNFNEQsSUFBSSxFQUFFO1FBQ0pDLE1BQU0sRUFBRSxDQUNOO1VBQUVDLEtBQUssRUFBRTtZQUFFZixTQUFTLEVBQUU7Y0FBRWdCLEVBQUUsRUFBRS9CO1lBQU07VUFBRTtRQUFFLENBQUMsRUFDdkM7VUFBRThCLEtBQUssRUFBRTtZQUFFLFlBQVksRUFBRTtjQUFFQyxFQUFFLEVBQUUvQjtZQUFNO1VBQUU7UUFBRSxDQUFDLENBQzNDO1FBQ0RnQyxvQkFBb0IsRUFBRTtNQUN4QjtJQUNGLENBQUMsQ0FDRjtJQUNELE1BQU1DLFNBQVMsR0FBRyxJQUFBQyw4QkFBaUIsRUFBQzNHLEtBQUssQ0FBQztJQUMxQyxJQUFJMEcsU0FBUyxFQUFFakUsTUFBTSxDQUFDbUUsSUFBSSxDQUFDRixTQUFTLENBQUM7SUFFckMsTUFBTTtNQUFFOUYsSUFBSSxFQUFFc0Q7SUFBTyxDQUFDLEdBQUcsTUFBTXZELE1BQU0sQ0FBQ3FHLE1BQU0sQ0FBQztNQUMzQ2pHLEtBQUssRUFBRWtHLHFDQUEwQjtNQUNqQ3JHLElBQUksRUFBRTtRQUNKc0csS0FBSyxFQUFFO1VBQUViLElBQUksRUFBRTtZQUFFNUQ7VUFBTztRQUFFLENBQUM7UUFDM0IwRSxJQUFJLEVBQUUsQ0FBQztVQUFFM0IsU0FBUyxFQUFFO1lBQUU3QyxLQUFLLEVBQUUsTUFBTTtZQUFFeUUsYUFBYSxFQUFFO1VBQU87UUFBRSxDQUFDLENBQUM7UUFDL0RQO01BQ0YsQ0FBQztNQUNEUSxrQkFBa0IsRUFBRTtJQUN0QixDQUFDLENBQUM7SUFFRixNQUFNOUMsSUFBSSxHQUFHLEVBQUErSCxhQUFBLEdBQUFwSSxNQUFNLENBQUNLLElBQUksY0FBQStILGFBQUEsdUJBQVhBLGFBQUEsQ0FBYS9ILElBQUksS0FBSSxFQUFFO0lBQ3BDLE1BQU1pSSxPQUFjLEdBQUcsRUFBRTtJQUN6QixNQUFNbkksT0FBK0IsR0FBRyxDQUFDLENBQUM7SUFFMUMsS0FBSyxNQUFNYyxHQUFHLElBQUlaLElBQUksRUFBRTtNQUN0QixNQUFNYSxLQUFLLEdBQUdELEdBQUcsQ0FBQ3RELE9BQU87TUFDekIsTUFBTTZELElBQUksR0FBRyxJQUFBQyw2QkFBZ0IsRUFBQ1AsS0FBSyxFQUFFcEYsS0FBSyxDQUFDO01BQzNDLElBQUksQ0FBQzBGLElBQUksRUFBRTtNQUNYckIsT0FBTyxDQUFDcUIsSUFBSSxDQUFDaEQsSUFBSSxDQUFDLEdBQUcsQ0FBQzJCLE9BQU8sQ0FBQ3FCLElBQUksQ0FBQ2hELElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO01BQ2xELElBQUk4SixPQUFPLENBQUNoSyxNQUFNLEdBQUcsRUFBRSxFQUFFO1FBQUEsSUFBQWlLLGFBQUEsRUFBQUMsYUFBQSxFQUFBQyxhQUFBLEVBQUFDLGFBQUE7UUFDdkJKLE9BQU8sQ0FBQzVGLElBQUksQ0FBQztVQUNYMkMsUUFBUSxFQUFFcEUsR0FBRyxDQUFDRyxHQUFHO1VBQ2pCRSxTQUFTLEVBQUUsQ0FBQUosS0FBSyxhQUFMQSxLQUFLLHVCQUFMQSxLQUFLLENBQUVJLFNBQVMsTUFBSUosS0FBSyxhQUFMQSxLQUFLLHVCQUFMQSxLQUFLLENBQUcsWUFBWSxDQUFDLEtBQUksRUFBRTtVQUMxRG9GLE9BQU8sRUFBRWxMLE1BQU0sQ0FBQyxDQUFBOEYsS0FBSyxhQUFMQSxLQUFLLGdCQUFBcUgsYUFBQSxHQUFMckgsS0FBSyxDQUFFTSxJQUFJLGNBQUErRyxhQUFBLHVCQUFYQSxhQUFBLENBQWE3SyxFQUFFLEtBQUksRUFBRSxDQUFDO1VBQ3RDOEksZ0JBQWdCLEVBQUUsQ0FBQXRGLEtBQUssYUFBTEEsS0FBSyxnQkFBQXNILGFBQUEsR0FBTHRILEtBQUssQ0FBRU0sSUFBSSxjQUFBZ0gsYUFBQSx1QkFBWEEsYUFBQSxDQUFhaEYsV0FBVyxLQUFJLEVBQUU7VUFDaEQ4QixVQUFVLEVBQUVqSyxNQUFNLENBQUM2RixLQUFLLGFBQUxBLEtBQUssZ0JBQUF1SCxhQUFBLEdBQUx2SCxLQUFLLENBQUVNLElBQUksY0FBQWlILGFBQUEsdUJBQVhBLGFBQUEsQ0FBYS9FLEtBQUssQ0FBQyxJQUFJLENBQUM7VUFDM0NtRCxVQUFVLEVBQUUsQ0FBQTNGLEtBQUssYUFBTEEsS0FBSyxnQkFBQXdILGFBQUEsR0FBTHhILEtBQUssQ0FBRTBGLEtBQUssY0FBQThCLGFBQUEsdUJBQVpBLGFBQUEsQ0FBY2xLLElBQUksS0FBSSxFQUFFO1VBQ3BDbUssWUFBWSxFQUFFbkgsSUFBSSxDQUFDaEQsSUFBSTtVQUN2QkksUUFBUSxFQUFFNEMsSUFBSSxDQUFDNUMsUUFBUTtVQUN2QkMsUUFBUSxFQUFFLElBQUFxRiw0QkFBZSxFQUFDMUMsSUFBSSxFQUFFTixLQUFLO1FBQ3ZDLENBQUMsQ0FBQztNQUNKO0lBQ0Y7SUFFQSxPQUFPO01BQUUwSCxPQUFPLEVBQUV2SSxJQUFJLENBQUMvQixNQUFNO01BQUVnSyxPQUFPO01BQUVsSSxRQUFRLEVBQUVEO0lBQVEsQ0FBQztFQUM3RDtBQUNGO0FBQUMwSSxPQUFBLENBQUF0TSxjQUFBLEdBQUFBLGNBQUE7QUFBQXBDLGVBQUEsQ0FuaEJZb0MsY0FBYyxvQkFDOEMsSUFBSTtBQUFBcEMsZUFBQSxDQURoRW9DLGNBQWMsYUFFQSxLQUFLIn0=