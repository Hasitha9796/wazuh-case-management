"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.MonitorService = void 0;
var _constants = require("../../common/constants");
var _case_service = require("./case_service");
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); } /*
 * Wazuh Case Management Plugin
 * Monitor Service — background polling for automatic case creation
 */
const CONFIG_DOC_ID = 'monitor_config';
const DEFAULT_CONFIG = {
  enabled: false,
  min_level: 10,
  interval_minutes: 5,
  default_priority: 'P2',
  default_category: 'other',
  last_run_at: null,
  last_processed_timestamp: null,
  cases_created: 0,
  updated_at: new Date().toISOString()
};
class MonitorService {
  // ── Config CRUD ──────────────────────────────────────────────

  static async ensureConfigIndex(client) {
    try {
      const {
        body
      } = await client.indices.exists({
        index: _constants.MONITOR_CONFIG_INDEX
      });
      if (!body) {
        await client.indices.create({
          index: _constants.MONITOR_CONFIG_INDEX,
          body: {
            settings: {
              number_of_shards: 1,
              number_of_replicas: 1
            },
            mappings: {
              properties: {
                enabled: {
                  type: 'boolean'
                },
                min_level: {
                  type: 'integer'
                },
                interval_minutes: {
                  type: 'integer'
                },
                default_priority: {
                  type: 'keyword'
                },
                default_category: {
                  type: 'keyword'
                },
                last_run_at: {
                  type: 'date'
                },
                last_processed_timestamp: {
                  type: 'date'
                },
                cases_created: {
                  type: 'long'
                },
                updated_at: {
                  type: 'date'
                }
              }
            }
          }
        });
      }
    } catch (e) {}
  }
  static async getConfig(client) {
    try {
      const {
        body
      } = await client.get({
        index: _constants.MONITOR_CONFIG_INDEX,
        id: CONFIG_DOC_ID
      });
      return body._source;
    } catch (e) {
      var _e$meta;
      if ((e === null || e === void 0 ? void 0 : e.statusCode) === 404 || (e === null || e === void 0 || (_e$meta = e.meta) === null || _e$meta === void 0 ? void 0 : _e$meta.statusCode) === 404) {
        return {
          ...DEFAULT_CONFIG
        };
      }
      throw e;
    }
  }
  static async saveConfig(client, updates) {
    const existing = await MonitorService.getConfig(client);
    const merged = {
      ...existing,
      ...updates,
      updated_at: new Date().toISOString()
    };
    await client.index({
      index: _constants.MONITOR_CONFIG_INDEX,
      id: CONFIG_DOC_ID,
      body: merged,
      refresh: 'wait_for'
    });
    return merged;
  }

  // ── Background Polling ───────────────────────────────────────

  static start(client, logger) {
    if (MonitorService.intervalHandle) return;
    MonitorService.intervalHandle = setInterval(async () => {
      try {
        await MonitorService.tick(client, logger);
      } catch (e) {
        logger.warn(`Monitor tick error: ${e.message}`);
      }
    }, 60_000);
    logger.info('Auto-monitor background job started (checking every 60s)');
  }
  static stop() {
    if (MonitorService.intervalHandle) {
      clearInterval(MonitorService.intervalHandle);
      MonitorService.intervalHandle = null;
    }
  }
  static async tick(client, logger) {
    const config = await MonitorService.getConfig(client);
    if (!config.enabled) return;
    const now = Date.now();
    const intervalMs = (config.interval_minutes || 5) * 60_000;
    const lastRun = config.last_run_at ? new Date(config.last_run_at).getTime() : 0;
    if (now - lastRun < intervalMs) return;
    if (MonitorService.running) return;
    MonitorService.running = true;
    try {
      logger.info(`Auto-monitor: scanning for rule.level >= ${config.min_level}, since=${config.last_processed_timestamp || 'beginning'}`);
      const created = await MonitorService.scanAndCreateCases(client, config, logger);
      await MonitorService.saveConfig(client, {
        last_run_at: new Date().toISOString(),
        cases_created: (config.cases_created || 0) + created
      });
      logger.info(`Auto-monitor: scan done, created=${created}`);
    } finally {
      MonitorService.running = false;
    }
  }

  // ── Alert scanning ───────────────────────────────────────────

  static async scanAndCreateCases(client, config, logger) {
    // Default: look back 24 hours on first run so existing alerts are picked up
    const since = config.last_processed_timestamp || new Date(Date.now() - 24 * 60 * 60_000).toISOString();

    // FIX 1: Wazuh alerts use either "timestamp" or "@timestamp" depending on version.
    // Query both fields with a should clause so alerts are found regardless.
    const searchBody = {
      query: {
        bool: {
          must: [{
            range: {
              'rule.level': {
                gte: Number(config.min_level)
              }
            }
          }],
          should: [{
            range: {
              timestamp: {
                gt: since
              }
            }
          }, {
            range: {
              '@timestamp': {
                gt: since
              }
            }
          }],
          minimum_should_match: 1
        }
      },
      sort: [{
        timestamp: {
          order: 'asc',
          unmapped_type: 'date'
        }
      }],
      size: 100
    };
    let hits = [];
    try {
      var _result$hits;
      const {
        body: result
      } = await client.search({
        index: _constants.WAZUH_ALERTS_INDEX_PATTERN,
        body: searchBody,
        ignore_unavailable: true
      });
      hits = ((_result$hits = result.hits) === null || _result$hits === void 0 ? void 0 : _result$hits.hits) || [];
      logger.info(`Auto-monitor: found ${hits.length} alert(s) with level >= ${config.min_level} since ${since}`);
    } catch (e) {
      logger.warn(`Auto-monitor: alert search failed — ${e.message}`);
      return 0;
    }
    if (hits.length === 0) {
      await MonitorService.saveConfig(client, {
        last_processed_timestamp: new Date().toISOString()
      });
      return 0;
    }
    let created = 0;
    let latestTimestamp = since;

    // FIX 2: Collect alert IDs already linked in open cases so we can deduplicate
    // without relying on custom_fields (which has enabled:false and is not indexed).
    const openCaseAlertIds = await MonitorService.getLinkedAlertIdsFromOpenCases(client, logger);
    for (const hit of hits) {
      var _alert$rule, _alert$rule2, _alert$rule3, _alert$agent;
      const alert = hit._source;
      const alertId = hit._id;

      // Pick timestamp from whichever field exists
      const alertTimestamp = (alert === null || alert === void 0 ? void 0 : alert.timestamp) || (alert === null || alert === void 0 ? void 0 : alert['@timestamp']) || new Date().toISOString();
      if (alertTimestamp > latestTimestamp) latestTimestamp = alertTimestamp;

      // Skip alerts already linked to an open case
      if (openCaseAlertIds.has(alertId)) {
        logger.info(`Auto-monitor: alert ${alertId} already linked — skipping`);
        continue;
      }
      const ruleDescription = (alert === null || alert === void 0 || (_alert$rule = alert.rule) === null || _alert$rule === void 0 ? void 0 : _alert$rule.description) || 'Security Alert';
      const ruleLevel = Number(alert === null || alert === void 0 || (_alert$rule2 = alert.rule) === null || _alert$rule2 === void 0 ? void 0 : _alert$rule2.level) || 0;
      const ruleId = String((alert === null || alert === void 0 || (_alert$rule3 = alert.rule) === null || _alert$rule3 === void 0 ? void 0 : _alert$rule3.id) || '');
      const agentId = String((alert === null || alert === void 0 || (_alert$agent = alert.agent) === null || _alert$agent === void 0 ? void 0 : _alert$agent.id) || '');
      try {
        let severity = 'low';
        if (ruleLevel >= 13) severity = 'critical';else if (ruleLevel >= 10) severity = 'high';else if (ruleLevel >= 7) severity = 'medium';
        const newCase = await _case_service.CaseService.createCase(client, {
          title: 'PLACEHOLDER',
          description: MonitorService.buildDescription(alert, hit._index),
          severity: severity,
          priority: config.default_priority,
          category: config.default_category,
          tags: ['auto-created', `level-${ruleLevel}`, ...(ruleId ? [`rule-${ruleId}`] : [])]
        }, 'auto-monitor');
        const caseDocId = newCase.id;
        // Title format: CASE-<caseID>: <rule.description>  (uses the real case_id)
        const prettyTitle = `${newCase.case_id}: ${ruleDescription}`;
        const linkedAlert = MonitorService.buildLinkedAlert(hit);
        await client.update({
          index: _constants.CASE_INDEX,
          id: caseDocId,
          body: {
            doc: {
              title: prettyTitle,
              linked_alerts: [linkedAlert],
              // FIX 3: store dedup keys as indexed tags instead of custom_fields
              tags: ['auto-created', `level-${ruleLevel}`, `auto-alert-${alertId}`],
              updated_at: new Date().toISOString()
            }
          },
          retry_on_conflict: 3
        });

        // Add to local set so we don't create duplicates within the same scan batch
        openCaseAlertIds.add(alertId);
        created++;
        logger.info(`Auto-monitor: created ${prettyTitle}`);
      } catch (e) {
        logger.warn(`Auto-monitor: failed to process alert ${alertId} — ${e.message}`);
      }
    }
    await MonitorService.saveConfig(client, {
      last_processed_timestamp: latestTimestamp
    });
    return created;
  }

  /**
   * Returns the set of alert IDs already linked inside any open/in-progress/waiting case.
   * Used for deduplication instead of custom_fields (which is not indexed).
   */
  static async getLinkedAlertIdsFromOpenCases(client, logger) {
    const ids = new Set();
    try {
      const {
        body: result
      } = await client.search({
        index: _constants.CASE_INDEX,
        body: {
          query: {
            bool: {
              must: [{
                terms: {
                  status: ['open', 'in_progress', 'waiting']
                }
              }, {
                term: {
                  tags: 'auto-created'
                }
              }]
            }
          },
          _source: ['linked_alerts'],
          size: 500
        }
      });
      for (const hit of ((_result$hits2 = result.hits) === null || _result$hits2 === void 0 ? void 0 : _result$hits2.hits) || []) {
        var _result$hits2;
        for (const la of ((_hit$_source = hit._source) === null || _hit$_source === void 0 ? void 0 : _hit$_source.linked_alerts) || []) {
          var _hit$_source;
          if (la.alert_id) ids.add(la.alert_id);
        }
      }
    } catch (e) {
      logger.warn(`Auto-monitor: could not fetch open case alert IDs — ${e.message}`);
    }
    return ids;
  }
  static buildLinkedAlert(hit) {
    var _alert$rule4, _alert$rule5, _alert$rule6, _alert$rule7, _alert$agent2, _alert$agent3;
    const alert = hit._source;
    return {
      alert_id: hit._id,
      index: hit._index || _constants.WAZUH_ALERTS_INDEX_PATTERN,
      rule_id: parseInt((alert === null || alert === void 0 || (_alert$rule4 = alert.rule) === null || _alert$rule4 === void 0 ? void 0 : _alert$rule4.id) || '0', 10),
      rule_description: (alert === null || alert === void 0 || (_alert$rule5 = alert.rule) === null || _alert$rule5 === void 0 ? void 0 : _alert$rule5.description) || '',
      rule_level: (alert === null || alert === void 0 || (_alert$rule6 = alert.rule) === null || _alert$rule6 === void 0 ? void 0 : _alert$rule6.level) || 0,
      rule_groups: (alert === null || alert === void 0 || (_alert$rule7 = alert.rule) === null || _alert$rule7 === void 0 ? void 0 : _alert$rule7.groups) || [],
      agent_id: (alert === null || alert === void 0 || (_alert$agent2 = alert.agent) === null || _alert$agent2 === void 0 ? void 0 : _alert$agent2.id) || '',
      agent_name: (alert === null || alert === void 0 || (_alert$agent3 = alert.agent) === null || _alert$agent3 === void 0 ? void 0 : _alert$agent3.name) || '',
      timestamp: (alert === null || alert === void 0 ? void 0 : alert.timestamp) || (alert === null || alert === void 0 ? void 0 : alert['@timestamp']) || new Date().toISOString(),
      full_log: (alert === null || alert === void 0 ? void 0 : alert.full_log) || ''
    };
  }
  static buildDescription(alert, index) {
    var _alert$rule8, _alert$rule9, _alert$rule$level, _alert$rule10, _alert$agent4, _alert$agent5, _alert$rule11;
    const ruleId = (alert === null || alert === void 0 || (_alert$rule8 = alert.rule) === null || _alert$rule8 === void 0 ? void 0 : _alert$rule8.id) || 'N/A';
    const ruleDesc = (alert === null || alert === void 0 || (_alert$rule9 = alert.rule) === null || _alert$rule9 === void 0 ? void 0 : _alert$rule9.description) || 'N/A';
    const ruleLevel = (_alert$rule$level = alert === null || alert === void 0 || (_alert$rule10 = alert.rule) === null || _alert$rule10 === void 0 ? void 0 : _alert$rule10.level) !== null && _alert$rule$level !== void 0 ? _alert$rule$level : 'N/A';
    const agentName = (alert === null || alert === void 0 || (_alert$agent4 = alert.agent) === null || _alert$agent4 === void 0 ? void 0 : _alert$agent4.name) || 'Unknown';
    const agentId = (alert === null || alert === void 0 || (_alert$agent5 = alert.agent) === null || _alert$agent5 === void 0 ? void 0 : _alert$agent5.id) || 'N/A';
    const groups = ((alert === null || alert === void 0 || (_alert$rule11 = alert.rule) === null || _alert$rule11 === void 0 ? void 0 : _alert$rule11.groups) || []).join(', ') || 'N/A';
    const rawTs = (alert === null || alert === void 0 ? void 0 : alert.timestamp) || (alert === null || alert === void 0 ? void 0 : alert['@timestamp']);
    const timestamp = rawTs ? new Date(rawTs).toLocaleString('en-GB', {
      dateStyle: 'medium',
      timeStyle: 'medium'
    }) : 'N/A';
    const lines = [`This case was automatically created by the Wazuh Case Monitor.`, ``, `## Alert Details`, ``, `- **Rule ID:** ${ruleId}`, `- **Description:** ${ruleDesc}`, `- **Level:** ${ruleLevel}`, `- **Groups:** ${groups}`, `- **Agent:** ${agentName} (ID: ${agentId})`, `- **Detected:** ${timestamp}`];
    if (alert !== null && alert !== void 0 && alert.full_log) {
      const log = String(alert.full_log).trim().substring(0, 600);
      lines.push(``, `## Raw Log`, ``, `\`\`\``, log, `\`\`\``);
    }
    return lines.join('\n');
  }
}
exports.MonitorService = MonitorService;
_defineProperty(MonitorService, "intervalHandle", null);
_defineProperty(MonitorService, "running", false);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfY29uc3RhbnRzIiwicmVxdWlyZSIsIl9jYXNlX3NlcnZpY2UiLCJfZGVmaW5lUHJvcGVydHkiLCJlIiwiciIsInQiLCJfdG9Qcm9wZXJ0eUtleSIsIk9iamVjdCIsImRlZmluZVByb3BlcnR5IiwidmFsdWUiLCJlbnVtZXJhYmxlIiwiY29uZmlndXJhYmxlIiwid3JpdGFibGUiLCJpIiwiX3RvUHJpbWl0aXZlIiwiU3ltYm9sIiwidG9QcmltaXRpdmUiLCJjYWxsIiwiVHlwZUVycm9yIiwiU3RyaW5nIiwiTnVtYmVyIiwiQ09ORklHX0RPQ19JRCIsIkRFRkFVTFRfQ09ORklHIiwiZW5hYmxlZCIsIm1pbl9sZXZlbCIsImludGVydmFsX21pbnV0ZXMiLCJkZWZhdWx0X3ByaW9yaXR5IiwiZGVmYXVsdF9jYXRlZ29yeSIsImxhc3RfcnVuX2F0IiwibGFzdF9wcm9jZXNzZWRfdGltZXN0YW1wIiwiY2FzZXNfY3JlYXRlZCIsInVwZGF0ZWRfYXQiLCJEYXRlIiwidG9JU09TdHJpbmciLCJNb25pdG9yU2VydmljZSIsImVuc3VyZUNvbmZpZ0luZGV4IiwiY2xpZW50IiwiYm9keSIsImluZGljZXMiLCJleGlzdHMiLCJpbmRleCIsIk1PTklUT1JfQ09ORklHX0lOREVYIiwiY3JlYXRlIiwic2V0dGluZ3MiLCJudW1iZXJfb2Zfc2hhcmRzIiwibnVtYmVyX29mX3JlcGxpY2FzIiwibWFwcGluZ3MiLCJwcm9wZXJ0aWVzIiwidHlwZSIsImdldENvbmZpZyIsImdldCIsImlkIiwiX3NvdXJjZSIsIl9lJG1ldGEiLCJzdGF0dXNDb2RlIiwibWV0YSIsInNhdmVDb25maWciLCJ1cGRhdGVzIiwiZXhpc3RpbmciLCJtZXJnZWQiLCJyZWZyZXNoIiwic3RhcnQiLCJsb2dnZXIiLCJpbnRlcnZhbEhhbmRsZSIsInNldEludGVydmFsIiwidGljayIsIndhcm4iLCJtZXNzYWdlIiwiaW5mbyIsInN0b3AiLCJjbGVhckludGVydmFsIiwiY29uZmlnIiwibm93IiwiaW50ZXJ2YWxNcyIsImxhc3RSdW4iLCJnZXRUaW1lIiwicnVubmluZyIsImNyZWF0ZWQiLCJzY2FuQW5kQ3JlYXRlQ2FzZXMiLCJzaW5jZSIsInNlYXJjaEJvZHkiLCJxdWVyeSIsImJvb2wiLCJtdXN0IiwicmFuZ2UiLCJndGUiLCJzaG91bGQiLCJ0aW1lc3RhbXAiLCJndCIsIm1pbmltdW1fc2hvdWxkX21hdGNoIiwic29ydCIsIm9yZGVyIiwidW5tYXBwZWRfdHlwZSIsInNpemUiLCJoaXRzIiwiX3Jlc3VsdCRoaXRzIiwicmVzdWx0Iiwic2VhcmNoIiwiV0FaVUhfQUxFUlRTX0lOREVYX1BBVFRFUk4iLCJpZ25vcmVfdW5hdmFpbGFibGUiLCJsZW5ndGgiLCJsYXRlc3RUaW1lc3RhbXAiLCJvcGVuQ2FzZUFsZXJ0SWRzIiwiZ2V0TGlua2VkQWxlcnRJZHNGcm9tT3BlbkNhc2VzIiwiaGl0IiwiX2FsZXJ0JHJ1bGUiLCJfYWxlcnQkcnVsZTIiLCJfYWxlcnQkcnVsZTMiLCJfYWxlcnQkYWdlbnQiLCJhbGVydCIsImFsZXJ0SWQiLCJfaWQiLCJhbGVydFRpbWVzdGFtcCIsImhhcyIsInJ1bGVEZXNjcmlwdGlvbiIsInJ1bGUiLCJkZXNjcmlwdGlvbiIsInJ1bGVMZXZlbCIsImxldmVsIiwicnVsZUlkIiwiYWdlbnRJZCIsImFnZW50Iiwic2V2ZXJpdHkiLCJuZXdDYXNlIiwiQ2FzZVNlcnZpY2UiLCJjcmVhdGVDYXNlIiwidGl0bGUiLCJidWlsZERlc2NyaXB0aW9uIiwiX2luZGV4IiwicHJpb3JpdHkiLCJjYXRlZ29yeSIsInRhZ3MiLCJjYXNlRG9jSWQiLCJwcmV0dHlUaXRsZSIsImNhc2VfaWQiLCJsaW5rZWRBbGVydCIsImJ1aWxkTGlua2VkQWxlcnQiLCJ1cGRhdGUiLCJDQVNFX0lOREVYIiwiZG9jIiwibGlua2VkX2FsZXJ0cyIsInJldHJ5X29uX2NvbmZsaWN0IiwiYWRkIiwiaWRzIiwiU2V0IiwidGVybXMiLCJzdGF0dXMiLCJ0ZXJtIiwiX3Jlc3VsdCRoaXRzMiIsImxhIiwiX2hpdCRfc291cmNlIiwiYWxlcnRfaWQiLCJfYWxlcnQkcnVsZTQiLCJfYWxlcnQkcnVsZTUiLCJfYWxlcnQkcnVsZTYiLCJfYWxlcnQkcnVsZTciLCJfYWxlcnQkYWdlbnQyIiwiX2FsZXJ0JGFnZW50MyIsInJ1bGVfaWQiLCJwYXJzZUludCIsInJ1bGVfZGVzY3JpcHRpb24iLCJydWxlX2xldmVsIiwicnVsZV9ncm91cHMiLCJncm91cHMiLCJhZ2VudF9pZCIsImFnZW50X25hbWUiLCJuYW1lIiwiZnVsbF9sb2ciLCJfYWxlcnQkcnVsZTgiLCJfYWxlcnQkcnVsZTkiLCJfYWxlcnQkcnVsZSRsZXZlbCIsIl9hbGVydCRydWxlMTAiLCJfYWxlcnQkYWdlbnQ0IiwiX2FsZXJ0JGFnZW50NSIsIl9hbGVydCRydWxlMTEiLCJydWxlRGVzYyIsImFnZW50TmFtZSIsImpvaW4iLCJyYXdUcyIsInRvTG9jYWxlU3RyaW5nIiwiZGF0ZVN0eWxlIiwidGltZVN0eWxlIiwibGluZXMiLCJsb2ciLCJ0cmltIiwic3Vic3RyaW5nIiwicHVzaCIsImV4cG9ydHMiXSwic291cmNlcyI6WyJtb25pdG9yX3NlcnZpY2UudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLypcbiAqIFdhenVoIENhc2UgTWFuYWdlbWVudCBQbHVnaW5cbiAqIE1vbml0b3IgU2VydmljZSDigJQgYmFja2dyb3VuZCBwb2xsaW5nIGZvciBhdXRvbWF0aWMgY2FzZSBjcmVhdGlvblxuICovXG5cbmltcG9ydCB7IExvZ2dlciB9IGZyb20gJy4uLy4uLy4uLy4uLy4uL3NyYy9jb3JlL3NlcnZlcic7XG5pbXBvcnQgeyBNT05JVE9SX0NPTkZJR19JTkRFWCwgV0FaVUhfQUxFUlRTX0lOREVYX1BBVFRFUk4sIENBU0VfSU5ERVggfSBmcm9tICcuLi8uLi9jb21tb24vY29uc3RhbnRzJztcbmltcG9ydCB7IENhc2VTZXJ2aWNlIH0gZnJvbSAnLi9jYXNlX3NlcnZpY2UnO1xuXG5leHBvcnQgaW50ZXJmYWNlIE1vbml0b3JDb25maWcge1xuICBlbmFibGVkOiBib29sZWFuO1xuICBtaW5fbGV2ZWw6IG51bWJlcjtcbiAgaW50ZXJ2YWxfbWludXRlczogbnVtYmVyO1xuICBkZWZhdWx0X3ByaW9yaXR5OiBzdHJpbmc7XG4gIGRlZmF1bHRfY2F0ZWdvcnk6IHN0cmluZztcbiAgbGFzdF9ydW5fYXQ6IHN0cmluZyB8IG51bGw7XG4gIGxhc3RfcHJvY2Vzc2VkX3RpbWVzdGFtcDogc3RyaW5nIHwgbnVsbDtcbiAgY2FzZXNfY3JlYXRlZDogbnVtYmVyO1xuICB1cGRhdGVkX2F0OiBzdHJpbmc7XG59XG5cbmNvbnN0IENPTkZJR19ET0NfSUQgPSAnbW9uaXRvcl9jb25maWcnO1xuXG5jb25zdCBERUZBVUxUX0NPTkZJRzogTW9uaXRvckNvbmZpZyA9IHtcbiAgZW5hYmxlZDogZmFsc2UsXG4gIG1pbl9sZXZlbDogMTAsXG4gIGludGVydmFsX21pbnV0ZXM6IDUsXG4gIGRlZmF1bHRfcHJpb3JpdHk6ICdQMicsXG4gIGRlZmF1bHRfY2F0ZWdvcnk6ICdvdGhlcicsXG4gIGxhc3RfcnVuX2F0OiBudWxsLFxuICBsYXN0X3Byb2Nlc3NlZF90aW1lc3RhbXA6IG51bGwsXG4gIGNhc2VzX2NyZWF0ZWQ6IDAsXG4gIHVwZGF0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbn07XG5cbmV4cG9ydCBjbGFzcyBNb25pdG9yU2VydmljZSB7XG4gIHByaXZhdGUgc3RhdGljIGludGVydmFsSGFuZGxlOiBSZXR1cm5UeXBlPHR5cGVvZiBzZXRJbnRlcnZhbD4gfCBudWxsID0gbnVsbDtcbiAgcHJpdmF0ZSBzdGF0aWMgcnVubmluZyA9IGZhbHNlO1xuXG4gIC8vIOKUgOKUgCBDb25maWcgQ1JVRCDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuICBzdGF0aWMgYXN5bmMgZW5zdXJlQ29uZmlnSW5kZXgoY2xpZW50OiBhbnkpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgeyBib2R5IH0gPSBhd2FpdCBjbGllbnQuaW5kaWNlcy5leGlzdHMoeyBpbmRleDogTU9OSVRPUl9DT05GSUdfSU5ERVggfSk7XG4gICAgICBpZiAoIWJvZHkpIHtcbiAgICAgICAgYXdhaXQgY2xpZW50LmluZGljZXMuY3JlYXRlKHtcbiAgICAgICAgICBpbmRleDogTU9OSVRPUl9DT05GSUdfSU5ERVgsXG4gICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgc2V0dGluZ3M6IHsgbnVtYmVyX29mX3NoYXJkczogMSwgbnVtYmVyX29mX3JlcGxpY2FzOiAxIH0sXG4gICAgICAgICAgICBtYXBwaW5nczoge1xuICAgICAgICAgICAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgICAgICAgICAgZW5hYmxlZDogeyB0eXBlOiAnYm9vbGVhbicgfSxcbiAgICAgICAgICAgICAgICBtaW5fbGV2ZWw6IHsgdHlwZTogJ2ludGVnZXInIH0sXG4gICAgICAgICAgICAgICAgaW50ZXJ2YWxfbWludXRlczogeyB0eXBlOiAnaW50ZWdlcicgfSxcbiAgICAgICAgICAgICAgICBkZWZhdWx0X3ByaW9yaXR5OiB7IHR5cGU6ICdrZXl3b3JkJyB9LFxuICAgICAgICAgICAgICAgIGRlZmF1bHRfY2F0ZWdvcnk6IHsgdHlwZTogJ2tleXdvcmQnIH0sXG4gICAgICAgICAgICAgICAgbGFzdF9ydW5fYXQ6IHsgdHlwZTogJ2RhdGUnIH0sXG4gICAgICAgICAgICAgICAgbGFzdF9wcm9jZXNzZWRfdGltZXN0YW1wOiB7IHR5cGU6ICdkYXRlJyB9LFxuICAgICAgICAgICAgICAgIGNhc2VzX2NyZWF0ZWQ6IHsgdHlwZTogJ2xvbmcnIH0sXG4gICAgICAgICAgICAgICAgdXBkYXRlZF9hdDogeyB0eXBlOiAnZGF0ZScgfSxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZSkge31cbiAgfVxuXG4gIHN0YXRpYyBhc3luYyBnZXRDb25maWcoY2xpZW50OiBhbnkpOiBQcm9taXNlPE1vbml0b3JDb25maWc+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgeyBib2R5IH0gPSBhd2FpdCBjbGllbnQuZ2V0KHsgaW5kZXg6IE1PTklUT1JfQ09ORklHX0lOREVYLCBpZDogQ09ORklHX0RPQ19JRCB9KTtcbiAgICAgIHJldHVybiBib2R5Ll9zb3VyY2UgYXMgTW9uaXRvckNvbmZpZztcbiAgICB9IGNhdGNoIChlOiBhbnkpIHtcbiAgICAgIGlmIChlPy5zdGF0dXNDb2RlID09PSA0MDQgfHwgZT8ubWV0YT8uc3RhdHVzQ29kZSA9PT0gNDA0KSB7XG4gICAgICAgIHJldHVybiB7IC4uLkRFRkFVTFRfQ09ORklHIH07XG4gICAgICB9XG4gICAgICB0aHJvdyBlO1xuICAgIH1cbiAgfVxuXG4gIHN0YXRpYyBhc3luYyBzYXZlQ29uZmlnKGNsaWVudDogYW55LCB1cGRhdGVzOiBQYXJ0aWFsPE1vbml0b3JDb25maWc+KTogUHJvbWlzZTxNb25pdG9yQ29uZmlnPiB7XG4gICAgY29uc3QgZXhpc3RpbmcgPSBhd2FpdCBNb25pdG9yU2VydmljZS5nZXRDb25maWcoY2xpZW50KTtcbiAgICBjb25zdCBtZXJnZWQ6IE1vbml0b3JDb25maWcgPSB7IC4uLmV4aXN0aW5nLCAuLi51cGRhdGVzLCB1cGRhdGVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkgfTtcbiAgICBhd2FpdCBjbGllbnQuaW5kZXgoe1xuICAgICAgaW5kZXg6IE1PTklUT1JfQ09ORklHX0lOREVYLFxuICAgICAgaWQ6IENPTkZJR19ET0NfSUQsXG4gICAgICBib2R5OiBtZXJnZWQsXG4gICAgICByZWZyZXNoOiAnd2FpdF9mb3InLFxuICAgIH0pO1xuICAgIHJldHVybiBtZXJnZWQ7XG4gIH1cblxuICAvLyDilIDilIAgQmFja2dyb3VuZCBQb2xsaW5nIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG4gIHN0YXRpYyBzdGFydChjbGllbnQ6IGFueSwgbG9nZ2VyOiBMb2dnZXIpOiB2b2lkIHtcbiAgICBpZiAoTW9uaXRvclNlcnZpY2UuaW50ZXJ2YWxIYW5kbGUpIHJldHVybjtcbiAgICBNb25pdG9yU2VydmljZS5pbnRlcnZhbEhhbmRsZSA9IHNldEludGVydmFsKGFzeW5jICgpID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGF3YWl0IE1vbml0b3JTZXJ2aWNlLnRpY2soY2xpZW50LCBsb2dnZXIpO1xuICAgICAgfSBjYXRjaCAoZTogYW55KSB7XG4gICAgICAgIGxvZ2dlci53YXJuKGBNb25pdG9yIHRpY2sgZXJyb3I6ICR7ZS5tZXNzYWdlfWApO1xuICAgICAgfVxuICAgIH0sIDYwXzAwMCk7XG4gICAgbG9nZ2VyLmluZm8oJ0F1dG8tbW9uaXRvciBiYWNrZ3JvdW5kIGpvYiBzdGFydGVkIChjaGVja2luZyBldmVyeSA2MHMpJyk7XG4gIH1cblxuICBzdGF0aWMgc3RvcCgpOiB2b2lkIHtcbiAgICBpZiAoTW9uaXRvclNlcnZpY2UuaW50ZXJ2YWxIYW5kbGUpIHtcbiAgICAgIGNsZWFySW50ZXJ2YWwoTW9uaXRvclNlcnZpY2UuaW50ZXJ2YWxIYW5kbGUpO1xuICAgICAgTW9uaXRvclNlcnZpY2UuaW50ZXJ2YWxIYW5kbGUgPSBudWxsO1xuICAgIH1cbiAgfVxuXG4gIHN0YXRpYyBhc3luYyB0aWNrKGNsaWVudDogYW55LCBsb2dnZXI6IExvZ2dlcik6IFByb21pc2U8dm9pZD4ge1xuICAgIGNvbnN0IGNvbmZpZyA9IGF3YWl0IE1vbml0b3JTZXJ2aWNlLmdldENvbmZpZyhjbGllbnQpO1xuICAgIGlmICghY29uZmlnLmVuYWJsZWQpIHJldHVybjtcblxuICAgIGNvbnN0IG5vdyA9IERhdGUubm93KCk7XG4gICAgY29uc3QgaW50ZXJ2YWxNcyA9IChjb25maWcuaW50ZXJ2YWxfbWludXRlcyB8fCA1KSAqIDYwXzAwMDtcbiAgICBjb25zdCBsYXN0UnVuID0gY29uZmlnLmxhc3RfcnVuX2F0ID8gbmV3IERhdGUoY29uZmlnLmxhc3RfcnVuX2F0KS5nZXRUaW1lKCkgOiAwO1xuICAgIGlmIChub3cgLSBsYXN0UnVuIDwgaW50ZXJ2YWxNcykgcmV0dXJuO1xuXG4gICAgaWYgKE1vbml0b3JTZXJ2aWNlLnJ1bm5pbmcpIHJldHVybjtcbiAgICBNb25pdG9yU2VydmljZS5ydW5uaW5nID0gdHJ1ZTtcblxuICAgIHRyeSB7XG4gICAgICBsb2dnZXIuaW5mbyhgQXV0by1tb25pdG9yOiBzY2FubmluZyBmb3IgcnVsZS5sZXZlbCA+PSAke2NvbmZpZy5taW5fbGV2ZWx9LCBzaW5jZT0ke2NvbmZpZy5sYXN0X3Byb2Nlc3NlZF90aW1lc3RhbXAgfHwgJ2JlZ2lubmluZyd9YCk7XG4gICAgICBjb25zdCBjcmVhdGVkID0gYXdhaXQgTW9uaXRvclNlcnZpY2Uuc2NhbkFuZENyZWF0ZUNhc2VzKGNsaWVudCwgY29uZmlnLCBsb2dnZXIpO1xuICAgICAgYXdhaXQgTW9uaXRvclNlcnZpY2Uuc2F2ZUNvbmZpZyhjbGllbnQsIHtcbiAgICAgICAgbGFzdF9ydW5fYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgICAgY2FzZXNfY3JlYXRlZDogKGNvbmZpZy5jYXNlc19jcmVhdGVkIHx8IDApICsgY3JlYXRlZCxcbiAgICAgIH0pO1xuICAgICAgbG9nZ2VyLmluZm8oYEF1dG8tbW9uaXRvcjogc2NhbiBkb25lLCBjcmVhdGVkPSR7Y3JlYXRlZH1gKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgTW9uaXRvclNlcnZpY2UucnVubmluZyA9IGZhbHNlO1xuICAgIH1cbiAgfVxuXG4gIC8vIOKUgOKUgCBBbGVydCBzY2FubmluZyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuICBzdGF0aWMgYXN5bmMgc2NhbkFuZENyZWF0ZUNhc2VzKFxuICAgIGNsaWVudDogYW55LFxuICAgIGNvbmZpZzogTW9uaXRvckNvbmZpZyxcbiAgICBsb2dnZXI6IExvZ2dlcixcbiAgKTogUHJvbWlzZTxudW1iZXI+IHtcbiAgICAvLyBEZWZhdWx0OiBsb29rIGJhY2sgMjQgaG91cnMgb24gZmlyc3QgcnVuIHNvIGV4aXN0aW5nIGFsZXJ0cyBhcmUgcGlja2VkIHVwXG4gICAgY29uc3Qgc2luY2UgPSBjb25maWcubGFzdF9wcm9jZXNzZWRfdGltZXN0YW1wXG4gICAgICB8fCBuZXcgRGF0ZShEYXRlLm5vdygpIC0gMjQgKiA2MCAqIDYwXzAwMCkudG9JU09TdHJpbmcoKTtcblxuICAgIC8vIEZJWCAxOiBXYXp1aCBhbGVydHMgdXNlIGVpdGhlciBcInRpbWVzdGFtcFwiIG9yIFwiQHRpbWVzdGFtcFwiIGRlcGVuZGluZyBvbiB2ZXJzaW9uLlxuICAgIC8vIFF1ZXJ5IGJvdGggZmllbGRzIHdpdGggYSBzaG91bGQgY2xhdXNlIHNvIGFsZXJ0cyBhcmUgZm91bmQgcmVnYXJkbGVzcy5cbiAgICBjb25zdCBzZWFyY2hCb2R5ID0ge1xuICAgICAgcXVlcnk6IHtcbiAgICAgICAgYm9vbDoge1xuICAgICAgICAgIG11c3Q6IFtcbiAgICAgICAgICAgIHsgcmFuZ2U6IHsgJ3J1bGUubGV2ZWwnOiB7IGd0ZTogTnVtYmVyKGNvbmZpZy5taW5fbGV2ZWwpIH0gfSB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICAgc2hvdWxkOiBbXG4gICAgICAgICAgICB7IHJhbmdlOiB7IHRpbWVzdGFtcDogICB7IGd0OiBzaW5jZSB9IH0gfSxcbiAgICAgICAgICAgIHsgcmFuZ2U6IHsgJ0B0aW1lc3RhbXAnOiB7IGd0OiBzaW5jZSB9IH0gfSxcbiAgICAgICAgICBdLFxuICAgICAgICAgIG1pbmltdW1fc2hvdWxkX21hdGNoOiAxLFxuICAgICAgICB9LFxuICAgICAgfSxcbiAgICAgIHNvcnQ6IFtcbiAgICAgICAgeyB0aW1lc3RhbXA6IHsgb3JkZXI6ICdhc2MnLCB1bm1hcHBlZF90eXBlOiAnZGF0ZScgfSB9LFxuICAgICAgXSxcbiAgICAgIHNpemU6IDEwMCxcbiAgICB9O1xuXG4gICAgbGV0IGhpdHM6IGFueVtdID0gW107XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHsgYm9keTogcmVzdWx0IH0gPSBhd2FpdCBjbGllbnQuc2VhcmNoKHtcbiAgICAgICAgaW5kZXg6IFdBWlVIX0FMRVJUU19JTkRFWF9QQVRURVJOLFxuICAgICAgICBib2R5OiBzZWFyY2hCb2R5LFxuICAgICAgICBpZ25vcmVfdW5hdmFpbGFibGU6IHRydWUsXG4gICAgICB9KTtcbiAgICAgIGhpdHMgPSByZXN1bHQuaGl0cz8uaGl0cyB8fCBbXTtcbiAgICAgIGxvZ2dlci5pbmZvKGBBdXRvLW1vbml0b3I6IGZvdW5kICR7aGl0cy5sZW5ndGh9IGFsZXJ0KHMpIHdpdGggbGV2ZWwgPj0gJHtjb25maWcubWluX2xldmVsfSBzaW5jZSAke3NpbmNlfWApO1xuICAgIH0gY2F0Y2ggKGU6IGFueSkge1xuICAgICAgbG9nZ2VyLndhcm4oYEF1dG8tbW9uaXRvcjogYWxlcnQgc2VhcmNoIGZhaWxlZCDigJQgJHtlLm1lc3NhZ2V9YCk7XG4gICAgICByZXR1cm4gMDtcbiAgICB9XG5cbiAgICBpZiAoaGl0cy5sZW5ndGggPT09IDApIHtcbiAgICAgIGF3YWl0IE1vbml0b3JTZXJ2aWNlLnNhdmVDb25maWcoY2xpZW50LCB7XG4gICAgICAgIGxhc3RfcHJvY2Vzc2VkX3RpbWVzdGFtcDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgfSk7XG4gICAgICByZXR1cm4gMDtcbiAgICB9XG5cbiAgICBsZXQgY3JlYXRlZCA9IDA7XG4gICAgbGV0IGxhdGVzdFRpbWVzdGFtcCA9IHNpbmNlO1xuXG4gICAgLy8gRklYIDI6IENvbGxlY3QgYWxlcnQgSURzIGFscmVhZHkgbGlua2VkIGluIG9wZW4gY2FzZXMgc28gd2UgY2FuIGRlZHVwbGljYXRlXG4gICAgLy8gd2l0aG91dCByZWx5aW5nIG9uIGN1c3RvbV9maWVsZHMgKHdoaWNoIGhhcyBlbmFibGVkOmZhbHNlIGFuZCBpcyBub3QgaW5kZXhlZCkuXG4gICAgY29uc3Qgb3BlbkNhc2VBbGVydElkcyA9IGF3YWl0IE1vbml0b3JTZXJ2aWNlLmdldExpbmtlZEFsZXJ0SWRzRnJvbU9wZW5DYXNlcyhjbGllbnQsIGxvZ2dlcik7XG5cbiAgICBmb3IgKGNvbnN0IGhpdCBvZiBoaXRzKSB7XG4gICAgICBjb25zdCBhbGVydCA9IGhpdC5fc291cmNlO1xuICAgICAgY29uc3QgYWxlcnRJZCA9IGhpdC5faWQ7XG5cbiAgICAgIC8vIFBpY2sgdGltZXN0YW1wIGZyb20gd2hpY2hldmVyIGZpZWxkIGV4aXN0c1xuICAgICAgY29uc3QgYWxlcnRUaW1lc3RhbXA6IHN0cmluZyA9XG4gICAgICAgIGFsZXJ0Py50aW1lc3RhbXAgfHwgYWxlcnQ/LlsnQHRpbWVzdGFtcCddIHx8IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKTtcblxuICAgICAgaWYgKGFsZXJ0VGltZXN0YW1wID4gbGF0ZXN0VGltZXN0YW1wKSBsYXRlc3RUaW1lc3RhbXAgPSBhbGVydFRpbWVzdGFtcDtcblxuICAgICAgLy8gU2tpcCBhbGVydHMgYWxyZWFkeSBsaW5rZWQgdG8gYW4gb3BlbiBjYXNlXG4gICAgICBpZiAob3BlbkNhc2VBbGVydElkcy5oYXMoYWxlcnRJZCkpIHtcbiAgICAgICAgbG9nZ2VyLmluZm8oYEF1dG8tbW9uaXRvcjogYWxlcnQgJHthbGVydElkfSBhbHJlYWR5IGxpbmtlZCDigJQgc2tpcHBpbmdgKTtcbiAgICAgICAgY29udGludWU7XG4gICAgICB9XG5cbiAgICAgIGNvbnN0IHJ1bGVEZXNjcmlwdGlvbiA9IGFsZXJ0Py5ydWxlPy5kZXNjcmlwdGlvbiB8fCAnU2VjdXJpdHkgQWxlcnQnO1xuICAgICAgY29uc3QgcnVsZUxldmVsICAgICAgID0gTnVtYmVyKGFsZXJ0Py5ydWxlPy5sZXZlbCkgfHwgMDtcbiAgICAgIGNvbnN0IHJ1bGVJZCAgICAgICAgICA9IFN0cmluZyhhbGVydD8ucnVsZT8uaWQgfHwgJycpO1xuICAgICAgY29uc3QgYWdlbnRJZCAgICAgICAgID0gU3RyaW5nKGFsZXJ0Py5hZ2VudD8uaWQgfHwgJycpO1xuXG4gICAgICB0cnkge1xuICAgICAgICBsZXQgc2V2ZXJpdHkgPSAnbG93JztcbiAgICAgICAgaWYgKHJ1bGVMZXZlbCA+PSAxMykgc2V2ZXJpdHkgPSAnY3JpdGljYWwnO1xuICAgICAgICBlbHNlIGlmIChydWxlTGV2ZWwgPj0gMTApIHNldmVyaXR5ID0gJ2hpZ2gnO1xuICAgICAgICBlbHNlIGlmIChydWxlTGV2ZWwgPj0gNykgIHNldmVyaXR5ID0gJ21lZGl1bSc7XG5cbiAgICAgICAgY29uc3QgbmV3Q2FzZSA9IGF3YWl0IENhc2VTZXJ2aWNlLmNyZWF0ZUNhc2UoXG4gICAgICAgICAgY2xpZW50LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIHRpdGxlOiAnUExBQ0VIT0xERVInLFxuICAgICAgICAgICAgZGVzY3JpcHRpb246IE1vbml0b3JTZXJ2aWNlLmJ1aWxkRGVzY3JpcHRpb24oYWxlcnQsIGhpdC5faW5kZXgpLFxuICAgICAgICAgICAgc2V2ZXJpdHk6IHNldmVyaXR5IGFzIGFueSxcbiAgICAgICAgICAgIHByaW9yaXR5OiBjb25maWcuZGVmYXVsdF9wcmlvcml0eSBhcyBhbnksXG4gICAgICAgICAgICBjYXRlZ29yeTogY29uZmlnLmRlZmF1bHRfY2F0ZWdvcnkgYXMgYW55LFxuICAgICAgICAgICAgdGFnczogWydhdXRvLWNyZWF0ZWQnLCBgbGV2ZWwtJHtydWxlTGV2ZWx9YCwgLi4uKHJ1bGVJZCA/IFtgcnVsZS0ke3J1bGVJZH1gXSA6IFtdKV0sXG4gICAgICAgICAgfSxcbiAgICAgICAgICAnYXV0by1tb25pdG9yJyxcbiAgICAgICAgKTtcblxuICAgICAgICBjb25zdCBjYXNlRG9jSWQgICAgICA9IG5ld0Nhc2UuaWQhO1xuICAgICAgICAvLyBUaXRsZSBmb3JtYXQ6IENBU0UtPGNhc2VJRD46IDxydWxlLmRlc2NyaXB0aW9uPiAgKHVzZXMgdGhlIHJlYWwgY2FzZV9pZClcbiAgICAgICAgY29uc3QgcHJldHR5VGl0bGUgICAgPSBgJHtuZXdDYXNlLmNhc2VfaWR9OiAke3J1bGVEZXNjcmlwdGlvbn1gO1xuICAgICAgICBjb25zdCBsaW5rZWRBbGVydCAgICA9IE1vbml0b3JTZXJ2aWNlLmJ1aWxkTGlua2VkQWxlcnQoaGl0KTtcblxuICAgICAgICBhd2FpdCBjbGllbnQudXBkYXRlKHtcbiAgICAgICAgICBpbmRleDogQ0FTRV9JTkRFWCxcbiAgICAgICAgICBpZDogY2FzZURvY0lkLFxuICAgICAgICAgIGJvZHk6IHtcbiAgICAgICAgICAgIGRvYzoge1xuICAgICAgICAgICAgICB0aXRsZTogcHJldHR5VGl0bGUsXG4gICAgICAgICAgICAgIGxpbmtlZF9hbGVydHM6IFtsaW5rZWRBbGVydF0sXG4gICAgICAgICAgICAgIC8vIEZJWCAzOiBzdG9yZSBkZWR1cCBrZXlzIGFzIGluZGV4ZWQgdGFncyBpbnN0ZWFkIG9mIGN1c3RvbV9maWVsZHNcbiAgICAgICAgICAgICAgdGFnczogWydhdXRvLWNyZWF0ZWQnLCBgbGV2ZWwtJHtydWxlTGV2ZWx9YCwgYGF1dG8tYWxlcnQtJHthbGVydElkfWBdLFxuICAgICAgICAgICAgICB1cGRhdGVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgICAgcmV0cnlfb25fY29uZmxpY3Q6IDMsXG4gICAgICAgIH0pO1xuXG4gICAgICAgIC8vIEFkZCB0byBsb2NhbCBzZXQgc28gd2UgZG9uJ3QgY3JlYXRlIGR1cGxpY2F0ZXMgd2l0aGluIHRoZSBzYW1lIHNjYW4gYmF0Y2hcbiAgICAgICAgb3BlbkNhc2VBbGVydElkcy5hZGQoYWxlcnRJZCk7XG5cbiAgICAgICAgY3JlYXRlZCsrO1xuICAgICAgICBsb2dnZXIuaW5mbyhgQXV0by1tb25pdG9yOiBjcmVhdGVkICR7cHJldHR5VGl0bGV9YCk7XG4gICAgICB9IGNhdGNoIChlOiBhbnkpIHtcbiAgICAgICAgbG9nZ2VyLndhcm4oYEF1dG8tbW9uaXRvcjogZmFpbGVkIHRvIHByb2Nlc3MgYWxlcnQgJHthbGVydElkfSDigJQgJHtlLm1lc3NhZ2V9YCk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgYXdhaXQgTW9uaXRvclNlcnZpY2Uuc2F2ZUNvbmZpZyhjbGllbnQsIHtcbiAgICAgIGxhc3RfcHJvY2Vzc2VkX3RpbWVzdGFtcDogbGF0ZXN0VGltZXN0YW1wLFxuICAgIH0pO1xuXG4gICAgcmV0dXJuIGNyZWF0ZWQ7XG4gIH1cblxuICAvKipcbiAgICogUmV0dXJucyB0aGUgc2V0IG9mIGFsZXJ0IElEcyBhbHJlYWR5IGxpbmtlZCBpbnNpZGUgYW55IG9wZW4vaW4tcHJvZ3Jlc3Mvd2FpdGluZyBjYXNlLlxuICAgKiBVc2VkIGZvciBkZWR1cGxpY2F0aW9uIGluc3RlYWQgb2YgY3VzdG9tX2ZpZWxkcyAod2hpY2ggaXMgbm90IGluZGV4ZWQpLlxuICAgKi9cbiAgcHJpdmF0ZSBzdGF0aWMgYXN5bmMgZ2V0TGlua2VkQWxlcnRJZHNGcm9tT3BlbkNhc2VzKFxuICAgIGNsaWVudDogYW55LFxuICAgIGxvZ2dlcjogTG9nZ2VyLFxuICApOiBQcm9taXNlPFNldDxzdHJpbmc+PiB7XG4gICAgY29uc3QgaWRzID0gbmV3IFNldDxzdHJpbmc+KCk7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHsgYm9keTogcmVzdWx0IH0gPSBhd2FpdCBjbGllbnQuc2VhcmNoKHtcbiAgICAgICAgaW5kZXg6IENBU0VfSU5ERVgsXG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBxdWVyeToge1xuICAgICAgICAgICAgYm9vbDoge1xuICAgICAgICAgICAgICBtdXN0OiBbXG4gICAgICAgICAgICAgICAgeyB0ZXJtczogeyBzdGF0dXM6IFsnb3BlbicsICdpbl9wcm9ncmVzcycsICd3YWl0aW5nJ10gfSB9LFxuICAgICAgICAgICAgICAgIHsgdGVybTogeyB0YWdzOiAnYXV0by1jcmVhdGVkJyB9IH0sXG4gICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgICAgX3NvdXJjZTogWydsaW5rZWRfYWxlcnRzJ10sXG4gICAgICAgICAgc2l6ZTogNTAwLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgICBmb3IgKGNvbnN0IGhpdCBvZiAocmVzdWx0LmhpdHM/LmhpdHMgfHwgW10pKSB7XG4gICAgICAgIGZvciAoY29uc3QgbGEgb2YgKGhpdC5fc291cmNlPy5saW5rZWRfYWxlcnRzIHx8IFtdKSkge1xuICAgICAgICAgIGlmIChsYS5hbGVydF9pZCkgaWRzLmFkZChsYS5hbGVydF9pZCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9IGNhdGNoIChlOiBhbnkpIHtcbiAgICAgIGxvZ2dlci53YXJuKGBBdXRvLW1vbml0b3I6IGNvdWxkIG5vdCBmZXRjaCBvcGVuIGNhc2UgYWxlcnQgSURzIOKAlCAke2UubWVzc2FnZX1gKTtcbiAgICB9XG4gICAgcmV0dXJuIGlkcztcbiAgfVxuXG4gIHByaXZhdGUgc3RhdGljIGJ1aWxkTGlua2VkQWxlcnQoaGl0OiBhbnkpOiBhbnkge1xuICAgIGNvbnN0IGFsZXJ0ID0gaGl0Ll9zb3VyY2U7XG4gICAgcmV0dXJuIHtcbiAgICAgIGFsZXJ0X2lkOiAgICAgICAgIGhpdC5faWQsXG4gICAgICBpbmRleDogICAgICAgICAgICBoaXQuX2luZGV4IHx8IFdBWlVIX0FMRVJUU19JTkRFWF9QQVRURVJOLFxuICAgICAgcnVsZV9pZDogICAgICAgICAgcGFyc2VJbnQoYWxlcnQ/LnJ1bGU/LmlkIHx8ICcwJywgMTApLFxuICAgICAgcnVsZV9kZXNjcmlwdGlvbjogYWxlcnQ/LnJ1bGU/LmRlc2NyaXB0aW9uIHx8ICcnLFxuICAgICAgcnVsZV9sZXZlbDogICAgICAgYWxlcnQ/LnJ1bGU/LmxldmVsIHx8IDAsXG4gICAgICBydWxlX2dyb3VwczogICAgICBhbGVydD8ucnVsZT8uZ3JvdXBzIHx8IFtdLFxuICAgICAgYWdlbnRfaWQ6ICAgICAgICAgYWxlcnQ/LmFnZW50Py5pZCB8fCAnJyxcbiAgICAgIGFnZW50X25hbWU6ICAgICAgIGFsZXJ0Py5hZ2VudD8ubmFtZSB8fCAnJyxcbiAgICAgIHRpbWVzdGFtcDogICAgICAgIGFsZXJ0Py50aW1lc3RhbXAgfHwgYWxlcnQ/LlsnQHRpbWVzdGFtcCddIHx8IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgIGZ1bGxfbG9nOiAgICAgICAgIGFsZXJ0Py5mdWxsX2xvZyB8fCAnJyxcbiAgICB9O1xuICB9XG5cbiAgcHJpdmF0ZSBzdGF0aWMgYnVpbGREZXNjcmlwdGlvbihhbGVydDogYW55LCBpbmRleDogc3RyaW5nKTogc3RyaW5nIHtcbiAgICBjb25zdCBydWxlSWQgICAgPSBhbGVydD8ucnVsZT8uaWQgfHwgJ04vQSc7XG4gICAgY29uc3QgcnVsZURlc2MgID0gYWxlcnQ/LnJ1bGU/LmRlc2NyaXB0aW9uIHx8ICdOL0EnO1xuICAgIGNvbnN0IHJ1bGVMZXZlbCA9IGFsZXJ0Py5ydWxlPy5sZXZlbCA/PyAnTi9BJztcbiAgICBjb25zdCBhZ2VudE5hbWUgPSBhbGVydD8uYWdlbnQ/Lm5hbWUgfHwgJ1Vua25vd24nO1xuICAgIGNvbnN0IGFnZW50SWQgICA9IGFsZXJ0Py5hZ2VudD8uaWQgfHwgJ04vQSc7XG4gICAgY29uc3QgZ3JvdXBzICAgID0gKGFsZXJ0Py5ydWxlPy5ncm91cHMgfHwgW10pLmpvaW4oJywgJykgfHwgJ04vQSc7XG4gICAgY29uc3QgcmF3VHMgICAgID0gYWxlcnQ/LnRpbWVzdGFtcCB8fCBhbGVydD8uWydAdGltZXN0YW1wJ107XG4gICAgY29uc3QgdGltZXN0YW1wID0gcmF3VHNcbiAgICAgID8gbmV3IERhdGUocmF3VHMpLnRvTG9jYWxlU3RyaW5nKCdlbi1HQicsIHsgZGF0ZVN0eWxlOiAnbWVkaXVtJywgdGltZVN0eWxlOiAnbWVkaXVtJyB9KVxuICAgICAgOiAnTi9BJztcblxuICAgIGNvbnN0IGxpbmVzOiBzdHJpbmdbXSA9IFtcbiAgICAgIGBUaGlzIGNhc2Ugd2FzIGF1dG9tYXRpY2FsbHkgY3JlYXRlZCBieSB0aGUgV2F6dWggQ2FzZSBNb25pdG9yLmAsXG4gICAgICBgYCxcbiAgICAgIGAjIyBBbGVydCBEZXRhaWxzYCxcbiAgICAgIGBgLFxuICAgICAgYC0gKipSdWxlIElEOioqICR7cnVsZUlkfWAsXG4gICAgICBgLSAqKkRlc2NyaXB0aW9uOioqICR7cnVsZURlc2N9YCxcbiAgICAgIGAtICoqTGV2ZWw6KiogJHtydWxlTGV2ZWx9YCxcbiAgICAgIGAtICoqR3JvdXBzOioqICR7Z3JvdXBzfWAsXG4gICAgICBgLSAqKkFnZW50OioqICR7YWdlbnROYW1lfSAoSUQ6ICR7YWdlbnRJZH0pYCxcbiAgICAgIGAtICoqRGV0ZWN0ZWQ6KiogJHt0aW1lc3RhbXB9YCxcbiAgICBdO1xuXG4gICAgaWYgKGFsZXJ0Py5mdWxsX2xvZykge1xuICAgICAgY29uc3QgbG9nID0gU3RyaW5nKGFsZXJ0LmZ1bGxfbG9nKS50cmltKCkuc3Vic3RyaW5nKDAsIDYwMCk7XG4gICAgICBsaW5lcy5wdXNoKGBgLCBgIyMgUmF3IExvZ2AsIGBgLCBgXFxgXFxgXFxgYCwgbG9nLCBgXFxgXFxgXFxgYCk7XG4gICAgfVxuXG4gICAgcmV0dXJuIGxpbmVzLmpvaW4oJ1xcbicpO1xuICB9XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQU1BLElBQUFBLFVBQUEsR0FBQUMsT0FBQTtBQUNBLElBQUFDLGFBQUEsR0FBQUQsT0FBQTtBQUE2QyxTQUFBRSxnQkFBQUMsQ0FBQSxFQUFBQyxDQUFBLEVBQUFDLENBQUEsWUFBQUQsQ0FBQSxHQUFBRSxjQUFBLENBQUFGLENBQUEsTUFBQUQsQ0FBQSxHQUFBSSxNQUFBLENBQUFDLGNBQUEsQ0FBQUwsQ0FBQSxFQUFBQyxDQUFBLElBQUFLLEtBQUEsRUFBQUosQ0FBQSxFQUFBSyxVQUFBLE1BQUFDLFlBQUEsTUFBQUMsUUFBQSxVQUFBVCxDQUFBLENBQUFDLENBQUEsSUFBQUMsQ0FBQSxFQUFBRixDQUFBO0FBQUEsU0FBQUcsZUFBQUQsQ0FBQSxRQUFBUSxDQUFBLEdBQUFDLFlBQUEsQ0FBQVQsQ0FBQSx1Q0FBQVEsQ0FBQSxHQUFBQSxDQUFBLEdBQUFBLENBQUE7QUFBQSxTQUFBQyxhQUFBVCxDQUFBLEVBQUFELENBQUEsMkJBQUFDLENBQUEsS0FBQUEsQ0FBQSxTQUFBQSxDQUFBLE1BQUFGLENBQUEsR0FBQUUsQ0FBQSxDQUFBVSxNQUFBLENBQUFDLFdBQUEsa0JBQUFiLENBQUEsUUFBQVUsQ0FBQSxHQUFBVixDQUFBLENBQUFjLElBQUEsQ0FBQVosQ0FBQSxFQUFBRCxDQUFBLHVDQUFBUyxDQUFBLFNBQUFBLENBQUEsWUFBQUssU0FBQSx5RUFBQWQsQ0FBQSxHQUFBZSxNQUFBLEdBQUFDLE1BQUEsRUFBQWYsQ0FBQSxLQVA3QztBQUNBO0FBQ0E7QUFDQTtBQWtCQSxNQUFNZ0IsYUFBYSxHQUFHLGdCQUFnQjtBQUV0QyxNQUFNQyxjQUE2QixHQUFHO0VBQ3BDQyxPQUFPLEVBQUUsS0FBSztFQUNkQyxTQUFTLEVBQUUsRUFBRTtFQUNiQyxnQkFBZ0IsRUFBRSxDQUFDO0VBQ25CQyxnQkFBZ0IsRUFBRSxJQUFJO0VBQ3RCQyxnQkFBZ0IsRUFBRSxPQUFPO0VBQ3pCQyxXQUFXLEVBQUUsSUFBSTtFQUNqQkMsd0JBQXdCLEVBQUUsSUFBSTtFQUM5QkMsYUFBYSxFQUFFLENBQUM7RUFDaEJDLFVBQVUsRUFBRSxJQUFJQyxJQUFJLENBQUMsQ0FBQyxDQUFDQyxXQUFXLENBQUM7QUFDckMsQ0FBQztBQUVNLE1BQU1DLGNBQWMsQ0FBQztFQUkxQjs7RUFFQSxhQUFhQyxpQkFBaUJBLENBQUNDLE1BQVcsRUFBaUI7SUFDekQsSUFBSTtNQUNGLE1BQU07UUFBRUM7TUFBSyxDQUFDLEdBQUcsTUFBTUQsTUFBTSxDQUFDRSxPQUFPLENBQUNDLE1BQU0sQ0FBQztRQUFFQyxLQUFLLEVBQUVDO01BQXFCLENBQUMsQ0FBQztNQUM3RSxJQUFJLENBQUNKLElBQUksRUFBRTtRQUNULE1BQU1ELE1BQU0sQ0FBQ0UsT0FBTyxDQUFDSSxNQUFNLENBQUM7VUFDMUJGLEtBQUssRUFBRUMsK0JBQW9CO1VBQzNCSixJQUFJLEVBQUU7WUFDSk0sUUFBUSxFQUFFO2NBQUVDLGdCQUFnQixFQUFFLENBQUM7Y0FBRUMsa0JBQWtCLEVBQUU7WUFBRSxDQUFDO1lBQ3hEQyxRQUFRLEVBQUU7Y0FDUkMsVUFBVSxFQUFFO2dCQUNWeEIsT0FBTyxFQUFFO2tCQUFFeUIsSUFBSSxFQUFFO2dCQUFVLENBQUM7Z0JBQzVCeEIsU0FBUyxFQUFFO2tCQUFFd0IsSUFBSSxFQUFFO2dCQUFVLENBQUM7Z0JBQzlCdkIsZ0JBQWdCLEVBQUU7a0JBQUV1QixJQUFJLEVBQUU7Z0JBQVUsQ0FBQztnQkFDckN0QixnQkFBZ0IsRUFBRTtrQkFBRXNCLElBQUksRUFBRTtnQkFBVSxDQUFDO2dCQUNyQ3JCLGdCQUFnQixFQUFFO2tCQUFFcUIsSUFBSSxFQUFFO2dCQUFVLENBQUM7Z0JBQ3JDcEIsV0FBVyxFQUFFO2tCQUFFb0IsSUFBSSxFQUFFO2dCQUFPLENBQUM7Z0JBQzdCbkIsd0JBQXdCLEVBQUU7a0JBQUVtQixJQUFJLEVBQUU7Z0JBQU8sQ0FBQztnQkFDMUNsQixhQUFhLEVBQUU7a0JBQUVrQixJQUFJLEVBQUU7Z0JBQU8sQ0FBQztnQkFDL0JqQixVQUFVLEVBQUU7a0JBQUVpQixJQUFJLEVBQUU7Z0JBQU87Y0FDN0I7WUFDRjtVQUNGO1FBQ0YsQ0FBQyxDQUFDO01BQ0o7SUFDRixDQUFDLENBQUMsT0FBTzdDLENBQUMsRUFBRSxDQUFDO0VBQ2Y7RUFFQSxhQUFhOEMsU0FBU0EsQ0FBQ2IsTUFBVyxFQUEwQjtJQUMxRCxJQUFJO01BQ0YsTUFBTTtRQUFFQztNQUFLLENBQUMsR0FBRyxNQUFNRCxNQUFNLENBQUNjLEdBQUcsQ0FBQztRQUFFVixLQUFLLEVBQUVDLCtCQUFvQjtRQUFFVSxFQUFFLEVBQUU5QjtNQUFjLENBQUMsQ0FBQztNQUNyRixPQUFPZ0IsSUFBSSxDQUFDZSxPQUFPO0lBQ3JCLENBQUMsQ0FBQyxPQUFPakQsQ0FBTSxFQUFFO01BQUEsSUFBQWtELE9BQUE7TUFDZixJQUFJLENBQUFsRCxDQUFDLGFBQURBLENBQUMsdUJBQURBLENBQUMsQ0FBRW1ELFVBQVUsTUFBSyxHQUFHLElBQUksQ0FBQW5ELENBQUMsYUFBREEsQ0FBQyxnQkFBQWtELE9BQUEsR0FBRGxELENBQUMsQ0FBRW9ELElBQUksY0FBQUYsT0FBQSx1QkFBUEEsT0FBQSxDQUFTQyxVQUFVLE1BQUssR0FBRyxFQUFFO1FBQ3hELE9BQU87VUFBRSxHQUFHaEM7UUFBZSxDQUFDO01BQzlCO01BQ0EsTUFBTW5CLENBQUM7SUFDVDtFQUNGO0VBRUEsYUFBYXFELFVBQVVBLENBQUNwQixNQUFXLEVBQUVxQixPQUErQixFQUEwQjtJQUM1RixNQUFNQyxRQUFRLEdBQUcsTUFBTXhCLGNBQWMsQ0FBQ2UsU0FBUyxDQUFDYixNQUFNLENBQUM7SUFDdkQsTUFBTXVCLE1BQXFCLEdBQUc7TUFBRSxHQUFHRCxRQUFRO01BQUUsR0FBR0QsT0FBTztNQUFFMUIsVUFBVSxFQUFFLElBQUlDLElBQUksQ0FBQyxDQUFDLENBQUNDLFdBQVcsQ0FBQztJQUFFLENBQUM7SUFDL0YsTUFBTUcsTUFBTSxDQUFDSSxLQUFLLENBQUM7TUFDakJBLEtBQUssRUFBRUMsK0JBQW9CO01BQzNCVSxFQUFFLEVBQUU5QixhQUFhO01BQ2pCZ0IsSUFBSSxFQUFFc0IsTUFBTTtNQUNaQyxPQUFPLEVBQUU7SUFDWCxDQUFDLENBQUM7SUFDRixPQUFPRCxNQUFNO0VBQ2Y7O0VBRUE7O0VBRUEsT0FBT0UsS0FBS0EsQ0FBQ3pCLE1BQVcsRUFBRTBCLE1BQWMsRUFBUTtJQUM5QyxJQUFJNUIsY0FBYyxDQUFDNkIsY0FBYyxFQUFFO0lBQ25DN0IsY0FBYyxDQUFDNkIsY0FBYyxHQUFHQyxXQUFXLENBQUMsWUFBWTtNQUN0RCxJQUFJO1FBQ0YsTUFBTTlCLGNBQWMsQ0FBQytCLElBQUksQ0FBQzdCLE1BQU0sRUFBRTBCLE1BQU0sQ0FBQztNQUMzQyxDQUFDLENBQUMsT0FBTzNELENBQU0sRUFBRTtRQUNmMkQsTUFBTSxDQUFDSSxJQUFJLENBQUUsdUJBQXNCL0QsQ0FBQyxDQUFDZ0UsT0FBUSxFQUFDLENBQUM7TUFDakQ7SUFDRixDQUFDLEVBQUUsTUFBTSxDQUFDO0lBQ1ZMLE1BQU0sQ0FBQ00sSUFBSSxDQUFDLDBEQUEwRCxDQUFDO0VBQ3pFO0VBRUEsT0FBT0MsSUFBSUEsQ0FBQSxFQUFTO0lBQ2xCLElBQUluQyxjQUFjLENBQUM2QixjQUFjLEVBQUU7TUFDakNPLGFBQWEsQ0FBQ3BDLGNBQWMsQ0FBQzZCLGNBQWMsQ0FBQztNQUM1QzdCLGNBQWMsQ0FBQzZCLGNBQWMsR0FBRyxJQUFJO0lBQ3RDO0VBQ0Y7RUFFQSxhQUFhRSxJQUFJQSxDQUFDN0IsTUFBVyxFQUFFMEIsTUFBYyxFQUFpQjtJQUM1RCxNQUFNUyxNQUFNLEdBQUcsTUFBTXJDLGNBQWMsQ0FBQ2UsU0FBUyxDQUFDYixNQUFNLENBQUM7SUFDckQsSUFBSSxDQUFDbUMsTUFBTSxDQUFDaEQsT0FBTyxFQUFFO0lBRXJCLE1BQU1pRCxHQUFHLEdBQUd4QyxJQUFJLENBQUN3QyxHQUFHLENBQUMsQ0FBQztJQUN0QixNQUFNQyxVQUFVLEdBQUcsQ0FBQ0YsTUFBTSxDQUFDOUMsZ0JBQWdCLElBQUksQ0FBQyxJQUFJLE1BQU07SUFDMUQsTUFBTWlELE9BQU8sR0FBR0gsTUFBTSxDQUFDM0MsV0FBVyxHQUFHLElBQUlJLElBQUksQ0FBQ3VDLE1BQU0sQ0FBQzNDLFdBQVcsQ0FBQyxDQUFDK0MsT0FBTyxDQUFDLENBQUMsR0FBRyxDQUFDO0lBQy9FLElBQUlILEdBQUcsR0FBR0UsT0FBTyxHQUFHRCxVQUFVLEVBQUU7SUFFaEMsSUFBSXZDLGNBQWMsQ0FBQzBDLE9BQU8sRUFBRTtJQUM1QjFDLGNBQWMsQ0FBQzBDLE9BQU8sR0FBRyxJQUFJO0lBRTdCLElBQUk7TUFDRmQsTUFBTSxDQUFDTSxJQUFJLENBQUUsNENBQTJDRyxNQUFNLENBQUMvQyxTQUFVLFdBQVUrQyxNQUFNLENBQUMxQyx3QkFBd0IsSUFBSSxXQUFZLEVBQUMsQ0FBQztNQUNwSSxNQUFNZ0QsT0FBTyxHQUFHLE1BQU0zQyxjQUFjLENBQUM0QyxrQkFBa0IsQ0FBQzFDLE1BQU0sRUFBRW1DLE1BQU0sRUFBRVQsTUFBTSxDQUFDO01BQy9FLE1BQU01QixjQUFjLENBQUNzQixVQUFVLENBQUNwQixNQUFNLEVBQUU7UUFDdENSLFdBQVcsRUFBRSxJQUFJSSxJQUFJLENBQUMsQ0FBQyxDQUFDQyxXQUFXLENBQUMsQ0FBQztRQUNyQ0gsYUFBYSxFQUFFLENBQUN5QyxNQUFNLENBQUN6QyxhQUFhLElBQUksQ0FBQyxJQUFJK0M7TUFDL0MsQ0FBQyxDQUFDO01BQ0ZmLE1BQU0sQ0FBQ00sSUFBSSxDQUFFLG9DQUFtQ1MsT0FBUSxFQUFDLENBQUM7SUFDNUQsQ0FBQyxTQUFTO01BQ1IzQyxjQUFjLENBQUMwQyxPQUFPLEdBQUcsS0FBSztJQUNoQztFQUNGOztFQUVBOztFQUVBLGFBQWFFLGtCQUFrQkEsQ0FDN0IxQyxNQUFXLEVBQ1htQyxNQUFxQixFQUNyQlQsTUFBYyxFQUNHO0lBQ2pCO0lBQ0EsTUFBTWlCLEtBQUssR0FBR1IsTUFBTSxDQUFDMUMsd0JBQXdCLElBQ3hDLElBQUlHLElBQUksQ0FBQ0EsSUFBSSxDQUFDd0MsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLE1BQU0sQ0FBQyxDQUFDdkMsV0FBVyxDQUFDLENBQUM7O0lBRTFEO0lBQ0E7SUFDQSxNQUFNK0MsVUFBVSxHQUFHO01BQ2pCQyxLQUFLLEVBQUU7UUFDTEMsSUFBSSxFQUFFO1VBQ0pDLElBQUksRUFBRSxDQUNKO1lBQUVDLEtBQUssRUFBRTtjQUFFLFlBQVksRUFBRTtnQkFBRUMsR0FBRyxFQUFFakUsTUFBTSxDQUFDbUQsTUFBTSxDQUFDL0MsU0FBUztjQUFFO1lBQUU7VUFBRSxDQUFDLENBQy9EO1VBQ0Q4RCxNQUFNLEVBQUUsQ0FDTjtZQUFFRixLQUFLLEVBQUU7Y0FBRUcsU0FBUyxFQUFJO2dCQUFFQyxFQUFFLEVBQUVUO2NBQU07WUFBRTtVQUFFLENBQUMsRUFDekM7WUFBRUssS0FBSyxFQUFFO2NBQUUsWUFBWSxFQUFFO2dCQUFFSSxFQUFFLEVBQUVUO2NBQU07WUFBRTtVQUFFLENBQUMsQ0FDM0M7VUFDRFUsb0JBQW9CLEVBQUU7UUFDeEI7TUFDRixDQUFDO01BQ0RDLElBQUksRUFBRSxDQUNKO1FBQUVILFNBQVMsRUFBRTtVQUFFSSxLQUFLLEVBQUUsS0FBSztVQUFFQyxhQUFhLEVBQUU7UUFBTztNQUFFLENBQUMsQ0FDdkQ7TUFDREMsSUFBSSxFQUFFO0lBQ1IsQ0FBQztJQUVELElBQUlDLElBQVcsR0FBRyxFQUFFO0lBQ3BCLElBQUk7TUFBQSxJQUFBQyxZQUFBO01BQ0YsTUFBTTtRQUFFMUQsSUFBSSxFQUFFMkQ7TUFBTyxDQUFDLEdBQUcsTUFBTTVELE1BQU0sQ0FBQzZELE1BQU0sQ0FBQztRQUMzQ3pELEtBQUssRUFBRTBELHFDQUEwQjtRQUNqQzdELElBQUksRUFBRTJDLFVBQVU7UUFDaEJtQixrQkFBa0IsRUFBRTtNQUN0QixDQUFDLENBQUM7TUFDRkwsSUFBSSxHQUFHLEVBQUFDLFlBQUEsR0FBQUMsTUFBTSxDQUFDRixJQUFJLGNBQUFDLFlBQUEsdUJBQVhBLFlBQUEsQ0FBYUQsSUFBSSxLQUFJLEVBQUU7TUFDOUJoQyxNQUFNLENBQUNNLElBQUksQ0FBRSx1QkFBc0IwQixJQUFJLENBQUNNLE1BQU8sMkJBQTBCN0IsTUFBTSxDQUFDL0MsU0FBVSxVQUFTdUQsS0FBTSxFQUFDLENBQUM7SUFDN0csQ0FBQyxDQUFDLE9BQU81RSxDQUFNLEVBQUU7TUFDZjJELE1BQU0sQ0FBQ0ksSUFBSSxDQUFFLHVDQUFzQy9ELENBQUMsQ0FBQ2dFLE9BQVEsRUFBQyxDQUFDO01BQy9ELE9BQU8sQ0FBQztJQUNWO0lBRUEsSUFBSTJCLElBQUksQ0FBQ00sTUFBTSxLQUFLLENBQUMsRUFBRTtNQUNyQixNQUFNbEUsY0FBYyxDQUFDc0IsVUFBVSxDQUFDcEIsTUFBTSxFQUFFO1FBQ3RDUCx3QkFBd0IsRUFBRSxJQUFJRyxJQUFJLENBQUMsQ0FBQyxDQUFDQyxXQUFXLENBQUM7TUFDbkQsQ0FBQyxDQUFDO01BQ0YsT0FBTyxDQUFDO0lBQ1Y7SUFFQSxJQUFJNEMsT0FBTyxHQUFHLENBQUM7SUFDZixJQUFJd0IsZUFBZSxHQUFHdEIsS0FBSzs7SUFFM0I7SUFDQTtJQUNBLE1BQU11QixnQkFBZ0IsR0FBRyxNQUFNcEUsY0FBYyxDQUFDcUUsOEJBQThCLENBQUNuRSxNQUFNLEVBQUUwQixNQUFNLENBQUM7SUFFNUYsS0FBSyxNQUFNMEMsR0FBRyxJQUFJVixJQUFJLEVBQUU7TUFBQSxJQUFBVyxXQUFBLEVBQUFDLFlBQUEsRUFBQUMsWUFBQSxFQUFBQyxZQUFBO01BQ3RCLE1BQU1DLEtBQUssR0FBR0wsR0FBRyxDQUFDcEQsT0FBTztNQUN6QixNQUFNMEQsT0FBTyxHQUFHTixHQUFHLENBQUNPLEdBQUc7O01BRXZCO01BQ0EsTUFBTUMsY0FBc0IsR0FDMUIsQ0FBQUgsS0FBSyxhQUFMQSxLQUFLLHVCQUFMQSxLQUFLLENBQUV0QixTQUFTLE1BQUlzQixLQUFLLGFBQUxBLEtBQUssdUJBQUxBLEtBQUssQ0FBRyxZQUFZLENBQUMsS0FBSSxJQUFJN0UsSUFBSSxDQUFDLENBQUMsQ0FBQ0MsV0FBVyxDQUFDLENBQUM7TUFFdkUsSUFBSStFLGNBQWMsR0FBR1gsZUFBZSxFQUFFQSxlQUFlLEdBQUdXLGNBQWM7O01BRXRFO01BQ0EsSUFBSVYsZ0JBQWdCLENBQUNXLEdBQUcsQ0FBQ0gsT0FBTyxDQUFDLEVBQUU7UUFDakNoRCxNQUFNLENBQUNNLElBQUksQ0FBRSx1QkFBc0IwQyxPQUFRLDRCQUEyQixDQUFDO1FBQ3ZFO01BQ0Y7TUFFQSxNQUFNSSxlQUFlLEdBQUcsQ0FBQUwsS0FBSyxhQUFMQSxLQUFLLGdCQUFBSixXQUFBLEdBQUxJLEtBQUssQ0FBRU0sSUFBSSxjQUFBVixXQUFBLHVCQUFYQSxXQUFBLENBQWFXLFdBQVcsS0FBSSxnQkFBZ0I7TUFDcEUsTUFBTUMsU0FBUyxHQUFTakcsTUFBTSxDQUFDeUYsS0FBSyxhQUFMQSxLQUFLLGdCQUFBSCxZQUFBLEdBQUxHLEtBQUssQ0FBRU0sSUFBSSxjQUFBVCxZQUFBLHVCQUFYQSxZQUFBLENBQWFZLEtBQUssQ0FBQyxJQUFJLENBQUM7TUFDdkQsTUFBTUMsTUFBTSxHQUFZcEcsTUFBTSxDQUFDLENBQUEwRixLQUFLLGFBQUxBLEtBQUssZ0JBQUFGLFlBQUEsR0FBTEUsS0FBSyxDQUFFTSxJQUFJLGNBQUFSLFlBQUEsdUJBQVhBLFlBQUEsQ0FBYXhELEVBQUUsS0FBSSxFQUFFLENBQUM7TUFDckQsTUFBTXFFLE9BQU8sR0FBV3JHLE1BQU0sQ0FBQyxDQUFBMEYsS0FBSyxhQUFMQSxLQUFLLGdCQUFBRCxZQUFBLEdBQUxDLEtBQUssQ0FBRVksS0FBSyxjQUFBYixZQUFBLHVCQUFaQSxZQUFBLENBQWN6RCxFQUFFLEtBQUksRUFBRSxDQUFDO01BRXRELElBQUk7UUFDRixJQUFJdUUsUUFBUSxHQUFHLEtBQUs7UUFDcEIsSUFBSUwsU0FBUyxJQUFJLEVBQUUsRUFBRUssUUFBUSxHQUFHLFVBQVUsQ0FBQyxLQUN0QyxJQUFJTCxTQUFTLElBQUksRUFBRSxFQUFFSyxRQUFRLEdBQUcsTUFBTSxDQUFDLEtBQ3ZDLElBQUlMLFNBQVMsSUFBSSxDQUFDLEVBQUdLLFFBQVEsR0FBRyxRQUFRO1FBRTdDLE1BQU1DLE9BQU8sR0FBRyxNQUFNQyx5QkFBVyxDQUFDQyxVQUFVLENBQzFDekYsTUFBTSxFQUNOO1VBQ0UwRixLQUFLLEVBQUUsYUFBYTtVQUNwQlYsV0FBVyxFQUFFbEYsY0FBYyxDQUFDNkYsZ0JBQWdCLENBQUNsQixLQUFLLEVBQUVMLEdBQUcsQ0FBQ3dCLE1BQU0sQ0FBQztVQUMvRE4sUUFBUSxFQUFFQSxRQUFlO1VBQ3pCTyxRQUFRLEVBQUUxRCxNQUFNLENBQUM3QyxnQkFBdUI7VUFDeEN3RyxRQUFRLEVBQUUzRCxNQUFNLENBQUM1QyxnQkFBdUI7VUFDeEN3RyxJQUFJLEVBQUUsQ0FBQyxjQUFjLEVBQUcsU0FBUWQsU0FBVSxFQUFDLEVBQUUsSUFBSUUsTUFBTSxHQUFHLENBQUUsUUFBT0EsTUFBTyxFQUFDLENBQUMsR0FBRyxFQUFFLENBQUM7UUFDcEYsQ0FBQyxFQUNELGNBQ0YsQ0FBQztRQUVELE1BQU1hLFNBQVMsR0FBUVQsT0FBTyxDQUFDeEUsRUFBRztRQUNsQztRQUNBLE1BQU1rRixXQUFXLEdBQU8sR0FBRVYsT0FBTyxDQUFDVyxPQUFRLEtBQUlwQixlQUFnQixFQUFDO1FBQy9ELE1BQU1xQixXQUFXLEdBQU1yRyxjQUFjLENBQUNzRyxnQkFBZ0IsQ0FBQ2hDLEdBQUcsQ0FBQztRQUUzRCxNQUFNcEUsTUFBTSxDQUFDcUcsTUFBTSxDQUFDO1VBQ2xCakcsS0FBSyxFQUFFa0cscUJBQVU7VUFDakJ2RixFQUFFLEVBQUVpRixTQUFTO1VBQ2IvRixJQUFJLEVBQUU7WUFDSnNHLEdBQUcsRUFBRTtjQUNIYixLQUFLLEVBQUVPLFdBQVc7Y0FDbEJPLGFBQWEsRUFBRSxDQUFDTCxXQUFXLENBQUM7Y0FDNUI7Y0FDQUosSUFBSSxFQUFFLENBQUMsY0FBYyxFQUFHLFNBQVFkLFNBQVUsRUFBQyxFQUFHLGNBQWFQLE9BQVEsRUFBQyxDQUFDO2NBQ3JFL0UsVUFBVSxFQUFFLElBQUlDLElBQUksQ0FBQyxDQUFDLENBQUNDLFdBQVcsQ0FBQztZQUNyQztVQUNGLENBQUM7VUFDRDRHLGlCQUFpQixFQUFFO1FBQ3JCLENBQUMsQ0FBQzs7UUFFRjtRQUNBdkMsZ0JBQWdCLENBQUN3QyxHQUFHLENBQUNoQyxPQUFPLENBQUM7UUFFN0JqQyxPQUFPLEVBQUU7UUFDVGYsTUFBTSxDQUFDTSxJQUFJLENBQUUseUJBQXdCaUUsV0FBWSxFQUFDLENBQUM7TUFDckQsQ0FBQyxDQUFDLE9BQU9sSSxDQUFNLEVBQUU7UUFDZjJELE1BQU0sQ0FBQ0ksSUFBSSxDQUFFLHlDQUF3QzRDLE9BQVEsTUFBSzNHLENBQUMsQ0FBQ2dFLE9BQVEsRUFBQyxDQUFDO01BQ2hGO0lBQ0Y7SUFFQSxNQUFNakMsY0FBYyxDQUFDc0IsVUFBVSxDQUFDcEIsTUFBTSxFQUFFO01BQ3RDUCx3QkFBd0IsRUFBRXdFO0lBQzVCLENBQUMsQ0FBQztJQUVGLE9BQU94QixPQUFPO0VBQ2hCOztFQUVBO0FBQ0Y7QUFDQTtBQUNBO0VBQ0UsYUFBcUIwQiw4QkFBOEJBLENBQ2pEbkUsTUFBVyxFQUNYMEIsTUFBYyxFQUNRO0lBQ3RCLE1BQU1pRixHQUFHLEdBQUcsSUFBSUMsR0FBRyxDQUFTLENBQUM7SUFDN0IsSUFBSTtNQUNGLE1BQU07UUFBRTNHLElBQUksRUFBRTJEO01BQU8sQ0FBQyxHQUFHLE1BQU01RCxNQUFNLENBQUM2RCxNQUFNLENBQUM7UUFDM0N6RCxLQUFLLEVBQUVrRyxxQkFBVTtRQUNqQnJHLElBQUksRUFBRTtVQUNKNEMsS0FBSyxFQUFFO1lBQ0xDLElBQUksRUFBRTtjQUNKQyxJQUFJLEVBQUUsQ0FDSjtnQkFBRThELEtBQUssRUFBRTtrQkFBRUMsTUFBTSxFQUFFLENBQUMsTUFBTSxFQUFFLGFBQWEsRUFBRSxTQUFTO2dCQUFFO2NBQUUsQ0FBQyxFQUN6RDtnQkFBRUMsSUFBSSxFQUFFO2tCQUFFaEIsSUFBSSxFQUFFO2dCQUFlO2NBQUUsQ0FBQztZQUV0QztVQUNGLENBQUM7VUFDRC9FLE9BQU8sRUFBRSxDQUFDLGVBQWUsQ0FBQztVQUMxQnlDLElBQUksRUFBRTtRQUNSO01BQ0YsQ0FBQyxDQUFDO01BQ0YsS0FBSyxNQUFNVyxHQUFHLElBQUssRUFBQTRDLGFBQUEsR0FBQXBELE1BQU0sQ0FBQ0YsSUFBSSxjQUFBc0QsYUFBQSx1QkFBWEEsYUFBQSxDQUFhdEQsSUFBSSxLQUFJLEVBQUUsRUFBRztRQUFBLElBQUFzRCxhQUFBO1FBQzNDLEtBQUssTUFBTUMsRUFBRSxJQUFLLEVBQUFDLFlBQUEsR0FBQTlDLEdBQUcsQ0FBQ3BELE9BQU8sY0FBQWtHLFlBQUEsdUJBQVhBLFlBQUEsQ0FBYVYsYUFBYSxLQUFJLEVBQUUsRUFBRztVQUFBLElBQUFVLFlBQUE7VUFDbkQsSUFBSUQsRUFBRSxDQUFDRSxRQUFRLEVBQUVSLEdBQUcsQ0FBQ0QsR0FBRyxDQUFDTyxFQUFFLENBQUNFLFFBQVEsQ0FBQztRQUN2QztNQUNGO0lBQ0YsQ0FBQyxDQUFDLE9BQU9wSixDQUFNLEVBQUU7TUFDZjJELE1BQU0sQ0FBQ0ksSUFBSSxDQUFFLHVEQUFzRC9ELENBQUMsQ0FBQ2dFLE9BQVEsRUFBQyxDQUFDO0lBQ2pGO0lBQ0EsT0FBTzRFLEdBQUc7RUFDWjtFQUVBLE9BQWVQLGdCQUFnQkEsQ0FBQ2hDLEdBQVEsRUFBTztJQUFBLElBQUFnRCxZQUFBLEVBQUFDLFlBQUEsRUFBQUMsWUFBQSxFQUFBQyxZQUFBLEVBQUFDLGFBQUEsRUFBQUMsYUFBQTtJQUM3QyxNQUFNaEQsS0FBSyxHQUFHTCxHQUFHLENBQUNwRCxPQUFPO0lBQ3pCLE9BQU87TUFDTG1HLFFBQVEsRUFBVS9DLEdBQUcsQ0FBQ08sR0FBRztNQUN6QnZFLEtBQUssRUFBYWdFLEdBQUcsQ0FBQ3dCLE1BQU0sSUFBSTlCLHFDQUEwQjtNQUMxRDRELE9BQU8sRUFBV0MsUUFBUSxDQUFDLENBQUFsRCxLQUFLLGFBQUxBLEtBQUssZ0JBQUEyQyxZQUFBLEdBQUwzQyxLQUFLLENBQUVNLElBQUksY0FBQXFDLFlBQUEsdUJBQVhBLFlBQUEsQ0FBYXJHLEVBQUUsS0FBSSxHQUFHLEVBQUUsRUFBRSxDQUFDO01BQ3RENkcsZ0JBQWdCLEVBQUUsQ0FBQW5ELEtBQUssYUFBTEEsS0FBSyxnQkFBQTRDLFlBQUEsR0FBTDVDLEtBQUssQ0FBRU0sSUFBSSxjQUFBc0MsWUFBQSx1QkFBWEEsWUFBQSxDQUFhckMsV0FBVyxLQUFJLEVBQUU7TUFDaEQ2QyxVQUFVLEVBQVEsQ0FBQXBELEtBQUssYUFBTEEsS0FBSyxnQkFBQTZDLFlBQUEsR0FBTDdDLEtBQUssQ0FBRU0sSUFBSSxjQUFBdUMsWUFBQSx1QkFBWEEsWUFBQSxDQUFhcEMsS0FBSyxLQUFJLENBQUM7TUFDekM0QyxXQUFXLEVBQU8sQ0FBQXJELEtBQUssYUFBTEEsS0FBSyxnQkFBQThDLFlBQUEsR0FBTDlDLEtBQUssQ0FBRU0sSUFBSSxjQUFBd0MsWUFBQSx1QkFBWEEsWUFBQSxDQUFhUSxNQUFNLEtBQUksRUFBRTtNQUMzQ0MsUUFBUSxFQUFVLENBQUF2RCxLQUFLLGFBQUxBLEtBQUssZ0JBQUErQyxhQUFBLEdBQUwvQyxLQUFLLENBQUVZLEtBQUssY0FBQW1DLGFBQUEsdUJBQVpBLGFBQUEsQ0FBY3pHLEVBQUUsS0FBSSxFQUFFO01BQ3hDa0gsVUFBVSxFQUFRLENBQUF4RCxLQUFLLGFBQUxBLEtBQUssZ0JBQUFnRCxhQUFBLEdBQUxoRCxLQUFLLENBQUVZLEtBQUssY0FBQW9DLGFBQUEsdUJBQVpBLGFBQUEsQ0FBY1MsSUFBSSxLQUFJLEVBQUU7TUFDMUMvRSxTQUFTLEVBQVMsQ0FBQXNCLEtBQUssYUFBTEEsS0FBSyx1QkFBTEEsS0FBSyxDQUFFdEIsU0FBUyxNQUFJc0IsS0FBSyxhQUFMQSxLQUFLLHVCQUFMQSxLQUFLLENBQUcsWUFBWSxDQUFDLEtBQUksSUFBSTdFLElBQUksQ0FBQyxDQUFDLENBQUNDLFdBQVcsQ0FBQyxDQUFDO01BQ3ZGc0ksUUFBUSxFQUFVLENBQUExRCxLQUFLLGFBQUxBLEtBQUssdUJBQUxBLEtBQUssQ0FBRTBELFFBQVEsS0FBSTtJQUN2QyxDQUFDO0VBQ0g7RUFFQSxPQUFleEMsZ0JBQWdCQSxDQUFDbEIsS0FBVSxFQUFFckUsS0FBYSxFQUFVO0lBQUEsSUFBQWdJLFlBQUEsRUFBQUMsWUFBQSxFQUFBQyxpQkFBQSxFQUFBQyxhQUFBLEVBQUFDLGFBQUEsRUFBQUMsYUFBQSxFQUFBQyxhQUFBO0lBQ2pFLE1BQU12RCxNQUFNLEdBQU0sQ0FBQVYsS0FBSyxhQUFMQSxLQUFLLGdCQUFBMkQsWUFBQSxHQUFMM0QsS0FBSyxDQUFFTSxJQUFJLGNBQUFxRCxZQUFBLHVCQUFYQSxZQUFBLENBQWFySCxFQUFFLEtBQUksS0FBSztJQUMxQyxNQUFNNEgsUUFBUSxHQUFJLENBQUFsRSxLQUFLLGFBQUxBLEtBQUssZ0JBQUE0RCxZQUFBLEdBQUw1RCxLQUFLLENBQUVNLElBQUksY0FBQXNELFlBQUEsdUJBQVhBLFlBQUEsQ0FBYXJELFdBQVcsS0FBSSxLQUFLO0lBQ25ELE1BQU1DLFNBQVMsSUFBQXFELGlCQUFBLEdBQUc3RCxLQUFLLGFBQUxBLEtBQUssZ0JBQUE4RCxhQUFBLEdBQUw5RCxLQUFLLENBQUVNLElBQUksY0FBQXdELGFBQUEsdUJBQVhBLGFBQUEsQ0FBYXJELEtBQUssY0FBQW9ELGlCQUFBLGNBQUFBLGlCQUFBLEdBQUksS0FBSztJQUM3QyxNQUFNTSxTQUFTLEdBQUcsQ0FBQW5FLEtBQUssYUFBTEEsS0FBSyxnQkFBQStELGFBQUEsR0FBTC9ELEtBQUssQ0FBRVksS0FBSyxjQUFBbUQsYUFBQSx1QkFBWkEsYUFBQSxDQUFjTixJQUFJLEtBQUksU0FBUztJQUNqRCxNQUFNOUMsT0FBTyxHQUFLLENBQUFYLEtBQUssYUFBTEEsS0FBSyxnQkFBQWdFLGFBQUEsR0FBTGhFLEtBQUssQ0FBRVksS0FBSyxjQUFBb0QsYUFBQSx1QkFBWkEsYUFBQSxDQUFjMUgsRUFBRSxLQUFJLEtBQUs7SUFDM0MsTUFBTWdILE1BQU0sR0FBTSxDQUFDLENBQUF0RCxLQUFLLGFBQUxBLEtBQUssZ0JBQUFpRSxhQUFBLEdBQUxqRSxLQUFLLENBQUVNLElBQUksY0FBQTJELGFBQUEsdUJBQVhBLGFBQUEsQ0FBYVgsTUFBTSxLQUFJLEVBQUUsRUFBRWMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLEtBQUs7SUFDakUsTUFBTUMsS0FBSyxHQUFPLENBQUFyRSxLQUFLLGFBQUxBLEtBQUssdUJBQUxBLEtBQUssQ0FBRXRCLFNBQVMsTUFBSXNCLEtBQUssYUFBTEEsS0FBSyx1QkFBTEEsS0FBSyxDQUFHLFlBQVksQ0FBQztJQUMzRCxNQUFNdEIsU0FBUyxHQUFHMkYsS0FBSyxHQUNuQixJQUFJbEosSUFBSSxDQUFDa0osS0FBSyxDQUFDLENBQUNDLGNBQWMsQ0FBQyxPQUFPLEVBQUU7TUFBRUMsU0FBUyxFQUFFLFFBQVE7TUFBRUMsU0FBUyxFQUFFO0lBQVMsQ0FBQyxDQUFDLEdBQ3JGLEtBQUs7SUFFVCxNQUFNQyxLQUFlLEdBQUcsQ0FDckIsZ0VBQStELEVBQy9ELEVBQUMsRUFDRCxrQkFBaUIsRUFDakIsRUFBQyxFQUNELGtCQUFpQi9ELE1BQU8sRUFBQyxFQUN6QixzQkFBcUJ3RCxRQUFTLEVBQUMsRUFDL0IsZ0JBQWUxRCxTQUFVLEVBQUMsRUFDMUIsaUJBQWdCOEMsTUFBTyxFQUFDLEVBQ3hCLGdCQUFlYSxTQUFVLFNBQVF4RCxPQUFRLEdBQUUsRUFDM0MsbUJBQWtCakMsU0FBVSxFQUFDLENBQy9CO0lBRUQsSUFBSXNCLEtBQUssYUFBTEEsS0FBSyxlQUFMQSxLQUFLLENBQUUwRCxRQUFRLEVBQUU7TUFDbkIsTUFBTWdCLEdBQUcsR0FBR3BLLE1BQU0sQ0FBQzBGLEtBQUssQ0FBQzBELFFBQVEsQ0FBQyxDQUFDaUIsSUFBSSxDQUFDLENBQUMsQ0FBQ0MsU0FBUyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUM7TUFDM0RILEtBQUssQ0FBQ0ksSUFBSSxDQUFFLEVBQUMsRUFBRyxZQUFXLEVBQUcsRUFBQyxFQUFHLFFBQU8sRUFBRUgsR0FBRyxFQUFHLFFBQU8sQ0FBQztJQUMzRDtJQUVBLE9BQU9ELEtBQUssQ0FBQ0wsSUFBSSxDQUFDLElBQUksQ0FBQztFQUN6QjtBQUNGO0FBQUNVLE9BQUEsQ0FBQXpKLGNBQUEsR0FBQUEsY0FBQTtBQUFBaEMsZUFBQSxDQXBVWWdDLGNBQWMsb0JBQzhDLElBQUk7QUFBQWhDLGVBQUEsQ0FEaEVnQyxjQUFjLGFBRUEsS0FBSyJ9