"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.CaseService = void 0;
var _constants = require("../../common/constants");
var _opensearch_service = require("./opensearch_service");
var _settings_service = require("./settings_service");
var _notification_service = require("./notification_service");
var _case_mappings = require("../saved_objects/case_mappings");
/*
 * Wazuh Case Management Plugin
 * Case Service: Business logic for case management operations
 *
 * Handles case ID generation, CRUD, status transitions, comments,
 * alert linking, observables, activity logging, and analytics.
 */

/** Empty analytics summary: returned when there are no cases or the index is unavailable. */
function emptyAnalyticsSummary() {
  return {
    total_cases: 0,
    open_cases: 0,
    in_progress_cases: 0,
    waiting_cases: 0,
    resolved_cases: 0,
    closed_cases: 0,
    by_severity: {},
    by_priority: {},
    by_category: {},
    avg_resolution_time_ms: null,
    cases_created_today: 0,
    cases_closed_today: 0
  };
}

/** Generate a UUID v4 without dashes (compact) */
function uuid() {
  // Use crypto.randomUUID if available, fallback to manual
  try {
    return crypto.randomUUID().replace(/-/g, '').substring(0, 12);
  } catch {
    return Date.now().toString(36) + Math.random().toString(36).substring(2, 8);
  }
}

/**
 * CaseService: all case management business logic.
 * Methods are static; the OpenSearch client is passed in per-request.
 */
class CaseService {
  // ──────────────────────────────────────────────────────────────
  // Case ID Generation
  // ──────────────────────────────────────────────────────────────

  /**
   * Generate the next human-readable case ID.
   * Format: CASE-2026-0001
   */
  static async generateCaseId(client) {
    const counter = await _opensearch_service.OpenSearchService.getNextCounterValue(client);

    // The ID format is user-configurable (Settings -> Case ID Format). Fall back
    // to the compiled-in defaults if settings cannot be read for any reason.
    try {
      const settings = await _settings_service.SettingsService.getSettings(client);
      return _settings_service.SettingsService.formatCaseId(settings, counter);
    } catch (_e) {
      const year = new Date().getFullYear();
      const paddedNum = String(counter).padStart(4, '0');
      return `${_constants.CASE_ID_PREFIX}${_constants.CASE_ID_SEPARATOR}${year}${_constants.CASE_ID_SEPARATOR}${paddedNum}`;
    }
  }

  // ──────────────────────────────────────────────────────────────
  // Activity Log Helper
  // ──────────────────────────────────────────────────────────────

  static createActivity(action, user, details) {
    return {
      id: uuid(),
      action,
      user,
      timestamp: new Date().toISOString(),
      details
    };
  }

  // ──────────────────────────────────────────────────────────────
  // Case CRUD
  // ──────────────────────────────────────────────────────────────

  /** Create a new case */
  static async createCase(client, payload, user) {
    // Auto-heal: make sure the indices exist with the correct mapping before writing,
    // so deleting an index and then creating a case restores the proper schema.
    await _opensearch_service.OpenSearchService.ensureIndex(client, _constants.CASE_COUNTER_INDEX, _case_mappings.counterMappings);
    await _opensearch_service.OpenSearchService.ensureIndex(client, _constants.CASE_INDEX, _case_mappings.caseMappings);
    const caseId = await CaseService.generateCaseId(client);
    const now = new Date().toISOString();
    const newCase = {
      case_id: caseId,
      title: payload.title,
      description: payload.description,
      status: 'open',
      severity: payload.severity,
      priority: payload.priority,
      category: payload.category,
      tlp: payload.tlp || 'WHITE',
      tags: payload.tags || [],
      assignee: payload.assignee || null,
      created_by: user,
      created_at: now,
      updated_at: now,
      closed_at: null,
      linked_alerts: [],
      observables: [],
      comments: [],
      tasks: [],
      notes: '',
      activity_log: [CaseService.createActivity('case_created', user, {
        case_id: caseId,
        title: payload.title
      })],
      resolution_summary: null,
      time_to_resolve_ms: null,
      related_cases: [],
      custom_fields: {}
    };

    // If an assignee was provided, log the assignment
    if (payload.assignee) {
      newCase.activity_log.push(CaseService.createActivity('assigned', user, {
        assignee: payload.assignee
      }));
    }
    const {
      _id
    } = await _opensearch_service.OpenSearchService.createDocument(client, _constants.CASE_INDEX, newCase);
    newCase.id = _id;

    // The auto-monitor sends its own, richer notification once the case has been
    // finalised with its title and linked alert. Don't duplicate it here.
    if (user !== 'auto-monitor') {
      await _notification_service.NotificationService.dispatch(client, {
        event: payload.assignee ? 'case_assigned' : 'case_created',
        recipients: [payload.assignee],
        title: `Case ${caseId} created`,
        message: `${user} created "${payload.title}" (${payload.priority}, ${payload.severity}).`,
        caseRef: newCase,
        actor: user
      });
    }
    return newCase;
  }

  /** Get a single case by its OpenSearch _id */
  static async getCase(client, id) {
    const doc = await _opensearch_service.OpenSearchService.getDocument(client, _constants.CASE_INDEX, id);
    if (!doc) return null;
    return {
      id: doc._id,
      ...doc._source
    };
  }

  /** Update a case (partial update) */
  static async updateCase(client, id, payload, user) {
    const existing = await CaseService.getCase(client, id);
    if (!existing) return null;
    const now = new Date().toISOString();
    const activities = [];
    const updateDoc = {
      updated_at: now
    };

    // Track changes for activity log
    if (payload.title !== undefined && payload.title !== existing.title) {
      updateDoc.title = payload.title;
    }
    if (payload.description !== undefined) {
      updateDoc.description = payload.description;
    }
    if (payload.severity !== undefined && payload.severity !== existing.severity) {
      updateDoc.severity = payload.severity;
      activities.push(CaseService.createActivity('severity_changed', user, {
        from: existing.severity,
        to: payload.severity
      }));
    }
    if (payload.priority !== undefined && payload.priority !== existing.priority) {
      updateDoc.priority = payload.priority;
      activities.push(CaseService.createActivity('priority_changed', user, {
        from: existing.priority,
        to: payload.priority
      }));
    }
    if (payload.category !== undefined) {
      updateDoc.category = payload.category;
    }
    if (payload.tlp !== undefined) {
      updateDoc.tlp = payload.tlp;
    }
    if (payload.tags !== undefined) {
      updateDoc.tags = payload.tags;
    }
    if (payload.assignee !== undefined && payload.assignee !== existing.assignee) {
      updateDoc.assignee = payload.assignee;
      activities.push(CaseService.createActivity(payload.assignee ? 'assigned' : 'unassigned', user, {
        from: existing.assignee,
        to: payload.assignee
      }));
    }
    if (payload.resolution_summary !== undefined) {
      updateDoc.resolution_summary = payload.resolution_summary;
    }

    // Append activities
    if (activities.length > 0) {
      updateDoc.activity_log = [...existing.activity_log, ...activities];
    }
    await _opensearch_service.OpenSearchService.updateDocument(client, _constants.CASE_INDEX, id, updateDoc);
    if (updateDoc.assignee) {
      await _notification_service.NotificationService.dispatch(client, {
        event: 'case_assigned',
        recipients: [updateDoc.assignee],
        title: `Case ${existing.case_id} assigned to you`,
        message: `${user} assigned you "${existing.title}".`,
        caseRef: {
          ...existing,
          assignee: updateDoc.assignee
        },
        actor: user
      });
    }
    if (updateDoc.priority) {
      await _notification_service.NotificationService.dispatch(client, {
        event: 'priority_changed',
        recipients: [existing.assignee, existing.created_by],
        title: `Case ${existing.case_id} priority is now ${updateDoc.priority}`,
        message: `${user} changed the priority from ${existing.priority} to ${updateDoc.priority}.`,
        caseRef: {
          ...existing,
          priority: updateDoc.priority
        },
        actor: user
      });
    }
    return await CaseService.getCase(client, id);
  }

  /** Delete a case by OpenSearch _id */
  static async deleteCase(client, id) {
    return await _opensearch_service.OpenSearchService.deleteDocument(client, _constants.CASE_INDEX, id);
  }

  /** List cases with filtering, pagination, and sorting */
  static async listCases(client, query) {
    const page = query.page || 1;
    const perPage = Math.min(query.per_page || _constants.DEFAULT_PAGE_SIZE, _constants.MAX_PAGE_SIZE);
    const sortField = query.sort_field || _constants.DEFAULT_SORT_FIELD;
    const sortOrder = query.sort_order || _constants.DEFAULT_SORT_ORDER;

    // Build the query
    const must = [];
    if (query.status) {
      must.push({
        term: {
          status: query.status
        }
      });
    }
    if (query.severity) {
      must.push({
        term: {
          severity: query.severity
        }
      });
    }
    if (query.priority) {
      must.push({
        term: {
          priority: query.priority
        }
      });
    }
    if (query.category) {
      must.push({
        term: {
          category: query.category
        }
      });
    }
    if (query.assignee) {
      must.push({
        term: {
          assignee: query.assignee
        }
      });
    }
    if (query.tags) {
      const tagList = query.tags.split(',').map(t => t.trim());
      must.push({
        terms: {
          tags: tagList
        }
      });
    }
    if (query.search) {
      must.push({
        multi_match: {
          query: query.search,
          fields: ['title^3', 'description', 'case_id^2', 'tags'],
          type: 'best_fields',
          fuzziness: 'AUTO'
        }
      });
    }
    if (query.created_from || query.created_to) {
      const range = {};
      if (query.created_from) range.gte = query.created_from;
      if (query.created_to) range.lte = query.created_to;
      must.push({
        range: {
          created_at: range
        }
      });
    }
    const searchBody = {
      query: must.length > 0 ? {
        bool: {
          must
        }
      } : {
        match_all: {}
      },
      sort: [{
        [sortField]: {
          order: sortOrder
        }
      }],
      from: (page - 1) * perPage,
      size: perPage,
      // Exclude heavy nested fields from listing to improve perf
      _source: {
        excludes: ['activity_log', 'comments.content']
      }
    };
    const {
      hits,
      total
    } = await _opensearch_service.OpenSearchService.searchDocuments(client, _constants.CASE_INDEX, searchBody);
    const cases = hits.map(hit => ({
      id: hit._id,
      ...hit._source
    }));
    return {
      cases,
      total,
      page,
      per_page: perPage
    };
  }

  // ──────────────────────────────────────────────────────────────
  // Status Management
  // ──────────────────────────────────────────────────────────────

  /** Change case status with transition validation */
  static async changeStatus(client, id, newStatus, user) {
    const existing = await CaseService.getCase(client, id);
    if (!existing) {
      return {
        success: false,
        error: 'Case not found'
      };
    }

    // Validate transition
    const allowedTransitions = _constants.STATUS_TRANSITIONS[existing.status] || [];
    if (!allowedTransitions.includes(newStatus)) {
      return {
        success: false,
        error: `Cannot transition from '${existing.status}' to '${newStatus}'. Allowed: ${allowedTransitions.join(', ')}`
      };
    }
    const now = new Date().toISOString();
    const updateDoc = {
      status: newStatus,
      updated_at: now
    };

    // Handle closing
    if (newStatus === 'closed' || newStatus === 'resolved') {
      updateDoc.closed_at = now;
      if (existing.created_at) {
        updateDoc.time_to_resolve_ms = new Date(now).getTime() - new Date(existing.created_at).getTime();
      }
    }

    // Handle reopening
    if (newStatus === 'open' && (existing.status === 'closed' || existing.status === 'resolved')) {
      updateDoc.closed_at = null;
      updateDoc.time_to_resolve_ms = null;
    }

    // Activity
    const activity = CaseService.createActivity(newStatus === 'closed' ? 'case_closed' : newStatus === 'open' && existing.status === 'closed' ? 'case_reopened' : 'status_changed', user, {
      from: existing.status,
      to: newStatus
    });
    updateDoc.activity_log = [...existing.activity_log, activity];
    await _opensearch_service.OpenSearchService.updateDocument(client, _constants.CASE_INDEX, id, updateDoc);
    const updatedCase = await CaseService.getCase(client, id);
    await _notification_service.NotificationService.dispatch(client, {
      event: 'status_changed',
      recipients: [existing.assignee, existing.created_by],
      title: `Case ${existing.case_id} is now ${newStatus.replace('_', ' ')}`,
      message: `${user} moved the case from ${existing.status.replace('_', ' ')} to ${newStatus.replace('_', ' ')}.`,
      caseRef: updatedCase || existing,
      actor: user,
      context: {
        from: existing.status,
        to: newStatus
      }
    });
    return {
      success: true,
      case: updatedCase
    };
  }

  /** Assign a case to a user */
  static async assignCase(client, id, assignee, user) {
    const existing = await CaseService.getCase(client, id);
    if (!existing) return null;
    const activity = CaseService.createActivity(assignee ? 'assigned' : 'unassigned', user, {
      from: existing.assignee,
      to: assignee
    });
    await _opensearch_service.OpenSearchService.updateDocument(client, _constants.CASE_INDEX, id, {
      assignee,
      updated_at: new Date().toISOString(),
      activity_log: [...existing.activity_log, activity]
    });
    if (assignee) {
      await _notification_service.NotificationService.dispatch(client, {
        event: 'case_assigned',
        recipients: [assignee],
        title: `Case ${existing.case_id} assigned to you`,
        message: `${user} assigned you "${existing.title}" (${existing.priority}, ${existing.severity}).`,
        caseRef: {
          ...existing,
          assignee
        },
        actor: user
      });
    }
    return await CaseService.getCase(client, id);
  }

  // ──────────────────────────────────────────────────────────────
  // Tasks
  // ──────────────────────────────────────────────────────────────

  /** Add a task to a case */
  static async addTask(client, caseId, params, user) {
    const existing = await CaseService.getCase(client, caseId);
    if (!existing) return null;
    const newTask = {
      task_id: uuid(),
      title: params.title,
      completed: false,
      assigned_to: params.assigned_to || null,
      due_date: params.due_date || null,
      created_at: new Date().toISOString(),
      created_by: user
    };
    const updateDoc = {
      tasks: [...(existing.tasks || []), newTask],
      updated_at: new Date().toISOString()
    };
    await _opensearch_service.OpenSearchService.updateDocument(client, _constants.CASE_INDEX, caseId, updateDoc);
    if (newTask.assigned_to) {
      await CaseService.notifyTaskAssignment(client, existing, newTask, user);
    }
    return await CaseService.getCase(client, caseId);
  }

  /** Update a task's assignee, due date or title. */
  static async updateTask(client, caseId, taskId, updates, user) {
    const existing = await CaseService.getCase(client, caseId);
    if (!existing) return null;
    const target = (existing.tasks || []).find(t => t.task_id === taskId);
    if (!target) return existing;
    const previousAssignee = target.assigned_to || null;
    const tasks = (existing.tasks || []).map(t => t.task_id === taskId ? {
      ...t,
      ...updates
    } : t);
    await _opensearch_service.OpenSearchService.updateDocument(client, _constants.CASE_INDEX, caseId, {
      tasks,
      updated_at: new Date().toISOString()
    });

    // Only notify when the assignee actually changed to somebody new.
    const nextAssignee = updates.assigned_to === undefined ? previousAssignee : updates.assigned_to;
    if (nextAssignee && nextAssignee !== previousAssignee) {
      await CaseService.notifyTaskAssignment(client, existing, {
        ...target,
        ...updates
      }, user);
    }
    return await CaseService.getCase(client, caseId);
  }
  static async notifyTaskAssignment(client, caseItem, task, actor) {
    const due = task.due_date ? ` (due ${task.due_date})` : '';
    await _notification_service.NotificationService.dispatch(client, {
      event: 'task_assigned',
      recipients: [task.assigned_to],
      title: `Task assigned on ${caseItem.case_id}`,
      message: `${actor} assigned you "${task.title}"${due}.`,
      caseRef: caseItem,
      actor,
      context: {
        task_id: task.task_id,
        task_title: task.title,
        due_date: task.due_date || null
      }
    });
  }

  /** Toggle task completion */
  static async toggleTask(client, caseId, taskId, completed, user) {
    const existing = await CaseService.getCase(client, caseId);
    if (!existing) return null;
    const tasks = (existing.tasks || []).map(t => t.task_id === taskId ? {
      ...t,
      completed,
      completed_at: completed ? new Date().toISOString() : null,
      completed_by: completed ? user : null
    } : t);
    const updateDoc = {
      tasks,
      updated_at: new Date().toISOString()
    };
    await _opensearch_service.OpenSearchService.updateDocument(client, _constants.CASE_INDEX, caseId, updateDoc);
    return await CaseService.getCase(client, caseId);
  }

  /** Remove a task */
  static async removeTask(client, caseId, taskId, user) {
    const existing = await CaseService.getCase(client, caseId);
    if (!existing) return null;
    const tasks = (existing.tasks || []).filter(t => t.task_id !== taskId);
    const updateDoc = {
      tasks,
      updated_at: new Date().toISOString()
    };
    await _opensearch_service.OpenSearchService.updateDocument(client, _constants.CASE_INDEX, caseId, updateDoc);
    return await CaseService.getCase(client, caseId);
  }

  // ──────────────────────────────────────────────────────────────
  // Notes
  // ──────────────────────────────────────────────────────────────

  /** Update case notes */
  static async updateNotes(client, caseId, notes, user) {
    const existing = await CaseService.getCase(client, caseId);
    if (!existing) return null;
    const updateDoc = {
      notes,
      updated_at: new Date().toISOString()
    };
    await _opensearch_service.OpenSearchService.updateDocument(client, _constants.CASE_INDEX, caseId, updateDoc);
    return await CaseService.getCase(client, caseId);
  }

  // ──────────────────────────────────────────────────────────────
  // Comments
  // ──────────────────────────────────────────────────────────────

  /** Add a comment to a case */
  static async addComment(client, caseId, content, user) {
    const existing = await CaseService.getCase(client, caseId);
    if (!existing) return null;
    const comment = {
      comment_id: uuid(),
      author: user,
      content,
      created_at: new Date().toISOString()
    };
    const activity = CaseService.createActivity('comment_added', user, {
      comment_id: comment.comment_id
    });
    await _opensearch_service.OpenSearchService.updateDocument(client, _constants.CASE_INDEX, caseId, {
      comments: [...existing.comments, comment],
      activity_log: [...existing.activity_log, activity],
      updated_at: new Date().toISOString()
    });
    await _notification_service.NotificationService.dispatch(client, {
      event: 'comment_added',
      recipients: [existing.assignee, existing.created_by],
      title: `New comment on ${existing.case_id}`,
      message: `${user}: ${content.substring(0, 200)}`,
      caseRef: existing,
      actor: user
    });
    return await CaseService.getCase(client, caseId);
  }

  /** Delete a comment from a case */
  static async deleteComment(client, caseId, commentId, user) {
    const existing = await CaseService.getCase(client, caseId);
    if (!existing) return null;
    const updatedComments = existing.comments.filter(c => c.comment_id !== commentId);
    if (updatedComments.length === existing.comments.length) {
      return existing; // Comment not found, no change
    }

    const activity = CaseService.createActivity('comment_deleted', user, {
      comment_id: commentId
    });
    await _opensearch_service.OpenSearchService.updateDocument(client, _constants.CASE_INDEX, caseId, {
      comments: updatedComments,
      activity_log: [...existing.activity_log, activity],
      updated_at: new Date().toISOString()
    });
    return await CaseService.getCase(client, caseId);
  }

  // ──────────────────────────────────────────────────────────────
  // Alert Linking
  // ──────────────────────────────────────────────────────────────

  /** Link an alert to a case */
  static async linkAlert(client, caseId, alert, user) {
    const existing = await CaseService.getCase(client, caseId);
    if (!existing) return null;

    // Check for duplicate
    if (existing.linked_alerts.some(a => a.alert_id === alert.alert_id)) {
      return existing; // Already linked
    }

    const activity = CaseService.createActivity('alert_linked', user, {
      alert_id: alert.alert_id,
      rule_description: alert.rule_description
    });
    await _opensearch_service.OpenSearchService.updateDocument(client, _constants.CASE_INDEX, caseId, {
      linked_alerts: [...existing.linked_alerts, alert],
      activity_log: [...existing.activity_log, activity],
      updated_at: new Date().toISOString()
    });
    return await CaseService.getCase(client, caseId);
  }

  /** Unlink an alert from a case */
  static async unlinkAlert(client, caseId, alertId, user) {
    const existing = await CaseService.getCase(client, caseId);
    if (!existing) return null;
    const updatedAlerts = existing.linked_alerts.filter(a => a.alert_id !== alertId);
    const activity = CaseService.createActivity('alert_unlinked', user, {
      alert_id: alertId
    });
    await _opensearch_service.OpenSearchService.updateDocument(client, _constants.CASE_INDEX, caseId, {
      linked_alerts: updatedAlerts,
      activity_log: [...existing.activity_log, activity],
      updated_at: new Date().toISOString()
    });
    return await CaseService.getCase(client, caseId);
  }

  /** Search Wazuh alerts in OpenSearch */
  static async searchAlerts(client, query) {
    const must = [];
    if (query.search) {
      must.push({
        multi_match: {
          query: query.search,
          fields: ['rule.description^2', 'full_log', 'data.*'],
          fuzziness: 'AUTO',
          // data.* spans non-text fields (date/ip/number); lenient skips them
          // instead of throwing query_shard_exception (400 Bad Request).
          lenient: true
        }
      });
    }
    if (query.agent_id) {
      must.push({
        term: {
          'agent.id': query.agent_id
        }
      });
    }
    if (query.rule_id) {
      must.push({
        term: {
          'rule.id': String(query.rule_id)
        }
      });
    }
    if (query.level_min || query.level_max) {
      const range = {};
      if (query.level_min) range.gte = query.level_min;
      if (query.level_max) range.lte = query.level_max;
      must.push({
        range: {
          'rule.level': range
        }
      });
    }
    if (query.from || query.to) {
      const range = {};
      if (query.from) range.gte = query.from;
      if (query.to) range.lte = query.to;
      must.push({
        range: {
          timestamp: range
        }
      });
    }
    const searchBody = {
      query: must.length > 0 ? {
        bool: {
          must
        }
      } : {
        match_all: {}
      },
      sort: [{
        timestamp: {
          order: 'desc'
        }
      }],
      size: Math.min(query.size || 50, 100)
    };
    return await _opensearch_service.OpenSearchService.searchDocuments(client, _constants.WAZUH_ALERTS_INDEX_PATTERN, searchBody);
  }

  // ──────────────────────────────────────────────────────────────
  // Observables
  // ──────────────────────────────────────────────────────────────

  /** Add an observable to a case */
  static async addObservable(client, caseId, observable, user) {
    const existing = await CaseService.getCase(client, caseId);
    if (!existing) return null;
    const newObservable = {
      ...observable,
      id: uuid(),
      added_at: new Date().toISOString(),
      added_by: user
    };
    const activity = CaseService.createActivity('observable_added', user, {
      type: observable.type,
      value: observable.value
    });
    await _opensearch_service.OpenSearchService.updateDocument(client, _constants.CASE_INDEX, caseId, {
      observables: [...existing.observables, newObservable],
      activity_log: [...existing.activity_log, activity],
      updated_at: new Date().toISOString()
    });
    return await CaseService.getCase(client, caseId);
  }

  /** Remove an observable from a case */
  static async removeObservable(client, caseId, observableId, user) {
    const existing = await CaseService.getCase(client, caseId);
    if (!existing) return null;
    const updated = existing.observables.filter(o => o.id !== observableId);
    const activity = CaseService.createActivity('observable_removed', user, {
      observable_id: observableId
    });
    await _opensearch_service.OpenSearchService.updateDocument(client, _constants.CASE_INDEX, caseId, {
      observables: updated,
      activity_log: [...existing.activity_log, activity],
      updated_at: new Date().toISOString()
    });
    return await CaseService.getCase(client, caseId);
  }

  // ──────────────────────────────────────────────────────────────
  // Analytics
  // ──────────────────────────────────────────────────────────────

  /** Get summary analytics for the dashboard */
  static async getAnalyticsSummary(client) {
    try {
      // Self-heal: if the index was deleted, recreate it with the correct mapping
      // (keyword fields) so aggregations don't fail with a 400.
      await _opensearch_service.OpenSearchService.ensureIndex(client, _constants.CASE_INDEX, _case_mappings.caseMappings);
      return await CaseService.computeAnalyticsSummary(client);
    } catch (e) {
      // Never surface a raw 400/aggregation error to the dashboard. Return an
      // empty summary so the UI shows an empty state instead of "Bad Request".
      return emptyAnalyticsSummary();
    }
  }
  static async computeAnalyticsSummary(client) {
    var _aggs$by_status, _aggs$by_severity, _aggs$by_priority, _aggs$by_category, _aggs$total, _aggs$avg_resolution_, _aggs$created_today, _aggs$closed_today;
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const todayStr = today.toISOString();
    const aggs = await _opensearch_service.OpenSearchService.aggregateDocuments(client, _constants.CASE_INDEX, {
      aggs: {
        by_status: {
          terms: {
            field: 'status',
            size: 10
          }
        },
        by_severity: {
          terms: {
            field: 'severity',
            size: 10
          }
        },
        by_priority: {
          terms: {
            field: 'priority',
            size: 10
          }
        },
        by_category: {
          terms: {
            field: 'category',
            size: 20
          }
        },
        avg_resolution_time: {
          avg: {
            field: 'time_to_resolve_ms'
          }
        },
        created_today: {
          filter: {
            range: {
              created_at: {
                gte: todayStr
              }
            }
          }
        },
        closed_today: {
          filter: {
            bool: {
              must: [{
                range: {
                  closed_at: {
                    gte: todayStr
                  }
                }
              }, {
                terms: {
                  status: ['resolved', 'closed']
                }
              }]
            }
          }
        },
        total: {
          value_count: {
            field: 'case_id'
          }
        }
      }
    });

    // Parse status counts
    const statusCounts = {};
    (((_aggs$by_status = aggs.by_status) === null || _aggs$by_status === void 0 ? void 0 : _aggs$by_status.buckets) || []).forEach(b => {
      statusCounts[b.key] = b.doc_count;
    });

    // Parse severity counts
    const severityCounts = {};
    (((_aggs$by_severity = aggs.by_severity) === null || _aggs$by_severity === void 0 ? void 0 : _aggs$by_severity.buckets) || []).forEach(b => {
      severityCounts[b.key] = b.doc_count;
    });

    // Parse priority counts
    const priorityCounts = {};
    (((_aggs$by_priority = aggs.by_priority) === null || _aggs$by_priority === void 0 ? void 0 : _aggs$by_priority.buckets) || []).forEach(b => {
      priorityCounts[b.key] = b.doc_count;
    });

    // Parse category counts
    const categoryCounts = {};
    (((_aggs$by_category = aggs.by_category) === null || _aggs$by_category === void 0 ? void 0 : _aggs$by_category.buckets) || []).forEach(b => {
      categoryCounts[b.key] = b.doc_count;
    });
    const totalCases = ((_aggs$total = aggs.total) === null || _aggs$total === void 0 ? void 0 : _aggs$total.value) || 0;
    return {
      total_cases: totalCases,
      open_cases: statusCounts['open'] || 0,
      in_progress_cases: statusCounts['in_progress'] || 0,
      waiting_cases: statusCounts['waiting'] || 0,
      resolved_cases: statusCounts['resolved'] || 0,
      closed_cases: statusCounts['closed'] || 0,
      by_severity: severityCounts,
      by_priority: priorityCounts,
      by_category: categoryCounts,
      avg_resolution_time_ms: ((_aggs$avg_resolution_ = aggs.avg_resolution_time) === null || _aggs$avg_resolution_ === void 0 ? void 0 : _aggs$avg_resolution_.value) || null,
      cases_created_today: ((_aggs$created_today = aggs.created_today) === null || _aggs$created_today === void 0 ? void 0 : _aggs$created_today.doc_count) || 0,
      cases_closed_today: ((_aggs$closed_today = aggs.closed_today) === null || _aggs$closed_today === void 0 ? void 0 : _aggs$closed_today.doc_count) || 0
    };
  }

  /** Get case trends over the last N days */
  static async getCaseTrends(client, days = 30) {
    var _aggs$cases_over_time, _aggs$closed_over_tim;
    const fromDate = new Date();
    fromDate.setDate(fromDate.getDate() - days);
    const aggs = await _opensearch_service.OpenSearchService.aggregateDocuments(client, _constants.CASE_INDEX, {
      query: {
        range: {
          created_at: {
            gte: fromDate.toISOString()
          }
        }
      },
      aggs: {
        cases_over_time: {
          date_histogram: {
            field: 'created_at',
            calendar_interval: 'day'
          }
        },
        closed_over_time: {
          filter: {
            exists: {
              field: 'closed_at'
            }
          },
          aggs: {
            by_day: {
              date_histogram: {
                field: 'closed_at',
                calendar_interval: 'day'
              }
            }
          }
        }
      }
    });
    const createdBuckets = ((_aggs$cases_over_time = aggs.cases_over_time) === null || _aggs$cases_over_time === void 0 ? void 0 : _aggs$cases_over_time.buckets) || [];
    const closedBuckets = ((_aggs$closed_over_tim = aggs.closed_over_time) === null || _aggs$closed_over_tim === void 0 || (_aggs$closed_over_tim = _aggs$closed_over_tim.by_day) === null || _aggs$closed_over_tim === void 0 ? void 0 : _aggs$closed_over_tim.buckets) || [];

    // Merge created and closed into a single timeline
    const closedMap = {};
    closedBuckets.forEach(b => {
      var _b$key_as_string;
      const dateKey = ((_b$key_as_string = b.key_as_string) === null || _b$key_as_string === void 0 ? void 0 : _b$key_as_string.split('T')[0]) || '';
      closedMap[dateKey] = b.doc_count;
    });
    return createdBuckets.map(b => {
      var _b$key_as_string2;
      const dateKey = ((_b$key_as_string2 = b.key_as_string) === null || _b$key_as_string2 === void 0 ? void 0 : _b$key_as_string2.split('T')[0]) || '';
      return {
        date: dateKey,
        created: b.doc_count,
        closed: closedMap[dateKey] || 0
      };
    });
  }

  // ──────────────────────────────────────────────────────────────
  // Automated Alert Handling (Webhooks)
  // ──────────────────────────────────────────────────────────────

  /**
   * Process an incoming alert from a Wazuh webhook.
   * Performs deduplication based on rule.id and agent.id for unresolved cases.
   */
  static async handleAutomatedAlert(client, alert, user) {
    var _alert$rule, _alert$agent, _alert$rule2, _alert$rule3, _alert$rule4, _alert$agent2, _alert$rule5, _alert$rule6, _alert$agent3;
    const ruleId = (_alert$rule = alert.rule) === null || _alert$rule === void 0 ? void 0 : _alert$rule.id;
    const agentId = (_alert$agent = alert.agent) === null || _alert$agent === void 0 ? void 0 : _alert$agent.id;
    const alertId = alert.id;
    if (!ruleId || !agentId || !alertId) {
      throw new Error('Invalid alert payload: Missing rule.id, agent.id, or id');
    }
    const linkedAlert = {
      alert_id: alertId,
      index: alert._index || 'wazuh-alerts-*',
      rule_id: parseInt(ruleId, 10),
      rule_description: ((_alert$rule2 = alert.rule) === null || _alert$rule2 === void 0 ? void 0 : _alert$rule2.description) || 'Unknown Rule',
      rule_level: ((_alert$rule3 = alert.rule) === null || _alert$rule3 === void 0 ? void 0 : _alert$rule3.level) || 0,
      rule_groups: ((_alert$rule4 = alert.rule) === null || _alert$rule4 === void 0 ? void 0 : _alert$rule4.groups) || [],
      agent_id: agentId,
      agent_name: ((_alert$agent2 = alert.agent) === null || _alert$agent2 === void 0 ? void 0 : _alert$agent2.name) || 'Unknown Agent',
      timestamp: alert.timestamp || new Date().toISOString(),
      full_log: alert.full_log
    };

    // Search for an unresolved case with the exact same rule and agent
    const searchBody = {
      query: {
        bool: {
          must: [{
            terms: {
              status: ['open', 'in_progress', 'waiting']
            }
          }, {
            term: {
              'custom_fields.automated_rule_id.keyword': String(ruleId)
            }
          }, {
            term: {
              'custom_fields.automated_agent_id.keyword': String(agentId)
            }
          }]
        }
      },
      size: 1,
      sort: [{
        created_at: {
          order: 'desc'
        }
      }]
    };
    const searchResult = await _opensearch_service.OpenSearchService.searchDocuments(client, _constants.CASE_INDEX, searchBody);

    // IF DUPLICATE FOUND: Append alert and add comment
    if (searchResult.hits.length > 0) {
      const existingCase = searchResult.hits[0];
      const caseId = existingCase._id;

      // Avoid linking the exact same alert twice
      const alreadyLinked = existingCase._source.linked_alerts.some(a => a.alert_id === alertId);
      if (alreadyLinked) {
        return {
          id: caseId,
          ...existingCase._source
        };
      }

      // Add automated comment
      const commentId = uuid();
      const comment = {
        comment_id: commentId,
        author: 'System Automation',
        content: `Duplicate alert detected (Rule ${ruleId} on Agent ${agentId}). Automatically linked.`,
        created_at: new Date().toISOString()
      };
      const updateDoc = {
        linked_alerts: [...existingCase._source.linked_alerts, linkedAlert],
        comments: [...existingCase._source.comments, comment],
        updated_at: new Date().toISOString()
      };
      await _opensearch_service.OpenSearchService.updateDocument(client, _constants.CASE_INDEX, caseId, updateDoc);
      return await CaseService.getCase(client, caseId);
    }

    // IF NO DUPLICATE: Create new case
    let severity = 'low';
    const level = ((_alert$rule5 = alert.rule) === null || _alert$rule5 === void 0 ? void 0 : _alert$rule5.level) || 0;
    if (level >= 12) severity = 'critical';else if (level >= 8) severity = 'high';else if (level >= 5) severity = 'medium';
    const payload = {
      title: `[Automated] ${((_alert$rule6 = alert.rule) === null || _alert$rule6 === void 0 ? void 0 : _alert$rule6.description) || 'Security Alert'}`,
      description: `Automated case created from Wazuh Alert.\n\nRule: ${ruleId}\nAgent: ${(_alert$agent3 = alert.agent) === null || _alert$agent3 === void 0 ? void 0 : _alert$agent3.name} (${agentId})\nLevel: ${level}\n\nLog: ${alert.full_log || 'N/A'}`,
      severity,
      priority: 'P2',
      category: 'other',
      tags: ['automated', `rule_${ruleId}`, `agent_${agentId}`]
    };
    const newCase = await CaseService.createCase(client, payload, user);

    // Add custom fields for deduplication tracking
    if (newCase.id) {
      await _opensearch_service.OpenSearchService.updateDocument(client, _constants.CASE_INDEX, newCase.id, {
        custom_fields: {
          automated_rule_id: String(ruleId),
          automated_agent_id: String(agentId)
        },
        linked_alerts: [linkedAlert]
      });
      return await CaseService.getCase(client, newCase.id);
    }
    return newCase;
  }
}
exports.CaseService = CaseService;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfY29uc3RhbnRzIiwicmVxdWlyZSIsIl9vcGVuc2VhcmNoX3NlcnZpY2UiLCJfc2V0dGluZ3Nfc2VydmljZSIsIl9ub3RpZmljYXRpb25fc2VydmljZSIsIl9jYXNlX21hcHBpbmdzIiwiZW1wdHlBbmFseXRpY3NTdW1tYXJ5IiwidG90YWxfY2FzZXMiLCJvcGVuX2Nhc2VzIiwiaW5fcHJvZ3Jlc3NfY2FzZXMiLCJ3YWl0aW5nX2Nhc2VzIiwicmVzb2x2ZWRfY2FzZXMiLCJjbG9zZWRfY2FzZXMiLCJieV9zZXZlcml0eSIsImJ5X3ByaW9yaXR5IiwiYnlfY2F0ZWdvcnkiLCJhdmdfcmVzb2x1dGlvbl90aW1lX21zIiwiY2FzZXNfY3JlYXRlZF90b2RheSIsImNhc2VzX2Nsb3NlZF90b2RheSIsInV1aWQiLCJjcnlwdG8iLCJyYW5kb21VVUlEIiwicmVwbGFjZSIsInN1YnN0cmluZyIsIkRhdGUiLCJub3ciLCJ0b1N0cmluZyIsIk1hdGgiLCJyYW5kb20iLCJDYXNlU2VydmljZSIsImdlbmVyYXRlQ2FzZUlkIiwiY2xpZW50IiwiY291bnRlciIsIk9wZW5TZWFyY2hTZXJ2aWNlIiwiZ2V0TmV4dENvdW50ZXJWYWx1ZSIsInNldHRpbmdzIiwiU2V0dGluZ3NTZXJ2aWNlIiwiZ2V0U2V0dGluZ3MiLCJmb3JtYXRDYXNlSWQiLCJfZSIsInllYXIiLCJnZXRGdWxsWWVhciIsInBhZGRlZE51bSIsIlN0cmluZyIsInBhZFN0YXJ0IiwiQ0FTRV9JRF9QUkVGSVgiLCJDQVNFX0lEX1NFUEFSQVRPUiIsImNyZWF0ZUFjdGl2aXR5IiwiYWN0aW9uIiwidXNlciIsImRldGFpbHMiLCJpZCIsInRpbWVzdGFtcCIsInRvSVNPU3RyaW5nIiwiY3JlYXRlQ2FzZSIsInBheWxvYWQiLCJlbnN1cmVJbmRleCIsIkNBU0VfQ09VTlRFUl9JTkRFWCIsImNvdW50ZXJNYXBwaW5ncyIsIkNBU0VfSU5ERVgiLCJjYXNlTWFwcGluZ3MiLCJjYXNlSWQiLCJuZXdDYXNlIiwiY2FzZV9pZCIsInRpdGxlIiwiZGVzY3JpcHRpb24iLCJzdGF0dXMiLCJzZXZlcml0eSIsInByaW9yaXR5IiwiY2F0ZWdvcnkiLCJ0bHAiLCJ0YWdzIiwiYXNzaWduZWUiLCJjcmVhdGVkX2J5IiwiY3JlYXRlZF9hdCIsInVwZGF0ZWRfYXQiLCJjbG9zZWRfYXQiLCJsaW5rZWRfYWxlcnRzIiwib2JzZXJ2YWJsZXMiLCJjb21tZW50cyIsInRhc2tzIiwibm90ZXMiLCJhY3Rpdml0eV9sb2ciLCJyZXNvbHV0aW9uX3N1bW1hcnkiLCJ0aW1lX3RvX3Jlc29sdmVfbXMiLCJyZWxhdGVkX2Nhc2VzIiwiY3VzdG9tX2ZpZWxkcyIsInB1c2giLCJfaWQiLCJjcmVhdGVEb2N1bWVudCIsIk5vdGlmaWNhdGlvblNlcnZpY2UiLCJkaXNwYXRjaCIsImV2ZW50IiwicmVjaXBpZW50cyIsIm1lc3NhZ2UiLCJjYXNlUmVmIiwiYWN0b3IiLCJnZXRDYXNlIiwiZG9jIiwiZ2V0RG9jdW1lbnQiLCJfc291cmNlIiwidXBkYXRlQ2FzZSIsImV4aXN0aW5nIiwiYWN0aXZpdGllcyIsInVwZGF0ZURvYyIsInVuZGVmaW5lZCIsImZyb20iLCJ0byIsImxlbmd0aCIsInVwZGF0ZURvY3VtZW50IiwiZGVsZXRlQ2FzZSIsImRlbGV0ZURvY3VtZW50IiwibGlzdENhc2VzIiwicXVlcnkiLCJwYWdlIiwicGVyUGFnZSIsIm1pbiIsInBlcl9wYWdlIiwiREVGQVVMVF9QQUdFX1NJWkUiLCJNQVhfUEFHRV9TSVpFIiwic29ydEZpZWxkIiwic29ydF9maWVsZCIsIkRFRkFVTFRfU09SVF9GSUVMRCIsInNvcnRPcmRlciIsInNvcnRfb3JkZXIiLCJERUZBVUxUX1NPUlRfT1JERVIiLCJtdXN0IiwidGVybSIsInRhZ0xpc3QiLCJzcGxpdCIsIm1hcCIsInQiLCJ0cmltIiwidGVybXMiLCJzZWFyY2giLCJtdWx0aV9tYXRjaCIsImZpZWxkcyIsInR5cGUiLCJmdXp6aW5lc3MiLCJjcmVhdGVkX2Zyb20iLCJjcmVhdGVkX3RvIiwicmFuZ2UiLCJndGUiLCJsdGUiLCJzZWFyY2hCb2R5IiwiYm9vbCIsIm1hdGNoX2FsbCIsInNvcnQiLCJvcmRlciIsInNpemUiLCJleGNsdWRlcyIsImhpdHMiLCJ0b3RhbCIsInNlYXJjaERvY3VtZW50cyIsImNhc2VzIiwiaGl0IiwiY2hhbmdlU3RhdHVzIiwibmV3U3RhdHVzIiwic3VjY2VzcyIsImVycm9yIiwiYWxsb3dlZFRyYW5zaXRpb25zIiwiU1RBVFVTX1RSQU5TSVRJT05TIiwiaW5jbHVkZXMiLCJqb2luIiwiZ2V0VGltZSIsImFjdGl2aXR5IiwidXBkYXRlZENhc2UiLCJjb250ZXh0IiwiY2FzZSIsImFzc2lnbkNhc2UiLCJhZGRUYXNrIiwicGFyYW1zIiwibmV3VGFzayIsInRhc2tfaWQiLCJjb21wbGV0ZWQiLCJhc3NpZ25lZF90byIsImR1ZV9kYXRlIiwibm90aWZ5VGFza0Fzc2lnbm1lbnQiLCJ1cGRhdGVUYXNrIiwidGFza0lkIiwidXBkYXRlcyIsInRhcmdldCIsImZpbmQiLCJwcmV2aW91c0Fzc2lnbmVlIiwibmV4dEFzc2lnbmVlIiwiY2FzZUl0ZW0iLCJ0YXNrIiwiZHVlIiwidGFza190aXRsZSIsInRvZ2dsZVRhc2siLCJjb21wbGV0ZWRfYXQiLCJjb21wbGV0ZWRfYnkiLCJyZW1vdmVUYXNrIiwiZmlsdGVyIiwidXBkYXRlTm90ZXMiLCJhZGRDb21tZW50IiwiY29udGVudCIsImNvbW1lbnQiLCJjb21tZW50X2lkIiwiYXV0aG9yIiwiZGVsZXRlQ29tbWVudCIsImNvbW1lbnRJZCIsInVwZGF0ZWRDb21tZW50cyIsImMiLCJsaW5rQWxlcnQiLCJhbGVydCIsInNvbWUiLCJhIiwiYWxlcnRfaWQiLCJydWxlX2Rlc2NyaXB0aW9uIiwidW5saW5rQWxlcnQiLCJhbGVydElkIiwidXBkYXRlZEFsZXJ0cyIsInNlYXJjaEFsZXJ0cyIsImxlbmllbnQiLCJhZ2VudF9pZCIsInJ1bGVfaWQiLCJsZXZlbF9taW4iLCJsZXZlbF9tYXgiLCJXQVpVSF9BTEVSVFNfSU5ERVhfUEFUVEVSTiIsImFkZE9ic2VydmFibGUiLCJvYnNlcnZhYmxlIiwibmV3T2JzZXJ2YWJsZSIsImFkZGVkX2F0IiwiYWRkZWRfYnkiLCJ2YWx1ZSIsInJlbW92ZU9ic2VydmFibGUiLCJvYnNlcnZhYmxlSWQiLCJ1cGRhdGVkIiwibyIsIm9ic2VydmFibGVfaWQiLCJnZXRBbmFseXRpY3NTdW1tYXJ5IiwiY29tcHV0ZUFuYWx5dGljc1N1bW1hcnkiLCJlIiwiX2FnZ3MkYnlfc3RhdHVzIiwiX2FnZ3MkYnlfc2V2ZXJpdHkiLCJfYWdncyRieV9wcmlvcml0eSIsIl9hZ2dzJGJ5X2NhdGVnb3J5IiwiX2FnZ3MkdG90YWwiLCJfYWdncyRhdmdfcmVzb2x1dGlvbl8iLCJfYWdncyRjcmVhdGVkX3RvZGF5IiwiX2FnZ3MkY2xvc2VkX3RvZGF5IiwidG9kYXkiLCJzZXRIb3VycyIsInRvZGF5U3RyIiwiYWdncyIsImFnZ3JlZ2F0ZURvY3VtZW50cyIsImJ5X3N0YXR1cyIsImZpZWxkIiwiYXZnX3Jlc29sdXRpb25fdGltZSIsImF2ZyIsImNyZWF0ZWRfdG9kYXkiLCJjbG9zZWRfdG9kYXkiLCJ2YWx1ZV9jb3VudCIsInN0YXR1c0NvdW50cyIsImJ1Y2tldHMiLCJmb3JFYWNoIiwiYiIsImtleSIsImRvY19jb3VudCIsInNldmVyaXR5Q291bnRzIiwicHJpb3JpdHlDb3VudHMiLCJjYXRlZ29yeUNvdW50cyIsInRvdGFsQ2FzZXMiLCJnZXRDYXNlVHJlbmRzIiwiZGF5cyIsIl9hZ2dzJGNhc2VzX292ZXJfdGltZSIsIl9hZ2dzJGNsb3NlZF9vdmVyX3RpbSIsImZyb21EYXRlIiwic2V0RGF0ZSIsImdldERhdGUiLCJjYXNlc19vdmVyX3RpbWUiLCJkYXRlX2hpc3RvZ3JhbSIsImNhbGVuZGFyX2ludGVydmFsIiwiY2xvc2VkX292ZXJfdGltZSIsImV4aXN0cyIsImJ5X2RheSIsImNyZWF0ZWRCdWNrZXRzIiwiY2xvc2VkQnVja2V0cyIsImNsb3NlZE1hcCIsIl9iJGtleV9hc19zdHJpbmciLCJkYXRlS2V5Iiwia2V5X2FzX3N0cmluZyIsIl9iJGtleV9hc19zdHJpbmcyIiwiZGF0ZSIsImNyZWF0ZWQiLCJjbG9zZWQiLCJoYW5kbGVBdXRvbWF0ZWRBbGVydCIsIl9hbGVydCRydWxlIiwiX2FsZXJ0JGFnZW50IiwiX2FsZXJ0JHJ1bGUyIiwiX2FsZXJ0JHJ1bGUzIiwiX2FsZXJ0JHJ1bGU0IiwiX2FsZXJ0JGFnZW50MiIsIl9hbGVydCRydWxlNSIsIl9hbGVydCRydWxlNiIsIl9hbGVydCRhZ2VudDMiLCJydWxlSWQiLCJydWxlIiwiYWdlbnRJZCIsImFnZW50IiwiRXJyb3IiLCJsaW5rZWRBbGVydCIsImluZGV4IiwiX2luZGV4IiwicGFyc2VJbnQiLCJydWxlX2xldmVsIiwibGV2ZWwiLCJydWxlX2dyb3VwcyIsImdyb3VwcyIsImFnZW50X25hbWUiLCJuYW1lIiwiZnVsbF9sb2ciLCJzZWFyY2hSZXN1bHQiLCJleGlzdGluZ0Nhc2UiLCJhbHJlYWR5TGlua2VkIiwiYXV0b21hdGVkX3J1bGVfaWQiLCJhdXRvbWF0ZWRfYWdlbnRfaWQiLCJleHBvcnRzIl0sInNvdXJjZXMiOlsiY2FzZV9zZXJ2aWNlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qXG4gKiBXYXp1aCBDYXNlIE1hbmFnZW1lbnQgUGx1Z2luXG4gKiBDYXNlIFNlcnZpY2U6IEJ1c2luZXNzIGxvZ2ljIGZvciBjYXNlIG1hbmFnZW1lbnQgb3BlcmF0aW9uc1xuICpcbiAqIEhhbmRsZXMgY2FzZSBJRCBnZW5lcmF0aW9uLCBDUlVELCBzdGF0dXMgdHJhbnNpdGlvbnMsIGNvbW1lbnRzLFxuICogYWxlcnQgbGlua2luZywgb2JzZXJ2YWJsZXMsIGFjdGl2aXR5IGxvZ2dpbmcsIGFuZCBhbmFseXRpY3MuXG4gKi9cblxuaW1wb3J0IHsgdjQgYXMgdXVpZFY0IH0gZnJvbSAnY3J5cHRvJztcbmltcG9ydCB7XG4gIENhc2UsXG4gIENyZWF0ZUNhc2VQYXlsb2FkLFxuICBVcGRhdGVDYXNlUGF5bG9hZCxcbiAgQ2FzZVN0YXR1cyxcbiAgQ2FzZVNldmVyaXR5LFxuICBDYXNlQWN0aXZpdHksXG4gIENhc2VDb21tZW50LFxuICBMaW5rZWRBbGVydCxcbiAgT2JzZXJ2YWJsZSxcbiAgQW5hbHl0aWNzU3VtbWFyeSxcbiAgQ2FzZVRyZW5kLFxuICBDYXNlTGlzdFF1ZXJ5LFxuICBDYXNlTGlzdFJlc3BvbnNlLFxuICBDYXNlVGFzayxcbiAgV2F6dWhBbGVydFNlYXJjaFF1ZXJ5LFxufSBmcm9tICcuLi8uLi9jb21tb24vdHlwZXMnO1xuaW1wb3J0IHtcbiAgQ0FTRV9JTkRFWCxcbiAgQ0FTRV9DT1VOVEVSX0lOREVYLFxuICBDQVNFX0lEX1BSRUZJWCxcbiAgQ0FTRV9JRF9TRVBBUkFUT1IsXG4gIFNUQVRVU19UUkFOU0lUSU9OUyxcbiAgV0FaVUhfQUxFUlRTX0lOREVYX1BBVFRFUk4sXG4gIERFRkFVTFRfUEFHRV9TSVpFLFxuICBNQVhfUEFHRV9TSVpFLFxuICBERUZBVUxUX1NPUlRfRklFTEQsXG4gIERFRkFVTFRfU09SVF9PUkRFUixcbn0gZnJvbSAnLi4vLi4vY29tbW9uL2NvbnN0YW50cyc7XG5pbXBvcnQgeyBPcGVuU2VhcmNoU2VydmljZSB9IGZyb20gJy4vb3BlbnNlYXJjaF9zZXJ2aWNlJztcbmltcG9ydCB7IFNldHRpbmdzU2VydmljZSB9IGZyb20gJy4vc2V0dGluZ3Nfc2VydmljZSc7XG5pbXBvcnQgeyBOb3RpZmljYXRpb25TZXJ2aWNlIH0gZnJvbSAnLi9ub3RpZmljYXRpb25fc2VydmljZSc7XG5pbXBvcnQgeyBjYXNlTWFwcGluZ3MsIGNvdW50ZXJNYXBwaW5ncyB9IGZyb20gJy4uL3NhdmVkX29iamVjdHMvY2FzZV9tYXBwaW5ncyc7XG5cbi8qKiBFbXB0eSBhbmFseXRpY3Mgc3VtbWFyeTogcmV0dXJuZWQgd2hlbiB0aGVyZSBhcmUgbm8gY2FzZXMgb3IgdGhlIGluZGV4IGlzIHVuYXZhaWxhYmxlLiAqL1xuZnVuY3Rpb24gZW1wdHlBbmFseXRpY3NTdW1tYXJ5KCk6IEFuYWx5dGljc1N1bW1hcnkge1xuICByZXR1cm4ge1xuICAgIHRvdGFsX2Nhc2VzOiAwLFxuICAgIG9wZW5fY2FzZXM6IDAsXG4gICAgaW5fcHJvZ3Jlc3NfY2FzZXM6IDAsXG4gICAgd2FpdGluZ19jYXNlczogMCxcbiAgICByZXNvbHZlZF9jYXNlczogMCxcbiAgICBjbG9zZWRfY2FzZXM6IDAsXG4gICAgYnlfc2V2ZXJpdHk6IHt9IGFzIGFueSxcbiAgICBieV9wcmlvcml0eToge30gYXMgYW55LFxuICAgIGJ5X2NhdGVnb3J5OiB7fSxcbiAgICBhdmdfcmVzb2x1dGlvbl90aW1lX21zOiBudWxsLFxuICAgIGNhc2VzX2NyZWF0ZWRfdG9kYXk6IDAsXG4gICAgY2FzZXNfY2xvc2VkX3RvZGF5OiAwLFxuICB9O1xufVxuXG4vKiogR2VuZXJhdGUgYSBVVUlEIHY0IHdpdGhvdXQgZGFzaGVzIChjb21wYWN0KSAqL1xuZnVuY3Rpb24gdXVpZCgpOiBzdHJpbmcge1xuICAvLyBVc2UgY3J5cHRvLnJhbmRvbVVVSUQgaWYgYXZhaWxhYmxlLCBmYWxsYmFjayB0byBtYW51YWxcbiAgdHJ5IHtcbiAgICByZXR1cm4gY3J5cHRvLnJhbmRvbVVVSUQoKS5yZXBsYWNlKC8tL2csICcnKS5zdWJzdHJpbmcoMCwgMTIpO1xuICB9IGNhdGNoIHtcbiAgICByZXR1cm4gRGF0ZS5ub3coKS50b1N0cmluZygzNikgKyBNYXRoLnJhbmRvbSgpLnRvU3RyaW5nKDM2KS5zdWJzdHJpbmcoMiwgOCk7XG4gIH1cbn1cblxuLyoqXG4gKiBDYXNlU2VydmljZTogYWxsIGNhc2UgbWFuYWdlbWVudCBidXNpbmVzcyBsb2dpYy5cbiAqIE1ldGhvZHMgYXJlIHN0YXRpYzsgdGhlIE9wZW5TZWFyY2ggY2xpZW50IGlzIHBhc3NlZCBpbiBwZXItcmVxdWVzdC5cbiAqL1xuZXhwb3J0IGNsYXNzIENhc2VTZXJ2aWNlIHtcbiAgLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gIC8vIENhc2UgSUQgR2VuZXJhdGlvblxuICAvLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuICAvKipcbiAgICogR2VuZXJhdGUgdGhlIG5leHQgaHVtYW4tcmVhZGFibGUgY2FzZSBJRC5cbiAgICogRm9ybWF0OiBDQVNFLTIwMjYtMDAwMVxuICAgKi9cbiAgc3RhdGljIGFzeW5jIGdlbmVyYXRlQ2FzZUlkKGNsaWVudDogYW55KTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgICBjb25zdCBjb3VudGVyID0gYXdhaXQgT3BlblNlYXJjaFNlcnZpY2UuZ2V0TmV4dENvdW50ZXJWYWx1ZShjbGllbnQpO1xuXG4gICAgLy8gVGhlIElEIGZvcm1hdCBpcyB1c2VyLWNvbmZpZ3VyYWJsZSAoU2V0dGluZ3MgLT4gQ2FzZSBJRCBGb3JtYXQpLiBGYWxsIGJhY2tcbiAgICAvLyB0byB0aGUgY29tcGlsZWQtaW4gZGVmYXVsdHMgaWYgc2V0dGluZ3MgY2Fubm90IGJlIHJlYWQgZm9yIGFueSByZWFzb24uXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHNldHRpbmdzID0gYXdhaXQgU2V0dGluZ3NTZXJ2aWNlLmdldFNldHRpbmdzKGNsaWVudCk7XG4gICAgICByZXR1cm4gU2V0dGluZ3NTZXJ2aWNlLmZvcm1hdENhc2VJZChzZXR0aW5ncywgY291bnRlcik7XG4gICAgfSBjYXRjaCAoX2UpIHtcbiAgICAgIGNvbnN0IHllYXIgPSBuZXcgRGF0ZSgpLmdldEZ1bGxZZWFyKCk7XG4gICAgICBjb25zdCBwYWRkZWROdW0gPSBTdHJpbmcoY291bnRlcikucGFkU3RhcnQoNCwgJzAnKTtcbiAgICAgIHJldHVybiBgJHtDQVNFX0lEX1BSRUZJWH0ke0NBU0VfSURfU0VQQVJBVE9SfSR7eWVhcn0ke0NBU0VfSURfU0VQQVJBVE9SfSR7cGFkZGVkTnVtfWA7XG4gICAgfVxuICB9XG5cbiAgLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gIC8vIEFjdGl2aXR5IExvZyBIZWxwZXJcbiAgLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbiAgcHJpdmF0ZSBzdGF0aWMgY3JlYXRlQWN0aXZpdHkoXG4gICAgYWN0aW9uOiBDYXNlQWN0aXZpdHlbJ2FjdGlvbiddLFxuICAgIHVzZXI6IHN0cmluZyxcbiAgICBkZXRhaWxzPzogUmVjb3JkPHN0cmluZywgYW55PixcbiAgKTogQ2FzZUFjdGl2aXR5IHtcbiAgICByZXR1cm4ge1xuICAgICAgaWQ6IHV1aWQoKSxcbiAgICAgIGFjdGlvbixcbiAgICAgIHVzZXIsXG4gICAgICB0aW1lc3RhbXA6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgIGRldGFpbHMsXG4gICAgfTtcbiAgfVxuXG4gIC8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICAvLyBDYXNlIENSVURcbiAgLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbiAgLyoqIENyZWF0ZSBhIG5ldyBjYXNlICovXG4gIHN0YXRpYyBhc3luYyBjcmVhdGVDYXNlKFxuICAgIGNsaWVudDogYW55LFxuICAgIHBheWxvYWQ6IENyZWF0ZUNhc2VQYXlsb2FkLFxuICAgIHVzZXI6IHN0cmluZyxcbiAgKTogUHJvbWlzZTxDYXNlPiB7XG4gICAgLy8gQXV0by1oZWFsOiBtYWtlIHN1cmUgdGhlIGluZGljZXMgZXhpc3Qgd2l0aCB0aGUgY29ycmVjdCBtYXBwaW5nIGJlZm9yZSB3cml0aW5nLFxuICAgIC8vIHNvIGRlbGV0aW5nIGFuIGluZGV4IGFuZCB0aGVuIGNyZWF0aW5nIGEgY2FzZSByZXN0b3JlcyB0aGUgcHJvcGVyIHNjaGVtYS5cbiAgICBhd2FpdCBPcGVuU2VhcmNoU2VydmljZS5lbnN1cmVJbmRleChjbGllbnQsIENBU0VfQ09VTlRFUl9JTkRFWCwgY291bnRlck1hcHBpbmdzKTtcbiAgICBhd2FpdCBPcGVuU2VhcmNoU2VydmljZS5lbnN1cmVJbmRleChjbGllbnQsIENBU0VfSU5ERVgsIGNhc2VNYXBwaW5ncyk7XG5cbiAgICBjb25zdCBjYXNlSWQgPSBhd2FpdCBDYXNlU2VydmljZS5nZW5lcmF0ZUNhc2VJZChjbGllbnQpO1xuICAgIGNvbnN0IG5vdyA9IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKTtcblxuICAgIGNvbnN0IG5ld0Nhc2U6IENhc2UgPSB7XG4gICAgICBjYXNlX2lkOiBjYXNlSWQsXG4gICAgICB0aXRsZTogcGF5bG9hZC50aXRsZSxcbiAgICAgIGRlc2NyaXB0aW9uOiBwYXlsb2FkLmRlc2NyaXB0aW9uLFxuICAgICAgc3RhdHVzOiAnb3BlbicsXG4gICAgICBzZXZlcml0eTogcGF5bG9hZC5zZXZlcml0eSxcbiAgICAgIHByaW9yaXR5OiBwYXlsb2FkLnByaW9yaXR5LFxuICAgICAgY2F0ZWdvcnk6IHBheWxvYWQuY2F0ZWdvcnksXG4gICAgICB0bHA6IHBheWxvYWQudGxwIHx8ICdXSElURScsXG4gICAgICB0YWdzOiBwYXlsb2FkLnRhZ3MgfHwgW10sXG4gICAgICBhc3NpZ25lZTogcGF5bG9hZC5hc3NpZ25lZSB8fCBudWxsLFxuICAgICAgY3JlYXRlZF9ieTogdXNlcixcbiAgICAgIGNyZWF0ZWRfYXQ6IG5vdyxcbiAgICAgIHVwZGF0ZWRfYXQ6IG5vdyxcbiAgICAgIGNsb3NlZF9hdDogbnVsbCxcbiAgICAgIGxpbmtlZF9hbGVydHM6IFtdLFxuICAgICAgb2JzZXJ2YWJsZXM6IFtdLFxuICAgICAgY29tbWVudHM6IFtdLFxuICAgICAgdGFza3M6IFtdLFxuICAgICAgbm90ZXM6ICcnLFxuICAgICAgYWN0aXZpdHlfbG9nOiBbXG4gICAgICAgIENhc2VTZXJ2aWNlLmNyZWF0ZUFjdGl2aXR5KCdjYXNlX2NyZWF0ZWQnLCB1c2VyLCB7XG4gICAgICAgICAgY2FzZV9pZDogY2FzZUlkLFxuICAgICAgICAgIHRpdGxlOiBwYXlsb2FkLnRpdGxlLFxuICAgICAgICB9KSxcbiAgICAgIF0sXG4gICAgICByZXNvbHV0aW9uX3N1bW1hcnk6IG51bGwsXG4gICAgICB0aW1lX3RvX3Jlc29sdmVfbXM6IG51bGwsXG4gICAgICByZWxhdGVkX2Nhc2VzOiBbXSxcbiAgICAgIGN1c3RvbV9maWVsZHM6IHt9LFxuICAgIH07XG5cbiAgICAvLyBJZiBhbiBhc3NpZ25lZSB3YXMgcHJvdmlkZWQsIGxvZyB0aGUgYXNzaWdubWVudFxuICAgIGlmIChwYXlsb2FkLmFzc2lnbmVlKSB7XG4gICAgICBuZXdDYXNlLmFjdGl2aXR5X2xvZy5wdXNoKFxuICAgICAgICBDYXNlU2VydmljZS5jcmVhdGVBY3Rpdml0eSgnYXNzaWduZWQnLCB1c2VyLCB7IGFzc2lnbmVlOiBwYXlsb2FkLmFzc2lnbmVlIH0pLFxuICAgICAgKTtcbiAgICB9XG5cbiAgICBjb25zdCB7IF9pZCB9ID0gYXdhaXQgT3BlblNlYXJjaFNlcnZpY2UuY3JlYXRlRG9jdW1lbnQoY2xpZW50LCBDQVNFX0lOREVYLCBuZXdDYXNlKTtcbiAgICBuZXdDYXNlLmlkID0gX2lkO1xuXG4gICAgLy8gVGhlIGF1dG8tbW9uaXRvciBzZW5kcyBpdHMgb3duLCByaWNoZXIgbm90aWZpY2F0aW9uIG9uY2UgdGhlIGNhc2UgaGFzIGJlZW5cbiAgICAvLyBmaW5hbGlzZWQgd2l0aCBpdHMgdGl0bGUgYW5kIGxpbmtlZCBhbGVydC4gRG9uJ3QgZHVwbGljYXRlIGl0IGhlcmUuXG4gICAgaWYgKHVzZXIgIT09ICdhdXRvLW1vbml0b3InKSB7XG4gICAgICBhd2FpdCBOb3RpZmljYXRpb25TZXJ2aWNlLmRpc3BhdGNoKGNsaWVudCwge1xuICAgICAgICBldmVudDogcGF5bG9hZC5hc3NpZ25lZSA/ICdjYXNlX2Fzc2lnbmVkJyA6ICdjYXNlX2NyZWF0ZWQnLFxuICAgICAgICByZWNpcGllbnRzOiBbcGF5bG9hZC5hc3NpZ25lZV0sXG4gICAgICAgIHRpdGxlOiBgQ2FzZSAke2Nhc2VJZH0gY3JlYXRlZGAsXG4gICAgICAgIG1lc3NhZ2U6IGAke3VzZXJ9IGNyZWF0ZWQgXCIke3BheWxvYWQudGl0bGV9XCIgKCR7cGF5bG9hZC5wcmlvcml0eX0sICR7cGF5bG9hZC5zZXZlcml0eX0pLmAsXG4gICAgICAgIGNhc2VSZWY6IG5ld0Nhc2UsXG4gICAgICAgIGFjdG9yOiB1c2VyLFxuICAgICAgfSk7XG4gICAgfVxuXG4gICAgcmV0dXJuIG5ld0Nhc2U7XG4gIH1cblxuICAvKiogR2V0IGEgc2luZ2xlIGNhc2UgYnkgaXRzIE9wZW5TZWFyY2ggX2lkICovXG4gIHN0YXRpYyBhc3luYyBnZXRDYXNlKGNsaWVudDogYW55LCBpZDogc3RyaW5nKTogUHJvbWlzZTxDYXNlIHwgbnVsbD4ge1xuICAgIGNvbnN0IGRvYyA9IGF3YWl0IE9wZW5TZWFyY2hTZXJ2aWNlLmdldERvY3VtZW50KGNsaWVudCwgQ0FTRV9JTkRFWCwgaWQpO1xuICAgIGlmICghZG9jKSByZXR1cm4gbnVsbDtcbiAgICByZXR1cm4geyBpZDogZG9jLl9pZCwgLi4uZG9jLl9zb3VyY2UgfSBhcyBDYXNlO1xuICB9XG5cbiAgLyoqIFVwZGF0ZSBhIGNhc2UgKHBhcnRpYWwgdXBkYXRlKSAqL1xuICBzdGF0aWMgYXN5bmMgdXBkYXRlQ2FzZShcbiAgICBjbGllbnQ6IGFueSxcbiAgICBpZDogc3RyaW5nLFxuICAgIHBheWxvYWQ6IFVwZGF0ZUNhc2VQYXlsb2FkLFxuICAgIHVzZXI6IHN0cmluZyxcbiAgKTogUHJvbWlzZTxDYXNlIHwgbnVsbD4ge1xuICAgIGNvbnN0IGV4aXN0aW5nID0gYXdhaXQgQ2FzZVNlcnZpY2UuZ2V0Q2FzZShjbGllbnQsIGlkKTtcbiAgICBpZiAoIWV4aXN0aW5nKSByZXR1cm4gbnVsbDtcblxuICAgIGNvbnN0IG5vdyA9IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKTtcbiAgICBjb25zdCBhY3Rpdml0aWVzOiBDYXNlQWN0aXZpdHlbXSA9IFtdO1xuICAgIGNvbnN0IHVwZGF0ZURvYzogYW55ID0geyB1cGRhdGVkX2F0OiBub3cgfTtcblxuICAgIC8vIFRyYWNrIGNoYW5nZXMgZm9yIGFjdGl2aXR5IGxvZ1xuICAgIGlmIChwYXlsb2FkLnRpdGxlICE9PSB1bmRlZmluZWQgJiYgcGF5bG9hZC50aXRsZSAhPT0gZXhpc3RpbmcudGl0bGUpIHtcbiAgICAgIHVwZGF0ZURvYy50aXRsZSA9IHBheWxvYWQudGl0bGU7XG4gICAgfVxuICAgIGlmIChwYXlsb2FkLmRlc2NyaXB0aW9uICE9PSB1bmRlZmluZWQpIHtcbiAgICAgIHVwZGF0ZURvYy5kZXNjcmlwdGlvbiA9IHBheWxvYWQuZGVzY3JpcHRpb247XG4gICAgfVxuICAgIGlmIChwYXlsb2FkLnNldmVyaXR5ICE9PSB1bmRlZmluZWQgJiYgcGF5bG9hZC5zZXZlcml0eSAhPT0gZXhpc3Rpbmcuc2V2ZXJpdHkpIHtcbiAgICAgIHVwZGF0ZURvYy5zZXZlcml0eSA9IHBheWxvYWQuc2V2ZXJpdHk7XG4gICAgICBhY3Rpdml0aWVzLnB1c2goXG4gICAgICAgIENhc2VTZXJ2aWNlLmNyZWF0ZUFjdGl2aXR5KCdzZXZlcml0eV9jaGFuZ2VkJywgdXNlciwge1xuICAgICAgICAgIGZyb206IGV4aXN0aW5nLnNldmVyaXR5LFxuICAgICAgICAgIHRvOiBwYXlsb2FkLnNldmVyaXR5LFxuICAgICAgICB9KSxcbiAgICAgICk7XG4gICAgfVxuICAgIGlmIChwYXlsb2FkLnByaW9yaXR5ICE9PSB1bmRlZmluZWQgJiYgcGF5bG9hZC5wcmlvcml0eSAhPT0gZXhpc3RpbmcucHJpb3JpdHkpIHtcbiAgICAgIHVwZGF0ZURvYy5wcmlvcml0eSA9IHBheWxvYWQucHJpb3JpdHk7XG4gICAgICBhY3Rpdml0aWVzLnB1c2goXG4gICAgICAgIENhc2VTZXJ2aWNlLmNyZWF0ZUFjdGl2aXR5KCdwcmlvcml0eV9jaGFuZ2VkJywgdXNlciwge1xuICAgICAgICAgIGZyb206IGV4aXN0aW5nLnByaW9yaXR5LFxuICAgICAgICAgIHRvOiBwYXlsb2FkLnByaW9yaXR5LFxuICAgICAgICB9KSxcbiAgICAgICk7XG4gICAgfVxuICAgIGlmIChwYXlsb2FkLmNhdGVnb3J5ICE9PSB1bmRlZmluZWQpIHtcbiAgICAgIHVwZGF0ZURvYy5jYXRlZ29yeSA9IHBheWxvYWQuY2F0ZWdvcnk7XG4gICAgfVxuICAgIGlmIChwYXlsb2FkLnRscCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICB1cGRhdGVEb2MudGxwID0gcGF5bG9hZC50bHA7XG4gICAgfVxuICAgIGlmIChwYXlsb2FkLnRhZ3MgIT09IHVuZGVmaW5lZCkge1xuICAgICAgdXBkYXRlRG9jLnRhZ3MgPSBwYXlsb2FkLnRhZ3M7XG4gICAgfVxuICAgIGlmIChwYXlsb2FkLmFzc2lnbmVlICE9PSB1bmRlZmluZWQgJiYgcGF5bG9hZC5hc3NpZ25lZSAhPT0gZXhpc3RpbmcuYXNzaWduZWUpIHtcbiAgICAgIHVwZGF0ZURvYy5hc3NpZ25lZSA9IHBheWxvYWQuYXNzaWduZWU7XG4gICAgICBhY3Rpdml0aWVzLnB1c2goXG4gICAgICAgIENhc2VTZXJ2aWNlLmNyZWF0ZUFjdGl2aXR5KHBheWxvYWQuYXNzaWduZWUgPyAnYXNzaWduZWQnIDogJ3VuYXNzaWduZWQnLCB1c2VyLCB7XG4gICAgICAgICAgZnJvbTogZXhpc3RpbmcuYXNzaWduZWUsXG4gICAgICAgICAgdG86IHBheWxvYWQuYXNzaWduZWUsXG4gICAgICAgIH0pLFxuICAgICAgKTtcbiAgICB9XG4gICAgaWYgKHBheWxvYWQucmVzb2x1dGlvbl9zdW1tYXJ5ICE9PSB1bmRlZmluZWQpIHtcbiAgICAgIHVwZGF0ZURvYy5yZXNvbHV0aW9uX3N1bW1hcnkgPSBwYXlsb2FkLnJlc29sdXRpb25fc3VtbWFyeTtcbiAgICB9XG5cbiAgICAvLyBBcHBlbmQgYWN0aXZpdGllc1xuICAgIGlmIChhY3Rpdml0aWVzLmxlbmd0aCA+IDApIHtcbiAgICAgIHVwZGF0ZURvYy5hY3Rpdml0eV9sb2cgPSBbLi4uZXhpc3RpbmcuYWN0aXZpdHlfbG9nLCAuLi5hY3Rpdml0aWVzXTtcbiAgICB9XG5cbiAgICBhd2FpdCBPcGVuU2VhcmNoU2VydmljZS51cGRhdGVEb2N1bWVudChjbGllbnQsIENBU0VfSU5ERVgsIGlkLCB1cGRhdGVEb2MpO1xuXG4gICAgaWYgKHVwZGF0ZURvYy5hc3NpZ25lZSkge1xuICAgICAgYXdhaXQgTm90aWZpY2F0aW9uU2VydmljZS5kaXNwYXRjaChjbGllbnQsIHtcbiAgICAgICAgZXZlbnQ6ICdjYXNlX2Fzc2lnbmVkJyxcbiAgICAgICAgcmVjaXBpZW50czogW3VwZGF0ZURvYy5hc3NpZ25lZV0sXG4gICAgICAgIHRpdGxlOiBgQ2FzZSAke2V4aXN0aW5nLmNhc2VfaWR9IGFzc2lnbmVkIHRvIHlvdWAsXG4gICAgICAgIG1lc3NhZ2U6IGAke3VzZXJ9IGFzc2lnbmVkIHlvdSBcIiR7ZXhpc3RpbmcudGl0bGV9XCIuYCxcbiAgICAgICAgY2FzZVJlZjogeyAuLi5leGlzdGluZywgYXNzaWduZWU6IHVwZGF0ZURvYy5hc3NpZ25lZSB9LFxuICAgICAgICBhY3RvcjogdXNlcixcbiAgICAgIH0pO1xuICAgIH1cbiAgICBpZiAodXBkYXRlRG9jLnByaW9yaXR5KSB7XG4gICAgICBhd2FpdCBOb3RpZmljYXRpb25TZXJ2aWNlLmRpc3BhdGNoKGNsaWVudCwge1xuICAgICAgICBldmVudDogJ3ByaW9yaXR5X2NoYW5nZWQnLFxuICAgICAgICByZWNpcGllbnRzOiBbZXhpc3RpbmcuYXNzaWduZWUsIGV4aXN0aW5nLmNyZWF0ZWRfYnldLFxuICAgICAgICB0aXRsZTogYENhc2UgJHtleGlzdGluZy5jYXNlX2lkfSBwcmlvcml0eSBpcyBub3cgJHt1cGRhdGVEb2MucHJpb3JpdHl9YCxcbiAgICAgICAgbWVzc2FnZTogYCR7dXNlcn0gY2hhbmdlZCB0aGUgcHJpb3JpdHkgZnJvbSAke2V4aXN0aW5nLnByaW9yaXR5fSB0byAke3VwZGF0ZURvYy5wcmlvcml0eX0uYCxcbiAgICAgICAgY2FzZVJlZjogeyAuLi5leGlzdGluZywgcHJpb3JpdHk6IHVwZGF0ZURvYy5wcmlvcml0eSB9LFxuICAgICAgICBhY3RvcjogdXNlcixcbiAgICAgIH0pO1xuICAgIH1cblxuICAgIHJldHVybiBhd2FpdCBDYXNlU2VydmljZS5nZXRDYXNlKGNsaWVudCwgaWQpO1xuICB9XG5cbiAgLyoqIERlbGV0ZSBhIGNhc2UgYnkgT3BlblNlYXJjaCBfaWQgKi9cbiAgc3RhdGljIGFzeW5jIGRlbGV0ZUNhc2UoY2xpZW50OiBhbnksIGlkOiBzdHJpbmcpOiBQcm9taXNlPGJvb2xlYW4+IHtcbiAgICByZXR1cm4gYXdhaXQgT3BlblNlYXJjaFNlcnZpY2UuZGVsZXRlRG9jdW1lbnQoY2xpZW50LCBDQVNFX0lOREVYLCBpZCk7XG4gIH1cblxuICAvKiogTGlzdCBjYXNlcyB3aXRoIGZpbHRlcmluZywgcGFnaW5hdGlvbiwgYW5kIHNvcnRpbmcgKi9cbiAgc3RhdGljIGFzeW5jIGxpc3RDYXNlcyhjbGllbnQ6IGFueSwgcXVlcnk6IENhc2VMaXN0UXVlcnkpOiBQcm9taXNlPENhc2VMaXN0UmVzcG9uc2U+IHtcbiAgICBjb25zdCBwYWdlID0gcXVlcnkucGFnZSB8fCAxO1xuICAgIGNvbnN0IHBlclBhZ2UgPSBNYXRoLm1pbihxdWVyeS5wZXJfcGFnZSB8fCBERUZBVUxUX1BBR0VfU0laRSwgTUFYX1BBR0VfU0laRSk7XG4gICAgY29uc3Qgc29ydEZpZWxkID0gcXVlcnkuc29ydF9maWVsZCB8fCBERUZBVUxUX1NPUlRfRklFTEQ7XG4gICAgY29uc3Qgc29ydE9yZGVyID0gcXVlcnkuc29ydF9vcmRlciB8fCBERUZBVUxUX1NPUlRfT1JERVI7XG5cbiAgICAvLyBCdWlsZCB0aGUgcXVlcnlcbiAgICBjb25zdCBtdXN0OiBhbnlbXSA9IFtdO1xuXG4gICAgaWYgKHF1ZXJ5LnN0YXR1cykge1xuICAgICAgbXVzdC5wdXNoKHsgdGVybTogeyBzdGF0dXM6IHF1ZXJ5LnN0YXR1cyB9IH0pO1xuICAgIH1cbiAgICBpZiAocXVlcnkuc2V2ZXJpdHkpIHtcbiAgICAgIG11c3QucHVzaCh7IHRlcm06IHsgc2V2ZXJpdHk6IHF1ZXJ5LnNldmVyaXR5IH0gfSk7XG4gICAgfVxuICAgIGlmIChxdWVyeS5wcmlvcml0eSkge1xuICAgICAgbXVzdC5wdXNoKHsgdGVybTogeyBwcmlvcml0eTogcXVlcnkucHJpb3JpdHkgfSB9KTtcbiAgICB9XG4gICAgaWYgKHF1ZXJ5LmNhdGVnb3J5KSB7XG4gICAgICBtdXN0LnB1c2goeyB0ZXJtOiB7IGNhdGVnb3J5OiBxdWVyeS5jYXRlZ29yeSB9IH0pO1xuICAgIH1cbiAgICBpZiAocXVlcnkuYXNzaWduZWUpIHtcbiAgICAgIG11c3QucHVzaCh7IHRlcm06IHsgYXNzaWduZWU6IHF1ZXJ5LmFzc2lnbmVlIH0gfSk7XG4gICAgfVxuICAgIGlmIChxdWVyeS50YWdzKSB7XG4gICAgICBjb25zdCB0YWdMaXN0ID0gcXVlcnkudGFncy5zcGxpdCgnLCcpLm1hcCgodCkgPT4gdC50cmltKCkpO1xuICAgICAgbXVzdC5wdXNoKHsgdGVybXM6IHsgdGFnczogdGFnTGlzdCB9IH0pO1xuICAgIH1cbiAgICBpZiAocXVlcnkuc2VhcmNoKSB7XG4gICAgICBtdXN0LnB1c2goe1xuICAgICAgICBtdWx0aV9tYXRjaDoge1xuICAgICAgICAgIHF1ZXJ5OiBxdWVyeS5zZWFyY2gsXG4gICAgICAgICAgZmllbGRzOiBbJ3RpdGxlXjMnLCAnZGVzY3JpcHRpb24nLCAnY2FzZV9pZF4yJywgJ3RhZ3MnXSxcbiAgICAgICAgICB0eXBlOiAnYmVzdF9maWVsZHMnLFxuICAgICAgICAgIGZ1enppbmVzczogJ0FVVE8nLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfVxuICAgIGlmIChxdWVyeS5jcmVhdGVkX2Zyb20gfHwgcXVlcnkuY3JlYXRlZF90bykge1xuICAgICAgY29uc3QgcmFuZ2U6IGFueSA9IHt9O1xuICAgICAgaWYgKHF1ZXJ5LmNyZWF0ZWRfZnJvbSkgcmFuZ2UuZ3RlID0gcXVlcnkuY3JlYXRlZF9mcm9tO1xuICAgICAgaWYgKHF1ZXJ5LmNyZWF0ZWRfdG8pIHJhbmdlLmx0ZSA9IHF1ZXJ5LmNyZWF0ZWRfdG87XG4gICAgICBtdXN0LnB1c2goeyByYW5nZTogeyBjcmVhdGVkX2F0OiByYW5nZSB9IH0pO1xuICAgIH1cblxuICAgIGNvbnN0IHNlYXJjaEJvZHkgPSB7XG4gICAgICBxdWVyeTogbXVzdC5sZW5ndGggPiAwID8geyBib29sOiB7IG11c3QgfSB9IDogeyBtYXRjaF9hbGw6IHt9IH0sXG4gICAgICBzb3J0OiBbeyBbc29ydEZpZWxkXTogeyBvcmRlcjogc29ydE9yZGVyIH0gfV0sXG4gICAgICBmcm9tOiAocGFnZSAtIDEpICogcGVyUGFnZSxcbiAgICAgIHNpemU6IHBlclBhZ2UsXG4gICAgICAvLyBFeGNsdWRlIGhlYXZ5IG5lc3RlZCBmaWVsZHMgZnJvbSBsaXN0aW5nIHRvIGltcHJvdmUgcGVyZlxuICAgICAgX3NvdXJjZToge1xuICAgICAgICBleGNsdWRlczogWydhY3Rpdml0eV9sb2cnLCAnY29tbWVudHMuY29udGVudCddLFxuICAgICAgfSxcbiAgICB9O1xuXG4gICAgY29uc3QgeyBoaXRzLCB0b3RhbCB9ID0gYXdhaXQgT3BlblNlYXJjaFNlcnZpY2Uuc2VhcmNoRG9jdW1lbnRzKGNsaWVudCwgQ0FTRV9JTkRFWCwgc2VhcmNoQm9keSk7XG5cbiAgICBjb25zdCBjYXNlczogQ2FzZVtdID0gaGl0cy5tYXAoKGhpdDogYW55KSA9PiAoe1xuICAgICAgaWQ6IGhpdC5faWQsXG4gICAgICAuLi5oaXQuX3NvdXJjZSxcbiAgICB9KSk7XG5cbiAgICByZXR1cm4geyBjYXNlcywgdG90YWwsIHBhZ2UsIHBlcl9wYWdlOiBwZXJQYWdlIH07XG4gIH1cblxuICAvLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgLy8gU3RhdHVzIE1hbmFnZW1lbnRcbiAgLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbiAgLyoqIENoYW5nZSBjYXNlIHN0YXR1cyB3aXRoIHRyYW5zaXRpb24gdmFsaWRhdGlvbiAqL1xuICBzdGF0aWMgYXN5bmMgY2hhbmdlU3RhdHVzKFxuICAgIGNsaWVudDogYW55LFxuICAgIGlkOiBzdHJpbmcsXG4gICAgbmV3U3RhdHVzOiBDYXNlU3RhdHVzLFxuICAgIHVzZXI6IHN0cmluZyxcbiAgKTogUHJvbWlzZTx7IHN1Y2Nlc3M6IGJvb2xlYW47IGVycm9yPzogc3RyaW5nOyBjYXNlPzogQ2FzZSB9PiB7XG4gICAgY29uc3QgZXhpc3RpbmcgPSBhd2FpdCBDYXNlU2VydmljZS5nZXRDYXNlKGNsaWVudCwgaWQpO1xuICAgIGlmICghZXhpc3RpbmcpIHtcbiAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogJ0Nhc2Ugbm90IGZvdW5kJyB9O1xuICAgIH1cblxuICAgIC8vIFZhbGlkYXRlIHRyYW5zaXRpb25cbiAgICBjb25zdCBhbGxvd2VkVHJhbnNpdGlvbnMgPSBTVEFUVVNfVFJBTlNJVElPTlNbZXhpc3Rpbmcuc3RhdHVzXSB8fCBbXTtcbiAgICBpZiAoIWFsbG93ZWRUcmFuc2l0aW9ucy5pbmNsdWRlcyhuZXdTdGF0dXMpKSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICBzdWNjZXNzOiBmYWxzZSxcbiAgICAgICAgZXJyb3I6IGBDYW5ub3QgdHJhbnNpdGlvbiBmcm9tICcke2V4aXN0aW5nLnN0YXR1c30nIHRvICcke25ld1N0YXR1c30nLiBBbGxvd2VkOiAke2FsbG93ZWRUcmFuc2l0aW9ucy5qb2luKCcsICcpfWAsXG4gICAgICB9O1xuICAgIH1cblxuICAgIGNvbnN0IG5vdyA9IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKTtcbiAgICBjb25zdCB1cGRhdGVEb2M6IGFueSA9IHtcbiAgICAgIHN0YXR1czogbmV3U3RhdHVzLFxuICAgICAgdXBkYXRlZF9hdDogbm93LFxuICAgIH07XG5cbiAgICAvLyBIYW5kbGUgY2xvc2luZ1xuICAgIGlmIChuZXdTdGF0dXMgPT09ICdjbG9zZWQnIHx8IG5ld1N0YXR1cyA9PT0gJ3Jlc29sdmVkJykge1xuICAgICAgdXBkYXRlRG9jLmNsb3NlZF9hdCA9IG5vdztcbiAgICAgIGlmIChleGlzdGluZy5jcmVhdGVkX2F0KSB7XG4gICAgICAgIHVwZGF0ZURvYy50aW1lX3RvX3Jlc29sdmVfbXMgPSBuZXcgRGF0ZShub3cpLmdldFRpbWUoKSAtIG5ldyBEYXRlKGV4aXN0aW5nLmNyZWF0ZWRfYXQpLmdldFRpbWUoKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBIYW5kbGUgcmVvcGVuaW5nXG4gICAgaWYgKG5ld1N0YXR1cyA9PT0gJ29wZW4nICYmIChleGlzdGluZy5zdGF0dXMgPT09ICdjbG9zZWQnIHx8IGV4aXN0aW5nLnN0YXR1cyA9PT0gJ3Jlc29sdmVkJykpIHtcbiAgICAgIHVwZGF0ZURvYy5jbG9zZWRfYXQgPSBudWxsO1xuICAgICAgdXBkYXRlRG9jLnRpbWVfdG9fcmVzb2x2ZV9tcyA9IG51bGw7XG4gICAgfVxuXG4gICAgLy8gQWN0aXZpdHlcbiAgICBjb25zdCBhY3Rpdml0eSA9IENhc2VTZXJ2aWNlLmNyZWF0ZUFjdGl2aXR5KFxuICAgICAgbmV3U3RhdHVzID09PSAnY2xvc2VkJyA/ICdjYXNlX2Nsb3NlZCcgOiBuZXdTdGF0dXMgPT09ICdvcGVuJyAmJiBleGlzdGluZy5zdGF0dXMgPT09ICdjbG9zZWQnID8gJ2Nhc2VfcmVvcGVuZWQnIDogJ3N0YXR1c19jaGFuZ2VkJyxcbiAgICAgIHVzZXIsXG4gICAgICB7IGZyb206IGV4aXN0aW5nLnN0YXR1cywgdG86IG5ld1N0YXR1cyB9LFxuICAgICk7XG4gICAgdXBkYXRlRG9jLmFjdGl2aXR5X2xvZyA9IFsuLi5leGlzdGluZy5hY3Rpdml0eV9sb2csIGFjdGl2aXR5XTtcblxuICAgIGF3YWl0IE9wZW5TZWFyY2hTZXJ2aWNlLnVwZGF0ZURvY3VtZW50KGNsaWVudCwgQ0FTRV9JTkRFWCwgaWQsIHVwZGF0ZURvYyk7XG4gICAgY29uc3QgdXBkYXRlZENhc2UgPSBhd2FpdCBDYXNlU2VydmljZS5nZXRDYXNlKGNsaWVudCwgaWQpO1xuXG4gICAgYXdhaXQgTm90aWZpY2F0aW9uU2VydmljZS5kaXNwYXRjaChjbGllbnQsIHtcbiAgICAgIGV2ZW50OiAnc3RhdHVzX2NoYW5nZWQnLFxuICAgICAgcmVjaXBpZW50czogW2V4aXN0aW5nLmFzc2lnbmVlLCBleGlzdGluZy5jcmVhdGVkX2J5XSxcbiAgICAgIHRpdGxlOiBgQ2FzZSAke2V4aXN0aW5nLmNhc2VfaWR9IGlzIG5vdyAke25ld1N0YXR1cy5yZXBsYWNlKCdfJywgJyAnKX1gLFxuICAgICAgbWVzc2FnZTogYCR7dXNlcn0gbW92ZWQgdGhlIGNhc2UgZnJvbSAke2V4aXN0aW5nLnN0YXR1cy5yZXBsYWNlKCdfJywgJyAnKX0gdG8gJHtuZXdTdGF0dXMucmVwbGFjZSgnXycsICcgJyl9LmAsXG4gICAgICBjYXNlUmVmOiB1cGRhdGVkQ2FzZSB8fCBleGlzdGluZyxcbiAgICAgIGFjdG9yOiB1c2VyLFxuICAgICAgY29udGV4dDogeyBmcm9tOiBleGlzdGluZy5zdGF0dXMsIHRvOiBuZXdTdGF0dXMgfSxcbiAgICB9KTtcblxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUsIGNhc2U6IHVwZGF0ZWRDYXNlISB9O1xuICB9XG5cbiAgLyoqIEFzc2lnbiBhIGNhc2UgdG8gYSB1c2VyICovXG4gIHN0YXRpYyBhc3luYyBhc3NpZ25DYXNlKFxuICAgIGNsaWVudDogYW55LFxuICAgIGlkOiBzdHJpbmcsXG4gICAgYXNzaWduZWU6IHN0cmluZyB8IG51bGwsXG4gICAgdXNlcjogc3RyaW5nLFxuICApOiBQcm9taXNlPENhc2UgfCBudWxsPiB7XG4gICAgY29uc3QgZXhpc3RpbmcgPSBhd2FpdCBDYXNlU2VydmljZS5nZXRDYXNlKGNsaWVudCwgaWQpO1xuICAgIGlmICghZXhpc3RpbmcpIHJldHVybiBudWxsO1xuXG4gICAgY29uc3QgYWN0aXZpdHkgPSBDYXNlU2VydmljZS5jcmVhdGVBY3Rpdml0eShcbiAgICAgIGFzc2lnbmVlID8gJ2Fzc2lnbmVkJyA6ICd1bmFzc2lnbmVkJyxcbiAgICAgIHVzZXIsXG4gICAgICB7IGZyb206IGV4aXN0aW5nLmFzc2lnbmVlLCB0bzogYXNzaWduZWUgfSxcbiAgICApO1xuXG4gICAgYXdhaXQgT3BlblNlYXJjaFNlcnZpY2UudXBkYXRlRG9jdW1lbnQoY2xpZW50LCBDQVNFX0lOREVYLCBpZCwge1xuICAgICAgYXNzaWduZWUsXG4gICAgICB1cGRhdGVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICBhY3Rpdml0eV9sb2c6IFsuLi5leGlzdGluZy5hY3Rpdml0eV9sb2csIGFjdGl2aXR5XSxcbiAgICB9KTtcblxuICAgIGlmIChhc3NpZ25lZSkge1xuICAgICAgYXdhaXQgTm90aWZpY2F0aW9uU2VydmljZS5kaXNwYXRjaChjbGllbnQsIHtcbiAgICAgICAgZXZlbnQ6ICdjYXNlX2Fzc2lnbmVkJyxcbiAgICAgICAgcmVjaXBpZW50czogW2Fzc2lnbmVlXSxcbiAgICAgICAgdGl0bGU6IGBDYXNlICR7ZXhpc3RpbmcuY2FzZV9pZH0gYXNzaWduZWQgdG8geW91YCxcbiAgICAgICAgbWVzc2FnZTogYCR7dXNlcn0gYXNzaWduZWQgeW91IFwiJHtleGlzdGluZy50aXRsZX1cIiAoJHtleGlzdGluZy5wcmlvcml0eX0sICR7ZXhpc3Rpbmcuc2V2ZXJpdHl9KS5gLFxuICAgICAgICBjYXNlUmVmOiB7IC4uLmV4aXN0aW5nLCBhc3NpZ25lZSB9LFxuICAgICAgICBhY3RvcjogdXNlcixcbiAgICAgIH0pO1xuICAgIH1cblxuICAgIHJldHVybiBhd2FpdCBDYXNlU2VydmljZS5nZXRDYXNlKGNsaWVudCwgaWQpO1xuICB9XG5cbiAgLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gIC8vIFRhc2tzXG4gIC8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG4gIC8qKiBBZGQgYSB0YXNrIHRvIGEgY2FzZSAqL1xuICBzdGF0aWMgYXN5bmMgYWRkVGFzayhcbiAgICBjbGllbnQ6IGFueSxcbiAgICBjYXNlSWQ6IHN0cmluZyxcbiAgICBwYXJhbXM6IHsgdGl0bGU6IHN0cmluZzsgYXNzaWduZWRfdG8/OiBzdHJpbmcgfCBudWxsOyBkdWVfZGF0ZT86IHN0cmluZyB8IG51bGwgfSxcbiAgICB1c2VyOiBzdHJpbmcsXG4gICk6IFByb21pc2U8Q2FzZSB8IG51bGw+IHtcbiAgICBjb25zdCBleGlzdGluZyA9IGF3YWl0IENhc2VTZXJ2aWNlLmdldENhc2UoY2xpZW50LCBjYXNlSWQpO1xuICAgIGlmICghZXhpc3RpbmcpIHJldHVybiBudWxsO1xuXG4gICAgY29uc3QgbmV3VGFzazogQ2FzZVRhc2sgPSB7XG4gICAgICB0YXNrX2lkOiB1dWlkKCksXG4gICAgICB0aXRsZTogcGFyYW1zLnRpdGxlLFxuICAgICAgY29tcGxldGVkOiBmYWxzZSxcbiAgICAgIGFzc2lnbmVkX3RvOiBwYXJhbXMuYXNzaWduZWRfdG8gfHwgbnVsbCxcbiAgICAgIGR1ZV9kYXRlOiBwYXJhbXMuZHVlX2RhdGUgfHwgbnVsbCxcbiAgICAgIGNyZWF0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgIGNyZWF0ZWRfYnk6IHVzZXIsXG4gICAgfTtcblxuICAgIGNvbnN0IHVwZGF0ZURvYyA9IHtcbiAgICAgIHRhc2tzOiBbLi4uKGV4aXN0aW5nLnRhc2tzIHx8IFtdKSwgbmV3VGFza10sXG4gICAgICB1cGRhdGVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgfTtcblxuICAgIGF3YWl0IE9wZW5TZWFyY2hTZXJ2aWNlLnVwZGF0ZURvY3VtZW50KGNsaWVudCwgQ0FTRV9JTkRFWCwgY2FzZUlkLCB1cGRhdGVEb2MpO1xuXG4gICAgaWYgKG5ld1Rhc2suYXNzaWduZWRfdG8pIHtcbiAgICAgIGF3YWl0IENhc2VTZXJ2aWNlLm5vdGlmeVRhc2tBc3NpZ25tZW50KGNsaWVudCwgZXhpc3RpbmcsIG5ld1Rhc2ssIHVzZXIpO1xuICAgIH1cblxuICAgIHJldHVybiBhd2FpdCBDYXNlU2VydmljZS5nZXRDYXNlKGNsaWVudCwgY2FzZUlkKTtcbiAgfVxuXG4gIC8qKiBVcGRhdGUgYSB0YXNrJ3MgYXNzaWduZWUsIGR1ZSBkYXRlIG9yIHRpdGxlLiAqL1xuICBzdGF0aWMgYXN5bmMgdXBkYXRlVGFzayhcbiAgICBjbGllbnQ6IGFueSxcbiAgICBjYXNlSWQ6IHN0cmluZyxcbiAgICB0YXNrSWQ6IHN0cmluZyxcbiAgICB1cGRhdGVzOiB7IHRpdGxlPzogc3RyaW5nOyBhc3NpZ25lZF90bz86IHN0cmluZyB8IG51bGw7IGR1ZV9kYXRlPzogc3RyaW5nIHwgbnVsbCB9LFxuICAgIHVzZXI6IHN0cmluZyxcbiAgKTogUHJvbWlzZTxDYXNlIHwgbnVsbD4ge1xuICAgIGNvbnN0IGV4aXN0aW5nID0gYXdhaXQgQ2FzZVNlcnZpY2UuZ2V0Q2FzZShjbGllbnQsIGNhc2VJZCk7XG4gICAgaWYgKCFleGlzdGluZykgcmV0dXJuIG51bGw7XG5cbiAgICBjb25zdCB0YXJnZXQgPSAoZXhpc3RpbmcudGFza3MgfHwgW10pLmZpbmQoKHQ6IGFueSkgPT4gdC50YXNrX2lkID09PSB0YXNrSWQpO1xuICAgIGlmICghdGFyZ2V0KSByZXR1cm4gZXhpc3Rpbmc7XG5cbiAgICBjb25zdCBwcmV2aW91c0Fzc2lnbmVlID0gdGFyZ2V0LmFzc2lnbmVkX3RvIHx8IG51bGw7XG4gICAgY29uc3QgdGFza3MgPSAoZXhpc3RpbmcudGFza3MgfHwgW10pLm1hcCgodDogYW55KSA9PlxuICAgICAgdC50YXNrX2lkID09PSB0YXNrSWQgPyB7IC4uLnQsIC4uLnVwZGF0ZXMgfSA6IHQsXG4gICAgKTtcblxuICAgIGF3YWl0IE9wZW5TZWFyY2hTZXJ2aWNlLnVwZGF0ZURvY3VtZW50KGNsaWVudCwgQ0FTRV9JTkRFWCwgY2FzZUlkLCB7XG4gICAgICB0YXNrcyxcbiAgICAgIHVwZGF0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICB9KTtcblxuICAgIC8vIE9ubHkgbm90aWZ5IHdoZW4gdGhlIGFzc2lnbmVlIGFjdHVhbGx5IGNoYW5nZWQgdG8gc29tZWJvZHkgbmV3LlxuICAgIGNvbnN0IG5leHRBc3NpZ25lZSA9IHVwZGF0ZXMuYXNzaWduZWRfdG8gPT09IHVuZGVmaW5lZCA/IHByZXZpb3VzQXNzaWduZWUgOiB1cGRhdGVzLmFzc2lnbmVkX3RvO1xuICAgIGlmIChuZXh0QXNzaWduZWUgJiYgbmV4dEFzc2lnbmVlICE9PSBwcmV2aW91c0Fzc2lnbmVlKSB7XG4gICAgICBhd2FpdCBDYXNlU2VydmljZS5ub3RpZnlUYXNrQXNzaWdubWVudChcbiAgICAgICAgY2xpZW50LFxuICAgICAgICBleGlzdGluZyxcbiAgICAgICAgeyAuLi50YXJnZXQsIC4uLnVwZGF0ZXMgfSBhcyBDYXNlVGFzayxcbiAgICAgICAgdXNlcixcbiAgICAgICk7XG4gICAgfVxuXG4gICAgcmV0dXJuIGF3YWl0IENhc2VTZXJ2aWNlLmdldENhc2UoY2xpZW50LCBjYXNlSWQpO1xuICB9XG5cbiAgcHJpdmF0ZSBzdGF0aWMgYXN5bmMgbm90aWZ5VGFza0Fzc2lnbm1lbnQoXG4gICAgY2xpZW50OiBhbnksXG4gICAgY2FzZUl0ZW06IENhc2UsXG4gICAgdGFzazogQ2FzZVRhc2ssXG4gICAgYWN0b3I6IHN0cmluZyxcbiAgKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgY29uc3QgZHVlID0gdGFzay5kdWVfZGF0ZSA/IGAgKGR1ZSAke3Rhc2suZHVlX2RhdGV9KWAgOiAnJztcbiAgICBhd2FpdCBOb3RpZmljYXRpb25TZXJ2aWNlLmRpc3BhdGNoKGNsaWVudCwge1xuICAgICAgZXZlbnQ6ICd0YXNrX2Fzc2lnbmVkJyxcbiAgICAgIHJlY2lwaWVudHM6IFt0YXNrLmFzc2lnbmVkX3RvXSxcbiAgICAgIHRpdGxlOiBgVGFzayBhc3NpZ25lZCBvbiAke2Nhc2VJdGVtLmNhc2VfaWR9YCxcbiAgICAgIG1lc3NhZ2U6IGAke2FjdG9yfSBhc3NpZ25lZCB5b3UgXCIke3Rhc2sudGl0bGV9XCIke2R1ZX0uYCxcbiAgICAgIGNhc2VSZWY6IGNhc2VJdGVtLFxuICAgICAgYWN0b3IsXG4gICAgICBjb250ZXh0OiB7IHRhc2tfaWQ6IHRhc2sudGFza19pZCwgdGFza190aXRsZTogdGFzay50aXRsZSwgZHVlX2RhdGU6IHRhc2suZHVlX2RhdGUgfHwgbnVsbCB9LFxuICAgIH0pO1xuICB9XG5cbiAgLyoqIFRvZ2dsZSB0YXNrIGNvbXBsZXRpb24gKi9cbiAgc3RhdGljIGFzeW5jIHRvZ2dsZVRhc2soY2xpZW50OiBhbnksIGNhc2VJZDogc3RyaW5nLCB0YXNrSWQ6IHN0cmluZywgY29tcGxldGVkOiBib29sZWFuLCB1c2VyOiBzdHJpbmcpOiBQcm9taXNlPENhc2UgfCBudWxsPiB7XG4gICAgY29uc3QgZXhpc3RpbmcgPSBhd2FpdCBDYXNlU2VydmljZS5nZXRDYXNlKGNsaWVudCwgY2FzZUlkKTtcbiAgICBpZiAoIWV4aXN0aW5nKSByZXR1cm4gbnVsbDtcblxuICAgIGNvbnN0IHRhc2tzID0gKGV4aXN0aW5nLnRhc2tzIHx8IFtdKS5tYXAoKHQ6IGFueSkgPT5cbiAgICAgIHQudGFza19pZCA9PT0gdGFza0lkXG4gICAgICAgID8ge1xuICAgICAgICAgICAgLi4udCxcbiAgICAgICAgICAgIGNvbXBsZXRlZCxcbiAgICAgICAgICAgIGNvbXBsZXRlZF9hdDogY29tcGxldGVkID8gbmV3IERhdGUoKS50b0lTT1N0cmluZygpIDogbnVsbCxcbiAgICAgICAgICAgIGNvbXBsZXRlZF9ieTogY29tcGxldGVkID8gdXNlciA6IG51bGwsXG4gICAgICAgICAgfVxuICAgICAgICA6IHQsXG4gICAgKTtcblxuICAgIGNvbnN0IHVwZGF0ZURvYyA9IHtcbiAgICAgIHRhc2tzLFxuICAgICAgdXBkYXRlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIH07XG5cbiAgICBhd2FpdCBPcGVuU2VhcmNoU2VydmljZS51cGRhdGVEb2N1bWVudChjbGllbnQsIENBU0VfSU5ERVgsIGNhc2VJZCwgdXBkYXRlRG9jKTtcbiAgICByZXR1cm4gYXdhaXQgQ2FzZVNlcnZpY2UuZ2V0Q2FzZShjbGllbnQsIGNhc2VJZCk7XG4gIH1cblxuICAvKiogUmVtb3ZlIGEgdGFzayAqL1xuICBzdGF0aWMgYXN5bmMgcmVtb3ZlVGFzayhjbGllbnQ6IGFueSwgY2FzZUlkOiBzdHJpbmcsIHRhc2tJZDogc3RyaW5nLCB1c2VyOiBzdHJpbmcpOiBQcm9taXNlPENhc2UgfCBudWxsPiB7XG4gICAgY29uc3QgZXhpc3RpbmcgPSBhd2FpdCBDYXNlU2VydmljZS5nZXRDYXNlKGNsaWVudCwgY2FzZUlkKTtcbiAgICBpZiAoIWV4aXN0aW5nKSByZXR1cm4gbnVsbDtcblxuICAgIGNvbnN0IHRhc2tzID0gKGV4aXN0aW5nLnRhc2tzIHx8IFtdKS5maWx0ZXIoKHQ6IGFueSkgPT4gdC50YXNrX2lkICE9PSB0YXNrSWQpO1xuXG4gICAgY29uc3QgdXBkYXRlRG9jID0ge1xuICAgICAgdGFza3MsXG4gICAgICB1cGRhdGVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgfTtcblxuICAgIGF3YWl0IE9wZW5TZWFyY2hTZXJ2aWNlLnVwZGF0ZURvY3VtZW50KGNsaWVudCwgQ0FTRV9JTkRFWCwgY2FzZUlkLCB1cGRhdGVEb2MpO1xuICAgIHJldHVybiBhd2FpdCBDYXNlU2VydmljZS5nZXRDYXNlKGNsaWVudCwgY2FzZUlkKTtcbiAgfVxuXG4gIC8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICAvLyBOb3Rlc1xuICAvLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuICAvKiogVXBkYXRlIGNhc2Ugbm90ZXMgKi9cbiAgc3RhdGljIGFzeW5jIHVwZGF0ZU5vdGVzKGNsaWVudDogYW55LCBjYXNlSWQ6IHN0cmluZywgbm90ZXM6IHN0cmluZywgdXNlcjogc3RyaW5nKTogUHJvbWlzZTxDYXNlIHwgbnVsbD4ge1xuICAgIGNvbnN0IGV4aXN0aW5nID0gYXdhaXQgQ2FzZVNlcnZpY2UuZ2V0Q2FzZShjbGllbnQsIGNhc2VJZCk7XG4gICAgaWYgKCFleGlzdGluZykgcmV0dXJuIG51bGw7XG5cbiAgICBjb25zdCB1cGRhdGVEb2MgPSB7XG4gICAgICBub3RlcyxcbiAgICAgIHVwZGF0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICB9O1xuXG4gICAgYXdhaXQgT3BlblNlYXJjaFNlcnZpY2UudXBkYXRlRG9jdW1lbnQoY2xpZW50LCBDQVNFX0lOREVYLCBjYXNlSWQsIHVwZGF0ZURvYyk7XG4gICAgcmV0dXJuIGF3YWl0IENhc2VTZXJ2aWNlLmdldENhc2UoY2xpZW50LCBjYXNlSWQpO1xuICB9XG5cbiAgLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gIC8vIENvbW1lbnRzXG4gIC8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG4gIC8qKiBBZGQgYSBjb21tZW50IHRvIGEgY2FzZSAqL1xuICBzdGF0aWMgYXN5bmMgYWRkQ29tbWVudChcbiAgICBjbGllbnQ6IGFueSxcbiAgICBjYXNlSWQ6IHN0cmluZyxcbiAgICBjb250ZW50OiBzdHJpbmcsXG4gICAgdXNlcjogc3RyaW5nLFxuICApOiBQcm9taXNlPENhc2UgfCBudWxsPiB7XG4gICAgY29uc3QgZXhpc3RpbmcgPSBhd2FpdCBDYXNlU2VydmljZS5nZXRDYXNlKGNsaWVudCwgY2FzZUlkKTtcbiAgICBpZiAoIWV4aXN0aW5nKSByZXR1cm4gbnVsbDtcblxuICAgIGNvbnN0IGNvbW1lbnQ6IENhc2VDb21tZW50ID0ge1xuICAgICAgY29tbWVudF9pZDogdXVpZCgpLFxuICAgICAgYXV0aG9yOiB1c2VyLFxuICAgICAgY29udGVudCxcbiAgICAgIGNyZWF0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICB9O1xuXG4gICAgY29uc3QgYWN0aXZpdHkgPSBDYXNlU2VydmljZS5jcmVhdGVBY3Rpdml0eSgnY29tbWVudF9hZGRlZCcsIHVzZXIsIHtcbiAgICAgIGNvbW1lbnRfaWQ6IGNvbW1lbnQuY29tbWVudF9pZCxcbiAgICB9KTtcblxuICAgIGF3YWl0IE9wZW5TZWFyY2hTZXJ2aWNlLnVwZGF0ZURvY3VtZW50KGNsaWVudCwgQ0FTRV9JTkRFWCwgY2FzZUlkLCB7XG4gICAgICBjb21tZW50czogWy4uLmV4aXN0aW5nLmNvbW1lbnRzLCBjb21tZW50XSxcbiAgICAgIGFjdGl2aXR5X2xvZzogWy4uLmV4aXN0aW5nLmFjdGl2aXR5X2xvZywgYWN0aXZpdHldLFxuICAgICAgdXBkYXRlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIH0pO1xuXG4gICAgYXdhaXQgTm90aWZpY2F0aW9uU2VydmljZS5kaXNwYXRjaChjbGllbnQsIHtcbiAgICAgIGV2ZW50OiAnY29tbWVudF9hZGRlZCcsXG4gICAgICByZWNpcGllbnRzOiBbZXhpc3RpbmcuYXNzaWduZWUsIGV4aXN0aW5nLmNyZWF0ZWRfYnldLFxuICAgICAgdGl0bGU6IGBOZXcgY29tbWVudCBvbiAke2V4aXN0aW5nLmNhc2VfaWR9YCxcbiAgICAgIG1lc3NhZ2U6IGAke3VzZXJ9OiAke2NvbnRlbnQuc3Vic3RyaW5nKDAsIDIwMCl9YCxcbiAgICAgIGNhc2VSZWY6IGV4aXN0aW5nLFxuICAgICAgYWN0b3I6IHVzZXIsXG4gICAgfSk7XG5cbiAgICByZXR1cm4gYXdhaXQgQ2FzZVNlcnZpY2UuZ2V0Q2FzZShjbGllbnQsIGNhc2VJZCk7XG4gIH1cblxuICAvKiogRGVsZXRlIGEgY29tbWVudCBmcm9tIGEgY2FzZSAqL1xuICBzdGF0aWMgYXN5bmMgZGVsZXRlQ29tbWVudChcbiAgICBjbGllbnQ6IGFueSxcbiAgICBjYXNlSWQ6IHN0cmluZyxcbiAgICBjb21tZW50SWQ6IHN0cmluZyxcbiAgICB1c2VyOiBzdHJpbmcsXG4gICk6IFByb21pc2U8Q2FzZSB8IG51bGw+IHtcbiAgICBjb25zdCBleGlzdGluZyA9IGF3YWl0IENhc2VTZXJ2aWNlLmdldENhc2UoY2xpZW50LCBjYXNlSWQpO1xuICAgIGlmICghZXhpc3RpbmcpIHJldHVybiBudWxsO1xuXG4gICAgY29uc3QgdXBkYXRlZENvbW1lbnRzID0gZXhpc3RpbmcuY29tbWVudHMuZmlsdGVyKChjKSA9PiBjLmNvbW1lbnRfaWQgIT09IGNvbW1lbnRJZCk7XG4gICAgaWYgKHVwZGF0ZWRDb21tZW50cy5sZW5ndGggPT09IGV4aXN0aW5nLmNvbW1lbnRzLmxlbmd0aCkge1xuICAgICAgcmV0dXJuIGV4aXN0aW5nOyAvLyBDb21tZW50IG5vdCBmb3VuZCwgbm8gY2hhbmdlXG4gICAgfVxuXG4gICAgY29uc3QgYWN0aXZpdHkgPSBDYXNlU2VydmljZS5jcmVhdGVBY3Rpdml0eSgnY29tbWVudF9kZWxldGVkJywgdXNlciwge1xuICAgICAgY29tbWVudF9pZDogY29tbWVudElkLFxuICAgIH0pO1xuXG4gICAgYXdhaXQgT3BlblNlYXJjaFNlcnZpY2UudXBkYXRlRG9jdW1lbnQoY2xpZW50LCBDQVNFX0lOREVYLCBjYXNlSWQsIHtcbiAgICAgIGNvbW1lbnRzOiB1cGRhdGVkQ29tbWVudHMsXG4gICAgICBhY3Rpdml0eV9sb2c6IFsuLi5leGlzdGluZy5hY3Rpdml0eV9sb2csIGFjdGl2aXR5XSxcbiAgICAgIHVwZGF0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICB9KTtcblxuICAgIHJldHVybiBhd2FpdCBDYXNlU2VydmljZS5nZXRDYXNlKGNsaWVudCwgY2FzZUlkKTtcbiAgfVxuXG4gIC8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICAvLyBBbGVydCBMaW5raW5nXG4gIC8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG4gIC8qKiBMaW5rIGFuIGFsZXJ0IHRvIGEgY2FzZSAqL1xuICBzdGF0aWMgYXN5bmMgbGlua0FsZXJ0KFxuICAgIGNsaWVudDogYW55LFxuICAgIGNhc2VJZDogc3RyaW5nLFxuICAgIGFsZXJ0OiBMaW5rZWRBbGVydCxcbiAgICB1c2VyOiBzdHJpbmcsXG4gICk6IFByb21pc2U8Q2FzZSB8IG51bGw+IHtcbiAgICBjb25zdCBleGlzdGluZyA9IGF3YWl0IENhc2VTZXJ2aWNlLmdldENhc2UoY2xpZW50LCBjYXNlSWQpO1xuICAgIGlmICghZXhpc3RpbmcpIHJldHVybiBudWxsO1xuXG4gICAgLy8gQ2hlY2sgZm9yIGR1cGxpY2F0ZVxuICAgIGlmIChleGlzdGluZy5saW5rZWRfYWxlcnRzLnNvbWUoKGEpID0+IGEuYWxlcnRfaWQgPT09IGFsZXJ0LmFsZXJ0X2lkKSkge1xuICAgICAgcmV0dXJuIGV4aXN0aW5nOyAvLyBBbHJlYWR5IGxpbmtlZFxuICAgIH1cblxuICAgIGNvbnN0IGFjdGl2aXR5ID0gQ2FzZVNlcnZpY2UuY3JlYXRlQWN0aXZpdHkoJ2FsZXJ0X2xpbmtlZCcsIHVzZXIsIHtcbiAgICAgIGFsZXJ0X2lkOiBhbGVydC5hbGVydF9pZCxcbiAgICAgIHJ1bGVfZGVzY3JpcHRpb246IGFsZXJ0LnJ1bGVfZGVzY3JpcHRpb24sXG4gICAgfSk7XG5cbiAgICBhd2FpdCBPcGVuU2VhcmNoU2VydmljZS51cGRhdGVEb2N1bWVudChjbGllbnQsIENBU0VfSU5ERVgsIGNhc2VJZCwge1xuICAgICAgbGlua2VkX2FsZXJ0czogWy4uLmV4aXN0aW5nLmxpbmtlZF9hbGVydHMsIGFsZXJ0XSxcbiAgICAgIGFjdGl2aXR5X2xvZzogWy4uLmV4aXN0aW5nLmFjdGl2aXR5X2xvZywgYWN0aXZpdHldLFxuICAgICAgdXBkYXRlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIH0pO1xuXG4gICAgcmV0dXJuIGF3YWl0IENhc2VTZXJ2aWNlLmdldENhc2UoY2xpZW50LCBjYXNlSWQpO1xuICB9XG5cbiAgLyoqIFVubGluayBhbiBhbGVydCBmcm9tIGEgY2FzZSAqL1xuICBzdGF0aWMgYXN5bmMgdW5saW5rQWxlcnQoXG4gICAgY2xpZW50OiBhbnksXG4gICAgY2FzZUlkOiBzdHJpbmcsXG4gICAgYWxlcnRJZDogc3RyaW5nLFxuICAgIHVzZXI6IHN0cmluZyxcbiAgKTogUHJvbWlzZTxDYXNlIHwgbnVsbD4ge1xuICAgIGNvbnN0IGV4aXN0aW5nID0gYXdhaXQgQ2FzZVNlcnZpY2UuZ2V0Q2FzZShjbGllbnQsIGNhc2VJZCk7XG4gICAgaWYgKCFleGlzdGluZykgcmV0dXJuIG51bGw7XG5cbiAgICBjb25zdCB1cGRhdGVkQWxlcnRzID0gZXhpc3RpbmcubGlua2VkX2FsZXJ0cy5maWx0ZXIoKGEpID0+IGEuYWxlcnRfaWQgIT09IGFsZXJ0SWQpO1xuICAgIGNvbnN0IGFjdGl2aXR5ID0gQ2FzZVNlcnZpY2UuY3JlYXRlQWN0aXZpdHkoJ2FsZXJ0X3VubGlua2VkJywgdXNlciwgeyBhbGVydF9pZDogYWxlcnRJZCB9KTtcblxuICAgIGF3YWl0IE9wZW5TZWFyY2hTZXJ2aWNlLnVwZGF0ZURvY3VtZW50KGNsaWVudCwgQ0FTRV9JTkRFWCwgY2FzZUlkLCB7XG4gICAgICBsaW5rZWRfYWxlcnRzOiB1cGRhdGVkQWxlcnRzLFxuICAgICAgYWN0aXZpdHlfbG9nOiBbLi4uZXhpc3RpbmcuYWN0aXZpdHlfbG9nLCBhY3Rpdml0eV0sXG4gICAgICB1cGRhdGVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgfSk7XG5cbiAgICByZXR1cm4gYXdhaXQgQ2FzZVNlcnZpY2UuZ2V0Q2FzZShjbGllbnQsIGNhc2VJZCk7XG4gIH1cblxuICAvKiogU2VhcmNoIFdhenVoIGFsZXJ0cyBpbiBPcGVuU2VhcmNoICovXG4gIHN0YXRpYyBhc3luYyBzZWFyY2hBbGVydHMoXG4gICAgY2xpZW50OiBhbnksXG4gICAgcXVlcnk6IFdhenVoQWxlcnRTZWFyY2hRdWVyeSxcbiAgKTogUHJvbWlzZTx7IGhpdHM6IGFueVtdOyB0b3RhbDogbnVtYmVyIH0+IHtcbiAgICBjb25zdCBtdXN0OiBhbnlbXSA9IFtdO1xuXG4gICAgaWYgKHF1ZXJ5LnNlYXJjaCkge1xuICAgICAgbXVzdC5wdXNoKHtcbiAgICAgICAgbXVsdGlfbWF0Y2g6IHtcbiAgICAgICAgICBxdWVyeTogcXVlcnkuc2VhcmNoLFxuICAgICAgICAgIGZpZWxkczogWydydWxlLmRlc2NyaXB0aW9uXjInLCAnZnVsbF9sb2cnLCAnZGF0YS4qJ10sXG4gICAgICAgICAgZnV6emluZXNzOiAnQVVUTycsXG4gICAgICAgICAgLy8gZGF0YS4qIHNwYW5zIG5vbi10ZXh0IGZpZWxkcyAoZGF0ZS9pcC9udW1iZXIpOyBsZW5pZW50IHNraXBzIHRoZW1cbiAgICAgICAgICAvLyBpbnN0ZWFkIG9mIHRocm93aW5nIHF1ZXJ5X3NoYXJkX2V4Y2VwdGlvbiAoNDAwIEJhZCBSZXF1ZXN0KS5cbiAgICAgICAgICBsZW5pZW50OiB0cnVlLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfVxuICAgIGlmIChxdWVyeS5hZ2VudF9pZCkge1xuICAgICAgbXVzdC5wdXNoKHsgdGVybTogeyAnYWdlbnQuaWQnOiBxdWVyeS5hZ2VudF9pZCB9IH0pO1xuICAgIH1cbiAgICBpZiAocXVlcnkucnVsZV9pZCkge1xuICAgICAgbXVzdC5wdXNoKHsgdGVybTogeyAncnVsZS5pZCc6IFN0cmluZyhxdWVyeS5ydWxlX2lkKSB9IH0pO1xuICAgIH1cbiAgICBpZiAocXVlcnkubGV2ZWxfbWluIHx8IHF1ZXJ5LmxldmVsX21heCkge1xuICAgICAgY29uc3QgcmFuZ2U6IGFueSA9IHt9O1xuICAgICAgaWYgKHF1ZXJ5LmxldmVsX21pbikgcmFuZ2UuZ3RlID0gcXVlcnkubGV2ZWxfbWluO1xuICAgICAgaWYgKHF1ZXJ5LmxldmVsX21heCkgcmFuZ2UubHRlID0gcXVlcnkubGV2ZWxfbWF4O1xuICAgICAgbXVzdC5wdXNoKHsgcmFuZ2U6IHsgJ3J1bGUubGV2ZWwnOiByYW5nZSB9IH0pO1xuICAgIH1cbiAgICBpZiAocXVlcnkuZnJvbSB8fCBxdWVyeS50bykge1xuICAgICAgY29uc3QgcmFuZ2U6IGFueSA9IHt9O1xuICAgICAgaWYgKHF1ZXJ5LmZyb20pIHJhbmdlLmd0ZSA9IHF1ZXJ5LmZyb207XG4gICAgICBpZiAocXVlcnkudG8pIHJhbmdlLmx0ZSA9IHF1ZXJ5LnRvO1xuICAgICAgbXVzdC5wdXNoKHsgcmFuZ2U6IHsgdGltZXN0YW1wOiByYW5nZSB9IH0pO1xuICAgIH1cblxuICAgIGNvbnN0IHNlYXJjaEJvZHkgPSB7XG4gICAgICBxdWVyeTogbXVzdC5sZW5ndGggPiAwID8geyBib29sOiB7IG11c3QgfSB9IDogeyBtYXRjaF9hbGw6IHt9IH0sXG4gICAgICBzb3J0OiBbeyB0aW1lc3RhbXA6IHsgb3JkZXI6ICdkZXNjJyB9IH1dLFxuICAgICAgc2l6ZTogTWF0aC5taW4ocXVlcnkuc2l6ZSB8fCA1MCwgMTAwKSxcbiAgICB9O1xuXG4gICAgcmV0dXJuIGF3YWl0IE9wZW5TZWFyY2hTZXJ2aWNlLnNlYXJjaERvY3VtZW50cyhjbGllbnQsIFdBWlVIX0FMRVJUU19JTkRFWF9QQVRURVJOLCBzZWFyY2hCb2R5KTtcbiAgfVxuXG4gIC8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICAvLyBPYnNlcnZhYmxlc1xuICAvLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuICAvKiogQWRkIGFuIG9ic2VydmFibGUgdG8gYSBjYXNlICovXG4gIHN0YXRpYyBhc3luYyBhZGRPYnNlcnZhYmxlKFxuICAgIGNsaWVudDogYW55LFxuICAgIGNhc2VJZDogc3RyaW5nLFxuICAgIG9ic2VydmFibGU6IE9taXQ8T2JzZXJ2YWJsZSwgJ2lkJyB8ICdhZGRlZF9hdCcgfCAnYWRkZWRfYnknPixcbiAgICB1c2VyOiBzdHJpbmcsXG4gICk6IFByb21pc2U8Q2FzZSB8IG51bGw+IHtcbiAgICBjb25zdCBleGlzdGluZyA9IGF3YWl0IENhc2VTZXJ2aWNlLmdldENhc2UoY2xpZW50LCBjYXNlSWQpO1xuICAgIGlmICghZXhpc3RpbmcpIHJldHVybiBudWxsO1xuXG4gICAgY29uc3QgbmV3T2JzZXJ2YWJsZTogT2JzZXJ2YWJsZSA9IHtcbiAgICAgIC4uLm9ic2VydmFibGUsXG4gICAgICBpZDogdXVpZCgpLFxuICAgICAgYWRkZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgIGFkZGVkX2J5OiB1c2VyLFxuICAgIH07XG5cbiAgICBjb25zdCBhY3Rpdml0eSA9IENhc2VTZXJ2aWNlLmNyZWF0ZUFjdGl2aXR5KCdvYnNlcnZhYmxlX2FkZGVkJywgdXNlciwge1xuICAgICAgdHlwZTogb2JzZXJ2YWJsZS50eXBlLFxuICAgICAgdmFsdWU6IG9ic2VydmFibGUudmFsdWUsXG4gICAgfSk7XG5cbiAgICBhd2FpdCBPcGVuU2VhcmNoU2VydmljZS51cGRhdGVEb2N1bWVudChjbGllbnQsIENBU0VfSU5ERVgsIGNhc2VJZCwge1xuICAgICAgb2JzZXJ2YWJsZXM6IFsuLi5leGlzdGluZy5vYnNlcnZhYmxlcywgbmV3T2JzZXJ2YWJsZV0sXG4gICAgICBhY3Rpdml0eV9sb2c6IFsuLi5leGlzdGluZy5hY3Rpdml0eV9sb2csIGFjdGl2aXR5XSxcbiAgICAgIHVwZGF0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICB9KTtcblxuICAgIHJldHVybiBhd2FpdCBDYXNlU2VydmljZS5nZXRDYXNlKGNsaWVudCwgY2FzZUlkKTtcbiAgfVxuXG4gIC8qKiBSZW1vdmUgYW4gb2JzZXJ2YWJsZSBmcm9tIGEgY2FzZSAqL1xuICBzdGF0aWMgYXN5bmMgcmVtb3ZlT2JzZXJ2YWJsZShcbiAgICBjbGllbnQ6IGFueSxcbiAgICBjYXNlSWQ6IHN0cmluZyxcbiAgICBvYnNlcnZhYmxlSWQ6IHN0cmluZyxcbiAgICB1c2VyOiBzdHJpbmcsXG4gICk6IFByb21pc2U8Q2FzZSB8IG51bGw+IHtcbiAgICBjb25zdCBleGlzdGluZyA9IGF3YWl0IENhc2VTZXJ2aWNlLmdldENhc2UoY2xpZW50LCBjYXNlSWQpO1xuICAgIGlmICghZXhpc3RpbmcpIHJldHVybiBudWxsO1xuXG4gICAgY29uc3QgdXBkYXRlZCA9IGV4aXN0aW5nLm9ic2VydmFibGVzLmZpbHRlcigobykgPT4gby5pZCAhPT0gb2JzZXJ2YWJsZUlkKTtcbiAgICBjb25zdCBhY3Rpdml0eSA9IENhc2VTZXJ2aWNlLmNyZWF0ZUFjdGl2aXR5KCdvYnNlcnZhYmxlX3JlbW92ZWQnLCB1c2VyLCB7XG4gICAgICBvYnNlcnZhYmxlX2lkOiBvYnNlcnZhYmxlSWQsXG4gICAgfSk7XG5cbiAgICBhd2FpdCBPcGVuU2VhcmNoU2VydmljZS51cGRhdGVEb2N1bWVudChjbGllbnQsIENBU0VfSU5ERVgsIGNhc2VJZCwge1xuICAgICAgb2JzZXJ2YWJsZXM6IHVwZGF0ZWQsXG4gICAgICBhY3Rpdml0eV9sb2c6IFsuLi5leGlzdGluZy5hY3Rpdml0eV9sb2csIGFjdGl2aXR5XSxcbiAgICAgIHVwZGF0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICB9KTtcblxuICAgIHJldHVybiBhd2FpdCBDYXNlU2VydmljZS5nZXRDYXNlKGNsaWVudCwgY2FzZUlkKTtcbiAgfVxuXG4gIC8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICAvLyBBbmFseXRpY3NcbiAgLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbiAgLyoqIEdldCBzdW1tYXJ5IGFuYWx5dGljcyBmb3IgdGhlIGRhc2hib2FyZCAqL1xuICBzdGF0aWMgYXN5bmMgZ2V0QW5hbHl0aWNzU3VtbWFyeShjbGllbnQ6IGFueSk6IFByb21pc2U8QW5hbHl0aWNzU3VtbWFyeT4ge1xuICAgIHRyeSB7XG4gICAgICAvLyBTZWxmLWhlYWw6IGlmIHRoZSBpbmRleCB3YXMgZGVsZXRlZCwgcmVjcmVhdGUgaXQgd2l0aCB0aGUgY29ycmVjdCBtYXBwaW5nXG4gICAgICAvLyAoa2V5d29yZCBmaWVsZHMpIHNvIGFnZ3JlZ2F0aW9ucyBkb24ndCBmYWlsIHdpdGggYSA0MDAuXG4gICAgICBhd2FpdCBPcGVuU2VhcmNoU2VydmljZS5lbnN1cmVJbmRleChjbGllbnQsIENBU0VfSU5ERVgsIGNhc2VNYXBwaW5ncyk7XG4gICAgICByZXR1cm4gYXdhaXQgQ2FzZVNlcnZpY2UuY29tcHV0ZUFuYWx5dGljc1N1bW1hcnkoY2xpZW50KTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICAvLyBOZXZlciBzdXJmYWNlIGEgcmF3IDQwMC9hZ2dyZWdhdGlvbiBlcnJvciB0byB0aGUgZGFzaGJvYXJkLiBSZXR1cm4gYW5cbiAgICAgIC8vIGVtcHR5IHN1bW1hcnkgc28gdGhlIFVJIHNob3dzIGFuIGVtcHR5IHN0YXRlIGluc3RlYWQgb2YgXCJCYWQgUmVxdWVzdFwiLlxuICAgICAgcmV0dXJuIGVtcHR5QW5hbHl0aWNzU3VtbWFyeSgpO1xuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgc3RhdGljIGFzeW5jIGNvbXB1dGVBbmFseXRpY3NTdW1tYXJ5KGNsaWVudDogYW55KTogUHJvbWlzZTxBbmFseXRpY3NTdW1tYXJ5PiB7XG4gICAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpO1xuICAgIHRvZGF5LnNldEhvdXJzKDAsIDAsIDAsIDApO1xuICAgIGNvbnN0IHRvZGF5U3RyID0gdG9kYXkudG9JU09TdHJpbmcoKTtcblxuICAgIGNvbnN0IGFnZ3MgPSBhd2FpdCBPcGVuU2VhcmNoU2VydmljZS5hZ2dyZWdhdGVEb2N1bWVudHMoY2xpZW50LCBDQVNFX0lOREVYLCB7XG4gICAgICBhZ2dzOiB7XG4gICAgICAgIGJ5X3N0YXR1czogeyB0ZXJtczogeyBmaWVsZDogJ3N0YXR1cycsIHNpemU6IDEwIH0gfSxcbiAgICAgICAgYnlfc2V2ZXJpdHk6IHsgdGVybXM6IHsgZmllbGQ6ICdzZXZlcml0eScsIHNpemU6IDEwIH0gfSxcbiAgICAgICAgYnlfcHJpb3JpdHk6IHsgdGVybXM6IHsgZmllbGQ6ICdwcmlvcml0eScsIHNpemU6IDEwIH0gfSxcbiAgICAgICAgYnlfY2F0ZWdvcnk6IHsgdGVybXM6IHsgZmllbGQ6ICdjYXRlZ29yeScsIHNpemU6IDIwIH0gfSxcbiAgICAgICAgYXZnX3Jlc29sdXRpb25fdGltZTogeyBhdmc6IHsgZmllbGQ6ICd0aW1lX3RvX3Jlc29sdmVfbXMnIH0gfSxcbiAgICAgICAgY3JlYXRlZF90b2RheToge1xuICAgICAgICAgIGZpbHRlcjogeyByYW5nZTogeyBjcmVhdGVkX2F0OiB7IGd0ZTogdG9kYXlTdHIgfSB9IH0sXG4gICAgICAgIH0sXG4gICAgICAgIGNsb3NlZF90b2RheToge1xuICAgICAgICAgIGZpbHRlcjoge1xuICAgICAgICAgICAgYm9vbDoge1xuICAgICAgICAgICAgICBtdXN0OiBbXG4gICAgICAgICAgICAgICAgeyByYW5nZTogeyBjbG9zZWRfYXQ6IHsgZ3RlOiB0b2RheVN0ciB9IH0gfSxcbiAgICAgICAgICAgICAgICB7IHRlcm1zOiB7IHN0YXR1czogWydyZXNvbHZlZCcsICdjbG9zZWQnXSB9IH0sXG4gICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICAgIHRvdGFsOiB7IHZhbHVlX2NvdW50OiB7IGZpZWxkOiAnY2FzZV9pZCcgfSB9LFxuICAgICAgfSxcbiAgICB9KTtcblxuICAgIC8vIFBhcnNlIHN0YXR1cyBjb3VudHNcbiAgICBjb25zdCBzdGF0dXNDb3VudHM6IFJlY29yZDxzdHJpbmcsIG51bWJlcj4gPSB7fTtcbiAgICAoYWdncy5ieV9zdGF0dXM/LmJ1Y2tldHMgfHwgW10pLmZvckVhY2goKGI6IGFueSkgPT4ge1xuICAgICAgc3RhdHVzQ291bnRzW2Iua2V5XSA9IGIuZG9jX2NvdW50O1xuICAgIH0pO1xuXG4gICAgLy8gUGFyc2Ugc2V2ZXJpdHkgY291bnRzXG4gICAgY29uc3Qgc2V2ZXJpdHlDb3VudHM6IFJlY29yZDxzdHJpbmcsIG51bWJlcj4gPSB7fTtcbiAgICAoYWdncy5ieV9zZXZlcml0eT8uYnVja2V0cyB8fCBbXSkuZm9yRWFjaCgoYjogYW55KSA9PiB7XG4gICAgICBzZXZlcml0eUNvdW50c1tiLmtleV0gPSBiLmRvY19jb3VudDtcbiAgICB9KTtcblxuICAgIC8vIFBhcnNlIHByaW9yaXR5IGNvdW50c1xuICAgIGNvbnN0IHByaW9yaXR5Q291bnRzOiBSZWNvcmQ8c3RyaW5nLCBudW1iZXI+ID0ge307XG4gICAgKGFnZ3MuYnlfcHJpb3JpdHk/LmJ1Y2tldHMgfHwgW10pLmZvckVhY2goKGI6IGFueSkgPT4ge1xuICAgICAgcHJpb3JpdHlDb3VudHNbYi5rZXldID0gYi5kb2NfY291bnQ7XG4gICAgfSk7XG5cbiAgICAvLyBQYXJzZSBjYXRlZ29yeSBjb3VudHNcbiAgICBjb25zdCBjYXRlZ29yeUNvdW50czogUmVjb3JkPHN0cmluZywgbnVtYmVyPiA9IHt9O1xuICAgIChhZ2dzLmJ5X2NhdGVnb3J5Py5idWNrZXRzIHx8IFtdKS5mb3JFYWNoKChiOiBhbnkpID0+IHtcbiAgICAgIGNhdGVnb3J5Q291bnRzW2Iua2V5XSA9IGIuZG9jX2NvdW50O1xuICAgIH0pO1xuXG4gICAgY29uc3QgdG90YWxDYXNlcyA9IGFnZ3MudG90YWw/LnZhbHVlIHx8IDA7XG5cbiAgICByZXR1cm4ge1xuICAgICAgdG90YWxfY2FzZXM6IHRvdGFsQ2FzZXMsXG4gICAgICBvcGVuX2Nhc2VzOiBzdGF0dXNDb3VudHNbJ29wZW4nXSB8fCAwLFxuICAgICAgaW5fcHJvZ3Jlc3NfY2FzZXM6IHN0YXR1c0NvdW50c1snaW5fcHJvZ3Jlc3MnXSB8fCAwLFxuICAgICAgd2FpdGluZ19jYXNlczogc3RhdHVzQ291bnRzWyd3YWl0aW5nJ10gfHwgMCxcbiAgICAgIHJlc29sdmVkX2Nhc2VzOiBzdGF0dXNDb3VudHNbJ3Jlc29sdmVkJ10gfHwgMCxcbiAgICAgIGNsb3NlZF9jYXNlczogc3RhdHVzQ291bnRzWydjbG9zZWQnXSB8fCAwLFxuICAgICAgYnlfc2V2ZXJpdHk6IHNldmVyaXR5Q291bnRzIGFzIGFueSxcbiAgICAgIGJ5X3ByaW9yaXR5OiBwcmlvcml0eUNvdW50cyBhcyBhbnksXG4gICAgICBieV9jYXRlZ29yeTogY2F0ZWdvcnlDb3VudHMsXG4gICAgICBhdmdfcmVzb2x1dGlvbl90aW1lX21zOiBhZ2dzLmF2Z19yZXNvbHV0aW9uX3RpbWU/LnZhbHVlIHx8IG51bGwsXG4gICAgICBjYXNlc19jcmVhdGVkX3RvZGF5OiBhZ2dzLmNyZWF0ZWRfdG9kYXk/LmRvY19jb3VudCB8fCAwLFxuICAgICAgY2FzZXNfY2xvc2VkX3RvZGF5OiBhZ2dzLmNsb3NlZF90b2RheT8uZG9jX2NvdW50IHx8IDAsXG4gICAgfTtcbiAgfVxuXG4gIC8qKiBHZXQgY2FzZSB0cmVuZHMgb3ZlciB0aGUgbGFzdCBOIGRheXMgKi9cbiAgc3RhdGljIGFzeW5jIGdldENhc2VUcmVuZHMoY2xpZW50OiBhbnksIGRheXM6IG51bWJlciA9IDMwKTogUHJvbWlzZTxDYXNlVHJlbmRbXT4ge1xuICAgIGNvbnN0IGZyb21EYXRlID0gbmV3IERhdGUoKTtcbiAgICBmcm9tRGF0ZS5zZXREYXRlKGZyb21EYXRlLmdldERhdGUoKSAtIGRheXMpO1xuXG4gICAgY29uc3QgYWdncyA9IGF3YWl0IE9wZW5TZWFyY2hTZXJ2aWNlLmFnZ3JlZ2F0ZURvY3VtZW50cyhjbGllbnQsIENBU0VfSU5ERVgsIHtcbiAgICAgIHF1ZXJ5OiB7XG4gICAgICAgIHJhbmdlOiB7IGNyZWF0ZWRfYXQ6IHsgZ3RlOiBmcm9tRGF0ZS50b0lTT1N0cmluZygpIH0gfSxcbiAgICAgIH0sXG4gICAgICBhZ2dzOiB7XG4gICAgICAgIGNhc2VzX292ZXJfdGltZToge1xuICAgICAgICAgIGRhdGVfaGlzdG9ncmFtOiB7XG4gICAgICAgICAgICBmaWVsZDogJ2NyZWF0ZWRfYXQnLFxuICAgICAgICAgICAgY2FsZW5kYXJfaW50ZXJ2YWw6ICdkYXknLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICAgIGNsb3NlZF9vdmVyX3RpbWU6IHtcbiAgICAgICAgICBmaWx0ZXI6IHsgZXhpc3RzOiB7IGZpZWxkOiAnY2xvc2VkX2F0JyB9IH0sXG4gICAgICAgICAgYWdnczoge1xuICAgICAgICAgICAgYnlfZGF5OiB7XG4gICAgICAgICAgICAgIGRhdGVfaGlzdG9ncmFtOiB7XG4gICAgICAgICAgICAgICAgZmllbGQ6ICdjbG9zZWRfYXQnLFxuICAgICAgICAgICAgICAgIGNhbGVuZGFyX2ludGVydmFsOiAnZGF5JyxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgfSk7XG5cbiAgICBjb25zdCBjcmVhdGVkQnVja2V0cyA9IGFnZ3MuY2FzZXNfb3Zlcl90aW1lPy5idWNrZXRzIHx8IFtdO1xuICAgIGNvbnN0IGNsb3NlZEJ1Y2tldHMgPSBhZ2dzLmNsb3NlZF9vdmVyX3RpbWU/LmJ5X2RheT8uYnVja2V0cyB8fCBbXTtcblxuICAgIC8vIE1lcmdlIGNyZWF0ZWQgYW5kIGNsb3NlZCBpbnRvIGEgc2luZ2xlIHRpbWVsaW5lXG4gICAgY29uc3QgY2xvc2VkTWFwOiBSZWNvcmQ8c3RyaW5nLCBudW1iZXI+ID0ge307XG4gICAgY2xvc2VkQnVja2V0cy5mb3JFYWNoKChiOiBhbnkpID0+IHtcbiAgICAgIGNvbnN0IGRhdGVLZXkgPSBiLmtleV9hc19zdHJpbmc/LnNwbGl0KCdUJylbMF0gfHwgJyc7XG4gICAgICBjbG9zZWRNYXBbZGF0ZUtleV0gPSBiLmRvY19jb3VudDtcbiAgICB9KTtcblxuICAgIHJldHVybiBjcmVhdGVkQnVja2V0cy5tYXAoKGI6IGFueSkgPT4ge1xuICAgICAgY29uc3QgZGF0ZUtleSA9IGIua2V5X2FzX3N0cmluZz8uc3BsaXQoJ1QnKVswXSB8fCAnJztcbiAgICAgIHJldHVybiB7XG4gICAgICAgIGRhdGU6IGRhdGVLZXksXG4gICAgICAgIGNyZWF0ZWQ6IGIuZG9jX2NvdW50LFxuICAgICAgICBjbG9zZWQ6IGNsb3NlZE1hcFtkYXRlS2V5XSB8fCAwLFxuICAgICAgfTtcbiAgICB9KTtcbiAgfVxuXG4gIC8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICAvLyBBdXRvbWF0ZWQgQWxlcnQgSGFuZGxpbmcgKFdlYmhvb2tzKVxuICAvLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuICAvKipcbiAgICogUHJvY2VzcyBhbiBpbmNvbWluZyBhbGVydCBmcm9tIGEgV2F6dWggd2ViaG9vay5cbiAgICogUGVyZm9ybXMgZGVkdXBsaWNhdGlvbiBiYXNlZCBvbiBydWxlLmlkIGFuZCBhZ2VudC5pZCBmb3IgdW5yZXNvbHZlZCBjYXNlcy5cbiAgICovXG4gIHN0YXRpYyBhc3luYyBoYW5kbGVBdXRvbWF0ZWRBbGVydChjbGllbnQ6IGFueSwgYWxlcnQ6IGFueSwgdXNlcjogc3RyaW5nKTogUHJvbWlzZTxDYXNlIHwgbnVsbD4ge1xuICAgIGNvbnN0IHJ1bGVJZCA9IGFsZXJ0LnJ1bGU/LmlkO1xuICAgIGNvbnN0IGFnZW50SWQgPSBhbGVydC5hZ2VudD8uaWQ7XG4gICAgY29uc3QgYWxlcnRJZCA9IGFsZXJ0LmlkO1xuXG4gICAgaWYgKCFydWxlSWQgfHwgIWFnZW50SWQgfHwgIWFsZXJ0SWQpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignSW52YWxpZCBhbGVydCBwYXlsb2FkOiBNaXNzaW5nIHJ1bGUuaWQsIGFnZW50LmlkLCBvciBpZCcpO1xuICAgIH1cblxuICAgIGNvbnN0IGxpbmtlZEFsZXJ0OiBMaW5rZWRBbGVydCA9IHtcbiAgICAgIGFsZXJ0X2lkOiBhbGVydElkLFxuICAgICAgaW5kZXg6IGFsZXJ0Ll9pbmRleCB8fCAnd2F6dWgtYWxlcnRzLSonLFxuICAgICAgcnVsZV9pZDogcGFyc2VJbnQocnVsZUlkLCAxMCksXG4gICAgICBydWxlX2Rlc2NyaXB0aW9uOiBhbGVydC5ydWxlPy5kZXNjcmlwdGlvbiB8fCAnVW5rbm93biBSdWxlJyxcbiAgICAgIHJ1bGVfbGV2ZWw6IGFsZXJ0LnJ1bGU/LmxldmVsIHx8IDAsXG4gICAgICBydWxlX2dyb3VwczogYWxlcnQucnVsZT8uZ3JvdXBzIHx8IFtdLFxuICAgICAgYWdlbnRfaWQ6IGFnZW50SWQsXG4gICAgICBhZ2VudF9uYW1lOiBhbGVydC5hZ2VudD8ubmFtZSB8fCAnVW5rbm93biBBZ2VudCcsXG4gICAgICB0aW1lc3RhbXA6IGFsZXJ0LnRpbWVzdGFtcCB8fCBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICBmdWxsX2xvZzogYWxlcnQuZnVsbF9sb2csXG4gICAgfTtcblxuICAgIC8vIFNlYXJjaCBmb3IgYW4gdW5yZXNvbHZlZCBjYXNlIHdpdGggdGhlIGV4YWN0IHNhbWUgcnVsZSBhbmQgYWdlbnRcbiAgICBjb25zdCBzZWFyY2hCb2R5ID0ge1xuICAgICAgcXVlcnk6IHtcbiAgICAgICAgYm9vbDoge1xuICAgICAgICAgIG11c3Q6IFtcbiAgICAgICAgICAgIHsgdGVybXM6IHsgc3RhdHVzOiBbJ29wZW4nLCAnaW5fcHJvZ3Jlc3MnLCAnd2FpdGluZyddIH0gfSxcbiAgICAgICAgICAgIHsgdGVybTogeyAnY3VzdG9tX2ZpZWxkcy5hdXRvbWF0ZWRfcnVsZV9pZC5rZXl3b3JkJzogU3RyaW5nKHJ1bGVJZCkgfSB9LFxuICAgICAgICAgICAgeyB0ZXJtOiB7ICdjdXN0b21fZmllbGRzLmF1dG9tYXRlZF9hZ2VudF9pZC5rZXl3b3JkJzogU3RyaW5nKGFnZW50SWQpIH0gfVxuICAgICAgICAgIF1cbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIHNpemU6IDEsXG4gICAgICBzb3J0OiBbeyBjcmVhdGVkX2F0OiB7IG9yZGVyOiAnZGVzYycgfSB9XVxuICAgIH07XG5cbiAgICBjb25zdCBzZWFyY2hSZXN1bHQgPSBhd2FpdCBPcGVuU2VhcmNoU2VydmljZS5zZWFyY2hEb2N1bWVudHMoY2xpZW50LCBDQVNFX0lOREVYLCBzZWFyY2hCb2R5KTtcbiAgICBcbiAgICAvLyBJRiBEVVBMSUNBVEUgRk9VTkQ6IEFwcGVuZCBhbGVydCBhbmQgYWRkIGNvbW1lbnRcbiAgICBpZiAoc2VhcmNoUmVzdWx0LmhpdHMubGVuZ3RoID4gMCkge1xuICAgICAgY29uc3QgZXhpc3RpbmdDYXNlID0gc2VhcmNoUmVzdWx0LmhpdHNbMF07XG4gICAgICBjb25zdCBjYXNlSWQgPSBleGlzdGluZ0Nhc2UuX2lkO1xuICAgICAgXG4gICAgICAvLyBBdm9pZCBsaW5raW5nIHRoZSBleGFjdCBzYW1lIGFsZXJ0IHR3aWNlXG4gICAgICBjb25zdCBhbHJlYWR5TGlua2VkID0gZXhpc3RpbmdDYXNlLl9zb3VyY2UubGlua2VkX2FsZXJ0cy5zb21lKChhOiBhbnkpID0+IGEuYWxlcnRfaWQgPT09IGFsZXJ0SWQpO1xuICAgICAgaWYgKGFscmVhZHlMaW5rZWQpIHtcbiAgICAgICAgIHJldHVybiB7IGlkOiBjYXNlSWQsIC4uLmV4aXN0aW5nQ2FzZS5fc291cmNlIH0gYXMgQ2FzZTtcbiAgICAgIH1cblxuICAgICAgLy8gQWRkIGF1dG9tYXRlZCBjb21tZW50XG4gICAgICBjb25zdCBjb21tZW50SWQgPSB1dWlkKCk7XG4gICAgICBjb25zdCBjb21tZW50OiBDYXNlQ29tbWVudCA9IHtcbiAgICAgICAgY29tbWVudF9pZDogY29tbWVudElkLFxuICAgICAgICBhdXRob3I6ICdTeXN0ZW0gQXV0b21hdGlvbicsXG4gICAgICAgIGNvbnRlbnQ6IGBEdXBsaWNhdGUgYWxlcnQgZGV0ZWN0ZWQgKFJ1bGUgJHtydWxlSWR9IG9uIEFnZW50ICR7YWdlbnRJZH0pLiBBdXRvbWF0aWNhbGx5IGxpbmtlZC5gLFxuICAgICAgICBjcmVhdGVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICB9O1xuXG4gICAgICBjb25zdCB1cGRhdGVEb2MgPSB7XG4gICAgICAgIGxpbmtlZF9hbGVydHM6IFsuLi5leGlzdGluZ0Nhc2UuX3NvdXJjZS5saW5rZWRfYWxlcnRzLCBsaW5rZWRBbGVydF0sXG4gICAgICAgIGNvbW1lbnRzOiBbLi4uZXhpc3RpbmdDYXNlLl9zb3VyY2UuY29tbWVudHMsIGNvbW1lbnRdLFxuICAgICAgICB1cGRhdGVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICB9O1xuXG4gICAgICBhd2FpdCBPcGVuU2VhcmNoU2VydmljZS51cGRhdGVEb2N1bWVudChjbGllbnQsIENBU0VfSU5ERVgsIGNhc2VJZCwgdXBkYXRlRG9jKTtcbiAgICAgIHJldHVybiBhd2FpdCBDYXNlU2VydmljZS5nZXRDYXNlKGNsaWVudCwgY2FzZUlkKTtcbiAgICB9XG5cbiAgICAvLyBJRiBOTyBEVVBMSUNBVEU6IENyZWF0ZSBuZXcgY2FzZVxuICAgIGxldCBzZXZlcml0eTogQ2FzZVNldmVyaXR5ID0gJ2xvdyc7XG4gICAgY29uc3QgbGV2ZWwgPSBhbGVydC5ydWxlPy5sZXZlbCB8fCAwO1xuICAgIGlmIChsZXZlbCA+PSAxMikgc2V2ZXJpdHkgPSAnY3JpdGljYWwnO1xuICAgIGVsc2UgaWYgKGxldmVsID49IDgpIHNldmVyaXR5ID0gJ2hpZ2gnO1xuICAgIGVsc2UgaWYgKGxldmVsID49IDUpIHNldmVyaXR5ID0gJ21lZGl1bSc7XG5cbiAgICBjb25zdCBwYXlsb2FkOiBDcmVhdGVDYXNlUGF5bG9hZCA9IHtcbiAgICAgIHRpdGxlOiBgW0F1dG9tYXRlZF0gJHthbGVydC5ydWxlPy5kZXNjcmlwdGlvbiB8fCAnU2VjdXJpdHkgQWxlcnQnfWAsXG4gICAgICBkZXNjcmlwdGlvbjogYEF1dG9tYXRlZCBjYXNlIGNyZWF0ZWQgZnJvbSBXYXp1aCBBbGVydC5cXG5cXG5SdWxlOiAke3J1bGVJZH1cXG5BZ2VudDogJHthbGVydC5hZ2VudD8ubmFtZX0gKCR7YWdlbnRJZH0pXFxuTGV2ZWw6ICR7bGV2ZWx9XFxuXFxuTG9nOiAke2FsZXJ0LmZ1bGxfbG9nIHx8ICdOL0EnfWAsXG4gICAgICBzZXZlcml0eSxcbiAgICAgIHByaW9yaXR5OiAnUDInLFxuICAgICAgY2F0ZWdvcnk6ICdvdGhlcicsXG4gICAgICB0YWdzOiBbJ2F1dG9tYXRlZCcsIGBydWxlXyR7cnVsZUlkfWAsIGBhZ2VudF8ke2FnZW50SWR9YF0sXG4gICAgfTtcblxuICAgIGNvbnN0IG5ld0Nhc2UgPSBhd2FpdCBDYXNlU2VydmljZS5jcmVhdGVDYXNlKGNsaWVudCwgcGF5bG9hZCwgdXNlcik7XG4gICAgXG4gICAgLy8gQWRkIGN1c3RvbSBmaWVsZHMgZm9yIGRlZHVwbGljYXRpb24gdHJhY2tpbmdcbiAgICBpZiAobmV3Q2FzZS5pZCkge1xuICAgICAgIGF3YWl0IE9wZW5TZWFyY2hTZXJ2aWNlLnVwZGF0ZURvY3VtZW50KGNsaWVudCwgQ0FTRV9JTkRFWCwgbmV3Q2FzZS5pZCwge1xuICAgICAgICAgY3VzdG9tX2ZpZWxkczoge1xuICAgICAgICAgICBhdXRvbWF0ZWRfcnVsZV9pZDogU3RyaW5nKHJ1bGVJZCksXG4gICAgICAgICAgIGF1dG9tYXRlZF9hZ2VudF9pZDogU3RyaW5nKGFnZW50SWQpXG4gICAgICAgICB9LFxuICAgICAgICAgbGlua2VkX2FsZXJ0czogW2xpbmtlZEFsZXJ0XVxuICAgICAgIH0pO1xuICAgICAgIHJldHVybiBhd2FpdCBDYXNlU2VydmljZS5nZXRDYXNlKGNsaWVudCwgbmV3Q2FzZS5pZCk7XG4gICAgfVxuICAgIFxuICAgIHJldHVybiBuZXdDYXNlO1xuICB9XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQTBCQSxJQUFBQSxVQUFBLEdBQUFDLE9BQUE7QUFZQSxJQUFBQyxtQkFBQSxHQUFBRCxPQUFBO0FBQ0EsSUFBQUUsaUJBQUEsR0FBQUYsT0FBQTtBQUNBLElBQUFHLHFCQUFBLEdBQUFILE9BQUE7QUFDQSxJQUFBSSxjQUFBLEdBQUFKLE9BQUE7QUF6Q0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBcUNBO0FBQ0EsU0FBU0sscUJBQXFCQSxDQUFBLEVBQXFCO0VBQ2pELE9BQU87SUFDTEMsV0FBVyxFQUFFLENBQUM7SUFDZEMsVUFBVSxFQUFFLENBQUM7SUFDYkMsaUJBQWlCLEVBQUUsQ0FBQztJQUNwQkMsYUFBYSxFQUFFLENBQUM7SUFDaEJDLGNBQWMsRUFBRSxDQUFDO0lBQ2pCQyxZQUFZLEVBQUUsQ0FBQztJQUNmQyxXQUFXLEVBQUUsQ0FBQyxDQUFRO0lBQ3RCQyxXQUFXLEVBQUUsQ0FBQyxDQUFRO0lBQ3RCQyxXQUFXLEVBQUUsQ0FBQyxDQUFDO0lBQ2ZDLHNCQUFzQixFQUFFLElBQUk7SUFDNUJDLG1CQUFtQixFQUFFLENBQUM7SUFDdEJDLGtCQUFrQixFQUFFO0VBQ3RCLENBQUM7QUFDSDs7QUFFQTtBQUNBLFNBQVNDLElBQUlBLENBQUEsRUFBVztFQUN0QjtFQUNBLElBQUk7SUFDRixPQUFPQyxNQUFNLENBQUNDLFVBQVUsQ0FBQyxDQUFDLENBQUNDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsRUFBRSxDQUFDLENBQUNDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDO0VBQy9ELENBQUMsQ0FBQyxNQUFNO0lBQ04sT0FBT0MsSUFBSSxDQUFDQyxHQUFHLENBQUMsQ0FBQyxDQUFDQyxRQUFRLENBQUMsRUFBRSxDQUFDLEdBQUdDLElBQUksQ0FBQ0MsTUFBTSxDQUFDLENBQUMsQ0FBQ0YsUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFDSCxTQUFTLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQztFQUM3RTtBQUNGOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sTUFBTU0sV0FBVyxDQUFDO0VBQ3ZCO0VBQ0E7RUFDQTs7RUFFQTtBQUNGO0FBQ0E7QUFDQTtFQUNFLGFBQWFDLGNBQWNBLENBQUNDLE1BQVcsRUFBbUI7SUFDeEQsTUFBTUMsT0FBTyxHQUFHLE1BQU1DLHFDQUFpQixDQUFDQyxtQkFBbUIsQ0FBQ0gsTUFBTSxDQUFDOztJQUVuRTtJQUNBO0lBQ0EsSUFBSTtNQUNGLE1BQU1JLFFBQVEsR0FBRyxNQUFNQyxpQ0FBZSxDQUFDQyxXQUFXLENBQUNOLE1BQU0sQ0FBQztNQUMxRCxPQUFPSyxpQ0FBZSxDQUFDRSxZQUFZLENBQUNILFFBQVEsRUFBRUgsT0FBTyxDQUFDO0lBQ3hELENBQUMsQ0FBQyxPQUFPTyxFQUFFLEVBQUU7TUFDWCxNQUFNQyxJQUFJLEdBQUcsSUFBSWhCLElBQUksQ0FBQyxDQUFDLENBQUNpQixXQUFXLENBQUMsQ0FBQztNQUNyQyxNQUFNQyxTQUFTLEdBQUdDLE1BQU0sQ0FBQ1gsT0FBTyxDQUFDLENBQUNZLFFBQVEsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDO01BQ2xELE9BQVEsR0FBRUMseUJBQWUsR0FBRUMsNEJBQWtCLEdBQUVOLElBQUssR0FBRU0sNEJBQWtCLEdBQUVKLFNBQVUsRUFBQztJQUN2RjtFQUNGOztFQUVBO0VBQ0E7RUFDQTs7RUFFQSxPQUFlSyxjQUFjQSxDQUMzQkMsTUFBOEIsRUFDOUJDLElBQVksRUFDWkMsT0FBNkIsRUFDZjtJQUNkLE9BQU87TUFDTEMsRUFBRSxFQUFFaEMsSUFBSSxDQUFDLENBQUM7TUFDVjZCLE1BQU07TUFDTkMsSUFBSTtNQUNKRyxTQUFTLEVBQUUsSUFBSTVCLElBQUksQ0FBQyxDQUFDLENBQUM2QixXQUFXLENBQUMsQ0FBQztNQUNuQ0g7SUFDRixDQUFDO0VBQ0g7O0VBRUE7RUFDQTtFQUNBOztFQUVBO0VBQ0EsYUFBYUksVUFBVUEsQ0FDckJ2QixNQUFXLEVBQ1h3QixPQUEwQixFQUMxQk4sSUFBWSxFQUNHO0lBQ2Y7SUFDQTtJQUNBLE1BQU1oQixxQ0FBaUIsQ0FBQ3VCLFdBQVcsQ0FBQ3pCLE1BQU0sRUFBRTBCLDZCQUFrQixFQUFFQyw4QkFBZSxDQUFDO0lBQ2hGLE1BQU16QixxQ0FBaUIsQ0FBQ3VCLFdBQVcsQ0FBQ3pCLE1BQU0sRUFBRTRCLHFCQUFVLEVBQUVDLDJCQUFZLENBQUM7SUFFckUsTUFBTUMsTUFBTSxHQUFHLE1BQU1oQyxXQUFXLENBQUNDLGNBQWMsQ0FBQ0MsTUFBTSxDQUFDO0lBQ3ZELE1BQU1OLEdBQUcsR0FBRyxJQUFJRCxJQUFJLENBQUMsQ0FBQyxDQUFDNkIsV0FBVyxDQUFDLENBQUM7SUFFcEMsTUFBTVMsT0FBYSxHQUFHO01BQ3BCQyxPQUFPLEVBQUVGLE1BQU07TUFDZkcsS0FBSyxFQUFFVCxPQUFPLENBQUNTLEtBQUs7TUFDcEJDLFdBQVcsRUFBRVYsT0FBTyxDQUFDVSxXQUFXO01BQ2hDQyxNQUFNLEVBQUUsTUFBTTtNQUNkQyxRQUFRLEVBQUVaLE9BQU8sQ0FBQ1ksUUFBUTtNQUMxQkMsUUFBUSxFQUFFYixPQUFPLENBQUNhLFFBQVE7TUFDMUJDLFFBQVEsRUFBRWQsT0FBTyxDQUFDYyxRQUFRO01BQzFCQyxHQUFHLEVBQUVmLE9BQU8sQ0FBQ2UsR0FBRyxJQUFJLE9BQU87TUFDM0JDLElBQUksRUFBRWhCLE9BQU8sQ0FBQ2dCLElBQUksSUFBSSxFQUFFO01BQ3hCQyxRQUFRLEVBQUVqQixPQUFPLENBQUNpQixRQUFRLElBQUksSUFBSTtNQUNsQ0MsVUFBVSxFQUFFeEIsSUFBSTtNQUNoQnlCLFVBQVUsRUFBRWpELEdBQUc7TUFDZmtELFVBQVUsRUFBRWxELEdBQUc7TUFDZm1ELFNBQVMsRUFBRSxJQUFJO01BQ2ZDLGFBQWEsRUFBRSxFQUFFO01BQ2pCQyxXQUFXLEVBQUUsRUFBRTtNQUNmQyxRQUFRLEVBQUUsRUFBRTtNQUNaQyxLQUFLLEVBQUUsRUFBRTtNQUNUQyxLQUFLLEVBQUUsRUFBRTtNQUNUQyxZQUFZLEVBQUUsQ0FDWnJELFdBQVcsQ0FBQ2tCLGNBQWMsQ0FBQyxjQUFjLEVBQUVFLElBQUksRUFBRTtRQUMvQ2MsT0FBTyxFQUFFRixNQUFNO1FBQ2ZHLEtBQUssRUFBRVQsT0FBTyxDQUFDUztNQUNqQixDQUFDLENBQUMsQ0FDSDtNQUNEbUIsa0JBQWtCLEVBQUUsSUFBSTtNQUN4QkMsa0JBQWtCLEVBQUUsSUFBSTtNQUN4QkMsYUFBYSxFQUFFLEVBQUU7TUFDakJDLGFBQWEsRUFBRSxDQUFDO0lBQ2xCLENBQUM7O0lBRUQ7SUFDQSxJQUFJL0IsT0FBTyxDQUFDaUIsUUFBUSxFQUFFO01BQ3BCVixPQUFPLENBQUNvQixZQUFZLENBQUNLLElBQUksQ0FDdkIxRCxXQUFXLENBQUNrQixjQUFjLENBQUMsVUFBVSxFQUFFRSxJQUFJLEVBQUU7UUFBRXVCLFFBQVEsRUFBRWpCLE9BQU8sQ0FBQ2lCO01BQVMsQ0FBQyxDQUM3RSxDQUFDO0lBQ0g7SUFFQSxNQUFNO01BQUVnQjtJQUFJLENBQUMsR0FBRyxNQUFNdkQscUNBQWlCLENBQUN3RCxjQUFjLENBQUMxRCxNQUFNLEVBQUU0QixxQkFBVSxFQUFFRyxPQUFPLENBQUM7SUFDbkZBLE9BQU8sQ0FBQ1gsRUFBRSxHQUFHcUMsR0FBRzs7SUFFaEI7SUFDQTtJQUNBLElBQUl2QyxJQUFJLEtBQUssY0FBYyxFQUFFO01BQzNCLE1BQU15Qyx5Q0FBbUIsQ0FBQ0MsUUFBUSxDQUFDNUQsTUFBTSxFQUFFO1FBQ3pDNkQsS0FBSyxFQUFFckMsT0FBTyxDQUFDaUIsUUFBUSxHQUFHLGVBQWUsR0FBRyxjQUFjO1FBQzFEcUIsVUFBVSxFQUFFLENBQUN0QyxPQUFPLENBQUNpQixRQUFRLENBQUM7UUFDOUJSLEtBQUssRUFBRyxRQUFPSCxNQUFPLFVBQVM7UUFDL0JpQyxPQUFPLEVBQUcsR0FBRTdDLElBQUssYUFBWU0sT0FBTyxDQUFDUyxLQUFNLE1BQUtULE9BQU8sQ0FBQ2EsUUFBUyxLQUFJYixPQUFPLENBQUNZLFFBQVMsSUFBRztRQUN6RjRCLE9BQU8sRUFBRWpDLE9BQU87UUFDaEJrQyxLQUFLLEVBQUUvQztNQUNULENBQUMsQ0FBQztJQUNKO0lBRUEsT0FBT2EsT0FBTztFQUNoQjs7RUFFQTtFQUNBLGFBQWFtQyxPQUFPQSxDQUFDbEUsTUFBVyxFQUFFb0IsRUFBVSxFQUF3QjtJQUNsRSxNQUFNK0MsR0FBRyxHQUFHLE1BQU1qRSxxQ0FBaUIsQ0FBQ2tFLFdBQVcsQ0FBQ3BFLE1BQU0sRUFBRTRCLHFCQUFVLEVBQUVSLEVBQUUsQ0FBQztJQUN2RSxJQUFJLENBQUMrQyxHQUFHLEVBQUUsT0FBTyxJQUFJO0lBQ3JCLE9BQU87TUFBRS9DLEVBQUUsRUFBRStDLEdBQUcsQ0FBQ1YsR0FBRztNQUFFLEdBQUdVLEdBQUcsQ0FBQ0U7SUFBUSxDQUFDO0VBQ3hDOztFQUVBO0VBQ0EsYUFBYUMsVUFBVUEsQ0FDckJ0RSxNQUFXLEVBQ1hvQixFQUFVLEVBQ1ZJLE9BQTBCLEVBQzFCTixJQUFZLEVBQ1U7SUFDdEIsTUFBTXFELFFBQVEsR0FBRyxNQUFNekUsV0FBVyxDQUFDb0UsT0FBTyxDQUFDbEUsTUFBTSxFQUFFb0IsRUFBRSxDQUFDO0lBQ3RELElBQUksQ0FBQ21ELFFBQVEsRUFBRSxPQUFPLElBQUk7SUFFMUIsTUFBTTdFLEdBQUcsR0FBRyxJQUFJRCxJQUFJLENBQUMsQ0FBQyxDQUFDNkIsV0FBVyxDQUFDLENBQUM7SUFDcEMsTUFBTWtELFVBQTBCLEdBQUcsRUFBRTtJQUNyQyxNQUFNQyxTQUFjLEdBQUc7TUFBRTdCLFVBQVUsRUFBRWxEO0lBQUksQ0FBQzs7SUFFMUM7SUFDQSxJQUFJOEIsT0FBTyxDQUFDUyxLQUFLLEtBQUt5QyxTQUFTLElBQUlsRCxPQUFPLENBQUNTLEtBQUssS0FBS3NDLFFBQVEsQ0FBQ3RDLEtBQUssRUFBRTtNQUNuRXdDLFNBQVMsQ0FBQ3hDLEtBQUssR0FBR1QsT0FBTyxDQUFDUyxLQUFLO0lBQ2pDO0lBQ0EsSUFBSVQsT0FBTyxDQUFDVSxXQUFXLEtBQUt3QyxTQUFTLEVBQUU7TUFDckNELFNBQVMsQ0FBQ3ZDLFdBQVcsR0FBR1YsT0FBTyxDQUFDVSxXQUFXO0lBQzdDO0lBQ0EsSUFBSVYsT0FBTyxDQUFDWSxRQUFRLEtBQUtzQyxTQUFTLElBQUlsRCxPQUFPLENBQUNZLFFBQVEsS0FBS21DLFFBQVEsQ0FBQ25DLFFBQVEsRUFBRTtNQUM1RXFDLFNBQVMsQ0FBQ3JDLFFBQVEsR0FBR1osT0FBTyxDQUFDWSxRQUFRO01BQ3JDb0MsVUFBVSxDQUFDaEIsSUFBSSxDQUNiMUQsV0FBVyxDQUFDa0IsY0FBYyxDQUFDLGtCQUFrQixFQUFFRSxJQUFJLEVBQUU7UUFDbkR5RCxJQUFJLEVBQUVKLFFBQVEsQ0FBQ25DLFFBQVE7UUFDdkJ3QyxFQUFFLEVBQUVwRCxPQUFPLENBQUNZO01BQ2QsQ0FBQyxDQUNILENBQUM7SUFDSDtJQUNBLElBQUlaLE9BQU8sQ0FBQ2EsUUFBUSxLQUFLcUMsU0FBUyxJQUFJbEQsT0FBTyxDQUFDYSxRQUFRLEtBQUtrQyxRQUFRLENBQUNsQyxRQUFRLEVBQUU7TUFDNUVvQyxTQUFTLENBQUNwQyxRQUFRLEdBQUdiLE9BQU8sQ0FBQ2EsUUFBUTtNQUNyQ21DLFVBQVUsQ0FBQ2hCLElBQUksQ0FDYjFELFdBQVcsQ0FBQ2tCLGNBQWMsQ0FBQyxrQkFBa0IsRUFBRUUsSUFBSSxFQUFFO1FBQ25EeUQsSUFBSSxFQUFFSixRQUFRLENBQUNsQyxRQUFRO1FBQ3ZCdUMsRUFBRSxFQUFFcEQsT0FBTyxDQUFDYTtNQUNkLENBQUMsQ0FDSCxDQUFDO0lBQ0g7SUFDQSxJQUFJYixPQUFPLENBQUNjLFFBQVEsS0FBS29DLFNBQVMsRUFBRTtNQUNsQ0QsU0FBUyxDQUFDbkMsUUFBUSxHQUFHZCxPQUFPLENBQUNjLFFBQVE7SUFDdkM7SUFDQSxJQUFJZCxPQUFPLENBQUNlLEdBQUcsS0FBS21DLFNBQVMsRUFBRTtNQUM3QkQsU0FBUyxDQUFDbEMsR0FBRyxHQUFHZixPQUFPLENBQUNlLEdBQUc7SUFDN0I7SUFDQSxJQUFJZixPQUFPLENBQUNnQixJQUFJLEtBQUtrQyxTQUFTLEVBQUU7TUFDOUJELFNBQVMsQ0FBQ2pDLElBQUksR0FBR2hCLE9BQU8sQ0FBQ2dCLElBQUk7SUFDL0I7SUFDQSxJQUFJaEIsT0FBTyxDQUFDaUIsUUFBUSxLQUFLaUMsU0FBUyxJQUFJbEQsT0FBTyxDQUFDaUIsUUFBUSxLQUFLOEIsUUFBUSxDQUFDOUIsUUFBUSxFQUFFO01BQzVFZ0MsU0FBUyxDQUFDaEMsUUFBUSxHQUFHakIsT0FBTyxDQUFDaUIsUUFBUTtNQUNyQytCLFVBQVUsQ0FBQ2hCLElBQUksQ0FDYjFELFdBQVcsQ0FBQ2tCLGNBQWMsQ0FBQ1EsT0FBTyxDQUFDaUIsUUFBUSxHQUFHLFVBQVUsR0FBRyxZQUFZLEVBQUV2QixJQUFJLEVBQUU7UUFDN0V5RCxJQUFJLEVBQUVKLFFBQVEsQ0FBQzlCLFFBQVE7UUFDdkJtQyxFQUFFLEVBQUVwRCxPQUFPLENBQUNpQjtNQUNkLENBQUMsQ0FDSCxDQUFDO0lBQ0g7SUFDQSxJQUFJakIsT0FBTyxDQUFDNEIsa0JBQWtCLEtBQUtzQixTQUFTLEVBQUU7TUFDNUNELFNBQVMsQ0FBQ3JCLGtCQUFrQixHQUFHNUIsT0FBTyxDQUFDNEIsa0JBQWtCO0lBQzNEOztJQUVBO0lBQ0EsSUFBSW9CLFVBQVUsQ0FBQ0ssTUFBTSxHQUFHLENBQUMsRUFBRTtNQUN6QkosU0FBUyxDQUFDdEIsWUFBWSxHQUFHLENBQUMsR0FBR29CLFFBQVEsQ0FBQ3BCLFlBQVksRUFBRSxHQUFHcUIsVUFBVSxDQUFDO0lBQ3BFO0lBRUEsTUFBTXRFLHFDQUFpQixDQUFDNEUsY0FBYyxDQUFDOUUsTUFBTSxFQUFFNEIscUJBQVUsRUFBRVIsRUFBRSxFQUFFcUQsU0FBUyxDQUFDO0lBRXpFLElBQUlBLFNBQVMsQ0FBQ2hDLFFBQVEsRUFBRTtNQUN0QixNQUFNa0IseUNBQW1CLENBQUNDLFFBQVEsQ0FBQzVELE1BQU0sRUFBRTtRQUN6QzZELEtBQUssRUFBRSxlQUFlO1FBQ3RCQyxVQUFVLEVBQUUsQ0FBQ1csU0FBUyxDQUFDaEMsUUFBUSxDQUFDO1FBQ2hDUixLQUFLLEVBQUcsUUFBT3NDLFFBQVEsQ0FBQ3ZDLE9BQVEsa0JBQWlCO1FBQ2pEK0IsT0FBTyxFQUFHLEdBQUU3QyxJQUFLLGtCQUFpQnFELFFBQVEsQ0FBQ3RDLEtBQU0sSUFBRztRQUNwRCtCLE9BQU8sRUFBRTtVQUFFLEdBQUdPLFFBQVE7VUFBRTlCLFFBQVEsRUFBRWdDLFNBQVMsQ0FBQ2hDO1FBQVMsQ0FBQztRQUN0RHdCLEtBQUssRUFBRS9DO01BQ1QsQ0FBQyxDQUFDO0lBQ0o7SUFDQSxJQUFJdUQsU0FBUyxDQUFDcEMsUUFBUSxFQUFFO01BQ3RCLE1BQU1zQix5Q0FBbUIsQ0FBQ0MsUUFBUSxDQUFDNUQsTUFBTSxFQUFFO1FBQ3pDNkQsS0FBSyxFQUFFLGtCQUFrQjtRQUN6QkMsVUFBVSxFQUFFLENBQUNTLFFBQVEsQ0FBQzlCLFFBQVEsRUFBRThCLFFBQVEsQ0FBQzdCLFVBQVUsQ0FBQztRQUNwRFQsS0FBSyxFQUFHLFFBQU9zQyxRQUFRLENBQUN2QyxPQUFRLG9CQUFtQnlDLFNBQVMsQ0FBQ3BDLFFBQVMsRUFBQztRQUN2RTBCLE9BQU8sRUFBRyxHQUFFN0MsSUFBSyw4QkFBNkJxRCxRQUFRLENBQUNsQyxRQUFTLE9BQU1vQyxTQUFTLENBQUNwQyxRQUFTLEdBQUU7UUFDM0YyQixPQUFPLEVBQUU7VUFBRSxHQUFHTyxRQUFRO1VBQUVsQyxRQUFRLEVBQUVvQyxTQUFTLENBQUNwQztRQUFTLENBQUM7UUFDdEQ0QixLQUFLLEVBQUUvQztNQUNULENBQUMsQ0FBQztJQUNKO0lBRUEsT0FBTyxNQUFNcEIsV0FBVyxDQUFDb0UsT0FBTyxDQUFDbEUsTUFBTSxFQUFFb0IsRUFBRSxDQUFDO0VBQzlDOztFQUVBO0VBQ0EsYUFBYTJELFVBQVVBLENBQUMvRSxNQUFXLEVBQUVvQixFQUFVLEVBQW9CO0lBQ2pFLE9BQU8sTUFBTWxCLHFDQUFpQixDQUFDOEUsY0FBYyxDQUFDaEYsTUFBTSxFQUFFNEIscUJBQVUsRUFBRVIsRUFBRSxDQUFDO0VBQ3ZFOztFQUVBO0VBQ0EsYUFBYTZELFNBQVNBLENBQUNqRixNQUFXLEVBQUVrRixLQUFvQixFQUE2QjtJQUNuRixNQUFNQyxJQUFJLEdBQUdELEtBQUssQ0FBQ0MsSUFBSSxJQUFJLENBQUM7SUFDNUIsTUFBTUMsT0FBTyxHQUFHeEYsSUFBSSxDQUFDeUYsR0FBRyxDQUFDSCxLQUFLLENBQUNJLFFBQVEsSUFBSUMsNEJBQWlCLEVBQUVDLHdCQUFhLENBQUM7SUFDNUUsTUFBTUMsU0FBUyxHQUFHUCxLQUFLLENBQUNRLFVBQVUsSUFBSUMsNkJBQWtCO0lBQ3hELE1BQU1DLFNBQVMsR0FBR1YsS0FBSyxDQUFDVyxVQUFVLElBQUlDLDZCQUFrQjs7SUFFeEQ7SUFDQSxNQUFNQyxJQUFXLEdBQUcsRUFBRTtJQUV0QixJQUFJYixLQUFLLENBQUMvQyxNQUFNLEVBQUU7TUFDaEI0RCxJQUFJLENBQUN2QyxJQUFJLENBQUM7UUFBRXdDLElBQUksRUFBRTtVQUFFN0QsTUFBTSxFQUFFK0MsS0FBSyxDQUFDL0M7UUFBTztNQUFFLENBQUMsQ0FBQztJQUMvQztJQUNBLElBQUkrQyxLQUFLLENBQUM5QyxRQUFRLEVBQUU7TUFDbEIyRCxJQUFJLENBQUN2QyxJQUFJLENBQUM7UUFBRXdDLElBQUksRUFBRTtVQUFFNUQsUUFBUSxFQUFFOEMsS0FBSyxDQUFDOUM7UUFBUztNQUFFLENBQUMsQ0FBQztJQUNuRDtJQUNBLElBQUk4QyxLQUFLLENBQUM3QyxRQUFRLEVBQUU7TUFDbEIwRCxJQUFJLENBQUN2QyxJQUFJLENBQUM7UUFBRXdDLElBQUksRUFBRTtVQUFFM0QsUUFBUSxFQUFFNkMsS0FBSyxDQUFDN0M7UUFBUztNQUFFLENBQUMsQ0FBQztJQUNuRDtJQUNBLElBQUk2QyxLQUFLLENBQUM1QyxRQUFRLEVBQUU7TUFDbEJ5RCxJQUFJLENBQUN2QyxJQUFJLENBQUM7UUFBRXdDLElBQUksRUFBRTtVQUFFMUQsUUFBUSxFQUFFNEMsS0FBSyxDQUFDNUM7UUFBUztNQUFFLENBQUMsQ0FBQztJQUNuRDtJQUNBLElBQUk0QyxLQUFLLENBQUN6QyxRQUFRLEVBQUU7TUFDbEJzRCxJQUFJLENBQUN2QyxJQUFJLENBQUM7UUFBRXdDLElBQUksRUFBRTtVQUFFdkQsUUFBUSxFQUFFeUMsS0FBSyxDQUFDekM7UUFBUztNQUFFLENBQUMsQ0FBQztJQUNuRDtJQUNBLElBQUl5QyxLQUFLLENBQUMxQyxJQUFJLEVBQUU7TUFDZCxNQUFNeUQsT0FBTyxHQUFHZixLQUFLLENBQUMxQyxJQUFJLENBQUMwRCxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUNDLEdBQUcsQ0FBRUMsQ0FBQyxJQUFLQSxDQUFDLENBQUNDLElBQUksQ0FBQyxDQUFDLENBQUM7TUFDMUROLElBQUksQ0FBQ3ZDLElBQUksQ0FBQztRQUFFOEMsS0FBSyxFQUFFO1VBQUU5RCxJQUFJLEVBQUV5RDtRQUFRO01BQUUsQ0FBQyxDQUFDO0lBQ3pDO0lBQ0EsSUFBSWYsS0FBSyxDQUFDcUIsTUFBTSxFQUFFO01BQ2hCUixJQUFJLENBQUN2QyxJQUFJLENBQUM7UUFDUmdELFdBQVcsRUFBRTtVQUNYdEIsS0FBSyxFQUFFQSxLQUFLLENBQUNxQixNQUFNO1VBQ25CRSxNQUFNLEVBQUUsQ0FBQyxTQUFTLEVBQUUsYUFBYSxFQUFFLFdBQVcsRUFBRSxNQUFNLENBQUM7VUFDdkRDLElBQUksRUFBRSxhQUFhO1VBQ25CQyxTQUFTLEVBQUU7UUFDYjtNQUNGLENBQUMsQ0FBQztJQUNKO0lBQ0EsSUFBSXpCLEtBQUssQ0FBQzBCLFlBQVksSUFBSTFCLEtBQUssQ0FBQzJCLFVBQVUsRUFBRTtNQUMxQyxNQUFNQyxLQUFVLEdBQUcsQ0FBQyxDQUFDO01BQ3JCLElBQUk1QixLQUFLLENBQUMwQixZQUFZLEVBQUVFLEtBQUssQ0FBQ0MsR0FBRyxHQUFHN0IsS0FBSyxDQUFDMEIsWUFBWTtNQUN0RCxJQUFJMUIsS0FBSyxDQUFDMkIsVUFBVSxFQUFFQyxLQUFLLENBQUNFLEdBQUcsR0FBRzlCLEtBQUssQ0FBQzJCLFVBQVU7TUFDbERkLElBQUksQ0FBQ3ZDLElBQUksQ0FBQztRQUFFc0QsS0FBSyxFQUFFO1VBQUVuRSxVQUFVLEVBQUVtRTtRQUFNO01BQUUsQ0FBQyxDQUFDO0lBQzdDO0lBRUEsTUFBTUcsVUFBVSxHQUFHO01BQ2pCL0IsS0FBSyxFQUFFYSxJQUFJLENBQUNsQixNQUFNLEdBQUcsQ0FBQyxHQUFHO1FBQUVxQyxJQUFJLEVBQUU7VUFBRW5CO1FBQUs7TUFBRSxDQUFDLEdBQUc7UUFBRW9CLFNBQVMsRUFBRSxDQUFDO01BQUUsQ0FBQztNQUMvREMsSUFBSSxFQUFFLENBQUM7UUFBRSxDQUFDM0IsU0FBUyxHQUFHO1VBQUU0QixLQUFLLEVBQUV6QjtRQUFVO01BQUUsQ0FBQyxDQUFDO01BQzdDakIsSUFBSSxFQUFFLENBQUNRLElBQUksR0FBRyxDQUFDLElBQUlDLE9BQU87TUFDMUJrQyxJQUFJLEVBQUVsQyxPQUFPO01BQ2I7TUFDQWYsT0FBTyxFQUFFO1FBQ1BrRCxRQUFRLEVBQUUsQ0FBQyxjQUFjLEVBQUUsa0JBQWtCO01BQy9DO0lBQ0YsQ0FBQztJQUVELE1BQU07TUFBRUMsSUFBSTtNQUFFQztJQUFNLENBQUMsR0FBRyxNQUFNdkgscUNBQWlCLENBQUN3SCxlQUFlLENBQUMxSCxNQUFNLEVBQUU0QixxQkFBVSxFQUFFcUYsVUFBVSxDQUFDO0lBRS9GLE1BQU1VLEtBQWEsR0FBR0gsSUFBSSxDQUFDckIsR0FBRyxDQUFFeUIsR0FBUSxLQUFNO01BQzVDeEcsRUFBRSxFQUFFd0csR0FBRyxDQUFDbkUsR0FBRztNQUNYLEdBQUdtRSxHQUFHLENBQUN2RDtJQUNULENBQUMsQ0FBQyxDQUFDO0lBRUgsT0FBTztNQUFFc0QsS0FBSztNQUFFRixLQUFLO01BQUV0QyxJQUFJO01BQUVHLFFBQVEsRUFBRUY7SUFBUSxDQUFDO0VBQ2xEOztFQUVBO0VBQ0E7RUFDQTs7RUFFQTtFQUNBLGFBQWF5QyxZQUFZQSxDQUN2QjdILE1BQVcsRUFDWG9CLEVBQVUsRUFDVjBHLFNBQXFCLEVBQ3JCNUcsSUFBWSxFQUNnRDtJQUM1RCxNQUFNcUQsUUFBUSxHQUFHLE1BQU16RSxXQUFXLENBQUNvRSxPQUFPLENBQUNsRSxNQUFNLEVBQUVvQixFQUFFLENBQUM7SUFDdEQsSUFBSSxDQUFDbUQsUUFBUSxFQUFFO01BQ2IsT0FBTztRQUFFd0QsT0FBTyxFQUFFLEtBQUs7UUFBRUMsS0FBSyxFQUFFO01BQWlCLENBQUM7SUFDcEQ7O0lBRUE7SUFDQSxNQUFNQyxrQkFBa0IsR0FBR0MsNkJBQWtCLENBQUMzRCxRQUFRLENBQUNwQyxNQUFNLENBQUMsSUFBSSxFQUFFO0lBQ3BFLElBQUksQ0FBQzhGLGtCQUFrQixDQUFDRSxRQUFRLENBQUNMLFNBQVMsQ0FBQyxFQUFFO01BQzNDLE9BQU87UUFDTEMsT0FBTyxFQUFFLEtBQUs7UUFDZEMsS0FBSyxFQUFHLDJCQUEwQnpELFFBQVEsQ0FBQ3BDLE1BQU8sU0FBUTJGLFNBQVUsZUFBY0csa0JBQWtCLENBQUNHLElBQUksQ0FBQyxJQUFJLENBQUU7TUFDbEgsQ0FBQztJQUNIO0lBRUEsTUFBTTFJLEdBQUcsR0FBRyxJQUFJRCxJQUFJLENBQUMsQ0FBQyxDQUFDNkIsV0FBVyxDQUFDLENBQUM7SUFDcEMsTUFBTW1ELFNBQWMsR0FBRztNQUNyQnRDLE1BQU0sRUFBRTJGLFNBQVM7TUFDakJsRixVQUFVLEVBQUVsRDtJQUNkLENBQUM7O0lBRUQ7SUFDQSxJQUFJb0ksU0FBUyxLQUFLLFFBQVEsSUFBSUEsU0FBUyxLQUFLLFVBQVUsRUFBRTtNQUN0RHJELFNBQVMsQ0FBQzVCLFNBQVMsR0FBR25ELEdBQUc7TUFDekIsSUFBSTZFLFFBQVEsQ0FBQzVCLFVBQVUsRUFBRTtRQUN2QjhCLFNBQVMsQ0FBQ3BCLGtCQUFrQixHQUFHLElBQUk1RCxJQUFJLENBQUNDLEdBQUcsQ0FBQyxDQUFDMkksT0FBTyxDQUFDLENBQUMsR0FBRyxJQUFJNUksSUFBSSxDQUFDOEUsUUFBUSxDQUFDNUIsVUFBVSxDQUFDLENBQUMwRixPQUFPLENBQUMsQ0FBQztNQUNsRztJQUNGOztJQUVBO0lBQ0EsSUFBSVAsU0FBUyxLQUFLLE1BQU0sS0FBS3ZELFFBQVEsQ0FBQ3BDLE1BQU0sS0FBSyxRQUFRLElBQUlvQyxRQUFRLENBQUNwQyxNQUFNLEtBQUssVUFBVSxDQUFDLEVBQUU7TUFDNUZzQyxTQUFTLENBQUM1QixTQUFTLEdBQUcsSUFBSTtNQUMxQjRCLFNBQVMsQ0FBQ3BCLGtCQUFrQixHQUFHLElBQUk7SUFDckM7O0lBRUE7SUFDQSxNQUFNaUYsUUFBUSxHQUFHeEksV0FBVyxDQUFDa0IsY0FBYyxDQUN6QzhHLFNBQVMsS0FBSyxRQUFRLEdBQUcsYUFBYSxHQUFHQSxTQUFTLEtBQUssTUFBTSxJQUFJdkQsUUFBUSxDQUFDcEMsTUFBTSxLQUFLLFFBQVEsR0FBRyxlQUFlLEdBQUcsZ0JBQWdCLEVBQ2xJakIsSUFBSSxFQUNKO01BQUV5RCxJQUFJLEVBQUVKLFFBQVEsQ0FBQ3BDLE1BQU07TUFBRXlDLEVBQUUsRUFBRWtEO0lBQVUsQ0FDekMsQ0FBQztJQUNEckQsU0FBUyxDQUFDdEIsWUFBWSxHQUFHLENBQUMsR0FBR29CLFFBQVEsQ0FBQ3BCLFlBQVksRUFBRW1GLFFBQVEsQ0FBQztJQUU3RCxNQUFNcEkscUNBQWlCLENBQUM0RSxjQUFjLENBQUM5RSxNQUFNLEVBQUU0QixxQkFBVSxFQUFFUixFQUFFLEVBQUVxRCxTQUFTLENBQUM7SUFDekUsTUFBTThELFdBQVcsR0FBRyxNQUFNekksV0FBVyxDQUFDb0UsT0FBTyxDQUFDbEUsTUFBTSxFQUFFb0IsRUFBRSxDQUFDO0lBRXpELE1BQU11Qyx5Q0FBbUIsQ0FBQ0MsUUFBUSxDQUFDNUQsTUFBTSxFQUFFO01BQ3pDNkQsS0FBSyxFQUFFLGdCQUFnQjtNQUN2QkMsVUFBVSxFQUFFLENBQUNTLFFBQVEsQ0FBQzlCLFFBQVEsRUFBRThCLFFBQVEsQ0FBQzdCLFVBQVUsQ0FBQztNQUNwRFQsS0FBSyxFQUFHLFFBQU9zQyxRQUFRLENBQUN2QyxPQUFRLFdBQVU4RixTQUFTLENBQUN2SSxPQUFPLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBRSxFQUFDO01BQ3ZFd0UsT0FBTyxFQUFHLEdBQUU3QyxJQUFLLHdCQUF1QnFELFFBQVEsQ0FBQ3BDLE1BQU0sQ0FBQzVDLE9BQU8sQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFFLE9BQU11SSxTQUFTLENBQUN2SSxPQUFPLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBRSxHQUFFO01BQzlHeUUsT0FBTyxFQUFFdUUsV0FBVyxJQUFJaEUsUUFBUTtNQUNoQ04sS0FBSyxFQUFFL0MsSUFBSTtNQUNYc0gsT0FBTyxFQUFFO1FBQUU3RCxJQUFJLEVBQUVKLFFBQVEsQ0FBQ3BDLE1BQU07UUFBRXlDLEVBQUUsRUFBRWtEO01BQVU7SUFDbEQsQ0FBQyxDQUFDO0lBRUYsT0FBTztNQUFFQyxPQUFPLEVBQUUsSUFBSTtNQUFFVSxJQUFJLEVBQUVGO0lBQWEsQ0FBQztFQUM5Qzs7RUFFQTtFQUNBLGFBQWFHLFVBQVVBLENBQ3JCMUksTUFBVyxFQUNYb0IsRUFBVSxFQUNWcUIsUUFBdUIsRUFDdkJ2QixJQUFZLEVBQ1U7SUFDdEIsTUFBTXFELFFBQVEsR0FBRyxNQUFNekUsV0FBVyxDQUFDb0UsT0FBTyxDQUFDbEUsTUFBTSxFQUFFb0IsRUFBRSxDQUFDO0lBQ3RELElBQUksQ0FBQ21ELFFBQVEsRUFBRSxPQUFPLElBQUk7SUFFMUIsTUFBTStELFFBQVEsR0FBR3hJLFdBQVcsQ0FBQ2tCLGNBQWMsQ0FDekN5QixRQUFRLEdBQUcsVUFBVSxHQUFHLFlBQVksRUFDcEN2QixJQUFJLEVBQ0o7TUFBRXlELElBQUksRUFBRUosUUFBUSxDQUFDOUIsUUFBUTtNQUFFbUMsRUFBRSxFQUFFbkM7SUFBUyxDQUMxQyxDQUFDO0lBRUQsTUFBTXZDLHFDQUFpQixDQUFDNEUsY0FBYyxDQUFDOUUsTUFBTSxFQUFFNEIscUJBQVUsRUFBRVIsRUFBRSxFQUFFO01BQzdEcUIsUUFBUTtNQUNSRyxVQUFVLEVBQUUsSUFBSW5ELElBQUksQ0FBQyxDQUFDLENBQUM2QixXQUFXLENBQUMsQ0FBQztNQUNwQzZCLFlBQVksRUFBRSxDQUFDLEdBQUdvQixRQUFRLENBQUNwQixZQUFZLEVBQUVtRixRQUFRO0lBQ25ELENBQUMsQ0FBQztJQUVGLElBQUk3RixRQUFRLEVBQUU7TUFDWixNQUFNa0IseUNBQW1CLENBQUNDLFFBQVEsQ0FBQzVELE1BQU0sRUFBRTtRQUN6QzZELEtBQUssRUFBRSxlQUFlO1FBQ3RCQyxVQUFVLEVBQUUsQ0FBQ3JCLFFBQVEsQ0FBQztRQUN0QlIsS0FBSyxFQUFHLFFBQU9zQyxRQUFRLENBQUN2QyxPQUFRLGtCQUFpQjtRQUNqRCtCLE9BQU8sRUFBRyxHQUFFN0MsSUFBSyxrQkFBaUJxRCxRQUFRLENBQUN0QyxLQUFNLE1BQUtzQyxRQUFRLENBQUNsQyxRQUFTLEtBQUlrQyxRQUFRLENBQUNuQyxRQUFTLElBQUc7UUFDakc0QixPQUFPLEVBQUU7VUFBRSxHQUFHTyxRQUFRO1VBQUU5QjtRQUFTLENBQUM7UUFDbEN3QixLQUFLLEVBQUUvQztNQUNULENBQUMsQ0FBQztJQUNKO0lBRUEsT0FBTyxNQUFNcEIsV0FBVyxDQUFDb0UsT0FBTyxDQUFDbEUsTUFBTSxFQUFFb0IsRUFBRSxDQUFDO0VBQzlDOztFQUVBO0VBQ0E7RUFDQTs7RUFFQTtFQUNBLGFBQWF1SCxPQUFPQSxDQUNsQjNJLE1BQVcsRUFDWDhCLE1BQWMsRUFDZDhHLE1BQWdGLEVBQ2hGMUgsSUFBWSxFQUNVO0lBQ3RCLE1BQU1xRCxRQUFRLEdBQUcsTUFBTXpFLFdBQVcsQ0FBQ29FLE9BQU8sQ0FBQ2xFLE1BQU0sRUFBRThCLE1BQU0sQ0FBQztJQUMxRCxJQUFJLENBQUN5QyxRQUFRLEVBQUUsT0FBTyxJQUFJO0lBRTFCLE1BQU1zRSxPQUFpQixHQUFHO01BQ3hCQyxPQUFPLEVBQUUxSixJQUFJLENBQUMsQ0FBQztNQUNmNkMsS0FBSyxFQUFFMkcsTUFBTSxDQUFDM0csS0FBSztNQUNuQjhHLFNBQVMsRUFBRSxLQUFLO01BQ2hCQyxXQUFXLEVBQUVKLE1BQU0sQ0FBQ0ksV0FBVyxJQUFJLElBQUk7TUFDdkNDLFFBQVEsRUFBRUwsTUFBTSxDQUFDSyxRQUFRLElBQUksSUFBSTtNQUNqQ3RHLFVBQVUsRUFBRSxJQUFJbEQsSUFBSSxDQUFDLENBQUMsQ0FBQzZCLFdBQVcsQ0FBQyxDQUFDO01BQ3BDb0IsVUFBVSxFQUFFeEI7SUFDZCxDQUFDO0lBRUQsTUFBTXVELFNBQVMsR0FBRztNQUNoQnhCLEtBQUssRUFBRSxDQUFDLElBQUlzQixRQUFRLENBQUN0QixLQUFLLElBQUksRUFBRSxDQUFDLEVBQUU0RixPQUFPLENBQUM7TUFDM0NqRyxVQUFVLEVBQUUsSUFBSW5ELElBQUksQ0FBQyxDQUFDLENBQUM2QixXQUFXLENBQUM7SUFDckMsQ0FBQztJQUVELE1BQU1wQixxQ0FBaUIsQ0FBQzRFLGNBQWMsQ0FBQzlFLE1BQU0sRUFBRTRCLHFCQUFVLEVBQUVFLE1BQU0sRUFBRTJDLFNBQVMsQ0FBQztJQUU3RSxJQUFJb0UsT0FBTyxDQUFDRyxXQUFXLEVBQUU7TUFDdkIsTUFBTWxKLFdBQVcsQ0FBQ29KLG9CQUFvQixDQUFDbEosTUFBTSxFQUFFdUUsUUFBUSxFQUFFc0UsT0FBTyxFQUFFM0gsSUFBSSxDQUFDO0lBQ3pFO0lBRUEsT0FBTyxNQUFNcEIsV0FBVyxDQUFDb0UsT0FBTyxDQUFDbEUsTUFBTSxFQUFFOEIsTUFBTSxDQUFDO0VBQ2xEOztFQUVBO0VBQ0EsYUFBYXFILFVBQVVBLENBQ3JCbkosTUFBVyxFQUNYOEIsTUFBYyxFQUNkc0gsTUFBYyxFQUNkQyxPQUFrRixFQUNsRm5JLElBQVksRUFDVTtJQUN0QixNQUFNcUQsUUFBUSxHQUFHLE1BQU16RSxXQUFXLENBQUNvRSxPQUFPLENBQUNsRSxNQUFNLEVBQUU4QixNQUFNLENBQUM7SUFDMUQsSUFBSSxDQUFDeUMsUUFBUSxFQUFFLE9BQU8sSUFBSTtJQUUxQixNQUFNK0UsTUFBTSxHQUFHLENBQUMvRSxRQUFRLENBQUN0QixLQUFLLElBQUksRUFBRSxFQUFFc0csSUFBSSxDQUFFbkQsQ0FBTSxJQUFLQSxDQUFDLENBQUMwQyxPQUFPLEtBQUtNLE1BQU0sQ0FBQztJQUM1RSxJQUFJLENBQUNFLE1BQU0sRUFBRSxPQUFPL0UsUUFBUTtJQUU1QixNQUFNaUYsZ0JBQWdCLEdBQUdGLE1BQU0sQ0FBQ04sV0FBVyxJQUFJLElBQUk7SUFDbkQsTUFBTS9GLEtBQUssR0FBRyxDQUFDc0IsUUFBUSxDQUFDdEIsS0FBSyxJQUFJLEVBQUUsRUFBRWtELEdBQUcsQ0FBRUMsQ0FBTSxJQUM5Q0EsQ0FBQyxDQUFDMEMsT0FBTyxLQUFLTSxNQUFNLEdBQUc7TUFBRSxHQUFHaEQsQ0FBQztNQUFFLEdBQUdpRDtJQUFRLENBQUMsR0FBR2pELENBQ2hELENBQUM7SUFFRCxNQUFNbEcscUNBQWlCLENBQUM0RSxjQUFjLENBQUM5RSxNQUFNLEVBQUU0QixxQkFBVSxFQUFFRSxNQUFNLEVBQUU7TUFDakVtQixLQUFLO01BQ0xMLFVBQVUsRUFBRSxJQUFJbkQsSUFBSSxDQUFDLENBQUMsQ0FBQzZCLFdBQVcsQ0FBQztJQUNyQyxDQUFDLENBQUM7O0lBRUY7SUFDQSxNQUFNbUksWUFBWSxHQUFHSixPQUFPLENBQUNMLFdBQVcsS0FBS3RFLFNBQVMsR0FBRzhFLGdCQUFnQixHQUFHSCxPQUFPLENBQUNMLFdBQVc7SUFDL0YsSUFBSVMsWUFBWSxJQUFJQSxZQUFZLEtBQUtELGdCQUFnQixFQUFFO01BQ3JELE1BQU0xSixXQUFXLENBQUNvSixvQkFBb0IsQ0FDcENsSixNQUFNLEVBQ051RSxRQUFRLEVBQ1I7UUFBRSxHQUFHK0UsTUFBTTtRQUFFLEdBQUdEO01BQVEsQ0FBQyxFQUN6Qm5JLElBQ0YsQ0FBQztJQUNIO0lBRUEsT0FBTyxNQUFNcEIsV0FBVyxDQUFDb0UsT0FBTyxDQUFDbEUsTUFBTSxFQUFFOEIsTUFBTSxDQUFDO0VBQ2xEO0VBRUEsYUFBcUJvSCxvQkFBb0JBLENBQ3ZDbEosTUFBVyxFQUNYMEosUUFBYyxFQUNkQyxJQUFjLEVBQ2QxRixLQUFhLEVBQ0U7SUFDZixNQUFNMkYsR0FBRyxHQUFHRCxJQUFJLENBQUNWLFFBQVEsR0FBSSxTQUFRVSxJQUFJLENBQUNWLFFBQVMsR0FBRSxHQUFHLEVBQUU7SUFDMUQsTUFBTXRGLHlDQUFtQixDQUFDQyxRQUFRLENBQUM1RCxNQUFNLEVBQUU7TUFDekM2RCxLQUFLLEVBQUUsZUFBZTtNQUN0QkMsVUFBVSxFQUFFLENBQUM2RixJQUFJLENBQUNYLFdBQVcsQ0FBQztNQUM5Qi9HLEtBQUssRUFBRyxvQkFBbUJ5SCxRQUFRLENBQUMxSCxPQUFRLEVBQUM7TUFDN0MrQixPQUFPLEVBQUcsR0FBRUUsS0FBTSxrQkFBaUIwRixJQUFJLENBQUMxSCxLQUFNLElBQUcySCxHQUFJLEdBQUU7TUFDdkQ1RixPQUFPLEVBQUUwRixRQUFRO01BQ2pCekYsS0FBSztNQUNMdUUsT0FBTyxFQUFFO1FBQUVNLE9BQU8sRUFBRWEsSUFBSSxDQUFDYixPQUFPO1FBQUVlLFVBQVUsRUFBRUYsSUFBSSxDQUFDMUgsS0FBSztRQUFFZ0gsUUFBUSxFQUFFVSxJQUFJLENBQUNWLFFBQVEsSUFBSTtNQUFLO0lBQzVGLENBQUMsQ0FBQztFQUNKOztFQUVBO0VBQ0EsYUFBYWEsVUFBVUEsQ0FBQzlKLE1BQVcsRUFBRThCLE1BQWMsRUFBRXNILE1BQWMsRUFBRUwsU0FBa0IsRUFBRTdILElBQVksRUFBd0I7SUFDM0gsTUFBTXFELFFBQVEsR0FBRyxNQUFNekUsV0FBVyxDQUFDb0UsT0FBTyxDQUFDbEUsTUFBTSxFQUFFOEIsTUFBTSxDQUFDO0lBQzFELElBQUksQ0FBQ3lDLFFBQVEsRUFBRSxPQUFPLElBQUk7SUFFMUIsTUFBTXRCLEtBQUssR0FBRyxDQUFDc0IsUUFBUSxDQUFDdEIsS0FBSyxJQUFJLEVBQUUsRUFBRWtELEdBQUcsQ0FBRUMsQ0FBTSxJQUM5Q0EsQ0FBQyxDQUFDMEMsT0FBTyxLQUFLTSxNQUFNLEdBQ2hCO01BQ0UsR0FBR2hELENBQUM7TUFDSjJDLFNBQVM7TUFDVGdCLFlBQVksRUFBRWhCLFNBQVMsR0FBRyxJQUFJdEosSUFBSSxDQUFDLENBQUMsQ0FBQzZCLFdBQVcsQ0FBQyxDQUFDLEdBQUcsSUFBSTtNQUN6RDBJLFlBQVksRUFBRWpCLFNBQVMsR0FBRzdILElBQUksR0FBRztJQUNuQyxDQUFDLEdBQ0RrRixDQUNOLENBQUM7SUFFRCxNQUFNM0IsU0FBUyxHQUFHO01BQ2hCeEIsS0FBSztNQUNMTCxVQUFVLEVBQUUsSUFBSW5ELElBQUksQ0FBQyxDQUFDLENBQUM2QixXQUFXLENBQUM7SUFDckMsQ0FBQztJQUVELE1BQU1wQixxQ0FBaUIsQ0FBQzRFLGNBQWMsQ0FBQzlFLE1BQU0sRUFBRTRCLHFCQUFVLEVBQUVFLE1BQU0sRUFBRTJDLFNBQVMsQ0FBQztJQUM3RSxPQUFPLE1BQU0zRSxXQUFXLENBQUNvRSxPQUFPLENBQUNsRSxNQUFNLEVBQUU4QixNQUFNLENBQUM7RUFDbEQ7O0VBRUE7RUFDQSxhQUFhbUksVUFBVUEsQ0FBQ2pLLE1BQVcsRUFBRThCLE1BQWMsRUFBRXNILE1BQWMsRUFBRWxJLElBQVksRUFBd0I7SUFDdkcsTUFBTXFELFFBQVEsR0FBRyxNQUFNekUsV0FBVyxDQUFDb0UsT0FBTyxDQUFDbEUsTUFBTSxFQUFFOEIsTUFBTSxDQUFDO0lBQzFELElBQUksQ0FBQ3lDLFFBQVEsRUFBRSxPQUFPLElBQUk7SUFFMUIsTUFBTXRCLEtBQUssR0FBRyxDQUFDc0IsUUFBUSxDQUFDdEIsS0FBSyxJQUFJLEVBQUUsRUFBRWlILE1BQU0sQ0FBRTlELENBQU0sSUFBS0EsQ0FBQyxDQUFDMEMsT0FBTyxLQUFLTSxNQUFNLENBQUM7SUFFN0UsTUFBTTNFLFNBQVMsR0FBRztNQUNoQnhCLEtBQUs7TUFDTEwsVUFBVSxFQUFFLElBQUluRCxJQUFJLENBQUMsQ0FBQyxDQUFDNkIsV0FBVyxDQUFDO0lBQ3JDLENBQUM7SUFFRCxNQUFNcEIscUNBQWlCLENBQUM0RSxjQUFjLENBQUM5RSxNQUFNLEVBQUU0QixxQkFBVSxFQUFFRSxNQUFNLEVBQUUyQyxTQUFTLENBQUM7SUFDN0UsT0FBTyxNQUFNM0UsV0FBVyxDQUFDb0UsT0FBTyxDQUFDbEUsTUFBTSxFQUFFOEIsTUFBTSxDQUFDO0VBQ2xEOztFQUVBO0VBQ0E7RUFDQTs7RUFFQTtFQUNBLGFBQWFxSSxXQUFXQSxDQUFDbkssTUFBVyxFQUFFOEIsTUFBYyxFQUFFb0IsS0FBYSxFQUFFaEMsSUFBWSxFQUF3QjtJQUN2RyxNQUFNcUQsUUFBUSxHQUFHLE1BQU16RSxXQUFXLENBQUNvRSxPQUFPLENBQUNsRSxNQUFNLEVBQUU4QixNQUFNLENBQUM7SUFDMUQsSUFBSSxDQUFDeUMsUUFBUSxFQUFFLE9BQU8sSUFBSTtJQUUxQixNQUFNRSxTQUFTLEdBQUc7TUFDaEJ2QixLQUFLO01BQ0xOLFVBQVUsRUFBRSxJQUFJbkQsSUFBSSxDQUFDLENBQUMsQ0FBQzZCLFdBQVcsQ0FBQztJQUNyQyxDQUFDO0lBRUQsTUFBTXBCLHFDQUFpQixDQUFDNEUsY0FBYyxDQUFDOUUsTUFBTSxFQUFFNEIscUJBQVUsRUFBRUUsTUFBTSxFQUFFMkMsU0FBUyxDQUFDO0lBQzdFLE9BQU8sTUFBTTNFLFdBQVcsQ0FBQ29FLE9BQU8sQ0FBQ2xFLE1BQU0sRUFBRThCLE1BQU0sQ0FBQztFQUNsRDs7RUFFQTtFQUNBO0VBQ0E7O0VBRUE7RUFDQSxhQUFhc0ksVUFBVUEsQ0FDckJwSyxNQUFXLEVBQ1g4QixNQUFjLEVBQ2R1SSxPQUFlLEVBQ2ZuSixJQUFZLEVBQ1U7SUFDdEIsTUFBTXFELFFBQVEsR0FBRyxNQUFNekUsV0FBVyxDQUFDb0UsT0FBTyxDQUFDbEUsTUFBTSxFQUFFOEIsTUFBTSxDQUFDO0lBQzFELElBQUksQ0FBQ3lDLFFBQVEsRUFBRSxPQUFPLElBQUk7SUFFMUIsTUFBTStGLE9BQW9CLEdBQUc7TUFDM0JDLFVBQVUsRUFBRW5MLElBQUksQ0FBQyxDQUFDO01BQ2xCb0wsTUFBTSxFQUFFdEosSUFBSTtNQUNabUosT0FBTztNQUNQMUgsVUFBVSxFQUFFLElBQUlsRCxJQUFJLENBQUMsQ0FBQyxDQUFDNkIsV0FBVyxDQUFDO0lBQ3JDLENBQUM7SUFFRCxNQUFNZ0gsUUFBUSxHQUFHeEksV0FBVyxDQUFDa0IsY0FBYyxDQUFDLGVBQWUsRUFBRUUsSUFBSSxFQUFFO01BQ2pFcUosVUFBVSxFQUFFRCxPQUFPLENBQUNDO0lBQ3RCLENBQUMsQ0FBQztJQUVGLE1BQU1ySyxxQ0FBaUIsQ0FBQzRFLGNBQWMsQ0FBQzlFLE1BQU0sRUFBRTRCLHFCQUFVLEVBQUVFLE1BQU0sRUFBRTtNQUNqRWtCLFFBQVEsRUFBRSxDQUFDLEdBQUd1QixRQUFRLENBQUN2QixRQUFRLEVBQUVzSCxPQUFPLENBQUM7TUFDekNuSCxZQUFZLEVBQUUsQ0FBQyxHQUFHb0IsUUFBUSxDQUFDcEIsWUFBWSxFQUFFbUYsUUFBUSxDQUFDO01BQ2xEMUYsVUFBVSxFQUFFLElBQUluRCxJQUFJLENBQUMsQ0FBQyxDQUFDNkIsV0FBVyxDQUFDO0lBQ3JDLENBQUMsQ0FBQztJQUVGLE1BQU1xQyx5Q0FBbUIsQ0FBQ0MsUUFBUSxDQUFDNUQsTUFBTSxFQUFFO01BQ3pDNkQsS0FBSyxFQUFFLGVBQWU7TUFDdEJDLFVBQVUsRUFBRSxDQUFDUyxRQUFRLENBQUM5QixRQUFRLEVBQUU4QixRQUFRLENBQUM3QixVQUFVLENBQUM7TUFDcERULEtBQUssRUFBRyxrQkFBaUJzQyxRQUFRLENBQUN2QyxPQUFRLEVBQUM7TUFDM0MrQixPQUFPLEVBQUcsR0FBRTdDLElBQUssS0FBSW1KLE9BQU8sQ0FBQzdLLFNBQVMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFFLEVBQUM7TUFDaER3RSxPQUFPLEVBQUVPLFFBQVE7TUFDakJOLEtBQUssRUFBRS9DO0lBQ1QsQ0FBQyxDQUFDO0lBRUYsT0FBTyxNQUFNcEIsV0FBVyxDQUFDb0UsT0FBTyxDQUFDbEUsTUFBTSxFQUFFOEIsTUFBTSxDQUFDO0VBQ2xEOztFQUVBO0VBQ0EsYUFBYTJJLGFBQWFBLENBQ3hCekssTUFBVyxFQUNYOEIsTUFBYyxFQUNkNEksU0FBaUIsRUFDakJ4SixJQUFZLEVBQ1U7SUFDdEIsTUFBTXFELFFBQVEsR0FBRyxNQUFNekUsV0FBVyxDQUFDb0UsT0FBTyxDQUFDbEUsTUFBTSxFQUFFOEIsTUFBTSxDQUFDO0lBQzFELElBQUksQ0FBQ3lDLFFBQVEsRUFBRSxPQUFPLElBQUk7SUFFMUIsTUFBTW9HLGVBQWUsR0FBR3BHLFFBQVEsQ0FBQ3ZCLFFBQVEsQ0FBQ2tILE1BQU0sQ0FBRVUsQ0FBQyxJQUFLQSxDQUFDLENBQUNMLFVBQVUsS0FBS0csU0FBUyxDQUFDO0lBQ25GLElBQUlDLGVBQWUsQ0FBQzlGLE1BQU0sS0FBS04sUUFBUSxDQUFDdkIsUUFBUSxDQUFDNkIsTUFBTSxFQUFFO01BQ3ZELE9BQU9OLFFBQVEsQ0FBQyxDQUFDO0lBQ25COztJQUVBLE1BQU0rRCxRQUFRLEdBQUd4SSxXQUFXLENBQUNrQixjQUFjLENBQUMsaUJBQWlCLEVBQUVFLElBQUksRUFBRTtNQUNuRXFKLFVBQVUsRUFBRUc7SUFDZCxDQUFDLENBQUM7SUFFRixNQUFNeEsscUNBQWlCLENBQUM0RSxjQUFjLENBQUM5RSxNQUFNLEVBQUU0QixxQkFBVSxFQUFFRSxNQUFNLEVBQUU7TUFDakVrQixRQUFRLEVBQUUySCxlQUFlO01BQ3pCeEgsWUFBWSxFQUFFLENBQUMsR0FBR29CLFFBQVEsQ0FBQ3BCLFlBQVksRUFBRW1GLFFBQVEsQ0FBQztNQUNsRDFGLFVBQVUsRUFBRSxJQUFJbkQsSUFBSSxDQUFDLENBQUMsQ0FBQzZCLFdBQVcsQ0FBQztJQUNyQyxDQUFDLENBQUM7SUFFRixPQUFPLE1BQU14QixXQUFXLENBQUNvRSxPQUFPLENBQUNsRSxNQUFNLEVBQUU4QixNQUFNLENBQUM7RUFDbEQ7O0VBRUE7RUFDQTtFQUNBOztFQUVBO0VBQ0EsYUFBYStJLFNBQVNBLENBQ3BCN0ssTUFBVyxFQUNYOEIsTUFBYyxFQUNkZ0osS0FBa0IsRUFDbEI1SixJQUFZLEVBQ1U7SUFDdEIsTUFBTXFELFFBQVEsR0FBRyxNQUFNekUsV0FBVyxDQUFDb0UsT0FBTyxDQUFDbEUsTUFBTSxFQUFFOEIsTUFBTSxDQUFDO0lBQzFELElBQUksQ0FBQ3lDLFFBQVEsRUFBRSxPQUFPLElBQUk7O0lBRTFCO0lBQ0EsSUFBSUEsUUFBUSxDQUFDekIsYUFBYSxDQUFDaUksSUFBSSxDQUFFQyxDQUFDLElBQUtBLENBQUMsQ0FBQ0MsUUFBUSxLQUFLSCxLQUFLLENBQUNHLFFBQVEsQ0FBQyxFQUFFO01BQ3JFLE9BQU8xRyxRQUFRLENBQUMsQ0FBQztJQUNuQjs7SUFFQSxNQUFNK0QsUUFBUSxHQUFHeEksV0FBVyxDQUFDa0IsY0FBYyxDQUFDLGNBQWMsRUFBRUUsSUFBSSxFQUFFO01BQ2hFK0osUUFBUSxFQUFFSCxLQUFLLENBQUNHLFFBQVE7TUFDeEJDLGdCQUFnQixFQUFFSixLQUFLLENBQUNJO0lBQzFCLENBQUMsQ0FBQztJQUVGLE1BQU1oTCxxQ0FBaUIsQ0FBQzRFLGNBQWMsQ0FBQzlFLE1BQU0sRUFBRTRCLHFCQUFVLEVBQUVFLE1BQU0sRUFBRTtNQUNqRWdCLGFBQWEsRUFBRSxDQUFDLEdBQUd5QixRQUFRLENBQUN6QixhQUFhLEVBQUVnSSxLQUFLLENBQUM7TUFDakQzSCxZQUFZLEVBQUUsQ0FBQyxHQUFHb0IsUUFBUSxDQUFDcEIsWUFBWSxFQUFFbUYsUUFBUSxDQUFDO01BQ2xEMUYsVUFBVSxFQUFFLElBQUluRCxJQUFJLENBQUMsQ0FBQyxDQUFDNkIsV0FBVyxDQUFDO0lBQ3JDLENBQUMsQ0FBQztJQUVGLE9BQU8sTUFBTXhCLFdBQVcsQ0FBQ29FLE9BQU8sQ0FBQ2xFLE1BQU0sRUFBRThCLE1BQU0sQ0FBQztFQUNsRDs7RUFFQTtFQUNBLGFBQWFxSixXQUFXQSxDQUN0Qm5MLE1BQVcsRUFDWDhCLE1BQWMsRUFDZHNKLE9BQWUsRUFDZmxLLElBQVksRUFDVTtJQUN0QixNQUFNcUQsUUFBUSxHQUFHLE1BQU16RSxXQUFXLENBQUNvRSxPQUFPLENBQUNsRSxNQUFNLEVBQUU4QixNQUFNLENBQUM7SUFDMUQsSUFBSSxDQUFDeUMsUUFBUSxFQUFFLE9BQU8sSUFBSTtJQUUxQixNQUFNOEcsYUFBYSxHQUFHOUcsUUFBUSxDQUFDekIsYUFBYSxDQUFDb0gsTUFBTSxDQUFFYyxDQUFDLElBQUtBLENBQUMsQ0FBQ0MsUUFBUSxLQUFLRyxPQUFPLENBQUM7SUFDbEYsTUFBTTlDLFFBQVEsR0FBR3hJLFdBQVcsQ0FBQ2tCLGNBQWMsQ0FBQyxnQkFBZ0IsRUFBRUUsSUFBSSxFQUFFO01BQUUrSixRQUFRLEVBQUVHO0lBQVEsQ0FBQyxDQUFDO0lBRTFGLE1BQU1sTCxxQ0FBaUIsQ0FBQzRFLGNBQWMsQ0FBQzlFLE1BQU0sRUFBRTRCLHFCQUFVLEVBQUVFLE1BQU0sRUFBRTtNQUNqRWdCLGFBQWEsRUFBRXVJLGFBQWE7TUFDNUJsSSxZQUFZLEVBQUUsQ0FBQyxHQUFHb0IsUUFBUSxDQUFDcEIsWUFBWSxFQUFFbUYsUUFBUSxDQUFDO01BQ2xEMUYsVUFBVSxFQUFFLElBQUluRCxJQUFJLENBQUMsQ0FBQyxDQUFDNkIsV0FBVyxDQUFDO0lBQ3JDLENBQUMsQ0FBQztJQUVGLE9BQU8sTUFBTXhCLFdBQVcsQ0FBQ29FLE9BQU8sQ0FBQ2xFLE1BQU0sRUFBRThCLE1BQU0sQ0FBQztFQUNsRDs7RUFFQTtFQUNBLGFBQWF3SixZQUFZQSxDQUN2QnRMLE1BQVcsRUFDWGtGLEtBQTRCLEVBQ2E7SUFDekMsTUFBTWEsSUFBVyxHQUFHLEVBQUU7SUFFdEIsSUFBSWIsS0FBSyxDQUFDcUIsTUFBTSxFQUFFO01BQ2hCUixJQUFJLENBQUN2QyxJQUFJLENBQUM7UUFDUmdELFdBQVcsRUFBRTtVQUNYdEIsS0FBSyxFQUFFQSxLQUFLLENBQUNxQixNQUFNO1VBQ25CRSxNQUFNLEVBQUUsQ0FBQyxvQkFBb0IsRUFBRSxVQUFVLEVBQUUsUUFBUSxDQUFDO1VBQ3BERSxTQUFTLEVBQUUsTUFBTTtVQUNqQjtVQUNBO1VBQ0E0RSxPQUFPLEVBQUU7UUFDWDtNQUNGLENBQUMsQ0FBQztJQUNKO0lBQ0EsSUFBSXJHLEtBQUssQ0FBQ3NHLFFBQVEsRUFBRTtNQUNsQnpGLElBQUksQ0FBQ3ZDLElBQUksQ0FBQztRQUFFd0MsSUFBSSxFQUFFO1VBQUUsVUFBVSxFQUFFZCxLQUFLLENBQUNzRztRQUFTO01BQUUsQ0FBQyxDQUFDO0lBQ3JEO0lBQ0EsSUFBSXRHLEtBQUssQ0FBQ3VHLE9BQU8sRUFBRTtNQUNqQjFGLElBQUksQ0FBQ3ZDLElBQUksQ0FBQztRQUFFd0MsSUFBSSxFQUFFO1VBQUUsU0FBUyxFQUFFcEYsTUFBTSxDQUFDc0UsS0FBSyxDQUFDdUcsT0FBTztRQUFFO01BQUUsQ0FBQyxDQUFDO0lBQzNEO0lBQ0EsSUFBSXZHLEtBQUssQ0FBQ3dHLFNBQVMsSUFBSXhHLEtBQUssQ0FBQ3lHLFNBQVMsRUFBRTtNQUN0QyxNQUFNN0UsS0FBVSxHQUFHLENBQUMsQ0FBQztNQUNyQixJQUFJNUIsS0FBSyxDQUFDd0csU0FBUyxFQUFFNUUsS0FBSyxDQUFDQyxHQUFHLEdBQUc3QixLQUFLLENBQUN3RyxTQUFTO01BQ2hELElBQUl4RyxLQUFLLENBQUN5RyxTQUFTLEVBQUU3RSxLQUFLLENBQUNFLEdBQUcsR0FBRzlCLEtBQUssQ0FBQ3lHLFNBQVM7TUFDaEQ1RixJQUFJLENBQUN2QyxJQUFJLENBQUM7UUFBRXNELEtBQUssRUFBRTtVQUFFLFlBQVksRUFBRUE7UUFBTTtNQUFFLENBQUMsQ0FBQztJQUMvQztJQUNBLElBQUk1QixLQUFLLENBQUNQLElBQUksSUFBSU8sS0FBSyxDQUFDTixFQUFFLEVBQUU7TUFDMUIsTUFBTWtDLEtBQVUsR0FBRyxDQUFDLENBQUM7TUFDckIsSUFBSTVCLEtBQUssQ0FBQ1AsSUFBSSxFQUFFbUMsS0FBSyxDQUFDQyxHQUFHLEdBQUc3QixLQUFLLENBQUNQLElBQUk7TUFDdEMsSUFBSU8sS0FBSyxDQUFDTixFQUFFLEVBQUVrQyxLQUFLLENBQUNFLEdBQUcsR0FBRzlCLEtBQUssQ0FBQ04sRUFBRTtNQUNsQ21CLElBQUksQ0FBQ3ZDLElBQUksQ0FBQztRQUFFc0QsS0FBSyxFQUFFO1VBQUV6RixTQUFTLEVBQUV5RjtRQUFNO01BQUUsQ0FBQyxDQUFDO0lBQzVDO0lBRUEsTUFBTUcsVUFBVSxHQUFHO01BQ2pCL0IsS0FBSyxFQUFFYSxJQUFJLENBQUNsQixNQUFNLEdBQUcsQ0FBQyxHQUFHO1FBQUVxQyxJQUFJLEVBQUU7VUFBRW5CO1FBQUs7TUFBRSxDQUFDLEdBQUc7UUFBRW9CLFNBQVMsRUFBRSxDQUFDO01BQUUsQ0FBQztNQUMvREMsSUFBSSxFQUFFLENBQUM7UUFBRS9GLFNBQVMsRUFBRTtVQUFFZ0csS0FBSyxFQUFFO1FBQU87TUFBRSxDQUFDLENBQUM7TUFDeENDLElBQUksRUFBRTFILElBQUksQ0FBQ3lGLEdBQUcsQ0FBQ0gsS0FBSyxDQUFDb0MsSUFBSSxJQUFJLEVBQUUsRUFBRSxHQUFHO0lBQ3RDLENBQUM7SUFFRCxPQUFPLE1BQU1wSCxxQ0FBaUIsQ0FBQ3dILGVBQWUsQ0FBQzFILE1BQU0sRUFBRTRMLHFDQUEwQixFQUFFM0UsVUFBVSxDQUFDO0VBQ2hHOztFQUVBO0VBQ0E7RUFDQTs7RUFFQTtFQUNBLGFBQWE0RSxhQUFhQSxDQUN4QjdMLE1BQVcsRUFDWDhCLE1BQWMsRUFDZGdLLFVBQTRELEVBQzVENUssSUFBWSxFQUNVO0lBQ3RCLE1BQU1xRCxRQUFRLEdBQUcsTUFBTXpFLFdBQVcsQ0FBQ29FLE9BQU8sQ0FBQ2xFLE1BQU0sRUFBRThCLE1BQU0sQ0FBQztJQUMxRCxJQUFJLENBQUN5QyxRQUFRLEVBQUUsT0FBTyxJQUFJO0lBRTFCLE1BQU13SCxhQUF5QixHQUFHO01BQ2hDLEdBQUdELFVBQVU7TUFDYjFLLEVBQUUsRUFBRWhDLElBQUksQ0FBQyxDQUFDO01BQ1Y0TSxRQUFRLEVBQUUsSUFBSXZNLElBQUksQ0FBQyxDQUFDLENBQUM2QixXQUFXLENBQUMsQ0FBQztNQUNsQzJLLFFBQVEsRUFBRS9LO0lBQ1osQ0FBQztJQUVELE1BQU1vSCxRQUFRLEdBQUd4SSxXQUFXLENBQUNrQixjQUFjLENBQUMsa0JBQWtCLEVBQUVFLElBQUksRUFBRTtNQUNwRXdGLElBQUksRUFBRW9GLFVBQVUsQ0FBQ3BGLElBQUk7TUFDckJ3RixLQUFLLEVBQUVKLFVBQVUsQ0FBQ0k7SUFDcEIsQ0FBQyxDQUFDO0lBRUYsTUFBTWhNLHFDQUFpQixDQUFDNEUsY0FBYyxDQUFDOUUsTUFBTSxFQUFFNEIscUJBQVUsRUFBRUUsTUFBTSxFQUFFO01BQ2pFaUIsV0FBVyxFQUFFLENBQUMsR0FBR3dCLFFBQVEsQ0FBQ3hCLFdBQVcsRUFBRWdKLGFBQWEsQ0FBQztNQUNyRDVJLFlBQVksRUFBRSxDQUFDLEdBQUdvQixRQUFRLENBQUNwQixZQUFZLEVBQUVtRixRQUFRLENBQUM7TUFDbEQxRixVQUFVLEVBQUUsSUFBSW5ELElBQUksQ0FBQyxDQUFDLENBQUM2QixXQUFXLENBQUM7SUFDckMsQ0FBQyxDQUFDO0lBRUYsT0FBTyxNQUFNeEIsV0FBVyxDQUFDb0UsT0FBTyxDQUFDbEUsTUFBTSxFQUFFOEIsTUFBTSxDQUFDO0VBQ2xEOztFQUVBO0VBQ0EsYUFBYXFLLGdCQUFnQkEsQ0FDM0JuTSxNQUFXLEVBQ1g4QixNQUFjLEVBQ2RzSyxZQUFvQixFQUNwQmxMLElBQVksRUFDVTtJQUN0QixNQUFNcUQsUUFBUSxHQUFHLE1BQU16RSxXQUFXLENBQUNvRSxPQUFPLENBQUNsRSxNQUFNLEVBQUU4QixNQUFNLENBQUM7SUFDMUQsSUFBSSxDQUFDeUMsUUFBUSxFQUFFLE9BQU8sSUFBSTtJQUUxQixNQUFNOEgsT0FBTyxHQUFHOUgsUUFBUSxDQUFDeEIsV0FBVyxDQUFDbUgsTUFBTSxDQUFFb0MsQ0FBQyxJQUFLQSxDQUFDLENBQUNsTCxFQUFFLEtBQUtnTCxZQUFZLENBQUM7SUFDekUsTUFBTTlELFFBQVEsR0FBR3hJLFdBQVcsQ0FBQ2tCLGNBQWMsQ0FBQyxvQkFBb0IsRUFBRUUsSUFBSSxFQUFFO01BQ3RFcUwsYUFBYSxFQUFFSDtJQUNqQixDQUFDLENBQUM7SUFFRixNQUFNbE0scUNBQWlCLENBQUM0RSxjQUFjLENBQUM5RSxNQUFNLEVBQUU0QixxQkFBVSxFQUFFRSxNQUFNLEVBQUU7TUFDakVpQixXQUFXLEVBQUVzSixPQUFPO01BQ3BCbEosWUFBWSxFQUFFLENBQUMsR0FBR29CLFFBQVEsQ0FBQ3BCLFlBQVksRUFBRW1GLFFBQVEsQ0FBQztNQUNsRDFGLFVBQVUsRUFBRSxJQUFJbkQsSUFBSSxDQUFDLENBQUMsQ0FBQzZCLFdBQVcsQ0FBQztJQUNyQyxDQUFDLENBQUM7SUFFRixPQUFPLE1BQU14QixXQUFXLENBQUNvRSxPQUFPLENBQUNsRSxNQUFNLEVBQUU4QixNQUFNLENBQUM7RUFDbEQ7O0VBRUE7RUFDQTtFQUNBOztFQUVBO0VBQ0EsYUFBYTBLLG1CQUFtQkEsQ0FBQ3hNLE1BQVcsRUFBNkI7SUFDdkUsSUFBSTtNQUNGO01BQ0E7TUFDQSxNQUFNRSxxQ0FBaUIsQ0FBQ3VCLFdBQVcsQ0FBQ3pCLE1BQU0sRUFBRTRCLHFCQUFVLEVBQUVDLDJCQUFZLENBQUM7TUFDckUsT0FBTyxNQUFNL0IsV0FBVyxDQUFDMk0sdUJBQXVCLENBQUN6TSxNQUFNLENBQUM7SUFDMUQsQ0FBQyxDQUFDLE9BQU8wTSxDQUFDLEVBQUU7TUFDVjtNQUNBO01BQ0EsT0FBT25PLHFCQUFxQixDQUFDLENBQUM7SUFDaEM7RUFDRjtFQUVBLGFBQXFCa08sdUJBQXVCQSxDQUFDek0sTUFBVyxFQUE2QjtJQUFBLElBQUEyTSxlQUFBLEVBQUFDLGlCQUFBLEVBQUFDLGlCQUFBLEVBQUFDLGlCQUFBLEVBQUFDLFdBQUEsRUFBQUMscUJBQUEsRUFBQUMsbUJBQUEsRUFBQUMsa0JBQUE7SUFDbkYsTUFBTUMsS0FBSyxHQUFHLElBQUkxTixJQUFJLENBQUMsQ0FBQztJQUN4QjBOLEtBQUssQ0FBQ0MsUUFBUSxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUMxQixNQUFNQyxRQUFRLEdBQUdGLEtBQUssQ0FBQzdMLFdBQVcsQ0FBQyxDQUFDO0lBRXBDLE1BQU1nTSxJQUFJLEdBQUcsTUFBTXBOLHFDQUFpQixDQUFDcU4sa0JBQWtCLENBQUN2TixNQUFNLEVBQUU0QixxQkFBVSxFQUFFO01BQzFFMEwsSUFBSSxFQUFFO1FBQ0pFLFNBQVMsRUFBRTtVQUFFbEgsS0FBSyxFQUFFO1lBQUVtSCxLQUFLLEVBQUUsUUFBUTtZQUFFbkcsSUFBSSxFQUFFO1VBQUc7UUFBRSxDQUFDO1FBQ25EeEksV0FBVyxFQUFFO1VBQUV3SCxLQUFLLEVBQUU7WUFBRW1ILEtBQUssRUFBRSxVQUFVO1lBQUVuRyxJQUFJLEVBQUU7VUFBRztRQUFFLENBQUM7UUFDdkR2SSxXQUFXLEVBQUU7VUFBRXVILEtBQUssRUFBRTtZQUFFbUgsS0FBSyxFQUFFLFVBQVU7WUFBRW5HLElBQUksRUFBRTtVQUFHO1FBQUUsQ0FBQztRQUN2RHRJLFdBQVcsRUFBRTtVQUFFc0gsS0FBSyxFQUFFO1lBQUVtSCxLQUFLLEVBQUUsVUFBVTtZQUFFbkcsSUFBSSxFQUFFO1VBQUc7UUFBRSxDQUFDO1FBQ3ZEb0csbUJBQW1CLEVBQUU7VUFBRUMsR0FBRyxFQUFFO1lBQUVGLEtBQUssRUFBRTtVQUFxQjtRQUFFLENBQUM7UUFDN0RHLGFBQWEsRUFBRTtVQUNiMUQsTUFBTSxFQUFFO1lBQUVwRCxLQUFLLEVBQUU7Y0FBRW5FLFVBQVUsRUFBRTtnQkFBRW9FLEdBQUcsRUFBRXNHO2NBQVM7WUFBRTtVQUFFO1FBQ3JELENBQUM7UUFDRFEsWUFBWSxFQUFFO1VBQ1ozRCxNQUFNLEVBQUU7WUFDTmhELElBQUksRUFBRTtjQUNKbkIsSUFBSSxFQUFFLENBQ0o7Z0JBQUVlLEtBQUssRUFBRTtrQkFBRWpFLFNBQVMsRUFBRTtvQkFBRWtFLEdBQUcsRUFBRXNHO2tCQUFTO2dCQUFFO2NBQUUsQ0FBQyxFQUMzQztnQkFBRS9HLEtBQUssRUFBRTtrQkFBRW5FLE1BQU0sRUFBRSxDQUFDLFVBQVUsRUFBRSxRQUFRO2dCQUFFO2NBQUUsQ0FBQztZQUVqRDtVQUNGO1FBQ0YsQ0FBQztRQUNEc0YsS0FBSyxFQUFFO1VBQUVxRyxXQUFXLEVBQUU7WUFBRUwsS0FBSyxFQUFFO1VBQVU7UUFBRTtNQUM3QztJQUNGLENBQUMsQ0FBQzs7SUFFRjtJQUNBLE1BQU1NLFlBQW9DLEdBQUcsQ0FBQyxDQUFDO0lBQy9DLENBQUMsRUFBQXBCLGVBQUEsR0FBQVcsSUFBSSxDQUFDRSxTQUFTLGNBQUFiLGVBQUEsdUJBQWRBLGVBQUEsQ0FBZ0JxQixPQUFPLEtBQUksRUFBRSxFQUFFQyxPQUFPLENBQUVDLENBQU0sSUFBSztNQUNsREgsWUFBWSxDQUFDRyxDQUFDLENBQUNDLEdBQUcsQ0FBQyxHQUFHRCxDQUFDLENBQUNFLFNBQVM7SUFDbkMsQ0FBQyxDQUFDOztJQUVGO0lBQ0EsTUFBTUMsY0FBc0MsR0FBRyxDQUFDLENBQUM7SUFDakQsQ0FBQyxFQUFBekIsaUJBQUEsR0FBQVUsSUFBSSxDQUFDeE8sV0FBVyxjQUFBOE4saUJBQUEsdUJBQWhCQSxpQkFBQSxDQUFrQm9CLE9BQU8sS0FBSSxFQUFFLEVBQUVDLE9BQU8sQ0FBRUMsQ0FBTSxJQUFLO01BQ3BERyxjQUFjLENBQUNILENBQUMsQ0FBQ0MsR0FBRyxDQUFDLEdBQUdELENBQUMsQ0FBQ0UsU0FBUztJQUNyQyxDQUFDLENBQUM7O0lBRUY7SUFDQSxNQUFNRSxjQUFzQyxHQUFHLENBQUMsQ0FBQztJQUNqRCxDQUFDLEVBQUF6QixpQkFBQSxHQUFBUyxJQUFJLENBQUN2TyxXQUFXLGNBQUE4TixpQkFBQSx1QkFBaEJBLGlCQUFBLENBQWtCbUIsT0FBTyxLQUFJLEVBQUUsRUFBRUMsT0FBTyxDQUFFQyxDQUFNLElBQUs7TUFDcERJLGNBQWMsQ0FBQ0osQ0FBQyxDQUFDQyxHQUFHLENBQUMsR0FBR0QsQ0FBQyxDQUFDRSxTQUFTO0lBQ3JDLENBQUMsQ0FBQzs7SUFFRjtJQUNBLE1BQU1HLGNBQXNDLEdBQUcsQ0FBQyxDQUFDO0lBQ2pELENBQUMsRUFBQXpCLGlCQUFBLEdBQUFRLElBQUksQ0FBQ3RPLFdBQVcsY0FBQThOLGlCQUFBLHVCQUFoQkEsaUJBQUEsQ0FBa0JrQixPQUFPLEtBQUksRUFBRSxFQUFFQyxPQUFPLENBQUVDLENBQU0sSUFBSztNQUNwREssY0FBYyxDQUFDTCxDQUFDLENBQUNDLEdBQUcsQ0FBQyxHQUFHRCxDQUFDLENBQUNFLFNBQVM7SUFDckMsQ0FBQyxDQUFDO0lBRUYsTUFBTUksVUFBVSxHQUFHLEVBQUF6QixXQUFBLEdBQUFPLElBQUksQ0FBQzdGLEtBQUssY0FBQXNGLFdBQUEsdUJBQVZBLFdBQUEsQ0FBWWIsS0FBSyxLQUFJLENBQUM7SUFFekMsT0FBTztNQUNMMU4sV0FBVyxFQUFFZ1EsVUFBVTtNQUN2Qi9QLFVBQVUsRUFBRXNQLFlBQVksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDO01BQ3JDclAsaUJBQWlCLEVBQUVxUCxZQUFZLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQztNQUNuRHBQLGFBQWEsRUFBRW9QLFlBQVksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDO01BQzNDblAsY0FBYyxFQUFFbVAsWUFBWSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUM7TUFDN0NsUCxZQUFZLEVBQUVrUCxZQUFZLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQztNQUN6Q2pQLFdBQVcsRUFBRXVQLGNBQXFCO01BQ2xDdFAsV0FBVyxFQUFFdVAsY0FBcUI7TUFDbEN0UCxXQUFXLEVBQUV1UCxjQUFjO01BQzNCdFAsc0JBQXNCLEVBQUUsRUFBQStOLHFCQUFBLEdBQUFNLElBQUksQ0FBQ0ksbUJBQW1CLGNBQUFWLHFCQUFBLHVCQUF4QkEscUJBQUEsQ0FBMEJkLEtBQUssS0FBSSxJQUFJO01BQy9EaE4sbUJBQW1CLEVBQUUsRUFBQStOLG1CQUFBLEdBQUFLLElBQUksQ0FBQ00sYUFBYSxjQUFBWCxtQkFBQSx1QkFBbEJBLG1CQUFBLENBQW9CbUIsU0FBUyxLQUFJLENBQUM7TUFDdkRqUCxrQkFBa0IsRUFBRSxFQUFBK04sa0JBQUEsR0FBQUksSUFBSSxDQUFDTyxZQUFZLGNBQUFYLGtCQUFBLHVCQUFqQkEsa0JBQUEsQ0FBbUJrQixTQUFTLEtBQUk7SUFDdEQsQ0FBQztFQUNIOztFQUVBO0VBQ0EsYUFBYUssYUFBYUEsQ0FBQ3pPLE1BQVcsRUFBRTBPLElBQVksR0FBRyxFQUFFLEVBQXdCO0lBQUEsSUFBQUMscUJBQUEsRUFBQUMscUJBQUE7SUFDL0UsTUFBTUMsUUFBUSxHQUFHLElBQUlwUCxJQUFJLENBQUMsQ0FBQztJQUMzQm9QLFFBQVEsQ0FBQ0MsT0FBTyxDQUFDRCxRQUFRLENBQUNFLE9BQU8sQ0FBQyxDQUFDLEdBQUdMLElBQUksQ0FBQztJQUUzQyxNQUFNcEIsSUFBSSxHQUFHLE1BQU1wTixxQ0FBaUIsQ0FBQ3FOLGtCQUFrQixDQUFDdk4sTUFBTSxFQUFFNEIscUJBQVUsRUFBRTtNQUMxRXNELEtBQUssRUFBRTtRQUNMNEIsS0FBSyxFQUFFO1VBQUVuRSxVQUFVLEVBQUU7WUFBRW9FLEdBQUcsRUFBRThILFFBQVEsQ0FBQ3ZOLFdBQVcsQ0FBQztVQUFFO1FBQUU7TUFDdkQsQ0FBQztNQUNEZ00sSUFBSSxFQUFFO1FBQ0owQixlQUFlLEVBQUU7VUFDZkMsY0FBYyxFQUFFO1lBQ2R4QixLQUFLLEVBQUUsWUFBWTtZQUNuQnlCLGlCQUFpQixFQUFFO1VBQ3JCO1FBQ0YsQ0FBQztRQUNEQyxnQkFBZ0IsRUFBRTtVQUNoQmpGLE1BQU0sRUFBRTtZQUFFa0YsTUFBTSxFQUFFO2NBQUUzQixLQUFLLEVBQUU7WUFBWTtVQUFFLENBQUM7VUFDMUNILElBQUksRUFBRTtZQUNKK0IsTUFBTSxFQUFFO2NBQ05KLGNBQWMsRUFBRTtnQkFDZHhCLEtBQUssRUFBRSxXQUFXO2dCQUNsQnlCLGlCQUFpQixFQUFFO2NBQ3JCO1lBQ0Y7VUFDRjtRQUNGO01BQ0Y7SUFDRixDQUFDLENBQUM7SUFFRixNQUFNSSxjQUFjLEdBQUcsRUFBQVgscUJBQUEsR0FBQXJCLElBQUksQ0FBQzBCLGVBQWUsY0FBQUwscUJBQUEsdUJBQXBCQSxxQkFBQSxDQUFzQlgsT0FBTyxLQUFJLEVBQUU7SUFDMUQsTUFBTXVCLGFBQWEsR0FBRyxFQUFBWCxxQkFBQSxHQUFBdEIsSUFBSSxDQUFDNkIsZ0JBQWdCLGNBQUFQLHFCQUFBLGdCQUFBQSxxQkFBQSxHQUFyQkEscUJBQUEsQ0FBdUJTLE1BQU0sY0FBQVQscUJBQUEsdUJBQTdCQSxxQkFBQSxDQUErQlosT0FBTyxLQUFJLEVBQUU7O0lBRWxFO0lBQ0EsTUFBTXdCLFNBQWlDLEdBQUcsQ0FBQyxDQUFDO0lBQzVDRCxhQUFhLENBQUN0QixPQUFPLENBQUVDLENBQU0sSUFBSztNQUFBLElBQUF1QixnQkFBQTtNQUNoQyxNQUFNQyxPQUFPLEdBQUcsRUFBQUQsZ0JBQUEsR0FBQXZCLENBQUMsQ0FBQ3lCLGFBQWEsY0FBQUYsZ0JBQUEsdUJBQWZBLGdCQUFBLENBQWlCdkosS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFJLEVBQUU7TUFDcERzSixTQUFTLENBQUNFLE9BQU8sQ0FBQyxHQUFHeEIsQ0FBQyxDQUFDRSxTQUFTO0lBQ2xDLENBQUMsQ0FBQztJQUVGLE9BQU9rQixjQUFjLENBQUNuSixHQUFHLENBQUUrSCxDQUFNLElBQUs7TUFBQSxJQUFBMEIsaUJBQUE7TUFDcEMsTUFBTUYsT0FBTyxHQUFHLEVBQUFFLGlCQUFBLEdBQUExQixDQUFDLENBQUN5QixhQUFhLGNBQUFDLGlCQUFBLHVCQUFmQSxpQkFBQSxDQUFpQjFKLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSSxFQUFFO01BQ3BELE9BQU87UUFDTDJKLElBQUksRUFBRUgsT0FBTztRQUNiSSxPQUFPLEVBQUU1QixDQUFDLENBQUNFLFNBQVM7UUFDcEIyQixNQUFNLEVBQUVQLFNBQVMsQ0FBQ0UsT0FBTyxDQUFDLElBQUk7TUFDaEMsQ0FBQztJQUNILENBQUMsQ0FBQztFQUNKOztFQUVBO0VBQ0E7RUFDQTs7RUFFQTtBQUNGO0FBQ0E7QUFDQTtFQUNFLGFBQWFNLG9CQUFvQkEsQ0FBQ2hRLE1BQVcsRUFBRThLLEtBQVUsRUFBRTVKLElBQVksRUFBd0I7SUFBQSxJQUFBK08sV0FBQSxFQUFBQyxZQUFBLEVBQUFDLFlBQUEsRUFBQUMsWUFBQSxFQUFBQyxZQUFBLEVBQUFDLGFBQUEsRUFBQUMsWUFBQSxFQUFBQyxZQUFBLEVBQUFDLGFBQUE7SUFDN0YsTUFBTUMsTUFBTSxJQUFBVCxXQUFBLEdBQUduRixLQUFLLENBQUM2RixJQUFJLGNBQUFWLFdBQUEsdUJBQVZBLFdBQUEsQ0FBWTdPLEVBQUU7SUFDN0IsTUFBTXdQLE9BQU8sSUFBQVYsWUFBQSxHQUFHcEYsS0FBSyxDQUFDK0YsS0FBSyxjQUFBWCxZQUFBLHVCQUFYQSxZQUFBLENBQWE5TyxFQUFFO0lBQy9CLE1BQU1nSyxPQUFPLEdBQUdOLEtBQUssQ0FBQzFKLEVBQUU7SUFFeEIsSUFBSSxDQUFDc1AsTUFBTSxJQUFJLENBQUNFLE9BQU8sSUFBSSxDQUFDeEYsT0FBTyxFQUFFO01BQ25DLE1BQU0sSUFBSTBGLEtBQUssQ0FBQyx5REFBeUQsQ0FBQztJQUM1RTtJQUVBLE1BQU1DLFdBQXdCLEdBQUc7TUFDL0I5RixRQUFRLEVBQUVHLE9BQU87TUFDakI0RixLQUFLLEVBQUVsRyxLQUFLLENBQUNtRyxNQUFNLElBQUksZ0JBQWdCO01BQ3ZDeEYsT0FBTyxFQUFFeUYsUUFBUSxDQUFDUixNQUFNLEVBQUUsRUFBRSxDQUFDO01BQzdCeEYsZ0JBQWdCLEVBQUUsRUFBQWlGLFlBQUEsR0FBQXJGLEtBQUssQ0FBQzZGLElBQUksY0FBQVIsWUFBQSx1QkFBVkEsWUFBQSxDQUFZak8sV0FBVyxLQUFJLGNBQWM7TUFDM0RpUCxVQUFVLEVBQUUsRUFBQWYsWUFBQSxHQUFBdEYsS0FBSyxDQUFDNkYsSUFBSSxjQUFBUCxZQUFBLHVCQUFWQSxZQUFBLENBQVlnQixLQUFLLEtBQUksQ0FBQztNQUNsQ0MsV0FBVyxFQUFFLEVBQUFoQixZQUFBLEdBQUF2RixLQUFLLENBQUM2RixJQUFJLGNBQUFOLFlBQUEsdUJBQVZBLFlBQUEsQ0FBWWlCLE1BQU0sS0FBSSxFQUFFO01BQ3JDOUYsUUFBUSxFQUFFb0YsT0FBTztNQUNqQlcsVUFBVSxFQUFFLEVBQUFqQixhQUFBLEdBQUF4RixLQUFLLENBQUMrRixLQUFLLGNBQUFQLGFBQUEsdUJBQVhBLGFBQUEsQ0FBYWtCLElBQUksS0FBSSxlQUFlO01BQ2hEblEsU0FBUyxFQUFFeUosS0FBSyxDQUFDekosU0FBUyxJQUFJLElBQUk1QixJQUFJLENBQUMsQ0FBQyxDQUFDNkIsV0FBVyxDQUFDLENBQUM7TUFDdERtUSxRQUFRLEVBQUUzRyxLQUFLLENBQUMyRztJQUNsQixDQUFDOztJQUVEO0lBQ0EsTUFBTXhLLFVBQVUsR0FBRztNQUNqQi9CLEtBQUssRUFBRTtRQUNMZ0MsSUFBSSxFQUFFO1VBQ0puQixJQUFJLEVBQUUsQ0FDSjtZQUFFTyxLQUFLLEVBQUU7Y0FBRW5FLE1BQU0sRUFBRSxDQUFDLE1BQU0sRUFBRSxhQUFhLEVBQUUsU0FBUztZQUFFO1VBQUUsQ0FBQyxFQUN6RDtZQUFFNkQsSUFBSSxFQUFFO2NBQUUseUNBQXlDLEVBQUVwRixNQUFNLENBQUM4UCxNQUFNO1lBQUU7VUFBRSxDQUFDLEVBQ3ZFO1lBQUUxSyxJQUFJLEVBQUU7Y0FBRSwwQ0FBMEMsRUFBRXBGLE1BQU0sQ0FBQ2dRLE9BQU87WUFBRTtVQUFFLENBQUM7UUFFN0U7TUFDRixDQUFDO01BQ0R0SixJQUFJLEVBQUUsQ0FBQztNQUNQRixJQUFJLEVBQUUsQ0FBQztRQUFFekUsVUFBVSxFQUFFO1VBQUUwRSxLQUFLLEVBQUU7UUFBTztNQUFFLENBQUM7SUFDMUMsQ0FBQztJQUVELE1BQU1xSyxZQUFZLEdBQUcsTUFBTXhSLHFDQUFpQixDQUFDd0gsZUFBZSxDQUFDMUgsTUFBTSxFQUFFNEIscUJBQVUsRUFBRXFGLFVBQVUsQ0FBQzs7SUFFNUY7SUFDQSxJQUFJeUssWUFBWSxDQUFDbEssSUFBSSxDQUFDM0MsTUFBTSxHQUFHLENBQUMsRUFBRTtNQUNoQyxNQUFNOE0sWUFBWSxHQUFHRCxZQUFZLENBQUNsSyxJQUFJLENBQUMsQ0FBQyxDQUFDO01BQ3pDLE1BQU0xRixNQUFNLEdBQUc2UCxZQUFZLENBQUNsTyxHQUFHOztNQUUvQjtNQUNBLE1BQU1tTyxhQUFhLEdBQUdELFlBQVksQ0FBQ3ROLE9BQU8sQ0FBQ3ZCLGFBQWEsQ0FBQ2lJLElBQUksQ0FBRUMsQ0FBTSxJQUFLQSxDQUFDLENBQUNDLFFBQVEsS0FBS0csT0FBTyxDQUFDO01BQ2pHLElBQUl3RyxhQUFhLEVBQUU7UUFDaEIsT0FBTztVQUFFeFEsRUFBRSxFQUFFVSxNQUFNO1VBQUUsR0FBRzZQLFlBQVksQ0FBQ3ROO1FBQVEsQ0FBQztNQUNqRDs7TUFFQTtNQUNBLE1BQU1xRyxTQUFTLEdBQUd0TCxJQUFJLENBQUMsQ0FBQztNQUN4QixNQUFNa0wsT0FBb0IsR0FBRztRQUMzQkMsVUFBVSxFQUFFRyxTQUFTO1FBQ3JCRixNQUFNLEVBQUUsbUJBQW1CO1FBQzNCSCxPQUFPLEVBQUcsa0NBQWlDcUcsTUFBTyxhQUFZRSxPQUFRLDBCQUF5QjtRQUMvRmpPLFVBQVUsRUFBRSxJQUFJbEQsSUFBSSxDQUFDLENBQUMsQ0FBQzZCLFdBQVcsQ0FBQztNQUNyQyxDQUFDO01BRUQsTUFBTW1ELFNBQVMsR0FBRztRQUNoQjNCLGFBQWEsRUFBRSxDQUFDLEdBQUc2TyxZQUFZLENBQUN0TixPQUFPLENBQUN2QixhQUFhLEVBQUVpTyxXQUFXLENBQUM7UUFDbkUvTixRQUFRLEVBQUUsQ0FBQyxHQUFHMk8sWUFBWSxDQUFDdE4sT0FBTyxDQUFDckIsUUFBUSxFQUFFc0gsT0FBTyxDQUFDO1FBQ3JEMUgsVUFBVSxFQUFFLElBQUluRCxJQUFJLENBQUMsQ0FBQyxDQUFDNkIsV0FBVyxDQUFDO01BQ3JDLENBQUM7TUFFRCxNQUFNcEIscUNBQWlCLENBQUM0RSxjQUFjLENBQUM5RSxNQUFNLEVBQUU0QixxQkFBVSxFQUFFRSxNQUFNLEVBQUUyQyxTQUFTLENBQUM7TUFDN0UsT0FBTyxNQUFNM0UsV0FBVyxDQUFDb0UsT0FBTyxDQUFDbEUsTUFBTSxFQUFFOEIsTUFBTSxDQUFDO0lBQ2xEOztJQUVBO0lBQ0EsSUFBSU0sUUFBc0IsR0FBRyxLQUFLO0lBQ2xDLE1BQU1nUCxLQUFLLEdBQUcsRUFBQWIsWUFBQSxHQUFBekYsS0FBSyxDQUFDNkYsSUFBSSxjQUFBSixZQUFBLHVCQUFWQSxZQUFBLENBQVlhLEtBQUssS0FBSSxDQUFDO0lBQ3BDLElBQUlBLEtBQUssSUFBSSxFQUFFLEVBQUVoUCxRQUFRLEdBQUcsVUFBVSxDQUFDLEtBQ2xDLElBQUlnUCxLQUFLLElBQUksQ0FBQyxFQUFFaFAsUUFBUSxHQUFHLE1BQU0sQ0FBQyxLQUNsQyxJQUFJZ1AsS0FBSyxJQUFJLENBQUMsRUFBRWhQLFFBQVEsR0FBRyxRQUFRO0lBRXhDLE1BQU1aLE9BQTBCLEdBQUc7TUFDakNTLEtBQUssRUFBRyxlQUFjLEVBQUF1TyxZQUFBLEdBQUExRixLQUFLLENBQUM2RixJQUFJLGNBQUFILFlBQUEsdUJBQVZBLFlBQUEsQ0FBWXRPLFdBQVcsS0FBSSxnQkFBaUIsRUFBQztNQUNuRUEsV0FBVyxFQUFHLHFEQUFvRHdPLE1BQU8sWUFBUyxDQUFBRCxhQUFBLEdBQUUzRixLQUFLLENBQUMrRixLQUFLLGNBQUFKLGFBQUEsdUJBQVhBLGFBQUEsQ0FBYWUsSUFBSyxLQUFJWixPQUFRLGFBQVlRLEtBQU0sWUFBV3RHLEtBQUssQ0FBQzJHLFFBQVEsSUFBSSxLQUFNLEVBQUM7TUFDeEtyUCxRQUFRO01BQ1JDLFFBQVEsRUFBRSxJQUFJO01BQ2RDLFFBQVEsRUFBRSxPQUFPO01BQ2pCRSxJQUFJLEVBQUUsQ0FBQyxXQUFXLEVBQUcsUUFBT2tPLE1BQU8sRUFBQyxFQUFHLFNBQVFFLE9BQVEsRUFBQztJQUMxRCxDQUFDO0lBRUQsTUFBTTdPLE9BQU8sR0FBRyxNQUFNakMsV0FBVyxDQUFDeUIsVUFBVSxDQUFDdkIsTUFBTSxFQUFFd0IsT0FBTyxFQUFFTixJQUFJLENBQUM7O0lBRW5FO0lBQ0EsSUFBSWEsT0FBTyxDQUFDWCxFQUFFLEVBQUU7TUFDYixNQUFNbEIscUNBQWlCLENBQUM0RSxjQUFjLENBQUM5RSxNQUFNLEVBQUU0QixxQkFBVSxFQUFFRyxPQUFPLENBQUNYLEVBQUUsRUFBRTtRQUNyRW1DLGFBQWEsRUFBRTtVQUNic08saUJBQWlCLEVBQUVqUixNQUFNLENBQUM4UCxNQUFNLENBQUM7VUFDakNvQixrQkFBa0IsRUFBRWxSLE1BQU0sQ0FBQ2dRLE9BQU87UUFDcEMsQ0FBQztRQUNEOU4sYUFBYSxFQUFFLENBQUNpTyxXQUFXO01BQzdCLENBQUMsQ0FBQztNQUNGLE9BQU8sTUFBTWpSLFdBQVcsQ0FBQ29FLE9BQU8sQ0FBQ2xFLE1BQU0sRUFBRStCLE9BQU8sQ0FBQ1gsRUFBRSxDQUFDO0lBQ3ZEO0lBRUEsT0FBT1csT0FBTztFQUNoQjtBQUNGO0FBQUNnUSxPQUFBLENBQUFqUyxXQUFBLEdBQUFBLFdBQUEifQ==