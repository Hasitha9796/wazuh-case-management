"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.CaseService = void 0;
var _constants = require("../../common/constants");
var _opensearch_service = require("./opensearch_service");
var _case_mappings = require("../saved_objects/case_mappings");
/*
 * Wazuh Case Management Plugin
 * Case Service — Business logic for case management operations
 *
 * Handles case ID generation, CRUD, status transitions, comments,
 * alert linking, observables, activity logging, and analytics.
 */

/** Empty analytics summary — returned when there are no cases or the index is unavailable. */
function emptyAnalyticsSummary() {
  return {
    total_cases: 0,
    open_cases: 0,
    in_progress_cases: 0,
    waiting_cases: 0,
    resolved_cases: 0,
    closed_cases: 0,
    by_severity: {},
    by_priority: {},
    by_category: {},
    avg_resolution_time_ms: null,
    cases_created_today: 0,
    cases_closed_today: 0
  };
}

/** Generate a UUID v4 without dashes (compact) */
function uuid() {
  // Use crypto.randomUUID if available, fallback to manual
  try {
    return crypto.randomUUID().replace(/-/g, '').substring(0, 12);
  } catch {
    return Date.now().toString(36) + Math.random().toString(36).substring(2, 8);
  }
}

/**
 * CaseService — all case management business logic.
 * Methods are static; the OpenSearch client is passed in per-request.
 */
class CaseService {
  // ──────────────────────────────────────────────────────────────
  // Case ID Generation
  // ──────────────────────────────────────────────────────────────

  /**
   * Generate the next human-readable case ID.
   * Format: CASE-2026-0001
   */
  static async generateCaseId(client) {
    const counter = await _opensearch_service.OpenSearchService.getNextCounterValue(client);
    const year = new Date().getFullYear();
    const paddedNum = String(counter).padStart(4, '0');
    return `${_constants.CASE_ID_PREFIX}${_constants.CASE_ID_SEPARATOR}${year}${_constants.CASE_ID_SEPARATOR}${paddedNum}`;
  }

  // ──────────────────────────────────────────────────────────────
  // Activity Log Helper
  // ──────────────────────────────────────────────────────────────

  static createActivity(action, user, details) {
    return {
      id: uuid(),
      action,
      user,
      timestamp: new Date().toISOString(),
      details
    };
  }

  // ──────────────────────────────────────────────────────────────
  // Case CRUD
  // ──────────────────────────────────────────────────────────────

  /** Create a new case */
  static async createCase(client, payload, user) {
    // Auto-heal: make sure the indices exist with the correct mapping before writing,
    // so deleting an index and then creating a case restores the proper schema.
    await _opensearch_service.OpenSearchService.ensureIndex(client, _constants.CASE_COUNTER_INDEX, _case_mappings.counterMappings);
    await _opensearch_service.OpenSearchService.ensureIndex(client, _constants.CASE_INDEX, _case_mappings.caseMappings);
    const caseId = await CaseService.generateCaseId(client);
    const now = new Date().toISOString();
    const newCase = {
      case_id: caseId,
      title: payload.title,
      description: payload.description,
      status: 'open',
      severity: payload.severity,
      priority: payload.priority,
      category: payload.category,
      tlp: payload.tlp || 'WHITE',
      tags: payload.tags || [],
      assignee: payload.assignee || null,
      created_by: user,
      created_at: now,
      updated_at: now,
      closed_at: null,
      linked_alerts: [],
      observables: [],
      comments: [],
      tasks: [],
      notes: '',
      activity_log: [CaseService.createActivity('case_created', user, {
        case_id: caseId,
        title: payload.title
      })],
      resolution_summary: null,
      time_to_resolve_ms: null,
      related_cases: [],
      custom_fields: {}
    };

    // If an assignee was provided, log the assignment
    if (payload.assignee) {
      newCase.activity_log.push(CaseService.createActivity('assigned', user, {
        assignee: payload.assignee
      }));
    }
    const {
      _id
    } = await _opensearch_service.OpenSearchService.createDocument(client, _constants.CASE_INDEX, newCase);
    newCase.id = _id;
    return newCase;
  }

  /** Get a single case by its OpenSearch _id */
  static async getCase(client, id) {
    const doc = await _opensearch_service.OpenSearchService.getDocument(client, _constants.CASE_INDEX, id);
    if (!doc) return null;
    return {
      id: doc._id,
      ...doc._source
    };
  }

  /** Update a case (partial update) */
  static async updateCase(client, id, payload, user) {
    const existing = await CaseService.getCase(client, id);
    if (!existing) return null;
    const now = new Date().toISOString();
    const activities = [];
    const updateDoc = {
      updated_at: now
    };

    // Track changes for activity log
    if (payload.title !== undefined && payload.title !== existing.title) {
      updateDoc.title = payload.title;
    }
    if (payload.description !== undefined) {
      updateDoc.description = payload.description;
    }
    if (payload.severity !== undefined && payload.severity !== existing.severity) {
      updateDoc.severity = payload.severity;
      activities.push(CaseService.createActivity('severity_changed', user, {
        from: existing.severity,
        to: payload.severity
      }));
    }
    if (payload.priority !== undefined && payload.priority !== existing.priority) {
      updateDoc.priority = payload.priority;
      activities.push(CaseService.createActivity('priority_changed', user, {
        from: existing.priority,
        to: payload.priority
      }));
    }
    if (payload.category !== undefined) {
      updateDoc.category = payload.category;
    }
    if (payload.tlp !== undefined) {
      updateDoc.tlp = payload.tlp;
    }
    if (payload.tags !== undefined) {
      updateDoc.tags = payload.tags;
    }
    if (payload.assignee !== undefined && payload.assignee !== existing.assignee) {
      updateDoc.assignee = payload.assignee;
      activities.push(CaseService.createActivity(payload.assignee ? 'assigned' : 'unassigned', user, {
        from: existing.assignee,
        to: payload.assignee
      }));
    }
    if (payload.resolution_summary !== undefined) {
      updateDoc.resolution_summary = payload.resolution_summary;
    }

    // Append activities
    if (activities.length > 0) {
      updateDoc.activity_log = [...existing.activity_log, ...activities];
    }
    await _opensearch_service.OpenSearchService.updateDocument(client, _constants.CASE_INDEX, id, updateDoc);
    return await CaseService.getCase(client, id);
  }

  /** Delete a case by OpenSearch _id */
  static async deleteCase(client, id) {
    return await _opensearch_service.OpenSearchService.deleteDocument(client, _constants.CASE_INDEX, id);
  }

  /** List cases with filtering, pagination, and sorting */
  static async listCases(client, query) {
    const page = query.page || 1;
    const perPage = Math.min(query.per_page || _constants.DEFAULT_PAGE_SIZE, _constants.MAX_PAGE_SIZE);
    const sortField = query.sort_field || _constants.DEFAULT_SORT_FIELD;
    const sortOrder = query.sort_order || _constants.DEFAULT_SORT_ORDER;

    // Build the query
    const must = [];
    if (query.status) {
      must.push({
        term: {
          status: query.status
        }
      });
    }
    if (query.severity) {
      must.push({
        term: {
          severity: query.severity
        }
      });
    }
    if (query.priority) {
      must.push({
        term: {
          priority: query.priority
        }
      });
    }
    if (query.category) {
      must.push({
        term: {
          category: query.category
        }
      });
    }
    if (query.assignee) {
      must.push({
        term: {
          assignee: query.assignee
        }
      });
    }
    if (query.tags) {
      const tagList = query.tags.split(',').map(t => t.trim());
      must.push({
        terms: {
          tags: tagList
        }
      });
    }
    if (query.search) {
      must.push({
        multi_match: {
          query: query.search,
          fields: ['title^3', 'description', 'case_id^2', 'tags'],
          type: 'best_fields',
          fuzziness: 'AUTO'
        }
      });
    }
    if (query.created_from || query.created_to) {
      const range = {};
      if (query.created_from) range.gte = query.created_from;
      if (query.created_to) range.lte = query.created_to;
      must.push({
        range: {
          created_at: range
        }
      });
    }
    const searchBody = {
      query: must.length > 0 ? {
        bool: {
          must
        }
      } : {
        match_all: {}
      },
      sort: [{
        [sortField]: {
          order: sortOrder
        }
      }],
      from: (page - 1) * perPage,
      size: perPage,
      // Exclude heavy nested fields from listing to improve perf
      _source: {
        excludes: ['activity_log', 'comments.content']
      }
    };
    const {
      hits,
      total
    } = await _opensearch_service.OpenSearchService.searchDocuments(client, _constants.CASE_INDEX, searchBody);
    const cases = hits.map(hit => ({
      id: hit._id,
      ...hit._source
    }));
    return {
      cases,
      total,
      page,
      per_page: perPage
    };
  }

  // ──────────────────────────────────────────────────────────────
  // Status Management
  // ──────────────────────────────────────────────────────────────

  /** Change case status with transition validation */
  static async changeStatus(client, id, newStatus, user) {
    const existing = await CaseService.getCase(client, id);
    if (!existing) {
      return {
        success: false,
        error: 'Case not found'
      };
    }

    // Validate transition
    const allowedTransitions = _constants.STATUS_TRANSITIONS[existing.status] || [];
    if (!allowedTransitions.includes(newStatus)) {
      return {
        success: false,
        error: `Cannot transition from '${existing.status}' to '${newStatus}'. Allowed: ${allowedTransitions.join(', ')}`
      };
    }
    const now = new Date().toISOString();
    const updateDoc = {
      status: newStatus,
      updated_at: now
    };

    // Handle closing
    if (newStatus === 'closed' || newStatus === 'resolved') {
      updateDoc.closed_at = now;
      if (existing.created_at) {
        updateDoc.time_to_resolve_ms = new Date(now).getTime() - new Date(existing.created_at).getTime();
      }
    }

    // Handle reopening
    if (newStatus === 'open' && (existing.status === 'closed' || existing.status === 'resolved')) {
      updateDoc.closed_at = null;
      updateDoc.time_to_resolve_ms = null;
    }

    // Activity
    const activity = CaseService.createActivity(newStatus === 'closed' ? 'case_closed' : newStatus === 'open' && existing.status === 'closed' ? 'case_reopened' : 'status_changed', user, {
      from: existing.status,
      to: newStatus
    });
    updateDoc.activity_log = [...existing.activity_log, activity];
    await _opensearch_service.OpenSearchService.updateDocument(client, _constants.CASE_INDEX, id, updateDoc);
    const updatedCase = await CaseService.getCase(client, id);
    return {
      success: true,
      case: updatedCase
    };
  }

  /** Assign a case to a user */
  static async assignCase(client, id, assignee, user) {
    const existing = await CaseService.getCase(client, id);
    if (!existing) return null;
    const activity = CaseService.createActivity(assignee ? 'assigned' : 'unassigned', user, {
      from: existing.assignee,
      to: assignee
    });
    await _opensearch_service.OpenSearchService.updateDocument(client, _constants.CASE_INDEX, id, {
      assignee,
      updated_at: new Date().toISOString(),
      activity_log: [...existing.activity_log, activity]
    });
    return await CaseService.getCase(client, id);
  }

  // ──────────────────────────────────────────────────────────────
  // Tasks
  // ──────────────────────────────────────────────────────────────

  /** Add a task to a case */
  static async addTask(client, caseId, title, user) {
    const existing = await CaseService.getCase(client, caseId);
    if (!existing) return null;
    const newTask = {
      task_id: uuid(),
      title,
      completed: false,
      created_at: new Date().toISOString()
    };
    const updateDoc = {
      tasks: [...(existing.tasks || []), newTask],
      updated_at: new Date().toISOString()
    };
    await _opensearch_service.OpenSearchService.updateDocument(client, _constants.CASE_INDEX, caseId, updateDoc);
    return await CaseService.getCase(client, caseId);
  }

  /** Toggle task completion */
  static async toggleTask(client, caseId, taskId, completed, user) {
    const existing = await CaseService.getCase(client, caseId);
    if (!existing) return null;
    const tasks = (existing.tasks || []).map(t => t.task_id === taskId ? {
      ...t,
      completed,
      completed_at: completed ? new Date().toISOString() : undefined
    } : t);
    const updateDoc = {
      tasks,
      updated_at: new Date().toISOString()
    };
    await _opensearch_service.OpenSearchService.updateDocument(client, _constants.CASE_INDEX, caseId, updateDoc);
    return await CaseService.getCase(client, caseId);
  }

  /** Remove a task */
  static async removeTask(client, caseId, taskId, user) {
    const existing = await CaseService.getCase(client, caseId);
    if (!existing) return null;
    const tasks = (existing.tasks || []).filter(t => t.task_id !== taskId);
    const updateDoc = {
      tasks,
      updated_at: new Date().toISOString()
    };
    await _opensearch_service.OpenSearchService.updateDocument(client, _constants.CASE_INDEX, caseId, updateDoc);
    return await CaseService.getCase(client, caseId);
  }

  // ──────────────────────────────────────────────────────────────
  // Notes
  // ──────────────────────────────────────────────────────────────

  /** Update case notes */
  static async updateNotes(client, caseId, notes, user) {
    const existing = await CaseService.getCase(client, caseId);
    if (!existing) return null;
    const updateDoc = {
      notes,
      updated_at: new Date().toISOString()
    };
    await _opensearch_service.OpenSearchService.updateDocument(client, _constants.CASE_INDEX, caseId, updateDoc);
    return await CaseService.getCase(client, caseId);
  }

  // ──────────────────────────────────────────────────────────────
  // Comments
  // ──────────────────────────────────────────────────────────────

  /** Add a comment to a case */
  static async addComment(client, caseId, content, user) {
    const existing = await CaseService.getCase(client, caseId);
    if (!existing) return null;
    const comment = {
      comment_id: uuid(),
      author: user,
      content,
      created_at: new Date().toISOString()
    };
    const activity = CaseService.createActivity('comment_added', user, {
      comment_id: comment.comment_id
    });
    await _opensearch_service.OpenSearchService.updateDocument(client, _constants.CASE_INDEX, caseId, {
      comments: [...existing.comments, comment],
      activity_log: [...existing.activity_log, activity],
      updated_at: new Date().toISOString()
    });
    return await CaseService.getCase(client, caseId);
  }

  /** Delete a comment from a case */
  static async deleteComment(client, caseId, commentId, user) {
    const existing = await CaseService.getCase(client, caseId);
    if (!existing) return null;
    const updatedComments = existing.comments.filter(c => c.comment_id !== commentId);
    if (updatedComments.length === existing.comments.length) {
      return existing; // Comment not found, no change
    }

    const activity = CaseService.createActivity('comment_deleted', user, {
      comment_id: commentId
    });
    await _opensearch_service.OpenSearchService.updateDocument(client, _constants.CASE_INDEX, caseId, {
      comments: updatedComments,
      activity_log: [...existing.activity_log, activity],
      updated_at: new Date().toISOString()
    });
    return await CaseService.getCase(client, caseId);
  }

  // ──────────────────────────────────────────────────────────────
  // Alert Linking
  // ──────────────────────────────────────────────────────────────

  /** Link an alert to a case */
  static async linkAlert(client, caseId, alert, user) {
    const existing = await CaseService.getCase(client, caseId);
    if (!existing) return null;

    // Check for duplicate
    if (existing.linked_alerts.some(a => a.alert_id === alert.alert_id)) {
      return existing; // Already linked
    }

    const activity = CaseService.createActivity('alert_linked', user, {
      alert_id: alert.alert_id,
      rule_description: alert.rule_description
    });
    await _opensearch_service.OpenSearchService.updateDocument(client, _constants.CASE_INDEX, caseId, {
      linked_alerts: [...existing.linked_alerts, alert],
      activity_log: [...existing.activity_log, activity],
      updated_at: new Date().toISOString()
    });
    return await CaseService.getCase(client, caseId);
  }

  /** Unlink an alert from a case */
  static async unlinkAlert(client, caseId, alertId, user) {
    const existing = await CaseService.getCase(client, caseId);
    if (!existing) return null;
    const updatedAlerts = existing.linked_alerts.filter(a => a.alert_id !== alertId);
    const activity = CaseService.createActivity('alert_unlinked', user, {
      alert_id: alertId
    });
    await _opensearch_service.OpenSearchService.updateDocument(client, _constants.CASE_INDEX, caseId, {
      linked_alerts: updatedAlerts,
      activity_log: [...existing.activity_log, activity],
      updated_at: new Date().toISOString()
    });
    return await CaseService.getCase(client, caseId);
  }

  /** Search Wazuh alerts in OpenSearch */
  static async searchAlerts(client, query) {
    const must = [];
    if (query.search) {
      must.push({
        multi_match: {
          query: query.search,
          fields: ['rule.description^2', 'full_log', 'data.*'],
          fuzziness: 'AUTO',
          // data.* spans non-text fields (date/ip/number); lenient skips them
          // instead of throwing query_shard_exception (400 Bad Request).
          lenient: true
        }
      });
    }
    if (query.agent_id) {
      must.push({
        term: {
          'agent.id': query.agent_id
        }
      });
    }
    if (query.rule_id) {
      must.push({
        term: {
          'rule.id': String(query.rule_id)
        }
      });
    }
    if (query.level_min || query.level_max) {
      const range = {};
      if (query.level_min) range.gte = query.level_min;
      if (query.level_max) range.lte = query.level_max;
      must.push({
        range: {
          'rule.level': range
        }
      });
    }
    if (query.from || query.to) {
      const range = {};
      if (query.from) range.gte = query.from;
      if (query.to) range.lte = query.to;
      must.push({
        range: {
          timestamp: range
        }
      });
    }
    const searchBody = {
      query: must.length > 0 ? {
        bool: {
          must
        }
      } : {
        match_all: {}
      },
      sort: [{
        timestamp: {
          order: 'desc'
        }
      }],
      size: Math.min(query.size || 50, 100)
    };
    return await _opensearch_service.OpenSearchService.searchDocuments(client, _constants.WAZUH_ALERTS_INDEX_PATTERN, searchBody);
  }

  // ──────────────────────────────────────────────────────────────
  // Observables
  // ──────────────────────────────────────────────────────────────

  /** Add an observable to a case */
  static async addObservable(client, caseId, observable, user) {
    const existing = await CaseService.getCase(client, caseId);
    if (!existing) return null;
    const newObservable = {
      ...observable,
      id: uuid(),
      added_at: new Date().toISOString(),
      added_by: user
    };
    const activity = CaseService.createActivity('observable_added', user, {
      type: observable.type,
      value: observable.value
    });
    await _opensearch_service.OpenSearchService.updateDocument(client, _constants.CASE_INDEX, caseId, {
      observables: [...existing.observables, newObservable],
      activity_log: [...existing.activity_log, activity],
      updated_at: new Date().toISOString()
    });
    return await CaseService.getCase(client, caseId);
  }

  /** Remove an observable from a case */
  static async removeObservable(client, caseId, observableId, user) {
    const existing = await CaseService.getCase(client, caseId);
    if (!existing) return null;
    const updated = existing.observables.filter(o => o.id !== observableId);
    const activity = CaseService.createActivity('observable_removed', user, {
      observable_id: observableId
    });
    await _opensearch_service.OpenSearchService.updateDocument(client, _constants.CASE_INDEX, caseId, {
      observables: updated,
      activity_log: [...existing.activity_log, activity],
      updated_at: new Date().toISOString()
    });
    return await CaseService.getCase(client, caseId);
  }

  // ──────────────────────────────────────────────────────────────
  // Analytics
  // ──────────────────────────────────────────────────────────────

  /** Get summary analytics for the dashboard */
  static async getAnalyticsSummary(client) {
    try {
      // Self-heal: if the index was deleted, recreate it with the correct mapping
      // (keyword fields) so aggregations don't fail with a 400.
      await _opensearch_service.OpenSearchService.ensureIndex(client, _constants.CASE_INDEX, _case_mappings.caseMappings);
      return await CaseService.computeAnalyticsSummary(client);
    } catch (e) {
      // Never surface a raw 400/aggregation error to the dashboard — return an
      // empty summary so the UI shows an empty state instead of "Bad Request".
      return emptyAnalyticsSummary();
    }
  }
  static async computeAnalyticsSummary(client) {
    var _aggs$by_status, _aggs$by_severity, _aggs$by_priority, _aggs$by_category, _aggs$total, _aggs$avg_resolution_, _aggs$created_today, _aggs$closed_today;
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const todayStr = today.toISOString();
    const aggs = await _opensearch_service.OpenSearchService.aggregateDocuments(client, _constants.CASE_INDEX, {
      aggs: {
        by_status: {
          terms: {
            field: 'status',
            size: 10
          }
        },
        by_severity: {
          terms: {
            field: 'severity',
            size: 10
          }
        },
        by_priority: {
          terms: {
            field: 'priority',
            size: 10
          }
        },
        by_category: {
          terms: {
            field: 'category',
            size: 20
          }
        },
        avg_resolution_time: {
          avg: {
            field: 'time_to_resolve_ms'
          }
        },
        created_today: {
          filter: {
            range: {
              created_at: {
                gte: todayStr
              }
            }
          }
        },
        closed_today: {
          filter: {
            bool: {
              must: [{
                range: {
                  closed_at: {
                    gte: todayStr
                  }
                }
              }, {
                terms: {
                  status: ['resolved', 'closed']
                }
              }]
            }
          }
        },
        total: {
          value_count: {
            field: 'case_id'
          }
        }
      }
    });

    // Parse status counts
    const statusCounts = {};
    (((_aggs$by_status = aggs.by_status) === null || _aggs$by_status === void 0 ? void 0 : _aggs$by_status.buckets) || []).forEach(b => {
      statusCounts[b.key] = b.doc_count;
    });

    // Parse severity counts
    const severityCounts = {};
    (((_aggs$by_severity = aggs.by_severity) === null || _aggs$by_severity === void 0 ? void 0 : _aggs$by_severity.buckets) || []).forEach(b => {
      severityCounts[b.key] = b.doc_count;
    });

    // Parse priority counts
    const priorityCounts = {};
    (((_aggs$by_priority = aggs.by_priority) === null || _aggs$by_priority === void 0 ? void 0 : _aggs$by_priority.buckets) || []).forEach(b => {
      priorityCounts[b.key] = b.doc_count;
    });

    // Parse category counts
    const categoryCounts = {};
    (((_aggs$by_category = aggs.by_category) === null || _aggs$by_category === void 0 ? void 0 : _aggs$by_category.buckets) || []).forEach(b => {
      categoryCounts[b.key] = b.doc_count;
    });
    const totalCases = ((_aggs$total = aggs.total) === null || _aggs$total === void 0 ? void 0 : _aggs$total.value) || 0;
    return {
      total_cases: totalCases,
      open_cases: statusCounts['open'] || 0,
      in_progress_cases: statusCounts['in_progress'] || 0,
      waiting_cases: statusCounts['waiting'] || 0,
      resolved_cases: statusCounts['resolved'] || 0,
      closed_cases: statusCounts['closed'] || 0,
      by_severity: severityCounts,
      by_priority: priorityCounts,
      by_category: categoryCounts,
      avg_resolution_time_ms: ((_aggs$avg_resolution_ = aggs.avg_resolution_time) === null || _aggs$avg_resolution_ === void 0 ? void 0 : _aggs$avg_resolution_.value) || null,
      cases_created_today: ((_aggs$created_today = aggs.created_today) === null || _aggs$created_today === void 0 ? void 0 : _aggs$created_today.doc_count) || 0,
      cases_closed_today: ((_aggs$closed_today = aggs.closed_today) === null || _aggs$closed_today === void 0 ? void 0 : _aggs$closed_today.doc_count) || 0
    };
  }

  /** Get case trends over the last N days */
  static async getCaseTrends(client, days = 30) {
    var _aggs$cases_over_time, _aggs$closed_over_tim;
    const fromDate = new Date();
    fromDate.setDate(fromDate.getDate() - days);
    const aggs = await _opensearch_service.OpenSearchService.aggregateDocuments(client, _constants.CASE_INDEX, {
      query: {
        range: {
          created_at: {
            gte: fromDate.toISOString()
          }
        }
      },
      aggs: {
        cases_over_time: {
          date_histogram: {
            field: 'created_at',
            calendar_interval: 'day'
          }
        },
        closed_over_time: {
          filter: {
            exists: {
              field: 'closed_at'
            }
          },
          aggs: {
            by_day: {
              date_histogram: {
                field: 'closed_at',
                calendar_interval: 'day'
              }
            }
          }
        }
      }
    });
    const createdBuckets = ((_aggs$cases_over_time = aggs.cases_over_time) === null || _aggs$cases_over_time === void 0 ? void 0 : _aggs$cases_over_time.buckets) || [];
    const closedBuckets = ((_aggs$closed_over_tim = aggs.closed_over_time) === null || _aggs$closed_over_tim === void 0 || (_aggs$closed_over_tim = _aggs$closed_over_tim.by_day) === null || _aggs$closed_over_tim === void 0 ? void 0 : _aggs$closed_over_tim.buckets) || [];

    // Merge created and closed into a single timeline
    const closedMap = {};
    closedBuckets.forEach(b => {
      var _b$key_as_string;
      const dateKey = ((_b$key_as_string = b.key_as_string) === null || _b$key_as_string === void 0 ? void 0 : _b$key_as_string.split('T')[0]) || '';
      closedMap[dateKey] = b.doc_count;
    });
    return createdBuckets.map(b => {
      var _b$key_as_string2;
      const dateKey = ((_b$key_as_string2 = b.key_as_string) === null || _b$key_as_string2 === void 0 ? void 0 : _b$key_as_string2.split('T')[0]) || '';
      return {
        date: dateKey,
        created: b.doc_count,
        closed: closedMap[dateKey] || 0
      };
    });
  }

  // ──────────────────────────────────────────────────────────────
  // Automated Alert Handling (Webhooks)
  // ──────────────────────────────────────────────────────────────

  /**
   * Process an incoming alert from a Wazuh webhook.
   * Performs deduplication based on rule.id and agent.id for unresolved cases.
   */
  static async handleAutomatedAlert(client, alert, user) {
    var _alert$rule, _alert$agent, _alert$rule2, _alert$rule3, _alert$rule4, _alert$agent2, _alert$rule5, _alert$rule6, _alert$agent3;
    const ruleId = (_alert$rule = alert.rule) === null || _alert$rule === void 0 ? void 0 : _alert$rule.id;
    const agentId = (_alert$agent = alert.agent) === null || _alert$agent === void 0 ? void 0 : _alert$agent.id;
    const alertId = alert.id;
    if (!ruleId || !agentId || !alertId) {
      throw new Error('Invalid alert payload: Missing rule.id, agent.id, or id');
    }
    const linkedAlert = {
      alert_id: alertId,
      index: alert._index || 'wazuh-alerts-*',
      rule_id: parseInt(ruleId, 10),
      rule_description: ((_alert$rule2 = alert.rule) === null || _alert$rule2 === void 0 ? void 0 : _alert$rule2.description) || 'Unknown Rule',
      rule_level: ((_alert$rule3 = alert.rule) === null || _alert$rule3 === void 0 ? void 0 : _alert$rule3.level) || 0,
      rule_groups: ((_alert$rule4 = alert.rule) === null || _alert$rule4 === void 0 ? void 0 : _alert$rule4.groups) || [],
      agent_id: agentId,
      agent_name: ((_alert$agent2 = alert.agent) === null || _alert$agent2 === void 0 ? void 0 : _alert$agent2.name) || 'Unknown Agent',
      timestamp: alert.timestamp || new Date().toISOString(),
      full_log: alert.full_log
    };

    // Search for an unresolved case with the exact same rule and agent
    const searchBody = {
      query: {
        bool: {
          must: [{
            terms: {
              status: ['open', 'in_progress', 'waiting']
            }
          }, {
            term: {
              'custom_fields.automated_rule_id.keyword': String(ruleId)
            }
          }, {
            term: {
              'custom_fields.automated_agent_id.keyword': String(agentId)
            }
          }]
        }
      },
      size: 1,
      sort: [{
        created_at: {
          order: 'desc'
        }
      }]
    };
    const searchResult = await _opensearch_service.OpenSearchService.searchDocuments(client, _constants.CASE_INDEX, searchBody);

    // IF DUPLICATE FOUND: Append alert and add comment
    if (searchResult.hits.length > 0) {
      const existingCase = searchResult.hits[0];
      const caseId = existingCase._id;

      // Avoid linking the exact same alert twice
      const alreadyLinked = existingCase._source.linked_alerts.some(a => a.alert_id === alertId);
      if (alreadyLinked) {
        return {
          id: caseId,
          ...existingCase._source
        };
      }

      // Add automated comment
      const commentId = uuid();
      const comment = {
        comment_id: commentId,
        author: 'System Automation',
        content: `Duplicate alert detected (Rule ${ruleId} on Agent ${agentId}). Automatically linked.`,
        created_at: new Date().toISOString()
      };
      const updateDoc = {
        linked_alerts: [...existingCase._source.linked_alerts, linkedAlert],
        comments: [...existingCase._source.comments, comment],
        updated_at: new Date().toISOString()
      };
      await _opensearch_service.OpenSearchService.updateDocument(client, _constants.CASE_INDEX, caseId, updateDoc);
      return await CaseService.getCase(client, caseId);
    }

    // IF NO DUPLICATE: Create new case
    let severity = 'low';
    const level = ((_alert$rule5 = alert.rule) === null || _alert$rule5 === void 0 ? void 0 : _alert$rule5.level) || 0;
    if (level >= 12) severity = 'critical';else if (level >= 8) severity = 'high';else if (level >= 5) severity = 'medium';
    const payload = {
      title: `[Automated] ${((_alert$rule6 = alert.rule) === null || _alert$rule6 === void 0 ? void 0 : _alert$rule6.description) || 'Security Alert'}`,
      description: `Automated case created from Wazuh Alert.\n\nRule: ${ruleId}\nAgent: ${(_alert$agent3 = alert.agent) === null || _alert$agent3 === void 0 ? void 0 : _alert$agent3.name} (${agentId})\nLevel: ${level}\n\nLog: ${alert.full_log || 'N/A'}`,
      severity,
      priority: 'P2',
      category: 'other',
      tags: ['automated', `rule_${ruleId}`, `agent_${agentId}`]
    };
    const newCase = await CaseService.createCase(client, payload, user);

    // Add custom fields for deduplication tracking
    if (newCase.id) {
      await _opensearch_service.OpenSearchService.updateDocument(client, _constants.CASE_INDEX, newCase.id, {
        custom_fields: {
          automated_rule_id: String(ruleId),
          automated_agent_id: String(agentId)
        },
        linked_alerts: [linkedAlert]
      });
      return await CaseService.getCase(client, newCase.id);
    }
    return newCase;
  }
}
exports.CaseService = CaseService;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfY29uc3RhbnRzIiwicmVxdWlyZSIsIl9vcGVuc2VhcmNoX3NlcnZpY2UiLCJfY2FzZV9tYXBwaW5ncyIsImVtcHR5QW5hbHl0aWNzU3VtbWFyeSIsInRvdGFsX2Nhc2VzIiwib3Blbl9jYXNlcyIsImluX3Byb2dyZXNzX2Nhc2VzIiwid2FpdGluZ19jYXNlcyIsInJlc29sdmVkX2Nhc2VzIiwiY2xvc2VkX2Nhc2VzIiwiYnlfc2V2ZXJpdHkiLCJieV9wcmlvcml0eSIsImJ5X2NhdGVnb3J5IiwiYXZnX3Jlc29sdXRpb25fdGltZV9tcyIsImNhc2VzX2NyZWF0ZWRfdG9kYXkiLCJjYXNlc19jbG9zZWRfdG9kYXkiLCJ1dWlkIiwiY3J5cHRvIiwicmFuZG9tVVVJRCIsInJlcGxhY2UiLCJzdWJzdHJpbmciLCJEYXRlIiwibm93IiwidG9TdHJpbmciLCJNYXRoIiwicmFuZG9tIiwiQ2FzZVNlcnZpY2UiLCJnZW5lcmF0ZUNhc2VJZCIsImNsaWVudCIsImNvdW50ZXIiLCJPcGVuU2VhcmNoU2VydmljZSIsImdldE5leHRDb3VudGVyVmFsdWUiLCJ5ZWFyIiwiZ2V0RnVsbFllYXIiLCJwYWRkZWROdW0iLCJTdHJpbmciLCJwYWRTdGFydCIsIkNBU0VfSURfUFJFRklYIiwiQ0FTRV9JRF9TRVBBUkFUT1IiLCJjcmVhdGVBY3Rpdml0eSIsImFjdGlvbiIsInVzZXIiLCJkZXRhaWxzIiwiaWQiLCJ0aW1lc3RhbXAiLCJ0b0lTT1N0cmluZyIsImNyZWF0ZUNhc2UiLCJwYXlsb2FkIiwiZW5zdXJlSW5kZXgiLCJDQVNFX0NPVU5URVJfSU5ERVgiLCJjb3VudGVyTWFwcGluZ3MiLCJDQVNFX0lOREVYIiwiY2FzZU1hcHBpbmdzIiwiY2FzZUlkIiwibmV3Q2FzZSIsImNhc2VfaWQiLCJ0aXRsZSIsImRlc2NyaXB0aW9uIiwic3RhdHVzIiwic2V2ZXJpdHkiLCJwcmlvcml0eSIsImNhdGVnb3J5IiwidGxwIiwidGFncyIsImFzc2lnbmVlIiwiY3JlYXRlZF9ieSIsImNyZWF0ZWRfYXQiLCJ1cGRhdGVkX2F0IiwiY2xvc2VkX2F0IiwibGlua2VkX2FsZXJ0cyIsIm9ic2VydmFibGVzIiwiY29tbWVudHMiLCJ0YXNrcyIsIm5vdGVzIiwiYWN0aXZpdHlfbG9nIiwicmVzb2x1dGlvbl9zdW1tYXJ5IiwidGltZV90b19yZXNvbHZlX21zIiwicmVsYXRlZF9jYXNlcyIsImN1c3RvbV9maWVsZHMiLCJwdXNoIiwiX2lkIiwiY3JlYXRlRG9jdW1lbnQiLCJnZXRDYXNlIiwiZG9jIiwiZ2V0RG9jdW1lbnQiLCJfc291cmNlIiwidXBkYXRlQ2FzZSIsImV4aXN0aW5nIiwiYWN0aXZpdGllcyIsInVwZGF0ZURvYyIsInVuZGVmaW5lZCIsImZyb20iLCJ0byIsImxlbmd0aCIsInVwZGF0ZURvY3VtZW50IiwiZGVsZXRlQ2FzZSIsImRlbGV0ZURvY3VtZW50IiwibGlzdENhc2VzIiwicXVlcnkiLCJwYWdlIiwicGVyUGFnZSIsIm1pbiIsInBlcl9wYWdlIiwiREVGQVVMVF9QQUdFX1NJWkUiLCJNQVhfUEFHRV9TSVpFIiwic29ydEZpZWxkIiwic29ydF9maWVsZCIsIkRFRkFVTFRfU09SVF9GSUVMRCIsInNvcnRPcmRlciIsInNvcnRfb3JkZXIiLCJERUZBVUxUX1NPUlRfT1JERVIiLCJtdXN0IiwidGVybSIsInRhZ0xpc3QiLCJzcGxpdCIsIm1hcCIsInQiLCJ0cmltIiwidGVybXMiLCJzZWFyY2giLCJtdWx0aV9tYXRjaCIsImZpZWxkcyIsInR5cGUiLCJmdXp6aW5lc3MiLCJjcmVhdGVkX2Zyb20iLCJjcmVhdGVkX3RvIiwicmFuZ2UiLCJndGUiLCJsdGUiLCJzZWFyY2hCb2R5IiwiYm9vbCIsIm1hdGNoX2FsbCIsInNvcnQiLCJvcmRlciIsInNpemUiLCJleGNsdWRlcyIsImhpdHMiLCJ0b3RhbCIsInNlYXJjaERvY3VtZW50cyIsImNhc2VzIiwiaGl0IiwiY2hhbmdlU3RhdHVzIiwibmV3U3RhdHVzIiwic3VjY2VzcyIsImVycm9yIiwiYWxsb3dlZFRyYW5zaXRpb25zIiwiU1RBVFVTX1RSQU5TSVRJT05TIiwiaW5jbHVkZXMiLCJqb2luIiwiZ2V0VGltZSIsImFjdGl2aXR5IiwidXBkYXRlZENhc2UiLCJjYXNlIiwiYXNzaWduQ2FzZSIsImFkZFRhc2siLCJuZXdUYXNrIiwidGFza19pZCIsImNvbXBsZXRlZCIsInRvZ2dsZVRhc2siLCJ0YXNrSWQiLCJjb21wbGV0ZWRfYXQiLCJyZW1vdmVUYXNrIiwiZmlsdGVyIiwidXBkYXRlTm90ZXMiLCJhZGRDb21tZW50IiwiY29udGVudCIsImNvbW1lbnQiLCJjb21tZW50X2lkIiwiYXV0aG9yIiwiZGVsZXRlQ29tbWVudCIsImNvbW1lbnRJZCIsInVwZGF0ZWRDb21tZW50cyIsImMiLCJsaW5rQWxlcnQiLCJhbGVydCIsInNvbWUiLCJhIiwiYWxlcnRfaWQiLCJydWxlX2Rlc2NyaXB0aW9uIiwidW5saW5rQWxlcnQiLCJhbGVydElkIiwidXBkYXRlZEFsZXJ0cyIsInNlYXJjaEFsZXJ0cyIsImxlbmllbnQiLCJhZ2VudF9pZCIsInJ1bGVfaWQiLCJsZXZlbF9taW4iLCJsZXZlbF9tYXgiLCJXQVpVSF9BTEVSVFNfSU5ERVhfUEFUVEVSTiIsImFkZE9ic2VydmFibGUiLCJvYnNlcnZhYmxlIiwibmV3T2JzZXJ2YWJsZSIsImFkZGVkX2F0IiwiYWRkZWRfYnkiLCJ2YWx1ZSIsInJlbW92ZU9ic2VydmFibGUiLCJvYnNlcnZhYmxlSWQiLCJ1cGRhdGVkIiwibyIsIm9ic2VydmFibGVfaWQiLCJnZXRBbmFseXRpY3NTdW1tYXJ5IiwiY29tcHV0ZUFuYWx5dGljc1N1bW1hcnkiLCJlIiwiX2FnZ3MkYnlfc3RhdHVzIiwiX2FnZ3MkYnlfc2V2ZXJpdHkiLCJfYWdncyRieV9wcmlvcml0eSIsIl9hZ2dzJGJ5X2NhdGVnb3J5IiwiX2FnZ3MkdG90YWwiLCJfYWdncyRhdmdfcmVzb2x1dGlvbl8iLCJfYWdncyRjcmVhdGVkX3RvZGF5IiwiX2FnZ3MkY2xvc2VkX3RvZGF5IiwidG9kYXkiLCJzZXRIb3VycyIsInRvZGF5U3RyIiwiYWdncyIsImFnZ3JlZ2F0ZURvY3VtZW50cyIsImJ5X3N0YXR1cyIsImZpZWxkIiwiYXZnX3Jlc29sdXRpb25fdGltZSIsImF2ZyIsImNyZWF0ZWRfdG9kYXkiLCJjbG9zZWRfdG9kYXkiLCJ2YWx1ZV9jb3VudCIsInN0YXR1c0NvdW50cyIsImJ1Y2tldHMiLCJmb3JFYWNoIiwiYiIsImtleSIsImRvY19jb3VudCIsInNldmVyaXR5Q291bnRzIiwicHJpb3JpdHlDb3VudHMiLCJjYXRlZ29yeUNvdW50cyIsInRvdGFsQ2FzZXMiLCJnZXRDYXNlVHJlbmRzIiwiZGF5cyIsIl9hZ2dzJGNhc2VzX292ZXJfdGltZSIsIl9hZ2dzJGNsb3NlZF9vdmVyX3RpbSIsImZyb21EYXRlIiwic2V0RGF0ZSIsImdldERhdGUiLCJjYXNlc19vdmVyX3RpbWUiLCJkYXRlX2hpc3RvZ3JhbSIsImNhbGVuZGFyX2ludGVydmFsIiwiY2xvc2VkX292ZXJfdGltZSIsImV4aXN0cyIsImJ5X2RheSIsImNyZWF0ZWRCdWNrZXRzIiwiY2xvc2VkQnVja2V0cyIsImNsb3NlZE1hcCIsIl9iJGtleV9hc19zdHJpbmciLCJkYXRlS2V5Iiwia2V5X2FzX3N0cmluZyIsIl9iJGtleV9hc19zdHJpbmcyIiwiZGF0ZSIsImNyZWF0ZWQiLCJjbG9zZWQiLCJoYW5kbGVBdXRvbWF0ZWRBbGVydCIsIl9hbGVydCRydWxlIiwiX2FsZXJ0JGFnZW50IiwiX2FsZXJ0JHJ1bGUyIiwiX2FsZXJ0JHJ1bGUzIiwiX2FsZXJ0JHJ1bGU0IiwiX2FsZXJ0JGFnZW50MiIsIl9hbGVydCRydWxlNSIsIl9hbGVydCRydWxlNiIsIl9hbGVydCRhZ2VudDMiLCJydWxlSWQiLCJydWxlIiwiYWdlbnRJZCIsImFnZW50IiwiRXJyb3IiLCJsaW5rZWRBbGVydCIsImluZGV4IiwiX2luZGV4IiwicGFyc2VJbnQiLCJydWxlX2xldmVsIiwibGV2ZWwiLCJydWxlX2dyb3VwcyIsImdyb3VwcyIsImFnZW50X25hbWUiLCJuYW1lIiwiZnVsbF9sb2ciLCJzZWFyY2hSZXN1bHQiLCJleGlzdGluZ0Nhc2UiLCJhbHJlYWR5TGlua2VkIiwiYXV0b21hdGVkX3J1bGVfaWQiLCJhdXRvbWF0ZWRfYWdlbnRfaWQiLCJleHBvcnRzIl0sInNvdXJjZXMiOlsiY2FzZV9zZXJ2aWNlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qXG4gKiBXYXp1aCBDYXNlIE1hbmFnZW1lbnQgUGx1Z2luXG4gKiBDYXNlIFNlcnZpY2Ug4oCUIEJ1c2luZXNzIGxvZ2ljIGZvciBjYXNlIG1hbmFnZW1lbnQgb3BlcmF0aW9uc1xuICpcbiAqIEhhbmRsZXMgY2FzZSBJRCBnZW5lcmF0aW9uLCBDUlVELCBzdGF0dXMgdHJhbnNpdGlvbnMsIGNvbW1lbnRzLFxuICogYWxlcnQgbGlua2luZywgb2JzZXJ2YWJsZXMsIGFjdGl2aXR5IGxvZ2dpbmcsIGFuZCBhbmFseXRpY3MuXG4gKi9cblxuaW1wb3J0IHsgdjQgYXMgdXVpZFY0IH0gZnJvbSAnY3J5cHRvJztcbmltcG9ydCB7XG4gIENhc2UsXG4gIENyZWF0ZUNhc2VQYXlsb2FkLFxuICBVcGRhdGVDYXNlUGF5bG9hZCxcbiAgQ2FzZVN0YXR1cyxcbiAgQ2FzZUFjdGl2aXR5LFxuICBDYXNlQ29tbWVudCxcbiAgTGlua2VkQWxlcnQsXG4gIE9ic2VydmFibGUsXG4gIEFuYWx5dGljc1N1bW1hcnksXG4gIENhc2VUcmVuZCxcbiAgQ2FzZUxpc3RRdWVyeSxcbiAgQ2FzZUxpc3RSZXNwb25zZSxcbiAgV2F6dWhBbGVydFNlYXJjaFF1ZXJ5LFxufSBmcm9tICcuLi8uLi9jb21tb24vdHlwZXMnO1xuaW1wb3J0IHtcbiAgQ0FTRV9JTkRFWCxcbiAgQ0FTRV9DT1VOVEVSX0lOREVYLFxuICBDQVNFX0lEX1BSRUZJWCxcbiAgQ0FTRV9JRF9TRVBBUkFUT1IsXG4gIFNUQVRVU19UUkFOU0lUSU9OUyxcbiAgV0FaVUhfQUxFUlRTX0lOREVYX1BBVFRFUk4sXG4gIERFRkFVTFRfUEFHRV9TSVpFLFxuICBNQVhfUEFHRV9TSVpFLFxuICBERUZBVUxUX1NPUlRfRklFTEQsXG4gIERFRkFVTFRfU09SVF9PUkRFUixcbn0gZnJvbSAnLi4vLi4vY29tbW9uL2NvbnN0YW50cyc7XG5pbXBvcnQgeyBPcGVuU2VhcmNoU2VydmljZSB9IGZyb20gJy4vb3BlbnNlYXJjaF9zZXJ2aWNlJztcbmltcG9ydCB7IGNhc2VNYXBwaW5ncywgY291bnRlck1hcHBpbmdzIH0gZnJvbSAnLi4vc2F2ZWRfb2JqZWN0cy9jYXNlX21hcHBpbmdzJztcblxuLyoqIEVtcHR5IGFuYWx5dGljcyBzdW1tYXJ5IOKAlCByZXR1cm5lZCB3aGVuIHRoZXJlIGFyZSBubyBjYXNlcyBvciB0aGUgaW5kZXggaXMgdW5hdmFpbGFibGUuICovXG5mdW5jdGlvbiBlbXB0eUFuYWx5dGljc1N1bW1hcnkoKTogQW5hbHl0aWNzU3VtbWFyeSB7XG4gIHJldHVybiB7XG4gICAgdG90YWxfY2FzZXM6IDAsXG4gICAgb3Blbl9jYXNlczogMCxcbiAgICBpbl9wcm9ncmVzc19jYXNlczogMCxcbiAgICB3YWl0aW5nX2Nhc2VzOiAwLFxuICAgIHJlc29sdmVkX2Nhc2VzOiAwLFxuICAgIGNsb3NlZF9jYXNlczogMCxcbiAgICBieV9zZXZlcml0eToge30gYXMgYW55LFxuICAgIGJ5X3ByaW9yaXR5OiB7fSBhcyBhbnksXG4gICAgYnlfY2F0ZWdvcnk6IHt9LFxuICAgIGF2Z19yZXNvbHV0aW9uX3RpbWVfbXM6IG51bGwsXG4gICAgY2FzZXNfY3JlYXRlZF90b2RheTogMCxcbiAgICBjYXNlc19jbG9zZWRfdG9kYXk6IDAsXG4gIH07XG59XG5cbi8qKiBHZW5lcmF0ZSBhIFVVSUQgdjQgd2l0aG91dCBkYXNoZXMgKGNvbXBhY3QpICovXG5mdW5jdGlvbiB1dWlkKCk6IHN0cmluZyB7XG4gIC8vIFVzZSBjcnlwdG8ucmFuZG9tVVVJRCBpZiBhdmFpbGFibGUsIGZhbGxiYWNrIHRvIG1hbnVhbFxuICB0cnkge1xuICAgIHJldHVybiBjcnlwdG8ucmFuZG9tVVVJRCgpLnJlcGxhY2UoLy0vZywgJycpLnN1YnN0cmluZygwLCAxMik7XG4gIH0gY2F0Y2gge1xuICAgIHJldHVybiBEYXRlLm5vdygpLnRvU3RyaW5nKDM2KSArIE1hdGgucmFuZG9tKCkudG9TdHJpbmcoMzYpLnN1YnN0cmluZygyLCA4KTtcbiAgfVxufVxuXG4vKipcbiAqIENhc2VTZXJ2aWNlIOKAlCBhbGwgY2FzZSBtYW5hZ2VtZW50IGJ1c2luZXNzIGxvZ2ljLlxuICogTWV0aG9kcyBhcmUgc3RhdGljOyB0aGUgT3BlblNlYXJjaCBjbGllbnQgaXMgcGFzc2VkIGluIHBlci1yZXF1ZXN0LlxuICovXG5leHBvcnQgY2xhc3MgQ2FzZVNlcnZpY2Uge1xuICAvLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgLy8gQ2FzZSBJRCBHZW5lcmF0aW9uXG4gIC8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG4gIC8qKlxuICAgKiBHZW5lcmF0ZSB0aGUgbmV4dCBodW1hbi1yZWFkYWJsZSBjYXNlIElELlxuICAgKiBGb3JtYXQ6IENBU0UtMjAyNi0wMDAxXG4gICAqL1xuICBzdGF0aWMgYXN5bmMgZ2VuZXJhdGVDYXNlSWQoY2xpZW50OiBhbnkpOiBQcm9taXNlPHN0cmluZz4ge1xuICAgIGNvbnN0IGNvdW50ZXIgPSBhd2FpdCBPcGVuU2VhcmNoU2VydmljZS5nZXROZXh0Q291bnRlclZhbHVlKGNsaWVudCk7XG4gICAgY29uc3QgeWVhciA9IG5ldyBEYXRlKCkuZ2V0RnVsbFllYXIoKTtcbiAgICBjb25zdCBwYWRkZWROdW0gPSBTdHJpbmcoY291bnRlcikucGFkU3RhcnQoNCwgJzAnKTtcbiAgICByZXR1cm4gYCR7Q0FTRV9JRF9QUkVGSVh9JHtDQVNFX0lEX1NFUEFSQVRPUn0ke3llYXJ9JHtDQVNFX0lEX1NFUEFSQVRPUn0ke3BhZGRlZE51bX1gO1xuICB9XG5cbiAgLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gIC8vIEFjdGl2aXR5IExvZyBIZWxwZXJcbiAgLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbiAgcHJpdmF0ZSBzdGF0aWMgY3JlYXRlQWN0aXZpdHkoXG4gICAgYWN0aW9uOiBDYXNlQWN0aXZpdHlbJ2FjdGlvbiddLFxuICAgIHVzZXI6IHN0cmluZyxcbiAgICBkZXRhaWxzPzogUmVjb3JkPHN0cmluZywgYW55PixcbiAgKTogQ2FzZUFjdGl2aXR5IHtcbiAgICByZXR1cm4ge1xuICAgICAgaWQ6IHV1aWQoKSxcbiAgICAgIGFjdGlvbixcbiAgICAgIHVzZXIsXG4gICAgICB0aW1lc3RhbXA6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgIGRldGFpbHMsXG4gICAgfTtcbiAgfVxuXG4gIC8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICAvLyBDYXNlIENSVURcbiAgLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbiAgLyoqIENyZWF0ZSBhIG5ldyBjYXNlICovXG4gIHN0YXRpYyBhc3luYyBjcmVhdGVDYXNlKFxuICAgIGNsaWVudDogYW55LFxuICAgIHBheWxvYWQ6IENyZWF0ZUNhc2VQYXlsb2FkLFxuICAgIHVzZXI6IHN0cmluZyxcbiAgKTogUHJvbWlzZTxDYXNlPiB7XG4gICAgLy8gQXV0by1oZWFsOiBtYWtlIHN1cmUgdGhlIGluZGljZXMgZXhpc3Qgd2l0aCB0aGUgY29ycmVjdCBtYXBwaW5nIGJlZm9yZSB3cml0aW5nLFxuICAgIC8vIHNvIGRlbGV0aW5nIGFuIGluZGV4IGFuZCB0aGVuIGNyZWF0aW5nIGEgY2FzZSByZXN0b3JlcyB0aGUgcHJvcGVyIHNjaGVtYS5cbiAgICBhd2FpdCBPcGVuU2VhcmNoU2VydmljZS5lbnN1cmVJbmRleChjbGllbnQsIENBU0VfQ09VTlRFUl9JTkRFWCwgY291bnRlck1hcHBpbmdzKTtcbiAgICBhd2FpdCBPcGVuU2VhcmNoU2VydmljZS5lbnN1cmVJbmRleChjbGllbnQsIENBU0VfSU5ERVgsIGNhc2VNYXBwaW5ncyk7XG5cbiAgICBjb25zdCBjYXNlSWQgPSBhd2FpdCBDYXNlU2VydmljZS5nZW5lcmF0ZUNhc2VJZChjbGllbnQpO1xuICAgIGNvbnN0IG5vdyA9IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKTtcblxuICAgIGNvbnN0IG5ld0Nhc2U6IENhc2UgPSB7XG4gICAgICBjYXNlX2lkOiBjYXNlSWQsXG4gICAgICB0aXRsZTogcGF5bG9hZC50aXRsZSxcbiAgICAgIGRlc2NyaXB0aW9uOiBwYXlsb2FkLmRlc2NyaXB0aW9uLFxuICAgICAgc3RhdHVzOiAnb3BlbicsXG4gICAgICBzZXZlcml0eTogcGF5bG9hZC5zZXZlcml0eSxcbiAgICAgIHByaW9yaXR5OiBwYXlsb2FkLnByaW9yaXR5LFxuICAgICAgY2F0ZWdvcnk6IHBheWxvYWQuY2F0ZWdvcnksXG4gICAgICB0bHA6IHBheWxvYWQudGxwIHx8ICdXSElURScsXG4gICAgICB0YWdzOiBwYXlsb2FkLnRhZ3MgfHwgW10sXG4gICAgICBhc3NpZ25lZTogcGF5bG9hZC5hc3NpZ25lZSB8fCBudWxsLFxuICAgICAgY3JlYXRlZF9ieTogdXNlcixcbiAgICAgIGNyZWF0ZWRfYXQ6IG5vdyxcbiAgICAgIHVwZGF0ZWRfYXQ6IG5vdyxcbiAgICAgIGNsb3NlZF9hdDogbnVsbCxcbiAgICAgIGxpbmtlZF9hbGVydHM6IFtdLFxuICAgICAgb2JzZXJ2YWJsZXM6IFtdLFxuICAgICAgY29tbWVudHM6IFtdLFxuICAgICAgdGFza3M6IFtdLFxuICAgICAgbm90ZXM6ICcnLFxuICAgICAgYWN0aXZpdHlfbG9nOiBbXG4gICAgICAgIENhc2VTZXJ2aWNlLmNyZWF0ZUFjdGl2aXR5KCdjYXNlX2NyZWF0ZWQnLCB1c2VyLCB7XG4gICAgICAgICAgY2FzZV9pZDogY2FzZUlkLFxuICAgICAgICAgIHRpdGxlOiBwYXlsb2FkLnRpdGxlLFxuICAgICAgICB9KSxcbiAgICAgIF0sXG4gICAgICByZXNvbHV0aW9uX3N1bW1hcnk6IG51bGwsXG4gICAgICB0aW1lX3RvX3Jlc29sdmVfbXM6IG51bGwsXG4gICAgICByZWxhdGVkX2Nhc2VzOiBbXSxcbiAgICAgIGN1c3RvbV9maWVsZHM6IHt9LFxuICAgIH07XG5cbiAgICAvLyBJZiBhbiBhc3NpZ25lZSB3YXMgcHJvdmlkZWQsIGxvZyB0aGUgYXNzaWdubWVudFxuICAgIGlmIChwYXlsb2FkLmFzc2lnbmVlKSB7XG4gICAgICBuZXdDYXNlLmFjdGl2aXR5X2xvZy5wdXNoKFxuICAgICAgICBDYXNlU2VydmljZS5jcmVhdGVBY3Rpdml0eSgnYXNzaWduZWQnLCB1c2VyLCB7IGFzc2lnbmVlOiBwYXlsb2FkLmFzc2lnbmVlIH0pLFxuICAgICAgKTtcbiAgICB9XG5cbiAgICBjb25zdCB7IF9pZCB9ID0gYXdhaXQgT3BlblNlYXJjaFNlcnZpY2UuY3JlYXRlRG9jdW1lbnQoY2xpZW50LCBDQVNFX0lOREVYLCBuZXdDYXNlKTtcbiAgICBuZXdDYXNlLmlkID0gX2lkO1xuXG4gICAgcmV0dXJuIG5ld0Nhc2U7XG4gIH1cblxuICAvKiogR2V0IGEgc2luZ2xlIGNhc2UgYnkgaXRzIE9wZW5TZWFyY2ggX2lkICovXG4gIHN0YXRpYyBhc3luYyBnZXRDYXNlKGNsaWVudDogYW55LCBpZDogc3RyaW5nKTogUHJvbWlzZTxDYXNlIHwgbnVsbD4ge1xuICAgIGNvbnN0IGRvYyA9IGF3YWl0IE9wZW5TZWFyY2hTZXJ2aWNlLmdldERvY3VtZW50KGNsaWVudCwgQ0FTRV9JTkRFWCwgaWQpO1xuICAgIGlmICghZG9jKSByZXR1cm4gbnVsbDtcbiAgICByZXR1cm4geyBpZDogZG9jLl9pZCwgLi4uZG9jLl9zb3VyY2UgfSBhcyBDYXNlO1xuICB9XG5cbiAgLyoqIFVwZGF0ZSBhIGNhc2UgKHBhcnRpYWwgdXBkYXRlKSAqL1xuICBzdGF0aWMgYXN5bmMgdXBkYXRlQ2FzZShcbiAgICBjbGllbnQ6IGFueSxcbiAgICBpZDogc3RyaW5nLFxuICAgIHBheWxvYWQ6IFVwZGF0ZUNhc2VQYXlsb2FkLFxuICAgIHVzZXI6IHN0cmluZyxcbiAgKTogUHJvbWlzZTxDYXNlIHwgbnVsbD4ge1xuICAgIGNvbnN0IGV4aXN0aW5nID0gYXdhaXQgQ2FzZVNlcnZpY2UuZ2V0Q2FzZShjbGllbnQsIGlkKTtcbiAgICBpZiAoIWV4aXN0aW5nKSByZXR1cm4gbnVsbDtcblxuICAgIGNvbnN0IG5vdyA9IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKTtcbiAgICBjb25zdCBhY3Rpdml0aWVzOiBDYXNlQWN0aXZpdHlbXSA9IFtdO1xuICAgIGNvbnN0IHVwZGF0ZURvYzogYW55ID0geyB1cGRhdGVkX2F0OiBub3cgfTtcblxuICAgIC8vIFRyYWNrIGNoYW5nZXMgZm9yIGFjdGl2aXR5IGxvZ1xuICAgIGlmIChwYXlsb2FkLnRpdGxlICE9PSB1bmRlZmluZWQgJiYgcGF5bG9hZC50aXRsZSAhPT0gZXhpc3RpbmcudGl0bGUpIHtcbiAgICAgIHVwZGF0ZURvYy50aXRsZSA9IHBheWxvYWQudGl0bGU7XG4gICAgfVxuICAgIGlmIChwYXlsb2FkLmRlc2NyaXB0aW9uICE9PSB1bmRlZmluZWQpIHtcbiAgICAgIHVwZGF0ZURvYy5kZXNjcmlwdGlvbiA9IHBheWxvYWQuZGVzY3JpcHRpb247XG4gICAgfVxuICAgIGlmIChwYXlsb2FkLnNldmVyaXR5ICE9PSB1bmRlZmluZWQgJiYgcGF5bG9hZC5zZXZlcml0eSAhPT0gZXhpc3Rpbmcuc2V2ZXJpdHkpIHtcbiAgICAgIHVwZGF0ZURvYy5zZXZlcml0eSA9IHBheWxvYWQuc2V2ZXJpdHk7XG4gICAgICBhY3Rpdml0aWVzLnB1c2goXG4gICAgICAgIENhc2VTZXJ2aWNlLmNyZWF0ZUFjdGl2aXR5KCdzZXZlcml0eV9jaGFuZ2VkJywgdXNlciwge1xuICAgICAgICAgIGZyb206IGV4aXN0aW5nLnNldmVyaXR5LFxuICAgICAgICAgIHRvOiBwYXlsb2FkLnNldmVyaXR5LFxuICAgICAgICB9KSxcbiAgICAgICk7XG4gICAgfVxuICAgIGlmIChwYXlsb2FkLnByaW9yaXR5ICE9PSB1bmRlZmluZWQgJiYgcGF5bG9hZC5wcmlvcml0eSAhPT0gZXhpc3RpbmcucHJpb3JpdHkpIHtcbiAgICAgIHVwZGF0ZURvYy5wcmlvcml0eSA9IHBheWxvYWQucHJpb3JpdHk7XG4gICAgICBhY3Rpdml0aWVzLnB1c2goXG4gICAgICAgIENhc2VTZXJ2aWNlLmNyZWF0ZUFjdGl2aXR5KCdwcmlvcml0eV9jaGFuZ2VkJywgdXNlciwge1xuICAgICAgICAgIGZyb206IGV4aXN0aW5nLnByaW9yaXR5LFxuICAgICAgICAgIHRvOiBwYXlsb2FkLnByaW9yaXR5LFxuICAgICAgICB9KSxcbiAgICAgICk7XG4gICAgfVxuICAgIGlmIChwYXlsb2FkLmNhdGVnb3J5ICE9PSB1bmRlZmluZWQpIHtcbiAgICAgIHVwZGF0ZURvYy5jYXRlZ29yeSA9IHBheWxvYWQuY2F0ZWdvcnk7XG4gICAgfVxuICAgIGlmIChwYXlsb2FkLnRscCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICB1cGRhdGVEb2MudGxwID0gcGF5bG9hZC50bHA7XG4gICAgfVxuICAgIGlmIChwYXlsb2FkLnRhZ3MgIT09IHVuZGVmaW5lZCkge1xuICAgICAgdXBkYXRlRG9jLnRhZ3MgPSBwYXlsb2FkLnRhZ3M7XG4gICAgfVxuICAgIGlmIChwYXlsb2FkLmFzc2lnbmVlICE9PSB1bmRlZmluZWQgJiYgcGF5bG9hZC5hc3NpZ25lZSAhPT0gZXhpc3RpbmcuYXNzaWduZWUpIHtcbiAgICAgIHVwZGF0ZURvYy5hc3NpZ25lZSA9IHBheWxvYWQuYXNzaWduZWU7XG4gICAgICBhY3Rpdml0aWVzLnB1c2goXG4gICAgICAgIENhc2VTZXJ2aWNlLmNyZWF0ZUFjdGl2aXR5KHBheWxvYWQuYXNzaWduZWUgPyAnYXNzaWduZWQnIDogJ3VuYXNzaWduZWQnLCB1c2VyLCB7XG4gICAgICAgICAgZnJvbTogZXhpc3RpbmcuYXNzaWduZWUsXG4gICAgICAgICAgdG86IHBheWxvYWQuYXNzaWduZWUsXG4gICAgICAgIH0pLFxuICAgICAgKTtcbiAgICB9XG4gICAgaWYgKHBheWxvYWQucmVzb2x1dGlvbl9zdW1tYXJ5ICE9PSB1bmRlZmluZWQpIHtcbiAgICAgIHVwZGF0ZURvYy5yZXNvbHV0aW9uX3N1bW1hcnkgPSBwYXlsb2FkLnJlc29sdXRpb25fc3VtbWFyeTtcbiAgICB9XG5cbiAgICAvLyBBcHBlbmQgYWN0aXZpdGllc1xuICAgIGlmIChhY3Rpdml0aWVzLmxlbmd0aCA+IDApIHtcbiAgICAgIHVwZGF0ZURvYy5hY3Rpdml0eV9sb2cgPSBbLi4uZXhpc3RpbmcuYWN0aXZpdHlfbG9nLCAuLi5hY3Rpdml0aWVzXTtcbiAgICB9XG5cbiAgICBhd2FpdCBPcGVuU2VhcmNoU2VydmljZS51cGRhdGVEb2N1bWVudChjbGllbnQsIENBU0VfSU5ERVgsIGlkLCB1cGRhdGVEb2MpO1xuICAgIHJldHVybiBhd2FpdCBDYXNlU2VydmljZS5nZXRDYXNlKGNsaWVudCwgaWQpO1xuICB9XG5cbiAgLyoqIERlbGV0ZSBhIGNhc2UgYnkgT3BlblNlYXJjaCBfaWQgKi9cbiAgc3RhdGljIGFzeW5jIGRlbGV0ZUNhc2UoY2xpZW50OiBhbnksIGlkOiBzdHJpbmcpOiBQcm9taXNlPGJvb2xlYW4+IHtcbiAgICByZXR1cm4gYXdhaXQgT3BlblNlYXJjaFNlcnZpY2UuZGVsZXRlRG9jdW1lbnQoY2xpZW50LCBDQVNFX0lOREVYLCBpZCk7XG4gIH1cblxuICAvKiogTGlzdCBjYXNlcyB3aXRoIGZpbHRlcmluZywgcGFnaW5hdGlvbiwgYW5kIHNvcnRpbmcgKi9cbiAgc3RhdGljIGFzeW5jIGxpc3RDYXNlcyhjbGllbnQ6IGFueSwgcXVlcnk6IENhc2VMaXN0UXVlcnkpOiBQcm9taXNlPENhc2VMaXN0UmVzcG9uc2U+IHtcbiAgICBjb25zdCBwYWdlID0gcXVlcnkucGFnZSB8fCAxO1xuICAgIGNvbnN0IHBlclBhZ2UgPSBNYXRoLm1pbihxdWVyeS5wZXJfcGFnZSB8fCBERUZBVUxUX1BBR0VfU0laRSwgTUFYX1BBR0VfU0laRSk7XG4gICAgY29uc3Qgc29ydEZpZWxkID0gcXVlcnkuc29ydF9maWVsZCB8fCBERUZBVUxUX1NPUlRfRklFTEQ7XG4gICAgY29uc3Qgc29ydE9yZGVyID0gcXVlcnkuc29ydF9vcmRlciB8fCBERUZBVUxUX1NPUlRfT1JERVI7XG5cbiAgICAvLyBCdWlsZCB0aGUgcXVlcnlcbiAgICBjb25zdCBtdXN0OiBhbnlbXSA9IFtdO1xuXG4gICAgaWYgKHF1ZXJ5LnN0YXR1cykge1xuICAgICAgbXVzdC5wdXNoKHsgdGVybTogeyBzdGF0dXM6IHF1ZXJ5LnN0YXR1cyB9IH0pO1xuICAgIH1cbiAgICBpZiAocXVlcnkuc2V2ZXJpdHkpIHtcbiAgICAgIG11c3QucHVzaCh7IHRlcm06IHsgc2V2ZXJpdHk6IHF1ZXJ5LnNldmVyaXR5IH0gfSk7XG4gICAgfVxuICAgIGlmIChxdWVyeS5wcmlvcml0eSkge1xuICAgICAgbXVzdC5wdXNoKHsgdGVybTogeyBwcmlvcml0eTogcXVlcnkucHJpb3JpdHkgfSB9KTtcbiAgICB9XG4gICAgaWYgKHF1ZXJ5LmNhdGVnb3J5KSB7XG4gICAgICBtdXN0LnB1c2goeyB0ZXJtOiB7IGNhdGVnb3J5OiBxdWVyeS5jYXRlZ29yeSB9IH0pO1xuICAgIH1cbiAgICBpZiAocXVlcnkuYXNzaWduZWUpIHtcbiAgICAgIG11c3QucHVzaCh7IHRlcm06IHsgYXNzaWduZWU6IHF1ZXJ5LmFzc2lnbmVlIH0gfSk7XG4gICAgfVxuICAgIGlmIChxdWVyeS50YWdzKSB7XG4gICAgICBjb25zdCB0YWdMaXN0ID0gcXVlcnkudGFncy5zcGxpdCgnLCcpLm1hcCgodCkgPT4gdC50cmltKCkpO1xuICAgICAgbXVzdC5wdXNoKHsgdGVybXM6IHsgdGFnczogdGFnTGlzdCB9IH0pO1xuICAgIH1cbiAgICBpZiAocXVlcnkuc2VhcmNoKSB7XG4gICAgICBtdXN0LnB1c2goe1xuICAgICAgICBtdWx0aV9tYXRjaDoge1xuICAgICAgICAgIHF1ZXJ5OiBxdWVyeS5zZWFyY2gsXG4gICAgICAgICAgZmllbGRzOiBbJ3RpdGxlXjMnLCAnZGVzY3JpcHRpb24nLCAnY2FzZV9pZF4yJywgJ3RhZ3MnXSxcbiAgICAgICAgICB0eXBlOiAnYmVzdF9maWVsZHMnLFxuICAgICAgICAgIGZ1enppbmVzczogJ0FVVE8nLFxuICAgICAgICB9LFxuICAgICAgfSk7XG4gICAgfVxuICAgIGlmIChxdWVyeS5jcmVhdGVkX2Zyb20gfHwgcXVlcnkuY3JlYXRlZF90bykge1xuICAgICAgY29uc3QgcmFuZ2U6IGFueSA9IHt9O1xuICAgICAgaWYgKHF1ZXJ5LmNyZWF0ZWRfZnJvbSkgcmFuZ2UuZ3RlID0gcXVlcnkuY3JlYXRlZF9mcm9tO1xuICAgICAgaWYgKHF1ZXJ5LmNyZWF0ZWRfdG8pIHJhbmdlLmx0ZSA9IHF1ZXJ5LmNyZWF0ZWRfdG87XG4gICAgICBtdXN0LnB1c2goeyByYW5nZTogeyBjcmVhdGVkX2F0OiByYW5nZSB9IH0pO1xuICAgIH1cblxuICAgIGNvbnN0IHNlYXJjaEJvZHkgPSB7XG4gICAgICBxdWVyeTogbXVzdC5sZW5ndGggPiAwID8geyBib29sOiB7IG11c3QgfSB9IDogeyBtYXRjaF9hbGw6IHt9IH0sXG4gICAgICBzb3J0OiBbeyBbc29ydEZpZWxkXTogeyBvcmRlcjogc29ydE9yZGVyIH0gfV0sXG4gICAgICBmcm9tOiAocGFnZSAtIDEpICogcGVyUGFnZSxcbiAgICAgIHNpemU6IHBlclBhZ2UsXG4gICAgICAvLyBFeGNsdWRlIGhlYXZ5IG5lc3RlZCBmaWVsZHMgZnJvbSBsaXN0aW5nIHRvIGltcHJvdmUgcGVyZlxuICAgICAgX3NvdXJjZToge1xuICAgICAgICBleGNsdWRlczogWydhY3Rpdml0eV9sb2cnLCAnY29tbWVudHMuY29udGVudCddLFxuICAgICAgfSxcbiAgICB9O1xuXG4gICAgY29uc3QgeyBoaXRzLCB0b3RhbCB9ID0gYXdhaXQgT3BlblNlYXJjaFNlcnZpY2Uuc2VhcmNoRG9jdW1lbnRzKGNsaWVudCwgQ0FTRV9JTkRFWCwgc2VhcmNoQm9keSk7XG5cbiAgICBjb25zdCBjYXNlczogQ2FzZVtdID0gaGl0cy5tYXAoKGhpdDogYW55KSA9PiAoe1xuICAgICAgaWQ6IGhpdC5faWQsXG4gICAgICAuLi5oaXQuX3NvdXJjZSxcbiAgICB9KSk7XG5cbiAgICByZXR1cm4geyBjYXNlcywgdG90YWwsIHBhZ2UsIHBlcl9wYWdlOiBwZXJQYWdlIH07XG4gIH1cblxuICAvLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgLy8gU3RhdHVzIE1hbmFnZW1lbnRcbiAgLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbiAgLyoqIENoYW5nZSBjYXNlIHN0YXR1cyB3aXRoIHRyYW5zaXRpb24gdmFsaWRhdGlvbiAqL1xuICBzdGF0aWMgYXN5bmMgY2hhbmdlU3RhdHVzKFxuICAgIGNsaWVudDogYW55LFxuICAgIGlkOiBzdHJpbmcsXG4gICAgbmV3U3RhdHVzOiBDYXNlU3RhdHVzLFxuICAgIHVzZXI6IHN0cmluZyxcbiAgKTogUHJvbWlzZTx7IHN1Y2Nlc3M6IGJvb2xlYW47IGVycm9yPzogc3RyaW5nOyBjYXNlPzogQ2FzZSB9PiB7XG4gICAgY29uc3QgZXhpc3RpbmcgPSBhd2FpdCBDYXNlU2VydmljZS5nZXRDYXNlKGNsaWVudCwgaWQpO1xuICAgIGlmICghZXhpc3RpbmcpIHtcbiAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogJ0Nhc2Ugbm90IGZvdW5kJyB9O1xuICAgIH1cblxuICAgIC8vIFZhbGlkYXRlIHRyYW5zaXRpb25cbiAgICBjb25zdCBhbGxvd2VkVHJhbnNpdGlvbnMgPSBTVEFUVVNfVFJBTlNJVElPTlNbZXhpc3Rpbmcuc3RhdHVzXSB8fCBbXTtcbiAgICBpZiAoIWFsbG93ZWRUcmFuc2l0aW9ucy5pbmNsdWRlcyhuZXdTdGF0dXMpKSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICBzdWNjZXNzOiBmYWxzZSxcbiAgICAgICAgZXJyb3I6IGBDYW5ub3QgdHJhbnNpdGlvbiBmcm9tICcke2V4aXN0aW5nLnN0YXR1c30nIHRvICcke25ld1N0YXR1c30nLiBBbGxvd2VkOiAke2FsbG93ZWRUcmFuc2l0aW9ucy5qb2luKCcsICcpfWAsXG4gICAgICB9O1xuICAgIH1cblxuICAgIGNvbnN0IG5vdyA9IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKTtcbiAgICBjb25zdCB1cGRhdGVEb2M6IGFueSA9IHtcbiAgICAgIHN0YXR1czogbmV3U3RhdHVzLFxuICAgICAgdXBkYXRlZF9hdDogbm93LFxuICAgIH07XG5cbiAgICAvLyBIYW5kbGUgY2xvc2luZ1xuICAgIGlmIChuZXdTdGF0dXMgPT09ICdjbG9zZWQnIHx8IG5ld1N0YXR1cyA9PT0gJ3Jlc29sdmVkJykge1xuICAgICAgdXBkYXRlRG9jLmNsb3NlZF9hdCA9IG5vdztcbiAgICAgIGlmIChleGlzdGluZy5jcmVhdGVkX2F0KSB7XG4gICAgICAgIHVwZGF0ZURvYy50aW1lX3RvX3Jlc29sdmVfbXMgPSBuZXcgRGF0ZShub3cpLmdldFRpbWUoKSAtIG5ldyBEYXRlKGV4aXN0aW5nLmNyZWF0ZWRfYXQpLmdldFRpbWUoKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBIYW5kbGUgcmVvcGVuaW5nXG4gICAgaWYgKG5ld1N0YXR1cyA9PT0gJ29wZW4nICYmIChleGlzdGluZy5zdGF0dXMgPT09ICdjbG9zZWQnIHx8IGV4aXN0aW5nLnN0YXR1cyA9PT0gJ3Jlc29sdmVkJykpIHtcbiAgICAgIHVwZGF0ZURvYy5jbG9zZWRfYXQgPSBudWxsO1xuICAgICAgdXBkYXRlRG9jLnRpbWVfdG9fcmVzb2x2ZV9tcyA9IG51bGw7XG4gICAgfVxuXG4gICAgLy8gQWN0aXZpdHlcbiAgICBjb25zdCBhY3Rpdml0eSA9IENhc2VTZXJ2aWNlLmNyZWF0ZUFjdGl2aXR5KFxuICAgICAgbmV3U3RhdHVzID09PSAnY2xvc2VkJyA/ICdjYXNlX2Nsb3NlZCcgOiBuZXdTdGF0dXMgPT09ICdvcGVuJyAmJiBleGlzdGluZy5zdGF0dXMgPT09ICdjbG9zZWQnID8gJ2Nhc2VfcmVvcGVuZWQnIDogJ3N0YXR1c19jaGFuZ2VkJyxcbiAgICAgIHVzZXIsXG4gICAgICB7IGZyb206IGV4aXN0aW5nLnN0YXR1cywgdG86IG5ld1N0YXR1cyB9LFxuICAgICk7XG4gICAgdXBkYXRlRG9jLmFjdGl2aXR5X2xvZyA9IFsuLi5leGlzdGluZy5hY3Rpdml0eV9sb2csIGFjdGl2aXR5XTtcblxuICAgIGF3YWl0IE9wZW5TZWFyY2hTZXJ2aWNlLnVwZGF0ZURvY3VtZW50KGNsaWVudCwgQ0FTRV9JTkRFWCwgaWQsIHVwZGF0ZURvYyk7XG4gICAgY29uc3QgdXBkYXRlZENhc2UgPSBhd2FpdCBDYXNlU2VydmljZS5nZXRDYXNlKGNsaWVudCwgaWQpO1xuICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUsIGNhc2U6IHVwZGF0ZWRDYXNlISB9O1xuICB9XG5cbiAgLyoqIEFzc2lnbiBhIGNhc2UgdG8gYSB1c2VyICovXG4gIHN0YXRpYyBhc3luYyBhc3NpZ25DYXNlKFxuICAgIGNsaWVudDogYW55LFxuICAgIGlkOiBzdHJpbmcsXG4gICAgYXNzaWduZWU6IHN0cmluZyB8IG51bGwsXG4gICAgdXNlcjogc3RyaW5nLFxuICApOiBQcm9taXNlPENhc2UgfCBudWxsPiB7XG4gICAgY29uc3QgZXhpc3RpbmcgPSBhd2FpdCBDYXNlU2VydmljZS5nZXRDYXNlKGNsaWVudCwgaWQpO1xuICAgIGlmICghZXhpc3RpbmcpIHJldHVybiBudWxsO1xuXG4gICAgY29uc3QgYWN0aXZpdHkgPSBDYXNlU2VydmljZS5jcmVhdGVBY3Rpdml0eShcbiAgICAgIGFzc2lnbmVlID8gJ2Fzc2lnbmVkJyA6ICd1bmFzc2lnbmVkJyxcbiAgICAgIHVzZXIsXG4gICAgICB7IGZyb206IGV4aXN0aW5nLmFzc2lnbmVlLCB0bzogYXNzaWduZWUgfSxcbiAgICApO1xuXG4gICAgYXdhaXQgT3BlblNlYXJjaFNlcnZpY2UudXBkYXRlRG9jdW1lbnQoY2xpZW50LCBDQVNFX0lOREVYLCBpZCwge1xuICAgICAgYXNzaWduZWUsXG4gICAgICB1cGRhdGVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICBhY3Rpdml0eV9sb2c6IFsuLi5leGlzdGluZy5hY3Rpdml0eV9sb2csIGFjdGl2aXR5XSxcbiAgICB9KTtcblxuICAgIHJldHVybiBhd2FpdCBDYXNlU2VydmljZS5nZXRDYXNlKGNsaWVudCwgaWQpO1xuICB9XG5cbiAgLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gIC8vIFRhc2tzXG4gIC8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG4gIC8qKiBBZGQgYSB0YXNrIHRvIGEgY2FzZSAqL1xuICBzdGF0aWMgYXN5bmMgYWRkVGFzayhjbGllbnQ6IGFueSwgY2FzZUlkOiBzdHJpbmcsIHRpdGxlOiBzdHJpbmcsIHVzZXI6IHN0cmluZyk6IFByb21pc2U8Q2FzZSB8IG51bGw+IHtcbiAgICBjb25zdCBleGlzdGluZyA9IGF3YWl0IENhc2VTZXJ2aWNlLmdldENhc2UoY2xpZW50LCBjYXNlSWQpO1xuICAgIGlmICghZXhpc3RpbmcpIHJldHVybiBudWxsO1xuXG4gICAgY29uc3QgbmV3VGFzayA9IHtcbiAgICAgIHRhc2tfaWQ6IHV1aWQoKSxcbiAgICAgIHRpdGxlLFxuICAgICAgY29tcGxldGVkOiBmYWxzZSxcbiAgICAgIGNyZWF0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICB9O1xuXG4gICAgY29uc3QgdXBkYXRlRG9jID0ge1xuICAgICAgdGFza3M6IFsuLi4oZXhpc3RpbmcudGFza3MgfHwgW10pLCBuZXdUYXNrXSxcbiAgICAgIHVwZGF0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICB9O1xuXG4gICAgYXdhaXQgT3BlblNlYXJjaFNlcnZpY2UudXBkYXRlRG9jdW1lbnQoY2xpZW50LCBDQVNFX0lOREVYLCBjYXNlSWQsIHVwZGF0ZURvYyk7XG4gICAgcmV0dXJuIGF3YWl0IENhc2VTZXJ2aWNlLmdldENhc2UoY2xpZW50LCBjYXNlSWQpO1xuICB9XG5cbiAgLyoqIFRvZ2dsZSB0YXNrIGNvbXBsZXRpb24gKi9cbiAgc3RhdGljIGFzeW5jIHRvZ2dsZVRhc2soY2xpZW50OiBhbnksIGNhc2VJZDogc3RyaW5nLCB0YXNrSWQ6IHN0cmluZywgY29tcGxldGVkOiBib29sZWFuLCB1c2VyOiBzdHJpbmcpOiBQcm9taXNlPENhc2UgfCBudWxsPiB7XG4gICAgY29uc3QgZXhpc3RpbmcgPSBhd2FpdCBDYXNlU2VydmljZS5nZXRDYXNlKGNsaWVudCwgY2FzZUlkKTtcbiAgICBpZiAoIWV4aXN0aW5nKSByZXR1cm4gbnVsbDtcblxuICAgIGNvbnN0IHRhc2tzID0gKGV4aXN0aW5nLnRhc2tzIHx8IFtdKS5tYXAoKHQ6IGFueSkgPT5cbiAgICAgIHQudGFza19pZCA9PT0gdGFza0lkID8geyAuLi50LCBjb21wbGV0ZWQsIGNvbXBsZXRlZF9hdDogY29tcGxldGVkID8gbmV3IERhdGUoKS50b0lTT1N0cmluZygpIDogdW5kZWZpbmVkIH0gOiB0XG4gICAgKTtcblxuICAgIGNvbnN0IHVwZGF0ZURvYyA9IHtcbiAgICAgIHRhc2tzLFxuICAgICAgdXBkYXRlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIH07XG5cbiAgICBhd2FpdCBPcGVuU2VhcmNoU2VydmljZS51cGRhdGVEb2N1bWVudChjbGllbnQsIENBU0VfSU5ERVgsIGNhc2VJZCwgdXBkYXRlRG9jKTtcbiAgICByZXR1cm4gYXdhaXQgQ2FzZVNlcnZpY2UuZ2V0Q2FzZShjbGllbnQsIGNhc2VJZCk7XG4gIH1cblxuICAvKiogUmVtb3ZlIGEgdGFzayAqL1xuICBzdGF0aWMgYXN5bmMgcmVtb3ZlVGFzayhjbGllbnQ6IGFueSwgY2FzZUlkOiBzdHJpbmcsIHRhc2tJZDogc3RyaW5nLCB1c2VyOiBzdHJpbmcpOiBQcm9taXNlPENhc2UgfCBudWxsPiB7XG4gICAgY29uc3QgZXhpc3RpbmcgPSBhd2FpdCBDYXNlU2VydmljZS5nZXRDYXNlKGNsaWVudCwgY2FzZUlkKTtcbiAgICBpZiAoIWV4aXN0aW5nKSByZXR1cm4gbnVsbDtcblxuICAgIGNvbnN0IHRhc2tzID0gKGV4aXN0aW5nLnRhc2tzIHx8IFtdKS5maWx0ZXIoKHQ6IGFueSkgPT4gdC50YXNrX2lkICE9PSB0YXNrSWQpO1xuXG4gICAgY29uc3QgdXBkYXRlRG9jID0ge1xuICAgICAgdGFza3MsXG4gICAgICB1cGRhdGVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgfTtcblxuICAgIGF3YWl0IE9wZW5TZWFyY2hTZXJ2aWNlLnVwZGF0ZURvY3VtZW50KGNsaWVudCwgQ0FTRV9JTkRFWCwgY2FzZUlkLCB1cGRhdGVEb2MpO1xuICAgIHJldHVybiBhd2FpdCBDYXNlU2VydmljZS5nZXRDYXNlKGNsaWVudCwgY2FzZUlkKTtcbiAgfVxuXG4gIC8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICAvLyBOb3Rlc1xuICAvLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuICAvKiogVXBkYXRlIGNhc2Ugbm90ZXMgKi9cbiAgc3RhdGljIGFzeW5jIHVwZGF0ZU5vdGVzKGNsaWVudDogYW55LCBjYXNlSWQ6IHN0cmluZywgbm90ZXM6IHN0cmluZywgdXNlcjogc3RyaW5nKTogUHJvbWlzZTxDYXNlIHwgbnVsbD4ge1xuICAgIGNvbnN0IGV4aXN0aW5nID0gYXdhaXQgQ2FzZVNlcnZpY2UuZ2V0Q2FzZShjbGllbnQsIGNhc2VJZCk7XG4gICAgaWYgKCFleGlzdGluZykgcmV0dXJuIG51bGw7XG5cbiAgICBjb25zdCB1cGRhdGVEb2MgPSB7XG4gICAgICBub3RlcyxcbiAgICAgIHVwZGF0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICB9O1xuXG4gICAgYXdhaXQgT3BlblNlYXJjaFNlcnZpY2UudXBkYXRlRG9jdW1lbnQoY2xpZW50LCBDQVNFX0lOREVYLCBjYXNlSWQsIHVwZGF0ZURvYyk7XG4gICAgcmV0dXJuIGF3YWl0IENhc2VTZXJ2aWNlLmdldENhc2UoY2xpZW50LCBjYXNlSWQpO1xuICB9XG5cbiAgLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gIC8vIENvbW1lbnRzXG4gIC8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG4gIC8qKiBBZGQgYSBjb21tZW50IHRvIGEgY2FzZSAqL1xuICBzdGF0aWMgYXN5bmMgYWRkQ29tbWVudChcbiAgICBjbGllbnQ6IGFueSxcbiAgICBjYXNlSWQ6IHN0cmluZyxcbiAgICBjb250ZW50OiBzdHJpbmcsXG4gICAgdXNlcjogc3RyaW5nLFxuICApOiBQcm9taXNlPENhc2UgfCBudWxsPiB7XG4gICAgY29uc3QgZXhpc3RpbmcgPSBhd2FpdCBDYXNlU2VydmljZS5nZXRDYXNlKGNsaWVudCwgY2FzZUlkKTtcbiAgICBpZiAoIWV4aXN0aW5nKSByZXR1cm4gbnVsbDtcblxuICAgIGNvbnN0IGNvbW1lbnQ6IENhc2VDb21tZW50ID0ge1xuICAgICAgY29tbWVudF9pZDogdXVpZCgpLFxuICAgICAgYXV0aG9yOiB1c2VyLFxuICAgICAgY29udGVudCxcbiAgICAgIGNyZWF0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICB9O1xuXG4gICAgY29uc3QgYWN0aXZpdHkgPSBDYXNlU2VydmljZS5jcmVhdGVBY3Rpdml0eSgnY29tbWVudF9hZGRlZCcsIHVzZXIsIHtcbiAgICAgIGNvbW1lbnRfaWQ6IGNvbW1lbnQuY29tbWVudF9pZCxcbiAgICB9KTtcblxuICAgIGF3YWl0IE9wZW5TZWFyY2hTZXJ2aWNlLnVwZGF0ZURvY3VtZW50KGNsaWVudCwgQ0FTRV9JTkRFWCwgY2FzZUlkLCB7XG4gICAgICBjb21tZW50czogWy4uLmV4aXN0aW5nLmNvbW1lbnRzLCBjb21tZW50XSxcbiAgICAgIGFjdGl2aXR5X2xvZzogWy4uLmV4aXN0aW5nLmFjdGl2aXR5X2xvZywgYWN0aXZpdHldLFxuICAgICAgdXBkYXRlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIH0pO1xuXG4gICAgcmV0dXJuIGF3YWl0IENhc2VTZXJ2aWNlLmdldENhc2UoY2xpZW50LCBjYXNlSWQpO1xuICB9XG5cbiAgLyoqIERlbGV0ZSBhIGNvbW1lbnQgZnJvbSBhIGNhc2UgKi9cbiAgc3RhdGljIGFzeW5jIGRlbGV0ZUNvbW1lbnQoXG4gICAgY2xpZW50OiBhbnksXG4gICAgY2FzZUlkOiBzdHJpbmcsXG4gICAgY29tbWVudElkOiBzdHJpbmcsXG4gICAgdXNlcjogc3RyaW5nLFxuICApOiBQcm9taXNlPENhc2UgfCBudWxsPiB7XG4gICAgY29uc3QgZXhpc3RpbmcgPSBhd2FpdCBDYXNlU2VydmljZS5nZXRDYXNlKGNsaWVudCwgY2FzZUlkKTtcbiAgICBpZiAoIWV4aXN0aW5nKSByZXR1cm4gbnVsbDtcblxuICAgIGNvbnN0IHVwZGF0ZWRDb21tZW50cyA9IGV4aXN0aW5nLmNvbW1lbnRzLmZpbHRlcigoYykgPT4gYy5jb21tZW50X2lkICE9PSBjb21tZW50SWQpO1xuICAgIGlmICh1cGRhdGVkQ29tbWVudHMubGVuZ3RoID09PSBleGlzdGluZy5jb21tZW50cy5sZW5ndGgpIHtcbiAgICAgIHJldHVybiBleGlzdGluZzsgLy8gQ29tbWVudCBub3QgZm91bmQsIG5vIGNoYW5nZVxuICAgIH1cblxuICAgIGNvbnN0IGFjdGl2aXR5ID0gQ2FzZVNlcnZpY2UuY3JlYXRlQWN0aXZpdHkoJ2NvbW1lbnRfZGVsZXRlZCcsIHVzZXIsIHtcbiAgICAgIGNvbW1lbnRfaWQ6IGNvbW1lbnRJZCxcbiAgICB9KTtcblxuICAgIGF3YWl0IE9wZW5TZWFyY2hTZXJ2aWNlLnVwZGF0ZURvY3VtZW50KGNsaWVudCwgQ0FTRV9JTkRFWCwgY2FzZUlkLCB7XG4gICAgICBjb21tZW50czogdXBkYXRlZENvbW1lbnRzLFxuICAgICAgYWN0aXZpdHlfbG9nOiBbLi4uZXhpc3RpbmcuYWN0aXZpdHlfbG9nLCBhY3Rpdml0eV0sXG4gICAgICB1cGRhdGVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgfSk7XG5cbiAgICByZXR1cm4gYXdhaXQgQ2FzZVNlcnZpY2UuZ2V0Q2FzZShjbGllbnQsIGNhc2VJZCk7XG4gIH1cblxuICAvLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgLy8gQWxlcnQgTGlua2luZ1xuICAvLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuICAvKiogTGluayBhbiBhbGVydCB0byBhIGNhc2UgKi9cbiAgc3RhdGljIGFzeW5jIGxpbmtBbGVydChcbiAgICBjbGllbnQ6IGFueSxcbiAgICBjYXNlSWQ6IHN0cmluZyxcbiAgICBhbGVydDogTGlua2VkQWxlcnQsXG4gICAgdXNlcjogc3RyaW5nLFxuICApOiBQcm9taXNlPENhc2UgfCBudWxsPiB7XG4gICAgY29uc3QgZXhpc3RpbmcgPSBhd2FpdCBDYXNlU2VydmljZS5nZXRDYXNlKGNsaWVudCwgY2FzZUlkKTtcbiAgICBpZiAoIWV4aXN0aW5nKSByZXR1cm4gbnVsbDtcblxuICAgIC8vIENoZWNrIGZvciBkdXBsaWNhdGVcbiAgICBpZiAoZXhpc3RpbmcubGlua2VkX2FsZXJ0cy5zb21lKChhKSA9PiBhLmFsZXJ0X2lkID09PSBhbGVydC5hbGVydF9pZCkpIHtcbiAgICAgIHJldHVybiBleGlzdGluZzsgLy8gQWxyZWFkeSBsaW5rZWRcbiAgICB9XG5cbiAgICBjb25zdCBhY3Rpdml0eSA9IENhc2VTZXJ2aWNlLmNyZWF0ZUFjdGl2aXR5KCdhbGVydF9saW5rZWQnLCB1c2VyLCB7XG4gICAgICBhbGVydF9pZDogYWxlcnQuYWxlcnRfaWQsXG4gICAgICBydWxlX2Rlc2NyaXB0aW9uOiBhbGVydC5ydWxlX2Rlc2NyaXB0aW9uLFxuICAgIH0pO1xuXG4gICAgYXdhaXQgT3BlblNlYXJjaFNlcnZpY2UudXBkYXRlRG9jdW1lbnQoY2xpZW50LCBDQVNFX0lOREVYLCBjYXNlSWQsIHtcbiAgICAgIGxpbmtlZF9hbGVydHM6IFsuLi5leGlzdGluZy5saW5rZWRfYWxlcnRzLCBhbGVydF0sXG4gICAgICBhY3Rpdml0eV9sb2c6IFsuLi5leGlzdGluZy5hY3Rpdml0eV9sb2csIGFjdGl2aXR5XSxcbiAgICAgIHVwZGF0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICB9KTtcblxuICAgIHJldHVybiBhd2FpdCBDYXNlU2VydmljZS5nZXRDYXNlKGNsaWVudCwgY2FzZUlkKTtcbiAgfVxuXG4gIC8qKiBVbmxpbmsgYW4gYWxlcnQgZnJvbSBhIGNhc2UgKi9cbiAgc3RhdGljIGFzeW5jIHVubGlua0FsZXJ0KFxuICAgIGNsaWVudDogYW55LFxuICAgIGNhc2VJZDogc3RyaW5nLFxuICAgIGFsZXJ0SWQ6IHN0cmluZyxcbiAgICB1c2VyOiBzdHJpbmcsXG4gICk6IFByb21pc2U8Q2FzZSB8IG51bGw+IHtcbiAgICBjb25zdCBleGlzdGluZyA9IGF3YWl0IENhc2VTZXJ2aWNlLmdldENhc2UoY2xpZW50LCBjYXNlSWQpO1xuICAgIGlmICghZXhpc3RpbmcpIHJldHVybiBudWxsO1xuXG4gICAgY29uc3QgdXBkYXRlZEFsZXJ0cyA9IGV4aXN0aW5nLmxpbmtlZF9hbGVydHMuZmlsdGVyKChhKSA9PiBhLmFsZXJ0X2lkICE9PSBhbGVydElkKTtcbiAgICBjb25zdCBhY3Rpdml0eSA9IENhc2VTZXJ2aWNlLmNyZWF0ZUFjdGl2aXR5KCdhbGVydF91bmxpbmtlZCcsIHVzZXIsIHsgYWxlcnRfaWQ6IGFsZXJ0SWQgfSk7XG5cbiAgICBhd2FpdCBPcGVuU2VhcmNoU2VydmljZS51cGRhdGVEb2N1bWVudChjbGllbnQsIENBU0VfSU5ERVgsIGNhc2VJZCwge1xuICAgICAgbGlua2VkX2FsZXJ0czogdXBkYXRlZEFsZXJ0cyxcbiAgICAgIGFjdGl2aXR5X2xvZzogWy4uLmV4aXN0aW5nLmFjdGl2aXR5X2xvZywgYWN0aXZpdHldLFxuICAgICAgdXBkYXRlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIH0pO1xuXG4gICAgcmV0dXJuIGF3YWl0IENhc2VTZXJ2aWNlLmdldENhc2UoY2xpZW50LCBjYXNlSWQpO1xuICB9XG5cbiAgLyoqIFNlYXJjaCBXYXp1aCBhbGVydHMgaW4gT3BlblNlYXJjaCAqL1xuICBzdGF0aWMgYXN5bmMgc2VhcmNoQWxlcnRzKFxuICAgIGNsaWVudDogYW55LFxuICAgIHF1ZXJ5OiBXYXp1aEFsZXJ0U2VhcmNoUXVlcnksXG4gICk6IFByb21pc2U8eyBoaXRzOiBhbnlbXTsgdG90YWw6IG51bWJlciB9PiB7XG4gICAgY29uc3QgbXVzdDogYW55W10gPSBbXTtcblxuICAgIGlmIChxdWVyeS5zZWFyY2gpIHtcbiAgICAgIG11c3QucHVzaCh7XG4gICAgICAgIG11bHRpX21hdGNoOiB7XG4gICAgICAgICAgcXVlcnk6IHF1ZXJ5LnNlYXJjaCxcbiAgICAgICAgICBmaWVsZHM6IFsncnVsZS5kZXNjcmlwdGlvbl4yJywgJ2Z1bGxfbG9nJywgJ2RhdGEuKiddLFxuICAgICAgICAgIGZ1enppbmVzczogJ0FVVE8nLFxuICAgICAgICAgIC8vIGRhdGEuKiBzcGFucyBub24tdGV4dCBmaWVsZHMgKGRhdGUvaXAvbnVtYmVyKTsgbGVuaWVudCBza2lwcyB0aGVtXG4gICAgICAgICAgLy8gaW5zdGVhZCBvZiB0aHJvd2luZyBxdWVyeV9zaGFyZF9leGNlcHRpb24gKDQwMCBCYWQgUmVxdWVzdCkuXG4gICAgICAgICAgbGVuaWVudDogdHJ1ZSxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH1cbiAgICBpZiAocXVlcnkuYWdlbnRfaWQpIHtcbiAgICAgIG11c3QucHVzaCh7IHRlcm06IHsgJ2FnZW50LmlkJzogcXVlcnkuYWdlbnRfaWQgfSB9KTtcbiAgICB9XG4gICAgaWYgKHF1ZXJ5LnJ1bGVfaWQpIHtcbiAgICAgIG11c3QucHVzaCh7IHRlcm06IHsgJ3J1bGUuaWQnOiBTdHJpbmcocXVlcnkucnVsZV9pZCkgfSB9KTtcbiAgICB9XG4gICAgaWYgKHF1ZXJ5LmxldmVsX21pbiB8fCBxdWVyeS5sZXZlbF9tYXgpIHtcbiAgICAgIGNvbnN0IHJhbmdlOiBhbnkgPSB7fTtcbiAgICAgIGlmIChxdWVyeS5sZXZlbF9taW4pIHJhbmdlLmd0ZSA9IHF1ZXJ5LmxldmVsX21pbjtcbiAgICAgIGlmIChxdWVyeS5sZXZlbF9tYXgpIHJhbmdlLmx0ZSA9IHF1ZXJ5LmxldmVsX21heDtcbiAgICAgIG11c3QucHVzaCh7IHJhbmdlOiB7ICdydWxlLmxldmVsJzogcmFuZ2UgfSB9KTtcbiAgICB9XG4gICAgaWYgKHF1ZXJ5LmZyb20gfHwgcXVlcnkudG8pIHtcbiAgICAgIGNvbnN0IHJhbmdlOiBhbnkgPSB7fTtcbiAgICAgIGlmIChxdWVyeS5mcm9tKSByYW5nZS5ndGUgPSBxdWVyeS5mcm9tO1xuICAgICAgaWYgKHF1ZXJ5LnRvKSByYW5nZS5sdGUgPSBxdWVyeS50bztcbiAgICAgIG11c3QucHVzaCh7IHJhbmdlOiB7IHRpbWVzdGFtcDogcmFuZ2UgfSB9KTtcbiAgICB9XG5cbiAgICBjb25zdCBzZWFyY2hCb2R5ID0ge1xuICAgICAgcXVlcnk6IG11c3QubGVuZ3RoID4gMCA/IHsgYm9vbDogeyBtdXN0IH0gfSA6IHsgbWF0Y2hfYWxsOiB7fSB9LFxuICAgICAgc29ydDogW3sgdGltZXN0YW1wOiB7IG9yZGVyOiAnZGVzYycgfSB9XSxcbiAgICAgIHNpemU6IE1hdGgubWluKHF1ZXJ5LnNpemUgfHwgNTAsIDEwMCksXG4gICAgfTtcblxuICAgIHJldHVybiBhd2FpdCBPcGVuU2VhcmNoU2VydmljZS5zZWFyY2hEb2N1bWVudHMoY2xpZW50LCBXQVpVSF9BTEVSVFNfSU5ERVhfUEFUVEVSTiwgc2VhcmNoQm9keSk7XG4gIH1cblxuICAvLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgLy8gT2JzZXJ2YWJsZXNcbiAgLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbiAgLyoqIEFkZCBhbiBvYnNlcnZhYmxlIHRvIGEgY2FzZSAqL1xuICBzdGF0aWMgYXN5bmMgYWRkT2JzZXJ2YWJsZShcbiAgICBjbGllbnQ6IGFueSxcbiAgICBjYXNlSWQ6IHN0cmluZyxcbiAgICBvYnNlcnZhYmxlOiBPbWl0PE9ic2VydmFibGUsICdpZCcgfCAnYWRkZWRfYXQnIHwgJ2FkZGVkX2J5Jz4sXG4gICAgdXNlcjogc3RyaW5nLFxuICApOiBQcm9taXNlPENhc2UgfCBudWxsPiB7XG4gICAgY29uc3QgZXhpc3RpbmcgPSBhd2FpdCBDYXNlU2VydmljZS5nZXRDYXNlKGNsaWVudCwgY2FzZUlkKTtcbiAgICBpZiAoIWV4aXN0aW5nKSByZXR1cm4gbnVsbDtcblxuICAgIGNvbnN0IG5ld09ic2VydmFibGU6IE9ic2VydmFibGUgPSB7XG4gICAgICAuLi5vYnNlcnZhYmxlLFxuICAgICAgaWQ6IHV1aWQoKSxcbiAgICAgIGFkZGVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICBhZGRlZF9ieTogdXNlcixcbiAgICB9O1xuXG4gICAgY29uc3QgYWN0aXZpdHkgPSBDYXNlU2VydmljZS5jcmVhdGVBY3Rpdml0eSgnb2JzZXJ2YWJsZV9hZGRlZCcsIHVzZXIsIHtcbiAgICAgIHR5cGU6IG9ic2VydmFibGUudHlwZSxcbiAgICAgIHZhbHVlOiBvYnNlcnZhYmxlLnZhbHVlLFxuICAgIH0pO1xuXG4gICAgYXdhaXQgT3BlblNlYXJjaFNlcnZpY2UudXBkYXRlRG9jdW1lbnQoY2xpZW50LCBDQVNFX0lOREVYLCBjYXNlSWQsIHtcbiAgICAgIG9ic2VydmFibGVzOiBbLi4uZXhpc3Rpbmcub2JzZXJ2YWJsZXMsIG5ld09ic2VydmFibGVdLFxuICAgICAgYWN0aXZpdHlfbG9nOiBbLi4uZXhpc3RpbmcuYWN0aXZpdHlfbG9nLCBhY3Rpdml0eV0sXG4gICAgICB1cGRhdGVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgfSk7XG5cbiAgICByZXR1cm4gYXdhaXQgQ2FzZVNlcnZpY2UuZ2V0Q2FzZShjbGllbnQsIGNhc2VJZCk7XG4gIH1cblxuICAvKiogUmVtb3ZlIGFuIG9ic2VydmFibGUgZnJvbSBhIGNhc2UgKi9cbiAgc3RhdGljIGFzeW5jIHJlbW92ZU9ic2VydmFibGUoXG4gICAgY2xpZW50OiBhbnksXG4gICAgY2FzZUlkOiBzdHJpbmcsXG4gICAgb2JzZXJ2YWJsZUlkOiBzdHJpbmcsXG4gICAgdXNlcjogc3RyaW5nLFxuICApOiBQcm9taXNlPENhc2UgfCBudWxsPiB7XG4gICAgY29uc3QgZXhpc3RpbmcgPSBhd2FpdCBDYXNlU2VydmljZS5nZXRDYXNlKGNsaWVudCwgY2FzZUlkKTtcbiAgICBpZiAoIWV4aXN0aW5nKSByZXR1cm4gbnVsbDtcblxuICAgIGNvbnN0IHVwZGF0ZWQgPSBleGlzdGluZy5vYnNlcnZhYmxlcy5maWx0ZXIoKG8pID0+IG8uaWQgIT09IG9ic2VydmFibGVJZCk7XG4gICAgY29uc3QgYWN0aXZpdHkgPSBDYXNlU2VydmljZS5jcmVhdGVBY3Rpdml0eSgnb2JzZXJ2YWJsZV9yZW1vdmVkJywgdXNlciwge1xuICAgICAgb2JzZXJ2YWJsZV9pZDogb2JzZXJ2YWJsZUlkLFxuICAgIH0pO1xuXG4gICAgYXdhaXQgT3BlblNlYXJjaFNlcnZpY2UudXBkYXRlRG9jdW1lbnQoY2xpZW50LCBDQVNFX0lOREVYLCBjYXNlSWQsIHtcbiAgICAgIG9ic2VydmFibGVzOiB1cGRhdGVkLFxuICAgICAgYWN0aXZpdHlfbG9nOiBbLi4uZXhpc3RpbmcuYWN0aXZpdHlfbG9nLCBhY3Rpdml0eV0sXG4gICAgICB1cGRhdGVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgfSk7XG5cbiAgICByZXR1cm4gYXdhaXQgQ2FzZVNlcnZpY2UuZ2V0Q2FzZShjbGllbnQsIGNhc2VJZCk7XG4gIH1cblxuICAvLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgLy8gQW5hbHl0aWNzXG4gIC8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG4gIC8qKiBHZXQgc3VtbWFyeSBhbmFseXRpY3MgZm9yIHRoZSBkYXNoYm9hcmQgKi9cbiAgc3RhdGljIGFzeW5jIGdldEFuYWx5dGljc1N1bW1hcnkoY2xpZW50OiBhbnkpOiBQcm9taXNlPEFuYWx5dGljc1N1bW1hcnk+IHtcbiAgICB0cnkge1xuICAgICAgLy8gU2VsZi1oZWFsOiBpZiB0aGUgaW5kZXggd2FzIGRlbGV0ZWQsIHJlY3JlYXRlIGl0IHdpdGggdGhlIGNvcnJlY3QgbWFwcGluZ1xuICAgICAgLy8gKGtleXdvcmQgZmllbGRzKSBzbyBhZ2dyZWdhdGlvbnMgZG9uJ3QgZmFpbCB3aXRoIGEgNDAwLlxuICAgICAgYXdhaXQgT3BlblNlYXJjaFNlcnZpY2UuZW5zdXJlSW5kZXgoY2xpZW50LCBDQVNFX0lOREVYLCBjYXNlTWFwcGluZ3MpO1xuICAgICAgcmV0dXJuIGF3YWl0IENhc2VTZXJ2aWNlLmNvbXB1dGVBbmFseXRpY3NTdW1tYXJ5KGNsaWVudCk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgLy8gTmV2ZXIgc3VyZmFjZSBhIHJhdyA0MDAvYWdncmVnYXRpb24gZXJyb3IgdG8gdGhlIGRhc2hib2FyZCDigJQgcmV0dXJuIGFuXG4gICAgICAvLyBlbXB0eSBzdW1tYXJ5IHNvIHRoZSBVSSBzaG93cyBhbiBlbXB0eSBzdGF0ZSBpbnN0ZWFkIG9mIFwiQmFkIFJlcXVlc3RcIi5cbiAgICAgIHJldHVybiBlbXB0eUFuYWx5dGljc1N1bW1hcnkoKTtcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIHN0YXRpYyBhc3luYyBjb21wdXRlQW5hbHl0aWNzU3VtbWFyeShjbGllbnQ6IGFueSk6IFByb21pc2U8QW5hbHl0aWNzU3VtbWFyeT4ge1xuICAgIGNvbnN0IHRvZGF5ID0gbmV3IERhdGUoKTtcbiAgICB0b2RheS5zZXRIb3VycygwLCAwLCAwLCAwKTtcbiAgICBjb25zdCB0b2RheVN0ciA9IHRvZGF5LnRvSVNPU3RyaW5nKCk7XG5cbiAgICBjb25zdCBhZ2dzID0gYXdhaXQgT3BlblNlYXJjaFNlcnZpY2UuYWdncmVnYXRlRG9jdW1lbnRzKGNsaWVudCwgQ0FTRV9JTkRFWCwge1xuICAgICAgYWdnczoge1xuICAgICAgICBieV9zdGF0dXM6IHsgdGVybXM6IHsgZmllbGQ6ICdzdGF0dXMnLCBzaXplOiAxMCB9IH0sXG4gICAgICAgIGJ5X3NldmVyaXR5OiB7IHRlcm1zOiB7IGZpZWxkOiAnc2V2ZXJpdHknLCBzaXplOiAxMCB9IH0sXG4gICAgICAgIGJ5X3ByaW9yaXR5OiB7IHRlcm1zOiB7IGZpZWxkOiAncHJpb3JpdHknLCBzaXplOiAxMCB9IH0sXG4gICAgICAgIGJ5X2NhdGVnb3J5OiB7IHRlcm1zOiB7IGZpZWxkOiAnY2F0ZWdvcnknLCBzaXplOiAyMCB9IH0sXG4gICAgICAgIGF2Z19yZXNvbHV0aW9uX3RpbWU6IHsgYXZnOiB7IGZpZWxkOiAndGltZV90b19yZXNvbHZlX21zJyB9IH0sXG4gICAgICAgIGNyZWF0ZWRfdG9kYXk6IHtcbiAgICAgICAgICBmaWx0ZXI6IHsgcmFuZ2U6IHsgY3JlYXRlZF9hdDogeyBndGU6IHRvZGF5U3RyIH0gfSB9LFxuICAgICAgICB9LFxuICAgICAgICBjbG9zZWRfdG9kYXk6IHtcbiAgICAgICAgICBmaWx0ZXI6IHtcbiAgICAgICAgICAgIGJvb2w6IHtcbiAgICAgICAgICAgICAgbXVzdDogW1xuICAgICAgICAgICAgICAgIHsgcmFuZ2U6IHsgY2xvc2VkX2F0OiB7IGd0ZTogdG9kYXlTdHIgfSB9IH0sXG4gICAgICAgICAgICAgICAgeyB0ZXJtczogeyBzdGF0dXM6IFsncmVzb2x2ZWQnLCAnY2xvc2VkJ10gfSB9LFxuICAgICAgICAgICAgICBdLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICB9LFxuICAgICAgICB0b3RhbDogeyB2YWx1ZV9jb3VudDogeyBmaWVsZDogJ2Nhc2VfaWQnIH0gfSxcbiAgICAgIH0sXG4gICAgfSk7XG5cbiAgICAvLyBQYXJzZSBzdGF0dXMgY291bnRzXG4gICAgY29uc3Qgc3RhdHVzQ291bnRzOiBSZWNvcmQ8c3RyaW5nLCBudW1iZXI+ID0ge307XG4gICAgKGFnZ3MuYnlfc3RhdHVzPy5idWNrZXRzIHx8IFtdKS5mb3JFYWNoKChiOiBhbnkpID0+IHtcbiAgICAgIHN0YXR1c0NvdW50c1tiLmtleV0gPSBiLmRvY19jb3VudDtcbiAgICB9KTtcblxuICAgIC8vIFBhcnNlIHNldmVyaXR5IGNvdW50c1xuICAgIGNvbnN0IHNldmVyaXR5Q291bnRzOiBSZWNvcmQ8c3RyaW5nLCBudW1iZXI+ID0ge307XG4gICAgKGFnZ3MuYnlfc2V2ZXJpdHk/LmJ1Y2tldHMgfHwgW10pLmZvckVhY2goKGI6IGFueSkgPT4ge1xuICAgICAgc2V2ZXJpdHlDb3VudHNbYi5rZXldID0gYi5kb2NfY291bnQ7XG4gICAgfSk7XG5cbiAgICAvLyBQYXJzZSBwcmlvcml0eSBjb3VudHNcbiAgICBjb25zdCBwcmlvcml0eUNvdW50czogUmVjb3JkPHN0cmluZywgbnVtYmVyPiA9IHt9O1xuICAgIChhZ2dzLmJ5X3ByaW9yaXR5Py5idWNrZXRzIHx8IFtdKS5mb3JFYWNoKChiOiBhbnkpID0+IHtcbiAgICAgIHByaW9yaXR5Q291bnRzW2Iua2V5XSA9IGIuZG9jX2NvdW50O1xuICAgIH0pO1xuXG4gICAgLy8gUGFyc2UgY2F0ZWdvcnkgY291bnRzXG4gICAgY29uc3QgY2F0ZWdvcnlDb3VudHM6IFJlY29yZDxzdHJpbmcsIG51bWJlcj4gPSB7fTtcbiAgICAoYWdncy5ieV9jYXRlZ29yeT8uYnVja2V0cyB8fCBbXSkuZm9yRWFjaCgoYjogYW55KSA9PiB7XG4gICAgICBjYXRlZ29yeUNvdW50c1tiLmtleV0gPSBiLmRvY19jb3VudDtcbiAgICB9KTtcblxuICAgIGNvbnN0IHRvdGFsQ2FzZXMgPSBhZ2dzLnRvdGFsPy52YWx1ZSB8fCAwO1xuXG4gICAgcmV0dXJuIHtcbiAgICAgIHRvdGFsX2Nhc2VzOiB0b3RhbENhc2VzLFxuICAgICAgb3Blbl9jYXNlczogc3RhdHVzQ291bnRzWydvcGVuJ10gfHwgMCxcbiAgICAgIGluX3Byb2dyZXNzX2Nhc2VzOiBzdGF0dXNDb3VudHNbJ2luX3Byb2dyZXNzJ10gfHwgMCxcbiAgICAgIHdhaXRpbmdfY2FzZXM6IHN0YXR1c0NvdW50c1snd2FpdGluZyddIHx8IDAsXG4gICAgICByZXNvbHZlZF9jYXNlczogc3RhdHVzQ291bnRzWydyZXNvbHZlZCddIHx8IDAsXG4gICAgICBjbG9zZWRfY2FzZXM6IHN0YXR1c0NvdW50c1snY2xvc2VkJ10gfHwgMCxcbiAgICAgIGJ5X3NldmVyaXR5OiBzZXZlcml0eUNvdW50cyBhcyBhbnksXG4gICAgICBieV9wcmlvcml0eTogcHJpb3JpdHlDb3VudHMgYXMgYW55LFxuICAgICAgYnlfY2F0ZWdvcnk6IGNhdGVnb3J5Q291bnRzLFxuICAgICAgYXZnX3Jlc29sdXRpb25fdGltZV9tczogYWdncy5hdmdfcmVzb2x1dGlvbl90aW1lPy52YWx1ZSB8fCBudWxsLFxuICAgICAgY2FzZXNfY3JlYXRlZF90b2RheTogYWdncy5jcmVhdGVkX3RvZGF5Py5kb2NfY291bnQgfHwgMCxcbiAgICAgIGNhc2VzX2Nsb3NlZF90b2RheTogYWdncy5jbG9zZWRfdG9kYXk/LmRvY19jb3VudCB8fCAwLFxuICAgIH07XG4gIH1cblxuICAvKiogR2V0IGNhc2UgdHJlbmRzIG92ZXIgdGhlIGxhc3QgTiBkYXlzICovXG4gIHN0YXRpYyBhc3luYyBnZXRDYXNlVHJlbmRzKGNsaWVudDogYW55LCBkYXlzOiBudW1iZXIgPSAzMCk6IFByb21pc2U8Q2FzZVRyZW5kW10+IHtcbiAgICBjb25zdCBmcm9tRGF0ZSA9IG5ldyBEYXRlKCk7XG4gICAgZnJvbURhdGUuc2V0RGF0ZShmcm9tRGF0ZS5nZXREYXRlKCkgLSBkYXlzKTtcblxuICAgIGNvbnN0IGFnZ3MgPSBhd2FpdCBPcGVuU2VhcmNoU2VydmljZS5hZ2dyZWdhdGVEb2N1bWVudHMoY2xpZW50LCBDQVNFX0lOREVYLCB7XG4gICAgICBxdWVyeToge1xuICAgICAgICByYW5nZTogeyBjcmVhdGVkX2F0OiB7IGd0ZTogZnJvbURhdGUudG9JU09TdHJpbmcoKSB9IH0sXG4gICAgICB9LFxuICAgICAgYWdnczoge1xuICAgICAgICBjYXNlc19vdmVyX3RpbWU6IHtcbiAgICAgICAgICBkYXRlX2hpc3RvZ3JhbToge1xuICAgICAgICAgICAgZmllbGQ6ICdjcmVhdGVkX2F0JyxcbiAgICAgICAgICAgIGNhbGVuZGFyX2ludGVydmFsOiAnZGF5JyxcbiAgICAgICAgICB9LFxuICAgICAgICB9LFxuICAgICAgICBjbG9zZWRfb3Zlcl90aW1lOiB7XG4gICAgICAgICAgZmlsdGVyOiB7IGV4aXN0czogeyBmaWVsZDogJ2Nsb3NlZF9hdCcgfSB9LFxuICAgICAgICAgIGFnZ3M6IHtcbiAgICAgICAgICAgIGJ5X2RheToge1xuICAgICAgICAgICAgICBkYXRlX2hpc3RvZ3JhbToge1xuICAgICAgICAgICAgICAgIGZpZWxkOiAnY2xvc2VkX2F0JyxcbiAgICAgICAgICAgICAgICBjYWxlbmRhcl9pbnRlcnZhbDogJ2RheScsXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgIH0pO1xuXG4gICAgY29uc3QgY3JlYXRlZEJ1Y2tldHMgPSBhZ2dzLmNhc2VzX292ZXJfdGltZT8uYnVja2V0cyB8fCBbXTtcbiAgICBjb25zdCBjbG9zZWRCdWNrZXRzID0gYWdncy5jbG9zZWRfb3Zlcl90aW1lPy5ieV9kYXk/LmJ1Y2tldHMgfHwgW107XG5cbiAgICAvLyBNZXJnZSBjcmVhdGVkIGFuZCBjbG9zZWQgaW50byBhIHNpbmdsZSB0aW1lbGluZVxuICAgIGNvbnN0IGNsb3NlZE1hcDogUmVjb3JkPHN0cmluZywgbnVtYmVyPiA9IHt9O1xuICAgIGNsb3NlZEJ1Y2tldHMuZm9yRWFjaCgoYjogYW55KSA9PiB7XG4gICAgICBjb25zdCBkYXRlS2V5ID0gYi5rZXlfYXNfc3RyaW5nPy5zcGxpdCgnVCcpWzBdIHx8ICcnO1xuICAgICAgY2xvc2VkTWFwW2RhdGVLZXldID0gYi5kb2NfY291bnQ7XG4gICAgfSk7XG5cbiAgICByZXR1cm4gY3JlYXRlZEJ1Y2tldHMubWFwKChiOiBhbnkpID0+IHtcbiAgICAgIGNvbnN0IGRhdGVLZXkgPSBiLmtleV9hc19zdHJpbmc/LnNwbGl0KCdUJylbMF0gfHwgJyc7XG4gICAgICByZXR1cm4ge1xuICAgICAgICBkYXRlOiBkYXRlS2V5LFxuICAgICAgICBjcmVhdGVkOiBiLmRvY19jb3VudCxcbiAgICAgICAgY2xvc2VkOiBjbG9zZWRNYXBbZGF0ZUtleV0gfHwgMCxcbiAgICAgIH07XG4gICAgfSk7XG4gIH1cblxuICAvLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgLy8gQXV0b21hdGVkIEFsZXJ0IEhhbmRsaW5nIChXZWJob29rcylcbiAgLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbiAgLyoqXG4gICAqIFByb2Nlc3MgYW4gaW5jb21pbmcgYWxlcnQgZnJvbSBhIFdhenVoIHdlYmhvb2suXG4gICAqIFBlcmZvcm1zIGRlZHVwbGljYXRpb24gYmFzZWQgb24gcnVsZS5pZCBhbmQgYWdlbnQuaWQgZm9yIHVucmVzb2x2ZWQgY2FzZXMuXG4gICAqL1xuICBzdGF0aWMgYXN5bmMgaGFuZGxlQXV0b21hdGVkQWxlcnQoY2xpZW50OiBhbnksIGFsZXJ0OiBhbnksIHVzZXI6IHN0cmluZyk6IFByb21pc2U8Q2FzZSB8IG51bGw+IHtcbiAgICBjb25zdCBydWxlSWQgPSBhbGVydC5ydWxlPy5pZDtcbiAgICBjb25zdCBhZ2VudElkID0gYWxlcnQuYWdlbnQ/LmlkO1xuICAgIGNvbnN0IGFsZXJ0SWQgPSBhbGVydC5pZDtcblxuICAgIGlmICghcnVsZUlkIHx8ICFhZ2VudElkIHx8ICFhbGVydElkKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ0ludmFsaWQgYWxlcnQgcGF5bG9hZDogTWlzc2luZyBydWxlLmlkLCBhZ2VudC5pZCwgb3IgaWQnKTtcbiAgICB9XG5cbiAgICBjb25zdCBsaW5rZWRBbGVydDogTGlua2VkQWxlcnQgPSB7XG4gICAgICBhbGVydF9pZDogYWxlcnRJZCxcbiAgICAgIGluZGV4OiBhbGVydC5faW5kZXggfHwgJ3dhenVoLWFsZXJ0cy0qJyxcbiAgICAgIHJ1bGVfaWQ6IHBhcnNlSW50KHJ1bGVJZCwgMTApLFxuICAgICAgcnVsZV9kZXNjcmlwdGlvbjogYWxlcnQucnVsZT8uZGVzY3JpcHRpb24gfHwgJ1Vua25vd24gUnVsZScsXG4gICAgICBydWxlX2xldmVsOiBhbGVydC5ydWxlPy5sZXZlbCB8fCAwLFxuICAgICAgcnVsZV9ncm91cHM6IGFsZXJ0LnJ1bGU/Lmdyb3VwcyB8fCBbXSxcbiAgICAgIGFnZW50X2lkOiBhZ2VudElkLFxuICAgICAgYWdlbnRfbmFtZTogYWxlcnQuYWdlbnQ/Lm5hbWUgfHwgJ1Vua25vd24gQWdlbnQnLFxuICAgICAgdGltZXN0YW1wOiBhbGVydC50aW1lc3RhbXAgfHwgbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgZnVsbF9sb2c6IGFsZXJ0LmZ1bGxfbG9nLFxuICAgIH07XG5cbiAgICAvLyBTZWFyY2ggZm9yIGFuIHVucmVzb2x2ZWQgY2FzZSB3aXRoIHRoZSBleGFjdCBzYW1lIHJ1bGUgYW5kIGFnZW50XG4gICAgY29uc3Qgc2VhcmNoQm9keSA9IHtcbiAgICAgIHF1ZXJ5OiB7XG4gICAgICAgIGJvb2w6IHtcbiAgICAgICAgICBtdXN0OiBbXG4gICAgICAgICAgICB7IHRlcm1zOiB7IHN0YXR1czogWydvcGVuJywgJ2luX3Byb2dyZXNzJywgJ3dhaXRpbmcnXSB9IH0sXG4gICAgICAgICAgICB7IHRlcm06IHsgJ2N1c3RvbV9maWVsZHMuYXV0b21hdGVkX3J1bGVfaWQua2V5d29yZCc6IFN0cmluZyhydWxlSWQpIH0gfSxcbiAgICAgICAgICAgIHsgdGVybTogeyAnY3VzdG9tX2ZpZWxkcy5hdXRvbWF0ZWRfYWdlbnRfaWQua2V5d29yZCc6IFN0cmluZyhhZ2VudElkKSB9IH1cbiAgICAgICAgICBdXG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICBzaXplOiAxLFxuICAgICAgc29ydDogW3sgY3JlYXRlZF9hdDogeyBvcmRlcjogJ2Rlc2MnIH0gfV1cbiAgICB9O1xuXG4gICAgY29uc3Qgc2VhcmNoUmVzdWx0ID0gYXdhaXQgT3BlblNlYXJjaFNlcnZpY2Uuc2VhcmNoRG9jdW1lbnRzKGNsaWVudCwgQ0FTRV9JTkRFWCwgc2VhcmNoQm9keSk7XG4gICAgXG4gICAgLy8gSUYgRFVQTElDQVRFIEZPVU5EOiBBcHBlbmQgYWxlcnQgYW5kIGFkZCBjb21tZW50XG4gICAgaWYgKHNlYXJjaFJlc3VsdC5oaXRzLmxlbmd0aCA+IDApIHtcbiAgICAgIGNvbnN0IGV4aXN0aW5nQ2FzZSA9IHNlYXJjaFJlc3VsdC5oaXRzWzBdO1xuICAgICAgY29uc3QgY2FzZUlkID0gZXhpc3RpbmdDYXNlLl9pZDtcbiAgICAgIFxuICAgICAgLy8gQXZvaWQgbGlua2luZyB0aGUgZXhhY3Qgc2FtZSBhbGVydCB0d2ljZVxuICAgICAgY29uc3QgYWxyZWFkeUxpbmtlZCA9IGV4aXN0aW5nQ2FzZS5fc291cmNlLmxpbmtlZF9hbGVydHMuc29tZSgoYTogYW55KSA9PiBhLmFsZXJ0X2lkID09PSBhbGVydElkKTtcbiAgICAgIGlmIChhbHJlYWR5TGlua2VkKSB7XG4gICAgICAgICByZXR1cm4geyBpZDogY2FzZUlkLCAuLi5leGlzdGluZ0Nhc2UuX3NvdXJjZSB9IGFzIENhc2U7XG4gICAgICB9XG5cbiAgICAgIC8vIEFkZCBhdXRvbWF0ZWQgY29tbWVudFxuICAgICAgY29uc3QgY29tbWVudElkID0gdXVpZCgpO1xuICAgICAgY29uc3QgY29tbWVudDogQ2FzZUNvbW1lbnQgPSB7XG4gICAgICAgIGNvbW1lbnRfaWQ6IGNvbW1lbnRJZCxcbiAgICAgICAgYXV0aG9yOiAnU3lzdGVtIEF1dG9tYXRpb24nLFxuICAgICAgICBjb250ZW50OiBgRHVwbGljYXRlIGFsZXJ0IGRldGVjdGVkIChSdWxlICR7cnVsZUlkfSBvbiBBZ2VudCAke2FnZW50SWR9KS4gQXV0b21hdGljYWxseSBsaW5rZWQuYCxcbiAgICAgICAgY3JlYXRlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgfTtcblxuICAgICAgY29uc3QgdXBkYXRlRG9jID0ge1xuICAgICAgICBsaW5rZWRfYWxlcnRzOiBbLi4uZXhpc3RpbmdDYXNlLl9zb3VyY2UubGlua2VkX2FsZXJ0cywgbGlua2VkQWxlcnRdLFxuICAgICAgICBjb21tZW50czogWy4uLmV4aXN0aW5nQ2FzZS5fc291cmNlLmNvbW1lbnRzLCBjb21tZW50XSxcbiAgICAgICAgdXBkYXRlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgfTtcblxuICAgICAgYXdhaXQgT3BlblNlYXJjaFNlcnZpY2UudXBkYXRlRG9jdW1lbnQoY2xpZW50LCBDQVNFX0lOREVYLCBjYXNlSWQsIHVwZGF0ZURvYyk7XG4gICAgICByZXR1cm4gYXdhaXQgQ2FzZVNlcnZpY2UuZ2V0Q2FzZShjbGllbnQsIGNhc2VJZCk7XG4gICAgfVxuXG4gICAgLy8gSUYgTk8gRFVQTElDQVRFOiBDcmVhdGUgbmV3IGNhc2VcbiAgICBsZXQgc2V2ZXJpdHk6IENhc2VTZXZlcml0eSA9ICdsb3cnO1xuICAgIGNvbnN0IGxldmVsID0gYWxlcnQucnVsZT8ubGV2ZWwgfHwgMDtcbiAgICBpZiAobGV2ZWwgPj0gMTIpIHNldmVyaXR5ID0gJ2NyaXRpY2FsJztcbiAgICBlbHNlIGlmIChsZXZlbCA+PSA4KSBzZXZlcml0eSA9ICdoaWdoJztcbiAgICBlbHNlIGlmIChsZXZlbCA+PSA1KSBzZXZlcml0eSA9ICdtZWRpdW0nO1xuXG4gICAgY29uc3QgcGF5bG9hZDogQ3JlYXRlQ2FzZVBheWxvYWQgPSB7XG4gICAgICB0aXRsZTogYFtBdXRvbWF0ZWRdICR7YWxlcnQucnVsZT8uZGVzY3JpcHRpb24gfHwgJ1NlY3VyaXR5IEFsZXJ0J31gLFxuICAgICAgZGVzY3JpcHRpb246IGBBdXRvbWF0ZWQgY2FzZSBjcmVhdGVkIGZyb20gV2F6dWggQWxlcnQuXFxuXFxuUnVsZTogJHtydWxlSWR9XFxuQWdlbnQ6ICR7YWxlcnQuYWdlbnQ/Lm5hbWV9ICgke2FnZW50SWR9KVxcbkxldmVsOiAke2xldmVsfVxcblxcbkxvZzogJHthbGVydC5mdWxsX2xvZyB8fCAnTi9BJ31gLFxuICAgICAgc2V2ZXJpdHksXG4gICAgICBwcmlvcml0eTogJ1AyJyxcbiAgICAgIGNhdGVnb3J5OiAnb3RoZXInLFxuICAgICAgdGFnczogWydhdXRvbWF0ZWQnLCBgcnVsZV8ke3J1bGVJZH1gLCBgYWdlbnRfJHthZ2VudElkfWBdLFxuICAgIH07XG5cbiAgICBjb25zdCBuZXdDYXNlID0gYXdhaXQgQ2FzZVNlcnZpY2UuY3JlYXRlQ2FzZShjbGllbnQsIHBheWxvYWQsIHVzZXIpO1xuICAgIFxuICAgIC8vIEFkZCBjdXN0b20gZmllbGRzIGZvciBkZWR1cGxpY2F0aW9uIHRyYWNraW5nXG4gICAgaWYgKG5ld0Nhc2UuaWQpIHtcbiAgICAgICBhd2FpdCBPcGVuU2VhcmNoU2VydmljZS51cGRhdGVEb2N1bWVudChjbGllbnQsIENBU0VfSU5ERVgsIG5ld0Nhc2UuaWQsIHtcbiAgICAgICAgIGN1c3RvbV9maWVsZHM6IHtcbiAgICAgICAgICAgYXV0b21hdGVkX3J1bGVfaWQ6IFN0cmluZyhydWxlSWQpLFxuICAgICAgICAgICBhdXRvbWF0ZWRfYWdlbnRfaWQ6IFN0cmluZyhhZ2VudElkKVxuICAgICAgICAgfSxcbiAgICAgICAgIGxpbmtlZF9hbGVydHM6IFtsaW5rZWRBbGVydF1cbiAgICAgICB9KTtcbiAgICAgICByZXR1cm4gYXdhaXQgQ2FzZVNlcnZpY2UuZ2V0Q2FzZShjbGllbnQsIG5ld0Nhc2UuaWQpO1xuICAgIH1cbiAgICBcbiAgICByZXR1cm4gbmV3Q2FzZTtcbiAgfVxufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUF3QkEsSUFBQUEsVUFBQSxHQUFBQyxPQUFBO0FBWUEsSUFBQUMsbUJBQUEsR0FBQUQsT0FBQTtBQUNBLElBQUFFLGNBQUEsR0FBQUYsT0FBQTtBQXJDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFpQ0E7QUFDQSxTQUFTRyxxQkFBcUJBLENBQUEsRUFBcUI7RUFDakQsT0FBTztJQUNMQyxXQUFXLEVBQUUsQ0FBQztJQUNkQyxVQUFVLEVBQUUsQ0FBQztJQUNiQyxpQkFBaUIsRUFBRSxDQUFDO0lBQ3BCQyxhQUFhLEVBQUUsQ0FBQztJQUNoQkMsY0FBYyxFQUFFLENBQUM7SUFDakJDLFlBQVksRUFBRSxDQUFDO0lBQ2ZDLFdBQVcsRUFBRSxDQUFDLENBQVE7SUFDdEJDLFdBQVcsRUFBRSxDQUFDLENBQVE7SUFDdEJDLFdBQVcsRUFBRSxDQUFDLENBQUM7SUFDZkMsc0JBQXNCLEVBQUUsSUFBSTtJQUM1QkMsbUJBQW1CLEVBQUUsQ0FBQztJQUN0QkMsa0JBQWtCLEVBQUU7RUFDdEIsQ0FBQztBQUNIOztBQUVBO0FBQ0EsU0FBU0MsSUFBSUEsQ0FBQSxFQUFXO0VBQ3RCO0VBQ0EsSUFBSTtJQUNGLE9BQU9DLE1BQU0sQ0FBQ0MsVUFBVSxDQUFDLENBQUMsQ0FBQ0MsT0FBTyxDQUFDLElBQUksRUFBRSxFQUFFLENBQUMsQ0FBQ0MsU0FBUyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUM7RUFDL0QsQ0FBQyxDQUFDLE1BQU07SUFDTixPQUFPQyxJQUFJLENBQUNDLEdBQUcsQ0FBQyxDQUFDLENBQUNDLFFBQVEsQ0FBQyxFQUFFLENBQUMsR0FBR0MsSUFBSSxDQUFDQyxNQUFNLENBQUMsQ0FBQyxDQUFDRixRQUFRLENBQUMsRUFBRSxDQUFDLENBQUNILFNBQVMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0VBQzdFO0FBQ0Y7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDTyxNQUFNTSxXQUFXLENBQUM7RUFDdkI7RUFDQTtFQUNBOztFQUVBO0FBQ0Y7QUFDQTtBQUNBO0VBQ0UsYUFBYUMsY0FBY0EsQ0FBQ0MsTUFBVyxFQUFtQjtJQUN4RCxNQUFNQyxPQUFPLEdBQUcsTUFBTUMscUNBQWlCLENBQUNDLG1CQUFtQixDQUFDSCxNQUFNLENBQUM7SUFDbkUsTUFBTUksSUFBSSxHQUFHLElBQUlYLElBQUksQ0FBQyxDQUFDLENBQUNZLFdBQVcsQ0FBQyxDQUFDO0lBQ3JDLE1BQU1DLFNBQVMsR0FBR0MsTUFBTSxDQUFDTixPQUFPLENBQUMsQ0FBQ08sUUFBUSxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUM7SUFDbEQsT0FBUSxHQUFFQyx5QkFBZSxHQUFFQyw0QkFBa0IsR0FBRU4sSUFBSyxHQUFFTSw0QkFBa0IsR0FBRUosU0FBVSxFQUFDO0VBQ3ZGOztFQUVBO0VBQ0E7RUFDQTs7RUFFQSxPQUFlSyxjQUFjQSxDQUMzQkMsTUFBOEIsRUFDOUJDLElBQVksRUFDWkMsT0FBNkIsRUFDZjtJQUNkLE9BQU87TUFDTEMsRUFBRSxFQUFFM0IsSUFBSSxDQUFDLENBQUM7TUFDVndCLE1BQU07TUFDTkMsSUFBSTtNQUNKRyxTQUFTLEVBQUUsSUFBSXZCLElBQUksQ0FBQyxDQUFDLENBQUN3QixXQUFXLENBQUMsQ0FBQztNQUNuQ0g7SUFDRixDQUFDO0VBQ0g7O0VBRUE7RUFDQTtFQUNBOztFQUVBO0VBQ0EsYUFBYUksVUFBVUEsQ0FDckJsQixNQUFXLEVBQ1htQixPQUEwQixFQUMxQk4sSUFBWSxFQUNHO0lBQ2Y7SUFDQTtJQUNBLE1BQU1YLHFDQUFpQixDQUFDa0IsV0FBVyxDQUFDcEIsTUFBTSxFQUFFcUIsNkJBQWtCLEVBQUVDLDhCQUFlLENBQUM7SUFDaEYsTUFBTXBCLHFDQUFpQixDQUFDa0IsV0FBVyxDQUFDcEIsTUFBTSxFQUFFdUIscUJBQVUsRUFBRUMsMkJBQVksQ0FBQztJQUVyRSxNQUFNQyxNQUFNLEdBQUcsTUFBTTNCLFdBQVcsQ0FBQ0MsY0FBYyxDQUFDQyxNQUFNLENBQUM7SUFDdkQsTUFBTU4sR0FBRyxHQUFHLElBQUlELElBQUksQ0FBQyxDQUFDLENBQUN3QixXQUFXLENBQUMsQ0FBQztJQUVwQyxNQUFNUyxPQUFhLEdBQUc7TUFDcEJDLE9BQU8sRUFBRUYsTUFBTTtNQUNmRyxLQUFLLEVBQUVULE9BQU8sQ0FBQ1MsS0FBSztNQUNwQkMsV0FBVyxFQUFFVixPQUFPLENBQUNVLFdBQVc7TUFDaENDLE1BQU0sRUFBRSxNQUFNO01BQ2RDLFFBQVEsRUFBRVosT0FBTyxDQUFDWSxRQUFRO01BQzFCQyxRQUFRLEVBQUViLE9BQU8sQ0FBQ2EsUUFBUTtNQUMxQkMsUUFBUSxFQUFFZCxPQUFPLENBQUNjLFFBQVE7TUFDMUJDLEdBQUcsRUFBRWYsT0FBTyxDQUFDZSxHQUFHLElBQUksT0FBTztNQUMzQkMsSUFBSSxFQUFFaEIsT0FBTyxDQUFDZ0IsSUFBSSxJQUFJLEVBQUU7TUFDeEJDLFFBQVEsRUFBRWpCLE9BQU8sQ0FBQ2lCLFFBQVEsSUFBSSxJQUFJO01BQ2xDQyxVQUFVLEVBQUV4QixJQUFJO01BQ2hCeUIsVUFBVSxFQUFFNUMsR0FBRztNQUNmNkMsVUFBVSxFQUFFN0MsR0FBRztNQUNmOEMsU0FBUyxFQUFFLElBQUk7TUFDZkMsYUFBYSxFQUFFLEVBQUU7TUFDakJDLFdBQVcsRUFBRSxFQUFFO01BQ2ZDLFFBQVEsRUFBRSxFQUFFO01BQ1pDLEtBQUssRUFBRSxFQUFFO01BQ1RDLEtBQUssRUFBRSxFQUFFO01BQ1RDLFlBQVksRUFBRSxDQUNaaEQsV0FBVyxDQUFDYSxjQUFjLENBQUMsY0FBYyxFQUFFRSxJQUFJLEVBQUU7UUFDL0NjLE9BQU8sRUFBRUYsTUFBTTtRQUNmRyxLQUFLLEVBQUVULE9BQU8sQ0FBQ1M7TUFDakIsQ0FBQyxDQUFDLENBQ0g7TUFDRG1CLGtCQUFrQixFQUFFLElBQUk7TUFDeEJDLGtCQUFrQixFQUFFLElBQUk7TUFDeEJDLGFBQWEsRUFBRSxFQUFFO01BQ2pCQyxhQUFhLEVBQUUsQ0FBQztJQUNsQixDQUFDOztJQUVEO0lBQ0EsSUFBSS9CLE9BQU8sQ0FBQ2lCLFFBQVEsRUFBRTtNQUNwQlYsT0FBTyxDQUFDb0IsWUFBWSxDQUFDSyxJQUFJLENBQ3ZCckQsV0FBVyxDQUFDYSxjQUFjLENBQUMsVUFBVSxFQUFFRSxJQUFJLEVBQUU7UUFBRXVCLFFBQVEsRUFBRWpCLE9BQU8sQ0FBQ2lCO01BQVMsQ0FBQyxDQUM3RSxDQUFDO0lBQ0g7SUFFQSxNQUFNO01BQUVnQjtJQUFJLENBQUMsR0FBRyxNQUFNbEQscUNBQWlCLENBQUNtRCxjQUFjLENBQUNyRCxNQUFNLEVBQUV1QixxQkFBVSxFQUFFRyxPQUFPLENBQUM7SUFDbkZBLE9BQU8sQ0FBQ1gsRUFBRSxHQUFHcUMsR0FBRztJQUVoQixPQUFPMUIsT0FBTztFQUNoQjs7RUFFQTtFQUNBLGFBQWE0QixPQUFPQSxDQUFDdEQsTUFBVyxFQUFFZSxFQUFVLEVBQXdCO0lBQ2xFLE1BQU13QyxHQUFHLEdBQUcsTUFBTXJELHFDQUFpQixDQUFDc0QsV0FBVyxDQUFDeEQsTUFBTSxFQUFFdUIscUJBQVUsRUFBRVIsRUFBRSxDQUFDO0lBQ3ZFLElBQUksQ0FBQ3dDLEdBQUcsRUFBRSxPQUFPLElBQUk7SUFDckIsT0FBTztNQUFFeEMsRUFBRSxFQUFFd0MsR0FBRyxDQUFDSCxHQUFHO01BQUUsR0FBR0csR0FBRyxDQUFDRTtJQUFRLENBQUM7RUFDeEM7O0VBRUE7RUFDQSxhQUFhQyxVQUFVQSxDQUNyQjFELE1BQVcsRUFDWGUsRUFBVSxFQUNWSSxPQUEwQixFQUMxQk4sSUFBWSxFQUNVO0lBQ3RCLE1BQU04QyxRQUFRLEdBQUcsTUFBTTdELFdBQVcsQ0FBQ3dELE9BQU8sQ0FBQ3RELE1BQU0sRUFBRWUsRUFBRSxDQUFDO0lBQ3RELElBQUksQ0FBQzRDLFFBQVEsRUFBRSxPQUFPLElBQUk7SUFFMUIsTUFBTWpFLEdBQUcsR0FBRyxJQUFJRCxJQUFJLENBQUMsQ0FBQyxDQUFDd0IsV0FBVyxDQUFDLENBQUM7SUFDcEMsTUFBTTJDLFVBQTBCLEdBQUcsRUFBRTtJQUNyQyxNQUFNQyxTQUFjLEdBQUc7TUFBRXRCLFVBQVUsRUFBRTdDO0lBQUksQ0FBQzs7SUFFMUM7SUFDQSxJQUFJeUIsT0FBTyxDQUFDUyxLQUFLLEtBQUtrQyxTQUFTLElBQUkzQyxPQUFPLENBQUNTLEtBQUssS0FBSytCLFFBQVEsQ0FBQy9CLEtBQUssRUFBRTtNQUNuRWlDLFNBQVMsQ0FBQ2pDLEtBQUssR0FBR1QsT0FBTyxDQUFDUyxLQUFLO0lBQ2pDO0lBQ0EsSUFBSVQsT0FBTyxDQUFDVSxXQUFXLEtBQUtpQyxTQUFTLEVBQUU7TUFDckNELFNBQVMsQ0FBQ2hDLFdBQVcsR0FBR1YsT0FBTyxDQUFDVSxXQUFXO0lBQzdDO0lBQ0EsSUFBSVYsT0FBTyxDQUFDWSxRQUFRLEtBQUsrQixTQUFTLElBQUkzQyxPQUFPLENBQUNZLFFBQVEsS0FBSzRCLFFBQVEsQ0FBQzVCLFFBQVEsRUFBRTtNQUM1RThCLFNBQVMsQ0FBQzlCLFFBQVEsR0FBR1osT0FBTyxDQUFDWSxRQUFRO01BQ3JDNkIsVUFBVSxDQUFDVCxJQUFJLENBQ2JyRCxXQUFXLENBQUNhLGNBQWMsQ0FBQyxrQkFBa0IsRUFBRUUsSUFBSSxFQUFFO1FBQ25Ea0QsSUFBSSxFQUFFSixRQUFRLENBQUM1QixRQUFRO1FBQ3ZCaUMsRUFBRSxFQUFFN0MsT0FBTyxDQUFDWTtNQUNkLENBQUMsQ0FDSCxDQUFDO0lBQ0g7SUFDQSxJQUFJWixPQUFPLENBQUNhLFFBQVEsS0FBSzhCLFNBQVMsSUFBSTNDLE9BQU8sQ0FBQ2EsUUFBUSxLQUFLMkIsUUFBUSxDQUFDM0IsUUFBUSxFQUFFO01BQzVFNkIsU0FBUyxDQUFDN0IsUUFBUSxHQUFHYixPQUFPLENBQUNhLFFBQVE7TUFDckM0QixVQUFVLENBQUNULElBQUksQ0FDYnJELFdBQVcsQ0FBQ2EsY0FBYyxDQUFDLGtCQUFrQixFQUFFRSxJQUFJLEVBQUU7UUFDbkRrRCxJQUFJLEVBQUVKLFFBQVEsQ0FBQzNCLFFBQVE7UUFDdkJnQyxFQUFFLEVBQUU3QyxPQUFPLENBQUNhO01BQ2QsQ0FBQyxDQUNILENBQUM7SUFDSDtJQUNBLElBQUliLE9BQU8sQ0FBQ2MsUUFBUSxLQUFLNkIsU0FBUyxFQUFFO01BQ2xDRCxTQUFTLENBQUM1QixRQUFRLEdBQUdkLE9BQU8sQ0FBQ2MsUUFBUTtJQUN2QztJQUNBLElBQUlkLE9BQU8sQ0FBQ2UsR0FBRyxLQUFLNEIsU0FBUyxFQUFFO01BQzdCRCxTQUFTLENBQUMzQixHQUFHLEdBQUdmLE9BQU8sQ0FBQ2UsR0FBRztJQUM3QjtJQUNBLElBQUlmLE9BQU8sQ0FBQ2dCLElBQUksS0FBSzJCLFNBQVMsRUFBRTtNQUM5QkQsU0FBUyxDQUFDMUIsSUFBSSxHQUFHaEIsT0FBTyxDQUFDZ0IsSUFBSTtJQUMvQjtJQUNBLElBQUloQixPQUFPLENBQUNpQixRQUFRLEtBQUswQixTQUFTLElBQUkzQyxPQUFPLENBQUNpQixRQUFRLEtBQUt1QixRQUFRLENBQUN2QixRQUFRLEVBQUU7TUFDNUV5QixTQUFTLENBQUN6QixRQUFRLEdBQUdqQixPQUFPLENBQUNpQixRQUFRO01BQ3JDd0IsVUFBVSxDQUFDVCxJQUFJLENBQ2JyRCxXQUFXLENBQUNhLGNBQWMsQ0FBQ1EsT0FBTyxDQUFDaUIsUUFBUSxHQUFHLFVBQVUsR0FBRyxZQUFZLEVBQUV2QixJQUFJLEVBQUU7UUFDN0VrRCxJQUFJLEVBQUVKLFFBQVEsQ0FBQ3ZCLFFBQVE7UUFDdkI0QixFQUFFLEVBQUU3QyxPQUFPLENBQUNpQjtNQUNkLENBQUMsQ0FDSCxDQUFDO0lBQ0g7SUFDQSxJQUFJakIsT0FBTyxDQUFDNEIsa0JBQWtCLEtBQUtlLFNBQVMsRUFBRTtNQUM1Q0QsU0FBUyxDQUFDZCxrQkFBa0IsR0FBRzVCLE9BQU8sQ0FBQzRCLGtCQUFrQjtJQUMzRDs7SUFFQTtJQUNBLElBQUlhLFVBQVUsQ0FBQ0ssTUFBTSxHQUFHLENBQUMsRUFBRTtNQUN6QkosU0FBUyxDQUFDZixZQUFZLEdBQUcsQ0FBQyxHQUFHYSxRQUFRLENBQUNiLFlBQVksRUFBRSxHQUFHYyxVQUFVLENBQUM7SUFDcEU7SUFFQSxNQUFNMUQscUNBQWlCLENBQUNnRSxjQUFjLENBQUNsRSxNQUFNLEVBQUV1QixxQkFBVSxFQUFFUixFQUFFLEVBQUU4QyxTQUFTLENBQUM7SUFDekUsT0FBTyxNQUFNL0QsV0FBVyxDQUFDd0QsT0FBTyxDQUFDdEQsTUFBTSxFQUFFZSxFQUFFLENBQUM7RUFDOUM7O0VBRUE7RUFDQSxhQUFhb0QsVUFBVUEsQ0FBQ25FLE1BQVcsRUFBRWUsRUFBVSxFQUFvQjtJQUNqRSxPQUFPLE1BQU1iLHFDQUFpQixDQUFDa0UsY0FBYyxDQUFDcEUsTUFBTSxFQUFFdUIscUJBQVUsRUFBRVIsRUFBRSxDQUFDO0VBQ3ZFOztFQUVBO0VBQ0EsYUFBYXNELFNBQVNBLENBQUNyRSxNQUFXLEVBQUVzRSxLQUFvQixFQUE2QjtJQUNuRixNQUFNQyxJQUFJLEdBQUdELEtBQUssQ0FBQ0MsSUFBSSxJQUFJLENBQUM7SUFDNUIsTUFBTUMsT0FBTyxHQUFHNUUsSUFBSSxDQUFDNkUsR0FBRyxDQUFDSCxLQUFLLENBQUNJLFFBQVEsSUFBSUMsNEJBQWlCLEVBQUVDLHdCQUFhLENBQUM7SUFDNUUsTUFBTUMsU0FBUyxHQUFHUCxLQUFLLENBQUNRLFVBQVUsSUFBSUMsNkJBQWtCO0lBQ3hELE1BQU1DLFNBQVMsR0FBR1YsS0FBSyxDQUFDVyxVQUFVLElBQUlDLDZCQUFrQjs7SUFFeEQ7SUFDQSxNQUFNQyxJQUFXLEdBQUcsRUFBRTtJQUV0QixJQUFJYixLQUFLLENBQUN4QyxNQUFNLEVBQUU7TUFDaEJxRCxJQUFJLENBQUNoQyxJQUFJLENBQUM7UUFBRWlDLElBQUksRUFBRTtVQUFFdEQsTUFBTSxFQUFFd0MsS0FBSyxDQUFDeEM7UUFBTztNQUFFLENBQUMsQ0FBQztJQUMvQztJQUNBLElBQUl3QyxLQUFLLENBQUN2QyxRQUFRLEVBQUU7TUFDbEJvRCxJQUFJLENBQUNoQyxJQUFJLENBQUM7UUFBRWlDLElBQUksRUFBRTtVQUFFckQsUUFBUSxFQUFFdUMsS0FBSyxDQUFDdkM7UUFBUztNQUFFLENBQUMsQ0FBQztJQUNuRDtJQUNBLElBQUl1QyxLQUFLLENBQUN0QyxRQUFRLEVBQUU7TUFDbEJtRCxJQUFJLENBQUNoQyxJQUFJLENBQUM7UUFBRWlDLElBQUksRUFBRTtVQUFFcEQsUUFBUSxFQUFFc0MsS0FBSyxDQUFDdEM7UUFBUztNQUFFLENBQUMsQ0FBQztJQUNuRDtJQUNBLElBQUlzQyxLQUFLLENBQUNyQyxRQUFRLEVBQUU7TUFDbEJrRCxJQUFJLENBQUNoQyxJQUFJLENBQUM7UUFBRWlDLElBQUksRUFBRTtVQUFFbkQsUUFBUSxFQUFFcUMsS0FBSyxDQUFDckM7UUFBUztNQUFFLENBQUMsQ0FBQztJQUNuRDtJQUNBLElBQUlxQyxLQUFLLENBQUNsQyxRQUFRLEVBQUU7TUFDbEIrQyxJQUFJLENBQUNoQyxJQUFJLENBQUM7UUFBRWlDLElBQUksRUFBRTtVQUFFaEQsUUFBUSxFQUFFa0MsS0FBSyxDQUFDbEM7UUFBUztNQUFFLENBQUMsQ0FBQztJQUNuRDtJQUNBLElBQUlrQyxLQUFLLENBQUNuQyxJQUFJLEVBQUU7TUFDZCxNQUFNa0QsT0FBTyxHQUFHZixLQUFLLENBQUNuQyxJQUFJLENBQUNtRCxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUNDLEdBQUcsQ0FBRUMsQ0FBQyxJQUFLQSxDQUFDLENBQUNDLElBQUksQ0FBQyxDQUFDLENBQUM7TUFDMUROLElBQUksQ0FBQ2hDLElBQUksQ0FBQztRQUFFdUMsS0FBSyxFQUFFO1VBQUV2RCxJQUFJLEVBQUVrRDtRQUFRO01BQUUsQ0FBQyxDQUFDO0lBQ3pDO0lBQ0EsSUFBSWYsS0FBSyxDQUFDcUIsTUFBTSxFQUFFO01BQ2hCUixJQUFJLENBQUNoQyxJQUFJLENBQUM7UUFDUnlDLFdBQVcsRUFBRTtVQUNYdEIsS0FBSyxFQUFFQSxLQUFLLENBQUNxQixNQUFNO1VBQ25CRSxNQUFNLEVBQUUsQ0FBQyxTQUFTLEVBQUUsYUFBYSxFQUFFLFdBQVcsRUFBRSxNQUFNLENBQUM7VUFDdkRDLElBQUksRUFBRSxhQUFhO1VBQ25CQyxTQUFTLEVBQUU7UUFDYjtNQUNGLENBQUMsQ0FBQztJQUNKO0lBQ0EsSUFBSXpCLEtBQUssQ0FBQzBCLFlBQVksSUFBSTFCLEtBQUssQ0FBQzJCLFVBQVUsRUFBRTtNQUMxQyxNQUFNQyxLQUFVLEdBQUcsQ0FBQyxDQUFDO01BQ3JCLElBQUk1QixLQUFLLENBQUMwQixZQUFZLEVBQUVFLEtBQUssQ0FBQ0MsR0FBRyxHQUFHN0IsS0FBSyxDQUFDMEIsWUFBWTtNQUN0RCxJQUFJMUIsS0FBSyxDQUFDMkIsVUFBVSxFQUFFQyxLQUFLLENBQUNFLEdBQUcsR0FBRzlCLEtBQUssQ0FBQzJCLFVBQVU7TUFDbERkLElBQUksQ0FBQ2hDLElBQUksQ0FBQztRQUFFK0MsS0FBSyxFQUFFO1VBQUU1RCxVQUFVLEVBQUU0RDtRQUFNO01BQUUsQ0FBQyxDQUFDO0lBQzdDO0lBRUEsTUFBTUcsVUFBVSxHQUFHO01BQ2pCL0IsS0FBSyxFQUFFYSxJQUFJLENBQUNsQixNQUFNLEdBQUcsQ0FBQyxHQUFHO1FBQUVxQyxJQUFJLEVBQUU7VUFBRW5CO1FBQUs7TUFBRSxDQUFDLEdBQUc7UUFBRW9CLFNBQVMsRUFBRSxDQUFDO01BQUUsQ0FBQztNQUMvREMsSUFBSSxFQUFFLENBQUM7UUFBRSxDQUFDM0IsU0FBUyxHQUFHO1VBQUU0QixLQUFLLEVBQUV6QjtRQUFVO01BQUUsQ0FBQyxDQUFDO01BQzdDakIsSUFBSSxFQUFFLENBQUNRLElBQUksR0FBRyxDQUFDLElBQUlDLE9BQU87TUFDMUJrQyxJQUFJLEVBQUVsQyxPQUFPO01BQ2I7TUFDQWYsT0FBTyxFQUFFO1FBQ1BrRCxRQUFRLEVBQUUsQ0FBQyxjQUFjLEVBQUUsa0JBQWtCO01BQy9DO0lBQ0YsQ0FBQztJQUVELE1BQU07TUFBRUMsSUFBSTtNQUFFQztJQUFNLENBQUMsR0FBRyxNQUFNM0cscUNBQWlCLENBQUM0RyxlQUFlLENBQUM5RyxNQUFNLEVBQUV1QixxQkFBVSxFQUFFOEUsVUFBVSxDQUFDO0lBRS9GLE1BQU1VLEtBQWEsR0FBR0gsSUFBSSxDQUFDckIsR0FBRyxDQUFFeUIsR0FBUSxLQUFNO01BQzVDakcsRUFBRSxFQUFFaUcsR0FBRyxDQUFDNUQsR0FBRztNQUNYLEdBQUc0RCxHQUFHLENBQUN2RDtJQUNULENBQUMsQ0FBQyxDQUFDO0lBRUgsT0FBTztNQUFFc0QsS0FBSztNQUFFRixLQUFLO01BQUV0QyxJQUFJO01BQUVHLFFBQVEsRUFBRUY7SUFBUSxDQUFDO0VBQ2xEOztFQUVBO0VBQ0E7RUFDQTs7RUFFQTtFQUNBLGFBQWF5QyxZQUFZQSxDQUN2QmpILE1BQVcsRUFDWGUsRUFBVSxFQUNWbUcsU0FBcUIsRUFDckJyRyxJQUFZLEVBQ2dEO0lBQzVELE1BQU04QyxRQUFRLEdBQUcsTUFBTTdELFdBQVcsQ0FBQ3dELE9BQU8sQ0FBQ3RELE1BQU0sRUFBRWUsRUFBRSxDQUFDO0lBQ3RELElBQUksQ0FBQzRDLFFBQVEsRUFBRTtNQUNiLE9BQU87UUFBRXdELE9BQU8sRUFBRSxLQUFLO1FBQUVDLEtBQUssRUFBRTtNQUFpQixDQUFDO0lBQ3BEOztJQUVBO0lBQ0EsTUFBTUMsa0JBQWtCLEdBQUdDLDZCQUFrQixDQUFDM0QsUUFBUSxDQUFDN0IsTUFBTSxDQUFDLElBQUksRUFBRTtJQUNwRSxJQUFJLENBQUN1RixrQkFBa0IsQ0FBQ0UsUUFBUSxDQUFDTCxTQUFTLENBQUMsRUFBRTtNQUMzQyxPQUFPO1FBQ0xDLE9BQU8sRUFBRSxLQUFLO1FBQ2RDLEtBQUssRUFBRywyQkFBMEJ6RCxRQUFRLENBQUM3QixNQUFPLFNBQVFvRixTQUFVLGVBQWNHLGtCQUFrQixDQUFDRyxJQUFJLENBQUMsSUFBSSxDQUFFO01BQ2xILENBQUM7SUFDSDtJQUVBLE1BQU05SCxHQUFHLEdBQUcsSUFBSUQsSUFBSSxDQUFDLENBQUMsQ0FBQ3dCLFdBQVcsQ0FBQyxDQUFDO0lBQ3BDLE1BQU00QyxTQUFjLEdBQUc7TUFDckIvQixNQUFNLEVBQUVvRixTQUFTO01BQ2pCM0UsVUFBVSxFQUFFN0M7SUFDZCxDQUFDOztJQUVEO0lBQ0EsSUFBSXdILFNBQVMsS0FBSyxRQUFRLElBQUlBLFNBQVMsS0FBSyxVQUFVLEVBQUU7TUFDdERyRCxTQUFTLENBQUNyQixTQUFTLEdBQUc5QyxHQUFHO01BQ3pCLElBQUlpRSxRQUFRLENBQUNyQixVQUFVLEVBQUU7UUFDdkJ1QixTQUFTLENBQUNiLGtCQUFrQixHQUFHLElBQUl2RCxJQUFJLENBQUNDLEdBQUcsQ0FBQyxDQUFDK0gsT0FBTyxDQUFDLENBQUMsR0FBRyxJQUFJaEksSUFBSSxDQUFDa0UsUUFBUSxDQUFDckIsVUFBVSxDQUFDLENBQUNtRixPQUFPLENBQUMsQ0FBQztNQUNsRztJQUNGOztJQUVBO0lBQ0EsSUFBSVAsU0FBUyxLQUFLLE1BQU0sS0FBS3ZELFFBQVEsQ0FBQzdCLE1BQU0sS0FBSyxRQUFRLElBQUk2QixRQUFRLENBQUM3QixNQUFNLEtBQUssVUFBVSxDQUFDLEVBQUU7TUFDNUYrQixTQUFTLENBQUNyQixTQUFTLEdBQUcsSUFBSTtNQUMxQnFCLFNBQVMsQ0FBQ2Isa0JBQWtCLEdBQUcsSUFBSTtJQUNyQzs7SUFFQTtJQUNBLE1BQU0wRSxRQUFRLEdBQUc1SCxXQUFXLENBQUNhLGNBQWMsQ0FDekN1RyxTQUFTLEtBQUssUUFBUSxHQUFHLGFBQWEsR0FBR0EsU0FBUyxLQUFLLE1BQU0sSUFBSXZELFFBQVEsQ0FBQzdCLE1BQU0sS0FBSyxRQUFRLEdBQUcsZUFBZSxHQUFHLGdCQUFnQixFQUNsSWpCLElBQUksRUFDSjtNQUFFa0QsSUFBSSxFQUFFSixRQUFRLENBQUM3QixNQUFNO01BQUVrQyxFQUFFLEVBQUVrRDtJQUFVLENBQ3pDLENBQUM7SUFDRHJELFNBQVMsQ0FBQ2YsWUFBWSxHQUFHLENBQUMsR0FBR2EsUUFBUSxDQUFDYixZQUFZLEVBQUU0RSxRQUFRLENBQUM7SUFFN0QsTUFBTXhILHFDQUFpQixDQUFDZ0UsY0FBYyxDQUFDbEUsTUFBTSxFQUFFdUIscUJBQVUsRUFBRVIsRUFBRSxFQUFFOEMsU0FBUyxDQUFDO0lBQ3pFLE1BQU04RCxXQUFXLEdBQUcsTUFBTTdILFdBQVcsQ0FBQ3dELE9BQU8sQ0FBQ3RELE1BQU0sRUFBRWUsRUFBRSxDQUFDO0lBQ3pELE9BQU87TUFBRW9HLE9BQU8sRUFBRSxJQUFJO01BQUVTLElBQUksRUFBRUQ7SUFBYSxDQUFDO0VBQzlDOztFQUVBO0VBQ0EsYUFBYUUsVUFBVUEsQ0FDckI3SCxNQUFXLEVBQ1hlLEVBQVUsRUFDVnFCLFFBQXVCLEVBQ3ZCdkIsSUFBWSxFQUNVO0lBQ3RCLE1BQU04QyxRQUFRLEdBQUcsTUFBTTdELFdBQVcsQ0FBQ3dELE9BQU8sQ0FBQ3RELE1BQU0sRUFBRWUsRUFBRSxDQUFDO0lBQ3RELElBQUksQ0FBQzRDLFFBQVEsRUFBRSxPQUFPLElBQUk7SUFFMUIsTUFBTStELFFBQVEsR0FBRzVILFdBQVcsQ0FBQ2EsY0FBYyxDQUN6Q3lCLFFBQVEsR0FBRyxVQUFVLEdBQUcsWUFBWSxFQUNwQ3ZCLElBQUksRUFDSjtNQUFFa0QsSUFBSSxFQUFFSixRQUFRLENBQUN2QixRQUFRO01BQUU0QixFQUFFLEVBQUU1QjtJQUFTLENBQzFDLENBQUM7SUFFRCxNQUFNbEMscUNBQWlCLENBQUNnRSxjQUFjLENBQUNsRSxNQUFNLEVBQUV1QixxQkFBVSxFQUFFUixFQUFFLEVBQUU7TUFDN0RxQixRQUFRO01BQ1JHLFVBQVUsRUFBRSxJQUFJOUMsSUFBSSxDQUFDLENBQUMsQ0FBQ3dCLFdBQVcsQ0FBQyxDQUFDO01BQ3BDNkIsWUFBWSxFQUFFLENBQUMsR0FBR2EsUUFBUSxDQUFDYixZQUFZLEVBQUU0RSxRQUFRO0lBQ25ELENBQUMsQ0FBQztJQUVGLE9BQU8sTUFBTTVILFdBQVcsQ0FBQ3dELE9BQU8sQ0FBQ3RELE1BQU0sRUFBRWUsRUFBRSxDQUFDO0VBQzlDOztFQUVBO0VBQ0E7RUFDQTs7RUFFQTtFQUNBLGFBQWErRyxPQUFPQSxDQUFDOUgsTUFBVyxFQUFFeUIsTUFBYyxFQUFFRyxLQUFhLEVBQUVmLElBQVksRUFBd0I7SUFDbkcsTUFBTThDLFFBQVEsR0FBRyxNQUFNN0QsV0FBVyxDQUFDd0QsT0FBTyxDQUFDdEQsTUFBTSxFQUFFeUIsTUFBTSxDQUFDO0lBQzFELElBQUksQ0FBQ2tDLFFBQVEsRUFBRSxPQUFPLElBQUk7SUFFMUIsTUFBTW9FLE9BQU8sR0FBRztNQUNkQyxPQUFPLEVBQUU1SSxJQUFJLENBQUMsQ0FBQztNQUNmd0MsS0FBSztNQUNMcUcsU0FBUyxFQUFFLEtBQUs7TUFDaEIzRixVQUFVLEVBQUUsSUFBSTdDLElBQUksQ0FBQyxDQUFDLENBQUN3QixXQUFXLENBQUM7SUFDckMsQ0FBQztJQUVELE1BQU00QyxTQUFTLEdBQUc7TUFDaEJqQixLQUFLLEVBQUUsQ0FBQyxJQUFJZSxRQUFRLENBQUNmLEtBQUssSUFBSSxFQUFFLENBQUMsRUFBRW1GLE9BQU8sQ0FBQztNQUMzQ3hGLFVBQVUsRUFBRSxJQUFJOUMsSUFBSSxDQUFDLENBQUMsQ0FBQ3dCLFdBQVcsQ0FBQztJQUNyQyxDQUFDO0lBRUQsTUFBTWYscUNBQWlCLENBQUNnRSxjQUFjLENBQUNsRSxNQUFNLEVBQUV1QixxQkFBVSxFQUFFRSxNQUFNLEVBQUVvQyxTQUFTLENBQUM7SUFDN0UsT0FBTyxNQUFNL0QsV0FBVyxDQUFDd0QsT0FBTyxDQUFDdEQsTUFBTSxFQUFFeUIsTUFBTSxDQUFDO0VBQ2xEOztFQUVBO0VBQ0EsYUFBYXlHLFVBQVVBLENBQUNsSSxNQUFXLEVBQUV5QixNQUFjLEVBQUUwRyxNQUFjLEVBQUVGLFNBQWtCLEVBQUVwSCxJQUFZLEVBQXdCO0lBQzNILE1BQU04QyxRQUFRLEdBQUcsTUFBTTdELFdBQVcsQ0FBQ3dELE9BQU8sQ0FBQ3RELE1BQU0sRUFBRXlCLE1BQU0sQ0FBQztJQUMxRCxJQUFJLENBQUNrQyxRQUFRLEVBQUUsT0FBTyxJQUFJO0lBRTFCLE1BQU1mLEtBQUssR0FBRyxDQUFDZSxRQUFRLENBQUNmLEtBQUssSUFBSSxFQUFFLEVBQUUyQyxHQUFHLENBQUVDLENBQU0sSUFDOUNBLENBQUMsQ0FBQ3dDLE9BQU8sS0FBS0csTUFBTSxHQUFHO01BQUUsR0FBRzNDLENBQUM7TUFBRXlDLFNBQVM7TUFBRUcsWUFBWSxFQUFFSCxTQUFTLEdBQUcsSUFBSXhJLElBQUksQ0FBQyxDQUFDLENBQUN3QixXQUFXLENBQUMsQ0FBQyxHQUFHNkM7SUFBVSxDQUFDLEdBQUcwQixDQUMvRyxDQUFDO0lBRUQsTUFBTTNCLFNBQVMsR0FBRztNQUNoQmpCLEtBQUs7TUFDTEwsVUFBVSxFQUFFLElBQUk5QyxJQUFJLENBQUMsQ0FBQyxDQUFDd0IsV0FBVyxDQUFDO0lBQ3JDLENBQUM7SUFFRCxNQUFNZixxQ0FBaUIsQ0FBQ2dFLGNBQWMsQ0FBQ2xFLE1BQU0sRUFBRXVCLHFCQUFVLEVBQUVFLE1BQU0sRUFBRW9DLFNBQVMsQ0FBQztJQUM3RSxPQUFPLE1BQU0vRCxXQUFXLENBQUN3RCxPQUFPLENBQUN0RCxNQUFNLEVBQUV5QixNQUFNLENBQUM7RUFDbEQ7O0VBRUE7RUFDQSxhQUFhNEcsVUFBVUEsQ0FBQ3JJLE1BQVcsRUFBRXlCLE1BQWMsRUFBRTBHLE1BQWMsRUFBRXRILElBQVksRUFBd0I7SUFDdkcsTUFBTThDLFFBQVEsR0FBRyxNQUFNN0QsV0FBVyxDQUFDd0QsT0FBTyxDQUFDdEQsTUFBTSxFQUFFeUIsTUFBTSxDQUFDO0lBQzFELElBQUksQ0FBQ2tDLFFBQVEsRUFBRSxPQUFPLElBQUk7SUFFMUIsTUFBTWYsS0FBSyxHQUFHLENBQUNlLFFBQVEsQ0FBQ2YsS0FBSyxJQUFJLEVBQUUsRUFBRTBGLE1BQU0sQ0FBRTlDLENBQU0sSUFBS0EsQ0FBQyxDQUFDd0MsT0FBTyxLQUFLRyxNQUFNLENBQUM7SUFFN0UsTUFBTXRFLFNBQVMsR0FBRztNQUNoQmpCLEtBQUs7TUFDTEwsVUFBVSxFQUFFLElBQUk5QyxJQUFJLENBQUMsQ0FBQyxDQUFDd0IsV0FBVyxDQUFDO0lBQ3JDLENBQUM7SUFFRCxNQUFNZixxQ0FBaUIsQ0FBQ2dFLGNBQWMsQ0FBQ2xFLE1BQU0sRUFBRXVCLHFCQUFVLEVBQUVFLE1BQU0sRUFBRW9DLFNBQVMsQ0FBQztJQUM3RSxPQUFPLE1BQU0vRCxXQUFXLENBQUN3RCxPQUFPLENBQUN0RCxNQUFNLEVBQUV5QixNQUFNLENBQUM7RUFDbEQ7O0VBRUE7RUFDQTtFQUNBOztFQUVBO0VBQ0EsYUFBYThHLFdBQVdBLENBQUN2SSxNQUFXLEVBQUV5QixNQUFjLEVBQUVvQixLQUFhLEVBQUVoQyxJQUFZLEVBQXdCO0lBQ3ZHLE1BQU04QyxRQUFRLEdBQUcsTUFBTTdELFdBQVcsQ0FBQ3dELE9BQU8sQ0FBQ3RELE1BQU0sRUFBRXlCLE1BQU0sQ0FBQztJQUMxRCxJQUFJLENBQUNrQyxRQUFRLEVBQUUsT0FBTyxJQUFJO0lBRTFCLE1BQU1FLFNBQVMsR0FBRztNQUNoQmhCLEtBQUs7TUFDTE4sVUFBVSxFQUFFLElBQUk5QyxJQUFJLENBQUMsQ0FBQyxDQUFDd0IsV0FBVyxDQUFDO0lBQ3JDLENBQUM7SUFFRCxNQUFNZixxQ0FBaUIsQ0FBQ2dFLGNBQWMsQ0FBQ2xFLE1BQU0sRUFBRXVCLHFCQUFVLEVBQUVFLE1BQU0sRUFBRW9DLFNBQVMsQ0FBQztJQUM3RSxPQUFPLE1BQU0vRCxXQUFXLENBQUN3RCxPQUFPLENBQUN0RCxNQUFNLEVBQUV5QixNQUFNLENBQUM7RUFDbEQ7O0VBRUE7RUFDQTtFQUNBOztFQUVBO0VBQ0EsYUFBYStHLFVBQVVBLENBQ3JCeEksTUFBVyxFQUNYeUIsTUFBYyxFQUNkZ0gsT0FBZSxFQUNmNUgsSUFBWSxFQUNVO0lBQ3RCLE1BQU04QyxRQUFRLEdBQUcsTUFBTTdELFdBQVcsQ0FBQ3dELE9BQU8sQ0FBQ3RELE1BQU0sRUFBRXlCLE1BQU0sQ0FBQztJQUMxRCxJQUFJLENBQUNrQyxRQUFRLEVBQUUsT0FBTyxJQUFJO0lBRTFCLE1BQU0rRSxPQUFvQixHQUFHO01BQzNCQyxVQUFVLEVBQUV2SixJQUFJLENBQUMsQ0FBQztNQUNsQndKLE1BQU0sRUFBRS9ILElBQUk7TUFDWjRILE9BQU87TUFDUG5HLFVBQVUsRUFBRSxJQUFJN0MsSUFBSSxDQUFDLENBQUMsQ0FBQ3dCLFdBQVcsQ0FBQztJQUNyQyxDQUFDO0lBRUQsTUFBTXlHLFFBQVEsR0FBRzVILFdBQVcsQ0FBQ2EsY0FBYyxDQUFDLGVBQWUsRUFBRUUsSUFBSSxFQUFFO01BQ2pFOEgsVUFBVSxFQUFFRCxPQUFPLENBQUNDO0lBQ3RCLENBQUMsQ0FBQztJQUVGLE1BQU16SSxxQ0FBaUIsQ0FBQ2dFLGNBQWMsQ0FBQ2xFLE1BQU0sRUFBRXVCLHFCQUFVLEVBQUVFLE1BQU0sRUFBRTtNQUNqRWtCLFFBQVEsRUFBRSxDQUFDLEdBQUdnQixRQUFRLENBQUNoQixRQUFRLEVBQUUrRixPQUFPLENBQUM7TUFDekM1RixZQUFZLEVBQUUsQ0FBQyxHQUFHYSxRQUFRLENBQUNiLFlBQVksRUFBRTRFLFFBQVEsQ0FBQztNQUNsRG5GLFVBQVUsRUFBRSxJQUFJOUMsSUFBSSxDQUFDLENBQUMsQ0FBQ3dCLFdBQVcsQ0FBQztJQUNyQyxDQUFDLENBQUM7SUFFRixPQUFPLE1BQU1uQixXQUFXLENBQUN3RCxPQUFPLENBQUN0RCxNQUFNLEVBQUV5QixNQUFNLENBQUM7RUFDbEQ7O0VBRUE7RUFDQSxhQUFhb0gsYUFBYUEsQ0FDeEI3SSxNQUFXLEVBQ1h5QixNQUFjLEVBQ2RxSCxTQUFpQixFQUNqQmpJLElBQVksRUFDVTtJQUN0QixNQUFNOEMsUUFBUSxHQUFHLE1BQU03RCxXQUFXLENBQUN3RCxPQUFPLENBQUN0RCxNQUFNLEVBQUV5QixNQUFNLENBQUM7SUFDMUQsSUFBSSxDQUFDa0MsUUFBUSxFQUFFLE9BQU8sSUFBSTtJQUUxQixNQUFNb0YsZUFBZSxHQUFHcEYsUUFBUSxDQUFDaEIsUUFBUSxDQUFDMkYsTUFBTSxDQUFFVSxDQUFDLElBQUtBLENBQUMsQ0FBQ0wsVUFBVSxLQUFLRyxTQUFTLENBQUM7SUFDbkYsSUFBSUMsZUFBZSxDQUFDOUUsTUFBTSxLQUFLTixRQUFRLENBQUNoQixRQUFRLENBQUNzQixNQUFNLEVBQUU7TUFDdkQsT0FBT04sUUFBUSxDQUFDLENBQUM7SUFDbkI7O0lBRUEsTUFBTStELFFBQVEsR0FBRzVILFdBQVcsQ0FBQ2EsY0FBYyxDQUFDLGlCQUFpQixFQUFFRSxJQUFJLEVBQUU7TUFDbkU4SCxVQUFVLEVBQUVHO0lBQ2QsQ0FBQyxDQUFDO0lBRUYsTUFBTTVJLHFDQUFpQixDQUFDZ0UsY0FBYyxDQUFDbEUsTUFBTSxFQUFFdUIscUJBQVUsRUFBRUUsTUFBTSxFQUFFO01BQ2pFa0IsUUFBUSxFQUFFb0csZUFBZTtNQUN6QmpHLFlBQVksRUFBRSxDQUFDLEdBQUdhLFFBQVEsQ0FBQ2IsWUFBWSxFQUFFNEUsUUFBUSxDQUFDO01BQ2xEbkYsVUFBVSxFQUFFLElBQUk5QyxJQUFJLENBQUMsQ0FBQyxDQUFDd0IsV0FBVyxDQUFDO0lBQ3JDLENBQUMsQ0FBQztJQUVGLE9BQU8sTUFBTW5CLFdBQVcsQ0FBQ3dELE9BQU8sQ0FBQ3RELE1BQU0sRUFBRXlCLE1BQU0sQ0FBQztFQUNsRDs7RUFFQTtFQUNBO0VBQ0E7O0VBRUE7RUFDQSxhQUFhd0gsU0FBU0EsQ0FDcEJqSixNQUFXLEVBQ1h5QixNQUFjLEVBQ2R5SCxLQUFrQixFQUNsQnJJLElBQVksRUFDVTtJQUN0QixNQUFNOEMsUUFBUSxHQUFHLE1BQU03RCxXQUFXLENBQUN3RCxPQUFPLENBQUN0RCxNQUFNLEVBQUV5QixNQUFNLENBQUM7SUFDMUQsSUFBSSxDQUFDa0MsUUFBUSxFQUFFLE9BQU8sSUFBSTs7SUFFMUI7SUFDQSxJQUFJQSxRQUFRLENBQUNsQixhQUFhLENBQUMwRyxJQUFJLENBQUVDLENBQUMsSUFBS0EsQ0FBQyxDQUFDQyxRQUFRLEtBQUtILEtBQUssQ0FBQ0csUUFBUSxDQUFDLEVBQUU7TUFDckUsT0FBTzFGLFFBQVEsQ0FBQyxDQUFDO0lBQ25COztJQUVBLE1BQU0rRCxRQUFRLEdBQUc1SCxXQUFXLENBQUNhLGNBQWMsQ0FBQyxjQUFjLEVBQUVFLElBQUksRUFBRTtNQUNoRXdJLFFBQVEsRUFBRUgsS0FBSyxDQUFDRyxRQUFRO01BQ3hCQyxnQkFBZ0IsRUFBRUosS0FBSyxDQUFDSTtJQUMxQixDQUFDLENBQUM7SUFFRixNQUFNcEoscUNBQWlCLENBQUNnRSxjQUFjLENBQUNsRSxNQUFNLEVBQUV1QixxQkFBVSxFQUFFRSxNQUFNLEVBQUU7TUFDakVnQixhQUFhLEVBQUUsQ0FBQyxHQUFHa0IsUUFBUSxDQUFDbEIsYUFBYSxFQUFFeUcsS0FBSyxDQUFDO01BQ2pEcEcsWUFBWSxFQUFFLENBQUMsR0FBR2EsUUFBUSxDQUFDYixZQUFZLEVBQUU0RSxRQUFRLENBQUM7TUFDbERuRixVQUFVLEVBQUUsSUFBSTlDLElBQUksQ0FBQyxDQUFDLENBQUN3QixXQUFXLENBQUM7SUFDckMsQ0FBQyxDQUFDO0lBRUYsT0FBTyxNQUFNbkIsV0FBVyxDQUFDd0QsT0FBTyxDQUFDdEQsTUFBTSxFQUFFeUIsTUFBTSxDQUFDO0VBQ2xEOztFQUVBO0VBQ0EsYUFBYThILFdBQVdBLENBQ3RCdkosTUFBVyxFQUNYeUIsTUFBYyxFQUNkK0gsT0FBZSxFQUNmM0ksSUFBWSxFQUNVO0lBQ3RCLE1BQU04QyxRQUFRLEdBQUcsTUFBTTdELFdBQVcsQ0FBQ3dELE9BQU8sQ0FBQ3RELE1BQU0sRUFBRXlCLE1BQU0sQ0FBQztJQUMxRCxJQUFJLENBQUNrQyxRQUFRLEVBQUUsT0FBTyxJQUFJO0lBRTFCLE1BQU04RixhQUFhLEdBQUc5RixRQUFRLENBQUNsQixhQUFhLENBQUM2RixNQUFNLENBQUVjLENBQUMsSUFBS0EsQ0FBQyxDQUFDQyxRQUFRLEtBQUtHLE9BQU8sQ0FBQztJQUNsRixNQUFNOUIsUUFBUSxHQUFHNUgsV0FBVyxDQUFDYSxjQUFjLENBQUMsZ0JBQWdCLEVBQUVFLElBQUksRUFBRTtNQUFFd0ksUUFBUSxFQUFFRztJQUFRLENBQUMsQ0FBQztJQUUxRixNQUFNdEoscUNBQWlCLENBQUNnRSxjQUFjLENBQUNsRSxNQUFNLEVBQUV1QixxQkFBVSxFQUFFRSxNQUFNLEVBQUU7TUFDakVnQixhQUFhLEVBQUVnSCxhQUFhO01BQzVCM0csWUFBWSxFQUFFLENBQUMsR0FBR2EsUUFBUSxDQUFDYixZQUFZLEVBQUU0RSxRQUFRLENBQUM7TUFDbERuRixVQUFVLEVBQUUsSUFBSTlDLElBQUksQ0FBQyxDQUFDLENBQUN3QixXQUFXLENBQUM7SUFDckMsQ0FBQyxDQUFDO0lBRUYsT0FBTyxNQUFNbkIsV0FBVyxDQUFDd0QsT0FBTyxDQUFDdEQsTUFBTSxFQUFFeUIsTUFBTSxDQUFDO0VBQ2xEOztFQUVBO0VBQ0EsYUFBYWlJLFlBQVlBLENBQ3ZCMUosTUFBVyxFQUNYc0UsS0FBNEIsRUFDYTtJQUN6QyxNQUFNYSxJQUFXLEdBQUcsRUFBRTtJQUV0QixJQUFJYixLQUFLLENBQUNxQixNQUFNLEVBQUU7TUFDaEJSLElBQUksQ0FBQ2hDLElBQUksQ0FBQztRQUNSeUMsV0FBVyxFQUFFO1VBQ1h0QixLQUFLLEVBQUVBLEtBQUssQ0FBQ3FCLE1BQU07VUFDbkJFLE1BQU0sRUFBRSxDQUFDLG9CQUFvQixFQUFFLFVBQVUsRUFBRSxRQUFRLENBQUM7VUFDcERFLFNBQVMsRUFBRSxNQUFNO1VBQ2pCO1VBQ0E7VUFDQTRELE9BQU8sRUFBRTtRQUNYO01BQ0YsQ0FBQyxDQUFDO0lBQ0o7SUFDQSxJQUFJckYsS0FBSyxDQUFDc0YsUUFBUSxFQUFFO01BQ2xCekUsSUFBSSxDQUFDaEMsSUFBSSxDQUFDO1FBQUVpQyxJQUFJLEVBQUU7VUFBRSxVQUFVLEVBQUVkLEtBQUssQ0FBQ3NGO1FBQVM7TUFBRSxDQUFDLENBQUM7SUFDckQ7SUFDQSxJQUFJdEYsS0FBSyxDQUFDdUYsT0FBTyxFQUFFO01BQ2pCMUUsSUFBSSxDQUFDaEMsSUFBSSxDQUFDO1FBQUVpQyxJQUFJLEVBQUU7VUFBRSxTQUFTLEVBQUU3RSxNQUFNLENBQUMrRCxLQUFLLENBQUN1RixPQUFPO1FBQUU7TUFBRSxDQUFDLENBQUM7SUFDM0Q7SUFDQSxJQUFJdkYsS0FBSyxDQUFDd0YsU0FBUyxJQUFJeEYsS0FBSyxDQUFDeUYsU0FBUyxFQUFFO01BQ3RDLE1BQU03RCxLQUFVLEdBQUcsQ0FBQyxDQUFDO01BQ3JCLElBQUk1QixLQUFLLENBQUN3RixTQUFTLEVBQUU1RCxLQUFLLENBQUNDLEdBQUcsR0FBRzdCLEtBQUssQ0FBQ3dGLFNBQVM7TUFDaEQsSUFBSXhGLEtBQUssQ0FBQ3lGLFNBQVMsRUFBRTdELEtBQUssQ0FBQ0UsR0FBRyxHQUFHOUIsS0FBSyxDQUFDeUYsU0FBUztNQUNoRDVFLElBQUksQ0FBQ2hDLElBQUksQ0FBQztRQUFFK0MsS0FBSyxFQUFFO1VBQUUsWUFBWSxFQUFFQTtRQUFNO01BQUUsQ0FBQyxDQUFDO0lBQy9DO0lBQ0EsSUFBSTVCLEtBQUssQ0FBQ1AsSUFBSSxJQUFJTyxLQUFLLENBQUNOLEVBQUUsRUFBRTtNQUMxQixNQUFNa0MsS0FBVSxHQUFHLENBQUMsQ0FBQztNQUNyQixJQUFJNUIsS0FBSyxDQUFDUCxJQUFJLEVBQUVtQyxLQUFLLENBQUNDLEdBQUcsR0FBRzdCLEtBQUssQ0FBQ1AsSUFBSTtNQUN0QyxJQUFJTyxLQUFLLENBQUNOLEVBQUUsRUFBRWtDLEtBQUssQ0FBQ0UsR0FBRyxHQUFHOUIsS0FBSyxDQUFDTixFQUFFO01BQ2xDbUIsSUFBSSxDQUFDaEMsSUFBSSxDQUFDO1FBQUUrQyxLQUFLLEVBQUU7VUFBRWxGLFNBQVMsRUFBRWtGO1FBQU07TUFBRSxDQUFDLENBQUM7SUFDNUM7SUFFQSxNQUFNRyxVQUFVLEdBQUc7TUFDakIvQixLQUFLLEVBQUVhLElBQUksQ0FBQ2xCLE1BQU0sR0FBRyxDQUFDLEdBQUc7UUFBRXFDLElBQUksRUFBRTtVQUFFbkI7UUFBSztNQUFFLENBQUMsR0FBRztRQUFFb0IsU0FBUyxFQUFFLENBQUM7TUFBRSxDQUFDO01BQy9EQyxJQUFJLEVBQUUsQ0FBQztRQUFFeEYsU0FBUyxFQUFFO1VBQUV5RixLQUFLLEVBQUU7UUFBTztNQUFFLENBQUMsQ0FBQztNQUN4Q0MsSUFBSSxFQUFFOUcsSUFBSSxDQUFDNkUsR0FBRyxDQUFDSCxLQUFLLENBQUNvQyxJQUFJLElBQUksRUFBRSxFQUFFLEdBQUc7SUFDdEMsQ0FBQztJQUVELE9BQU8sTUFBTXhHLHFDQUFpQixDQUFDNEcsZUFBZSxDQUFDOUcsTUFBTSxFQUFFZ0sscUNBQTBCLEVBQUUzRCxVQUFVLENBQUM7RUFDaEc7O0VBRUE7RUFDQTtFQUNBOztFQUVBO0VBQ0EsYUFBYTRELGFBQWFBLENBQ3hCakssTUFBVyxFQUNYeUIsTUFBYyxFQUNkeUksVUFBNEQsRUFDNURySixJQUFZLEVBQ1U7SUFDdEIsTUFBTThDLFFBQVEsR0FBRyxNQUFNN0QsV0FBVyxDQUFDd0QsT0FBTyxDQUFDdEQsTUFBTSxFQUFFeUIsTUFBTSxDQUFDO0lBQzFELElBQUksQ0FBQ2tDLFFBQVEsRUFBRSxPQUFPLElBQUk7SUFFMUIsTUFBTXdHLGFBQXlCLEdBQUc7TUFDaEMsR0FBR0QsVUFBVTtNQUNibkosRUFBRSxFQUFFM0IsSUFBSSxDQUFDLENBQUM7TUFDVmdMLFFBQVEsRUFBRSxJQUFJM0ssSUFBSSxDQUFDLENBQUMsQ0FBQ3dCLFdBQVcsQ0FBQyxDQUFDO01BQ2xDb0osUUFBUSxFQUFFeEo7SUFDWixDQUFDO0lBRUQsTUFBTTZHLFFBQVEsR0FBRzVILFdBQVcsQ0FBQ2EsY0FBYyxDQUFDLGtCQUFrQixFQUFFRSxJQUFJLEVBQUU7TUFDcEVpRixJQUFJLEVBQUVvRSxVQUFVLENBQUNwRSxJQUFJO01BQ3JCd0UsS0FBSyxFQUFFSixVQUFVLENBQUNJO0lBQ3BCLENBQUMsQ0FBQztJQUVGLE1BQU1wSyxxQ0FBaUIsQ0FBQ2dFLGNBQWMsQ0FBQ2xFLE1BQU0sRUFBRXVCLHFCQUFVLEVBQUVFLE1BQU0sRUFBRTtNQUNqRWlCLFdBQVcsRUFBRSxDQUFDLEdBQUdpQixRQUFRLENBQUNqQixXQUFXLEVBQUV5SCxhQUFhLENBQUM7TUFDckRySCxZQUFZLEVBQUUsQ0FBQyxHQUFHYSxRQUFRLENBQUNiLFlBQVksRUFBRTRFLFFBQVEsQ0FBQztNQUNsRG5GLFVBQVUsRUFBRSxJQUFJOUMsSUFBSSxDQUFDLENBQUMsQ0FBQ3dCLFdBQVcsQ0FBQztJQUNyQyxDQUFDLENBQUM7SUFFRixPQUFPLE1BQU1uQixXQUFXLENBQUN3RCxPQUFPLENBQUN0RCxNQUFNLEVBQUV5QixNQUFNLENBQUM7RUFDbEQ7O0VBRUE7RUFDQSxhQUFhOEksZ0JBQWdCQSxDQUMzQnZLLE1BQVcsRUFDWHlCLE1BQWMsRUFDZCtJLFlBQW9CLEVBQ3BCM0osSUFBWSxFQUNVO0lBQ3RCLE1BQU04QyxRQUFRLEdBQUcsTUFBTTdELFdBQVcsQ0FBQ3dELE9BQU8sQ0FBQ3RELE1BQU0sRUFBRXlCLE1BQU0sQ0FBQztJQUMxRCxJQUFJLENBQUNrQyxRQUFRLEVBQUUsT0FBTyxJQUFJO0lBRTFCLE1BQU04RyxPQUFPLEdBQUc5RyxRQUFRLENBQUNqQixXQUFXLENBQUM0RixNQUFNLENBQUVvQyxDQUFDLElBQUtBLENBQUMsQ0FBQzNKLEVBQUUsS0FBS3lKLFlBQVksQ0FBQztJQUN6RSxNQUFNOUMsUUFBUSxHQUFHNUgsV0FBVyxDQUFDYSxjQUFjLENBQUMsb0JBQW9CLEVBQUVFLElBQUksRUFBRTtNQUN0RThKLGFBQWEsRUFBRUg7SUFDakIsQ0FBQyxDQUFDO0lBRUYsTUFBTXRLLHFDQUFpQixDQUFDZ0UsY0FBYyxDQUFDbEUsTUFBTSxFQUFFdUIscUJBQVUsRUFBRUUsTUFBTSxFQUFFO01BQ2pFaUIsV0FBVyxFQUFFK0gsT0FBTztNQUNwQjNILFlBQVksRUFBRSxDQUFDLEdBQUdhLFFBQVEsQ0FBQ2IsWUFBWSxFQUFFNEUsUUFBUSxDQUFDO01BQ2xEbkYsVUFBVSxFQUFFLElBQUk5QyxJQUFJLENBQUMsQ0FBQyxDQUFDd0IsV0FBVyxDQUFDO0lBQ3JDLENBQUMsQ0FBQztJQUVGLE9BQU8sTUFBTW5CLFdBQVcsQ0FBQ3dELE9BQU8sQ0FBQ3RELE1BQU0sRUFBRXlCLE1BQU0sQ0FBQztFQUNsRDs7RUFFQTtFQUNBO0VBQ0E7O0VBRUE7RUFDQSxhQUFhbUosbUJBQW1CQSxDQUFDNUssTUFBVyxFQUE2QjtJQUN2RSxJQUFJO01BQ0Y7TUFDQTtNQUNBLE1BQU1FLHFDQUFpQixDQUFDa0IsV0FBVyxDQUFDcEIsTUFBTSxFQUFFdUIscUJBQVUsRUFBRUMsMkJBQVksQ0FBQztNQUNyRSxPQUFPLE1BQU0xQixXQUFXLENBQUMrSyx1QkFBdUIsQ0FBQzdLLE1BQU0sQ0FBQztJQUMxRCxDQUFDLENBQUMsT0FBTzhLLENBQUMsRUFBRTtNQUNWO01BQ0E7TUFDQSxPQUFPdk0scUJBQXFCLENBQUMsQ0FBQztJQUNoQztFQUNGO0VBRUEsYUFBcUJzTSx1QkFBdUJBLENBQUM3SyxNQUFXLEVBQTZCO0lBQUEsSUFBQStLLGVBQUEsRUFBQUMsaUJBQUEsRUFBQUMsaUJBQUEsRUFBQUMsaUJBQUEsRUFBQUMsV0FBQSxFQUFBQyxxQkFBQSxFQUFBQyxtQkFBQSxFQUFBQyxrQkFBQTtJQUNuRixNQUFNQyxLQUFLLEdBQUcsSUFBSTlMLElBQUksQ0FBQyxDQUFDO0lBQ3hCOEwsS0FBSyxDQUFDQyxRQUFRLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDO0lBQzFCLE1BQU1DLFFBQVEsR0FBR0YsS0FBSyxDQUFDdEssV0FBVyxDQUFDLENBQUM7SUFFcEMsTUFBTXlLLElBQUksR0FBRyxNQUFNeEwscUNBQWlCLENBQUN5TCxrQkFBa0IsQ0FBQzNMLE1BQU0sRUFBRXVCLHFCQUFVLEVBQUU7TUFDMUVtSyxJQUFJLEVBQUU7UUFDSkUsU0FBUyxFQUFFO1VBQUVsRyxLQUFLLEVBQUU7WUFBRW1HLEtBQUssRUFBRSxRQUFRO1lBQUVuRixJQUFJLEVBQUU7VUFBRztRQUFFLENBQUM7UUFDbkQ1SCxXQUFXLEVBQUU7VUFBRTRHLEtBQUssRUFBRTtZQUFFbUcsS0FBSyxFQUFFLFVBQVU7WUFBRW5GLElBQUksRUFBRTtVQUFHO1FBQUUsQ0FBQztRQUN2RDNILFdBQVcsRUFBRTtVQUFFMkcsS0FBSyxFQUFFO1lBQUVtRyxLQUFLLEVBQUUsVUFBVTtZQUFFbkYsSUFBSSxFQUFFO1VBQUc7UUFBRSxDQUFDO1FBQ3ZEMUgsV0FBVyxFQUFFO1VBQUUwRyxLQUFLLEVBQUU7WUFBRW1HLEtBQUssRUFBRSxVQUFVO1lBQUVuRixJQUFJLEVBQUU7VUFBRztRQUFFLENBQUM7UUFDdkRvRixtQkFBbUIsRUFBRTtVQUFFQyxHQUFHLEVBQUU7WUFBRUYsS0FBSyxFQUFFO1VBQXFCO1FBQUUsQ0FBQztRQUM3REcsYUFBYSxFQUFFO1VBQ2IxRCxNQUFNLEVBQUU7WUFBRXBDLEtBQUssRUFBRTtjQUFFNUQsVUFBVSxFQUFFO2dCQUFFNkQsR0FBRyxFQUFFc0Y7Y0FBUztZQUFFO1VBQUU7UUFDckQsQ0FBQztRQUNEUSxZQUFZLEVBQUU7VUFDWjNELE1BQU0sRUFBRTtZQUNOaEMsSUFBSSxFQUFFO2NBQ0puQixJQUFJLEVBQUUsQ0FDSjtnQkFBRWUsS0FBSyxFQUFFO2tCQUFFMUQsU0FBUyxFQUFFO29CQUFFMkQsR0FBRyxFQUFFc0Y7a0JBQVM7Z0JBQUU7Y0FBRSxDQUFDLEVBQzNDO2dCQUFFL0YsS0FBSyxFQUFFO2tCQUFFNUQsTUFBTSxFQUFFLENBQUMsVUFBVSxFQUFFLFFBQVE7Z0JBQUU7Y0FBRSxDQUFDO1lBRWpEO1VBQ0Y7UUFDRixDQUFDO1FBQ0QrRSxLQUFLLEVBQUU7VUFBRXFGLFdBQVcsRUFBRTtZQUFFTCxLQUFLLEVBQUU7VUFBVTtRQUFFO01BQzdDO0lBQ0YsQ0FBQyxDQUFDOztJQUVGO0lBQ0EsTUFBTU0sWUFBb0MsR0FBRyxDQUFDLENBQUM7SUFDL0MsQ0FBQyxFQUFBcEIsZUFBQSxHQUFBVyxJQUFJLENBQUNFLFNBQVMsY0FBQWIsZUFBQSx1QkFBZEEsZUFBQSxDQUFnQnFCLE9BQU8sS0FBSSxFQUFFLEVBQUVDLE9BQU8sQ0FBRUMsQ0FBTSxJQUFLO01BQ2xESCxZQUFZLENBQUNHLENBQUMsQ0FBQ0MsR0FBRyxDQUFDLEdBQUdELENBQUMsQ0FBQ0UsU0FBUztJQUNuQyxDQUFDLENBQUM7O0lBRUY7SUFDQSxNQUFNQyxjQUFzQyxHQUFHLENBQUMsQ0FBQztJQUNqRCxDQUFDLEVBQUF6QixpQkFBQSxHQUFBVSxJQUFJLENBQUM1TSxXQUFXLGNBQUFrTSxpQkFBQSx1QkFBaEJBLGlCQUFBLENBQWtCb0IsT0FBTyxLQUFJLEVBQUUsRUFBRUMsT0FBTyxDQUFFQyxDQUFNLElBQUs7TUFDcERHLGNBQWMsQ0FBQ0gsQ0FBQyxDQUFDQyxHQUFHLENBQUMsR0FBR0QsQ0FBQyxDQUFDRSxTQUFTO0lBQ3JDLENBQUMsQ0FBQzs7SUFFRjtJQUNBLE1BQU1FLGNBQXNDLEdBQUcsQ0FBQyxDQUFDO0lBQ2pELENBQUMsRUFBQXpCLGlCQUFBLEdBQUFTLElBQUksQ0FBQzNNLFdBQVcsY0FBQWtNLGlCQUFBLHVCQUFoQkEsaUJBQUEsQ0FBa0JtQixPQUFPLEtBQUksRUFBRSxFQUFFQyxPQUFPLENBQUVDLENBQU0sSUFBSztNQUNwREksY0FBYyxDQUFDSixDQUFDLENBQUNDLEdBQUcsQ0FBQyxHQUFHRCxDQUFDLENBQUNFLFNBQVM7SUFDckMsQ0FBQyxDQUFDOztJQUVGO0lBQ0EsTUFBTUcsY0FBc0MsR0FBRyxDQUFDLENBQUM7SUFDakQsQ0FBQyxFQUFBekIsaUJBQUEsR0FBQVEsSUFBSSxDQUFDMU0sV0FBVyxjQUFBa00saUJBQUEsdUJBQWhCQSxpQkFBQSxDQUFrQmtCLE9BQU8sS0FBSSxFQUFFLEVBQUVDLE9BQU8sQ0FBRUMsQ0FBTSxJQUFLO01BQ3BESyxjQUFjLENBQUNMLENBQUMsQ0FBQ0MsR0FBRyxDQUFDLEdBQUdELENBQUMsQ0FBQ0UsU0FBUztJQUNyQyxDQUFDLENBQUM7SUFFRixNQUFNSSxVQUFVLEdBQUcsRUFBQXpCLFdBQUEsR0FBQU8sSUFBSSxDQUFDN0UsS0FBSyxjQUFBc0UsV0FBQSx1QkFBVkEsV0FBQSxDQUFZYixLQUFLLEtBQUksQ0FBQztJQUV6QyxPQUFPO01BQ0w5TCxXQUFXLEVBQUVvTyxVQUFVO01BQ3ZCbk8sVUFBVSxFQUFFME4sWUFBWSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUM7TUFDckN6TixpQkFBaUIsRUFBRXlOLFlBQVksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDO01BQ25EeE4sYUFBYSxFQUFFd04sWUFBWSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUM7TUFDM0N2TixjQUFjLEVBQUV1TixZQUFZLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQztNQUM3Q3ROLFlBQVksRUFBRXNOLFlBQVksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDO01BQ3pDck4sV0FBVyxFQUFFMk4sY0FBcUI7TUFDbEMxTixXQUFXLEVBQUUyTixjQUFxQjtNQUNsQzFOLFdBQVcsRUFBRTJOLGNBQWM7TUFDM0IxTixzQkFBc0IsRUFBRSxFQUFBbU0scUJBQUEsR0FBQU0sSUFBSSxDQUFDSSxtQkFBbUIsY0FBQVYscUJBQUEsdUJBQXhCQSxxQkFBQSxDQUEwQmQsS0FBSyxLQUFJLElBQUk7TUFDL0RwTCxtQkFBbUIsRUFBRSxFQUFBbU0sbUJBQUEsR0FBQUssSUFBSSxDQUFDTSxhQUFhLGNBQUFYLG1CQUFBLHVCQUFsQkEsbUJBQUEsQ0FBb0JtQixTQUFTLEtBQUksQ0FBQztNQUN2RHJOLGtCQUFrQixFQUFFLEVBQUFtTSxrQkFBQSxHQUFBSSxJQUFJLENBQUNPLFlBQVksY0FBQVgsa0JBQUEsdUJBQWpCQSxrQkFBQSxDQUFtQmtCLFNBQVMsS0FBSTtJQUN0RCxDQUFDO0VBQ0g7O0VBRUE7RUFDQSxhQUFhSyxhQUFhQSxDQUFDN00sTUFBVyxFQUFFOE0sSUFBWSxHQUFHLEVBQUUsRUFBd0I7SUFBQSxJQUFBQyxxQkFBQSxFQUFBQyxxQkFBQTtJQUMvRSxNQUFNQyxRQUFRLEdBQUcsSUFBSXhOLElBQUksQ0FBQyxDQUFDO0lBQzNCd04sUUFBUSxDQUFDQyxPQUFPLENBQUNELFFBQVEsQ0FBQ0UsT0FBTyxDQUFDLENBQUMsR0FBR0wsSUFBSSxDQUFDO0lBRTNDLE1BQU1wQixJQUFJLEdBQUcsTUFBTXhMLHFDQUFpQixDQUFDeUwsa0JBQWtCLENBQUMzTCxNQUFNLEVBQUV1QixxQkFBVSxFQUFFO01BQzFFK0MsS0FBSyxFQUFFO1FBQ0w0QixLQUFLLEVBQUU7VUFBRTVELFVBQVUsRUFBRTtZQUFFNkQsR0FBRyxFQUFFOEcsUUFBUSxDQUFDaE0sV0FBVyxDQUFDO1VBQUU7UUFBRTtNQUN2RCxDQUFDO01BQ0R5SyxJQUFJLEVBQUU7UUFDSjBCLGVBQWUsRUFBRTtVQUNmQyxjQUFjLEVBQUU7WUFDZHhCLEtBQUssRUFBRSxZQUFZO1lBQ25CeUIsaUJBQWlCLEVBQUU7VUFDckI7UUFDRixDQUFDO1FBQ0RDLGdCQUFnQixFQUFFO1VBQ2hCakYsTUFBTSxFQUFFO1lBQUVrRixNQUFNLEVBQUU7Y0FBRTNCLEtBQUssRUFBRTtZQUFZO1VBQUUsQ0FBQztVQUMxQ0gsSUFBSSxFQUFFO1lBQ0orQixNQUFNLEVBQUU7Y0FDTkosY0FBYyxFQUFFO2dCQUNkeEIsS0FBSyxFQUFFLFdBQVc7Z0JBQ2xCeUIsaUJBQWlCLEVBQUU7Y0FDckI7WUFDRjtVQUNGO1FBQ0Y7TUFDRjtJQUNGLENBQUMsQ0FBQztJQUVGLE1BQU1JLGNBQWMsR0FBRyxFQUFBWCxxQkFBQSxHQUFBckIsSUFBSSxDQUFDMEIsZUFBZSxjQUFBTCxxQkFBQSx1QkFBcEJBLHFCQUFBLENBQXNCWCxPQUFPLEtBQUksRUFBRTtJQUMxRCxNQUFNdUIsYUFBYSxHQUFHLEVBQUFYLHFCQUFBLEdBQUF0QixJQUFJLENBQUM2QixnQkFBZ0IsY0FBQVAscUJBQUEsZ0JBQUFBLHFCQUFBLEdBQXJCQSxxQkFBQSxDQUF1QlMsTUFBTSxjQUFBVCxxQkFBQSx1QkFBN0JBLHFCQUFBLENBQStCWixPQUFPLEtBQUksRUFBRTs7SUFFbEU7SUFDQSxNQUFNd0IsU0FBaUMsR0FBRyxDQUFDLENBQUM7SUFDNUNELGFBQWEsQ0FBQ3RCLE9BQU8sQ0FBRUMsQ0FBTSxJQUFLO01BQUEsSUFBQXVCLGdCQUFBO01BQ2hDLE1BQU1DLE9BQU8sR0FBRyxFQUFBRCxnQkFBQSxHQUFBdkIsQ0FBQyxDQUFDeUIsYUFBYSxjQUFBRixnQkFBQSx1QkFBZkEsZ0JBQUEsQ0FBaUJ2SSxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUksRUFBRTtNQUNwRHNJLFNBQVMsQ0FBQ0UsT0FBTyxDQUFDLEdBQUd4QixDQUFDLENBQUNFLFNBQVM7SUFDbEMsQ0FBQyxDQUFDO0lBRUYsT0FBT2tCLGNBQWMsQ0FBQ25JLEdBQUcsQ0FBRStHLENBQU0sSUFBSztNQUFBLElBQUEwQixpQkFBQTtNQUNwQyxNQUFNRixPQUFPLEdBQUcsRUFBQUUsaUJBQUEsR0FBQTFCLENBQUMsQ0FBQ3lCLGFBQWEsY0FBQUMsaUJBQUEsdUJBQWZBLGlCQUFBLENBQWlCMUksS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFJLEVBQUU7TUFDcEQsT0FBTztRQUNMMkksSUFBSSxFQUFFSCxPQUFPO1FBQ2JJLE9BQU8sRUFBRTVCLENBQUMsQ0FBQ0UsU0FBUztRQUNwQjJCLE1BQU0sRUFBRVAsU0FBUyxDQUFDRSxPQUFPLENBQUMsSUFBSTtNQUNoQyxDQUFDO0lBQ0gsQ0FBQyxDQUFDO0VBQ0o7O0VBRUE7RUFDQTtFQUNBOztFQUVBO0FBQ0Y7QUFDQTtBQUNBO0VBQ0UsYUFBYU0sb0JBQW9CQSxDQUFDcE8sTUFBVyxFQUFFa0osS0FBVSxFQUFFckksSUFBWSxFQUF3QjtJQUFBLElBQUF3TixXQUFBLEVBQUFDLFlBQUEsRUFBQUMsWUFBQSxFQUFBQyxZQUFBLEVBQUFDLFlBQUEsRUFBQUMsYUFBQSxFQUFBQyxZQUFBLEVBQUFDLFlBQUEsRUFBQUMsYUFBQTtJQUM3RixNQUFNQyxNQUFNLElBQUFULFdBQUEsR0FBR25GLEtBQUssQ0FBQzZGLElBQUksY0FBQVYsV0FBQSx1QkFBVkEsV0FBQSxDQUFZdE4sRUFBRTtJQUM3QixNQUFNaU8sT0FBTyxJQUFBVixZQUFBLEdBQUdwRixLQUFLLENBQUMrRixLQUFLLGNBQUFYLFlBQUEsdUJBQVhBLFlBQUEsQ0FBYXZOLEVBQUU7SUFDL0IsTUFBTXlJLE9BQU8sR0FBR04sS0FBSyxDQUFDbkksRUFBRTtJQUV4QixJQUFJLENBQUMrTixNQUFNLElBQUksQ0FBQ0UsT0FBTyxJQUFJLENBQUN4RixPQUFPLEVBQUU7TUFDbkMsTUFBTSxJQUFJMEYsS0FBSyxDQUFDLHlEQUF5RCxDQUFDO0lBQzVFO0lBRUEsTUFBTUMsV0FBd0IsR0FBRztNQUMvQjlGLFFBQVEsRUFBRUcsT0FBTztNQUNqQjRGLEtBQUssRUFBRWxHLEtBQUssQ0FBQ21HLE1BQU0sSUFBSSxnQkFBZ0I7TUFDdkN4RixPQUFPLEVBQUV5RixRQUFRLENBQUNSLE1BQU0sRUFBRSxFQUFFLENBQUM7TUFDN0J4RixnQkFBZ0IsRUFBRSxFQUFBaUYsWUFBQSxHQUFBckYsS0FBSyxDQUFDNkYsSUFBSSxjQUFBUixZQUFBLHVCQUFWQSxZQUFBLENBQVkxTSxXQUFXLEtBQUksY0FBYztNQUMzRDBOLFVBQVUsRUFBRSxFQUFBZixZQUFBLEdBQUF0RixLQUFLLENBQUM2RixJQUFJLGNBQUFQLFlBQUEsdUJBQVZBLFlBQUEsQ0FBWWdCLEtBQUssS0FBSSxDQUFDO01BQ2xDQyxXQUFXLEVBQUUsRUFBQWhCLFlBQUEsR0FBQXZGLEtBQUssQ0FBQzZGLElBQUksY0FBQU4sWUFBQSx1QkFBVkEsWUFBQSxDQUFZaUIsTUFBTSxLQUFJLEVBQUU7TUFDckM5RixRQUFRLEVBQUVvRixPQUFPO01BQ2pCVyxVQUFVLEVBQUUsRUFBQWpCLGFBQUEsR0FBQXhGLEtBQUssQ0FBQytGLEtBQUssY0FBQVAsYUFBQSx1QkFBWEEsYUFBQSxDQUFha0IsSUFBSSxLQUFJLGVBQWU7TUFDaEQ1TyxTQUFTLEVBQUVrSSxLQUFLLENBQUNsSSxTQUFTLElBQUksSUFBSXZCLElBQUksQ0FBQyxDQUFDLENBQUN3QixXQUFXLENBQUMsQ0FBQztNQUN0RDRPLFFBQVEsRUFBRTNHLEtBQUssQ0FBQzJHO0lBQ2xCLENBQUM7O0lBRUQ7SUFDQSxNQUFNeEosVUFBVSxHQUFHO01BQ2pCL0IsS0FBSyxFQUFFO1FBQ0xnQyxJQUFJLEVBQUU7VUFDSm5CLElBQUksRUFBRSxDQUNKO1lBQUVPLEtBQUssRUFBRTtjQUFFNUQsTUFBTSxFQUFFLENBQUMsTUFBTSxFQUFFLGFBQWEsRUFBRSxTQUFTO1lBQUU7VUFBRSxDQUFDLEVBQ3pEO1lBQUVzRCxJQUFJLEVBQUU7Y0FBRSx5Q0FBeUMsRUFBRTdFLE1BQU0sQ0FBQ3VPLE1BQU07WUFBRTtVQUFFLENBQUMsRUFDdkU7WUFBRTFKLElBQUksRUFBRTtjQUFFLDBDQUEwQyxFQUFFN0UsTUFBTSxDQUFDeU8sT0FBTztZQUFFO1VBQUUsQ0FBQztRQUU3RTtNQUNGLENBQUM7TUFDRHRJLElBQUksRUFBRSxDQUFDO01BQ1BGLElBQUksRUFBRSxDQUFDO1FBQUVsRSxVQUFVLEVBQUU7VUFBRW1FLEtBQUssRUFBRTtRQUFPO01BQUUsQ0FBQztJQUMxQyxDQUFDO0lBRUQsTUFBTXFKLFlBQVksR0FBRyxNQUFNNVAscUNBQWlCLENBQUM0RyxlQUFlLENBQUM5RyxNQUFNLEVBQUV1QixxQkFBVSxFQUFFOEUsVUFBVSxDQUFDOztJQUU1RjtJQUNBLElBQUl5SixZQUFZLENBQUNsSixJQUFJLENBQUMzQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO01BQ2hDLE1BQU04TCxZQUFZLEdBQUdELFlBQVksQ0FBQ2xKLElBQUksQ0FBQyxDQUFDLENBQUM7TUFDekMsTUFBTW5GLE1BQU0sR0FBR3NPLFlBQVksQ0FBQzNNLEdBQUc7O01BRS9CO01BQ0EsTUFBTTRNLGFBQWEsR0FBR0QsWUFBWSxDQUFDdE0sT0FBTyxDQUFDaEIsYUFBYSxDQUFDMEcsSUFBSSxDQUFFQyxDQUFNLElBQUtBLENBQUMsQ0FBQ0MsUUFBUSxLQUFLRyxPQUFPLENBQUM7TUFDakcsSUFBSXdHLGFBQWEsRUFBRTtRQUNoQixPQUFPO1VBQUVqUCxFQUFFLEVBQUVVLE1BQU07VUFBRSxHQUFHc08sWUFBWSxDQUFDdE07UUFBUSxDQUFDO01BQ2pEOztNQUVBO01BQ0EsTUFBTXFGLFNBQVMsR0FBRzFKLElBQUksQ0FBQyxDQUFDO01BQ3hCLE1BQU1zSixPQUFvQixHQUFHO1FBQzNCQyxVQUFVLEVBQUVHLFNBQVM7UUFDckJGLE1BQU0sRUFBRSxtQkFBbUI7UUFDM0JILE9BQU8sRUFBRyxrQ0FBaUNxRyxNQUFPLGFBQVlFLE9BQVEsMEJBQXlCO1FBQy9GMU0sVUFBVSxFQUFFLElBQUk3QyxJQUFJLENBQUMsQ0FBQyxDQUFDd0IsV0FBVyxDQUFDO01BQ3JDLENBQUM7TUFFRCxNQUFNNEMsU0FBUyxHQUFHO1FBQ2hCcEIsYUFBYSxFQUFFLENBQUMsR0FBR3NOLFlBQVksQ0FBQ3RNLE9BQU8sQ0FBQ2hCLGFBQWEsRUFBRTBNLFdBQVcsQ0FBQztRQUNuRXhNLFFBQVEsRUFBRSxDQUFDLEdBQUdvTixZQUFZLENBQUN0TSxPQUFPLENBQUNkLFFBQVEsRUFBRStGLE9BQU8sQ0FBQztRQUNyRG5HLFVBQVUsRUFBRSxJQUFJOUMsSUFBSSxDQUFDLENBQUMsQ0FBQ3dCLFdBQVcsQ0FBQztNQUNyQyxDQUFDO01BRUQsTUFBTWYscUNBQWlCLENBQUNnRSxjQUFjLENBQUNsRSxNQUFNLEVBQUV1QixxQkFBVSxFQUFFRSxNQUFNLEVBQUVvQyxTQUFTLENBQUM7TUFDN0UsT0FBTyxNQUFNL0QsV0FBVyxDQUFDd0QsT0FBTyxDQUFDdEQsTUFBTSxFQUFFeUIsTUFBTSxDQUFDO0lBQ2xEOztJQUVBO0lBQ0EsSUFBSU0sUUFBc0IsR0FBRyxLQUFLO0lBQ2xDLE1BQU15TixLQUFLLEdBQUcsRUFBQWIsWUFBQSxHQUFBekYsS0FBSyxDQUFDNkYsSUFBSSxjQUFBSixZQUFBLHVCQUFWQSxZQUFBLENBQVlhLEtBQUssS0FBSSxDQUFDO0lBQ3BDLElBQUlBLEtBQUssSUFBSSxFQUFFLEVBQUV6TixRQUFRLEdBQUcsVUFBVSxDQUFDLEtBQ2xDLElBQUl5TixLQUFLLElBQUksQ0FBQyxFQUFFek4sUUFBUSxHQUFHLE1BQU0sQ0FBQyxLQUNsQyxJQUFJeU4sS0FBSyxJQUFJLENBQUMsRUFBRXpOLFFBQVEsR0FBRyxRQUFRO0lBRXhDLE1BQU1aLE9BQTBCLEdBQUc7TUFDakNTLEtBQUssRUFBRyxlQUFjLEVBQUFnTixZQUFBLEdBQUExRixLQUFLLENBQUM2RixJQUFJLGNBQUFILFlBQUEsdUJBQVZBLFlBQUEsQ0FBWS9NLFdBQVcsS0FBSSxnQkFBaUIsRUFBQztNQUNuRUEsV0FBVyxFQUFHLHFEQUFvRGlOLE1BQU8sWUFBUyxDQUFBRCxhQUFBLEdBQUUzRixLQUFLLENBQUMrRixLQUFLLGNBQUFKLGFBQUEsdUJBQVhBLGFBQUEsQ0FBYWUsSUFBSyxLQUFJWixPQUFRLGFBQVlRLEtBQU0sWUFBV3RHLEtBQUssQ0FBQzJHLFFBQVEsSUFBSSxLQUFNLEVBQUM7TUFDeEs5TixRQUFRO01BQ1JDLFFBQVEsRUFBRSxJQUFJO01BQ2RDLFFBQVEsRUFBRSxPQUFPO01BQ2pCRSxJQUFJLEVBQUUsQ0FBQyxXQUFXLEVBQUcsUUFBTzJNLE1BQU8sRUFBQyxFQUFHLFNBQVFFLE9BQVEsRUFBQztJQUMxRCxDQUFDO0lBRUQsTUFBTXROLE9BQU8sR0FBRyxNQUFNNUIsV0FBVyxDQUFDb0IsVUFBVSxDQUFDbEIsTUFBTSxFQUFFbUIsT0FBTyxFQUFFTixJQUFJLENBQUM7O0lBRW5FO0lBQ0EsSUFBSWEsT0FBTyxDQUFDWCxFQUFFLEVBQUU7TUFDYixNQUFNYixxQ0FBaUIsQ0FBQ2dFLGNBQWMsQ0FBQ2xFLE1BQU0sRUFBRXVCLHFCQUFVLEVBQUVHLE9BQU8sQ0FBQ1gsRUFBRSxFQUFFO1FBQ3JFbUMsYUFBYSxFQUFFO1VBQ2IrTSxpQkFBaUIsRUFBRTFQLE1BQU0sQ0FBQ3VPLE1BQU0sQ0FBQztVQUNqQ29CLGtCQUFrQixFQUFFM1AsTUFBTSxDQUFDeU8sT0FBTztRQUNwQyxDQUFDO1FBQ0R2TSxhQUFhLEVBQUUsQ0FBQzBNLFdBQVc7TUFDN0IsQ0FBQyxDQUFDO01BQ0YsT0FBTyxNQUFNclAsV0FBVyxDQUFDd0QsT0FBTyxDQUFDdEQsTUFBTSxFQUFFMEIsT0FBTyxDQUFDWCxFQUFFLENBQUM7SUFDdkQ7SUFFQSxPQUFPVyxPQUFPO0VBQ2hCO0FBQ0Y7QUFBQ3lPLE9BQUEsQ0FBQXJRLFdBQUEsR0FBQUEsV0FBQSJ9