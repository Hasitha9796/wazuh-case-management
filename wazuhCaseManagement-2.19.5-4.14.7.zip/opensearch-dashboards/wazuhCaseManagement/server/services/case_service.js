"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.CaseService = void 0;
var _constants = require("../../common/constants");
var _opensearch_service = require("./opensearch_service");
/*
 * Wazuh Case Management Plugin
 * Case Service — Business logic for case management operations
 *
 * Handles case ID generation, CRUD, status transitions, comments,
 * alert linking, observables, activity logging, and analytics.
 */

/** Generate a UUID v4 without dashes (compact) */
function uuid() {
  // Use crypto.randomUUID if available, fallback to manual
  try {
    return crypto.randomUUID().replace(/-/g, '').substring(0, 12);
  } catch {
    return Date.now().toString(36) + Math.random().toString(36).substring(2, 8);
  }
}

/**
 * CaseService — all case management business logic.
 * Methods are static; the OpenSearch client is passed in per-request.
 */
class CaseService {
  // ──────────────────────────────────────────────────────────────
  // Case ID Generation
  // ──────────────────────────────────────────────────────────────

  /**
   * Generate the next human-readable case ID.
   * Format: CASE-2026-0001
   */
  static async generateCaseId(client) {
    const counter = await _opensearch_service.OpenSearchService.getNextCounterValue(client);
    const year = new Date().getFullYear();
    const paddedNum = String(counter).padStart(4, '0');
    return `${_constants.CASE_ID_PREFIX}${_constants.CASE_ID_SEPARATOR}${year}${_constants.CASE_ID_SEPARATOR}${paddedNum}`;
  }

  // ──────────────────────────────────────────────────────────────
  // Activity Log Helper
  // ──────────────────────────────────────────────────────────────

  static createActivity(action, user, details) {
    return {
      id: uuid(),
      action,
      user,
      timestamp: new Date().toISOString(),
      details
    };
  }

  // ──────────────────────────────────────────────────────────────
  // Case CRUD
  // ──────────────────────────────────────────────────────────────

  /** Create a new case */
  static async createCase(client, payload, user) {
    const caseId = await CaseService.generateCaseId(client);
    const now = new Date().toISOString();
    const newCase = {
      case_id: caseId,
      title: payload.title,
      description: payload.description,
      status: 'open',
      severity: payload.severity,
      priority: payload.priority,
      category: payload.category,
      tlp: payload.tlp || 'WHITE',
      tags: payload.tags || [],
      assignee: payload.assignee || null,
      created_by: user,
      created_at: now,
      updated_at: now,
      closed_at: null,
      linked_alerts: [],
      observables: [],
      comments: [],
      tasks: [],
      notes: '',
      activity_log: [CaseService.createActivity('case_created', user, {
        case_id: caseId,
        title: payload.title
      })],
      resolution_summary: null,
      time_to_resolve_ms: null,
      related_cases: [],
      custom_fields: {}
    };

    // If an assignee was provided, log the assignment
    if (payload.assignee) {
      newCase.activity_log.push(CaseService.createActivity('assigned', user, {
        assignee: payload.assignee
      }));
    }
    const {
      _id
    } = await _opensearch_service.OpenSearchService.createDocument(client, _constants.CASE_INDEX, newCase);
    newCase.id = _id;
    return newCase;
  }

  /** Get a single case by its OpenSearch _id */
  static async getCase(client, id) {
    const doc = await _opensearch_service.OpenSearchService.getDocument(client, _constants.CASE_INDEX, id);
    if (!doc) return null;
    return {
      id: doc._id,
      ...doc._source
    };
  }

  /** Update a case (partial update) */
  static async updateCase(client, id, payload, user) {
    const existing = await CaseService.getCase(client, id);
    if (!existing) return null;
    const now = new Date().toISOString();
    const activities = [];
    const updateDoc = {
      updated_at: now
    };

    // Track changes for activity log
    if (payload.title !== undefined && payload.title !== existing.title) {
      updateDoc.title = payload.title;
    }
    if (payload.description !== undefined) {
      updateDoc.description = payload.description;
    }
    if (payload.severity !== undefined && payload.severity !== existing.severity) {
      updateDoc.severity = payload.severity;
      activities.push(CaseService.createActivity('severity_changed', user, {
        from: existing.severity,
        to: payload.severity
      }));
    }
    if (payload.priority !== undefined && payload.priority !== existing.priority) {
      updateDoc.priority = payload.priority;
      activities.push(CaseService.createActivity('priority_changed', user, {
        from: existing.priority,
        to: payload.priority
      }));
    }
    if (payload.category !== undefined) {
      updateDoc.category = payload.category;
    }
    if (payload.tlp !== undefined) {
      updateDoc.tlp = payload.tlp;
    }
    if (payload.tags !== undefined) {
      updateDoc.tags = payload.tags;
    }
    if (payload.assignee !== undefined && payload.assignee !== existing.assignee) {
      updateDoc.assignee = payload.assignee;
      activities.push(CaseService.createActivity(payload.assignee ? 'assigned' : 'unassigned', user, {
        from: existing.assignee,
        to: payload.assignee
      }));
    }
    if (payload.resolution_summary !== undefined) {
      updateDoc.resolution_summary = payload.resolution_summary;
    }

    // Append activities
    if (activities.length > 0) {
      updateDoc.activity_log = [...existing.activity_log, ...activities];
    }
    await _opensearch_service.OpenSearchService.updateDocument(client, _constants.CASE_INDEX, id, updateDoc);
    return await CaseService.getCase(client, id);
  }

  /** Delete a case by OpenSearch _id */
  static async deleteCase(client, id) {
    return await _opensearch_service.OpenSearchService.deleteDocument(client, _constants.CASE_INDEX, id);
  }

  /** List cases with filtering, pagination, and sorting */
  static async listCases(client, query) {
    const page = query.page || 1;
    const perPage = Math.min(query.per_page || _constants.DEFAULT_PAGE_SIZE, _constants.MAX_PAGE_SIZE);
    const sortField = query.sort_field || _constants.DEFAULT_SORT_FIELD;
    const sortOrder = query.sort_order || _constants.DEFAULT_SORT_ORDER;

    // Build the query
    const must = [];
    if (query.status) {
      must.push({
        term: {
          status: query.status
        }
      });
    }
    if (query.severity) {
      must.push({
        term: {
          severity: query.severity
        }
      });
    }
    if (query.priority) {
      must.push({
        term: {
          priority: query.priority
        }
      });
    }
    if (query.category) {
      must.push({
        term: {
          category: query.category
        }
      });
    }
    if (query.assignee) {
      must.push({
        term: {
          assignee: query.assignee
        }
      });
    }
    if (query.tags) {
      const tagList = query.tags.split(',').map(t => t.trim());
      must.push({
        terms: {
          tags: tagList
        }
      });
    }
    if (query.search) {
      must.push({
        multi_match: {
          query: query.search,
          fields: ['title^3', 'description', 'case_id^2', 'tags'],
          type: 'best_fields',
          fuzziness: 'AUTO'
        }
      });
    }
    if (query.created_from || query.created_to) {
      const range = {};
      if (query.created_from) range.gte = query.created_from;
      if (query.created_to) range.lte = query.created_to;
      must.push({
        range: {
          created_at: range
        }
      });
    }
    const searchBody = {
      query: must.length > 0 ? {
        bool: {
          must
        }
      } : {
        match_all: {}
      },
      sort: [{
        [sortField]: {
          order: sortOrder
        }
      }],
      from: (page - 1) * perPage,
      size: perPage,
      // Exclude heavy nested fields from listing to improve perf
      _source: {
        excludes: ['activity_log', 'comments.content']
      }
    };
    const {
      hits,
      total
    } = await _opensearch_service.OpenSearchService.searchDocuments(client, _constants.CASE_INDEX, searchBody);
    const cases = hits.map(hit => ({
      id: hit._id,
      ...hit._source
    }));
    return {
      cases,
      total,
      page,
      per_page: perPage
    };
  }

  // ──────────────────────────────────────────────────────────────
  // Status Management
  // ──────────────────────────────────────────────────────────────

  /** Change case status with transition validation */
  static async changeStatus(client, id, newStatus, user) {
    const existing = await CaseService.getCase(client, id);
    if (!existing) {
      return {
        success: false,
        error: 'Case not found'
      };
    }

    // Validate transition
    const allowedTransitions = _constants.STATUS_TRANSITIONS[existing.status] || [];
    if (!allowedTransitions.includes(newStatus)) {
      return {
        success: false,
        error: `Cannot transition from '${existing.status}' to '${newStatus}'. Allowed: ${allowedTransitions.join(', ')}`
      };
    }
    const now = new Date().toISOString();
    const updateDoc = {
      status: newStatus,
      updated_at: now
    };

    // Handle closing
    if (newStatus === 'closed' || newStatus === 'resolved') {
      updateDoc.closed_at = now;
      if (existing.created_at) {
        updateDoc.time_to_resolve_ms = new Date(now).getTime() - new Date(existing.created_at).getTime();
      }
    }

    // Handle reopening
    if (newStatus === 'open' && (existing.status === 'closed' || existing.status === 'resolved')) {
      updateDoc.closed_at = null;
      updateDoc.time_to_resolve_ms = null;
    }

    // Activity
    const activity = CaseService.createActivity(newStatus === 'closed' ? 'case_closed' : newStatus === 'open' && existing.status === 'closed' ? 'case_reopened' : 'status_changed', user, {
      from: existing.status,
      to: newStatus
    });
    updateDoc.activity_log = [...existing.activity_log, activity];
    await _opensearch_service.OpenSearchService.updateDocument(client, _constants.CASE_INDEX, id, updateDoc);
    const updatedCase = await CaseService.getCase(client, id);
    return {
      success: true,
      case: updatedCase
    };
  }

  /** Assign a case to a user */
  static async assignCase(client, id, assignee, user) {
    const existing = await CaseService.getCase(client, id);
    if (!existing) return null;
    const activity = CaseService.createActivity(assignee ? 'assigned' : 'unassigned', user, {
      from: existing.assignee,
      to: assignee
    });
    await _opensearch_service.OpenSearchService.updateDocument(client, _constants.CASE_INDEX, id, {
      assignee,
      updated_at: new Date().toISOString(),
      activity_log: [...existing.activity_log, activity]
    });
    return await CaseService.getCase(client, id);
  }

  // ──────────────────────────────────────────────────────────────
  // Tasks
  // ──────────────────────────────────────────────────────────────

  /** Add a task to a case */
  static async addTask(client, caseId, title, user) {
    const existing = await CaseService.getCase(client, caseId);
    if (!existing) return null;
    const newTask = {
      task_id: uuid(),
      title,
      completed: false,
      created_at: new Date().toISOString()
    };
    const updateDoc = {
      tasks: [...(existing.tasks || []), newTask],
      updated_at: new Date().toISOString()
    };
    await _opensearch_service.OpenSearchService.updateDocument(client, _constants.CASE_INDEX, caseId, updateDoc);
    return await CaseService.getCase(client, caseId);
  }

  /** Toggle task completion */
  static async toggleTask(client, caseId, taskId, completed, user) {
    const existing = await CaseService.getCase(client, caseId);
    if (!existing) return null;
    const tasks = (existing.tasks || []).map(t => t.task_id === taskId ? {
      ...t,
      completed,
      completed_at: completed ? new Date().toISOString() : undefined
    } : t);
    const updateDoc = {
      tasks,
      updated_at: new Date().toISOString()
    };
    await _opensearch_service.OpenSearchService.updateDocument(client, _constants.CASE_INDEX, caseId, updateDoc);
    return await CaseService.getCase(client, caseId);
  }

  /** Remove a task */
  static async removeTask(client, caseId, taskId, user) {
    const existing = await CaseService.getCase(client, caseId);
    if (!existing) return null;
    const tasks = (existing.tasks || []).filter(t => t.task_id !== taskId);
    const updateDoc = {
      tasks,
      updated_at: new Date().toISOString()
    };
    await _opensearch_service.OpenSearchService.updateDocument(client, _constants.CASE_INDEX, caseId, updateDoc);
    return await CaseService.getCase(client, caseId);
  }

  // ──────────────────────────────────────────────────────────────
  // Notes
  // ──────────────────────────────────────────────────────────────

  /** Update case notes */
  static async updateNotes(client, caseId, notes, user) {
    const existing = await CaseService.getCase(client, caseId);
    if (!existing) return null;
    const updateDoc = {
      notes,
      updated_at: new Date().toISOString()
    };
    await _opensearch_service.OpenSearchService.updateDocument(client, _constants.CASE_INDEX, caseId, updateDoc);
    return await CaseService.getCase(client, caseId);
  }

  // ──────────────────────────────────────────────────────────────
  // Comments
  // ──────────────────────────────────────────────────────────────

  /** Add a comment to a case */
  static async addComment(client, caseId, content, user) {
    const existing = await CaseService.getCase(client, caseId);
    if (!existing) return null;
    const comment = {
      comment_id: uuid(),
      author: user,
      content,
      created_at: new Date().toISOString()
    };
    const activity = CaseService.createActivity('comment_added', user, {
      comment_id: comment.comment_id
    });
    await _opensearch_service.OpenSearchService.updateDocument(client, _constants.CASE_INDEX, caseId, {
      comments: [...existing.comments, comment],
      activity_log: [...existing.activity_log, activity],
      updated_at: new Date().toISOString()
    });
    return await CaseService.getCase(client, caseId);
  }

  /** Delete a comment from a case */
  static async deleteComment(client, caseId, commentId, user) {
    const existing = await CaseService.getCase(client, caseId);
    if (!existing) return null;
    const updatedComments = existing.comments.filter(c => c.comment_id !== commentId);
    if (updatedComments.length === existing.comments.length) {
      return existing; // Comment not found, no change
    }

    const activity = CaseService.createActivity('comment_deleted', user, {
      comment_id: commentId
    });
    await _opensearch_service.OpenSearchService.updateDocument(client, _constants.CASE_INDEX, caseId, {
      comments: updatedComments,
      activity_log: [...existing.activity_log, activity],
      updated_at: new Date().toISOString()
    });
    return await CaseService.getCase(client, caseId);
  }

  // ──────────────────────────────────────────────────────────────
  // Alert Linking
  // ──────────────────────────────────────────────────────────────

  /** Link an alert to a case */
  static async linkAlert(client, caseId, alert, user) {
    const existing = await CaseService.getCase(client, caseId);
    if (!existing) return null;

    // Check for duplicate
    if (existing.linked_alerts.some(a => a.alert_id === alert.alert_id)) {
      return existing; // Already linked
    }

    const activity = CaseService.createActivity('alert_linked', user, {
      alert_id: alert.alert_id,
      rule_description: alert.rule_description
    });
    await _opensearch_service.OpenSearchService.updateDocument(client, _constants.CASE_INDEX, caseId, {
      linked_alerts: [...existing.linked_alerts, alert],
      activity_log: [...existing.activity_log, activity],
      updated_at: new Date().toISOString()
    });
    return await CaseService.getCase(client, caseId);
  }

  /** Unlink an alert from a case */
  static async unlinkAlert(client, caseId, alertId, user) {
    const existing = await CaseService.getCase(client, caseId);
    if (!existing) return null;
    const updatedAlerts = existing.linked_alerts.filter(a => a.alert_id !== alertId);
    const activity = CaseService.createActivity('alert_unlinked', user, {
      alert_id: alertId
    });
    await _opensearch_service.OpenSearchService.updateDocument(client, _constants.CASE_INDEX, caseId, {
      linked_alerts: updatedAlerts,
      activity_log: [...existing.activity_log, activity],
      updated_at: new Date().toISOString()
    });
    return await CaseService.getCase(client, caseId);
  }

  /** Search Wazuh alerts in OpenSearch */
  static async searchAlerts(client, query) {
    const must = [];
    if (query.search) {
      must.push({
        multi_match: {
          query: query.search,
          fields: ['rule.description^2', 'full_log', 'data.*'],
          fuzziness: 'AUTO'
        }
      });
    }
    if (query.agent_id) {
      must.push({
        term: {
          'agent.id': query.agent_id
        }
      });
    }
    if (query.rule_id) {
      must.push({
        term: {
          'rule.id': String(query.rule_id)
        }
      });
    }
    if (query.level_min || query.level_max) {
      const range = {};
      if (query.level_min) range.gte = query.level_min;
      if (query.level_max) range.lte = query.level_max;
      must.push({
        range: {
          'rule.level': range
        }
      });
    }
    if (query.from || query.to) {
      const range = {};
      if (query.from) range.gte = query.from;
      if (query.to) range.lte = query.to;
      must.push({
        range: {
          timestamp: range
        }
      });
    }
    const searchBody = {
      query: must.length > 0 ? {
        bool: {
          must
        }
      } : {
        match_all: {}
      },
      sort: [{
        timestamp: {
          order: 'desc'
        }
      }],
      size: Math.min(query.size || 50, 100)
    };
    return await _opensearch_service.OpenSearchService.searchDocuments(client, _constants.WAZUH_ALERTS_INDEX_PATTERN, searchBody);
  }

  // ──────────────────────────────────────────────────────────────
  // Observables
  // ──────────────────────────────────────────────────────────────

  /** Add an observable to a case */
  static async addObservable(client, caseId, observable, user) {
    const existing = await CaseService.getCase(client, caseId);
    if (!existing) return null;
    const newObservable = {
      ...observable,
      id: uuid(),
      added_at: new Date().toISOString(),
      added_by: user
    };
    const activity = CaseService.createActivity('observable_added', user, {
      type: observable.type,
      value: observable.value
    });
    await _opensearch_service.OpenSearchService.updateDocument(client, _constants.CASE_INDEX, caseId, {
      observables: [...existing.observables, newObservable],
      activity_log: [...existing.activity_log, activity],
      updated_at: new Date().toISOString()
    });
    return await CaseService.getCase(client, caseId);
  }

  /** Remove an observable from a case */
  static async removeObservable(client, caseId, observableId, user) {
    const existing = await CaseService.getCase(client, caseId);
    if (!existing) return null;
    const updated = existing.observables.filter(o => o.id !== observableId);
    const activity = CaseService.createActivity('observable_removed', user, {
      observable_id: observableId
    });
    await _opensearch_service.OpenSearchService.updateDocument(client, _constants.CASE_INDEX, caseId, {
      observables: updated,
      activity_log: [...existing.activity_log, activity],
      updated_at: new Date().toISOString()
    });
    return await CaseService.getCase(client, caseId);
  }

  // ──────────────────────────────────────────────────────────────
  // Analytics
  // ──────────────────────────────────────────────────────────────

  /** Get summary analytics for the dashboard */
  static async getAnalyticsSummary(client) {
    var _aggs$by_status, _aggs$by_severity, _aggs$by_priority, _aggs$by_category, _aggs$total, _aggs$avg_resolution_, _aggs$created_today, _aggs$closed_today;
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const todayStr = today.toISOString();
    const aggs = await _opensearch_service.OpenSearchService.aggregateDocuments(client, _constants.CASE_INDEX, {
      aggs: {
        by_status: {
          terms: {
            field: 'status',
            size: 10
          }
        },
        by_severity: {
          terms: {
            field: 'severity',
            size: 10
          }
        },
        by_priority: {
          terms: {
            field: 'priority',
            size: 10
          }
        },
        by_category: {
          terms: {
            field: 'category',
            size: 20
          }
        },
        avg_resolution_time: {
          avg: {
            field: 'time_to_resolve_ms'
          }
        },
        created_today: {
          filter: {
            range: {
              created_at: {
                gte: todayStr
              }
            }
          }
        },
        closed_today: {
          filter: {
            bool: {
              must: [{
                range: {
                  closed_at: {
                    gte: todayStr
                  }
                }
              }, {
                terms: {
                  status: ['resolved', 'closed']
                }
              }]
            }
          }
        },
        total: {
          value_count: {
            field: 'case_id'
          }
        }
      }
    });

    // Parse status counts
    const statusCounts = {};
    (((_aggs$by_status = aggs.by_status) === null || _aggs$by_status === void 0 ? void 0 : _aggs$by_status.buckets) || []).forEach(b => {
      statusCounts[b.key] = b.doc_count;
    });

    // Parse severity counts
    const severityCounts = {};
    (((_aggs$by_severity = aggs.by_severity) === null || _aggs$by_severity === void 0 ? void 0 : _aggs$by_severity.buckets) || []).forEach(b => {
      severityCounts[b.key] = b.doc_count;
    });

    // Parse priority counts
    const priorityCounts = {};
    (((_aggs$by_priority = aggs.by_priority) === null || _aggs$by_priority === void 0 ? void 0 : _aggs$by_priority.buckets) || []).forEach(b => {
      priorityCounts[b.key] = b.doc_count;
    });

    // Parse category counts
    const categoryCounts = {};
    (((_aggs$by_category = aggs.by_category) === null || _aggs$by_category === void 0 ? void 0 : _aggs$by_category.buckets) || []).forEach(b => {
      categoryCounts[b.key] = b.doc_count;
    });
    const totalCases = ((_aggs$total = aggs.total) === null || _aggs$total === void 0 ? void 0 : _aggs$total.value) || 0;
    return {
      total_cases: totalCases,
      open_cases: statusCounts['open'] || 0,
      in_progress_cases: statusCounts['in_progress'] || 0,
      waiting_cases: statusCounts['waiting'] || 0,
      resolved_cases: statusCounts['resolved'] || 0,
      closed_cases: statusCounts['closed'] || 0,
      by_severity: severityCounts,
      by_priority: priorityCounts,
      by_category: categoryCounts,
      avg_resolution_time_ms: ((_aggs$avg_resolution_ = aggs.avg_resolution_time) === null || _aggs$avg_resolution_ === void 0 ? void 0 : _aggs$avg_resolution_.value) || null,
      cases_created_today: ((_aggs$created_today = aggs.created_today) === null || _aggs$created_today === void 0 ? void 0 : _aggs$created_today.doc_count) || 0,
      cases_closed_today: ((_aggs$closed_today = aggs.closed_today) === null || _aggs$closed_today === void 0 ? void 0 : _aggs$closed_today.doc_count) || 0
    };
  }

  /** Get case trends over the last N days */
  static async getCaseTrends(client, days = 30) {
    var _aggs$cases_over_time, _aggs$closed_over_tim;
    const fromDate = new Date();
    fromDate.setDate(fromDate.getDate() - days);
    const aggs = await _opensearch_service.OpenSearchService.aggregateDocuments(client, _constants.CASE_INDEX, {
      query: {
        range: {
          created_at: {
            gte: fromDate.toISOString()
          }
        }
      },
      aggs: {
        cases_over_time: {
          date_histogram: {
            field: 'created_at',
            calendar_interval: 'day'
          }
        },
        closed_over_time: {
          filter: {
            exists: {
              field: 'closed_at'
            }
          },
          aggs: {
            by_day: {
              date_histogram: {
                field: 'closed_at',
                calendar_interval: 'day'
              }
            }
          }
        }
      }
    });
    const createdBuckets = ((_aggs$cases_over_time = aggs.cases_over_time) === null || _aggs$cases_over_time === void 0 ? void 0 : _aggs$cases_over_time.buckets) || [];
    const closedBuckets = ((_aggs$closed_over_tim = aggs.closed_over_time) === null || _aggs$closed_over_tim === void 0 || (_aggs$closed_over_tim = _aggs$closed_over_tim.by_day) === null || _aggs$closed_over_tim === void 0 ? void 0 : _aggs$closed_over_tim.buckets) || [];

    // Merge created and closed into a single timeline
    const closedMap = {};
    closedBuckets.forEach(b => {
      var _b$key_as_string;
      const dateKey = ((_b$key_as_string = b.key_as_string) === null || _b$key_as_string === void 0 ? void 0 : _b$key_as_string.split('T')[0]) || '';
      closedMap[dateKey] = b.doc_count;
    });
    return createdBuckets.map(b => {
      var _b$key_as_string2;
      const dateKey = ((_b$key_as_string2 = b.key_as_string) === null || _b$key_as_string2 === void 0 ? void 0 : _b$key_as_string2.split('T')[0]) || '';
      return {
        date: dateKey,
        created: b.doc_count,
        closed: closedMap[dateKey] || 0
      };
    });
  }

  // ──────────────────────────────────────────────────────────────
  // Automated Alert Handling (Webhooks)
  // ──────────────────────────────────────────────────────────────

  /**
   * Process an incoming alert from a Wazuh webhook.
   * Performs deduplication based on rule.id and agent.id for unresolved cases.
   */
  static async handleAutomatedAlert(client, alert, user) {
    var _alert$rule, _alert$agent, _alert$rule2, _alert$rule3, _alert$rule4, _alert$agent2, _alert$rule5, _alert$rule6, _alert$agent3;
    const ruleId = (_alert$rule = alert.rule) === null || _alert$rule === void 0 ? void 0 : _alert$rule.id;
    const agentId = (_alert$agent = alert.agent) === null || _alert$agent === void 0 ? void 0 : _alert$agent.id;
    const alertId = alert.id;
    if (!ruleId || !agentId || !alertId) {
      throw new Error('Invalid alert payload: Missing rule.id, agent.id, or id');
    }
    const linkedAlert = {
      alert_id: alertId,
      index: alert._index || 'wazuh-alerts-*',
      rule_id: parseInt(ruleId, 10),
      rule_description: ((_alert$rule2 = alert.rule) === null || _alert$rule2 === void 0 ? void 0 : _alert$rule2.description) || 'Unknown Rule',
      rule_level: ((_alert$rule3 = alert.rule) === null || _alert$rule3 === void 0 ? void 0 : _alert$rule3.level) || 0,
      rule_groups: ((_alert$rule4 = alert.rule) === null || _alert$rule4 === void 0 ? void 0 : _alert$rule4.groups) || [],
      agent_id: agentId,
      agent_name: ((_alert$agent2 = alert.agent) === null || _alert$agent2 === void 0 ? void 0 : _alert$agent2.name) || 'Unknown Agent',
      timestamp: alert.timestamp || new Date().toISOString(),
      full_log: alert.full_log
    };

    // Search for an unresolved case with the exact same rule and agent
    const searchBody = {
      query: {
        bool: {
          must: [{
            terms: {
              status: ['open', 'in_progress', 'waiting']
            }
          }, {
            term: {
              'custom_fields.automated_rule_id.keyword': String(ruleId)
            }
          }, {
            term: {
              'custom_fields.automated_agent_id.keyword': String(agentId)
            }
          }]
        }
      },
      size: 1,
      sort: [{
        created_at: {
          order: 'desc'
        }
      }]
    };
    const searchResult = await _opensearch_service.OpenSearchService.searchDocuments(client, _constants.CASE_INDEX, searchBody);

    // IF DUPLICATE FOUND: Append alert and add comment
    if (searchResult.hits.length > 0) {
      const existingCase = searchResult.hits[0];
      const caseId = existingCase._id;

      // Avoid linking the exact same alert twice
      const alreadyLinked = existingCase._source.linked_alerts.some(a => a.alert_id === alertId);
      if (alreadyLinked) {
        return {
          id: caseId,
          ...existingCase._source
        };
      }

      // Add automated comment
      const commentId = uuid();
      const comment = {
        comment_id: commentId,
        author: 'System Automation',
        content: `Duplicate alert detected (Rule ${ruleId} on Agent ${agentId}). Automatically linked.`,
        created_at: new Date().toISOString()
      };
      const updateDoc = {
        linked_alerts: [...existingCase._source.linked_alerts, linkedAlert],
        comments: [...existingCase._source.comments, comment],
        updated_at: new Date().toISOString()
      };
      await _opensearch_service.OpenSearchService.updateDocument(client, _constants.CASE_INDEX, caseId, updateDoc);
      return await CaseService.getCase(client, caseId);
    }

    // IF NO DUPLICATE: Create new case
    let severity = 'low';
    const level = ((_alert$rule5 = alert.rule) === null || _alert$rule5 === void 0 ? void 0 : _alert$rule5.level) || 0;
    if (level >= 12) severity = 'critical';else if (level >= 8) severity = 'high';else if (level >= 5) severity = 'medium';
    const payload = {
      title: `[Automated] ${((_alert$rule6 = alert.rule) === null || _alert$rule6 === void 0 ? void 0 : _alert$rule6.description) || 'Security Alert'}`,
      description: `Automated case created from Wazuh Alert.\n\nRule: ${ruleId}\nAgent: ${(_alert$agent3 = alert.agent) === null || _alert$agent3 === void 0 ? void 0 : _alert$agent3.name} (${agentId})\nLevel: ${level}\n\nLog: ${alert.full_log || 'N/A'}`,
      severity,
      priority: 'P2',
      category: 'other',
      tags: ['automated', `rule_${ruleId}`, `agent_${agentId}`]
    };
    const newCase = await CaseService.createCase(client, payload, user);

    // Add custom fields for deduplication tracking
    if (newCase.id) {
      await _opensearch_service.OpenSearchService.updateDocument(client, _constants.CASE_INDEX, newCase.id, {
        custom_fields: {
          automated_rule_id: String(ruleId),
          automated_agent_id: String(agentId)
        },
        linked_alerts: [linkedAlert]
      });
      return await CaseService.getCase(client, newCase.id);
    }
    return newCase;
  }
}
exports.CaseService = CaseService;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfY29uc3RhbnRzIiwicmVxdWlyZSIsIl9vcGVuc2VhcmNoX3NlcnZpY2UiLCJ1dWlkIiwiY3J5cHRvIiwicmFuZG9tVVVJRCIsInJlcGxhY2UiLCJzdWJzdHJpbmciLCJEYXRlIiwibm93IiwidG9TdHJpbmciLCJNYXRoIiwicmFuZG9tIiwiQ2FzZVNlcnZpY2UiLCJnZW5lcmF0ZUNhc2VJZCIsImNsaWVudCIsImNvdW50ZXIiLCJPcGVuU2VhcmNoU2VydmljZSIsImdldE5leHRDb3VudGVyVmFsdWUiLCJ5ZWFyIiwiZ2V0RnVsbFllYXIiLCJwYWRkZWROdW0iLCJTdHJpbmciLCJwYWRTdGFydCIsIkNBU0VfSURfUFJFRklYIiwiQ0FTRV9JRF9TRVBBUkFUT1IiLCJjcmVhdGVBY3Rpdml0eSIsImFjdGlvbiIsInVzZXIiLCJkZXRhaWxzIiwiaWQiLCJ0aW1lc3RhbXAiLCJ0b0lTT1N0cmluZyIsImNyZWF0ZUNhc2UiLCJwYXlsb2FkIiwiY2FzZUlkIiwibmV3Q2FzZSIsImNhc2VfaWQiLCJ0aXRsZSIsImRlc2NyaXB0aW9uIiwic3RhdHVzIiwic2V2ZXJpdHkiLCJwcmlvcml0eSIsImNhdGVnb3J5IiwidGxwIiwidGFncyIsImFzc2lnbmVlIiwiY3JlYXRlZF9ieSIsImNyZWF0ZWRfYXQiLCJ1cGRhdGVkX2F0IiwiY2xvc2VkX2F0IiwibGlua2VkX2FsZXJ0cyIsIm9ic2VydmFibGVzIiwiY29tbWVudHMiLCJ0YXNrcyIsIm5vdGVzIiwiYWN0aXZpdHlfbG9nIiwicmVzb2x1dGlvbl9zdW1tYXJ5IiwidGltZV90b19yZXNvbHZlX21zIiwicmVsYXRlZF9jYXNlcyIsImN1c3RvbV9maWVsZHMiLCJwdXNoIiwiX2lkIiwiY3JlYXRlRG9jdW1lbnQiLCJDQVNFX0lOREVYIiwiZ2V0Q2FzZSIsImRvYyIsImdldERvY3VtZW50IiwiX3NvdXJjZSIsInVwZGF0ZUNhc2UiLCJleGlzdGluZyIsImFjdGl2aXRpZXMiLCJ1cGRhdGVEb2MiLCJ1bmRlZmluZWQiLCJmcm9tIiwidG8iLCJsZW5ndGgiLCJ1cGRhdGVEb2N1bWVudCIsImRlbGV0ZUNhc2UiLCJkZWxldGVEb2N1bWVudCIsImxpc3RDYXNlcyIsInF1ZXJ5IiwicGFnZSIsInBlclBhZ2UiLCJtaW4iLCJwZXJfcGFnZSIsIkRFRkFVTFRfUEFHRV9TSVpFIiwiTUFYX1BBR0VfU0laRSIsInNvcnRGaWVsZCIsInNvcnRfZmllbGQiLCJERUZBVUxUX1NPUlRfRklFTEQiLCJzb3J0T3JkZXIiLCJzb3J0X29yZGVyIiwiREVGQVVMVF9TT1JUX09SREVSIiwibXVzdCIsInRlcm0iLCJ0YWdMaXN0Iiwic3BsaXQiLCJtYXAiLCJ0IiwidHJpbSIsInRlcm1zIiwic2VhcmNoIiwibXVsdGlfbWF0Y2giLCJmaWVsZHMiLCJ0eXBlIiwiZnV6emluZXNzIiwiY3JlYXRlZF9mcm9tIiwiY3JlYXRlZF90byIsInJhbmdlIiwiZ3RlIiwibHRlIiwic2VhcmNoQm9keSIsImJvb2wiLCJtYXRjaF9hbGwiLCJzb3J0Iiwib3JkZXIiLCJzaXplIiwiZXhjbHVkZXMiLCJoaXRzIiwidG90YWwiLCJzZWFyY2hEb2N1bWVudHMiLCJjYXNlcyIsImhpdCIsImNoYW5nZVN0YXR1cyIsIm5ld1N0YXR1cyIsInN1Y2Nlc3MiLCJlcnJvciIsImFsbG93ZWRUcmFuc2l0aW9ucyIsIlNUQVRVU19UUkFOU0lUSU9OUyIsImluY2x1ZGVzIiwiam9pbiIsImdldFRpbWUiLCJhY3Rpdml0eSIsInVwZGF0ZWRDYXNlIiwiY2FzZSIsImFzc2lnbkNhc2UiLCJhZGRUYXNrIiwibmV3VGFzayIsInRhc2tfaWQiLCJjb21wbGV0ZWQiLCJ0b2dnbGVUYXNrIiwidGFza0lkIiwiY29tcGxldGVkX2F0IiwicmVtb3ZlVGFzayIsImZpbHRlciIsInVwZGF0ZU5vdGVzIiwiYWRkQ29tbWVudCIsImNvbnRlbnQiLCJjb21tZW50IiwiY29tbWVudF9pZCIsImF1dGhvciIsImRlbGV0ZUNvbW1lbnQiLCJjb21tZW50SWQiLCJ1cGRhdGVkQ29tbWVudHMiLCJjIiwibGlua0FsZXJ0IiwiYWxlcnQiLCJzb21lIiwiYSIsImFsZXJ0X2lkIiwicnVsZV9kZXNjcmlwdGlvbiIsInVubGlua0FsZXJ0IiwiYWxlcnRJZCIsInVwZGF0ZWRBbGVydHMiLCJzZWFyY2hBbGVydHMiLCJhZ2VudF9pZCIsInJ1bGVfaWQiLCJsZXZlbF9taW4iLCJsZXZlbF9tYXgiLCJXQVpVSF9BTEVSVFNfSU5ERVhfUEFUVEVSTiIsImFkZE9ic2VydmFibGUiLCJvYnNlcnZhYmxlIiwibmV3T2JzZXJ2YWJsZSIsImFkZGVkX2F0IiwiYWRkZWRfYnkiLCJ2YWx1ZSIsInJlbW92ZU9ic2VydmFibGUiLCJvYnNlcnZhYmxlSWQiLCJ1cGRhdGVkIiwibyIsIm9ic2VydmFibGVfaWQiLCJnZXRBbmFseXRpY3NTdW1tYXJ5IiwiX2FnZ3MkYnlfc3RhdHVzIiwiX2FnZ3MkYnlfc2V2ZXJpdHkiLCJfYWdncyRieV9wcmlvcml0eSIsIl9hZ2dzJGJ5X2NhdGVnb3J5IiwiX2FnZ3MkdG90YWwiLCJfYWdncyRhdmdfcmVzb2x1dGlvbl8iLCJfYWdncyRjcmVhdGVkX3RvZGF5IiwiX2FnZ3MkY2xvc2VkX3RvZGF5IiwidG9kYXkiLCJzZXRIb3VycyIsInRvZGF5U3RyIiwiYWdncyIsImFnZ3JlZ2F0ZURvY3VtZW50cyIsImJ5X3N0YXR1cyIsImZpZWxkIiwiYnlfc2V2ZXJpdHkiLCJieV9wcmlvcml0eSIsImJ5X2NhdGVnb3J5IiwiYXZnX3Jlc29sdXRpb25fdGltZSIsImF2ZyIsImNyZWF0ZWRfdG9kYXkiLCJjbG9zZWRfdG9kYXkiLCJ2YWx1ZV9jb3VudCIsInN0YXR1c0NvdW50cyIsImJ1Y2tldHMiLCJmb3JFYWNoIiwiYiIsImtleSIsImRvY19jb3VudCIsInNldmVyaXR5Q291bnRzIiwicHJpb3JpdHlDb3VudHMiLCJjYXRlZ29yeUNvdW50cyIsInRvdGFsQ2FzZXMiLCJ0b3RhbF9jYXNlcyIsIm9wZW5fY2FzZXMiLCJpbl9wcm9ncmVzc19jYXNlcyIsIndhaXRpbmdfY2FzZXMiLCJyZXNvbHZlZF9jYXNlcyIsImNsb3NlZF9jYXNlcyIsImF2Z19yZXNvbHV0aW9uX3RpbWVfbXMiLCJjYXNlc19jcmVhdGVkX3RvZGF5IiwiY2FzZXNfY2xvc2VkX3RvZGF5IiwiZ2V0Q2FzZVRyZW5kcyIsImRheXMiLCJfYWdncyRjYXNlc19vdmVyX3RpbWUiLCJfYWdncyRjbG9zZWRfb3Zlcl90aW0iLCJmcm9tRGF0ZSIsInNldERhdGUiLCJnZXREYXRlIiwiY2FzZXNfb3Zlcl90aW1lIiwiZGF0ZV9oaXN0b2dyYW0iLCJjYWxlbmRhcl9pbnRlcnZhbCIsImNsb3NlZF9vdmVyX3RpbWUiLCJleGlzdHMiLCJieV9kYXkiLCJjcmVhdGVkQnVja2V0cyIsImNsb3NlZEJ1Y2tldHMiLCJjbG9zZWRNYXAiLCJfYiRrZXlfYXNfc3RyaW5nIiwiZGF0ZUtleSIsImtleV9hc19zdHJpbmciLCJfYiRrZXlfYXNfc3RyaW5nMiIsImRhdGUiLCJjcmVhdGVkIiwiY2xvc2VkIiwiaGFuZGxlQXV0b21hdGVkQWxlcnQiLCJfYWxlcnQkcnVsZSIsIl9hbGVydCRhZ2VudCIsIl9hbGVydCRydWxlMiIsIl9hbGVydCRydWxlMyIsIl9hbGVydCRydWxlNCIsIl9hbGVydCRhZ2VudDIiLCJfYWxlcnQkcnVsZTUiLCJfYWxlcnQkcnVsZTYiLCJfYWxlcnQkYWdlbnQzIiwicnVsZUlkIiwicnVsZSIsImFnZW50SWQiLCJhZ2VudCIsIkVycm9yIiwibGlua2VkQWxlcnQiLCJpbmRleCIsIl9pbmRleCIsInBhcnNlSW50IiwicnVsZV9sZXZlbCIsImxldmVsIiwicnVsZV9ncm91cHMiLCJncm91cHMiLCJhZ2VudF9uYW1lIiwibmFtZSIsImZ1bGxfbG9nIiwic2VhcmNoUmVzdWx0IiwiZXhpc3RpbmdDYXNlIiwiYWxyZWFkeUxpbmtlZCIsImF1dG9tYXRlZF9ydWxlX2lkIiwiYXV0b21hdGVkX2FnZW50X2lkIiwiZXhwb3J0cyJdLCJzb3VyY2VzIjpbImNhc2Vfc2VydmljZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogV2F6dWggQ2FzZSBNYW5hZ2VtZW50IFBsdWdpblxuICogQ2FzZSBTZXJ2aWNlIOKAlCBCdXNpbmVzcyBsb2dpYyBmb3IgY2FzZSBtYW5hZ2VtZW50IG9wZXJhdGlvbnNcbiAqXG4gKiBIYW5kbGVzIGNhc2UgSUQgZ2VuZXJhdGlvbiwgQ1JVRCwgc3RhdHVzIHRyYW5zaXRpb25zLCBjb21tZW50cyxcbiAqIGFsZXJ0IGxpbmtpbmcsIG9ic2VydmFibGVzLCBhY3Rpdml0eSBsb2dnaW5nLCBhbmQgYW5hbHl0aWNzLlxuICovXG5cbmltcG9ydCB7IHY0IGFzIHV1aWRWNCB9IGZyb20gJ2NyeXB0byc7XG5pbXBvcnQge1xuICBDYXNlLFxuICBDcmVhdGVDYXNlUGF5bG9hZCxcbiAgVXBkYXRlQ2FzZVBheWxvYWQsXG4gIENhc2VTdGF0dXMsXG4gIENhc2VBY3Rpdml0eSxcbiAgQ2FzZUNvbW1lbnQsXG4gIExpbmtlZEFsZXJ0LFxuICBPYnNlcnZhYmxlLFxuICBBbmFseXRpY3NTdW1tYXJ5LFxuICBDYXNlVHJlbmQsXG4gIENhc2VMaXN0UXVlcnksXG4gIENhc2VMaXN0UmVzcG9uc2UsXG4gIFdhenVoQWxlcnRTZWFyY2hRdWVyeSxcbn0gZnJvbSAnLi4vLi4vY29tbW9uL3R5cGVzJztcbmltcG9ydCB7XG4gIENBU0VfSU5ERVgsXG4gIENBU0VfSURfUFJFRklYLFxuICBDQVNFX0lEX1NFUEFSQVRPUixcbiAgU1RBVFVTX1RSQU5TSVRJT05TLFxuICBXQVpVSF9BTEVSVFNfSU5ERVhfUEFUVEVSTixcbiAgREVGQVVMVF9QQUdFX1NJWkUsXG4gIE1BWF9QQUdFX1NJWkUsXG4gIERFRkFVTFRfU09SVF9GSUVMRCxcbiAgREVGQVVMVF9TT1JUX09SREVSLFxufSBmcm9tICcuLi8uLi9jb21tb24vY29uc3RhbnRzJztcbmltcG9ydCB7IE9wZW5TZWFyY2hTZXJ2aWNlIH0gZnJvbSAnLi9vcGVuc2VhcmNoX3NlcnZpY2UnO1xuXG4vKiogR2VuZXJhdGUgYSBVVUlEIHY0IHdpdGhvdXQgZGFzaGVzIChjb21wYWN0KSAqL1xuZnVuY3Rpb24gdXVpZCgpOiBzdHJpbmcge1xuICAvLyBVc2UgY3J5cHRvLnJhbmRvbVVVSUQgaWYgYXZhaWxhYmxlLCBmYWxsYmFjayB0byBtYW51YWxcbiAgdHJ5IHtcbiAgICByZXR1cm4gY3J5cHRvLnJhbmRvbVVVSUQoKS5yZXBsYWNlKC8tL2csICcnKS5zdWJzdHJpbmcoMCwgMTIpO1xuICB9IGNhdGNoIHtcbiAgICByZXR1cm4gRGF0ZS5ub3coKS50b1N0cmluZygzNikgKyBNYXRoLnJhbmRvbSgpLnRvU3RyaW5nKDM2KS5zdWJzdHJpbmcoMiwgOCk7XG4gIH1cbn1cblxuLyoqXG4gKiBDYXNlU2VydmljZSDigJQgYWxsIGNhc2UgbWFuYWdlbWVudCBidXNpbmVzcyBsb2dpYy5cbiAqIE1ldGhvZHMgYXJlIHN0YXRpYzsgdGhlIE9wZW5TZWFyY2ggY2xpZW50IGlzIHBhc3NlZCBpbiBwZXItcmVxdWVzdC5cbiAqL1xuZXhwb3J0IGNsYXNzIENhc2VTZXJ2aWNlIHtcbiAgLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gIC8vIENhc2UgSUQgR2VuZXJhdGlvblxuICAvLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuICAvKipcbiAgICogR2VuZXJhdGUgdGhlIG5leHQgaHVtYW4tcmVhZGFibGUgY2FzZSBJRC5cbiAgICogRm9ybWF0OiBDQVNFLTIwMjYtMDAwMVxuICAgKi9cbiAgc3RhdGljIGFzeW5jIGdlbmVyYXRlQ2FzZUlkKGNsaWVudDogYW55KTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgICBjb25zdCBjb3VudGVyID0gYXdhaXQgT3BlblNlYXJjaFNlcnZpY2UuZ2V0TmV4dENvdW50ZXJWYWx1ZShjbGllbnQpO1xuICAgIGNvbnN0IHllYXIgPSBuZXcgRGF0ZSgpLmdldEZ1bGxZZWFyKCk7XG4gICAgY29uc3QgcGFkZGVkTnVtID0gU3RyaW5nKGNvdW50ZXIpLnBhZFN0YXJ0KDQsICcwJyk7XG4gICAgcmV0dXJuIGAke0NBU0VfSURfUFJFRklYfSR7Q0FTRV9JRF9TRVBBUkFUT1J9JHt5ZWFyfSR7Q0FTRV9JRF9TRVBBUkFUT1J9JHtwYWRkZWROdW19YDtcbiAgfVxuXG4gIC8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICAvLyBBY3Rpdml0eSBMb2cgSGVscGVyXG4gIC8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG4gIHByaXZhdGUgc3RhdGljIGNyZWF0ZUFjdGl2aXR5KFxuICAgIGFjdGlvbjogQ2FzZUFjdGl2aXR5WydhY3Rpb24nXSxcbiAgICB1c2VyOiBzdHJpbmcsXG4gICAgZGV0YWlscz86IFJlY29yZDxzdHJpbmcsIGFueT4sXG4gICk6IENhc2VBY3Rpdml0eSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIGlkOiB1dWlkKCksXG4gICAgICBhY3Rpb24sXG4gICAgICB1c2VyLFxuICAgICAgdGltZXN0YW1wOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICBkZXRhaWxzLFxuICAgIH07XG4gIH1cblxuICAvLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgLy8gQ2FzZSBDUlVEXG4gIC8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG4gIC8qKiBDcmVhdGUgYSBuZXcgY2FzZSAqL1xuICBzdGF0aWMgYXN5bmMgY3JlYXRlQ2FzZShcbiAgICBjbGllbnQ6IGFueSxcbiAgICBwYXlsb2FkOiBDcmVhdGVDYXNlUGF5bG9hZCxcbiAgICB1c2VyOiBzdHJpbmcsXG4gICk6IFByb21pc2U8Q2FzZT4ge1xuICAgIGNvbnN0IGNhc2VJZCA9IGF3YWl0IENhc2VTZXJ2aWNlLmdlbmVyYXRlQ2FzZUlkKGNsaWVudCk7XG4gICAgY29uc3Qgbm93ID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpO1xuXG4gICAgY29uc3QgbmV3Q2FzZTogQ2FzZSA9IHtcbiAgICAgIGNhc2VfaWQ6IGNhc2VJZCxcbiAgICAgIHRpdGxlOiBwYXlsb2FkLnRpdGxlLFxuICAgICAgZGVzY3JpcHRpb246IHBheWxvYWQuZGVzY3JpcHRpb24sXG4gICAgICBzdGF0dXM6ICdvcGVuJyxcbiAgICAgIHNldmVyaXR5OiBwYXlsb2FkLnNldmVyaXR5LFxuICAgICAgcHJpb3JpdHk6IHBheWxvYWQucHJpb3JpdHksXG4gICAgICBjYXRlZ29yeTogcGF5bG9hZC5jYXRlZ29yeSxcbiAgICAgIHRscDogcGF5bG9hZC50bHAgfHwgJ1dISVRFJyxcbiAgICAgIHRhZ3M6IHBheWxvYWQudGFncyB8fCBbXSxcbiAgICAgIGFzc2lnbmVlOiBwYXlsb2FkLmFzc2lnbmVlIHx8IG51bGwsXG4gICAgICBjcmVhdGVkX2J5OiB1c2VyLFxuICAgICAgY3JlYXRlZF9hdDogbm93LFxuICAgICAgdXBkYXRlZF9hdDogbm93LFxuICAgICAgY2xvc2VkX2F0OiBudWxsLFxuICAgICAgbGlua2VkX2FsZXJ0czogW10sXG4gICAgICBvYnNlcnZhYmxlczogW10sXG4gICAgICBjb21tZW50czogW10sXG4gICAgICB0YXNrczogW10sXG4gICAgICBub3RlczogJycsXG4gICAgICBhY3Rpdml0eV9sb2c6IFtcbiAgICAgICAgQ2FzZVNlcnZpY2UuY3JlYXRlQWN0aXZpdHkoJ2Nhc2VfY3JlYXRlZCcsIHVzZXIsIHtcbiAgICAgICAgICBjYXNlX2lkOiBjYXNlSWQsXG4gICAgICAgICAgdGl0bGU6IHBheWxvYWQudGl0bGUsXG4gICAgICAgIH0pLFxuICAgICAgXSxcbiAgICAgIHJlc29sdXRpb25fc3VtbWFyeTogbnVsbCxcbiAgICAgIHRpbWVfdG9fcmVzb2x2ZV9tczogbnVsbCxcbiAgICAgIHJlbGF0ZWRfY2FzZXM6IFtdLFxuICAgICAgY3VzdG9tX2ZpZWxkczoge30sXG4gICAgfTtcblxuICAgIC8vIElmIGFuIGFzc2lnbmVlIHdhcyBwcm92aWRlZCwgbG9nIHRoZSBhc3NpZ25tZW50XG4gICAgaWYgKHBheWxvYWQuYXNzaWduZWUpIHtcbiAgICAgIG5ld0Nhc2UuYWN0aXZpdHlfbG9nLnB1c2goXG4gICAgICAgIENhc2VTZXJ2aWNlLmNyZWF0ZUFjdGl2aXR5KCdhc3NpZ25lZCcsIHVzZXIsIHsgYXNzaWduZWU6IHBheWxvYWQuYXNzaWduZWUgfSksXG4gICAgICApO1xuICAgIH1cblxuICAgIGNvbnN0IHsgX2lkIH0gPSBhd2FpdCBPcGVuU2VhcmNoU2VydmljZS5jcmVhdGVEb2N1bWVudChjbGllbnQsIENBU0VfSU5ERVgsIG5ld0Nhc2UpO1xuICAgIG5ld0Nhc2UuaWQgPSBfaWQ7XG5cbiAgICByZXR1cm4gbmV3Q2FzZTtcbiAgfVxuXG4gIC8qKiBHZXQgYSBzaW5nbGUgY2FzZSBieSBpdHMgT3BlblNlYXJjaCBfaWQgKi9cbiAgc3RhdGljIGFzeW5jIGdldENhc2UoY2xpZW50OiBhbnksIGlkOiBzdHJpbmcpOiBQcm9taXNlPENhc2UgfCBudWxsPiB7XG4gICAgY29uc3QgZG9jID0gYXdhaXQgT3BlblNlYXJjaFNlcnZpY2UuZ2V0RG9jdW1lbnQoY2xpZW50LCBDQVNFX0lOREVYLCBpZCk7XG4gICAgaWYgKCFkb2MpIHJldHVybiBudWxsO1xuICAgIHJldHVybiB7IGlkOiBkb2MuX2lkLCAuLi5kb2MuX3NvdXJjZSB9IGFzIENhc2U7XG4gIH1cblxuICAvKiogVXBkYXRlIGEgY2FzZSAocGFydGlhbCB1cGRhdGUpICovXG4gIHN0YXRpYyBhc3luYyB1cGRhdGVDYXNlKFxuICAgIGNsaWVudDogYW55LFxuICAgIGlkOiBzdHJpbmcsXG4gICAgcGF5bG9hZDogVXBkYXRlQ2FzZVBheWxvYWQsXG4gICAgdXNlcjogc3RyaW5nLFxuICApOiBQcm9taXNlPENhc2UgfCBudWxsPiB7XG4gICAgY29uc3QgZXhpc3RpbmcgPSBhd2FpdCBDYXNlU2VydmljZS5nZXRDYXNlKGNsaWVudCwgaWQpO1xuICAgIGlmICghZXhpc3RpbmcpIHJldHVybiBudWxsO1xuXG4gICAgY29uc3Qgbm93ID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpO1xuICAgIGNvbnN0IGFjdGl2aXRpZXM6IENhc2VBY3Rpdml0eVtdID0gW107XG4gICAgY29uc3QgdXBkYXRlRG9jOiBhbnkgPSB7IHVwZGF0ZWRfYXQ6IG5vdyB9O1xuXG4gICAgLy8gVHJhY2sgY2hhbmdlcyBmb3IgYWN0aXZpdHkgbG9nXG4gICAgaWYgKHBheWxvYWQudGl0bGUgIT09IHVuZGVmaW5lZCAmJiBwYXlsb2FkLnRpdGxlICE9PSBleGlzdGluZy50aXRsZSkge1xuICAgICAgdXBkYXRlRG9jLnRpdGxlID0gcGF5bG9hZC50aXRsZTtcbiAgICB9XG4gICAgaWYgKHBheWxvYWQuZGVzY3JpcHRpb24gIT09IHVuZGVmaW5lZCkge1xuICAgICAgdXBkYXRlRG9jLmRlc2NyaXB0aW9uID0gcGF5bG9hZC5kZXNjcmlwdGlvbjtcbiAgICB9XG4gICAgaWYgKHBheWxvYWQuc2V2ZXJpdHkgIT09IHVuZGVmaW5lZCAmJiBwYXlsb2FkLnNldmVyaXR5ICE9PSBleGlzdGluZy5zZXZlcml0eSkge1xuICAgICAgdXBkYXRlRG9jLnNldmVyaXR5ID0gcGF5bG9hZC5zZXZlcml0eTtcbiAgICAgIGFjdGl2aXRpZXMucHVzaChcbiAgICAgICAgQ2FzZVNlcnZpY2UuY3JlYXRlQWN0aXZpdHkoJ3NldmVyaXR5X2NoYW5nZWQnLCB1c2VyLCB7XG4gICAgICAgICAgZnJvbTogZXhpc3Rpbmcuc2V2ZXJpdHksXG4gICAgICAgICAgdG86IHBheWxvYWQuc2V2ZXJpdHksXG4gICAgICAgIH0pLFxuICAgICAgKTtcbiAgICB9XG4gICAgaWYgKHBheWxvYWQucHJpb3JpdHkgIT09IHVuZGVmaW5lZCAmJiBwYXlsb2FkLnByaW9yaXR5ICE9PSBleGlzdGluZy5wcmlvcml0eSkge1xuICAgICAgdXBkYXRlRG9jLnByaW9yaXR5ID0gcGF5bG9hZC5wcmlvcml0eTtcbiAgICAgIGFjdGl2aXRpZXMucHVzaChcbiAgICAgICAgQ2FzZVNlcnZpY2UuY3JlYXRlQWN0aXZpdHkoJ3ByaW9yaXR5X2NoYW5nZWQnLCB1c2VyLCB7XG4gICAgICAgICAgZnJvbTogZXhpc3RpbmcucHJpb3JpdHksXG4gICAgICAgICAgdG86IHBheWxvYWQucHJpb3JpdHksXG4gICAgICAgIH0pLFxuICAgICAgKTtcbiAgICB9XG4gICAgaWYgKHBheWxvYWQuY2F0ZWdvcnkgIT09IHVuZGVmaW5lZCkge1xuICAgICAgdXBkYXRlRG9jLmNhdGVnb3J5ID0gcGF5bG9hZC5jYXRlZ29yeTtcbiAgICB9XG4gICAgaWYgKHBheWxvYWQudGxwICE9PSB1bmRlZmluZWQpIHtcbiAgICAgIHVwZGF0ZURvYy50bHAgPSBwYXlsb2FkLnRscDtcbiAgICB9XG4gICAgaWYgKHBheWxvYWQudGFncyAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICB1cGRhdGVEb2MudGFncyA9IHBheWxvYWQudGFncztcbiAgICB9XG4gICAgaWYgKHBheWxvYWQuYXNzaWduZWUgIT09IHVuZGVmaW5lZCAmJiBwYXlsb2FkLmFzc2lnbmVlICE9PSBleGlzdGluZy5hc3NpZ25lZSkge1xuICAgICAgdXBkYXRlRG9jLmFzc2lnbmVlID0gcGF5bG9hZC5hc3NpZ25lZTtcbiAgICAgIGFjdGl2aXRpZXMucHVzaChcbiAgICAgICAgQ2FzZVNlcnZpY2UuY3JlYXRlQWN0aXZpdHkocGF5bG9hZC5hc3NpZ25lZSA/ICdhc3NpZ25lZCcgOiAndW5hc3NpZ25lZCcsIHVzZXIsIHtcbiAgICAgICAgICBmcm9tOiBleGlzdGluZy5hc3NpZ25lZSxcbiAgICAgICAgICB0bzogcGF5bG9hZC5hc3NpZ25lZSxcbiAgICAgICAgfSksXG4gICAgICApO1xuICAgIH1cbiAgICBpZiAocGF5bG9hZC5yZXNvbHV0aW9uX3N1bW1hcnkgIT09IHVuZGVmaW5lZCkge1xuICAgICAgdXBkYXRlRG9jLnJlc29sdXRpb25fc3VtbWFyeSA9IHBheWxvYWQucmVzb2x1dGlvbl9zdW1tYXJ5O1xuICAgIH1cblxuICAgIC8vIEFwcGVuZCBhY3Rpdml0aWVzXG4gICAgaWYgKGFjdGl2aXRpZXMubGVuZ3RoID4gMCkge1xuICAgICAgdXBkYXRlRG9jLmFjdGl2aXR5X2xvZyA9IFsuLi5leGlzdGluZy5hY3Rpdml0eV9sb2csIC4uLmFjdGl2aXRpZXNdO1xuICAgIH1cblxuICAgIGF3YWl0IE9wZW5TZWFyY2hTZXJ2aWNlLnVwZGF0ZURvY3VtZW50KGNsaWVudCwgQ0FTRV9JTkRFWCwgaWQsIHVwZGF0ZURvYyk7XG4gICAgcmV0dXJuIGF3YWl0IENhc2VTZXJ2aWNlLmdldENhc2UoY2xpZW50LCBpZCk7XG4gIH1cblxuICAvKiogRGVsZXRlIGEgY2FzZSBieSBPcGVuU2VhcmNoIF9pZCAqL1xuICBzdGF0aWMgYXN5bmMgZGVsZXRlQ2FzZShjbGllbnQ6IGFueSwgaWQ6IHN0cmluZyk6IFByb21pc2U8Ym9vbGVhbj4ge1xuICAgIHJldHVybiBhd2FpdCBPcGVuU2VhcmNoU2VydmljZS5kZWxldGVEb2N1bWVudChjbGllbnQsIENBU0VfSU5ERVgsIGlkKTtcbiAgfVxuXG4gIC8qKiBMaXN0IGNhc2VzIHdpdGggZmlsdGVyaW5nLCBwYWdpbmF0aW9uLCBhbmQgc29ydGluZyAqL1xuICBzdGF0aWMgYXN5bmMgbGlzdENhc2VzKGNsaWVudDogYW55LCBxdWVyeTogQ2FzZUxpc3RRdWVyeSk6IFByb21pc2U8Q2FzZUxpc3RSZXNwb25zZT4ge1xuICAgIGNvbnN0IHBhZ2UgPSBxdWVyeS5wYWdlIHx8IDE7XG4gICAgY29uc3QgcGVyUGFnZSA9IE1hdGgubWluKHF1ZXJ5LnBlcl9wYWdlIHx8IERFRkFVTFRfUEFHRV9TSVpFLCBNQVhfUEFHRV9TSVpFKTtcbiAgICBjb25zdCBzb3J0RmllbGQgPSBxdWVyeS5zb3J0X2ZpZWxkIHx8IERFRkFVTFRfU09SVF9GSUVMRDtcbiAgICBjb25zdCBzb3J0T3JkZXIgPSBxdWVyeS5zb3J0X29yZGVyIHx8IERFRkFVTFRfU09SVF9PUkRFUjtcblxuICAgIC8vIEJ1aWxkIHRoZSBxdWVyeVxuICAgIGNvbnN0IG11c3Q6IGFueVtdID0gW107XG5cbiAgICBpZiAocXVlcnkuc3RhdHVzKSB7XG4gICAgICBtdXN0LnB1c2goeyB0ZXJtOiB7IHN0YXR1czogcXVlcnkuc3RhdHVzIH0gfSk7XG4gICAgfVxuICAgIGlmIChxdWVyeS5zZXZlcml0eSkge1xuICAgICAgbXVzdC5wdXNoKHsgdGVybTogeyBzZXZlcml0eTogcXVlcnkuc2V2ZXJpdHkgfSB9KTtcbiAgICB9XG4gICAgaWYgKHF1ZXJ5LnByaW9yaXR5KSB7XG4gICAgICBtdXN0LnB1c2goeyB0ZXJtOiB7IHByaW9yaXR5OiBxdWVyeS5wcmlvcml0eSB9IH0pO1xuICAgIH1cbiAgICBpZiAocXVlcnkuY2F0ZWdvcnkpIHtcbiAgICAgIG11c3QucHVzaCh7IHRlcm06IHsgY2F0ZWdvcnk6IHF1ZXJ5LmNhdGVnb3J5IH0gfSk7XG4gICAgfVxuICAgIGlmIChxdWVyeS5hc3NpZ25lZSkge1xuICAgICAgbXVzdC5wdXNoKHsgdGVybTogeyBhc3NpZ25lZTogcXVlcnkuYXNzaWduZWUgfSB9KTtcbiAgICB9XG4gICAgaWYgKHF1ZXJ5LnRhZ3MpIHtcbiAgICAgIGNvbnN0IHRhZ0xpc3QgPSBxdWVyeS50YWdzLnNwbGl0KCcsJykubWFwKCh0KSA9PiB0LnRyaW0oKSk7XG4gICAgICBtdXN0LnB1c2goeyB0ZXJtczogeyB0YWdzOiB0YWdMaXN0IH0gfSk7XG4gICAgfVxuICAgIGlmIChxdWVyeS5zZWFyY2gpIHtcbiAgICAgIG11c3QucHVzaCh7XG4gICAgICAgIG11bHRpX21hdGNoOiB7XG4gICAgICAgICAgcXVlcnk6IHF1ZXJ5LnNlYXJjaCxcbiAgICAgICAgICBmaWVsZHM6IFsndGl0bGVeMycsICdkZXNjcmlwdGlvbicsICdjYXNlX2lkXjInLCAndGFncyddLFxuICAgICAgICAgIHR5cGU6ICdiZXN0X2ZpZWxkcycsXG4gICAgICAgICAgZnV6emluZXNzOiAnQVVUTycsXG4gICAgICAgIH0sXG4gICAgICB9KTtcbiAgICB9XG4gICAgaWYgKHF1ZXJ5LmNyZWF0ZWRfZnJvbSB8fCBxdWVyeS5jcmVhdGVkX3RvKSB7XG4gICAgICBjb25zdCByYW5nZTogYW55ID0ge307XG4gICAgICBpZiAocXVlcnkuY3JlYXRlZF9mcm9tKSByYW5nZS5ndGUgPSBxdWVyeS5jcmVhdGVkX2Zyb207XG4gICAgICBpZiAocXVlcnkuY3JlYXRlZF90bykgcmFuZ2UubHRlID0gcXVlcnkuY3JlYXRlZF90bztcbiAgICAgIG11c3QucHVzaCh7IHJhbmdlOiB7IGNyZWF0ZWRfYXQ6IHJhbmdlIH0gfSk7XG4gICAgfVxuXG4gICAgY29uc3Qgc2VhcmNoQm9keSA9IHtcbiAgICAgIHF1ZXJ5OiBtdXN0Lmxlbmd0aCA+IDAgPyB7IGJvb2w6IHsgbXVzdCB9IH0gOiB7IG1hdGNoX2FsbDoge30gfSxcbiAgICAgIHNvcnQ6IFt7IFtzb3J0RmllbGRdOiB7IG9yZGVyOiBzb3J0T3JkZXIgfSB9XSxcbiAgICAgIGZyb206IChwYWdlIC0gMSkgKiBwZXJQYWdlLFxuICAgICAgc2l6ZTogcGVyUGFnZSxcbiAgICAgIC8vIEV4Y2x1ZGUgaGVhdnkgbmVzdGVkIGZpZWxkcyBmcm9tIGxpc3RpbmcgdG8gaW1wcm92ZSBwZXJmXG4gICAgICBfc291cmNlOiB7XG4gICAgICAgIGV4Y2x1ZGVzOiBbJ2FjdGl2aXR5X2xvZycsICdjb21tZW50cy5jb250ZW50J10sXG4gICAgICB9LFxuICAgIH07XG5cbiAgICBjb25zdCB7IGhpdHMsIHRvdGFsIH0gPSBhd2FpdCBPcGVuU2VhcmNoU2VydmljZS5zZWFyY2hEb2N1bWVudHMoY2xpZW50LCBDQVNFX0lOREVYLCBzZWFyY2hCb2R5KTtcblxuICAgIGNvbnN0IGNhc2VzOiBDYXNlW10gPSBoaXRzLm1hcCgoaGl0OiBhbnkpID0+ICh7XG4gICAgICBpZDogaGl0Ll9pZCxcbiAgICAgIC4uLmhpdC5fc291cmNlLFxuICAgIH0pKTtcblxuICAgIHJldHVybiB7IGNhc2VzLCB0b3RhbCwgcGFnZSwgcGVyX3BhZ2U6IHBlclBhZ2UgfTtcbiAgfVxuXG4gIC8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICAvLyBTdGF0dXMgTWFuYWdlbWVudFxuICAvLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuICAvKiogQ2hhbmdlIGNhc2Ugc3RhdHVzIHdpdGggdHJhbnNpdGlvbiB2YWxpZGF0aW9uICovXG4gIHN0YXRpYyBhc3luYyBjaGFuZ2VTdGF0dXMoXG4gICAgY2xpZW50OiBhbnksXG4gICAgaWQ6IHN0cmluZyxcbiAgICBuZXdTdGF0dXM6IENhc2VTdGF0dXMsXG4gICAgdXNlcjogc3RyaW5nLFxuICApOiBQcm9taXNlPHsgc3VjY2VzczogYm9vbGVhbjsgZXJyb3I/OiBzdHJpbmc7IGNhc2U/OiBDYXNlIH0+IHtcbiAgICBjb25zdCBleGlzdGluZyA9IGF3YWl0IENhc2VTZXJ2aWNlLmdldENhc2UoY2xpZW50LCBpZCk7XG4gICAgaWYgKCFleGlzdGluZykge1xuICAgICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiAnQ2FzZSBub3QgZm91bmQnIH07XG4gICAgfVxuXG4gICAgLy8gVmFsaWRhdGUgdHJhbnNpdGlvblxuICAgIGNvbnN0IGFsbG93ZWRUcmFuc2l0aW9ucyA9IFNUQVRVU19UUkFOU0lUSU9OU1tleGlzdGluZy5zdGF0dXNdIHx8IFtdO1xuICAgIGlmICghYWxsb3dlZFRyYW5zaXRpb25zLmluY2x1ZGVzKG5ld1N0YXR1cykpIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHN1Y2Nlc3M6IGZhbHNlLFxuICAgICAgICBlcnJvcjogYENhbm5vdCB0cmFuc2l0aW9uIGZyb20gJyR7ZXhpc3Rpbmcuc3RhdHVzfScgdG8gJyR7bmV3U3RhdHVzfScuIEFsbG93ZWQ6ICR7YWxsb3dlZFRyYW5zaXRpb25zLmpvaW4oJywgJyl9YCxcbiAgICAgIH07XG4gICAgfVxuXG4gICAgY29uc3Qgbm93ID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpO1xuICAgIGNvbnN0IHVwZGF0ZURvYzogYW55ID0ge1xuICAgICAgc3RhdHVzOiBuZXdTdGF0dXMsXG4gICAgICB1cGRhdGVkX2F0OiBub3csXG4gICAgfTtcblxuICAgIC8vIEhhbmRsZSBjbG9zaW5nXG4gICAgaWYgKG5ld1N0YXR1cyA9PT0gJ2Nsb3NlZCcgfHwgbmV3U3RhdHVzID09PSAncmVzb2x2ZWQnKSB7XG4gICAgICB1cGRhdGVEb2MuY2xvc2VkX2F0ID0gbm93O1xuICAgICAgaWYgKGV4aXN0aW5nLmNyZWF0ZWRfYXQpIHtcbiAgICAgICAgdXBkYXRlRG9jLnRpbWVfdG9fcmVzb2x2ZV9tcyA9IG5ldyBEYXRlKG5vdykuZ2V0VGltZSgpIC0gbmV3IERhdGUoZXhpc3RpbmcuY3JlYXRlZF9hdCkuZ2V0VGltZSgpO1xuICAgICAgfVxuICAgIH1cblxuICAgIC8vIEhhbmRsZSByZW9wZW5pbmdcbiAgICBpZiAobmV3U3RhdHVzID09PSAnb3BlbicgJiYgKGV4aXN0aW5nLnN0YXR1cyA9PT0gJ2Nsb3NlZCcgfHwgZXhpc3Rpbmcuc3RhdHVzID09PSAncmVzb2x2ZWQnKSkge1xuICAgICAgdXBkYXRlRG9jLmNsb3NlZF9hdCA9IG51bGw7XG4gICAgICB1cGRhdGVEb2MudGltZV90b19yZXNvbHZlX21zID0gbnVsbDtcbiAgICB9XG5cbiAgICAvLyBBY3Rpdml0eVxuICAgIGNvbnN0IGFjdGl2aXR5ID0gQ2FzZVNlcnZpY2UuY3JlYXRlQWN0aXZpdHkoXG4gICAgICBuZXdTdGF0dXMgPT09ICdjbG9zZWQnID8gJ2Nhc2VfY2xvc2VkJyA6IG5ld1N0YXR1cyA9PT0gJ29wZW4nICYmIGV4aXN0aW5nLnN0YXR1cyA9PT0gJ2Nsb3NlZCcgPyAnY2FzZV9yZW9wZW5lZCcgOiAnc3RhdHVzX2NoYW5nZWQnLFxuICAgICAgdXNlcixcbiAgICAgIHsgZnJvbTogZXhpc3Rpbmcuc3RhdHVzLCB0bzogbmV3U3RhdHVzIH0sXG4gICAgKTtcbiAgICB1cGRhdGVEb2MuYWN0aXZpdHlfbG9nID0gWy4uLmV4aXN0aW5nLmFjdGl2aXR5X2xvZywgYWN0aXZpdHldO1xuXG4gICAgYXdhaXQgT3BlblNlYXJjaFNlcnZpY2UudXBkYXRlRG9jdW1lbnQoY2xpZW50LCBDQVNFX0lOREVYLCBpZCwgdXBkYXRlRG9jKTtcbiAgICBjb25zdCB1cGRhdGVkQ2FzZSA9IGF3YWl0IENhc2VTZXJ2aWNlLmdldENhc2UoY2xpZW50LCBpZCk7XG4gICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSwgY2FzZTogdXBkYXRlZENhc2UhIH07XG4gIH1cblxuICAvKiogQXNzaWduIGEgY2FzZSB0byBhIHVzZXIgKi9cbiAgc3RhdGljIGFzeW5jIGFzc2lnbkNhc2UoXG4gICAgY2xpZW50OiBhbnksXG4gICAgaWQ6IHN0cmluZyxcbiAgICBhc3NpZ25lZTogc3RyaW5nIHwgbnVsbCxcbiAgICB1c2VyOiBzdHJpbmcsXG4gICk6IFByb21pc2U8Q2FzZSB8IG51bGw+IHtcbiAgICBjb25zdCBleGlzdGluZyA9IGF3YWl0IENhc2VTZXJ2aWNlLmdldENhc2UoY2xpZW50LCBpZCk7XG4gICAgaWYgKCFleGlzdGluZykgcmV0dXJuIG51bGw7XG5cbiAgICBjb25zdCBhY3Rpdml0eSA9IENhc2VTZXJ2aWNlLmNyZWF0ZUFjdGl2aXR5KFxuICAgICAgYXNzaWduZWUgPyAnYXNzaWduZWQnIDogJ3VuYXNzaWduZWQnLFxuICAgICAgdXNlcixcbiAgICAgIHsgZnJvbTogZXhpc3RpbmcuYXNzaWduZWUsIHRvOiBhc3NpZ25lZSB9LFxuICAgICk7XG5cbiAgICBhd2FpdCBPcGVuU2VhcmNoU2VydmljZS51cGRhdGVEb2N1bWVudChjbGllbnQsIENBU0VfSU5ERVgsIGlkLCB7XG4gICAgICBhc3NpZ25lZSxcbiAgICAgIHVwZGF0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgIGFjdGl2aXR5X2xvZzogWy4uLmV4aXN0aW5nLmFjdGl2aXR5X2xvZywgYWN0aXZpdHldLFxuICAgIH0pO1xuXG4gICAgcmV0dXJuIGF3YWl0IENhc2VTZXJ2aWNlLmdldENhc2UoY2xpZW50LCBpZCk7XG4gIH1cblxuICAvLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgLy8gVGFza3NcbiAgLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbiAgLyoqIEFkZCBhIHRhc2sgdG8gYSBjYXNlICovXG4gIHN0YXRpYyBhc3luYyBhZGRUYXNrKGNsaWVudDogYW55LCBjYXNlSWQ6IHN0cmluZywgdGl0bGU6IHN0cmluZywgdXNlcjogc3RyaW5nKTogUHJvbWlzZTxDYXNlIHwgbnVsbD4ge1xuICAgIGNvbnN0IGV4aXN0aW5nID0gYXdhaXQgQ2FzZVNlcnZpY2UuZ2V0Q2FzZShjbGllbnQsIGNhc2VJZCk7XG4gICAgaWYgKCFleGlzdGluZykgcmV0dXJuIG51bGw7XG5cbiAgICBjb25zdCBuZXdUYXNrID0ge1xuICAgICAgdGFza19pZDogdXVpZCgpLFxuICAgICAgdGl0bGUsXG4gICAgICBjb21wbGV0ZWQ6IGZhbHNlLFxuICAgICAgY3JlYXRlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIH07XG5cbiAgICBjb25zdCB1cGRhdGVEb2MgPSB7XG4gICAgICB0YXNrczogWy4uLihleGlzdGluZy50YXNrcyB8fCBbXSksIG5ld1Rhc2tdLFxuICAgICAgdXBkYXRlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIH07XG5cbiAgICBhd2FpdCBPcGVuU2VhcmNoU2VydmljZS51cGRhdGVEb2N1bWVudChjbGllbnQsIENBU0VfSU5ERVgsIGNhc2VJZCwgdXBkYXRlRG9jKTtcbiAgICByZXR1cm4gYXdhaXQgQ2FzZVNlcnZpY2UuZ2V0Q2FzZShjbGllbnQsIGNhc2VJZCk7XG4gIH1cblxuICAvKiogVG9nZ2xlIHRhc2sgY29tcGxldGlvbiAqL1xuICBzdGF0aWMgYXN5bmMgdG9nZ2xlVGFzayhjbGllbnQ6IGFueSwgY2FzZUlkOiBzdHJpbmcsIHRhc2tJZDogc3RyaW5nLCBjb21wbGV0ZWQ6IGJvb2xlYW4sIHVzZXI6IHN0cmluZyk6IFByb21pc2U8Q2FzZSB8IG51bGw+IHtcbiAgICBjb25zdCBleGlzdGluZyA9IGF3YWl0IENhc2VTZXJ2aWNlLmdldENhc2UoY2xpZW50LCBjYXNlSWQpO1xuICAgIGlmICghZXhpc3RpbmcpIHJldHVybiBudWxsO1xuXG4gICAgY29uc3QgdGFza3MgPSAoZXhpc3RpbmcudGFza3MgfHwgW10pLm1hcCgodDogYW55KSA9PlxuICAgICAgdC50YXNrX2lkID09PSB0YXNrSWQgPyB7IC4uLnQsIGNvbXBsZXRlZCwgY29tcGxldGVkX2F0OiBjb21wbGV0ZWQgPyBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkgOiB1bmRlZmluZWQgfSA6IHRcbiAgICApO1xuXG4gICAgY29uc3QgdXBkYXRlRG9jID0ge1xuICAgICAgdGFza3MsXG4gICAgICB1cGRhdGVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgfTtcblxuICAgIGF3YWl0IE9wZW5TZWFyY2hTZXJ2aWNlLnVwZGF0ZURvY3VtZW50KGNsaWVudCwgQ0FTRV9JTkRFWCwgY2FzZUlkLCB1cGRhdGVEb2MpO1xuICAgIHJldHVybiBhd2FpdCBDYXNlU2VydmljZS5nZXRDYXNlKGNsaWVudCwgY2FzZUlkKTtcbiAgfVxuXG4gIC8qKiBSZW1vdmUgYSB0YXNrICovXG4gIHN0YXRpYyBhc3luYyByZW1vdmVUYXNrKGNsaWVudDogYW55LCBjYXNlSWQ6IHN0cmluZywgdGFza0lkOiBzdHJpbmcsIHVzZXI6IHN0cmluZyk6IFByb21pc2U8Q2FzZSB8IG51bGw+IHtcbiAgICBjb25zdCBleGlzdGluZyA9IGF3YWl0IENhc2VTZXJ2aWNlLmdldENhc2UoY2xpZW50LCBjYXNlSWQpO1xuICAgIGlmICghZXhpc3RpbmcpIHJldHVybiBudWxsO1xuXG4gICAgY29uc3QgdGFza3MgPSAoZXhpc3RpbmcudGFza3MgfHwgW10pLmZpbHRlcigodDogYW55KSA9PiB0LnRhc2tfaWQgIT09IHRhc2tJZCk7XG5cbiAgICBjb25zdCB1cGRhdGVEb2MgPSB7XG4gICAgICB0YXNrcyxcbiAgICAgIHVwZGF0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICB9O1xuXG4gICAgYXdhaXQgT3BlblNlYXJjaFNlcnZpY2UudXBkYXRlRG9jdW1lbnQoY2xpZW50LCBDQVNFX0lOREVYLCBjYXNlSWQsIHVwZGF0ZURvYyk7XG4gICAgcmV0dXJuIGF3YWl0IENhc2VTZXJ2aWNlLmdldENhc2UoY2xpZW50LCBjYXNlSWQpO1xuICB9XG5cbiAgLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gIC8vIE5vdGVzXG4gIC8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG4gIC8qKiBVcGRhdGUgY2FzZSBub3RlcyAqL1xuICBzdGF0aWMgYXN5bmMgdXBkYXRlTm90ZXMoY2xpZW50OiBhbnksIGNhc2VJZDogc3RyaW5nLCBub3Rlczogc3RyaW5nLCB1c2VyOiBzdHJpbmcpOiBQcm9taXNlPENhc2UgfCBudWxsPiB7XG4gICAgY29uc3QgZXhpc3RpbmcgPSBhd2FpdCBDYXNlU2VydmljZS5nZXRDYXNlKGNsaWVudCwgY2FzZUlkKTtcbiAgICBpZiAoIWV4aXN0aW5nKSByZXR1cm4gbnVsbDtcblxuICAgIGNvbnN0IHVwZGF0ZURvYyA9IHtcbiAgICAgIG5vdGVzLFxuICAgICAgdXBkYXRlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIH07XG5cbiAgICBhd2FpdCBPcGVuU2VhcmNoU2VydmljZS51cGRhdGVEb2N1bWVudChjbGllbnQsIENBU0VfSU5ERVgsIGNhc2VJZCwgdXBkYXRlRG9jKTtcbiAgICByZXR1cm4gYXdhaXQgQ2FzZVNlcnZpY2UuZ2V0Q2FzZShjbGllbnQsIGNhc2VJZCk7XG4gIH1cblxuICAvLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgLy8gQ29tbWVudHNcbiAgLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbiAgLyoqIEFkZCBhIGNvbW1lbnQgdG8gYSBjYXNlICovXG4gIHN0YXRpYyBhc3luYyBhZGRDb21tZW50KFxuICAgIGNsaWVudDogYW55LFxuICAgIGNhc2VJZDogc3RyaW5nLFxuICAgIGNvbnRlbnQ6IHN0cmluZyxcbiAgICB1c2VyOiBzdHJpbmcsXG4gICk6IFByb21pc2U8Q2FzZSB8IG51bGw+IHtcbiAgICBjb25zdCBleGlzdGluZyA9IGF3YWl0IENhc2VTZXJ2aWNlLmdldENhc2UoY2xpZW50LCBjYXNlSWQpO1xuICAgIGlmICghZXhpc3RpbmcpIHJldHVybiBudWxsO1xuXG4gICAgY29uc3QgY29tbWVudDogQ2FzZUNvbW1lbnQgPSB7XG4gICAgICBjb21tZW50X2lkOiB1dWlkKCksXG4gICAgICBhdXRob3I6IHVzZXIsXG4gICAgICBjb250ZW50LFxuICAgICAgY3JlYXRlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIH07XG5cbiAgICBjb25zdCBhY3Rpdml0eSA9IENhc2VTZXJ2aWNlLmNyZWF0ZUFjdGl2aXR5KCdjb21tZW50X2FkZGVkJywgdXNlciwge1xuICAgICAgY29tbWVudF9pZDogY29tbWVudC5jb21tZW50X2lkLFxuICAgIH0pO1xuXG4gICAgYXdhaXQgT3BlblNlYXJjaFNlcnZpY2UudXBkYXRlRG9jdW1lbnQoY2xpZW50LCBDQVNFX0lOREVYLCBjYXNlSWQsIHtcbiAgICAgIGNvbW1lbnRzOiBbLi4uZXhpc3RpbmcuY29tbWVudHMsIGNvbW1lbnRdLFxuICAgICAgYWN0aXZpdHlfbG9nOiBbLi4uZXhpc3RpbmcuYWN0aXZpdHlfbG9nLCBhY3Rpdml0eV0sXG4gICAgICB1cGRhdGVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgfSk7XG5cbiAgICByZXR1cm4gYXdhaXQgQ2FzZVNlcnZpY2UuZ2V0Q2FzZShjbGllbnQsIGNhc2VJZCk7XG4gIH1cblxuICAvKiogRGVsZXRlIGEgY29tbWVudCBmcm9tIGEgY2FzZSAqL1xuICBzdGF0aWMgYXN5bmMgZGVsZXRlQ29tbWVudChcbiAgICBjbGllbnQ6IGFueSxcbiAgICBjYXNlSWQ6IHN0cmluZyxcbiAgICBjb21tZW50SWQ6IHN0cmluZyxcbiAgICB1c2VyOiBzdHJpbmcsXG4gICk6IFByb21pc2U8Q2FzZSB8IG51bGw+IHtcbiAgICBjb25zdCBleGlzdGluZyA9IGF3YWl0IENhc2VTZXJ2aWNlLmdldENhc2UoY2xpZW50LCBjYXNlSWQpO1xuICAgIGlmICghZXhpc3RpbmcpIHJldHVybiBudWxsO1xuXG4gICAgY29uc3QgdXBkYXRlZENvbW1lbnRzID0gZXhpc3RpbmcuY29tbWVudHMuZmlsdGVyKChjKSA9PiBjLmNvbW1lbnRfaWQgIT09IGNvbW1lbnRJZCk7XG4gICAgaWYgKHVwZGF0ZWRDb21tZW50cy5sZW5ndGggPT09IGV4aXN0aW5nLmNvbW1lbnRzLmxlbmd0aCkge1xuICAgICAgcmV0dXJuIGV4aXN0aW5nOyAvLyBDb21tZW50IG5vdCBmb3VuZCwgbm8gY2hhbmdlXG4gICAgfVxuXG4gICAgY29uc3QgYWN0aXZpdHkgPSBDYXNlU2VydmljZS5jcmVhdGVBY3Rpdml0eSgnY29tbWVudF9kZWxldGVkJywgdXNlciwge1xuICAgICAgY29tbWVudF9pZDogY29tbWVudElkLFxuICAgIH0pO1xuXG4gICAgYXdhaXQgT3BlblNlYXJjaFNlcnZpY2UudXBkYXRlRG9jdW1lbnQoY2xpZW50LCBDQVNFX0lOREVYLCBjYXNlSWQsIHtcbiAgICAgIGNvbW1lbnRzOiB1cGRhdGVkQ29tbWVudHMsXG4gICAgICBhY3Rpdml0eV9sb2c6IFsuLi5leGlzdGluZy5hY3Rpdml0eV9sb2csIGFjdGl2aXR5XSxcbiAgICAgIHVwZGF0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICB9KTtcblxuICAgIHJldHVybiBhd2FpdCBDYXNlU2VydmljZS5nZXRDYXNlKGNsaWVudCwgY2FzZUlkKTtcbiAgfVxuXG4gIC8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICAvLyBBbGVydCBMaW5raW5nXG4gIC8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG4gIC8qKiBMaW5rIGFuIGFsZXJ0IHRvIGEgY2FzZSAqL1xuICBzdGF0aWMgYXN5bmMgbGlua0FsZXJ0KFxuICAgIGNsaWVudDogYW55LFxuICAgIGNhc2VJZDogc3RyaW5nLFxuICAgIGFsZXJ0OiBMaW5rZWRBbGVydCxcbiAgICB1c2VyOiBzdHJpbmcsXG4gICk6IFByb21pc2U8Q2FzZSB8IG51bGw+IHtcbiAgICBjb25zdCBleGlzdGluZyA9IGF3YWl0IENhc2VTZXJ2aWNlLmdldENhc2UoY2xpZW50LCBjYXNlSWQpO1xuICAgIGlmICghZXhpc3RpbmcpIHJldHVybiBudWxsO1xuXG4gICAgLy8gQ2hlY2sgZm9yIGR1cGxpY2F0ZVxuICAgIGlmIChleGlzdGluZy5saW5rZWRfYWxlcnRzLnNvbWUoKGEpID0+IGEuYWxlcnRfaWQgPT09IGFsZXJ0LmFsZXJ0X2lkKSkge1xuICAgICAgcmV0dXJuIGV4aXN0aW5nOyAvLyBBbHJlYWR5IGxpbmtlZFxuICAgIH1cblxuICAgIGNvbnN0IGFjdGl2aXR5ID0gQ2FzZVNlcnZpY2UuY3JlYXRlQWN0aXZpdHkoJ2FsZXJ0X2xpbmtlZCcsIHVzZXIsIHtcbiAgICAgIGFsZXJ0X2lkOiBhbGVydC5hbGVydF9pZCxcbiAgICAgIHJ1bGVfZGVzY3JpcHRpb246IGFsZXJ0LnJ1bGVfZGVzY3JpcHRpb24sXG4gICAgfSk7XG5cbiAgICBhd2FpdCBPcGVuU2VhcmNoU2VydmljZS51cGRhdGVEb2N1bWVudChjbGllbnQsIENBU0VfSU5ERVgsIGNhc2VJZCwge1xuICAgICAgbGlua2VkX2FsZXJ0czogWy4uLmV4aXN0aW5nLmxpbmtlZF9hbGVydHMsIGFsZXJ0XSxcbiAgICAgIGFjdGl2aXR5X2xvZzogWy4uLmV4aXN0aW5nLmFjdGl2aXR5X2xvZywgYWN0aXZpdHldLFxuICAgICAgdXBkYXRlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIH0pO1xuXG4gICAgcmV0dXJuIGF3YWl0IENhc2VTZXJ2aWNlLmdldENhc2UoY2xpZW50LCBjYXNlSWQpO1xuICB9XG5cbiAgLyoqIFVubGluayBhbiBhbGVydCBmcm9tIGEgY2FzZSAqL1xuICBzdGF0aWMgYXN5bmMgdW5saW5rQWxlcnQoXG4gICAgY2xpZW50OiBhbnksXG4gICAgY2FzZUlkOiBzdHJpbmcsXG4gICAgYWxlcnRJZDogc3RyaW5nLFxuICAgIHVzZXI6IHN0cmluZyxcbiAgKTogUHJvbWlzZTxDYXNlIHwgbnVsbD4ge1xuICAgIGNvbnN0IGV4aXN0aW5nID0gYXdhaXQgQ2FzZVNlcnZpY2UuZ2V0Q2FzZShjbGllbnQsIGNhc2VJZCk7XG4gICAgaWYgKCFleGlzdGluZykgcmV0dXJuIG51bGw7XG5cbiAgICBjb25zdCB1cGRhdGVkQWxlcnRzID0gZXhpc3RpbmcubGlua2VkX2FsZXJ0cy5maWx0ZXIoKGEpID0+IGEuYWxlcnRfaWQgIT09IGFsZXJ0SWQpO1xuICAgIGNvbnN0IGFjdGl2aXR5ID0gQ2FzZVNlcnZpY2UuY3JlYXRlQWN0aXZpdHkoJ2FsZXJ0X3VubGlua2VkJywgdXNlciwgeyBhbGVydF9pZDogYWxlcnRJZCB9KTtcblxuICAgIGF3YWl0IE9wZW5TZWFyY2hTZXJ2aWNlLnVwZGF0ZURvY3VtZW50KGNsaWVudCwgQ0FTRV9JTkRFWCwgY2FzZUlkLCB7XG4gICAgICBsaW5rZWRfYWxlcnRzOiB1cGRhdGVkQWxlcnRzLFxuICAgICAgYWN0aXZpdHlfbG9nOiBbLi4uZXhpc3RpbmcuYWN0aXZpdHlfbG9nLCBhY3Rpdml0eV0sXG4gICAgICB1cGRhdGVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgfSk7XG5cbiAgICByZXR1cm4gYXdhaXQgQ2FzZVNlcnZpY2UuZ2V0Q2FzZShjbGllbnQsIGNhc2VJZCk7XG4gIH1cblxuICAvKiogU2VhcmNoIFdhenVoIGFsZXJ0cyBpbiBPcGVuU2VhcmNoICovXG4gIHN0YXRpYyBhc3luYyBzZWFyY2hBbGVydHMoXG4gICAgY2xpZW50OiBhbnksXG4gICAgcXVlcnk6IFdhenVoQWxlcnRTZWFyY2hRdWVyeSxcbiAgKTogUHJvbWlzZTx7IGhpdHM6IGFueVtdOyB0b3RhbDogbnVtYmVyIH0+IHtcbiAgICBjb25zdCBtdXN0OiBhbnlbXSA9IFtdO1xuXG4gICAgaWYgKHF1ZXJ5LnNlYXJjaCkge1xuICAgICAgbXVzdC5wdXNoKHtcbiAgICAgICAgbXVsdGlfbWF0Y2g6IHtcbiAgICAgICAgICBxdWVyeTogcXVlcnkuc2VhcmNoLFxuICAgICAgICAgIGZpZWxkczogWydydWxlLmRlc2NyaXB0aW9uXjInLCAnZnVsbF9sb2cnLCAnZGF0YS4qJ10sXG4gICAgICAgICAgZnV6emluZXNzOiAnQVVUTycsXG4gICAgICAgIH0sXG4gICAgICB9KTtcbiAgICB9XG4gICAgaWYgKHF1ZXJ5LmFnZW50X2lkKSB7XG4gICAgICBtdXN0LnB1c2goeyB0ZXJtOiB7ICdhZ2VudC5pZCc6IHF1ZXJ5LmFnZW50X2lkIH0gfSk7XG4gICAgfVxuICAgIGlmIChxdWVyeS5ydWxlX2lkKSB7XG4gICAgICBtdXN0LnB1c2goeyB0ZXJtOiB7ICdydWxlLmlkJzogU3RyaW5nKHF1ZXJ5LnJ1bGVfaWQpIH0gfSk7XG4gICAgfVxuICAgIGlmIChxdWVyeS5sZXZlbF9taW4gfHwgcXVlcnkubGV2ZWxfbWF4KSB7XG4gICAgICBjb25zdCByYW5nZTogYW55ID0ge307XG4gICAgICBpZiAocXVlcnkubGV2ZWxfbWluKSByYW5nZS5ndGUgPSBxdWVyeS5sZXZlbF9taW47XG4gICAgICBpZiAocXVlcnkubGV2ZWxfbWF4KSByYW5nZS5sdGUgPSBxdWVyeS5sZXZlbF9tYXg7XG4gICAgICBtdXN0LnB1c2goeyByYW5nZTogeyAncnVsZS5sZXZlbCc6IHJhbmdlIH0gfSk7XG4gICAgfVxuICAgIGlmIChxdWVyeS5mcm9tIHx8IHF1ZXJ5LnRvKSB7XG4gICAgICBjb25zdCByYW5nZTogYW55ID0ge307XG4gICAgICBpZiAocXVlcnkuZnJvbSkgcmFuZ2UuZ3RlID0gcXVlcnkuZnJvbTtcbiAgICAgIGlmIChxdWVyeS50bykgcmFuZ2UubHRlID0gcXVlcnkudG87XG4gICAgICBtdXN0LnB1c2goeyByYW5nZTogeyB0aW1lc3RhbXA6IHJhbmdlIH0gfSk7XG4gICAgfVxuXG4gICAgY29uc3Qgc2VhcmNoQm9keSA9IHtcbiAgICAgIHF1ZXJ5OiBtdXN0Lmxlbmd0aCA+IDAgPyB7IGJvb2w6IHsgbXVzdCB9IH0gOiB7IG1hdGNoX2FsbDoge30gfSxcbiAgICAgIHNvcnQ6IFt7IHRpbWVzdGFtcDogeyBvcmRlcjogJ2Rlc2MnIH0gfV0sXG4gICAgICBzaXplOiBNYXRoLm1pbihxdWVyeS5zaXplIHx8IDUwLCAxMDApLFxuICAgIH07XG5cbiAgICByZXR1cm4gYXdhaXQgT3BlblNlYXJjaFNlcnZpY2Uuc2VhcmNoRG9jdW1lbnRzKGNsaWVudCwgV0FaVUhfQUxFUlRTX0lOREVYX1BBVFRFUk4sIHNlYXJjaEJvZHkpO1xuICB9XG5cbiAgLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gIC8vIE9ic2VydmFibGVzXG4gIC8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG4gIC8qKiBBZGQgYW4gb2JzZXJ2YWJsZSB0byBhIGNhc2UgKi9cbiAgc3RhdGljIGFzeW5jIGFkZE9ic2VydmFibGUoXG4gICAgY2xpZW50OiBhbnksXG4gICAgY2FzZUlkOiBzdHJpbmcsXG4gICAgb2JzZXJ2YWJsZTogT21pdDxPYnNlcnZhYmxlLCAnaWQnIHwgJ2FkZGVkX2F0JyB8ICdhZGRlZF9ieSc+LFxuICAgIHVzZXI6IHN0cmluZyxcbiAgKTogUHJvbWlzZTxDYXNlIHwgbnVsbD4ge1xuICAgIGNvbnN0IGV4aXN0aW5nID0gYXdhaXQgQ2FzZVNlcnZpY2UuZ2V0Q2FzZShjbGllbnQsIGNhc2VJZCk7XG4gICAgaWYgKCFleGlzdGluZykgcmV0dXJuIG51bGw7XG5cbiAgICBjb25zdCBuZXdPYnNlcnZhYmxlOiBPYnNlcnZhYmxlID0ge1xuICAgICAgLi4ub2JzZXJ2YWJsZSxcbiAgICAgIGlkOiB1dWlkKCksXG4gICAgICBhZGRlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgYWRkZWRfYnk6IHVzZXIsXG4gICAgfTtcblxuICAgIGNvbnN0IGFjdGl2aXR5ID0gQ2FzZVNlcnZpY2UuY3JlYXRlQWN0aXZpdHkoJ29ic2VydmFibGVfYWRkZWQnLCB1c2VyLCB7XG4gICAgICB0eXBlOiBvYnNlcnZhYmxlLnR5cGUsXG4gICAgICB2YWx1ZTogb2JzZXJ2YWJsZS52YWx1ZSxcbiAgICB9KTtcblxuICAgIGF3YWl0IE9wZW5TZWFyY2hTZXJ2aWNlLnVwZGF0ZURvY3VtZW50KGNsaWVudCwgQ0FTRV9JTkRFWCwgY2FzZUlkLCB7XG4gICAgICBvYnNlcnZhYmxlczogWy4uLmV4aXN0aW5nLm9ic2VydmFibGVzLCBuZXdPYnNlcnZhYmxlXSxcbiAgICAgIGFjdGl2aXR5X2xvZzogWy4uLmV4aXN0aW5nLmFjdGl2aXR5X2xvZywgYWN0aXZpdHldLFxuICAgICAgdXBkYXRlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIH0pO1xuXG4gICAgcmV0dXJuIGF3YWl0IENhc2VTZXJ2aWNlLmdldENhc2UoY2xpZW50LCBjYXNlSWQpO1xuICB9XG5cbiAgLyoqIFJlbW92ZSBhbiBvYnNlcnZhYmxlIGZyb20gYSBjYXNlICovXG4gIHN0YXRpYyBhc3luYyByZW1vdmVPYnNlcnZhYmxlKFxuICAgIGNsaWVudDogYW55LFxuICAgIGNhc2VJZDogc3RyaW5nLFxuICAgIG9ic2VydmFibGVJZDogc3RyaW5nLFxuICAgIHVzZXI6IHN0cmluZyxcbiAgKTogUHJvbWlzZTxDYXNlIHwgbnVsbD4ge1xuICAgIGNvbnN0IGV4aXN0aW5nID0gYXdhaXQgQ2FzZVNlcnZpY2UuZ2V0Q2FzZShjbGllbnQsIGNhc2VJZCk7XG4gICAgaWYgKCFleGlzdGluZykgcmV0dXJuIG51bGw7XG5cbiAgICBjb25zdCB1cGRhdGVkID0gZXhpc3Rpbmcub2JzZXJ2YWJsZXMuZmlsdGVyKChvKSA9PiBvLmlkICE9PSBvYnNlcnZhYmxlSWQpO1xuICAgIGNvbnN0IGFjdGl2aXR5ID0gQ2FzZVNlcnZpY2UuY3JlYXRlQWN0aXZpdHkoJ29ic2VydmFibGVfcmVtb3ZlZCcsIHVzZXIsIHtcbiAgICAgIG9ic2VydmFibGVfaWQ6IG9ic2VydmFibGVJZCxcbiAgICB9KTtcblxuICAgIGF3YWl0IE9wZW5TZWFyY2hTZXJ2aWNlLnVwZGF0ZURvY3VtZW50KGNsaWVudCwgQ0FTRV9JTkRFWCwgY2FzZUlkLCB7XG4gICAgICBvYnNlcnZhYmxlczogdXBkYXRlZCxcbiAgICAgIGFjdGl2aXR5X2xvZzogWy4uLmV4aXN0aW5nLmFjdGl2aXR5X2xvZywgYWN0aXZpdHldLFxuICAgICAgdXBkYXRlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIH0pO1xuXG4gICAgcmV0dXJuIGF3YWl0IENhc2VTZXJ2aWNlLmdldENhc2UoY2xpZW50LCBjYXNlSWQpO1xuICB9XG5cbiAgLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gIC8vIEFuYWx5dGljc1xuICAvLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuICAvKiogR2V0IHN1bW1hcnkgYW5hbHl0aWNzIGZvciB0aGUgZGFzaGJvYXJkICovXG4gIHN0YXRpYyBhc3luYyBnZXRBbmFseXRpY3NTdW1tYXJ5KGNsaWVudDogYW55KTogUHJvbWlzZTxBbmFseXRpY3NTdW1tYXJ5PiB7XG4gICAgY29uc3QgdG9kYXkgPSBuZXcgRGF0ZSgpO1xuICAgIHRvZGF5LnNldEhvdXJzKDAsIDAsIDAsIDApO1xuICAgIGNvbnN0IHRvZGF5U3RyID0gdG9kYXkudG9JU09TdHJpbmcoKTtcblxuICAgIGNvbnN0IGFnZ3MgPSBhd2FpdCBPcGVuU2VhcmNoU2VydmljZS5hZ2dyZWdhdGVEb2N1bWVudHMoY2xpZW50LCBDQVNFX0lOREVYLCB7XG4gICAgICBhZ2dzOiB7XG4gICAgICAgIGJ5X3N0YXR1czogeyB0ZXJtczogeyBmaWVsZDogJ3N0YXR1cycsIHNpemU6IDEwIH0gfSxcbiAgICAgICAgYnlfc2V2ZXJpdHk6IHsgdGVybXM6IHsgZmllbGQ6ICdzZXZlcml0eScsIHNpemU6IDEwIH0gfSxcbiAgICAgICAgYnlfcHJpb3JpdHk6IHsgdGVybXM6IHsgZmllbGQ6ICdwcmlvcml0eScsIHNpemU6IDEwIH0gfSxcbiAgICAgICAgYnlfY2F0ZWdvcnk6IHsgdGVybXM6IHsgZmllbGQ6ICdjYXRlZ29yeScsIHNpemU6IDIwIH0gfSxcbiAgICAgICAgYXZnX3Jlc29sdXRpb25fdGltZTogeyBhdmc6IHsgZmllbGQ6ICd0aW1lX3RvX3Jlc29sdmVfbXMnIH0gfSxcbiAgICAgICAgY3JlYXRlZF90b2RheToge1xuICAgICAgICAgIGZpbHRlcjogeyByYW5nZTogeyBjcmVhdGVkX2F0OiB7IGd0ZTogdG9kYXlTdHIgfSB9IH0sXG4gICAgICAgIH0sXG4gICAgICAgIGNsb3NlZF90b2RheToge1xuICAgICAgICAgIGZpbHRlcjoge1xuICAgICAgICAgICAgYm9vbDoge1xuICAgICAgICAgICAgICBtdXN0OiBbXG4gICAgICAgICAgICAgICAgeyByYW5nZTogeyBjbG9zZWRfYXQ6IHsgZ3RlOiB0b2RheVN0ciB9IH0gfSxcbiAgICAgICAgICAgICAgICB7IHRlcm1zOiB7IHN0YXR1czogWydyZXNvbHZlZCcsICdjbG9zZWQnXSB9IH0sXG4gICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICAgIHRvdGFsOiB7IHZhbHVlX2NvdW50OiB7IGZpZWxkOiAnY2FzZV9pZCcgfSB9LFxuICAgICAgfSxcbiAgICB9KTtcblxuICAgIC8vIFBhcnNlIHN0YXR1cyBjb3VudHNcbiAgICBjb25zdCBzdGF0dXNDb3VudHM6IFJlY29yZDxzdHJpbmcsIG51bWJlcj4gPSB7fTtcbiAgICAoYWdncy5ieV9zdGF0dXM/LmJ1Y2tldHMgfHwgW10pLmZvckVhY2goKGI6IGFueSkgPT4ge1xuICAgICAgc3RhdHVzQ291bnRzW2Iua2V5XSA9IGIuZG9jX2NvdW50O1xuICAgIH0pO1xuXG4gICAgLy8gUGFyc2Ugc2V2ZXJpdHkgY291bnRzXG4gICAgY29uc3Qgc2V2ZXJpdHlDb3VudHM6IFJlY29yZDxzdHJpbmcsIG51bWJlcj4gPSB7fTtcbiAgICAoYWdncy5ieV9zZXZlcml0eT8uYnVja2V0cyB8fCBbXSkuZm9yRWFjaCgoYjogYW55KSA9PiB7XG4gICAgICBzZXZlcml0eUNvdW50c1tiLmtleV0gPSBiLmRvY19jb3VudDtcbiAgICB9KTtcblxuICAgIC8vIFBhcnNlIHByaW9yaXR5IGNvdW50c1xuICAgIGNvbnN0IHByaW9yaXR5Q291bnRzOiBSZWNvcmQ8c3RyaW5nLCBudW1iZXI+ID0ge307XG4gICAgKGFnZ3MuYnlfcHJpb3JpdHk/LmJ1Y2tldHMgfHwgW10pLmZvckVhY2goKGI6IGFueSkgPT4ge1xuICAgICAgcHJpb3JpdHlDb3VudHNbYi5rZXldID0gYi5kb2NfY291bnQ7XG4gICAgfSk7XG5cbiAgICAvLyBQYXJzZSBjYXRlZ29yeSBjb3VudHNcbiAgICBjb25zdCBjYXRlZ29yeUNvdW50czogUmVjb3JkPHN0cmluZywgbnVtYmVyPiA9IHt9O1xuICAgIChhZ2dzLmJ5X2NhdGVnb3J5Py5idWNrZXRzIHx8IFtdKS5mb3JFYWNoKChiOiBhbnkpID0+IHtcbiAgICAgIGNhdGVnb3J5Q291bnRzW2Iua2V5XSA9IGIuZG9jX2NvdW50O1xuICAgIH0pO1xuXG4gICAgY29uc3QgdG90YWxDYXNlcyA9IGFnZ3MudG90YWw/LnZhbHVlIHx8IDA7XG5cbiAgICByZXR1cm4ge1xuICAgICAgdG90YWxfY2FzZXM6IHRvdGFsQ2FzZXMsXG4gICAgICBvcGVuX2Nhc2VzOiBzdGF0dXNDb3VudHNbJ29wZW4nXSB8fCAwLFxuICAgICAgaW5fcHJvZ3Jlc3NfY2FzZXM6IHN0YXR1c0NvdW50c1snaW5fcHJvZ3Jlc3MnXSB8fCAwLFxuICAgICAgd2FpdGluZ19jYXNlczogc3RhdHVzQ291bnRzWyd3YWl0aW5nJ10gfHwgMCxcbiAgICAgIHJlc29sdmVkX2Nhc2VzOiBzdGF0dXNDb3VudHNbJ3Jlc29sdmVkJ10gfHwgMCxcbiAgICAgIGNsb3NlZF9jYXNlczogc3RhdHVzQ291bnRzWydjbG9zZWQnXSB8fCAwLFxuICAgICAgYnlfc2V2ZXJpdHk6IHNldmVyaXR5Q291bnRzIGFzIGFueSxcbiAgICAgIGJ5X3ByaW9yaXR5OiBwcmlvcml0eUNvdW50cyBhcyBhbnksXG4gICAgICBieV9jYXRlZ29yeTogY2F0ZWdvcnlDb3VudHMsXG4gICAgICBhdmdfcmVzb2x1dGlvbl90aW1lX21zOiBhZ2dzLmF2Z19yZXNvbHV0aW9uX3RpbWU/LnZhbHVlIHx8IG51bGwsXG4gICAgICBjYXNlc19jcmVhdGVkX3RvZGF5OiBhZ2dzLmNyZWF0ZWRfdG9kYXk/LmRvY19jb3VudCB8fCAwLFxuICAgICAgY2FzZXNfY2xvc2VkX3RvZGF5OiBhZ2dzLmNsb3NlZF90b2RheT8uZG9jX2NvdW50IHx8IDAsXG4gICAgfTtcbiAgfVxuXG4gIC8qKiBHZXQgY2FzZSB0cmVuZHMgb3ZlciB0aGUgbGFzdCBOIGRheXMgKi9cbiAgc3RhdGljIGFzeW5jIGdldENhc2VUcmVuZHMoY2xpZW50OiBhbnksIGRheXM6IG51bWJlciA9IDMwKTogUHJvbWlzZTxDYXNlVHJlbmRbXT4ge1xuICAgIGNvbnN0IGZyb21EYXRlID0gbmV3IERhdGUoKTtcbiAgICBmcm9tRGF0ZS5zZXREYXRlKGZyb21EYXRlLmdldERhdGUoKSAtIGRheXMpO1xuXG4gICAgY29uc3QgYWdncyA9IGF3YWl0IE9wZW5TZWFyY2hTZXJ2aWNlLmFnZ3JlZ2F0ZURvY3VtZW50cyhjbGllbnQsIENBU0VfSU5ERVgsIHtcbiAgICAgIHF1ZXJ5OiB7XG4gICAgICAgIHJhbmdlOiB7IGNyZWF0ZWRfYXQ6IHsgZ3RlOiBmcm9tRGF0ZS50b0lTT1N0cmluZygpIH0gfSxcbiAgICAgIH0sXG4gICAgICBhZ2dzOiB7XG4gICAgICAgIGNhc2VzX292ZXJfdGltZToge1xuICAgICAgICAgIGRhdGVfaGlzdG9ncmFtOiB7XG4gICAgICAgICAgICBmaWVsZDogJ2NyZWF0ZWRfYXQnLFxuICAgICAgICAgICAgY2FsZW5kYXJfaW50ZXJ2YWw6ICdkYXknLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICAgIGNsb3NlZF9vdmVyX3RpbWU6IHtcbiAgICAgICAgICBmaWx0ZXI6IHsgZXhpc3RzOiB7IGZpZWxkOiAnY2xvc2VkX2F0JyB9IH0sXG4gICAgICAgICAgYWdnczoge1xuICAgICAgICAgICAgYnlfZGF5OiB7XG4gICAgICAgICAgICAgIGRhdGVfaGlzdG9ncmFtOiB7XG4gICAgICAgICAgICAgICAgZmllbGQ6ICdjbG9zZWRfYXQnLFxuICAgICAgICAgICAgICAgIGNhbGVuZGFyX2ludGVydmFsOiAnZGF5JyxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgfSk7XG5cbiAgICBjb25zdCBjcmVhdGVkQnVja2V0cyA9IGFnZ3MuY2FzZXNfb3Zlcl90aW1lPy5idWNrZXRzIHx8IFtdO1xuICAgIGNvbnN0IGNsb3NlZEJ1Y2tldHMgPSBhZ2dzLmNsb3NlZF9vdmVyX3RpbWU/LmJ5X2RheT8uYnVja2V0cyB8fCBbXTtcblxuICAgIC8vIE1lcmdlIGNyZWF0ZWQgYW5kIGNsb3NlZCBpbnRvIGEgc2luZ2xlIHRpbWVsaW5lXG4gICAgY29uc3QgY2xvc2VkTWFwOiBSZWNvcmQ8c3RyaW5nLCBudW1iZXI+ID0ge307XG4gICAgY2xvc2VkQnVja2V0cy5mb3JFYWNoKChiOiBhbnkpID0+IHtcbiAgICAgIGNvbnN0IGRhdGVLZXkgPSBiLmtleV9hc19zdHJpbmc/LnNwbGl0KCdUJylbMF0gfHwgJyc7XG4gICAgICBjbG9zZWRNYXBbZGF0ZUtleV0gPSBiLmRvY19jb3VudDtcbiAgICB9KTtcblxuICAgIHJldHVybiBjcmVhdGVkQnVja2V0cy5tYXAoKGI6IGFueSkgPT4ge1xuICAgICAgY29uc3QgZGF0ZUtleSA9IGIua2V5X2FzX3N0cmluZz8uc3BsaXQoJ1QnKVswXSB8fCAnJztcbiAgICAgIHJldHVybiB7XG4gICAgICAgIGRhdGU6IGRhdGVLZXksXG4gICAgICAgIGNyZWF0ZWQ6IGIuZG9jX2NvdW50LFxuICAgICAgICBjbG9zZWQ6IGNsb3NlZE1hcFtkYXRlS2V5XSB8fCAwLFxuICAgICAgfTtcbiAgICB9KTtcbiAgfVxuXG4gIC8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICAvLyBBdXRvbWF0ZWQgQWxlcnQgSGFuZGxpbmcgKFdlYmhvb2tzKVxuICAvLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuICAvKipcbiAgICogUHJvY2VzcyBhbiBpbmNvbWluZyBhbGVydCBmcm9tIGEgV2F6dWggd2ViaG9vay5cbiAgICogUGVyZm9ybXMgZGVkdXBsaWNhdGlvbiBiYXNlZCBvbiBydWxlLmlkIGFuZCBhZ2VudC5pZCBmb3IgdW5yZXNvbHZlZCBjYXNlcy5cbiAgICovXG4gIHN0YXRpYyBhc3luYyBoYW5kbGVBdXRvbWF0ZWRBbGVydChjbGllbnQ6IGFueSwgYWxlcnQ6IGFueSwgdXNlcjogc3RyaW5nKTogUHJvbWlzZTxDYXNlIHwgbnVsbD4ge1xuICAgIGNvbnN0IHJ1bGVJZCA9IGFsZXJ0LnJ1bGU/LmlkO1xuICAgIGNvbnN0IGFnZW50SWQgPSBhbGVydC5hZ2VudD8uaWQ7XG4gICAgY29uc3QgYWxlcnRJZCA9IGFsZXJ0LmlkO1xuXG4gICAgaWYgKCFydWxlSWQgfHwgIWFnZW50SWQgfHwgIWFsZXJ0SWQpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignSW52YWxpZCBhbGVydCBwYXlsb2FkOiBNaXNzaW5nIHJ1bGUuaWQsIGFnZW50LmlkLCBvciBpZCcpO1xuICAgIH1cblxuICAgIGNvbnN0IGxpbmtlZEFsZXJ0OiBMaW5rZWRBbGVydCA9IHtcbiAgICAgIGFsZXJ0X2lkOiBhbGVydElkLFxuICAgICAgaW5kZXg6IGFsZXJ0Ll9pbmRleCB8fCAnd2F6dWgtYWxlcnRzLSonLFxuICAgICAgcnVsZV9pZDogcGFyc2VJbnQocnVsZUlkLCAxMCksXG4gICAgICBydWxlX2Rlc2NyaXB0aW9uOiBhbGVydC5ydWxlPy5kZXNjcmlwdGlvbiB8fCAnVW5rbm93biBSdWxlJyxcbiAgICAgIHJ1bGVfbGV2ZWw6IGFsZXJ0LnJ1bGU/LmxldmVsIHx8IDAsXG4gICAgICBydWxlX2dyb3VwczogYWxlcnQucnVsZT8uZ3JvdXBzIHx8IFtdLFxuICAgICAgYWdlbnRfaWQ6IGFnZW50SWQsXG4gICAgICBhZ2VudF9uYW1lOiBhbGVydC5hZ2VudD8ubmFtZSB8fCAnVW5rbm93biBBZ2VudCcsXG4gICAgICB0aW1lc3RhbXA6IGFsZXJ0LnRpbWVzdGFtcCB8fCBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICBmdWxsX2xvZzogYWxlcnQuZnVsbF9sb2csXG4gICAgfTtcblxuICAgIC8vIFNlYXJjaCBmb3IgYW4gdW5yZXNvbHZlZCBjYXNlIHdpdGggdGhlIGV4YWN0IHNhbWUgcnVsZSBhbmQgYWdlbnRcbiAgICBjb25zdCBzZWFyY2hCb2R5ID0ge1xuICAgICAgcXVlcnk6IHtcbiAgICAgICAgYm9vbDoge1xuICAgICAgICAgIG11c3Q6IFtcbiAgICAgICAgICAgIHsgdGVybXM6IHsgc3RhdHVzOiBbJ29wZW4nLCAnaW5fcHJvZ3Jlc3MnLCAnd2FpdGluZyddIH0gfSxcbiAgICAgICAgICAgIHsgdGVybTogeyAnY3VzdG9tX2ZpZWxkcy5hdXRvbWF0ZWRfcnVsZV9pZC5rZXl3b3JkJzogU3RyaW5nKHJ1bGVJZCkgfSB9LFxuICAgICAgICAgICAgeyB0ZXJtOiB7ICdjdXN0b21fZmllbGRzLmF1dG9tYXRlZF9hZ2VudF9pZC5rZXl3b3JkJzogU3RyaW5nKGFnZW50SWQpIH0gfVxuICAgICAgICAgIF1cbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIHNpemU6IDEsXG4gICAgICBzb3J0OiBbeyBjcmVhdGVkX2F0OiB7IG9yZGVyOiAnZGVzYycgfSB9XVxuICAgIH07XG5cbiAgICBjb25zdCBzZWFyY2hSZXN1bHQgPSBhd2FpdCBPcGVuU2VhcmNoU2VydmljZS5zZWFyY2hEb2N1bWVudHMoY2xpZW50LCBDQVNFX0lOREVYLCBzZWFyY2hCb2R5KTtcbiAgICBcbiAgICAvLyBJRiBEVVBMSUNBVEUgRk9VTkQ6IEFwcGVuZCBhbGVydCBhbmQgYWRkIGNvbW1lbnRcbiAgICBpZiAoc2VhcmNoUmVzdWx0LmhpdHMubGVuZ3RoID4gMCkge1xuICAgICAgY29uc3QgZXhpc3RpbmdDYXNlID0gc2VhcmNoUmVzdWx0LmhpdHNbMF07XG4gICAgICBjb25zdCBjYXNlSWQgPSBleGlzdGluZ0Nhc2UuX2lkO1xuICAgICAgXG4gICAgICAvLyBBdm9pZCBsaW5raW5nIHRoZSBleGFjdCBzYW1lIGFsZXJ0IHR3aWNlXG4gICAgICBjb25zdCBhbHJlYWR5TGlua2VkID0gZXhpc3RpbmdDYXNlLl9zb3VyY2UubGlua2VkX2FsZXJ0cy5zb21lKChhOiBhbnkpID0+IGEuYWxlcnRfaWQgPT09IGFsZXJ0SWQpO1xuICAgICAgaWYgKGFscmVhZHlMaW5rZWQpIHtcbiAgICAgICAgIHJldHVybiB7IGlkOiBjYXNlSWQsIC4uLmV4aXN0aW5nQ2FzZS5fc291cmNlIH0gYXMgQ2FzZTtcbiAgICAgIH1cblxuICAgICAgLy8gQWRkIGF1dG9tYXRlZCBjb21tZW50XG4gICAgICBjb25zdCBjb21tZW50SWQgPSB1dWlkKCk7XG4gICAgICBjb25zdCBjb21tZW50OiBDYXNlQ29tbWVudCA9IHtcbiAgICAgICAgY29tbWVudF9pZDogY29tbWVudElkLFxuICAgICAgICBhdXRob3I6ICdTeXN0ZW0gQXV0b21hdGlvbicsXG4gICAgICAgIGNvbnRlbnQ6IGBEdXBsaWNhdGUgYWxlcnQgZGV0ZWN0ZWQgKFJ1bGUgJHtydWxlSWR9IG9uIEFnZW50ICR7YWdlbnRJZH0pLiBBdXRvbWF0aWNhbGx5IGxpbmtlZC5gLFxuICAgICAgICBjcmVhdGVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICB9O1xuXG4gICAgICBjb25zdCB1cGRhdGVEb2MgPSB7XG4gICAgICAgIGxpbmtlZF9hbGVydHM6IFsuLi5leGlzdGluZ0Nhc2UuX3NvdXJjZS5saW5rZWRfYWxlcnRzLCBsaW5rZWRBbGVydF0sXG4gICAgICAgIGNvbW1lbnRzOiBbLi4uZXhpc3RpbmdDYXNlLl9zb3VyY2UuY29tbWVudHMsIGNvbW1lbnRdLFxuICAgICAgICB1cGRhdGVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICB9O1xuXG4gICAgICBhd2FpdCBPcGVuU2VhcmNoU2VydmljZS51cGRhdGVEb2N1bWVudChjbGllbnQsIENBU0VfSU5ERVgsIGNhc2VJZCwgdXBkYXRlRG9jKTtcbiAgICAgIHJldHVybiBhd2FpdCBDYXNlU2VydmljZS5nZXRDYXNlKGNsaWVudCwgY2FzZUlkKTtcbiAgICB9XG5cbiAgICAvLyBJRiBOTyBEVVBMSUNBVEU6IENyZWF0ZSBuZXcgY2FzZVxuICAgIGxldCBzZXZlcml0eTogQ2FzZVNldmVyaXR5ID0gJ2xvdyc7XG4gICAgY29uc3QgbGV2ZWwgPSBhbGVydC5ydWxlPy5sZXZlbCB8fCAwO1xuICAgIGlmIChsZXZlbCA+PSAxMikgc2V2ZXJpdHkgPSAnY3JpdGljYWwnO1xuICAgIGVsc2UgaWYgKGxldmVsID49IDgpIHNldmVyaXR5ID0gJ2hpZ2gnO1xuICAgIGVsc2UgaWYgKGxldmVsID49IDUpIHNldmVyaXR5ID0gJ21lZGl1bSc7XG5cbiAgICBjb25zdCBwYXlsb2FkOiBDcmVhdGVDYXNlUGF5bG9hZCA9IHtcbiAgICAgIHRpdGxlOiBgW0F1dG9tYXRlZF0gJHthbGVydC5ydWxlPy5kZXNjcmlwdGlvbiB8fCAnU2VjdXJpdHkgQWxlcnQnfWAsXG4gICAgICBkZXNjcmlwdGlvbjogYEF1dG9tYXRlZCBjYXNlIGNyZWF0ZWQgZnJvbSBXYXp1aCBBbGVydC5cXG5cXG5SdWxlOiAke3J1bGVJZH1cXG5BZ2VudDogJHthbGVydC5hZ2VudD8ubmFtZX0gKCR7YWdlbnRJZH0pXFxuTGV2ZWw6ICR7bGV2ZWx9XFxuXFxuTG9nOiAke2FsZXJ0LmZ1bGxfbG9nIHx8ICdOL0EnfWAsXG4gICAgICBzZXZlcml0eSxcbiAgICAgIHByaW9yaXR5OiAnUDInLFxuICAgICAgY2F0ZWdvcnk6ICdvdGhlcicsXG4gICAgICB0YWdzOiBbJ2F1dG9tYXRlZCcsIGBydWxlXyR7cnVsZUlkfWAsIGBhZ2VudF8ke2FnZW50SWR9YF0sXG4gICAgfTtcblxuICAgIGNvbnN0IG5ld0Nhc2UgPSBhd2FpdCBDYXNlU2VydmljZS5jcmVhdGVDYXNlKGNsaWVudCwgcGF5bG9hZCwgdXNlcik7XG4gICAgXG4gICAgLy8gQWRkIGN1c3RvbSBmaWVsZHMgZm9yIGRlZHVwbGljYXRpb24gdHJhY2tpbmdcbiAgICBpZiAobmV3Q2FzZS5pZCkge1xuICAgICAgIGF3YWl0IE9wZW5TZWFyY2hTZXJ2aWNlLnVwZGF0ZURvY3VtZW50KGNsaWVudCwgQ0FTRV9JTkRFWCwgbmV3Q2FzZS5pZCwge1xuICAgICAgICAgY3VzdG9tX2ZpZWxkczoge1xuICAgICAgICAgICBhdXRvbWF0ZWRfcnVsZV9pZDogU3RyaW5nKHJ1bGVJZCksXG4gICAgICAgICAgIGF1dG9tYXRlZF9hZ2VudF9pZDogU3RyaW5nKGFnZW50SWQpXG4gICAgICAgICB9LFxuICAgICAgICAgbGlua2VkX2FsZXJ0czogW2xpbmtlZEFsZXJ0XVxuICAgICAgIH0pO1xuICAgICAgIHJldHVybiBhd2FpdCBDYXNlU2VydmljZS5nZXRDYXNlKGNsaWVudCwgbmV3Q2FzZS5pZCk7XG4gICAgfVxuICAgIFxuICAgIHJldHVybiBuZXdDYXNlO1xuICB9XG59XG4iXSwibWFwcGluZ3MiOiI7Ozs7OztBQXdCQSxJQUFBQSxVQUFBLEdBQUFDLE9BQUE7QUFXQSxJQUFBQyxtQkFBQSxHQUFBRCxPQUFBO0FBbkNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQStCQTtBQUNBLFNBQVNFLElBQUlBLENBQUEsRUFBVztFQUN0QjtFQUNBLElBQUk7SUFDRixPQUFPQyxNQUFNLENBQUNDLFVBQVUsQ0FBQyxDQUFDLENBQUNDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsRUFBRSxDQUFDLENBQUNDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDO0VBQy9ELENBQUMsQ0FBQyxNQUFNO0lBQ04sT0FBT0MsSUFBSSxDQUFDQyxHQUFHLENBQUMsQ0FBQyxDQUFDQyxRQUFRLENBQUMsRUFBRSxDQUFDLEdBQUdDLElBQUksQ0FBQ0MsTUFBTSxDQUFDLENBQUMsQ0FBQ0YsUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFDSCxTQUFTLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQztFQUM3RTtBQUNGOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sTUFBTU0sV0FBVyxDQUFDO0VBQ3ZCO0VBQ0E7RUFDQTs7RUFFQTtBQUNGO0FBQ0E7QUFDQTtFQUNFLGFBQWFDLGNBQWNBLENBQUNDLE1BQVcsRUFBbUI7SUFDeEQsTUFBTUMsT0FBTyxHQUFHLE1BQU1DLHFDQUFpQixDQUFDQyxtQkFBbUIsQ0FBQ0gsTUFBTSxDQUFDO0lBQ25FLE1BQU1JLElBQUksR0FBRyxJQUFJWCxJQUFJLENBQUMsQ0FBQyxDQUFDWSxXQUFXLENBQUMsQ0FBQztJQUNyQyxNQUFNQyxTQUFTLEdBQUdDLE1BQU0sQ0FBQ04sT0FBTyxDQUFDLENBQUNPLFFBQVEsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDO0lBQ2xELE9BQVEsR0FBRUMseUJBQWUsR0FBRUMsNEJBQWtCLEdBQUVOLElBQUssR0FBRU0sNEJBQWtCLEdBQUVKLFNBQVUsRUFBQztFQUN2Rjs7RUFFQTtFQUNBO0VBQ0E7O0VBRUEsT0FBZUssY0FBY0EsQ0FDM0JDLE1BQThCLEVBQzlCQyxJQUFZLEVBQ1pDLE9BQTZCLEVBQ2Y7SUFDZCxPQUFPO01BQ0xDLEVBQUUsRUFBRTNCLElBQUksQ0FBQyxDQUFDO01BQ1Z3QixNQUFNO01BQ05DLElBQUk7TUFDSkcsU0FBUyxFQUFFLElBQUl2QixJQUFJLENBQUMsQ0FBQyxDQUFDd0IsV0FBVyxDQUFDLENBQUM7TUFDbkNIO0lBQ0YsQ0FBQztFQUNIOztFQUVBO0VBQ0E7RUFDQTs7RUFFQTtFQUNBLGFBQWFJLFVBQVVBLENBQ3JCbEIsTUFBVyxFQUNYbUIsT0FBMEIsRUFDMUJOLElBQVksRUFDRztJQUNmLE1BQU1PLE1BQU0sR0FBRyxNQUFNdEIsV0FBVyxDQUFDQyxjQUFjLENBQUNDLE1BQU0sQ0FBQztJQUN2RCxNQUFNTixHQUFHLEdBQUcsSUFBSUQsSUFBSSxDQUFDLENBQUMsQ0FBQ3dCLFdBQVcsQ0FBQyxDQUFDO0lBRXBDLE1BQU1JLE9BQWEsR0FBRztNQUNwQkMsT0FBTyxFQUFFRixNQUFNO01BQ2ZHLEtBQUssRUFBRUosT0FBTyxDQUFDSSxLQUFLO01BQ3BCQyxXQUFXLEVBQUVMLE9BQU8sQ0FBQ0ssV0FBVztNQUNoQ0MsTUFBTSxFQUFFLE1BQU07TUFDZEMsUUFBUSxFQUFFUCxPQUFPLENBQUNPLFFBQVE7TUFDMUJDLFFBQVEsRUFBRVIsT0FBTyxDQUFDUSxRQUFRO01BQzFCQyxRQUFRLEVBQUVULE9BQU8sQ0FBQ1MsUUFBUTtNQUMxQkMsR0FBRyxFQUFFVixPQUFPLENBQUNVLEdBQUcsSUFBSSxPQUFPO01BQzNCQyxJQUFJLEVBQUVYLE9BQU8sQ0FBQ1csSUFBSSxJQUFJLEVBQUU7TUFDeEJDLFFBQVEsRUFBRVosT0FBTyxDQUFDWSxRQUFRLElBQUksSUFBSTtNQUNsQ0MsVUFBVSxFQUFFbkIsSUFBSTtNQUNoQm9CLFVBQVUsRUFBRXZDLEdBQUc7TUFDZndDLFVBQVUsRUFBRXhDLEdBQUc7TUFDZnlDLFNBQVMsRUFBRSxJQUFJO01BQ2ZDLGFBQWEsRUFBRSxFQUFFO01BQ2pCQyxXQUFXLEVBQUUsRUFBRTtNQUNmQyxRQUFRLEVBQUUsRUFBRTtNQUNaQyxLQUFLLEVBQUUsRUFBRTtNQUNUQyxLQUFLLEVBQUUsRUFBRTtNQUNUQyxZQUFZLEVBQUUsQ0FDWjNDLFdBQVcsQ0FBQ2EsY0FBYyxDQUFDLGNBQWMsRUFBRUUsSUFBSSxFQUFFO1FBQy9DUyxPQUFPLEVBQUVGLE1BQU07UUFDZkcsS0FBSyxFQUFFSixPQUFPLENBQUNJO01BQ2pCLENBQUMsQ0FBQyxDQUNIO01BQ0RtQixrQkFBa0IsRUFBRSxJQUFJO01BQ3hCQyxrQkFBa0IsRUFBRSxJQUFJO01BQ3hCQyxhQUFhLEVBQUUsRUFBRTtNQUNqQkMsYUFBYSxFQUFFLENBQUM7SUFDbEIsQ0FBQzs7SUFFRDtJQUNBLElBQUkxQixPQUFPLENBQUNZLFFBQVEsRUFBRTtNQUNwQlYsT0FBTyxDQUFDb0IsWUFBWSxDQUFDSyxJQUFJLENBQ3ZCaEQsV0FBVyxDQUFDYSxjQUFjLENBQUMsVUFBVSxFQUFFRSxJQUFJLEVBQUU7UUFBRWtCLFFBQVEsRUFBRVosT0FBTyxDQUFDWTtNQUFTLENBQUMsQ0FDN0UsQ0FBQztJQUNIO0lBRUEsTUFBTTtNQUFFZ0I7SUFBSSxDQUFDLEdBQUcsTUFBTTdDLHFDQUFpQixDQUFDOEMsY0FBYyxDQUFDaEQsTUFBTSxFQUFFaUQscUJBQVUsRUFBRTVCLE9BQU8sQ0FBQztJQUNuRkEsT0FBTyxDQUFDTixFQUFFLEdBQUdnQyxHQUFHO0lBRWhCLE9BQU8xQixPQUFPO0VBQ2hCOztFQUVBO0VBQ0EsYUFBYTZCLE9BQU9BLENBQUNsRCxNQUFXLEVBQUVlLEVBQVUsRUFBd0I7SUFDbEUsTUFBTW9DLEdBQUcsR0FBRyxNQUFNakQscUNBQWlCLENBQUNrRCxXQUFXLENBQUNwRCxNQUFNLEVBQUVpRCxxQkFBVSxFQUFFbEMsRUFBRSxDQUFDO0lBQ3ZFLElBQUksQ0FBQ29DLEdBQUcsRUFBRSxPQUFPLElBQUk7SUFDckIsT0FBTztNQUFFcEMsRUFBRSxFQUFFb0MsR0FBRyxDQUFDSixHQUFHO01BQUUsR0FBR0ksR0FBRyxDQUFDRTtJQUFRLENBQUM7RUFDeEM7O0VBRUE7RUFDQSxhQUFhQyxVQUFVQSxDQUNyQnRELE1BQVcsRUFDWGUsRUFBVSxFQUNWSSxPQUEwQixFQUMxQk4sSUFBWSxFQUNVO0lBQ3RCLE1BQU0wQyxRQUFRLEdBQUcsTUFBTXpELFdBQVcsQ0FBQ29ELE9BQU8sQ0FBQ2xELE1BQU0sRUFBRWUsRUFBRSxDQUFDO0lBQ3RELElBQUksQ0FBQ3dDLFFBQVEsRUFBRSxPQUFPLElBQUk7SUFFMUIsTUFBTTdELEdBQUcsR0FBRyxJQUFJRCxJQUFJLENBQUMsQ0FBQyxDQUFDd0IsV0FBVyxDQUFDLENBQUM7SUFDcEMsTUFBTXVDLFVBQTBCLEdBQUcsRUFBRTtJQUNyQyxNQUFNQyxTQUFjLEdBQUc7TUFBRXZCLFVBQVUsRUFBRXhDO0lBQUksQ0FBQzs7SUFFMUM7SUFDQSxJQUFJeUIsT0FBTyxDQUFDSSxLQUFLLEtBQUttQyxTQUFTLElBQUl2QyxPQUFPLENBQUNJLEtBQUssS0FBS2dDLFFBQVEsQ0FBQ2hDLEtBQUssRUFBRTtNQUNuRWtDLFNBQVMsQ0FBQ2xDLEtBQUssR0FBR0osT0FBTyxDQUFDSSxLQUFLO0lBQ2pDO0lBQ0EsSUFBSUosT0FBTyxDQUFDSyxXQUFXLEtBQUtrQyxTQUFTLEVBQUU7TUFDckNELFNBQVMsQ0FBQ2pDLFdBQVcsR0FBR0wsT0FBTyxDQUFDSyxXQUFXO0lBQzdDO0lBQ0EsSUFBSUwsT0FBTyxDQUFDTyxRQUFRLEtBQUtnQyxTQUFTLElBQUl2QyxPQUFPLENBQUNPLFFBQVEsS0FBSzZCLFFBQVEsQ0FBQzdCLFFBQVEsRUFBRTtNQUM1RStCLFNBQVMsQ0FBQy9CLFFBQVEsR0FBR1AsT0FBTyxDQUFDTyxRQUFRO01BQ3JDOEIsVUFBVSxDQUFDVixJQUFJLENBQ2JoRCxXQUFXLENBQUNhLGNBQWMsQ0FBQyxrQkFBa0IsRUFBRUUsSUFBSSxFQUFFO1FBQ25EOEMsSUFBSSxFQUFFSixRQUFRLENBQUM3QixRQUFRO1FBQ3ZCa0MsRUFBRSxFQUFFekMsT0FBTyxDQUFDTztNQUNkLENBQUMsQ0FDSCxDQUFDO0lBQ0g7SUFDQSxJQUFJUCxPQUFPLENBQUNRLFFBQVEsS0FBSytCLFNBQVMsSUFBSXZDLE9BQU8sQ0FBQ1EsUUFBUSxLQUFLNEIsUUFBUSxDQUFDNUIsUUFBUSxFQUFFO01BQzVFOEIsU0FBUyxDQUFDOUIsUUFBUSxHQUFHUixPQUFPLENBQUNRLFFBQVE7TUFDckM2QixVQUFVLENBQUNWLElBQUksQ0FDYmhELFdBQVcsQ0FBQ2EsY0FBYyxDQUFDLGtCQUFrQixFQUFFRSxJQUFJLEVBQUU7UUFDbkQ4QyxJQUFJLEVBQUVKLFFBQVEsQ0FBQzVCLFFBQVE7UUFDdkJpQyxFQUFFLEVBQUV6QyxPQUFPLENBQUNRO01BQ2QsQ0FBQyxDQUNILENBQUM7SUFDSDtJQUNBLElBQUlSLE9BQU8sQ0FBQ1MsUUFBUSxLQUFLOEIsU0FBUyxFQUFFO01BQ2xDRCxTQUFTLENBQUM3QixRQUFRLEdBQUdULE9BQU8sQ0FBQ1MsUUFBUTtJQUN2QztJQUNBLElBQUlULE9BQU8sQ0FBQ1UsR0FBRyxLQUFLNkIsU0FBUyxFQUFFO01BQzdCRCxTQUFTLENBQUM1QixHQUFHLEdBQUdWLE9BQU8sQ0FBQ1UsR0FBRztJQUM3QjtJQUNBLElBQUlWLE9BQU8sQ0FBQ1csSUFBSSxLQUFLNEIsU0FBUyxFQUFFO01BQzlCRCxTQUFTLENBQUMzQixJQUFJLEdBQUdYLE9BQU8sQ0FBQ1csSUFBSTtJQUMvQjtJQUNBLElBQUlYLE9BQU8sQ0FBQ1ksUUFBUSxLQUFLMkIsU0FBUyxJQUFJdkMsT0FBTyxDQUFDWSxRQUFRLEtBQUt3QixRQUFRLENBQUN4QixRQUFRLEVBQUU7TUFDNUUwQixTQUFTLENBQUMxQixRQUFRLEdBQUdaLE9BQU8sQ0FBQ1ksUUFBUTtNQUNyQ3lCLFVBQVUsQ0FBQ1YsSUFBSSxDQUNiaEQsV0FBVyxDQUFDYSxjQUFjLENBQUNRLE9BQU8sQ0FBQ1ksUUFBUSxHQUFHLFVBQVUsR0FBRyxZQUFZLEVBQUVsQixJQUFJLEVBQUU7UUFDN0U4QyxJQUFJLEVBQUVKLFFBQVEsQ0FBQ3hCLFFBQVE7UUFDdkI2QixFQUFFLEVBQUV6QyxPQUFPLENBQUNZO01BQ2QsQ0FBQyxDQUNILENBQUM7SUFDSDtJQUNBLElBQUlaLE9BQU8sQ0FBQ3VCLGtCQUFrQixLQUFLZ0IsU0FBUyxFQUFFO01BQzVDRCxTQUFTLENBQUNmLGtCQUFrQixHQUFHdkIsT0FBTyxDQUFDdUIsa0JBQWtCO0lBQzNEOztJQUVBO0lBQ0EsSUFBSWMsVUFBVSxDQUFDSyxNQUFNLEdBQUcsQ0FBQyxFQUFFO01BQ3pCSixTQUFTLENBQUNoQixZQUFZLEdBQUcsQ0FBQyxHQUFHYyxRQUFRLENBQUNkLFlBQVksRUFBRSxHQUFHZSxVQUFVLENBQUM7SUFDcEU7SUFFQSxNQUFNdEQscUNBQWlCLENBQUM0RCxjQUFjLENBQUM5RCxNQUFNLEVBQUVpRCxxQkFBVSxFQUFFbEMsRUFBRSxFQUFFMEMsU0FBUyxDQUFDO0lBQ3pFLE9BQU8sTUFBTTNELFdBQVcsQ0FBQ29ELE9BQU8sQ0FBQ2xELE1BQU0sRUFBRWUsRUFBRSxDQUFDO0VBQzlDOztFQUVBO0VBQ0EsYUFBYWdELFVBQVVBLENBQUMvRCxNQUFXLEVBQUVlLEVBQVUsRUFBb0I7SUFDakUsT0FBTyxNQUFNYixxQ0FBaUIsQ0FBQzhELGNBQWMsQ0FBQ2hFLE1BQU0sRUFBRWlELHFCQUFVLEVBQUVsQyxFQUFFLENBQUM7RUFDdkU7O0VBRUE7RUFDQSxhQUFha0QsU0FBU0EsQ0FBQ2pFLE1BQVcsRUFBRWtFLEtBQW9CLEVBQTZCO0lBQ25GLE1BQU1DLElBQUksR0FBR0QsS0FBSyxDQUFDQyxJQUFJLElBQUksQ0FBQztJQUM1QixNQUFNQyxPQUFPLEdBQUd4RSxJQUFJLENBQUN5RSxHQUFHLENBQUNILEtBQUssQ0FBQ0ksUUFBUSxJQUFJQyw0QkFBaUIsRUFBRUMsd0JBQWEsQ0FBQztJQUM1RSxNQUFNQyxTQUFTLEdBQUdQLEtBQUssQ0FBQ1EsVUFBVSxJQUFJQyw2QkFBa0I7SUFDeEQsTUFBTUMsU0FBUyxHQUFHVixLQUFLLENBQUNXLFVBQVUsSUFBSUMsNkJBQWtCOztJQUV4RDtJQUNBLE1BQU1DLElBQVcsR0FBRyxFQUFFO0lBRXRCLElBQUliLEtBQUssQ0FBQ3pDLE1BQU0sRUFBRTtNQUNoQnNELElBQUksQ0FBQ2pDLElBQUksQ0FBQztRQUFFa0MsSUFBSSxFQUFFO1VBQUV2RCxNQUFNLEVBQUV5QyxLQUFLLENBQUN6QztRQUFPO01BQUUsQ0FBQyxDQUFDO0lBQy9DO0lBQ0EsSUFBSXlDLEtBQUssQ0FBQ3hDLFFBQVEsRUFBRTtNQUNsQnFELElBQUksQ0FBQ2pDLElBQUksQ0FBQztRQUFFa0MsSUFBSSxFQUFFO1VBQUV0RCxRQUFRLEVBQUV3QyxLQUFLLENBQUN4QztRQUFTO01BQUUsQ0FBQyxDQUFDO0lBQ25EO0lBQ0EsSUFBSXdDLEtBQUssQ0FBQ3ZDLFFBQVEsRUFBRTtNQUNsQm9ELElBQUksQ0FBQ2pDLElBQUksQ0FBQztRQUFFa0MsSUFBSSxFQUFFO1VBQUVyRCxRQUFRLEVBQUV1QyxLQUFLLENBQUN2QztRQUFTO01BQUUsQ0FBQyxDQUFDO0lBQ25EO0lBQ0EsSUFBSXVDLEtBQUssQ0FBQ3RDLFFBQVEsRUFBRTtNQUNsQm1ELElBQUksQ0FBQ2pDLElBQUksQ0FBQztRQUFFa0MsSUFBSSxFQUFFO1VBQUVwRCxRQUFRLEVBQUVzQyxLQUFLLENBQUN0QztRQUFTO01BQUUsQ0FBQyxDQUFDO0lBQ25EO0lBQ0EsSUFBSXNDLEtBQUssQ0FBQ25DLFFBQVEsRUFBRTtNQUNsQmdELElBQUksQ0FBQ2pDLElBQUksQ0FBQztRQUFFa0MsSUFBSSxFQUFFO1VBQUVqRCxRQUFRLEVBQUVtQyxLQUFLLENBQUNuQztRQUFTO01BQUUsQ0FBQyxDQUFDO0lBQ25EO0lBQ0EsSUFBSW1DLEtBQUssQ0FBQ3BDLElBQUksRUFBRTtNQUNkLE1BQU1tRCxPQUFPLEdBQUdmLEtBQUssQ0FBQ3BDLElBQUksQ0FBQ29ELEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQ0MsR0FBRyxDQUFFQyxDQUFDLElBQUtBLENBQUMsQ0FBQ0MsSUFBSSxDQUFDLENBQUMsQ0FBQztNQUMxRE4sSUFBSSxDQUFDakMsSUFBSSxDQUFDO1FBQUV3QyxLQUFLLEVBQUU7VUFBRXhELElBQUksRUFBRW1EO1FBQVE7TUFBRSxDQUFDLENBQUM7SUFDekM7SUFDQSxJQUFJZixLQUFLLENBQUNxQixNQUFNLEVBQUU7TUFDaEJSLElBQUksQ0FBQ2pDLElBQUksQ0FBQztRQUNSMEMsV0FBVyxFQUFFO1VBQ1h0QixLQUFLLEVBQUVBLEtBQUssQ0FBQ3FCLE1BQU07VUFDbkJFLE1BQU0sRUFBRSxDQUFDLFNBQVMsRUFBRSxhQUFhLEVBQUUsV0FBVyxFQUFFLE1BQU0sQ0FBQztVQUN2REMsSUFBSSxFQUFFLGFBQWE7VUFDbkJDLFNBQVMsRUFBRTtRQUNiO01BQ0YsQ0FBQyxDQUFDO0lBQ0o7SUFDQSxJQUFJekIsS0FBSyxDQUFDMEIsWUFBWSxJQUFJMUIsS0FBSyxDQUFDMkIsVUFBVSxFQUFFO01BQzFDLE1BQU1DLEtBQVUsR0FBRyxDQUFDLENBQUM7TUFDckIsSUFBSTVCLEtBQUssQ0FBQzBCLFlBQVksRUFBRUUsS0FBSyxDQUFDQyxHQUFHLEdBQUc3QixLQUFLLENBQUMwQixZQUFZO01BQ3RELElBQUkxQixLQUFLLENBQUMyQixVQUFVLEVBQUVDLEtBQUssQ0FBQ0UsR0FBRyxHQUFHOUIsS0FBSyxDQUFDMkIsVUFBVTtNQUNsRGQsSUFBSSxDQUFDakMsSUFBSSxDQUFDO1FBQUVnRCxLQUFLLEVBQUU7VUFBRTdELFVBQVUsRUFBRTZEO1FBQU07TUFBRSxDQUFDLENBQUM7SUFDN0M7SUFFQSxNQUFNRyxVQUFVLEdBQUc7TUFDakIvQixLQUFLLEVBQUVhLElBQUksQ0FBQ2xCLE1BQU0sR0FBRyxDQUFDLEdBQUc7UUFBRXFDLElBQUksRUFBRTtVQUFFbkI7UUFBSztNQUFFLENBQUMsR0FBRztRQUFFb0IsU0FBUyxFQUFFLENBQUM7TUFBRSxDQUFDO01BQy9EQyxJQUFJLEVBQUUsQ0FBQztRQUFFLENBQUMzQixTQUFTLEdBQUc7VUFBRTRCLEtBQUssRUFBRXpCO1FBQVU7TUFBRSxDQUFDLENBQUM7TUFDN0NqQixJQUFJLEVBQUUsQ0FBQ1EsSUFBSSxHQUFHLENBQUMsSUFBSUMsT0FBTztNQUMxQmtDLElBQUksRUFBRWxDLE9BQU87TUFDYjtNQUNBZixPQUFPLEVBQUU7UUFDUGtELFFBQVEsRUFBRSxDQUFDLGNBQWMsRUFBRSxrQkFBa0I7TUFDL0M7SUFDRixDQUFDO0lBRUQsTUFBTTtNQUFFQyxJQUFJO01BQUVDO0lBQU0sQ0FBQyxHQUFHLE1BQU12RyxxQ0FBaUIsQ0FBQ3dHLGVBQWUsQ0FBQzFHLE1BQU0sRUFBRWlELHFCQUFVLEVBQUVnRCxVQUFVLENBQUM7SUFFL0YsTUFBTVUsS0FBYSxHQUFHSCxJQUFJLENBQUNyQixHQUFHLENBQUV5QixHQUFRLEtBQU07TUFDNUM3RixFQUFFLEVBQUU2RixHQUFHLENBQUM3RCxHQUFHO01BQ1gsR0FBRzZELEdBQUcsQ0FBQ3ZEO0lBQ1QsQ0FBQyxDQUFDLENBQUM7SUFFSCxPQUFPO01BQUVzRCxLQUFLO01BQUVGLEtBQUs7TUFBRXRDLElBQUk7TUFBRUcsUUFBUSxFQUFFRjtJQUFRLENBQUM7RUFDbEQ7O0VBRUE7RUFDQTtFQUNBOztFQUVBO0VBQ0EsYUFBYXlDLFlBQVlBLENBQ3ZCN0csTUFBVyxFQUNYZSxFQUFVLEVBQ1YrRixTQUFxQixFQUNyQmpHLElBQVksRUFDZ0Q7SUFDNUQsTUFBTTBDLFFBQVEsR0FBRyxNQUFNekQsV0FBVyxDQUFDb0QsT0FBTyxDQUFDbEQsTUFBTSxFQUFFZSxFQUFFLENBQUM7SUFDdEQsSUFBSSxDQUFDd0MsUUFBUSxFQUFFO01BQ2IsT0FBTztRQUFFd0QsT0FBTyxFQUFFLEtBQUs7UUFBRUMsS0FBSyxFQUFFO01BQWlCLENBQUM7SUFDcEQ7O0lBRUE7SUFDQSxNQUFNQyxrQkFBa0IsR0FBR0MsNkJBQWtCLENBQUMzRCxRQUFRLENBQUM5QixNQUFNLENBQUMsSUFBSSxFQUFFO0lBQ3BFLElBQUksQ0FBQ3dGLGtCQUFrQixDQUFDRSxRQUFRLENBQUNMLFNBQVMsQ0FBQyxFQUFFO01BQzNDLE9BQU87UUFDTEMsT0FBTyxFQUFFLEtBQUs7UUFDZEMsS0FBSyxFQUFHLDJCQUEwQnpELFFBQVEsQ0FBQzlCLE1BQU8sU0FBUXFGLFNBQVUsZUFBY0csa0JBQWtCLENBQUNHLElBQUksQ0FBQyxJQUFJLENBQUU7TUFDbEgsQ0FBQztJQUNIO0lBRUEsTUFBTTFILEdBQUcsR0FBRyxJQUFJRCxJQUFJLENBQUMsQ0FBQyxDQUFDd0IsV0FBVyxDQUFDLENBQUM7SUFDcEMsTUFBTXdDLFNBQWMsR0FBRztNQUNyQmhDLE1BQU0sRUFBRXFGLFNBQVM7TUFDakI1RSxVQUFVLEVBQUV4QztJQUNkLENBQUM7O0lBRUQ7SUFDQSxJQUFJb0gsU0FBUyxLQUFLLFFBQVEsSUFBSUEsU0FBUyxLQUFLLFVBQVUsRUFBRTtNQUN0RHJELFNBQVMsQ0FBQ3RCLFNBQVMsR0FBR3pDLEdBQUc7TUFDekIsSUFBSTZELFFBQVEsQ0FBQ3RCLFVBQVUsRUFBRTtRQUN2QndCLFNBQVMsQ0FBQ2Qsa0JBQWtCLEdBQUcsSUFBSWxELElBQUksQ0FBQ0MsR0FBRyxDQUFDLENBQUMySCxPQUFPLENBQUMsQ0FBQyxHQUFHLElBQUk1SCxJQUFJLENBQUM4RCxRQUFRLENBQUN0QixVQUFVLENBQUMsQ0FBQ29GLE9BQU8sQ0FBQyxDQUFDO01BQ2xHO0lBQ0Y7O0lBRUE7SUFDQSxJQUFJUCxTQUFTLEtBQUssTUFBTSxLQUFLdkQsUUFBUSxDQUFDOUIsTUFBTSxLQUFLLFFBQVEsSUFBSThCLFFBQVEsQ0FBQzlCLE1BQU0sS0FBSyxVQUFVLENBQUMsRUFBRTtNQUM1RmdDLFNBQVMsQ0FBQ3RCLFNBQVMsR0FBRyxJQUFJO01BQzFCc0IsU0FBUyxDQUFDZCxrQkFBa0IsR0FBRyxJQUFJO0lBQ3JDOztJQUVBO0lBQ0EsTUFBTTJFLFFBQVEsR0FBR3hILFdBQVcsQ0FBQ2EsY0FBYyxDQUN6Q21HLFNBQVMsS0FBSyxRQUFRLEdBQUcsYUFBYSxHQUFHQSxTQUFTLEtBQUssTUFBTSxJQUFJdkQsUUFBUSxDQUFDOUIsTUFBTSxLQUFLLFFBQVEsR0FBRyxlQUFlLEdBQUcsZ0JBQWdCLEVBQ2xJWixJQUFJLEVBQ0o7TUFBRThDLElBQUksRUFBRUosUUFBUSxDQUFDOUIsTUFBTTtNQUFFbUMsRUFBRSxFQUFFa0Q7SUFBVSxDQUN6QyxDQUFDO0lBQ0RyRCxTQUFTLENBQUNoQixZQUFZLEdBQUcsQ0FBQyxHQUFHYyxRQUFRLENBQUNkLFlBQVksRUFBRTZFLFFBQVEsQ0FBQztJQUU3RCxNQUFNcEgscUNBQWlCLENBQUM0RCxjQUFjLENBQUM5RCxNQUFNLEVBQUVpRCxxQkFBVSxFQUFFbEMsRUFBRSxFQUFFMEMsU0FBUyxDQUFDO0lBQ3pFLE1BQU04RCxXQUFXLEdBQUcsTUFBTXpILFdBQVcsQ0FBQ29ELE9BQU8sQ0FBQ2xELE1BQU0sRUFBRWUsRUFBRSxDQUFDO0lBQ3pELE9BQU87TUFBRWdHLE9BQU8sRUFBRSxJQUFJO01BQUVTLElBQUksRUFBRUQ7SUFBYSxDQUFDO0VBQzlDOztFQUVBO0VBQ0EsYUFBYUUsVUFBVUEsQ0FDckJ6SCxNQUFXLEVBQ1hlLEVBQVUsRUFDVmdCLFFBQXVCLEVBQ3ZCbEIsSUFBWSxFQUNVO0lBQ3RCLE1BQU0wQyxRQUFRLEdBQUcsTUFBTXpELFdBQVcsQ0FBQ29ELE9BQU8sQ0FBQ2xELE1BQU0sRUFBRWUsRUFBRSxDQUFDO0lBQ3RELElBQUksQ0FBQ3dDLFFBQVEsRUFBRSxPQUFPLElBQUk7SUFFMUIsTUFBTStELFFBQVEsR0FBR3hILFdBQVcsQ0FBQ2EsY0FBYyxDQUN6Q29CLFFBQVEsR0FBRyxVQUFVLEdBQUcsWUFBWSxFQUNwQ2xCLElBQUksRUFDSjtNQUFFOEMsSUFBSSxFQUFFSixRQUFRLENBQUN4QixRQUFRO01BQUU2QixFQUFFLEVBQUU3QjtJQUFTLENBQzFDLENBQUM7SUFFRCxNQUFNN0IscUNBQWlCLENBQUM0RCxjQUFjLENBQUM5RCxNQUFNLEVBQUVpRCxxQkFBVSxFQUFFbEMsRUFBRSxFQUFFO01BQzdEZ0IsUUFBUTtNQUNSRyxVQUFVLEVBQUUsSUFBSXpDLElBQUksQ0FBQyxDQUFDLENBQUN3QixXQUFXLENBQUMsQ0FBQztNQUNwQ3dCLFlBQVksRUFBRSxDQUFDLEdBQUdjLFFBQVEsQ0FBQ2QsWUFBWSxFQUFFNkUsUUFBUTtJQUNuRCxDQUFDLENBQUM7SUFFRixPQUFPLE1BQU14SCxXQUFXLENBQUNvRCxPQUFPLENBQUNsRCxNQUFNLEVBQUVlLEVBQUUsQ0FBQztFQUM5Qzs7RUFFQTtFQUNBO0VBQ0E7O0VBRUE7RUFDQSxhQUFhMkcsT0FBT0EsQ0FBQzFILE1BQVcsRUFBRW9CLE1BQWMsRUFBRUcsS0FBYSxFQUFFVixJQUFZLEVBQXdCO0lBQ25HLE1BQU0wQyxRQUFRLEdBQUcsTUFBTXpELFdBQVcsQ0FBQ29ELE9BQU8sQ0FBQ2xELE1BQU0sRUFBRW9CLE1BQU0sQ0FBQztJQUMxRCxJQUFJLENBQUNtQyxRQUFRLEVBQUUsT0FBTyxJQUFJO0lBRTFCLE1BQU1vRSxPQUFPLEdBQUc7TUFDZEMsT0FBTyxFQUFFeEksSUFBSSxDQUFDLENBQUM7TUFDZm1DLEtBQUs7TUFDTHNHLFNBQVMsRUFBRSxLQUFLO01BQ2hCNUYsVUFBVSxFQUFFLElBQUl4QyxJQUFJLENBQUMsQ0FBQyxDQUFDd0IsV0FBVyxDQUFDO0lBQ3JDLENBQUM7SUFFRCxNQUFNd0MsU0FBUyxHQUFHO01BQ2hCbEIsS0FBSyxFQUFFLENBQUMsSUFBSWdCLFFBQVEsQ0FBQ2hCLEtBQUssSUFBSSxFQUFFLENBQUMsRUFBRW9GLE9BQU8sQ0FBQztNQUMzQ3pGLFVBQVUsRUFBRSxJQUFJekMsSUFBSSxDQUFDLENBQUMsQ0FBQ3dCLFdBQVcsQ0FBQztJQUNyQyxDQUFDO0lBRUQsTUFBTWYscUNBQWlCLENBQUM0RCxjQUFjLENBQUM5RCxNQUFNLEVBQUVpRCxxQkFBVSxFQUFFN0IsTUFBTSxFQUFFcUMsU0FBUyxDQUFDO0lBQzdFLE9BQU8sTUFBTTNELFdBQVcsQ0FBQ29ELE9BQU8sQ0FBQ2xELE1BQU0sRUFBRW9CLE1BQU0sQ0FBQztFQUNsRDs7RUFFQTtFQUNBLGFBQWEwRyxVQUFVQSxDQUFDOUgsTUFBVyxFQUFFb0IsTUFBYyxFQUFFMkcsTUFBYyxFQUFFRixTQUFrQixFQUFFaEgsSUFBWSxFQUF3QjtJQUMzSCxNQUFNMEMsUUFBUSxHQUFHLE1BQU16RCxXQUFXLENBQUNvRCxPQUFPLENBQUNsRCxNQUFNLEVBQUVvQixNQUFNLENBQUM7SUFDMUQsSUFBSSxDQUFDbUMsUUFBUSxFQUFFLE9BQU8sSUFBSTtJQUUxQixNQUFNaEIsS0FBSyxHQUFHLENBQUNnQixRQUFRLENBQUNoQixLQUFLLElBQUksRUFBRSxFQUFFNEMsR0FBRyxDQUFFQyxDQUFNLElBQzlDQSxDQUFDLENBQUN3QyxPQUFPLEtBQUtHLE1BQU0sR0FBRztNQUFFLEdBQUczQyxDQUFDO01BQUV5QyxTQUFTO01BQUVHLFlBQVksRUFBRUgsU0FBUyxHQUFHLElBQUlwSSxJQUFJLENBQUMsQ0FBQyxDQUFDd0IsV0FBVyxDQUFDLENBQUMsR0FBR3lDO0lBQVUsQ0FBQyxHQUFHMEIsQ0FDL0csQ0FBQztJQUVELE1BQU0zQixTQUFTLEdBQUc7TUFDaEJsQixLQUFLO01BQ0xMLFVBQVUsRUFBRSxJQUFJekMsSUFBSSxDQUFDLENBQUMsQ0FBQ3dCLFdBQVcsQ0FBQztJQUNyQyxDQUFDO0lBRUQsTUFBTWYscUNBQWlCLENBQUM0RCxjQUFjLENBQUM5RCxNQUFNLEVBQUVpRCxxQkFBVSxFQUFFN0IsTUFBTSxFQUFFcUMsU0FBUyxDQUFDO0lBQzdFLE9BQU8sTUFBTTNELFdBQVcsQ0FBQ29ELE9BQU8sQ0FBQ2xELE1BQU0sRUFBRW9CLE1BQU0sQ0FBQztFQUNsRDs7RUFFQTtFQUNBLGFBQWE2RyxVQUFVQSxDQUFDakksTUFBVyxFQUFFb0IsTUFBYyxFQUFFMkcsTUFBYyxFQUFFbEgsSUFBWSxFQUF3QjtJQUN2RyxNQUFNMEMsUUFBUSxHQUFHLE1BQU16RCxXQUFXLENBQUNvRCxPQUFPLENBQUNsRCxNQUFNLEVBQUVvQixNQUFNLENBQUM7SUFDMUQsSUFBSSxDQUFDbUMsUUFBUSxFQUFFLE9BQU8sSUFBSTtJQUUxQixNQUFNaEIsS0FBSyxHQUFHLENBQUNnQixRQUFRLENBQUNoQixLQUFLLElBQUksRUFBRSxFQUFFMkYsTUFBTSxDQUFFOUMsQ0FBTSxJQUFLQSxDQUFDLENBQUN3QyxPQUFPLEtBQUtHLE1BQU0sQ0FBQztJQUU3RSxNQUFNdEUsU0FBUyxHQUFHO01BQ2hCbEIsS0FBSztNQUNMTCxVQUFVLEVBQUUsSUFBSXpDLElBQUksQ0FBQyxDQUFDLENBQUN3QixXQUFXLENBQUM7SUFDckMsQ0FBQztJQUVELE1BQU1mLHFDQUFpQixDQUFDNEQsY0FBYyxDQUFDOUQsTUFBTSxFQUFFaUQscUJBQVUsRUFBRTdCLE1BQU0sRUFBRXFDLFNBQVMsQ0FBQztJQUM3RSxPQUFPLE1BQU0zRCxXQUFXLENBQUNvRCxPQUFPLENBQUNsRCxNQUFNLEVBQUVvQixNQUFNLENBQUM7RUFDbEQ7O0VBRUE7RUFDQTtFQUNBOztFQUVBO0VBQ0EsYUFBYStHLFdBQVdBLENBQUNuSSxNQUFXLEVBQUVvQixNQUFjLEVBQUVvQixLQUFhLEVBQUUzQixJQUFZLEVBQXdCO0lBQ3ZHLE1BQU0wQyxRQUFRLEdBQUcsTUFBTXpELFdBQVcsQ0FBQ29ELE9BQU8sQ0FBQ2xELE1BQU0sRUFBRW9CLE1BQU0sQ0FBQztJQUMxRCxJQUFJLENBQUNtQyxRQUFRLEVBQUUsT0FBTyxJQUFJO0lBRTFCLE1BQU1FLFNBQVMsR0FBRztNQUNoQmpCLEtBQUs7TUFDTE4sVUFBVSxFQUFFLElBQUl6QyxJQUFJLENBQUMsQ0FBQyxDQUFDd0IsV0FBVyxDQUFDO0lBQ3JDLENBQUM7SUFFRCxNQUFNZixxQ0FBaUIsQ0FBQzRELGNBQWMsQ0FBQzlELE1BQU0sRUFBRWlELHFCQUFVLEVBQUU3QixNQUFNLEVBQUVxQyxTQUFTLENBQUM7SUFDN0UsT0FBTyxNQUFNM0QsV0FBVyxDQUFDb0QsT0FBTyxDQUFDbEQsTUFBTSxFQUFFb0IsTUFBTSxDQUFDO0VBQ2xEOztFQUVBO0VBQ0E7RUFDQTs7RUFFQTtFQUNBLGFBQWFnSCxVQUFVQSxDQUNyQnBJLE1BQVcsRUFDWG9CLE1BQWMsRUFDZGlILE9BQWUsRUFDZnhILElBQVksRUFDVTtJQUN0QixNQUFNMEMsUUFBUSxHQUFHLE1BQU16RCxXQUFXLENBQUNvRCxPQUFPLENBQUNsRCxNQUFNLEVBQUVvQixNQUFNLENBQUM7SUFDMUQsSUFBSSxDQUFDbUMsUUFBUSxFQUFFLE9BQU8sSUFBSTtJQUUxQixNQUFNK0UsT0FBb0IsR0FBRztNQUMzQkMsVUFBVSxFQUFFbkosSUFBSSxDQUFDLENBQUM7TUFDbEJvSixNQUFNLEVBQUUzSCxJQUFJO01BQ1p3SCxPQUFPO01BQ1BwRyxVQUFVLEVBQUUsSUFBSXhDLElBQUksQ0FBQyxDQUFDLENBQUN3QixXQUFXLENBQUM7SUFDckMsQ0FBQztJQUVELE1BQU1xRyxRQUFRLEdBQUd4SCxXQUFXLENBQUNhLGNBQWMsQ0FBQyxlQUFlLEVBQUVFLElBQUksRUFBRTtNQUNqRTBILFVBQVUsRUFBRUQsT0FBTyxDQUFDQztJQUN0QixDQUFDLENBQUM7SUFFRixNQUFNckkscUNBQWlCLENBQUM0RCxjQUFjLENBQUM5RCxNQUFNLEVBQUVpRCxxQkFBVSxFQUFFN0IsTUFBTSxFQUFFO01BQ2pFa0IsUUFBUSxFQUFFLENBQUMsR0FBR2lCLFFBQVEsQ0FBQ2pCLFFBQVEsRUFBRWdHLE9BQU8sQ0FBQztNQUN6QzdGLFlBQVksRUFBRSxDQUFDLEdBQUdjLFFBQVEsQ0FBQ2QsWUFBWSxFQUFFNkUsUUFBUSxDQUFDO01BQ2xEcEYsVUFBVSxFQUFFLElBQUl6QyxJQUFJLENBQUMsQ0FBQyxDQUFDd0IsV0FBVyxDQUFDO0lBQ3JDLENBQUMsQ0FBQztJQUVGLE9BQU8sTUFBTW5CLFdBQVcsQ0FBQ29ELE9BQU8sQ0FBQ2xELE1BQU0sRUFBRW9CLE1BQU0sQ0FBQztFQUNsRDs7RUFFQTtFQUNBLGFBQWFxSCxhQUFhQSxDQUN4QnpJLE1BQVcsRUFDWG9CLE1BQWMsRUFDZHNILFNBQWlCLEVBQ2pCN0gsSUFBWSxFQUNVO0lBQ3RCLE1BQU0wQyxRQUFRLEdBQUcsTUFBTXpELFdBQVcsQ0FBQ29ELE9BQU8sQ0FBQ2xELE1BQU0sRUFBRW9CLE1BQU0sQ0FBQztJQUMxRCxJQUFJLENBQUNtQyxRQUFRLEVBQUUsT0FBTyxJQUFJO0lBRTFCLE1BQU1vRixlQUFlLEdBQUdwRixRQUFRLENBQUNqQixRQUFRLENBQUM0RixNQUFNLENBQUVVLENBQUMsSUFBS0EsQ0FBQyxDQUFDTCxVQUFVLEtBQUtHLFNBQVMsQ0FBQztJQUNuRixJQUFJQyxlQUFlLENBQUM5RSxNQUFNLEtBQUtOLFFBQVEsQ0FBQ2pCLFFBQVEsQ0FBQ3VCLE1BQU0sRUFBRTtNQUN2RCxPQUFPTixRQUFRLENBQUMsQ0FBQztJQUNuQjs7SUFFQSxNQUFNK0QsUUFBUSxHQUFHeEgsV0FBVyxDQUFDYSxjQUFjLENBQUMsaUJBQWlCLEVBQUVFLElBQUksRUFBRTtNQUNuRTBILFVBQVUsRUFBRUc7SUFDZCxDQUFDLENBQUM7SUFFRixNQUFNeEkscUNBQWlCLENBQUM0RCxjQUFjLENBQUM5RCxNQUFNLEVBQUVpRCxxQkFBVSxFQUFFN0IsTUFBTSxFQUFFO01BQ2pFa0IsUUFBUSxFQUFFcUcsZUFBZTtNQUN6QmxHLFlBQVksRUFBRSxDQUFDLEdBQUdjLFFBQVEsQ0FBQ2QsWUFBWSxFQUFFNkUsUUFBUSxDQUFDO01BQ2xEcEYsVUFBVSxFQUFFLElBQUl6QyxJQUFJLENBQUMsQ0FBQyxDQUFDd0IsV0FBVyxDQUFDO0lBQ3JDLENBQUMsQ0FBQztJQUVGLE9BQU8sTUFBTW5CLFdBQVcsQ0FBQ29ELE9BQU8sQ0FBQ2xELE1BQU0sRUFBRW9CLE1BQU0sQ0FBQztFQUNsRDs7RUFFQTtFQUNBO0VBQ0E7O0VBRUE7RUFDQSxhQUFheUgsU0FBU0EsQ0FDcEI3SSxNQUFXLEVBQ1hvQixNQUFjLEVBQ2QwSCxLQUFrQixFQUNsQmpJLElBQVksRUFDVTtJQUN0QixNQUFNMEMsUUFBUSxHQUFHLE1BQU16RCxXQUFXLENBQUNvRCxPQUFPLENBQUNsRCxNQUFNLEVBQUVvQixNQUFNLENBQUM7SUFDMUQsSUFBSSxDQUFDbUMsUUFBUSxFQUFFLE9BQU8sSUFBSTs7SUFFMUI7SUFDQSxJQUFJQSxRQUFRLENBQUNuQixhQUFhLENBQUMyRyxJQUFJLENBQUVDLENBQUMsSUFBS0EsQ0FBQyxDQUFDQyxRQUFRLEtBQUtILEtBQUssQ0FBQ0csUUFBUSxDQUFDLEVBQUU7TUFDckUsT0FBTzFGLFFBQVEsQ0FBQyxDQUFDO0lBQ25COztJQUVBLE1BQU0rRCxRQUFRLEdBQUd4SCxXQUFXLENBQUNhLGNBQWMsQ0FBQyxjQUFjLEVBQUVFLElBQUksRUFBRTtNQUNoRW9JLFFBQVEsRUFBRUgsS0FBSyxDQUFDRyxRQUFRO01BQ3hCQyxnQkFBZ0IsRUFBRUosS0FBSyxDQUFDSTtJQUMxQixDQUFDLENBQUM7SUFFRixNQUFNaEoscUNBQWlCLENBQUM0RCxjQUFjLENBQUM5RCxNQUFNLEVBQUVpRCxxQkFBVSxFQUFFN0IsTUFBTSxFQUFFO01BQ2pFZ0IsYUFBYSxFQUFFLENBQUMsR0FBR21CLFFBQVEsQ0FBQ25CLGFBQWEsRUFBRTBHLEtBQUssQ0FBQztNQUNqRHJHLFlBQVksRUFBRSxDQUFDLEdBQUdjLFFBQVEsQ0FBQ2QsWUFBWSxFQUFFNkUsUUFBUSxDQUFDO01BQ2xEcEYsVUFBVSxFQUFFLElBQUl6QyxJQUFJLENBQUMsQ0FBQyxDQUFDd0IsV0FBVyxDQUFDO0lBQ3JDLENBQUMsQ0FBQztJQUVGLE9BQU8sTUFBTW5CLFdBQVcsQ0FBQ29ELE9BQU8sQ0FBQ2xELE1BQU0sRUFBRW9CLE1BQU0sQ0FBQztFQUNsRDs7RUFFQTtFQUNBLGFBQWErSCxXQUFXQSxDQUN0Qm5KLE1BQVcsRUFDWG9CLE1BQWMsRUFDZGdJLE9BQWUsRUFDZnZJLElBQVksRUFDVTtJQUN0QixNQUFNMEMsUUFBUSxHQUFHLE1BQU16RCxXQUFXLENBQUNvRCxPQUFPLENBQUNsRCxNQUFNLEVBQUVvQixNQUFNLENBQUM7SUFDMUQsSUFBSSxDQUFDbUMsUUFBUSxFQUFFLE9BQU8sSUFBSTtJQUUxQixNQUFNOEYsYUFBYSxHQUFHOUYsUUFBUSxDQUFDbkIsYUFBYSxDQUFDOEYsTUFBTSxDQUFFYyxDQUFDLElBQUtBLENBQUMsQ0FBQ0MsUUFBUSxLQUFLRyxPQUFPLENBQUM7SUFDbEYsTUFBTTlCLFFBQVEsR0FBR3hILFdBQVcsQ0FBQ2EsY0FBYyxDQUFDLGdCQUFnQixFQUFFRSxJQUFJLEVBQUU7TUFBRW9JLFFBQVEsRUFBRUc7SUFBUSxDQUFDLENBQUM7SUFFMUYsTUFBTWxKLHFDQUFpQixDQUFDNEQsY0FBYyxDQUFDOUQsTUFBTSxFQUFFaUQscUJBQVUsRUFBRTdCLE1BQU0sRUFBRTtNQUNqRWdCLGFBQWEsRUFBRWlILGFBQWE7TUFDNUI1RyxZQUFZLEVBQUUsQ0FBQyxHQUFHYyxRQUFRLENBQUNkLFlBQVksRUFBRTZFLFFBQVEsQ0FBQztNQUNsRHBGLFVBQVUsRUFBRSxJQUFJekMsSUFBSSxDQUFDLENBQUMsQ0FBQ3dCLFdBQVcsQ0FBQztJQUNyQyxDQUFDLENBQUM7SUFFRixPQUFPLE1BQU1uQixXQUFXLENBQUNvRCxPQUFPLENBQUNsRCxNQUFNLEVBQUVvQixNQUFNLENBQUM7RUFDbEQ7O0VBRUE7RUFDQSxhQUFha0ksWUFBWUEsQ0FDdkJ0SixNQUFXLEVBQ1hrRSxLQUE0QixFQUNhO0lBQ3pDLE1BQU1hLElBQVcsR0FBRyxFQUFFO0lBRXRCLElBQUliLEtBQUssQ0FBQ3FCLE1BQU0sRUFBRTtNQUNoQlIsSUFBSSxDQUFDakMsSUFBSSxDQUFDO1FBQ1IwQyxXQUFXLEVBQUU7VUFDWHRCLEtBQUssRUFBRUEsS0FBSyxDQUFDcUIsTUFBTTtVQUNuQkUsTUFBTSxFQUFFLENBQUMsb0JBQW9CLEVBQUUsVUFBVSxFQUFFLFFBQVEsQ0FBQztVQUNwREUsU0FBUyxFQUFFO1FBQ2I7TUFDRixDQUFDLENBQUM7SUFDSjtJQUNBLElBQUl6QixLQUFLLENBQUNxRixRQUFRLEVBQUU7TUFDbEJ4RSxJQUFJLENBQUNqQyxJQUFJLENBQUM7UUFBRWtDLElBQUksRUFBRTtVQUFFLFVBQVUsRUFBRWQsS0FBSyxDQUFDcUY7UUFBUztNQUFFLENBQUMsQ0FBQztJQUNyRDtJQUNBLElBQUlyRixLQUFLLENBQUNzRixPQUFPLEVBQUU7TUFDakJ6RSxJQUFJLENBQUNqQyxJQUFJLENBQUM7UUFBRWtDLElBQUksRUFBRTtVQUFFLFNBQVMsRUFBRXpFLE1BQU0sQ0FBQzJELEtBQUssQ0FBQ3NGLE9BQU87UUFBRTtNQUFFLENBQUMsQ0FBQztJQUMzRDtJQUNBLElBQUl0RixLQUFLLENBQUN1RixTQUFTLElBQUl2RixLQUFLLENBQUN3RixTQUFTLEVBQUU7TUFDdEMsTUFBTTVELEtBQVUsR0FBRyxDQUFDLENBQUM7TUFDckIsSUFBSTVCLEtBQUssQ0FBQ3VGLFNBQVMsRUFBRTNELEtBQUssQ0FBQ0MsR0FBRyxHQUFHN0IsS0FBSyxDQUFDdUYsU0FBUztNQUNoRCxJQUFJdkYsS0FBSyxDQUFDd0YsU0FBUyxFQUFFNUQsS0FBSyxDQUFDRSxHQUFHLEdBQUc5QixLQUFLLENBQUN3RixTQUFTO01BQ2hEM0UsSUFBSSxDQUFDakMsSUFBSSxDQUFDO1FBQUVnRCxLQUFLLEVBQUU7VUFBRSxZQUFZLEVBQUVBO1FBQU07TUFBRSxDQUFDLENBQUM7SUFDL0M7SUFDQSxJQUFJNUIsS0FBSyxDQUFDUCxJQUFJLElBQUlPLEtBQUssQ0FBQ04sRUFBRSxFQUFFO01BQzFCLE1BQU1rQyxLQUFVLEdBQUcsQ0FBQyxDQUFDO01BQ3JCLElBQUk1QixLQUFLLENBQUNQLElBQUksRUFBRW1DLEtBQUssQ0FBQ0MsR0FBRyxHQUFHN0IsS0FBSyxDQUFDUCxJQUFJO01BQ3RDLElBQUlPLEtBQUssQ0FBQ04sRUFBRSxFQUFFa0MsS0FBSyxDQUFDRSxHQUFHLEdBQUc5QixLQUFLLENBQUNOLEVBQUU7TUFDbENtQixJQUFJLENBQUNqQyxJQUFJLENBQUM7UUFBRWdELEtBQUssRUFBRTtVQUFFOUUsU0FBUyxFQUFFOEU7UUFBTTtNQUFFLENBQUMsQ0FBQztJQUM1QztJQUVBLE1BQU1HLFVBQVUsR0FBRztNQUNqQi9CLEtBQUssRUFBRWEsSUFBSSxDQUFDbEIsTUFBTSxHQUFHLENBQUMsR0FBRztRQUFFcUMsSUFBSSxFQUFFO1VBQUVuQjtRQUFLO01BQUUsQ0FBQyxHQUFHO1FBQUVvQixTQUFTLEVBQUUsQ0FBQztNQUFFLENBQUM7TUFDL0RDLElBQUksRUFBRSxDQUFDO1FBQUVwRixTQUFTLEVBQUU7VUFBRXFGLEtBQUssRUFBRTtRQUFPO01BQUUsQ0FBQyxDQUFDO01BQ3hDQyxJQUFJLEVBQUUxRyxJQUFJLENBQUN5RSxHQUFHLENBQUNILEtBQUssQ0FBQ29DLElBQUksSUFBSSxFQUFFLEVBQUUsR0FBRztJQUN0QyxDQUFDO0lBRUQsT0FBTyxNQUFNcEcscUNBQWlCLENBQUN3RyxlQUFlLENBQUMxRyxNQUFNLEVBQUUySixxQ0FBMEIsRUFBRTFELFVBQVUsQ0FBQztFQUNoRzs7RUFFQTtFQUNBO0VBQ0E7O0VBRUE7RUFDQSxhQUFhMkQsYUFBYUEsQ0FDeEI1SixNQUFXLEVBQ1hvQixNQUFjLEVBQ2R5SSxVQUE0RCxFQUM1RGhKLElBQVksRUFDVTtJQUN0QixNQUFNMEMsUUFBUSxHQUFHLE1BQU16RCxXQUFXLENBQUNvRCxPQUFPLENBQUNsRCxNQUFNLEVBQUVvQixNQUFNLENBQUM7SUFDMUQsSUFBSSxDQUFDbUMsUUFBUSxFQUFFLE9BQU8sSUFBSTtJQUUxQixNQUFNdUcsYUFBeUIsR0FBRztNQUNoQyxHQUFHRCxVQUFVO01BQ2I5SSxFQUFFLEVBQUUzQixJQUFJLENBQUMsQ0FBQztNQUNWMkssUUFBUSxFQUFFLElBQUl0SyxJQUFJLENBQUMsQ0FBQyxDQUFDd0IsV0FBVyxDQUFDLENBQUM7TUFDbEMrSSxRQUFRLEVBQUVuSjtJQUNaLENBQUM7SUFFRCxNQUFNeUcsUUFBUSxHQUFHeEgsV0FBVyxDQUFDYSxjQUFjLENBQUMsa0JBQWtCLEVBQUVFLElBQUksRUFBRTtNQUNwRTZFLElBQUksRUFBRW1FLFVBQVUsQ0FBQ25FLElBQUk7TUFDckJ1RSxLQUFLLEVBQUVKLFVBQVUsQ0FBQ0k7SUFDcEIsQ0FBQyxDQUFDO0lBRUYsTUFBTS9KLHFDQUFpQixDQUFDNEQsY0FBYyxDQUFDOUQsTUFBTSxFQUFFaUQscUJBQVUsRUFBRTdCLE1BQU0sRUFBRTtNQUNqRWlCLFdBQVcsRUFBRSxDQUFDLEdBQUdrQixRQUFRLENBQUNsQixXQUFXLEVBQUV5SCxhQUFhLENBQUM7TUFDckRySCxZQUFZLEVBQUUsQ0FBQyxHQUFHYyxRQUFRLENBQUNkLFlBQVksRUFBRTZFLFFBQVEsQ0FBQztNQUNsRHBGLFVBQVUsRUFBRSxJQUFJekMsSUFBSSxDQUFDLENBQUMsQ0FBQ3dCLFdBQVcsQ0FBQztJQUNyQyxDQUFDLENBQUM7SUFFRixPQUFPLE1BQU1uQixXQUFXLENBQUNvRCxPQUFPLENBQUNsRCxNQUFNLEVBQUVvQixNQUFNLENBQUM7RUFDbEQ7O0VBRUE7RUFDQSxhQUFhOEksZ0JBQWdCQSxDQUMzQmxLLE1BQVcsRUFDWG9CLE1BQWMsRUFDZCtJLFlBQW9CLEVBQ3BCdEosSUFBWSxFQUNVO0lBQ3RCLE1BQU0wQyxRQUFRLEdBQUcsTUFBTXpELFdBQVcsQ0FBQ29ELE9BQU8sQ0FBQ2xELE1BQU0sRUFBRW9CLE1BQU0sQ0FBQztJQUMxRCxJQUFJLENBQUNtQyxRQUFRLEVBQUUsT0FBTyxJQUFJO0lBRTFCLE1BQU02RyxPQUFPLEdBQUc3RyxRQUFRLENBQUNsQixXQUFXLENBQUM2RixNQUFNLENBQUVtQyxDQUFDLElBQUtBLENBQUMsQ0FBQ3RKLEVBQUUsS0FBS29KLFlBQVksQ0FBQztJQUN6RSxNQUFNN0MsUUFBUSxHQUFHeEgsV0FBVyxDQUFDYSxjQUFjLENBQUMsb0JBQW9CLEVBQUVFLElBQUksRUFBRTtNQUN0RXlKLGFBQWEsRUFBRUg7SUFDakIsQ0FBQyxDQUFDO0lBRUYsTUFBTWpLLHFDQUFpQixDQUFDNEQsY0FBYyxDQUFDOUQsTUFBTSxFQUFFaUQscUJBQVUsRUFBRTdCLE1BQU0sRUFBRTtNQUNqRWlCLFdBQVcsRUFBRStILE9BQU87TUFDcEIzSCxZQUFZLEVBQUUsQ0FBQyxHQUFHYyxRQUFRLENBQUNkLFlBQVksRUFBRTZFLFFBQVEsQ0FBQztNQUNsRHBGLFVBQVUsRUFBRSxJQUFJekMsSUFBSSxDQUFDLENBQUMsQ0FBQ3dCLFdBQVcsQ0FBQztJQUNyQyxDQUFDLENBQUM7SUFFRixPQUFPLE1BQU1uQixXQUFXLENBQUNvRCxPQUFPLENBQUNsRCxNQUFNLEVBQUVvQixNQUFNLENBQUM7RUFDbEQ7O0VBRUE7RUFDQTtFQUNBOztFQUVBO0VBQ0EsYUFBYW1KLG1CQUFtQkEsQ0FBQ3ZLLE1BQVcsRUFBNkI7SUFBQSxJQUFBd0ssZUFBQSxFQUFBQyxpQkFBQSxFQUFBQyxpQkFBQSxFQUFBQyxpQkFBQSxFQUFBQyxXQUFBLEVBQUFDLHFCQUFBLEVBQUFDLG1CQUFBLEVBQUFDLGtCQUFBO0lBQ3ZFLE1BQU1DLEtBQUssR0FBRyxJQUFJdkwsSUFBSSxDQUFDLENBQUM7SUFDeEJ1TCxLQUFLLENBQUNDLFFBQVEsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUM7SUFDMUIsTUFBTUMsUUFBUSxHQUFHRixLQUFLLENBQUMvSixXQUFXLENBQUMsQ0FBQztJQUVwQyxNQUFNa0ssSUFBSSxHQUFHLE1BQU1qTCxxQ0FBaUIsQ0FBQ2tMLGtCQUFrQixDQUFDcEwsTUFBTSxFQUFFaUQscUJBQVUsRUFBRTtNQUMxRWtJLElBQUksRUFBRTtRQUNKRSxTQUFTLEVBQUU7VUFBRS9GLEtBQUssRUFBRTtZQUFFZ0csS0FBSyxFQUFFLFFBQVE7WUFBRWhGLElBQUksRUFBRTtVQUFHO1FBQUUsQ0FBQztRQUNuRGlGLFdBQVcsRUFBRTtVQUFFakcsS0FBSyxFQUFFO1lBQUVnRyxLQUFLLEVBQUUsVUFBVTtZQUFFaEYsSUFBSSxFQUFFO1VBQUc7UUFBRSxDQUFDO1FBQ3ZEa0YsV0FBVyxFQUFFO1VBQUVsRyxLQUFLLEVBQUU7WUFBRWdHLEtBQUssRUFBRSxVQUFVO1lBQUVoRixJQUFJLEVBQUU7VUFBRztRQUFFLENBQUM7UUFDdkRtRixXQUFXLEVBQUU7VUFBRW5HLEtBQUssRUFBRTtZQUFFZ0csS0FBSyxFQUFFLFVBQVU7WUFBRWhGLElBQUksRUFBRTtVQUFHO1FBQUUsQ0FBQztRQUN2RG9GLG1CQUFtQixFQUFFO1VBQUVDLEdBQUcsRUFBRTtZQUFFTCxLQUFLLEVBQUU7VUFBcUI7UUFBRSxDQUFDO1FBQzdETSxhQUFhLEVBQUU7VUFDYjFELE1BQU0sRUFBRTtZQUFFcEMsS0FBSyxFQUFFO2NBQUU3RCxVQUFVLEVBQUU7Z0JBQUU4RCxHQUFHLEVBQUVtRjtjQUFTO1lBQUU7VUFBRTtRQUNyRCxDQUFDO1FBQ0RXLFlBQVksRUFBRTtVQUNaM0QsTUFBTSxFQUFFO1lBQ05oQyxJQUFJLEVBQUU7Y0FDSm5CLElBQUksRUFBRSxDQUNKO2dCQUFFZSxLQUFLLEVBQUU7a0JBQUUzRCxTQUFTLEVBQUU7b0JBQUU0RCxHQUFHLEVBQUVtRjtrQkFBUztnQkFBRTtjQUFFLENBQUMsRUFDM0M7Z0JBQUU1RixLQUFLLEVBQUU7a0JBQUU3RCxNQUFNLEVBQUUsQ0FBQyxVQUFVLEVBQUUsUUFBUTtnQkFBRTtjQUFFLENBQUM7WUFFakQ7VUFDRjtRQUNGLENBQUM7UUFDRGdGLEtBQUssRUFBRTtVQUFFcUYsV0FBVyxFQUFFO1lBQUVSLEtBQUssRUFBRTtVQUFVO1FBQUU7TUFDN0M7SUFDRixDQUFDLENBQUM7O0lBRUY7SUFDQSxNQUFNUyxZQUFvQyxHQUFHLENBQUMsQ0FBQztJQUMvQyxDQUFDLEVBQUF2QixlQUFBLEdBQUFXLElBQUksQ0FBQ0UsU0FBUyxjQUFBYixlQUFBLHVCQUFkQSxlQUFBLENBQWdCd0IsT0FBTyxLQUFJLEVBQUUsRUFBRUMsT0FBTyxDQUFFQyxDQUFNLElBQUs7TUFDbERILFlBQVksQ0FBQ0csQ0FBQyxDQUFDQyxHQUFHLENBQUMsR0FBR0QsQ0FBQyxDQUFDRSxTQUFTO0lBQ25DLENBQUMsQ0FBQzs7SUFFRjtJQUNBLE1BQU1DLGNBQXNDLEdBQUcsQ0FBQyxDQUFDO0lBQ2pELENBQUMsRUFBQTVCLGlCQUFBLEdBQUFVLElBQUksQ0FBQ0ksV0FBVyxjQUFBZCxpQkFBQSx1QkFBaEJBLGlCQUFBLENBQWtCdUIsT0FBTyxLQUFJLEVBQUUsRUFBRUMsT0FBTyxDQUFFQyxDQUFNLElBQUs7TUFDcERHLGNBQWMsQ0FBQ0gsQ0FBQyxDQUFDQyxHQUFHLENBQUMsR0FBR0QsQ0FBQyxDQUFDRSxTQUFTO0lBQ3JDLENBQUMsQ0FBQzs7SUFFRjtJQUNBLE1BQU1FLGNBQXNDLEdBQUcsQ0FBQyxDQUFDO0lBQ2pELENBQUMsRUFBQTVCLGlCQUFBLEdBQUFTLElBQUksQ0FBQ0ssV0FBVyxjQUFBZCxpQkFBQSx1QkFBaEJBLGlCQUFBLENBQWtCc0IsT0FBTyxLQUFJLEVBQUUsRUFBRUMsT0FBTyxDQUFFQyxDQUFNLElBQUs7TUFDcERJLGNBQWMsQ0FBQ0osQ0FBQyxDQUFDQyxHQUFHLENBQUMsR0FBR0QsQ0FBQyxDQUFDRSxTQUFTO0lBQ3JDLENBQUMsQ0FBQzs7SUFFRjtJQUNBLE1BQU1HLGNBQXNDLEdBQUcsQ0FBQyxDQUFDO0lBQ2pELENBQUMsRUFBQTVCLGlCQUFBLEdBQUFRLElBQUksQ0FBQ00sV0FBVyxjQUFBZCxpQkFBQSx1QkFBaEJBLGlCQUFBLENBQWtCcUIsT0FBTyxLQUFJLEVBQUUsRUFBRUMsT0FBTyxDQUFFQyxDQUFNLElBQUs7TUFDcERLLGNBQWMsQ0FBQ0wsQ0FBQyxDQUFDQyxHQUFHLENBQUMsR0FBR0QsQ0FBQyxDQUFDRSxTQUFTO0lBQ3JDLENBQUMsQ0FBQztJQUVGLE1BQU1JLFVBQVUsR0FBRyxFQUFBNUIsV0FBQSxHQUFBTyxJQUFJLENBQUMxRSxLQUFLLGNBQUFtRSxXQUFBLHVCQUFWQSxXQUFBLENBQVlYLEtBQUssS0FBSSxDQUFDO0lBRXpDLE9BQU87TUFDTHdDLFdBQVcsRUFBRUQsVUFBVTtNQUN2QkUsVUFBVSxFQUFFWCxZQUFZLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQztNQUNyQ1ksaUJBQWlCLEVBQUVaLFlBQVksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDO01BQ25EYSxhQUFhLEVBQUViLFlBQVksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDO01BQzNDYyxjQUFjLEVBQUVkLFlBQVksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDO01BQzdDZSxZQUFZLEVBQUVmLFlBQVksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDO01BQ3pDUixXQUFXLEVBQUVjLGNBQXFCO01BQ2xDYixXQUFXLEVBQUVjLGNBQXFCO01BQ2xDYixXQUFXLEVBQUVjLGNBQWM7TUFDM0JRLHNCQUFzQixFQUFFLEVBQUFsQyxxQkFBQSxHQUFBTSxJQUFJLENBQUNPLG1CQUFtQixjQUFBYixxQkFBQSx1QkFBeEJBLHFCQUFBLENBQTBCWixLQUFLLEtBQUksSUFBSTtNQUMvRCtDLG1CQUFtQixFQUFFLEVBQUFsQyxtQkFBQSxHQUFBSyxJQUFJLENBQUNTLGFBQWEsY0FBQWQsbUJBQUEsdUJBQWxCQSxtQkFBQSxDQUFvQnNCLFNBQVMsS0FBSSxDQUFDO01BQ3ZEYSxrQkFBa0IsRUFBRSxFQUFBbEMsa0JBQUEsR0FBQUksSUFBSSxDQUFDVSxZQUFZLGNBQUFkLGtCQUFBLHVCQUFqQkEsa0JBQUEsQ0FBbUJxQixTQUFTLEtBQUk7SUFDdEQsQ0FBQztFQUNIOztFQUVBO0VBQ0EsYUFBYWMsYUFBYUEsQ0FBQ2xOLE1BQVcsRUFBRW1OLElBQVksR0FBRyxFQUFFLEVBQXdCO0lBQUEsSUFBQUMscUJBQUEsRUFBQUMscUJBQUE7SUFDL0UsTUFBTUMsUUFBUSxHQUFHLElBQUk3TixJQUFJLENBQUMsQ0FBQztJQUMzQjZOLFFBQVEsQ0FBQ0MsT0FBTyxDQUFDRCxRQUFRLENBQUNFLE9BQU8sQ0FBQyxDQUFDLEdBQUdMLElBQUksQ0FBQztJQUUzQyxNQUFNaEMsSUFBSSxHQUFHLE1BQU1qTCxxQ0FBaUIsQ0FBQ2tMLGtCQUFrQixDQUFDcEwsTUFBTSxFQUFFaUQscUJBQVUsRUFBRTtNQUMxRWlCLEtBQUssRUFBRTtRQUNMNEIsS0FBSyxFQUFFO1VBQUU3RCxVQUFVLEVBQUU7WUFBRThELEdBQUcsRUFBRXVILFFBQVEsQ0FBQ3JNLFdBQVcsQ0FBQztVQUFFO1FBQUU7TUFDdkQsQ0FBQztNQUNEa0ssSUFBSSxFQUFFO1FBQ0pzQyxlQUFlLEVBQUU7VUFDZkMsY0FBYyxFQUFFO1lBQ2RwQyxLQUFLLEVBQUUsWUFBWTtZQUNuQnFDLGlCQUFpQixFQUFFO1VBQ3JCO1FBQ0YsQ0FBQztRQUNEQyxnQkFBZ0IsRUFBRTtVQUNoQjFGLE1BQU0sRUFBRTtZQUFFMkYsTUFBTSxFQUFFO2NBQUV2QyxLQUFLLEVBQUU7WUFBWTtVQUFFLENBQUM7VUFDMUNILElBQUksRUFBRTtZQUNKMkMsTUFBTSxFQUFFO2NBQ05KLGNBQWMsRUFBRTtnQkFDZHBDLEtBQUssRUFBRSxXQUFXO2dCQUNsQnFDLGlCQUFpQixFQUFFO2NBQ3JCO1lBQ0Y7VUFDRjtRQUNGO01BQ0Y7SUFDRixDQUFDLENBQUM7SUFFRixNQUFNSSxjQUFjLEdBQUcsRUFBQVgscUJBQUEsR0FBQWpDLElBQUksQ0FBQ3NDLGVBQWUsY0FBQUwscUJBQUEsdUJBQXBCQSxxQkFBQSxDQUFzQnBCLE9BQU8sS0FBSSxFQUFFO0lBQzFELE1BQU1nQyxhQUFhLEdBQUcsRUFBQVgscUJBQUEsR0FBQWxDLElBQUksQ0FBQ3lDLGdCQUFnQixjQUFBUCxxQkFBQSxnQkFBQUEscUJBQUEsR0FBckJBLHFCQUFBLENBQXVCUyxNQUFNLGNBQUFULHFCQUFBLHVCQUE3QkEscUJBQUEsQ0FBK0JyQixPQUFPLEtBQUksRUFBRTs7SUFFbEU7SUFDQSxNQUFNaUMsU0FBaUMsR0FBRyxDQUFDLENBQUM7SUFDNUNELGFBQWEsQ0FBQy9CLE9BQU8sQ0FBRUMsQ0FBTSxJQUFLO01BQUEsSUFBQWdDLGdCQUFBO01BQ2hDLE1BQU1DLE9BQU8sR0FBRyxFQUFBRCxnQkFBQSxHQUFBaEMsQ0FBQyxDQUFDa0MsYUFBYSxjQUFBRixnQkFBQSx1QkFBZkEsZ0JBQUEsQ0FBaUJoSixLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUksRUFBRTtNQUNwRCtJLFNBQVMsQ0FBQ0UsT0FBTyxDQUFDLEdBQUdqQyxDQUFDLENBQUNFLFNBQVM7SUFDbEMsQ0FBQyxDQUFDO0lBRUYsT0FBTzJCLGNBQWMsQ0FBQzVJLEdBQUcsQ0FBRStHLENBQU0sSUFBSztNQUFBLElBQUFtQyxpQkFBQTtNQUNwQyxNQUFNRixPQUFPLEdBQUcsRUFBQUUsaUJBQUEsR0FBQW5DLENBQUMsQ0FBQ2tDLGFBQWEsY0FBQUMsaUJBQUEsdUJBQWZBLGlCQUFBLENBQWlCbkosS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFJLEVBQUU7TUFDcEQsT0FBTztRQUNMb0osSUFBSSxFQUFFSCxPQUFPO1FBQ2JJLE9BQU8sRUFBRXJDLENBQUMsQ0FBQ0UsU0FBUztRQUNwQm9DLE1BQU0sRUFBRVAsU0FBUyxDQUFDRSxPQUFPLENBQUMsSUFBSTtNQUNoQyxDQUFDO0lBQ0gsQ0FBQyxDQUFDO0VBQ0o7O0VBRUE7RUFDQTtFQUNBOztFQUVBO0FBQ0Y7QUFDQTtBQUNBO0VBQ0UsYUFBYU0sb0JBQW9CQSxDQUFDek8sTUFBVyxFQUFFOEksS0FBVSxFQUFFakksSUFBWSxFQUF3QjtJQUFBLElBQUE2TixXQUFBLEVBQUFDLFlBQUEsRUFBQUMsWUFBQSxFQUFBQyxZQUFBLEVBQUFDLFlBQUEsRUFBQUMsYUFBQSxFQUFBQyxZQUFBLEVBQUFDLFlBQUEsRUFBQUMsYUFBQTtJQUM3RixNQUFNQyxNQUFNLElBQUFULFdBQUEsR0FBRzVGLEtBQUssQ0FBQ3NHLElBQUksY0FBQVYsV0FBQSx1QkFBVkEsV0FBQSxDQUFZM04sRUFBRTtJQUM3QixNQUFNc08sT0FBTyxJQUFBVixZQUFBLEdBQUc3RixLQUFLLENBQUN3RyxLQUFLLGNBQUFYLFlBQUEsdUJBQVhBLFlBQUEsQ0FBYTVOLEVBQUU7SUFDL0IsTUFBTXFJLE9BQU8sR0FBR04sS0FBSyxDQUFDL0gsRUFBRTtJQUV4QixJQUFJLENBQUNvTyxNQUFNLElBQUksQ0FBQ0UsT0FBTyxJQUFJLENBQUNqRyxPQUFPLEVBQUU7TUFDbkMsTUFBTSxJQUFJbUcsS0FBSyxDQUFDLHlEQUF5RCxDQUFDO0lBQzVFO0lBRUEsTUFBTUMsV0FBd0IsR0FBRztNQUMvQnZHLFFBQVEsRUFBRUcsT0FBTztNQUNqQnFHLEtBQUssRUFBRTNHLEtBQUssQ0FBQzRHLE1BQU0sSUFBSSxnQkFBZ0I7TUFDdkNsRyxPQUFPLEVBQUVtRyxRQUFRLENBQUNSLE1BQU0sRUFBRSxFQUFFLENBQUM7TUFDN0JqRyxnQkFBZ0IsRUFBRSxFQUFBMEYsWUFBQSxHQUFBOUYsS0FBSyxDQUFDc0csSUFBSSxjQUFBUixZQUFBLHVCQUFWQSxZQUFBLENBQVlwTixXQUFXLEtBQUksY0FBYztNQUMzRG9PLFVBQVUsRUFBRSxFQUFBZixZQUFBLEdBQUEvRixLQUFLLENBQUNzRyxJQUFJLGNBQUFQLFlBQUEsdUJBQVZBLFlBQUEsQ0FBWWdCLEtBQUssS0FBSSxDQUFDO01BQ2xDQyxXQUFXLEVBQUUsRUFBQWhCLFlBQUEsR0FBQWhHLEtBQUssQ0FBQ3NHLElBQUksY0FBQU4sWUFBQSx1QkFBVkEsWUFBQSxDQUFZaUIsTUFBTSxLQUFJLEVBQUU7TUFDckN4RyxRQUFRLEVBQUU4RixPQUFPO01BQ2pCVyxVQUFVLEVBQUUsRUFBQWpCLGFBQUEsR0FBQWpHLEtBQUssQ0FBQ3dHLEtBQUssY0FBQVAsYUFBQSx1QkFBWEEsYUFBQSxDQUFha0IsSUFBSSxLQUFJLGVBQWU7TUFDaERqUCxTQUFTLEVBQUU4SCxLQUFLLENBQUM5SCxTQUFTLElBQUksSUFBSXZCLElBQUksQ0FBQyxDQUFDLENBQUN3QixXQUFXLENBQUMsQ0FBQztNQUN0RGlQLFFBQVEsRUFBRXBILEtBQUssQ0FBQ29IO0lBQ2xCLENBQUM7O0lBRUQ7SUFDQSxNQUFNakssVUFBVSxHQUFHO01BQ2pCL0IsS0FBSyxFQUFFO1FBQ0xnQyxJQUFJLEVBQUU7VUFDSm5CLElBQUksRUFBRSxDQUNKO1lBQUVPLEtBQUssRUFBRTtjQUFFN0QsTUFBTSxFQUFFLENBQUMsTUFBTSxFQUFFLGFBQWEsRUFBRSxTQUFTO1lBQUU7VUFBRSxDQUFDLEVBQ3pEO1lBQUV1RCxJQUFJLEVBQUU7Y0FBRSx5Q0FBeUMsRUFBRXpFLE1BQU0sQ0FBQzRPLE1BQU07WUFBRTtVQUFFLENBQUMsRUFDdkU7WUFBRW5LLElBQUksRUFBRTtjQUFFLDBDQUEwQyxFQUFFekUsTUFBTSxDQUFDOE8sT0FBTztZQUFFO1VBQUUsQ0FBQztRQUU3RTtNQUNGLENBQUM7TUFDRC9JLElBQUksRUFBRSxDQUFDO01BQ1BGLElBQUksRUFBRSxDQUFDO1FBQUVuRSxVQUFVLEVBQUU7VUFBRW9FLEtBQUssRUFBRTtRQUFPO01BQUUsQ0FBQztJQUMxQyxDQUFDO0lBRUQsTUFBTThKLFlBQVksR0FBRyxNQUFNalEscUNBQWlCLENBQUN3RyxlQUFlLENBQUMxRyxNQUFNLEVBQUVpRCxxQkFBVSxFQUFFZ0QsVUFBVSxDQUFDOztJQUU1RjtJQUNBLElBQUlrSyxZQUFZLENBQUMzSixJQUFJLENBQUMzQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO01BQ2hDLE1BQU11TSxZQUFZLEdBQUdELFlBQVksQ0FBQzNKLElBQUksQ0FBQyxDQUFDLENBQUM7TUFDekMsTUFBTXBGLE1BQU0sR0FBR2dQLFlBQVksQ0FBQ3JOLEdBQUc7O01BRS9CO01BQ0EsTUFBTXNOLGFBQWEsR0FBR0QsWUFBWSxDQUFDL00sT0FBTyxDQUFDakIsYUFBYSxDQUFDMkcsSUFBSSxDQUFFQyxDQUFNLElBQUtBLENBQUMsQ0FBQ0MsUUFBUSxLQUFLRyxPQUFPLENBQUM7TUFDakcsSUFBSWlILGFBQWEsRUFBRTtRQUNoQixPQUFPO1VBQUV0UCxFQUFFLEVBQUVLLE1BQU07VUFBRSxHQUFHZ1AsWUFBWSxDQUFDL007UUFBUSxDQUFDO01BQ2pEOztNQUVBO01BQ0EsTUFBTXFGLFNBQVMsR0FBR3RKLElBQUksQ0FBQyxDQUFDO01BQ3hCLE1BQU1rSixPQUFvQixHQUFHO1FBQzNCQyxVQUFVLEVBQUVHLFNBQVM7UUFDckJGLE1BQU0sRUFBRSxtQkFBbUI7UUFDM0JILE9BQU8sRUFBRyxrQ0FBaUM4RyxNQUFPLGFBQVlFLE9BQVEsMEJBQXlCO1FBQy9GcE4sVUFBVSxFQUFFLElBQUl4QyxJQUFJLENBQUMsQ0FBQyxDQUFDd0IsV0FBVyxDQUFDO01BQ3JDLENBQUM7TUFFRCxNQUFNd0MsU0FBUyxHQUFHO1FBQ2hCckIsYUFBYSxFQUFFLENBQUMsR0FBR2dPLFlBQVksQ0FBQy9NLE9BQU8sQ0FBQ2pCLGFBQWEsRUFBRW9OLFdBQVcsQ0FBQztRQUNuRWxOLFFBQVEsRUFBRSxDQUFDLEdBQUc4TixZQUFZLENBQUMvTSxPQUFPLENBQUNmLFFBQVEsRUFBRWdHLE9BQU8sQ0FBQztRQUNyRHBHLFVBQVUsRUFBRSxJQUFJekMsSUFBSSxDQUFDLENBQUMsQ0FBQ3dCLFdBQVcsQ0FBQztNQUNyQyxDQUFDO01BRUQsTUFBTWYscUNBQWlCLENBQUM0RCxjQUFjLENBQUM5RCxNQUFNLEVBQUVpRCxxQkFBVSxFQUFFN0IsTUFBTSxFQUFFcUMsU0FBUyxDQUFDO01BQzdFLE9BQU8sTUFBTTNELFdBQVcsQ0FBQ29ELE9BQU8sQ0FBQ2xELE1BQU0sRUFBRW9CLE1BQU0sQ0FBQztJQUNsRDs7SUFFQTtJQUNBLElBQUlNLFFBQXNCLEdBQUcsS0FBSztJQUNsQyxNQUFNbU8sS0FBSyxHQUFHLEVBQUFiLFlBQUEsR0FBQWxHLEtBQUssQ0FBQ3NHLElBQUksY0FBQUosWUFBQSx1QkFBVkEsWUFBQSxDQUFZYSxLQUFLLEtBQUksQ0FBQztJQUNwQyxJQUFJQSxLQUFLLElBQUksRUFBRSxFQUFFbk8sUUFBUSxHQUFHLFVBQVUsQ0FBQyxLQUNsQyxJQUFJbU8sS0FBSyxJQUFJLENBQUMsRUFBRW5PLFFBQVEsR0FBRyxNQUFNLENBQUMsS0FDbEMsSUFBSW1PLEtBQUssSUFBSSxDQUFDLEVBQUVuTyxRQUFRLEdBQUcsUUFBUTtJQUV4QyxNQUFNUCxPQUEwQixHQUFHO01BQ2pDSSxLQUFLLEVBQUcsZUFBYyxFQUFBME4sWUFBQSxHQUFBbkcsS0FBSyxDQUFDc0csSUFBSSxjQUFBSCxZQUFBLHVCQUFWQSxZQUFBLENBQVl6TixXQUFXLEtBQUksZ0JBQWlCLEVBQUM7TUFDbkVBLFdBQVcsRUFBRyxxREFBb0QyTixNQUFPLFlBQVMsQ0FBQUQsYUFBQSxHQUFFcEcsS0FBSyxDQUFDd0csS0FBSyxjQUFBSixhQUFBLHVCQUFYQSxhQUFBLENBQWFlLElBQUssS0FBSVosT0FBUSxhQUFZUSxLQUFNLFlBQVcvRyxLQUFLLENBQUNvSCxRQUFRLElBQUksS0FBTSxFQUFDO01BQ3hLeE8sUUFBUTtNQUNSQyxRQUFRLEVBQUUsSUFBSTtNQUNkQyxRQUFRLEVBQUUsT0FBTztNQUNqQkUsSUFBSSxFQUFFLENBQUMsV0FBVyxFQUFHLFFBQU9xTixNQUFPLEVBQUMsRUFBRyxTQUFRRSxPQUFRLEVBQUM7SUFDMUQsQ0FBQztJQUVELE1BQU1oTyxPQUFPLEdBQUcsTUFBTXZCLFdBQVcsQ0FBQ29CLFVBQVUsQ0FBQ2xCLE1BQU0sRUFBRW1CLE9BQU8sRUFBRU4sSUFBSSxDQUFDOztJQUVuRTtJQUNBLElBQUlRLE9BQU8sQ0FBQ04sRUFBRSxFQUFFO01BQ2IsTUFBTWIscUNBQWlCLENBQUM0RCxjQUFjLENBQUM5RCxNQUFNLEVBQUVpRCxxQkFBVSxFQUFFNUIsT0FBTyxDQUFDTixFQUFFLEVBQUU7UUFDckU4QixhQUFhLEVBQUU7VUFDYnlOLGlCQUFpQixFQUFFL1AsTUFBTSxDQUFDNE8sTUFBTSxDQUFDO1VBQ2pDb0Isa0JBQWtCLEVBQUVoUSxNQUFNLENBQUM4TyxPQUFPO1FBQ3BDLENBQUM7UUFDRGpOLGFBQWEsRUFBRSxDQUFDb04sV0FBVztNQUM3QixDQUFDLENBQUM7TUFDRixPQUFPLE1BQU0xUCxXQUFXLENBQUNvRCxPQUFPLENBQUNsRCxNQUFNLEVBQUVxQixPQUFPLENBQUNOLEVBQUUsQ0FBQztJQUN2RDtJQUVBLE9BQU9NLE9BQU87RUFDaEI7QUFDRjtBQUFDbVAsT0FBQSxDQUFBMVEsV0FBQSxHQUFBQSxXQUFBIn0=