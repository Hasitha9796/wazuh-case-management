"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.buildRuleSetQuery = buildRuleSetQuery;
exports.describeNode = describeNode;
exports.evaluateCondition = evaluateCondition;
exports.evaluateNode = evaluateNode;
exports.findMatchingRule = findMatchingRule;
exports.getFieldValues = getFieldValues;
exports.levelThresholdCriteria = levelThresholdCriteria;
exports.matchesRule = matchesRule;
exports.normalizeNode = normalizeNode;
exports.normalizeRules = normalizeRules;
exports.resolveSeverity = resolveSeverity;
exports.severityFromLevel = severityFromLevel;
exports.splitList = splitList;
var _constants = require("../../common/constants");
/*
 * Wazuh Case Management Plugin
 * Rule Engine: boolean criteria evaluation for auto-monitor rules
 *
 * A rule's criteria is a tree of AND / OR / NOT groups over leaf conditions
 * such as `rule.level >= 12`, `rule.groups is one of [authentication_failed,
 * web_scan]`, `rule.id is none of [5710]`.
 *
 * Matching happens in two stages:
 *   1. toQuery()  builds a *lenient* OpenSearch pre-filter. It is guaranteed to
 *      return a superset of the matching alerts, never fewer. Conditions that
 *      cannot be translated safely (substring matches, negations, text fields
 *      whose mapping varies between Wazuh versions) simply drop out of the
 *      query rather than risking a false negative.
 *   2. matches()  evaluates the full tree in JavaScript against each fetched
 *      alert and is the authority on whether a rule actually matched.
 */

/** Fields whose mapping is a stable keyword/numeric across Wazuh versions. */
const RELIABLE_QUERY_FIELDS = new Set(['rule.level', 'rule.id', 'rule.groups', 'rule.mitre.id', 'rule.mitre.tactic', 'agent.id', 'agent.name', 'agent.ip', 'location', 'decoder.name', 'data.srcip', 'data.dstuser']);

/** Operators that translate to an OpenSearch clause without changing semantics. */
const RELIABLE_QUERY_OPERATORS = new Set(['eq', 'gt', 'gte', 'lt', 'lte', 'in', 'exists']);

// ─── Value helpers ──────────────────────────────────────────────

/** Read a dotted path out of an alert, flattening arrays along the way. */
function getFieldValues(source, path) {
  const parts = path.split('.');
  let current = [source];
  for (const part of parts) {
    const next = [];
    for (const node of current) {
      if (node === null || node === undefined) continue;
      const value = node[part];
      if (value === null || value === undefined) continue;
      if (Array.isArray(value)) next.push(...value);else next.push(value);
    }
    current = next;
    if (current.length === 0) return [];
  }
  return current;
}

/** Split a comma-separated condition value into trimmed, non-empty items. */
function splitList(value) {
  return String(value !== null && value !== void 0 ? value : '').split(',').map(v => v.trim()).filter(v => v.length > 0);
}
function asNumber(value) {
  const n = typeof value === 'number' ? value : parseFloat(String(value));
  return Number.isNaN(n) ? null : n;
}

// ─── Condition evaluation ───────────────────────────────────────

function evaluateCondition(alert, condition) {
  var _condition$value;
  const values = getFieldValues(alert, condition.field);
  const raw = (_condition$value = condition.value) !== null && _condition$value !== void 0 ? _condition$value : '';
  const op = condition.operator;
  if (op === 'exists') return values.length > 0 && values.some(v => v !== '');
  if (op === 'not_exists') return !(values.length > 0 && values.some(v => v !== ''));

  // Every remaining operator needs at least one value to compare against.
  if (values.length === 0) {
    // A missing field cannot equal anything, but it also doesn't equal the
    // target, so negative operators are satisfied.
    return op === 'neq' || op === 'not_in' || op === 'not_contains';
  }
  switch (op) {
    case 'eq':
      return values.some(v => looseEquals(v, raw));
    case 'neq':
      return !values.some(v => looseEquals(v, raw));
    case 'gt':
    case 'gte':
    case 'lt':
    case 'lte':
      {
        const target = asNumber(raw);
        if (target === null) return false;
        return values.some(v => {
          const n = asNumber(v);
          if (n === null) return false;
          if (op === 'gt') return n > target;
          if (op === 'gte') return n >= target;
          if (op === 'lt') return n < target;
          return n <= target;
        });
      }
    case 'in':
      {
        const list = splitList(raw);
        return values.some(v => list.some(item => looseEquals(v, item)));
      }
    case 'not_in':
      {
        const list = splitList(raw);
        return !values.some(v => list.some(item => looseEquals(v, item)));
      }
    case 'contains':
      {
        const needle = raw.toLowerCase();
        return values.some(v => String(v).toLowerCase().includes(needle));
      }
    case 'not_contains':
      {
        const needle = raw.toLowerCase();
        return !values.some(v => String(v).toLowerCase().includes(needle));
      }
    case 'starts_with':
      {
        const needle = raw.toLowerCase();
        return values.some(v => String(v).toLowerCase().startsWith(needle));
      }
    default:
      return false;
  }
}

/** Compare numerically when both sides look numeric, otherwise as strings. */
function looseEquals(a, b) {
  const na = asNumber(a);
  const nb = asNumber(b);
  if (na !== null && nb !== null) return na === nb;
  return String(a).toLowerCase() === String(b).toLowerCase();
}

// ─── Tree evaluation ────────────────────────────────────────────

function evaluateNode(alert, node) {
  if (!node) return false;
  if (node.type === 'condition') {
    return evaluateCondition(alert, node);
  }
  const children = node.children || [];
  switch (node.logic) {
    case 'AND':
      // An empty AND group matches everything. It imposes no constraint.
      return children.every(child => evaluateNode(alert, child));
    case 'OR':
      // An empty OR group matches nothing.
      return children.length > 0 && children.some(child => evaluateNode(alert, child));
    case 'NOT':
      // NOT matches when none of its children match.
      return !children.some(child => evaluateNode(alert, child));
    default:
      return false;
  }
}

/** Does this alert satisfy the rule's criteria? */
function matchesRule(alert, rule) {
  if (!rule.enabled) return false;
  if (!rule.criteria) return false;
  return evaluateNode(alert, rule.criteria);
}

// ─── Query translation (lenient pre-filter) ─────────────────────

/**
 * Translate a node into an OpenSearch clause, or null when it cannot be
 * translated without risking false negatives.
 */
function nodeToQuery(node) {
  if (!node) return null;
  if (node.type === 'condition') {
    return conditionToQuery(node);
  }
  const children = node.children || [];
  if (node.logic === 'AND') {
    // Dropping untranslatable children only widens the result set, which is safe.
    const clauses = children.map(nodeToQuery).filter(c => c !== null);
    if (clauses.length === 0) return null;
    return {
      bool: {
        filter: clauses
      }
    };
  }
  if (node.logic === 'OR') {
    // An OR is only safe if *every* branch translates; otherwise the untranslated
    // branch's matches would be excluded.
    if (children.length === 0) return null;
    const clauses = children.map(nodeToQuery);
    if (clauses.some(c => c === null)) return null;
    return {
      bool: {
        should: clauses,
        minimum_should_match: 1
      }
    };
  }

  // NOT is left to the JavaScript pass.
  return null;
}
function conditionToQuery(condition) {
  var _condition$value2;
  const {
    field,
    operator
  } = condition;
  const value = (_condition$value2 = condition.value) !== null && _condition$value2 !== void 0 ? _condition$value2 : '';
  if (!RELIABLE_QUERY_FIELDS.has(field)) return null;
  if (!RELIABLE_QUERY_OPERATORS.has(operator)) return null;
  if (!_constants.VALUELESS_OPERATORS.includes(operator) && value === '') return null;
  switch (operator) {
    case 'eq':
      return {
        term: {
          [field]: value
        }
      };
    case 'in':
      {
        const list = splitList(value);
        return list.length ? {
          terms: {
            [field]: list
          }
        } : null;
      }
    case 'gt':
    case 'gte':
    case 'lt':
    case 'lte':
      {
        const n = asNumber(value);
        return n === null ? null : {
          range: {
            [field]: {
              [operator]: n
            }
          }
        };
      }
    case 'exists':
      return {
        exists: {
          field
        }
      };
    default:
      return null;
  }
}

/**
 * Build the pre-filter for a whole rule set: the union of each rule's clauses.
 * Returns null when at least one rule cannot be pre-filtered, meaning the scan
 * must consider every alert in the window.
 */
function buildRuleSetQuery(rules) {
  const enabled = rules.filter(r => r.enabled);
  if (enabled.length === 0) return null;
  const clauses = [];
  for (const rule of enabled) {
    const clause = nodeToQuery(rule.criteria);
    if (clause === null) return null; // this rule needs the full window
    clauses.push(clause);
  }
  return {
    bool: {
      should: clauses,
      minimum_should_match: 1
    }
  };
}

// ─── Rule application ───────────────────────────────────────────

/** Map a Wazuh rule.level onto a case severity. */
function severityFromLevel(level) {
  const entry = _constants.LEVEL_SEVERITY_MAP.find(e => level >= e.min);
  return (entry === null || entry === void 0 ? void 0 : entry.severity) || 'low';
}

/** Resolve the severity a rule assigns to an alert ('auto' derives from level). */
function resolveSeverity(rule, alert) {
  if (rule.severity && rule.severity !== 'auto') return rule.severity;
  const level = Number(getFieldValues(alert, 'rule.level')[0]) || 0;
  return severityFromLevel(level);
}

/**
 * Find the first rule (in `order`) whose criteria the alert satisfies.
 * Returns null when no rule matches.
 */
function findMatchingRule(alert, rules) {
  const ordered = [...rules].filter(r => r.enabled).sort((a, b) => {
    var _a$order, _b$order;
    return ((_a$order = a.order) !== null && _a$order !== void 0 ? _a$order : 0) - ((_b$order = b.order) !== null && _b$order !== void 0 ? _b$order : 0);
  });
  for (const rule of ordered) {
    if (matchesRule(alert, rule)) return rule;
  }
  return null;
}

/** Describe a criteria tree in one human-readable line (for logs and the UI). */
function describeNode(node) {
  if (!node) return '';
  if (node.type === 'condition') {
    if (_constants.VALUELESS_OPERATORS.includes(node.operator)) {
      return `${node.field} ${node.operator.replace('_', ' ')}`;
    }
    return `${node.field} ${node.operator} ${node.value}`;
  }
  const parts = (node.children || []).map(describeNode).filter(Boolean);
  if (parts.length === 0) return '';
  if (node.logic === 'NOT') return `NOT (${parts.join(' OR ')})`;
  return `(${parts.join(` ${node.logic} `)})`;
}

/** A criteria tree equivalent to the legacy `min_level` threshold. */
function levelThresholdCriteria(minLevel) {
  return {
    type: 'group',
    logic: 'AND',
    children: [{
      type: 'condition',
      field: 'rule.level',
      operator: 'gte',
      value: String(minLevel)
    }]
  };
}

// ─── Input normalisation ────────────────────────────────────────

const VALID_LOGIC = ['AND', 'OR', 'NOT'];
const VALID_OPERATORS = ['eq', 'neq', 'gt', 'gte', 'lt', 'lte', 'in', 'not_in', 'contains', 'not_contains', 'starts_with', 'exists', 'not_exists'];

/** Depth limit on the criteria tree. Guards against pathological input. */
const MAX_DEPTH = 6;

/**
 * Coerce a client-supplied criteria tree into a well-formed one, dropping
 * anything unrecognised. The rule builder sends free-form JSON, so this is the
 * validation boundary.
 */
function normalizeNode(input, depth = 0) {
  if (!input || typeof input !== 'object' || depth > MAX_DEPTH) return null;
  if (input.type === 'group' || Array.isArray(input.children)) {
    const logic = VALID_LOGIC.includes(input.logic) ? input.logic : 'AND';
    const children = (Array.isArray(input.children) ? input.children : []).map(child => normalizeNode(child, depth + 1)).filter(child => child !== null);
    return {
      type: 'group',
      logic,
      children
    };
  }
  const field = typeof input.field === 'string' ? input.field.trim() : '';
  if (!field) return null;
  const operator = VALID_OPERATORS.includes(input.operator) ? input.operator : 'eq';
  const value = input.value === undefined || input.value === null ? '' : String(input.value);
  return {
    type: 'condition',
    field,
    operator,
    value
  };
}

/** Coerce a client-supplied rule list into well-formed rules. */
function normalizeRules(input) {
  if (!Array.isArray(input)) return [];
  return input.map((raw, index) => {
    if (!raw || typeof raw !== 'object') return null;
    const criteria = normalizeNode(raw.criteria);
    const root = criteria && criteria.type === 'group' ? criteria : {
      type: 'group',
      logic: 'AND',
      children: criteria ? [criteria] : []
    };
    return {
      id: String(raw.id || `rule-${Date.now()}-${index}`),
      name: String(raw.name || `Rule ${index + 1}`).substring(0, 120),
      enabled: raw.enabled !== false,
      order: Number.isFinite(raw.order) ? Number(raw.order) : index,
      criteria: root,
      priority: ['P1', 'P2', 'P3', 'P4'].includes(raw.priority) ? raw.priority : 'P3',
      severity: raw.severity || 'auto',
      category: String(raw.category || 'other'),
      tlp: raw.tlp,
      assignee: raw.assignee || null,
      tags: Array.isArray(raw.tags) ? raw.tags.map(String).slice(0, 20) : [],
      stop_on_match: raw.stop_on_match !== false,
      max_cases_per_scan: Number.isFinite(raw.max_cases_per_scan) ? Number(raw.max_cases_per_scan) : undefined,
      cases_created: Number.isFinite(raw.cases_created) ? Number(raw.cases_created) : 0
    };
  }).filter(r => r !== null).slice(0, 50);
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfY29uc3RhbnRzIiwicmVxdWlyZSIsIlJFTElBQkxFX1FVRVJZX0ZJRUxEUyIsIlNldCIsIlJFTElBQkxFX1FVRVJZX09QRVJBVE9SUyIsImdldEZpZWxkVmFsdWVzIiwic291cmNlIiwicGF0aCIsInBhcnRzIiwic3BsaXQiLCJjdXJyZW50IiwicGFydCIsIm5leHQiLCJub2RlIiwidW5kZWZpbmVkIiwidmFsdWUiLCJBcnJheSIsImlzQXJyYXkiLCJwdXNoIiwibGVuZ3RoIiwic3BsaXRMaXN0IiwiU3RyaW5nIiwibWFwIiwidiIsInRyaW0iLCJmaWx0ZXIiLCJhc051bWJlciIsIm4iLCJwYXJzZUZsb2F0IiwiTnVtYmVyIiwiaXNOYU4iLCJldmFsdWF0ZUNvbmRpdGlvbiIsImFsZXJ0IiwiY29uZGl0aW9uIiwiX2NvbmRpdGlvbiR2YWx1ZSIsInZhbHVlcyIsImZpZWxkIiwicmF3Iiwib3AiLCJvcGVyYXRvciIsInNvbWUiLCJsb29zZUVxdWFscyIsInRhcmdldCIsImxpc3QiLCJpdGVtIiwibmVlZGxlIiwidG9Mb3dlckNhc2UiLCJpbmNsdWRlcyIsInN0YXJ0c1dpdGgiLCJhIiwiYiIsIm5hIiwibmIiLCJldmFsdWF0ZU5vZGUiLCJ0eXBlIiwiY2hpbGRyZW4iLCJsb2dpYyIsImV2ZXJ5IiwiY2hpbGQiLCJtYXRjaGVzUnVsZSIsInJ1bGUiLCJlbmFibGVkIiwiY3JpdGVyaWEiLCJub2RlVG9RdWVyeSIsImNvbmRpdGlvblRvUXVlcnkiLCJjbGF1c2VzIiwiYyIsImJvb2wiLCJzaG91bGQiLCJtaW5pbXVtX3Nob3VsZF9tYXRjaCIsIl9jb25kaXRpb24kdmFsdWUyIiwiaGFzIiwiVkFMVUVMRVNTX09QRVJBVE9SUyIsInRlcm0iLCJ0ZXJtcyIsInJhbmdlIiwiZXhpc3RzIiwiYnVpbGRSdWxlU2V0UXVlcnkiLCJydWxlcyIsInIiLCJjbGF1c2UiLCJzZXZlcml0eUZyb21MZXZlbCIsImxldmVsIiwiZW50cnkiLCJMRVZFTF9TRVZFUklUWV9NQVAiLCJmaW5kIiwiZSIsIm1pbiIsInNldmVyaXR5IiwicmVzb2x2ZVNldmVyaXR5IiwiZmluZE1hdGNoaW5nUnVsZSIsIm9yZGVyZWQiLCJzb3J0IiwiX2Ekb3JkZXIiLCJfYiRvcmRlciIsIm9yZGVyIiwiZGVzY3JpYmVOb2RlIiwicmVwbGFjZSIsIkJvb2xlYW4iLCJqb2luIiwibGV2ZWxUaHJlc2hvbGRDcml0ZXJpYSIsIm1pbkxldmVsIiwiVkFMSURfTE9HSUMiLCJWQUxJRF9PUEVSQVRPUlMiLCJNQVhfREVQVEgiLCJub3JtYWxpemVOb2RlIiwiaW5wdXQiLCJkZXB0aCIsIm5vcm1hbGl6ZVJ1bGVzIiwiaW5kZXgiLCJyb290IiwiaWQiLCJEYXRlIiwibm93IiwibmFtZSIsInN1YnN0cmluZyIsImlzRmluaXRlIiwicHJpb3JpdHkiLCJjYXRlZ29yeSIsInRscCIsImFzc2lnbmVlIiwidGFncyIsInNsaWNlIiwic3RvcF9vbl9tYXRjaCIsIm1heF9jYXNlc19wZXJfc2NhbiIsImNhc2VzX2NyZWF0ZWQiXSwic291cmNlcyI6WyJydWxlX2VuZ2luZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogV2F6dWggQ2FzZSBNYW5hZ2VtZW50IFBsdWdpblxuICogUnVsZSBFbmdpbmU6IGJvb2xlYW4gY3JpdGVyaWEgZXZhbHVhdGlvbiBmb3IgYXV0by1tb25pdG9yIHJ1bGVzXG4gKlxuICogQSBydWxlJ3MgY3JpdGVyaWEgaXMgYSB0cmVlIG9mIEFORCAvIE9SIC8gTk9UIGdyb3VwcyBvdmVyIGxlYWYgY29uZGl0aW9uc1xuICogc3VjaCBhcyBgcnVsZS5sZXZlbCA+PSAxMmAsIGBydWxlLmdyb3VwcyBpcyBvbmUgb2YgW2F1dGhlbnRpY2F0aW9uX2ZhaWxlZCxcbiAqIHdlYl9zY2FuXWAsIGBydWxlLmlkIGlzIG5vbmUgb2YgWzU3MTBdYC5cbiAqXG4gKiBNYXRjaGluZyBoYXBwZW5zIGluIHR3byBzdGFnZXM6XG4gKiAgIDEuIHRvUXVlcnkoKSAgYnVpbGRzIGEgKmxlbmllbnQqIE9wZW5TZWFyY2ggcHJlLWZpbHRlci4gSXQgaXMgZ3VhcmFudGVlZCB0b1xuICogICAgICByZXR1cm4gYSBzdXBlcnNldCBvZiB0aGUgbWF0Y2hpbmcgYWxlcnRzLCBuZXZlciBmZXdlci4gQ29uZGl0aW9ucyB0aGF0XG4gKiAgICAgIGNhbm5vdCBiZSB0cmFuc2xhdGVkIHNhZmVseSAoc3Vic3RyaW5nIG1hdGNoZXMsIG5lZ2F0aW9ucywgdGV4dCBmaWVsZHNcbiAqICAgICAgd2hvc2UgbWFwcGluZyB2YXJpZXMgYmV0d2VlbiBXYXp1aCB2ZXJzaW9ucykgc2ltcGx5IGRyb3Agb3V0IG9mIHRoZVxuICogICAgICBxdWVyeSByYXRoZXIgdGhhbiByaXNraW5nIGEgZmFsc2UgbmVnYXRpdmUuXG4gKiAgIDIuIG1hdGNoZXMoKSAgZXZhbHVhdGVzIHRoZSBmdWxsIHRyZWUgaW4gSmF2YVNjcmlwdCBhZ2FpbnN0IGVhY2ggZmV0Y2hlZFxuICogICAgICBhbGVydCBhbmQgaXMgdGhlIGF1dGhvcml0eSBvbiB3aGV0aGVyIGEgcnVsZSBhY3R1YWxseSBtYXRjaGVkLlxuICovXG5cbmltcG9ydCB7XG4gIE1vbml0b3JDb25kaXRpb24sXG4gIE1vbml0b3JDb25kaXRpb25Hcm91cCxcbiAgTW9uaXRvck5vZGUsXG4gIE1vbml0b3JSdWxlLFxuICBDYXNlU2V2ZXJpdHksXG59IGZyb20gJy4uLy4uL2NvbW1vbi90eXBlcyc7XG5pbXBvcnQgeyBMRVZFTF9TRVZFUklUWV9NQVAsIFZBTFVFTEVTU19PUEVSQVRPUlMgfSBmcm9tICcuLi8uLi9jb21tb24vY29uc3RhbnRzJztcblxuLyoqIEZpZWxkcyB3aG9zZSBtYXBwaW5nIGlzIGEgc3RhYmxlIGtleXdvcmQvbnVtZXJpYyBhY3Jvc3MgV2F6dWggdmVyc2lvbnMuICovXG5jb25zdCBSRUxJQUJMRV9RVUVSWV9GSUVMRFMgPSBuZXcgU2V0KFtcbiAgJ3J1bGUubGV2ZWwnLFxuICAncnVsZS5pZCcsXG4gICdydWxlLmdyb3VwcycsXG4gICdydWxlLm1pdHJlLmlkJyxcbiAgJ3J1bGUubWl0cmUudGFjdGljJyxcbiAgJ2FnZW50LmlkJyxcbiAgJ2FnZW50Lm5hbWUnLFxuICAnYWdlbnQuaXAnLFxuICAnbG9jYXRpb24nLFxuICAnZGVjb2Rlci5uYW1lJyxcbiAgJ2RhdGEuc3JjaXAnLFxuICAnZGF0YS5kc3R1c2VyJyxcbl0pO1xuXG4vKiogT3BlcmF0b3JzIHRoYXQgdHJhbnNsYXRlIHRvIGFuIE9wZW5TZWFyY2ggY2xhdXNlIHdpdGhvdXQgY2hhbmdpbmcgc2VtYW50aWNzLiAqL1xuY29uc3QgUkVMSUFCTEVfUVVFUllfT1BFUkFUT1JTID0gbmV3IFNldChbJ2VxJywgJ2d0JywgJ2d0ZScsICdsdCcsICdsdGUnLCAnaW4nLCAnZXhpc3RzJ10pO1xuXG4vLyDilIDilIDilIAgVmFsdWUgaGVscGVycyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuLyoqIFJlYWQgYSBkb3R0ZWQgcGF0aCBvdXQgb2YgYW4gYWxlcnQsIGZsYXR0ZW5pbmcgYXJyYXlzIGFsb25nIHRoZSB3YXkuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0RmllbGRWYWx1ZXMoc291cmNlOiBhbnksIHBhdGg6IHN0cmluZyk6IGFueVtdIHtcbiAgY29uc3QgcGFydHMgPSBwYXRoLnNwbGl0KCcuJyk7XG4gIGxldCBjdXJyZW50OiBhbnlbXSA9IFtzb3VyY2VdO1xuXG4gIGZvciAoY29uc3QgcGFydCBvZiBwYXJ0cykge1xuICAgIGNvbnN0IG5leHQ6IGFueVtdID0gW107XG4gICAgZm9yIChjb25zdCBub2RlIG9mIGN1cnJlbnQpIHtcbiAgICAgIGlmIChub2RlID09PSBudWxsIHx8IG5vZGUgPT09IHVuZGVmaW5lZCkgY29udGludWU7XG4gICAgICBjb25zdCB2YWx1ZSA9IG5vZGVbcGFydF07XG4gICAgICBpZiAodmFsdWUgPT09IG51bGwgfHwgdmFsdWUgPT09IHVuZGVmaW5lZCkgY29udGludWU7XG4gICAgICBpZiAoQXJyYXkuaXNBcnJheSh2YWx1ZSkpIG5leHQucHVzaCguLi52YWx1ZSk7XG4gICAgICBlbHNlIG5leHQucHVzaCh2YWx1ZSk7XG4gICAgfVxuICAgIGN1cnJlbnQgPSBuZXh0O1xuICAgIGlmIChjdXJyZW50Lmxlbmd0aCA9PT0gMCkgcmV0dXJuIFtdO1xuICB9XG5cbiAgcmV0dXJuIGN1cnJlbnQ7XG59XG5cbi8qKiBTcGxpdCBhIGNvbW1hLXNlcGFyYXRlZCBjb25kaXRpb24gdmFsdWUgaW50byB0cmltbWVkLCBub24tZW1wdHkgaXRlbXMuICovXG5leHBvcnQgZnVuY3Rpb24gc3BsaXRMaXN0KHZhbHVlOiBzdHJpbmcpOiBzdHJpbmdbXSB7XG4gIHJldHVybiBTdHJpbmcodmFsdWUgPz8gJycpXG4gICAgLnNwbGl0KCcsJylcbiAgICAubWFwKCh2KSA9PiB2LnRyaW0oKSlcbiAgICAuZmlsdGVyKCh2KSA9PiB2Lmxlbmd0aCA+IDApO1xufVxuXG5mdW5jdGlvbiBhc051bWJlcih2YWx1ZTogYW55KTogbnVtYmVyIHwgbnVsbCB7XG4gIGNvbnN0IG4gPSB0eXBlb2YgdmFsdWUgPT09ICdudW1iZXInID8gdmFsdWUgOiBwYXJzZUZsb2F0KFN0cmluZyh2YWx1ZSkpO1xuICByZXR1cm4gTnVtYmVyLmlzTmFOKG4pID8gbnVsbCA6IG47XG59XG5cbi8vIOKUgOKUgOKUgCBDb25kaXRpb24gZXZhbHVhdGlvbiDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuZXhwb3J0IGZ1bmN0aW9uIGV2YWx1YXRlQ29uZGl0aW9uKGFsZXJ0OiBhbnksIGNvbmRpdGlvbjogTW9uaXRvckNvbmRpdGlvbik6IGJvb2xlYW4ge1xuICBjb25zdCB2YWx1ZXMgPSBnZXRGaWVsZFZhbHVlcyhhbGVydCwgY29uZGl0aW9uLmZpZWxkKTtcbiAgY29uc3QgcmF3ID0gY29uZGl0aW9uLnZhbHVlID8/ICcnO1xuICBjb25zdCBvcCA9IGNvbmRpdGlvbi5vcGVyYXRvcjtcblxuICBpZiAob3AgPT09ICdleGlzdHMnKSByZXR1cm4gdmFsdWVzLmxlbmd0aCA+IDAgJiYgdmFsdWVzLnNvbWUoKHYpID0+IHYgIT09ICcnKTtcbiAgaWYgKG9wID09PSAnbm90X2V4aXN0cycpIHJldHVybiAhKHZhbHVlcy5sZW5ndGggPiAwICYmIHZhbHVlcy5zb21lKCh2KSA9PiB2ICE9PSAnJykpO1xuXG4gIC8vIEV2ZXJ5IHJlbWFpbmluZyBvcGVyYXRvciBuZWVkcyBhdCBsZWFzdCBvbmUgdmFsdWUgdG8gY29tcGFyZSBhZ2FpbnN0LlxuICBpZiAodmFsdWVzLmxlbmd0aCA9PT0gMCkge1xuICAgIC8vIEEgbWlzc2luZyBmaWVsZCBjYW5ub3QgZXF1YWwgYW55dGhpbmcsIGJ1dCBpdCBhbHNvIGRvZXNuJ3QgZXF1YWwgdGhlXG4gICAgLy8gdGFyZ2V0LCBzbyBuZWdhdGl2ZSBvcGVyYXRvcnMgYXJlIHNhdGlzZmllZC5cbiAgICByZXR1cm4gb3AgPT09ICduZXEnIHx8IG9wID09PSAnbm90X2luJyB8fCBvcCA9PT0gJ25vdF9jb250YWlucyc7XG4gIH1cblxuICBzd2l0Y2ggKG9wKSB7XG4gICAgY2FzZSAnZXEnOlxuICAgICAgcmV0dXJuIHZhbHVlcy5zb21lKCh2KSA9PiBsb29zZUVxdWFscyh2LCByYXcpKTtcbiAgICBjYXNlICduZXEnOlxuICAgICAgcmV0dXJuICF2YWx1ZXMuc29tZSgodikgPT4gbG9vc2VFcXVhbHModiwgcmF3KSk7XG5cbiAgICBjYXNlICdndCc6XG4gICAgY2FzZSAnZ3RlJzpcbiAgICBjYXNlICdsdCc6XG4gICAgY2FzZSAnbHRlJzoge1xuICAgICAgY29uc3QgdGFyZ2V0ID0gYXNOdW1iZXIocmF3KTtcbiAgICAgIGlmICh0YXJnZXQgPT09IG51bGwpIHJldHVybiBmYWxzZTtcbiAgICAgIHJldHVybiB2YWx1ZXMuc29tZSgodikgPT4ge1xuICAgICAgICBjb25zdCBuID0gYXNOdW1iZXIodik7XG4gICAgICAgIGlmIChuID09PSBudWxsKSByZXR1cm4gZmFsc2U7XG4gICAgICAgIGlmIChvcCA9PT0gJ2d0JykgcmV0dXJuIG4gPiB0YXJnZXQ7XG4gICAgICAgIGlmIChvcCA9PT0gJ2d0ZScpIHJldHVybiBuID49IHRhcmdldDtcbiAgICAgICAgaWYgKG9wID09PSAnbHQnKSByZXR1cm4gbiA8IHRhcmdldDtcbiAgICAgICAgcmV0dXJuIG4gPD0gdGFyZ2V0O1xuICAgICAgfSk7XG4gICAgfVxuXG4gICAgY2FzZSAnaW4nOiB7XG4gICAgICBjb25zdCBsaXN0ID0gc3BsaXRMaXN0KHJhdyk7XG4gICAgICByZXR1cm4gdmFsdWVzLnNvbWUoKHYpID0+IGxpc3Quc29tZSgoaXRlbSkgPT4gbG9vc2VFcXVhbHModiwgaXRlbSkpKTtcbiAgICB9XG4gICAgY2FzZSAnbm90X2luJzoge1xuICAgICAgY29uc3QgbGlzdCA9IHNwbGl0TGlzdChyYXcpO1xuICAgICAgcmV0dXJuICF2YWx1ZXMuc29tZSgodikgPT4gbGlzdC5zb21lKChpdGVtKSA9PiBsb29zZUVxdWFscyh2LCBpdGVtKSkpO1xuICAgIH1cblxuICAgIGNhc2UgJ2NvbnRhaW5zJzoge1xuICAgICAgY29uc3QgbmVlZGxlID0gcmF3LnRvTG93ZXJDYXNlKCk7XG4gICAgICByZXR1cm4gdmFsdWVzLnNvbWUoKHYpID0+IFN0cmluZyh2KS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKG5lZWRsZSkpO1xuICAgIH1cbiAgICBjYXNlICdub3RfY29udGFpbnMnOiB7XG4gICAgICBjb25zdCBuZWVkbGUgPSByYXcudG9Mb3dlckNhc2UoKTtcbiAgICAgIHJldHVybiAhdmFsdWVzLnNvbWUoKHYpID0+IFN0cmluZyh2KS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKG5lZWRsZSkpO1xuICAgIH1cbiAgICBjYXNlICdzdGFydHNfd2l0aCc6IHtcbiAgICAgIGNvbnN0IG5lZWRsZSA9IHJhdy50b0xvd2VyQ2FzZSgpO1xuICAgICAgcmV0dXJuIHZhbHVlcy5zb21lKCh2KSA9PiBTdHJpbmcodikudG9Mb3dlckNhc2UoKS5zdGFydHNXaXRoKG5lZWRsZSkpO1xuICAgIH1cblxuICAgIGRlZmF1bHQ6XG4gICAgICByZXR1cm4gZmFsc2U7XG4gIH1cbn1cblxuLyoqIENvbXBhcmUgbnVtZXJpY2FsbHkgd2hlbiBib3RoIHNpZGVzIGxvb2sgbnVtZXJpYywgb3RoZXJ3aXNlIGFzIHN0cmluZ3MuICovXG5mdW5jdGlvbiBsb29zZUVxdWFscyhhOiBhbnksIGI6IGFueSk6IGJvb2xlYW4ge1xuICBjb25zdCBuYSA9IGFzTnVtYmVyKGEpO1xuICBjb25zdCBuYiA9IGFzTnVtYmVyKGIpO1xuICBpZiAobmEgIT09IG51bGwgJiYgbmIgIT09IG51bGwpIHJldHVybiBuYSA9PT0gbmI7XG4gIHJldHVybiBTdHJpbmcoYSkudG9Mb3dlckNhc2UoKSA9PT0gU3RyaW5nKGIpLnRvTG93ZXJDYXNlKCk7XG59XG5cbi8vIOKUgOKUgOKUgCBUcmVlIGV2YWx1YXRpb24g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbmV4cG9ydCBmdW5jdGlvbiBldmFsdWF0ZU5vZGUoYWxlcnQ6IGFueSwgbm9kZTogTW9uaXRvck5vZGUpOiBib29sZWFuIHtcbiAgaWYgKCFub2RlKSByZXR1cm4gZmFsc2U7XG5cbiAgaWYgKG5vZGUudHlwZSA9PT0gJ2NvbmRpdGlvbicpIHtcbiAgICByZXR1cm4gZXZhbHVhdGVDb25kaXRpb24oYWxlcnQsIG5vZGUpO1xuICB9XG5cbiAgY29uc3QgY2hpbGRyZW4gPSBub2RlLmNoaWxkcmVuIHx8IFtdO1xuXG4gIHN3aXRjaCAobm9kZS5sb2dpYykge1xuICAgIGNhc2UgJ0FORCc6XG4gICAgICAvLyBBbiBlbXB0eSBBTkQgZ3JvdXAgbWF0Y2hlcyBldmVyeXRoaW5nLiBJdCBpbXBvc2VzIG5vIGNvbnN0cmFpbnQuXG4gICAgICByZXR1cm4gY2hpbGRyZW4uZXZlcnkoKGNoaWxkKSA9PiBldmFsdWF0ZU5vZGUoYWxlcnQsIGNoaWxkKSk7XG4gICAgY2FzZSAnT1InOlxuICAgICAgLy8gQW4gZW1wdHkgT1IgZ3JvdXAgbWF0Y2hlcyBub3RoaW5nLlxuICAgICAgcmV0dXJuIGNoaWxkcmVuLmxlbmd0aCA+IDAgJiYgY2hpbGRyZW4uc29tZSgoY2hpbGQpID0+IGV2YWx1YXRlTm9kZShhbGVydCwgY2hpbGQpKTtcbiAgICBjYXNlICdOT1QnOlxuICAgICAgLy8gTk9UIG1hdGNoZXMgd2hlbiBub25lIG9mIGl0cyBjaGlsZHJlbiBtYXRjaC5cbiAgICAgIHJldHVybiAhY2hpbGRyZW4uc29tZSgoY2hpbGQpID0+IGV2YWx1YXRlTm9kZShhbGVydCwgY2hpbGQpKTtcbiAgICBkZWZhdWx0OlxuICAgICAgcmV0dXJuIGZhbHNlO1xuICB9XG59XG5cbi8qKiBEb2VzIHRoaXMgYWxlcnQgc2F0aXNmeSB0aGUgcnVsZSdzIGNyaXRlcmlhPyAqL1xuZXhwb3J0IGZ1bmN0aW9uIG1hdGNoZXNSdWxlKGFsZXJ0OiBhbnksIHJ1bGU6IE1vbml0b3JSdWxlKTogYm9vbGVhbiB7XG4gIGlmICghcnVsZS5lbmFibGVkKSByZXR1cm4gZmFsc2U7XG4gIGlmICghcnVsZS5jcml0ZXJpYSkgcmV0dXJuIGZhbHNlO1xuICByZXR1cm4gZXZhbHVhdGVOb2RlKGFsZXJ0LCBydWxlLmNyaXRlcmlhKTtcbn1cblxuLy8g4pSA4pSA4pSAIFF1ZXJ5IHRyYW5zbGF0aW9uIChsZW5pZW50IHByZS1maWx0ZXIpIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG4vKipcbiAqIFRyYW5zbGF0ZSBhIG5vZGUgaW50byBhbiBPcGVuU2VhcmNoIGNsYXVzZSwgb3IgbnVsbCB3aGVuIGl0IGNhbm5vdCBiZVxuICogdHJhbnNsYXRlZCB3aXRob3V0IHJpc2tpbmcgZmFsc2UgbmVnYXRpdmVzLlxuICovXG5mdW5jdGlvbiBub2RlVG9RdWVyeShub2RlOiBNb25pdG9yTm9kZSk6IGFueSB8IG51bGwge1xuICBpZiAoIW5vZGUpIHJldHVybiBudWxsO1xuXG4gIGlmIChub2RlLnR5cGUgPT09ICdjb25kaXRpb24nKSB7XG4gICAgcmV0dXJuIGNvbmRpdGlvblRvUXVlcnkobm9kZSk7XG4gIH1cblxuICBjb25zdCBjaGlsZHJlbiA9IG5vZGUuY2hpbGRyZW4gfHwgW107XG5cbiAgaWYgKG5vZGUubG9naWMgPT09ICdBTkQnKSB7XG4gICAgLy8gRHJvcHBpbmcgdW50cmFuc2xhdGFibGUgY2hpbGRyZW4gb25seSB3aWRlbnMgdGhlIHJlc3VsdCBzZXQsIHdoaWNoIGlzIHNhZmUuXG4gICAgY29uc3QgY2xhdXNlcyA9IGNoaWxkcmVuLm1hcChub2RlVG9RdWVyeSkuZmlsdGVyKChjKTogYyBpcyBhbnkgPT4gYyAhPT0gbnVsbCk7XG4gICAgaWYgKGNsYXVzZXMubGVuZ3RoID09PSAwKSByZXR1cm4gbnVsbDtcbiAgICByZXR1cm4geyBib29sOiB7IGZpbHRlcjogY2xhdXNlcyB9IH07XG4gIH1cblxuICBpZiAobm9kZS5sb2dpYyA9PT0gJ09SJykge1xuICAgIC8vIEFuIE9SIGlzIG9ubHkgc2FmZSBpZiAqZXZlcnkqIGJyYW5jaCB0cmFuc2xhdGVzOyBvdGhlcndpc2UgdGhlIHVudHJhbnNsYXRlZFxuICAgIC8vIGJyYW5jaCdzIG1hdGNoZXMgd291bGQgYmUgZXhjbHVkZWQuXG4gICAgaWYgKGNoaWxkcmVuLmxlbmd0aCA9PT0gMCkgcmV0dXJuIG51bGw7XG4gICAgY29uc3QgY2xhdXNlcyA9IGNoaWxkcmVuLm1hcChub2RlVG9RdWVyeSk7XG4gICAgaWYgKGNsYXVzZXMuc29tZSgoYykgPT4gYyA9PT0gbnVsbCkpIHJldHVybiBudWxsO1xuICAgIHJldHVybiB7IGJvb2w6IHsgc2hvdWxkOiBjbGF1c2VzLCBtaW5pbXVtX3Nob3VsZF9tYXRjaDogMSB9IH07XG4gIH1cblxuICAvLyBOT1QgaXMgbGVmdCB0byB0aGUgSmF2YVNjcmlwdCBwYXNzLlxuICByZXR1cm4gbnVsbDtcbn1cblxuZnVuY3Rpb24gY29uZGl0aW9uVG9RdWVyeShjb25kaXRpb246IE1vbml0b3JDb25kaXRpb24pOiBhbnkgfCBudWxsIHtcbiAgY29uc3QgeyBmaWVsZCwgb3BlcmF0b3IgfSA9IGNvbmRpdGlvbjtcbiAgY29uc3QgdmFsdWUgPSBjb25kaXRpb24udmFsdWUgPz8gJyc7XG5cbiAgaWYgKCFSRUxJQUJMRV9RVUVSWV9GSUVMRFMuaGFzKGZpZWxkKSkgcmV0dXJuIG51bGw7XG4gIGlmICghUkVMSUFCTEVfUVVFUllfT1BFUkFUT1JTLmhhcyhvcGVyYXRvcikpIHJldHVybiBudWxsO1xuICBpZiAoIVZBTFVFTEVTU19PUEVSQVRPUlMuaW5jbHVkZXMob3BlcmF0b3IpICYmIHZhbHVlID09PSAnJykgcmV0dXJuIG51bGw7XG5cbiAgc3dpdGNoIChvcGVyYXRvcikge1xuICAgIGNhc2UgJ2VxJzpcbiAgICAgIHJldHVybiB7IHRlcm06IHsgW2ZpZWxkXTogdmFsdWUgfSB9O1xuICAgIGNhc2UgJ2luJzoge1xuICAgICAgY29uc3QgbGlzdCA9IHNwbGl0TGlzdCh2YWx1ZSk7XG4gICAgICByZXR1cm4gbGlzdC5sZW5ndGggPyB7IHRlcm1zOiB7IFtmaWVsZF06IGxpc3QgfSB9IDogbnVsbDtcbiAgICB9XG4gICAgY2FzZSAnZ3QnOlxuICAgIGNhc2UgJ2d0ZSc6XG4gICAgY2FzZSAnbHQnOlxuICAgIGNhc2UgJ2x0ZSc6IHtcbiAgICAgIGNvbnN0IG4gPSBhc051bWJlcih2YWx1ZSk7XG4gICAgICByZXR1cm4gbiA9PT0gbnVsbCA/IG51bGwgOiB7IHJhbmdlOiB7IFtmaWVsZF06IHsgW29wZXJhdG9yXTogbiB9IH0gfTtcbiAgICB9XG4gICAgY2FzZSAnZXhpc3RzJzpcbiAgICAgIHJldHVybiB7IGV4aXN0czogeyBmaWVsZCB9IH07XG4gICAgZGVmYXVsdDpcbiAgICAgIHJldHVybiBudWxsO1xuICB9XG59XG5cbi8qKlxuICogQnVpbGQgdGhlIHByZS1maWx0ZXIgZm9yIGEgd2hvbGUgcnVsZSBzZXQ6IHRoZSB1bmlvbiBvZiBlYWNoIHJ1bGUncyBjbGF1c2VzLlxuICogUmV0dXJucyBudWxsIHdoZW4gYXQgbGVhc3Qgb25lIHJ1bGUgY2Fubm90IGJlIHByZS1maWx0ZXJlZCwgbWVhbmluZyB0aGUgc2NhblxuICogbXVzdCBjb25zaWRlciBldmVyeSBhbGVydCBpbiB0aGUgd2luZG93LlxuICovXG5leHBvcnQgZnVuY3Rpb24gYnVpbGRSdWxlU2V0UXVlcnkocnVsZXM6IE1vbml0b3JSdWxlW10pOiBhbnkgfCBudWxsIHtcbiAgY29uc3QgZW5hYmxlZCA9IHJ1bGVzLmZpbHRlcigocikgPT4gci5lbmFibGVkKTtcbiAgaWYgKGVuYWJsZWQubGVuZ3RoID09PSAwKSByZXR1cm4gbnVsbDtcblxuICBjb25zdCBjbGF1c2VzOiBhbnlbXSA9IFtdO1xuICBmb3IgKGNvbnN0IHJ1bGUgb2YgZW5hYmxlZCkge1xuICAgIGNvbnN0IGNsYXVzZSA9IG5vZGVUb1F1ZXJ5KHJ1bGUuY3JpdGVyaWEpO1xuICAgIGlmIChjbGF1c2UgPT09IG51bGwpIHJldHVybiBudWxsOyAvLyB0aGlzIHJ1bGUgbmVlZHMgdGhlIGZ1bGwgd2luZG93XG4gICAgY2xhdXNlcy5wdXNoKGNsYXVzZSk7XG4gIH1cblxuICByZXR1cm4geyBib29sOiB7IHNob3VsZDogY2xhdXNlcywgbWluaW11bV9zaG91bGRfbWF0Y2g6IDEgfSB9O1xufVxuXG4vLyDilIDilIDilIAgUnVsZSBhcHBsaWNhdGlvbiDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuLyoqIE1hcCBhIFdhenVoIHJ1bGUubGV2ZWwgb250byBhIGNhc2Ugc2V2ZXJpdHkuICovXG5leHBvcnQgZnVuY3Rpb24gc2V2ZXJpdHlGcm9tTGV2ZWwobGV2ZWw6IG51bWJlcik6IENhc2VTZXZlcml0eSB7XG4gIGNvbnN0IGVudHJ5ID0gTEVWRUxfU0VWRVJJVFlfTUFQLmZpbmQoKGUpID0+IGxldmVsID49IGUubWluKTtcbiAgcmV0dXJuIChlbnRyeT8uc2V2ZXJpdHkgfHwgJ2xvdycpIGFzIENhc2VTZXZlcml0eTtcbn1cblxuLyoqIFJlc29sdmUgdGhlIHNldmVyaXR5IGEgcnVsZSBhc3NpZ25zIHRvIGFuIGFsZXJ0ICgnYXV0bycgZGVyaXZlcyBmcm9tIGxldmVsKS4gKi9cbmV4cG9ydCBmdW5jdGlvbiByZXNvbHZlU2V2ZXJpdHkocnVsZTogTW9uaXRvclJ1bGUsIGFsZXJ0OiBhbnkpOiBDYXNlU2V2ZXJpdHkge1xuICBpZiAocnVsZS5zZXZlcml0eSAmJiBydWxlLnNldmVyaXR5ICE9PSAnYXV0bycpIHJldHVybiBydWxlLnNldmVyaXR5O1xuICBjb25zdCBsZXZlbCA9IE51bWJlcihnZXRGaWVsZFZhbHVlcyhhbGVydCwgJ3J1bGUubGV2ZWwnKVswXSkgfHwgMDtcbiAgcmV0dXJuIHNldmVyaXR5RnJvbUxldmVsKGxldmVsKTtcbn1cblxuLyoqXG4gKiBGaW5kIHRoZSBmaXJzdCBydWxlIChpbiBgb3JkZXJgKSB3aG9zZSBjcml0ZXJpYSB0aGUgYWxlcnQgc2F0aXNmaWVzLlxuICogUmV0dXJucyBudWxsIHdoZW4gbm8gcnVsZSBtYXRjaGVzLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZmluZE1hdGNoaW5nUnVsZShhbGVydDogYW55LCBydWxlczogTW9uaXRvclJ1bGVbXSk6IE1vbml0b3JSdWxlIHwgbnVsbCB7XG4gIGNvbnN0IG9yZGVyZWQgPSBbLi4ucnVsZXNdXG4gICAgLmZpbHRlcigocikgPT4gci5lbmFibGVkKVxuICAgIC5zb3J0KChhLCBiKSA9PiAoYS5vcmRlciA/PyAwKSAtIChiLm9yZGVyID8/IDApKTtcblxuICBmb3IgKGNvbnN0IHJ1bGUgb2Ygb3JkZXJlZCkge1xuICAgIGlmIChtYXRjaGVzUnVsZShhbGVydCwgcnVsZSkpIHJldHVybiBydWxlO1xuICB9XG4gIHJldHVybiBudWxsO1xufVxuXG4vKiogRGVzY3JpYmUgYSBjcml0ZXJpYSB0cmVlIGluIG9uZSBodW1hbi1yZWFkYWJsZSBsaW5lIChmb3IgbG9ncyBhbmQgdGhlIFVJKS4gKi9cbmV4cG9ydCBmdW5jdGlvbiBkZXNjcmliZU5vZGUobm9kZTogTW9uaXRvck5vZGUpOiBzdHJpbmcge1xuICBpZiAoIW5vZGUpIHJldHVybiAnJztcblxuICBpZiAobm9kZS50eXBlID09PSAnY29uZGl0aW9uJykge1xuICAgIGlmIChWQUxVRUxFU1NfT1BFUkFUT1JTLmluY2x1ZGVzKG5vZGUub3BlcmF0b3IpKSB7XG4gICAgICByZXR1cm4gYCR7bm9kZS5maWVsZH0gJHtub2RlLm9wZXJhdG9yLnJlcGxhY2UoJ18nLCAnICcpfWA7XG4gICAgfVxuICAgIHJldHVybiBgJHtub2RlLmZpZWxkfSAke25vZGUub3BlcmF0b3J9ICR7bm9kZS52YWx1ZX1gO1xuICB9XG5cbiAgY29uc3QgcGFydHMgPSAobm9kZS5jaGlsZHJlbiB8fCBbXSkubWFwKGRlc2NyaWJlTm9kZSkuZmlsdGVyKEJvb2xlYW4pO1xuICBpZiAocGFydHMubGVuZ3RoID09PSAwKSByZXR1cm4gJyc7XG4gIGlmIChub2RlLmxvZ2ljID09PSAnTk9UJykgcmV0dXJuIGBOT1QgKCR7cGFydHMuam9pbignIE9SICcpfSlgO1xuICByZXR1cm4gYCgke3BhcnRzLmpvaW4oYCAke25vZGUubG9naWN9IGApfSlgO1xufVxuXG4vKiogQSBjcml0ZXJpYSB0cmVlIGVxdWl2YWxlbnQgdG8gdGhlIGxlZ2FjeSBgbWluX2xldmVsYCB0aHJlc2hvbGQuICovXG5leHBvcnQgZnVuY3Rpb24gbGV2ZWxUaHJlc2hvbGRDcml0ZXJpYShtaW5MZXZlbDogbnVtYmVyKTogTW9uaXRvckNvbmRpdGlvbkdyb3VwIHtcbiAgcmV0dXJuIHtcbiAgICB0eXBlOiAnZ3JvdXAnLFxuICAgIGxvZ2ljOiAnQU5EJyxcbiAgICBjaGlsZHJlbjogW1xuICAgICAgeyB0eXBlOiAnY29uZGl0aW9uJywgZmllbGQ6ICdydWxlLmxldmVsJywgb3BlcmF0b3I6ICdndGUnLCB2YWx1ZTogU3RyaW5nKG1pbkxldmVsKSB9LFxuICAgIF0sXG4gIH07XG59XG5cbi8vIOKUgOKUgOKUgCBJbnB1dCBub3JtYWxpc2F0aW9uIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG5jb25zdCBWQUxJRF9MT0dJQyA9IFsnQU5EJywgJ09SJywgJ05PVCddO1xuY29uc3QgVkFMSURfT1BFUkFUT1JTID0gW1xuICAnZXEnLCAnbmVxJywgJ2d0JywgJ2d0ZScsICdsdCcsICdsdGUnLCAnaW4nLCAnbm90X2luJyxcbiAgJ2NvbnRhaW5zJywgJ25vdF9jb250YWlucycsICdzdGFydHNfd2l0aCcsICdleGlzdHMnLCAnbm90X2V4aXN0cycsXG5dO1xuXG4vKiogRGVwdGggbGltaXQgb24gdGhlIGNyaXRlcmlhIHRyZWUuIEd1YXJkcyBhZ2FpbnN0IHBhdGhvbG9naWNhbCBpbnB1dC4gKi9cbmNvbnN0IE1BWF9ERVBUSCA9IDY7XG5cbi8qKlxuICogQ29lcmNlIGEgY2xpZW50LXN1cHBsaWVkIGNyaXRlcmlhIHRyZWUgaW50byBhIHdlbGwtZm9ybWVkIG9uZSwgZHJvcHBpbmdcbiAqIGFueXRoaW5nIHVucmVjb2duaXNlZC4gVGhlIHJ1bGUgYnVpbGRlciBzZW5kcyBmcmVlLWZvcm0gSlNPTiwgc28gdGhpcyBpcyB0aGVcbiAqIHZhbGlkYXRpb24gYm91bmRhcnkuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBub3JtYWxpemVOb2RlKGlucHV0OiBhbnksIGRlcHRoID0gMCk6IE1vbml0b3JOb2RlIHwgbnVsbCB7XG4gIGlmICghaW5wdXQgfHwgdHlwZW9mIGlucHV0ICE9PSAnb2JqZWN0JyB8fCBkZXB0aCA+IE1BWF9ERVBUSCkgcmV0dXJuIG51bGw7XG5cbiAgaWYgKGlucHV0LnR5cGUgPT09ICdncm91cCcgfHwgQXJyYXkuaXNBcnJheShpbnB1dC5jaGlsZHJlbikpIHtcbiAgICBjb25zdCBsb2dpYyA9IFZBTElEX0xPR0lDLmluY2x1ZGVzKGlucHV0LmxvZ2ljKSA/IGlucHV0LmxvZ2ljIDogJ0FORCc7XG4gICAgY29uc3QgY2hpbGRyZW4gPSAoQXJyYXkuaXNBcnJheShpbnB1dC5jaGlsZHJlbikgPyBpbnB1dC5jaGlsZHJlbiA6IFtdKVxuICAgICAgLm1hcCgoY2hpbGQ6IGFueSkgPT4gbm9ybWFsaXplTm9kZShjaGlsZCwgZGVwdGggKyAxKSlcbiAgICAgIC5maWx0ZXIoKGNoaWxkOiBNb25pdG9yTm9kZSB8IG51bGwpOiBjaGlsZCBpcyBNb25pdG9yTm9kZSA9PiBjaGlsZCAhPT0gbnVsbCk7XG4gICAgcmV0dXJuIHsgdHlwZTogJ2dyb3VwJywgbG9naWMsIGNoaWxkcmVuIH0gYXMgTW9uaXRvckNvbmRpdGlvbkdyb3VwO1xuICB9XG5cbiAgY29uc3QgZmllbGQgPSB0eXBlb2YgaW5wdXQuZmllbGQgPT09ICdzdHJpbmcnID8gaW5wdXQuZmllbGQudHJpbSgpIDogJyc7XG4gIGlmICghZmllbGQpIHJldHVybiBudWxsO1xuICBjb25zdCBvcGVyYXRvciA9IFZBTElEX09QRVJBVE9SUy5pbmNsdWRlcyhpbnB1dC5vcGVyYXRvcikgPyBpbnB1dC5vcGVyYXRvciA6ICdlcSc7XG4gIGNvbnN0IHZhbHVlID0gaW5wdXQudmFsdWUgPT09IHVuZGVmaW5lZCB8fCBpbnB1dC52YWx1ZSA9PT0gbnVsbCA/ICcnIDogU3RyaW5nKGlucHV0LnZhbHVlKTtcblxuICByZXR1cm4geyB0eXBlOiAnY29uZGl0aW9uJywgZmllbGQsIG9wZXJhdG9yLCB2YWx1ZSB9IGFzIE1vbml0b3JDb25kaXRpb247XG59XG5cbi8qKiBDb2VyY2UgYSBjbGllbnQtc3VwcGxpZWQgcnVsZSBsaXN0IGludG8gd2VsbC1mb3JtZWQgcnVsZXMuICovXG5leHBvcnQgZnVuY3Rpb24gbm9ybWFsaXplUnVsZXMoaW5wdXQ6IGFueSk6IE1vbml0b3JSdWxlW10ge1xuICBpZiAoIUFycmF5LmlzQXJyYXkoaW5wdXQpKSByZXR1cm4gW107XG5cbiAgcmV0dXJuIGlucHV0XG4gICAgLm1hcCgocmF3OiBhbnksIGluZGV4OiBudW1iZXIpOiBNb25pdG9yUnVsZSB8IG51bGwgPT4ge1xuICAgICAgaWYgKCFyYXcgfHwgdHlwZW9mIHJhdyAhPT0gJ29iamVjdCcpIHJldHVybiBudWxsO1xuXG4gICAgICBjb25zdCBjcml0ZXJpYSA9IG5vcm1hbGl6ZU5vZGUocmF3LmNyaXRlcmlhKTtcbiAgICAgIGNvbnN0IHJvb3Q6IE1vbml0b3JDb25kaXRpb25Hcm91cCA9XG4gICAgICAgIGNyaXRlcmlhICYmIGNyaXRlcmlhLnR5cGUgPT09ICdncm91cCdcbiAgICAgICAgICA/IGNyaXRlcmlhXG4gICAgICAgICAgOiB7IHR5cGU6ICdncm91cCcsIGxvZ2ljOiAnQU5EJywgY2hpbGRyZW46IGNyaXRlcmlhID8gW2NyaXRlcmlhXSA6IFtdIH07XG5cbiAgICAgIHJldHVybiB7XG4gICAgICAgIGlkOiBTdHJpbmcocmF3LmlkIHx8IGBydWxlLSR7RGF0ZS5ub3coKX0tJHtpbmRleH1gKSxcbiAgICAgICAgbmFtZTogU3RyaW5nKHJhdy5uYW1lIHx8IGBSdWxlICR7aW5kZXggKyAxfWApLnN1YnN0cmluZygwLCAxMjApLFxuICAgICAgICBlbmFibGVkOiByYXcuZW5hYmxlZCAhPT0gZmFsc2UsXG4gICAgICAgIG9yZGVyOiBOdW1iZXIuaXNGaW5pdGUocmF3Lm9yZGVyKSA/IE51bWJlcihyYXcub3JkZXIpIDogaW5kZXgsXG4gICAgICAgIGNyaXRlcmlhOiByb290LFxuICAgICAgICBwcmlvcml0eTogWydQMScsICdQMicsICdQMycsICdQNCddLmluY2x1ZGVzKHJhdy5wcmlvcml0eSkgPyByYXcucHJpb3JpdHkgOiAnUDMnLFxuICAgICAgICBzZXZlcml0eTogcmF3LnNldmVyaXR5IHx8ICdhdXRvJyxcbiAgICAgICAgY2F0ZWdvcnk6IFN0cmluZyhyYXcuY2F0ZWdvcnkgfHwgJ290aGVyJyksXG4gICAgICAgIHRscDogcmF3LnRscCxcbiAgICAgICAgYXNzaWduZWU6IHJhdy5hc3NpZ25lZSB8fCBudWxsLFxuICAgICAgICB0YWdzOiBBcnJheS5pc0FycmF5KHJhdy50YWdzKSA/IHJhdy50YWdzLm1hcChTdHJpbmcpLnNsaWNlKDAsIDIwKSA6IFtdLFxuICAgICAgICBzdG9wX29uX21hdGNoOiByYXcuc3RvcF9vbl9tYXRjaCAhPT0gZmFsc2UsXG4gICAgICAgIG1heF9jYXNlc19wZXJfc2NhbjogTnVtYmVyLmlzRmluaXRlKHJhdy5tYXhfY2FzZXNfcGVyX3NjYW4pXG4gICAgICAgICAgPyBOdW1iZXIocmF3Lm1heF9jYXNlc19wZXJfc2NhbilcbiAgICAgICAgICA6IHVuZGVmaW5lZCxcbiAgICAgICAgY2FzZXNfY3JlYXRlZDogTnVtYmVyLmlzRmluaXRlKHJhdy5jYXNlc19jcmVhdGVkKSA/IE51bWJlcihyYXcuY2FzZXNfY3JlYXRlZCkgOiAwLFxuICAgICAgfSBhcyBNb25pdG9yUnVsZTtcbiAgICB9KVxuICAgIC5maWx0ZXIoKHIpOiByIGlzIE1vbml0b3JSdWxlID0+IHIgIT09IG51bGwpXG4gICAgLnNsaWNlKDAsIDUwKTtcbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBeUJBLElBQUFBLFVBQUEsR0FBQUMsT0FBQTtBQXpCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQVdBO0FBQ0EsTUFBTUMscUJBQXFCLEdBQUcsSUFBSUMsR0FBRyxDQUFDLENBQ3BDLFlBQVksRUFDWixTQUFTLEVBQ1QsYUFBYSxFQUNiLGVBQWUsRUFDZixtQkFBbUIsRUFDbkIsVUFBVSxFQUNWLFlBQVksRUFDWixVQUFVLEVBQ1YsVUFBVSxFQUNWLGNBQWMsRUFDZCxZQUFZLEVBQ1osY0FBYyxDQUNmLENBQUM7O0FBRUY7QUFDQSxNQUFNQyx3QkFBd0IsR0FBRyxJQUFJRCxHQUFHLENBQUMsQ0FBQyxJQUFJLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxRQUFRLENBQUMsQ0FBQzs7QUFFMUY7O0FBRUE7QUFDTyxTQUFTRSxjQUFjQSxDQUFDQyxNQUFXLEVBQUVDLElBQVksRUFBUztFQUMvRCxNQUFNQyxLQUFLLEdBQUdELElBQUksQ0FBQ0UsS0FBSyxDQUFDLEdBQUcsQ0FBQztFQUM3QixJQUFJQyxPQUFjLEdBQUcsQ0FBQ0osTUFBTSxDQUFDO0VBRTdCLEtBQUssTUFBTUssSUFBSSxJQUFJSCxLQUFLLEVBQUU7SUFDeEIsTUFBTUksSUFBVyxHQUFHLEVBQUU7SUFDdEIsS0FBSyxNQUFNQyxJQUFJLElBQUlILE9BQU8sRUFBRTtNQUMxQixJQUFJRyxJQUFJLEtBQUssSUFBSSxJQUFJQSxJQUFJLEtBQUtDLFNBQVMsRUFBRTtNQUN6QyxNQUFNQyxLQUFLLEdBQUdGLElBQUksQ0FBQ0YsSUFBSSxDQUFDO01BQ3hCLElBQUlJLEtBQUssS0FBSyxJQUFJLElBQUlBLEtBQUssS0FBS0QsU0FBUyxFQUFFO01BQzNDLElBQUlFLEtBQUssQ0FBQ0MsT0FBTyxDQUFDRixLQUFLLENBQUMsRUFBRUgsSUFBSSxDQUFDTSxJQUFJLENBQUMsR0FBR0gsS0FBSyxDQUFDLENBQUMsS0FDekNILElBQUksQ0FBQ00sSUFBSSxDQUFDSCxLQUFLLENBQUM7SUFDdkI7SUFDQUwsT0FBTyxHQUFHRSxJQUFJO0lBQ2QsSUFBSUYsT0FBTyxDQUFDUyxNQUFNLEtBQUssQ0FBQyxFQUFFLE9BQU8sRUFBRTtFQUNyQztFQUVBLE9BQU9ULE9BQU87QUFDaEI7O0FBRUE7QUFDTyxTQUFTVSxTQUFTQSxDQUFDTCxLQUFhLEVBQVk7RUFDakQsT0FBT00sTUFBTSxDQUFDTixLQUFLLGFBQUxBLEtBQUssY0FBTEEsS0FBSyxHQUFJLEVBQUUsQ0FBQyxDQUN2Qk4sS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUNWYSxHQUFHLENBQUVDLENBQUMsSUFBS0EsQ0FBQyxDQUFDQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQ3BCQyxNQUFNLENBQUVGLENBQUMsSUFBS0EsQ0FBQyxDQUFDSixNQUFNLEdBQUcsQ0FBQyxDQUFDO0FBQ2hDO0FBRUEsU0FBU08sUUFBUUEsQ0FBQ1gsS0FBVSxFQUFpQjtFQUMzQyxNQUFNWSxDQUFDLEdBQUcsT0FBT1osS0FBSyxLQUFLLFFBQVEsR0FBR0EsS0FBSyxHQUFHYSxVQUFVLENBQUNQLE1BQU0sQ0FBQ04sS0FBSyxDQUFDLENBQUM7RUFDdkUsT0FBT2MsTUFBTSxDQUFDQyxLQUFLLENBQUNILENBQUMsQ0FBQyxHQUFHLElBQUksR0FBR0EsQ0FBQztBQUNuQzs7QUFFQTs7QUFFTyxTQUFTSSxpQkFBaUJBLENBQUNDLEtBQVUsRUFBRUMsU0FBMkIsRUFBVztFQUFBLElBQUFDLGdCQUFBO0VBQ2xGLE1BQU1DLE1BQU0sR0FBRzlCLGNBQWMsQ0FBQzJCLEtBQUssRUFBRUMsU0FBUyxDQUFDRyxLQUFLLENBQUM7RUFDckQsTUFBTUMsR0FBRyxJQUFBSCxnQkFBQSxHQUFHRCxTQUFTLENBQUNsQixLQUFLLGNBQUFtQixnQkFBQSxjQUFBQSxnQkFBQSxHQUFJLEVBQUU7RUFDakMsTUFBTUksRUFBRSxHQUFHTCxTQUFTLENBQUNNLFFBQVE7RUFFN0IsSUFBSUQsRUFBRSxLQUFLLFFBQVEsRUFBRSxPQUFPSCxNQUFNLENBQUNoQixNQUFNLEdBQUcsQ0FBQyxJQUFJZ0IsTUFBTSxDQUFDSyxJQUFJLENBQUVqQixDQUFDLElBQUtBLENBQUMsS0FBSyxFQUFFLENBQUM7RUFDN0UsSUFBSWUsRUFBRSxLQUFLLFlBQVksRUFBRSxPQUFPLEVBQUVILE1BQU0sQ0FBQ2hCLE1BQU0sR0FBRyxDQUFDLElBQUlnQixNQUFNLENBQUNLLElBQUksQ0FBRWpCLENBQUMsSUFBS0EsQ0FBQyxLQUFLLEVBQUUsQ0FBQyxDQUFDOztFQUVwRjtFQUNBLElBQUlZLE1BQU0sQ0FBQ2hCLE1BQU0sS0FBSyxDQUFDLEVBQUU7SUFDdkI7SUFDQTtJQUNBLE9BQU9tQixFQUFFLEtBQUssS0FBSyxJQUFJQSxFQUFFLEtBQUssUUFBUSxJQUFJQSxFQUFFLEtBQUssY0FBYztFQUNqRTtFQUVBLFFBQVFBLEVBQUU7SUFDUixLQUFLLElBQUk7TUFDUCxPQUFPSCxNQUFNLENBQUNLLElBQUksQ0FBRWpCLENBQUMsSUFBS2tCLFdBQVcsQ0FBQ2xCLENBQUMsRUFBRWMsR0FBRyxDQUFDLENBQUM7SUFDaEQsS0FBSyxLQUFLO01BQ1IsT0FBTyxDQUFDRixNQUFNLENBQUNLLElBQUksQ0FBRWpCLENBQUMsSUFBS2tCLFdBQVcsQ0FBQ2xCLENBQUMsRUFBRWMsR0FBRyxDQUFDLENBQUM7SUFFakQsS0FBSyxJQUFJO0lBQ1QsS0FBSyxLQUFLO0lBQ1YsS0FBSyxJQUFJO0lBQ1QsS0FBSyxLQUFLO01BQUU7UUFDVixNQUFNSyxNQUFNLEdBQUdoQixRQUFRLENBQUNXLEdBQUcsQ0FBQztRQUM1QixJQUFJSyxNQUFNLEtBQUssSUFBSSxFQUFFLE9BQU8sS0FBSztRQUNqQyxPQUFPUCxNQUFNLENBQUNLLElBQUksQ0FBRWpCLENBQUMsSUFBSztVQUN4QixNQUFNSSxDQUFDLEdBQUdELFFBQVEsQ0FBQ0gsQ0FBQyxDQUFDO1VBQ3JCLElBQUlJLENBQUMsS0FBSyxJQUFJLEVBQUUsT0FBTyxLQUFLO1VBQzVCLElBQUlXLEVBQUUsS0FBSyxJQUFJLEVBQUUsT0FBT1gsQ0FBQyxHQUFHZSxNQUFNO1VBQ2xDLElBQUlKLEVBQUUsS0FBSyxLQUFLLEVBQUUsT0FBT1gsQ0FBQyxJQUFJZSxNQUFNO1VBQ3BDLElBQUlKLEVBQUUsS0FBSyxJQUFJLEVBQUUsT0FBT1gsQ0FBQyxHQUFHZSxNQUFNO1VBQ2xDLE9BQU9mLENBQUMsSUFBSWUsTUFBTTtRQUNwQixDQUFDLENBQUM7TUFDSjtJQUVBLEtBQUssSUFBSTtNQUFFO1FBQ1QsTUFBTUMsSUFBSSxHQUFHdkIsU0FBUyxDQUFDaUIsR0FBRyxDQUFDO1FBQzNCLE9BQU9GLE1BQU0sQ0FBQ0ssSUFBSSxDQUFFakIsQ0FBQyxJQUFLb0IsSUFBSSxDQUFDSCxJQUFJLENBQUVJLElBQUksSUFBS0gsV0FBVyxDQUFDbEIsQ0FBQyxFQUFFcUIsSUFBSSxDQUFDLENBQUMsQ0FBQztNQUN0RTtJQUNBLEtBQUssUUFBUTtNQUFFO1FBQ2IsTUFBTUQsSUFBSSxHQUFHdkIsU0FBUyxDQUFDaUIsR0FBRyxDQUFDO1FBQzNCLE9BQU8sQ0FBQ0YsTUFBTSxDQUFDSyxJQUFJLENBQUVqQixDQUFDLElBQUtvQixJQUFJLENBQUNILElBQUksQ0FBRUksSUFBSSxJQUFLSCxXQUFXLENBQUNsQixDQUFDLEVBQUVxQixJQUFJLENBQUMsQ0FBQyxDQUFDO01BQ3ZFO0lBRUEsS0FBSyxVQUFVO01BQUU7UUFDZixNQUFNQyxNQUFNLEdBQUdSLEdBQUcsQ0FBQ1MsV0FBVyxDQUFDLENBQUM7UUFDaEMsT0FBT1gsTUFBTSxDQUFDSyxJQUFJLENBQUVqQixDQUFDLElBQUtGLE1BQU0sQ0FBQ0UsQ0FBQyxDQUFDLENBQUN1QixXQUFXLENBQUMsQ0FBQyxDQUFDQyxRQUFRLENBQUNGLE1BQU0sQ0FBQyxDQUFDO01BQ3JFO0lBQ0EsS0FBSyxjQUFjO01BQUU7UUFDbkIsTUFBTUEsTUFBTSxHQUFHUixHQUFHLENBQUNTLFdBQVcsQ0FBQyxDQUFDO1FBQ2hDLE9BQU8sQ0FBQ1gsTUFBTSxDQUFDSyxJQUFJLENBQUVqQixDQUFDLElBQUtGLE1BQU0sQ0FBQ0UsQ0FBQyxDQUFDLENBQUN1QixXQUFXLENBQUMsQ0FBQyxDQUFDQyxRQUFRLENBQUNGLE1BQU0sQ0FBQyxDQUFDO01BQ3RFO0lBQ0EsS0FBSyxhQUFhO01BQUU7UUFDbEIsTUFBTUEsTUFBTSxHQUFHUixHQUFHLENBQUNTLFdBQVcsQ0FBQyxDQUFDO1FBQ2hDLE9BQU9YLE1BQU0sQ0FBQ0ssSUFBSSxDQUFFakIsQ0FBQyxJQUFLRixNQUFNLENBQUNFLENBQUMsQ0FBQyxDQUFDdUIsV0FBVyxDQUFDLENBQUMsQ0FBQ0UsVUFBVSxDQUFDSCxNQUFNLENBQUMsQ0FBQztNQUN2RTtJQUVBO01BQ0UsT0FBTyxLQUFLO0VBQ2hCO0FBQ0Y7O0FBRUE7QUFDQSxTQUFTSixXQUFXQSxDQUFDUSxDQUFNLEVBQUVDLENBQU0sRUFBVztFQUM1QyxNQUFNQyxFQUFFLEdBQUd6QixRQUFRLENBQUN1QixDQUFDLENBQUM7RUFDdEIsTUFBTUcsRUFBRSxHQUFHMUIsUUFBUSxDQUFDd0IsQ0FBQyxDQUFDO0VBQ3RCLElBQUlDLEVBQUUsS0FBSyxJQUFJLElBQUlDLEVBQUUsS0FBSyxJQUFJLEVBQUUsT0FBT0QsRUFBRSxLQUFLQyxFQUFFO0VBQ2hELE9BQU8vQixNQUFNLENBQUM0QixDQUFDLENBQUMsQ0FBQ0gsV0FBVyxDQUFDLENBQUMsS0FBS3pCLE1BQU0sQ0FBQzZCLENBQUMsQ0FBQyxDQUFDSixXQUFXLENBQUMsQ0FBQztBQUM1RDs7QUFFQTs7QUFFTyxTQUFTTyxZQUFZQSxDQUFDckIsS0FBVSxFQUFFbkIsSUFBaUIsRUFBVztFQUNuRSxJQUFJLENBQUNBLElBQUksRUFBRSxPQUFPLEtBQUs7RUFFdkIsSUFBSUEsSUFBSSxDQUFDeUMsSUFBSSxLQUFLLFdBQVcsRUFBRTtJQUM3QixPQUFPdkIsaUJBQWlCLENBQUNDLEtBQUssRUFBRW5CLElBQUksQ0FBQztFQUN2QztFQUVBLE1BQU0wQyxRQUFRLEdBQUcxQyxJQUFJLENBQUMwQyxRQUFRLElBQUksRUFBRTtFQUVwQyxRQUFRMUMsSUFBSSxDQUFDMkMsS0FBSztJQUNoQixLQUFLLEtBQUs7TUFDUjtNQUNBLE9BQU9ELFFBQVEsQ0FBQ0UsS0FBSyxDQUFFQyxLQUFLLElBQUtMLFlBQVksQ0FBQ3JCLEtBQUssRUFBRTBCLEtBQUssQ0FBQyxDQUFDO0lBQzlELEtBQUssSUFBSTtNQUNQO01BQ0EsT0FBT0gsUUFBUSxDQUFDcEMsTUFBTSxHQUFHLENBQUMsSUFBSW9DLFFBQVEsQ0FBQ2YsSUFBSSxDQUFFa0IsS0FBSyxJQUFLTCxZQUFZLENBQUNyQixLQUFLLEVBQUUwQixLQUFLLENBQUMsQ0FBQztJQUNwRixLQUFLLEtBQUs7TUFDUjtNQUNBLE9BQU8sQ0FBQ0gsUUFBUSxDQUFDZixJQUFJLENBQUVrQixLQUFLLElBQUtMLFlBQVksQ0FBQ3JCLEtBQUssRUFBRTBCLEtBQUssQ0FBQyxDQUFDO0lBQzlEO01BQ0UsT0FBTyxLQUFLO0VBQ2hCO0FBQ0Y7O0FBRUE7QUFDTyxTQUFTQyxXQUFXQSxDQUFDM0IsS0FBVSxFQUFFNEIsSUFBaUIsRUFBVztFQUNsRSxJQUFJLENBQUNBLElBQUksQ0FBQ0MsT0FBTyxFQUFFLE9BQU8sS0FBSztFQUMvQixJQUFJLENBQUNELElBQUksQ0FBQ0UsUUFBUSxFQUFFLE9BQU8sS0FBSztFQUNoQyxPQUFPVCxZQUFZLENBQUNyQixLQUFLLEVBQUU0QixJQUFJLENBQUNFLFFBQVEsQ0FBQztBQUMzQzs7QUFFQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVNDLFdBQVdBLENBQUNsRCxJQUFpQixFQUFjO0VBQ2xELElBQUksQ0FBQ0EsSUFBSSxFQUFFLE9BQU8sSUFBSTtFQUV0QixJQUFJQSxJQUFJLENBQUN5QyxJQUFJLEtBQUssV0FBVyxFQUFFO0lBQzdCLE9BQU9VLGdCQUFnQixDQUFDbkQsSUFBSSxDQUFDO0VBQy9CO0VBRUEsTUFBTTBDLFFBQVEsR0FBRzFDLElBQUksQ0FBQzBDLFFBQVEsSUFBSSxFQUFFO0VBRXBDLElBQUkxQyxJQUFJLENBQUMyQyxLQUFLLEtBQUssS0FBSyxFQUFFO0lBQ3hCO0lBQ0EsTUFBTVMsT0FBTyxHQUFHVixRQUFRLENBQUNqQyxHQUFHLENBQUN5QyxXQUFXLENBQUMsQ0FBQ3RDLE1BQU0sQ0FBRXlDLENBQUMsSUFBZUEsQ0FBQyxLQUFLLElBQUksQ0FBQztJQUM3RSxJQUFJRCxPQUFPLENBQUM5QyxNQUFNLEtBQUssQ0FBQyxFQUFFLE9BQU8sSUFBSTtJQUNyQyxPQUFPO01BQUVnRCxJQUFJLEVBQUU7UUFBRTFDLE1BQU0sRUFBRXdDO01BQVE7SUFBRSxDQUFDO0VBQ3RDO0VBRUEsSUFBSXBELElBQUksQ0FBQzJDLEtBQUssS0FBSyxJQUFJLEVBQUU7SUFDdkI7SUFDQTtJQUNBLElBQUlELFFBQVEsQ0FBQ3BDLE1BQU0sS0FBSyxDQUFDLEVBQUUsT0FBTyxJQUFJO0lBQ3RDLE1BQU04QyxPQUFPLEdBQUdWLFFBQVEsQ0FBQ2pDLEdBQUcsQ0FBQ3lDLFdBQVcsQ0FBQztJQUN6QyxJQUFJRSxPQUFPLENBQUN6QixJQUFJLENBQUUwQixDQUFDLElBQUtBLENBQUMsS0FBSyxJQUFJLENBQUMsRUFBRSxPQUFPLElBQUk7SUFDaEQsT0FBTztNQUFFQyxJQUFJLEVBQUU7UUFBRUMsTUFBTSxFQUFFSCxPQUFPO1FBQUVJLG9CQUFvQixFQUFFO01BQUU7SUFBRSxDQUFDO0VBQy9EOztFQUVBO0VBQ0EsT0FBTyxJQUFJO0FBQ2I7QUFFQSxTQUFTTCxnQkFBZ0JBLENBQUMvQixTQUEyQixFQUFjO0VBQUEsSUFBQXFDLGlCQUFBO0VBQ2pFLE1BQU07SUFBRWxDLEtBQUs7SUFBRUc7RUFBUyxDQUFDLEdBQUdOLFNBQVM7RUFDckMsTUFBTWxCLEtBQUssSUFBQXVELGlCQUFBLEdBQUdyQyxTQUFTLENBQUNsQixLQUFLLGNBQUF1RCxpQkFBQSxjQUFBQSxpQkFBQSxHQUFJLEVBQUU7RUFFbkMsSUFBSSxDQUFDcEUscUJBQXFCLENBQUNxRSxHQUFHLENBQUNuQyxLQUFLLENBQUMsRUFBRSxPQUFPLElBQUk7RUFDbEQsSUFBSSxDQUFDaEMsd0JBQXdCLENBQUNtRSxHQUFHLENBQUNoQyxRQUFRLENBQUMsRUFBRSxPQUFPLElBQUk7RUFDeEQsSUFBSSxDQUFDaUMsOEJBQW1CLENBQUN6QixRQUFRLENBQUNSLFFBQVEsQ0FBQyxJQUFJeEIsS0FBSyxLQUFLLEVBQUUsRUFBRSxPQUFPLElBQUk7RUFFeEUsUUFBUXdCLFFBQVE7SUFDZCxLQUFLLElBQUk7TUFDUCxPQUFPO1FBQUVrQyxJQUFJLEVBQUU7VUFBRSxDQUFDckMsS0FBSyxHQUFHckI7UUFBTTtNQUFFLENBQUM7SUFDckMsS0FBSyxJQUFJO01BQUU7UUFDVCxNQUFNNEIsSUFBSSxHQUFHdkIsU0FBUyxDQUFDTCxLQUFLLENBQUM7UUFDN0IsT0FBTzRCLElBQUksQ0FBQ3hCLE1BQU0sR0FBRztVQUFFdUQsS0FBSyxFQUFFO1lBQUUsQ0FBQ3RDLEtBQUssR0FBR087VUFBSztRQUFFLENBQUMsR0FBRyxJQUFJO01BQzFEO0lBQ0EsS0FBSyxJQUFJO0lBQ1QsS0FBSyxLQUFLO0lBQ1YsS0FBSyxJQUFJO0lBQ1QsS0FBSyxLQUFLO01BQUU7UUFDVixNQUFNaEIsQ0FBQyxHQUFHRCxRQUFRLENBQUNYLEtBQUssQ0FBQztRQUN6QixPQUFPWSxDQUFDLEtBQUssSUFBSSxHQUFHLElBQUksR0FBRztVQUFFZ0QsS0FBSyxFQUFFO1lBQUUsQ0FBQ3ZDLEtBQUssR0FBRztjQUFFLENBQUNHLFFBQVEsR0FBR1o7WUFBRTtVQUFFO1FBQUUsQ0FBQztNQUN0RTtJQUNBLEtBQUssUUFBUTtNQUNYLE9BQU87UUFBRWlELE1BQU0sRUFBRTtVQUFFeEM7UUFBTTtNQUFFLENBQUM7SUFDOUI7TUFDRSxPQUFPLElBQUk7RUFDZjtBQUNGOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxTQUFTeUMsaUJBQWlCQSxDQUFDQyxLQUFvQixFQUFjO0VBQ2xFLE1BQU1qQixPQUFPLEdBQUdpQixLQUFLLENBQUNyRCxNQUFNLENBQUVzRCxDQUFDLElBQUtBLENBQUMsQ0FBQ2xCLE9BQU8sQ0FBQztFQUM5QyxJQUFJQSxPQUFPLENBQUMxQyxNQUFNLEtBQUssQ0FBQyxFQUFFLE9BQU8sSUFBSTtFQUVyQyxNQUFNOEMsT0FBYyxHQUFHLEVBQUU7RUFDekIsS0FBSyxNQUFNTCxJQUFJLElBQUlDLE9BQU8sRUFBRTtJQUMxQixNQUFNbUIsTUFBTSxHQUFHakIsV0FBVyxDQUFDSCxJQUFJLENBQUNFLFFBQVEsQ0FBQztJQUN6QyxJQUFJa0IsTUFBTSxLQUFLLElBQUksRUFBRSxPQUFPLElBQUksQ0FBQyxDQUFDO0lBQ2xDZixPQUFPLENBQUMvQyxJQUFJLENBQUM4RCxNQUFNLENBQUM7RUFDdEI7RUFFQSxPQUFPO0lBQUViLElBQUksRUFBRTtNQUFFQyxNQUFNLEVBQUVILE9BQU87TUFBRUksb0JBQW9CLEVBQUU7SUFBRTtFQUFFLENBQUM7QUFDL0Q7O0FBRUE7O0FBRUE7QUFDTyxTQUFTWSxpQkFBaUJBLENBQUNDLEtBQWEsRUFBZ0I7RUFDN0QsTUFBTUMsS0FBSyxHQUFHQyw2QkFBa0IsQ0FBQ0MsSUFBSSxDQUFFQyxDQUFDLElBQUtKLEtBQUssSUFBSUksQ0FBQyxDQUFDQyxHQUFHLENBQUM7RUFDNUQsT0FBUSxDQUFBSixLQUFLLGFBQUxBLEtBQUssdUJBQUxBLEtBQUssQ0FBRUssUUFBUSxLQUFJLEtBQUs7QUFDbEM7O0FBRUE7QUFDTyxTQUFTQyxlQUFlQSxDQUFDN0IsSUFBaUIsRUFBRTVCLEtBQVUsRUFBZ0I7RUFDM0UsSUFBSTRCLElBQUksQ0FBQzRCLFFBQVEsSUFBSTVCLElBQUksQ0FBQzRCLFFBQVEsS0FBSyxNQUFNLEVBQUUsT0FBTzVCLElBQUksQ0FBQzRCLFFBQVE7RUFDbkUsTUFBTU4sS0FBSyxHQUFHckQsTUFBTSxDQUFDeEIsY0FBYyxDQUFDMkIsS0FBSyxFQUFFLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztFQUNqRSxPQUFPaUQsaUJBQWlCLENBQUNDLEtBQUssQ0FBQztBQUNqQzs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLFNBQVNRLGdCQUFnQkEsQ0FBQzFELEtBQVUsRUFBRThDLEtBQW9CLEVBQXNCO0VBQ3JGLE1BQU1hLE9BQU8sR0FBRyxDQUFDLEdBQUdiLEtBQUssQ0FBQyxDQUN2QnJELE1BQU0sQ0FBRXNELENBQUMsSUFBS0EsQ0FBQyxDQUFDbEIsT0FBTyxDQUFDLENBQ3hCK0IsSUFBSSxDQUFDLENBQUMzQyxDQUFDLEVBQUVDLENBQUM7SUFBQSxJQUFBMkMsUUFBQSxFQUFBQyxRQUFBO0lBQUEsT0FBSyxFQUFBRCxRQUFBLEdBQUM1QyxDQUFDLENBQUM4QyxLQUFLLGNBQUFGLFFBQUEsY0FBQUEsUUFBQSxHQUFJLENBQUMsTUFBQUMsUUFBQSxHQUFLNUMsQ0FBQyxDQUFDNkMsS0FBSyxjQUFBRCxRQUFBLGNBQUFBLFFBQUEsR0FBSSxDQUFDLENBQUM7RUFBQSxFQUFDO0VBRWxELEtBQUssTUFBTWxDLElBQUksSUFBSStCLE9BQU8sRUFBRTtJQUMxQixJQUFJaEMsV0FBVyxDQUFDM0IsS0FBSyxFQUFFNEIsSUFBSSxDQUFDLEVBQUUsT0FBT0EsSUFBSTtFQUMzQztFQUNBLE9BQU8sSUFBSTtBQUNiOztBQUVBO0FBQ08sU0FBU29DLFlBQVlBLENBQUNuRixJQUFpQixFQUFVO0VBQ3RELElBQUksQ0FBQ0EsSUFBSSxFQUFFLE9BQU8sRUFBRTtFQUVwQixJQUFJQSxJQUFJLENBQUN5QyxJQUFJLEtBQUssV0FBVyxFQUFFO0lBQzdCLElBQUlrQiw4QkFBbUIsQ0FBQ3pCLFFBQVEsQ0FBQ2xDLElBQUksQ0FBQzBCLFFBQVEsQ0FBQyxFQUFFO01BQy9DLE9BQVEsR0FBRTFCLElBQUksQ0FBQ3VCLEtBQU0sSUFBR3ZCLElBQUksQ0FBQzBCLFFBQVEsQ0FBQzBELE9BQU8sQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFFLEVBQUM7SUFDM0Q7SUFDQSxPQUFRLEdBQUVwRixJQUFJLENBQUN1QixLQUFNLElBQUd2QixJQUFJLENBQUMwQixRQUFTLElBQUcxQixJQUFJLENBQUNFLEtBQU0sRUFBQztFQUN2RDtFQUVBLE1BQU1QLEtBQUssR0FBRyxDQUFDSyxJQUFJLENBQUMwQyxRQUFRLElBQUksRUFBRSxFQUFFakMsR0FBRyxDQUFDMEUsWUFBWSxDQUFDLENBQUN2RSxNQUFNLENBQUN5RSxPQUFPLENBQUM7RUFDckUsSUFBSTFGLEtBQUssQ0FBQ1csTUFBTSxLQUFLLENBQUMsRUFBRSxPQUFPLEVBQUU7RUFDakMsSUFBSU4sSUFBSSxDQUFDMkMsS0FBSyxLQUFLLEtBQUssRUFBRSxPQUFRLFFBQU9oRCxLQUFLLENBQUMyRixJQUFJLENBQUMsTUFBTSxDQUFFLEdBQUU7RUFDOUQsT0FBUSxJQUFHM0YsS0FBSyxDQUFDMkYsSUFBSSxDQUFFLElBQUd0RixJQUFJLENBQUMyQyxLQUFNLEdBQUUsQ0FBRSxHQUFFO0FBQzdDOztBQUVBO0FBQ08sU0FBUzRDLHNCQUFzQkEsQ0FBQ0MsUUFBZ0IsRUFBeUI7RUFDOUUsT0FBTztJQUNML0MsSUFBSSxFQUFFLE9BQU87SUFDYkUsS0FBSyxFQUFFLEtBQUs7SUFDWkQsUUFBUSxFQUFFLENBQ1I7TUFBRUQsSUFBSSxFQUFFLFdBQVc7TUFBRWxCLEtBQUssRUFBRSxZQUFZO01BQUVHLFFBQVEsRUFBRSxLQUFLO01BQUV4QixLQUFLLEVBQUVNLE1BQU0sQ0FBQ2dGLFFBQVE7SUFBRSxDQUFDO0VBRXhGLENBQUM7QUFDSDs7QUFFQTs7QUFFQSxNQUFNQyxXQUFXLEdBQUcsQ0FBQyxLQUFLLEVBQUUsSUFBSSxFQUFFLEtBQUssQ0FBQztBQUN4QyxNQUFNQyxlQUFlLEdBQUcsQ0FDdEIsSUFBSSxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFDckQsVUFBVSxFQUFFLGNBQWMsRUFBRSxhQUFhLEVBQUUsUUFBUSxFQUFFLFlBQVksQ0FDbEU7O0FBRUQ7QUFDQSxNQUFNQyxTQUFTLEdBQUcsQ0FBQzs7QUFFbkI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLFNBQVNDLGFBQWFBLENBQUNDLEtBQVUsRUFBRUMsS0FBSyxHQUFHLENBQUMsRUFBc0I7RUFDdkUsSUFBSSxDQUFDRCxLQUFLLElBQUksT0FBT0EsS0FBSyxLQUFLLFFBQVEsSUFBSUMsS0FBSyxHQUFHSCxTQUFTLEVBQUUsT0FBTyxJQUFJO0VBRXpFLElBQUlFLEtBQUssQ0FBQ3BELElBQUksS0FBSyxPQUFPLElBQUl0QyxLQUFLLENBQUNDLE9BQU8sQ0FBQ3lGLEtBQUssQ0FBQ25ELFFBQVEsQ0FBQyxFQUFFO0lBQzNELE1BQU1DLEtBQUssR0FBRzhDLFdBQVcsQ0FBQ3ZELFFBQVEsQ0FBQzJELEtBQUssQ0FBQ2xELEtBQUssQ0FBQyxHQUFHa0QsS0FBSyxDQUFDbEQsS0FBSyxHQUFHLEtBQUs7SUFDckUsTUFBTUQsUUFBUSxHQUFHLENBQUN2QyxLQUFLLENBQUNDLE9BQU8sQ0FBQ3lGLEtBQUssQ0FBQ25ELFFBQVEsQ0FBQyxHQUFHbUQsS0FBSyxDQUFDbkQsUUFBUSxHQUFHLEVBQUUsRUFDbEVqQyxHQUFHLENBQUVvQyxLQUFVLElBQUsrQyxhQUFhLENBQUMvQyxLQUFLLEVBQUVpRCxLQUFLLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FDcERsRixNQUFNLENBQUVpQyxLQUF5QixJQUEyQkEsS0FBSyxLQUFLLElBQUksQ0FBQztJQUM5RSxPQUFPO01BQUVKLElBQUksRUFBRSxPQUFPO01BQUVFLEtBQUs7TUFBRUQ7SUFBUyxDQUFDO0VBQzNDO0VBRUEsTUFBTW5CLEtBQUssR0FBRyxPQUFPc0UsS0FBSyxDQUFDdEUsS0FBSyxLQUFLLFFBQVEsR0FBR3NFLEtBQUssQ0FBQ3RFLEtBQUssQ0FBQ1osSUFBSSxDQUFDLENBQUMsR0FBRyxFQUFFO0VBQ3ZFLElBQUksQ0FBQ1ksS0FBSyxFQUFFLE9BQU8sSUFBSTtFQUN2QixNQUFNRyxRQUFRLEdBQUdnRSxlQUFlLENBQUN4RCxRQUFRLENBQUMyRCxLQUFLLENBQUNuRSxRQUFRLENBQUMsR0FBR21FLEtBQUssQ0FBQ25FLFFBQVEsR0FBRyxJQUFJO0VBQ2pGLE1BQU14QixLQUFLLEdBQUcyRixLQUFLLENBQUMzRixLQUFLLEtBQUtELFNBQVMsSUFBSTRGLEtBQUssQ0FBQzNGLEtBQUssS0FBSyxJQUFJLEdBQUcsRUFBRSxHQUFHTSxNQUFNLENBQUNxRixLQUFLLENBQUMzRixLQUFLLENBQUM7RUFFMUYsT0FBTztJQUFFdUMsSUFBSSxFQUFFLFdBQVc7SUFBRWxCLEtBQUs7SUFBRUcsUUFBUTtJQUFFeEI7RUFBTSxDQUFDO0FBQ3REOztBQUVBO0FBQ08sU0FBUzZGLGNBQWNBLENBQUNGLEtBQVUsRUFBaUI7RUFDeEQsSUFBSSxDQUFDMUYsS0FBSyxDQUFDQyxPQUFPLENBQUN5RixLQUFLLENBQUMsRUFBRSxPQUFPLEVBQUU7RUFFcEMsT0FBT0EsS0FBSyxDQUNUcEYsR0FBRyxDQUFDLENBQUNlLEdBQVEsRUFBRXdFLEtBQWEsS0FBeUI7SUFDcEQsSUFBSSxDQUFDeEUsR0FBRyxJQUFJLE9BQU9BLEdBQUcsS0FBSyxRQUFRLEVBQUUsT0FBTyxJQUFJO0lBRWhELE1BQU15QixRQUFRLEdBQUcyQyxhQUFhLENBQUNwRSxHQUFHLENBQUN5QixRQUFRLENBQUM7SUFDNUMsTUFBTWdELElBQTJCLEdBQy9CaEQsUUFBUSxJQUFJQSxRQUFRLENBQUNSLElBQUksS0FBSyxPQUFPLEdBQ2pDUSxRQUFRLEdBQ1I7TUFBRVIsSUFBSSxFQUFFLE9BQU87TUFBRUUsS0FBSyxFQUFFLEtBQUs7TUFBRUQsUUFBUSxFQUFFTyxRQUFRLEdBQUcsQ0FBQ0EsUUFBUSxDQUFDLEdBQUc7SUFBRyxDQUFDO0lBRTNFLE9BQU87TUFDTGlELEVBQUUsRUFBRTFGLE1BQU0sQ0FBQ2dCLEdBQUcsQ0FBQzBFLEVBQUUsSUFBSyxRQUFPQyxJQUFJLENBQUNDLEdBQUcsQ0FBQyxDQUFFLElBQUdKLEtBQU0sRUFBQyxDQUFDO01BQ25ESyxJQUFJLEVBQUU3RixNQUFNLENBQUNnQixHQUFHLENBQUM2RSxJQUFJLElBQUssUUFBT0wsS0FBSyxHQUFHLENBQUUsRUFBQyxDQUFDLENBQUNNLFNBQVMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDO01BQy9EdEQsT0FBTyxFQUFFeEIsR0FBRyxDQUFDd0IsT0FBTyxLQUFLLEtBQUs7TUFDOUJrQyxLQUFLLEVBQUVsRSxNQUFNLENBQUN1RixRQUFRLENBQUMvRSxHQUFHLENBQUMwRCxLQUFLLENBQUMsR0FBR2xFLE1BQU0sQ0FBQ1EsR0FBRyxDQUFDMEQsS0FBSyxDQUFDLEdBQUdjLEtBQUs7TUFDN0QvQyxRQUFRLEVBQUVnRCxJQUFJO01BQ2RPLFFBQVEsRUFBRSxDQUFDLElBQUksRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDdEUsUUFBUSxDQUFDVixHQUFHLENBQUNnRixRQUFRLENBQUMsR0FBR2hGLEdBQUcsQ0FBQ2dGLFFBQVEsR0FBRyxJQUFJO01BQy9FN0IsUUFBUSxFQUFFbkQsR0FBRyxDQUFDbUQsUUFBUSxJQUFJLE1BQU07TUFDaEM4QixRQUFRLEVBQUVqRyxNQUFNLENBQUNnQixHQUFHLENBQUNpRixRQUFRLElBQUksT0FBTyxDQUFDO01BQ3pDQyxHQUFHLEVBQUVsRixHQUFHLENBQUNrRixHQUFHO01BQ1pDLFFBQVEsRUFBRW5GLEdBQUcsQ0FBQ21GLFFBQVEsSUFBSSxJQUFJO01BQzlCQyxJQUFJLEVBQUV6RyxLQUFLLENBQUNDLE9BQU8sQ0FBQ29CLEdBQUcsQ0FBQ29GLElBQUksQ0FBQyxHQUFHcEYsR0FBRyxDQUFDb0YsSUFBSSxDQUFDbkcsR0FBRyxDQUFDRCxNQUFNLENBQUMsQ0FBQ3FHLEtBQUssQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLEdBQUcsRUFBRTtNQUN0RUMsYUFBYSxFQUFFdEYsR0FBRyxDQUFDc0YsYUFBYSxLQUFLLEtBQUs7TUFDMUNDLGtCQUFrQixFQUFFL0YsTUFBTSxDQUFDdUYsUUFBUSxDQUFDL0UsR0FBRyxDQUFDdUYsa0JBQWtCLENBQUMsR0FDdkQvRixNQUFNLENBQUNRLEdBQUcsQ0FBQ3VGLGtCQUFrQixDQUFDLEdBQzlCOUcsU0FBUztNQUNiK0csYUFBYSxFQUFFaEcsTUFBTSxDQUFDdUYsUUFBUSxDQUFDL0UsR0FBRyxDQUFDd0YsYUFBYSxDQUFDLEdBQUdoRyxNQUFNLENBQUNRLEdBQUcsQ0FBQ3dGLGFBQWEsQ0FBQyxHQUFHO0lBQ2xGLENBQUM7RUFDSCxDQUFDLENBQUMsQ0FDRHBHLE1BQU0sQ0FBRXNELENBQUMsSUFBdUJBLENBQUMsS0FBSyxJQUFJLENBQUMsQ0FDM0MyQyxLQUFLLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQztBQUNqQiJ9