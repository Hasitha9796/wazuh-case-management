"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.OpenSearchService = void 0;
var _constants = require("../../common/constants");
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); } /*
 * Wazuh Case Management Plugin
 * OpenSearch Service — Low-level OpenSearch client operations
 *
 * Provides reusable CRUD helpers, search, aggregation, and counter management
 * that wrap the OpenSearch client obtained from the request context.
 * This service is stateless — every method receives the client explicitly.
 */
/** A minimal interface representing the scoped OpenSearch client */

/**
 * OpenSearchService — thin wrapper around the scoped OpenSearch client.
 *
 * Design notes:
 *  - Every public method is static so callers don't need to manage instances.
 *  - The `client` parameter must be `context.core.opensearch.client.asCurrentUser`.
 */
class OpenSearchService {
  // ──────────────────────────────────────────────────────────────
  // Index operations
  // ──────────────────────────────────────────────────────────────

  /** Check whether an index already exists */
  static async indexExists(client, index) {
    try {
      const {
        body
      } = await client.indices.exists({
        index
      });
      return body;
    } catch (error) {
      // 404 means it does not exist — not an error
      return false;
    }
  }

  /** Create an index with the given body (settings + mappings) */
  static async createIndex(client, index, body) {
    await client.indices.create({
      index,
      body
    });
  }

  /**
   * Register an index template so that if the index is ever deleted and later
   * auto-created by a write, it is recreated with the correct mapping.
   * This is the durable safeguard against dynamic-mapping drift (e.g. `status`
   * becoming `text` instead of `keyword`).
   */
  static async ensureTemplate(client, name, indexPatterns, mapping) {
    const template = {
      settings: mapping.settings || {},
      mappings: mapping.mappings || {}
    };
    try {
      // Composable index template (OpenSearch 2.x)
      await client.indices.putIndexTemplate({
        name,
        body: {
          index_patterns: indexPatterns,
          template,
          priority: 200
        }
      });
    } catch (e) {
      // Fall back to the legacy template API on older clusters
      await client.indices.putTemplate({
        name,
        body: {
          index_patterns: indexPatterns,
          settings: template.settings,
          mappings: template.mappings
        }
      });
    }
  }

  /**
   * Ensure an index exists with the correct mapping; create it if missing.
   * Idempotent and safe to call before every write. Tolerates the race where
   * another request creates the index first.
   */
  static async ensureIndex(client, index, body) {
    const exists = await OpenSearchService.indexExists(client, index);
    if (exists) return;
    try {
      await client.indices.create({
        index,
        body
      });
    } catch (e) {
      var _e$body, _e$meta;
      const type = (e === null || e === void 0 || (_e$body = e.body) === null || _e$body === void 0 || (_e$body = _e$body.error) === null || _e$body === void 0 ? void 0 : _e$body.type) || (e === null || e === void 0 || (_e$meta = e.meta) === null || _e$meta === void 0 || (_e$meta = _e$meta.body) === null || _e$meta === void 0 || (_e$meta = _e$meta.error) === null || _e$meta === void 0 ? void 0 : _e$meta.type);
      if (type !== 'resource_already_exists_exception') throw e;
    }
  }

  // ──────────────────────────────────────────────────────────────
  // Document CRUD
  // ──────────────────────────────────────────────────────────────

  /**
   * Index (create/overwrite) a document.
   * If `id` is provided the document is stored under that _id, otherwise
   * OpenSearch auto-generates one.
   */
  static async createDocument(client, index, body, id) {
    const params = {
      index,
      body,
      refresh: 'wait_for'
    };
    if (id) params.id = id;
    const {
      body: result
    } = await client.index(params);
    return {
      _id: result._id
    };
  }

  /** Retrieve a single document by _id */
  static async getDocument(client, index, id) {
    try {
      const {
        body
      } = await client.get({
        index,
        id
      });
      return {
        _id: body._id,
        _source: body._source
      };
    } catch (error) {
      var _error$meta;
      if ((error === null || error === void 0 ? void 0 : error.statusCode) === 404 || (error === null || error === void 0 || (_error$meta = error.meta) === null || _error$meta === void 0 ? void 0 : _error$meta.statusCode) === 404) {
        return null;
      }
      throw error;
    }
  }

  /** Partially update a document (merge fields) */
  static async updateDocument(client, index, id, doc) {
    await client.update({
      index,
      id,
      body: {
        doc
      },
      refresh: 'wait_for',
      retry_on_conflict: 3
    });
  }

  /** Delete a document by _id */
  static async deleteDocument(client, index, id) {
    try {
      await client.delete({
        index,
        id,
        refresh: 'wait_for'
      });
      return true;
    } catch (error) {
      var _error$meta2;
      if ((error === null || error === void 0 ? void 0 : error.statusCode) === 404 || (error === null || error === void 0 || (_error$meta2 = error.meta) === null || _error$meta2 === void 0 ? void 0 : _error$meta2.statusCode) === 404) {
        return false;
      }
      throw error;
    }
  }

  // ──────────────────────────────────────────────────────────────
  // Search & Aggregation
  // ──────────────────────────────────────────────────────────────

  /**
   * Perform a search query against an index.
   * Returns the raw hits array together with the total count.
   */
  static async searchDocuments(client, index, body) {
    var _result$hits$total$va, _result$hits$total;
    const {
      body: result
    } = await client.search({
      index,
      body
    });
    const total = typeof result.hits.total === 'number' ? result.hits.total : (_result$hits$total$va = (_result$hits$total = result.hits.total) === null || _result$hits$total === void 0 ? void 0 : _result$hits$total.value) !== null && _result$hits$total$va !== void 0 ? _result$hits$total$va : 0;
    return {
      hits: result.hits.hits,
      total
    };
  }

  /**
   * Run an aggregation-only query (size=0).
   * Returns the raw aggregations object.
   */
  static async aggregateDocuments(client, index, body) {
    var _result$aggregations;
    const {
      body: result
    } = await client.search({
      index,
      body: {
        size: 0,
        ...body
      }
    });
    return (_result$aggregations = result.aggregations) !== null && _result$aggregations !== void 0 ? _result$aggregations : {};
  }

  // ──────────────────────────────────────────────────────────────
  // Counter management for case ID generation
  // ──────────────────────────────────────────────────────────────

  /** The well-known document ID that holds the case counter */

  /**
   * Atomically increment-and-return the case counter.
   * Uses optimistic concurrency control (seq_no + primary_term) instead of
   * Painless scripts, which may be disabled in Wazuh's OpenSearch deployment.
   */
  static async getNextCounterValue(client) {
    const MAX_RETRIES = 10;
    for (let attempt = 0; attempt < MAX_RETRIES; attempt++) {
      let seqNo;
      let primaryTerm;
      let currentValue = 0;

      // Try to read the existing counter document
      try {
        var _body$_source$current, _body$_source;
        const {
          body
        } = await client.get({
          index: _constants.CASE_COUNTER_INDEX,
          id: OpenSearchService.COUNTER_DOC_ID
        });
        seqNo = body._seq_no;
        primaryTerm = body._primary_term;
        currentValue = (_body$_source$current = (_body$_source = body._source) === null || _body$_source === void 0 ? void 0 : _body$_source.current_value) !== null && _body$_source$current !== void 0 ? _body$_source$current : 0;
      } catch (err) {
        var _err$meta;
        // 404 — counter doesn't exist yet, we'll create it below
        if ((err === null || err === void 0 ? void 0 : err.statusCode) !== 404 && (err === null || err === void 0 || (_err$meta = err.meta) === null || _err$meta === void 0 ? void 0 : _err$meta.statusCode) !== 404) {
          throw err;
        }
      }
      const nextValue = currentValue + 1;
      try {
        if (seqNo === undefined) {
          // Create the counter document for the first time
          await client.index({
            index: _constants.CASE_COUNTER_INDEX,
            id: OpenSearchService.COUNTER_DOC_ID,
            body: {
              counter_name: 'case_id',
              current_value: nextValue
            },
            op_type: 'create',
            refresh: 'wait_for'
          });
        } else {
          // Update with optimistic concurrency check
          await client.index({
            index: _constants.CASE_COUNTER_INDEX,
            id: OpenSearchService.COUNTER_DOC_ID,
            body: {
              counter_name: 'case_id',
              current_value: nextValue
            },
            if_seq_no: seqNo,
            if_primary_term: primaryTerm,
            refresh: 'wait_for'
          });
        }
        return nextValue;
      } catch (err) {
        var _err$statusCode, _err$meta2;
        const status = (_err$statusCode = err === null || err === void 0 ? void 0 : err.statusCode) !== null && _err$statusCode !== void 0 ? _err$statusCode : err === null || err === void 0 || (_err$meta2 = err.meta) === null || _err$meta2 === void 0 ? void 0 : _err$meta2.statusCode;
        // 409 conflict means another request updated the counter first — retry
        if (status === 409) {
          continue;
        }
        throw err;
      }
    }

    // Fallback: use timestamp-based value if all retries exhausted
    return Date.now();
  }
}
exports.OpenSearchService = OpenSearchService;
_defineProperty(OpenSearchService, "COUNTER_DOC_ID", 'case_id_counter');
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfY29uc3RhbnRzIiwicmVxdWlyZSIsIl9kZWZpbmVQcm9wZXJ0eSIsImUiLCJyIiwidCIsIl90b1Byb3BlcnR5S2V5IiwiT2JqZWN0IiwiZGVmaW5lUHJvcGVydHkiLCJ2YWx1ZSIsImVudW1lcmFibGUiLCJjb25maWd1cmFibGUiLCJ3cml0YWJsZSIsImkiLCJfdG9QcmltaXRpdmUiLCJTeW1ib2wiLCJ0b1ByaW1pdGl2ZSIsImNhbGwiLCJUeXBlRXJyb3IiLCJTdHJpbmciLCJOdW1iZXIiLCJPcGVuU2VhcmNoU2VydmljZSIsImluZGV4RXhpc3RzIiwiY2xpZW50IiwiaW5kZXgiLCJib2R5IiwiaW5kaWNlcyIsImV4aXN0cyIsImVycm9yIiwiY3JlYXRlSW5kZXgiLCJjcmVhdGUiLCJlbnN1cmVUZW1wbGF0ZSIsIm5hbWUiLCJpbmRleFBhdHRlcm5zIiwibWFwcGluZyIsInRlbXBsYXRlIiwic2V0dGluZ3MiLCJtYXBwaW5ncyIsInB1dEluZGV4VGVtcGxhdGUiLCJpbmRleF9wYXR0ZXJucyIsInByaW9yaXR5IiwicHV0VGVtcGxhdGUiLCJlbnN1cmVJbmRleCIsIl9lJGJvZHkiLCJfZSRtZXRhIiwidHlwZSIsIm1ldGEiLCJjcmVhdGVEb2N1bWVudCIsImlkIiwicGFyYW1zIiwicmVmcmVzaCIsInJlc3VsdCIsIl9pZCIsImdldERvY3VtZW50IiwiZ2V0IiwiX3NvdXJjZSIsIl9lcnJvciRtZXRhIiwic3RhdHVzQ29kZSIsInVwZGF0ZURvY3VtZW50IiwiZG9jIiwidXBkYXRlIiwicmV0cnlfb25fY29uZmxpY3QiLCJkZWxldGVEb2N1bWVudCIsImRlbGV0ZSIsIl9lcnJvciRtZXRhMiIsInNlYXJjaERvY3VtZW50cyIsIl9yZXN1bHQkaGl0cyR0b3RhbCR2YSIsIl9yZXN1bHQkaGl0cyR0b3RhbCIsInNlYXJjaCIsInRvdGFsIiwiaGl0cyIsImFnZ3JlZ2F0ZURvY3VtZW50cyIsIl9yZXN1bHQkYWdncmVnYXRpb25zIiwic2l6ZSIsImFnZ3JlZ2F0aW9ucyIsImdldE5leHRDb3VudGVyVmFsdWUiLCJNQVhfUkVUUklFUyIsImF0dGVtcHQiLCJzZXFObyIsInByaW1hcnlUZXJtIiwiY3VycmVudFZhbHVlIiwiX2JvZHkkX3NvdXJjZSRjdXJyZW50IiwiX2JvZHkkX3NvdXJjZSIsIkNBU0VfQ09VTlRFUl9JTkRFWCIsIkNPVU5URVJfRE9DX0lEIiwiX3NlcV9ubyIsIl9wcmltYXJ5X3Rlcm0iLCJjdXJyZW50X3ZhbHVlIiwiZXJyIiwiX2VyciRtZXRhIiwibmV4dFZhbHVlIiwidW5kZWZpbmVkIiwiY291bnRlcl9uYW1lIiwib3BfdHlwZSIsImlmX3NlcV9ubyIsImlmX3ByaW1hcnlfdGVybSIsIl9lcnIkc3RhdHVzQ29kZSIsIl9lcnIkbWV0YTIiLCJzdGF0dXMiLCJEYXRlIiwibm93IiwiZXhwb3J0cyJdLCJzb3VyY2VzIjpbIm9wZW5zZWFyY2hfc2VydmljZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogV2F6dWggQ2FzZSBNYW5hZ2VtZW50IFBsdWdpblxuICogT3BlblNlYXJjaCBTZXJ2aWNlIOKAlCBMb3ctbGV2ZWwgT3BlblNlYXJjaCBjbGllbnQgb3BlcmF0aW9uc1xuICpcbiAqIFByb3ZpZGVzIHJldXNhYmxlIENSVUQgaGVscGVycywgc2VhcmNoLCBhZ2dyZWdhdGlvbiwgYW5kIGNvdW50ZXIgbWFuYWdlbWVudFxuICogdGhhdCB3cmFwIHRoZSBPcGVuU2VhcmNoIGNsaWVudCBvYnRhaW5lZCBmcm9tIHRoZSByZXF1ZXN0IGNvbnRleHQuXG4gKiBUaGlzIHNlcnZpY2UgaXMgc3RhdGVsZXNzIOKAlCBldmVyeSBtZXRob2QgcmVjZWl2ZXMgdGhlIGNsaWVudCBleHBsaWNpdGx5LlxuICovXG5cbmltcG9ydCB7IENBU0VfQ09VTlRFUl9JTkRFWCB9IGZyb20gJy4uLy4uL2NvbW1vbi9jb25zdGFudHMnO1xuXG4vKiogQSBtaW5pbWFsIGludGVyZmFjZSByZXByZXNlbnRpbmcgdGhlIHNjb3BlZCBPcGVuU2VhcmNoIGNsaWVudCAqL1xudHlwZSBPcGVuU2VhcmNoQ2xpZW50ID0ge1xuICBpbmRpY2VzOiB7XG4gICAgZXhpc3RzOiAocGFyYW1zOiBhbnkpID0+IFByb21pc2U8eyBib2R5OiBib29sZWFuIH0+O1xuICAgIGNyZWF0ZTogKHBhcmFtczogYW55KSA9PiBQcm9taXNlPGFueT47XG4gIH07XG4gIGluZGV4OiAocGFyYW1zOiBhbnkpID0+IFByb21pc2U8YW55PjtcbiAgZ2V0OiAocGFyYW1zOiBhbnkpID0+IFByb21pc2U8YW55PjtcbiAgdXBkYXRlOiAocGFyYW1zOiBhbnkpID0+IFByb21pc2U8YW55PjtcbiAgZGVsZXRlOiAocGFyYW1zOiBhbnkpID0+IFByb21pc2U8YW55PjtcbiAgc2VhcmNoOiAocGFyYW1zOiBhbnkpID0+IFByb21pc2U8YW55PjtcbiAgY291bnQ6IChwYXJhbXM6IGFueSkgPT4gUHJvbWlzZTxhbnk+O1xufTtcblxuLyoqXG4gKiBPcGVuU2VhcmNoU2VydmljZSDigJQgdGhpbiB3cmFwcGVyIGFyb3VuZCB0aGUgc2NvcGVkIE9wZW5TZWFyY2ggY2xpZW50LlxuICpcbiAqIERlc2lnbiBub3RlczpcbiAqICAtIEV2ZXJ5IHB1YmxpYyBtZXRob2QgaXMgc3RhdGljIHNvIGNhbGxlcnMgZG9uJ3QgbmVlZCB0byBtYW5hZ2UgaW5zdGFuY2VzLlxuICogIC0gVGhlIGBjbGllbnRgIHBhcmFtZXRlciBtdXN0IGJlIGBjb250ZXh0LmNvcmUub3BlbnNlYXJjaC5jbGllbnQuYXNDdXJyZW50VXNlcmAuXG4gKi9cbmV4cG9ydCBjbGFzcyBPcGVuU2VhcmNoU2VydmljZSB7XG4gIC8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICAvLyBJbmRleCBvcGVyYXRpb25zXG4gIC8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG4gIC8qKiBDaGVjayB3aGV0aGVyIGFuIGluZGV4IGFscmVhZHkgZXhpc3RzICovXG4gIHN0YXRpYyBhc3luYyBpbmRleEV4aXN0cyhjbGllbnQ6IGFueSwgaW5kZXg6IHN0cmluZyk6IFByb21pc2U8Ym9vbGVhbj4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB7IGJvZHkgfSA9IGF3YWl0IGNsaWVudC5pbmRpY2VzLmV4aXN0cyh7IGluZGV4IH0pO1xuICAgICAgcmV0dXJuIGJvZHkgYXMgYm9vbGVhbjtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgLy8gNDA0IG1lYW5zIGl0IGRvZXMgbm90IGV4aXN0IOKAlCBub3QgYW4gZXJyb3JcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gIH1cblxuICAvKiogQ3JlYXRlIGFuIGluZGV4IHdpdGggdGhlIGdpdmVuIGJvZHkgKHNldHRpbmdzICsgbWFwcGluZ3MpICovXG4gIHN0YXRpYyBhc3luYyBjcmVhdGVJbmRleChjbGllbnQ6IGFueSwgaW5kZXg6IHN0cmluZywgYm9keTogYW55KTogUHJvbWlzZTx2b2lkPiB7XG4gICAgYXdhaXQgY2xpZW50LmluZGljZXMuY3JlYXRlKHsgaW5kZXgsIGJvZHkgfSk7XG4gIH1cblxuICAvKipcbiAgICogUmVnaXN0ZXIgYW4gaW5kZXggdGVtcGxhdGUgc28gdGhhdCBpZiB0aGUgaW5kZXggaXMgZXZlciBkZWxldGVkIGFuZCBsYXRlclxuICAgKiBhdXRvLWNyZWF0ZWQgYnkgYSB3cml0ZSwgaXQgaXMgcmVjcmVhdGVkIHdpdGggdGhlIGNvcnJlY3QgbWFwcGluZy5cbiAgICogVGhpcyBpcyB0aGUgZHVyYWJsZSBzYWZlZ3VhcmQgYWdhaW5zdCBkeW5hbWljLW1hcHBpbmcgZHJpZnQgKGUuZy4gYHN0YXR1c2BcbiAgICogYmVjb21pbmcgYHRleHRgIGluc3RlYWQgb2YgYGtleXdvcmRgKS5cbiAgICovXG4gIHN0YXRpYyBhc3luYyBlbnN1cmVUZW1wbGF0ZShcbiAgICBjbGllbnQ6IGFueSxcbiAgICBuYW1lOiBzdHJpbmcsXG4gICAgaW5kZXhQYXR0ZXJuczogc3RyaW5nW10sXG4gICAgbWFwcGluZzogeyBzZXR0aW5ncz86IGFueTsgbWFwcGluZ3M/OiBhbnkgfSxcbiAgKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgY29uc3QgdGVtcGxhdGUgPSB7IHNldHRpbmdzOiBtYXBwaW5nLnNldHRpbmdzIHx8IHt9LCBtYXBwaW5nczogbWFwcGluZy5tYXBwaW5ncyB8fCB7fSB9O1xuICAgIHRyeSB7XG4gICAgICAvLyBDb21wb3NhYmxlIGluZGV4IHRlbXBsYXRlIChPcGVuU2VhcmNoIDIueClcbiAgICAgIGF3YWl0IGNsaWVudC5pbmRpY2VzLnB1dEluZGV4VGVtcGxhdGUoe1xuICAgICAgICBuYW1lLFxuICAgICAgICBib2R5OiB7IGluZGV4X3BhdHRlcm5zOiBpbmRleFBhdHRlcm5zLCB0ZW1wbGF0ZSwgcHJpb3JpdHk6IDIwMCB9LFxuICAgICAgfSk7XG4gICAgfSBjYXRjaCAoZTogYW55KSB7XG4gICAgICAvLyBGYWxsIGJhY2sgdG8gdGhlIGxlZ2FjeSB0ZW1wbGF0ZSBBUEkgb24gb2xkZXIgY2x1c3RlcnNcbiAgICAgIGF3YWl0IGNsaWVudC5pbmRpY2VzLnB1dFRlbXBsYXRlKHtcbiAgICAgICAgbmFtZSxcbiAgICAgICAgYm9keTogeyBpbmRleF9wYXR0ZXJuczogaW5kZXhQYXR0ZXJucywgc2V0dGluZ3M6IHRlbXBsYXRlLnNldHRpbmdzLCBtYXBwaW5nczogdGVtcGxhdGUubWFwcGluZ3MgfSxcbiAgICAgIH0pO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBFbnN1cmUgYW4gaW5kZXggZXhpc3RzIHdpdGggdGhlIGNvcnJlY3QgbWFwcGluZzsgY3JlYXRlIGl0IGlmIG1pc3NpbmcuXG4gICAqIElkZW1wb3RlbnQgYW5kIHNhZmUgdG8gY2FsbCBiZWZvcmUgZXZlcnkgd3JpdGUuIFRvbGVyYXRlcyB0aGUgcmFjZSB3aGVyZVxuICAgKiBhbm90aGVyIHJlcXVlc3QgY3JlYXRlcyB0aGUgaW5kZXggZmlyc3QuXG4gICAqL1xuICBzdGF0aWMgYXN5bmMgZW5zdXJlSW5kZXgoY2xpZW50OiBhbnksIGluZGV4OiBzdHJpbmcsIGJvZHk6IGFueSk6IFByb21pc2U8dm9pZD4ge1xuICAgIGNvbnN0IGV4aXN0cyA9IGF3YWl0IE9wZW5TZWFyY2hTZXJ2aWNlLmluZGV4RXhpc3RzKGNsaWVudCwgaW5kZXgpO1xuICAgIGlmIChleGlzdHMpIHJldHVybjtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgY2xpZW50LmluZGljZXMuY3JlYXRlKHsgaW5kZXgsIGJvZHkgfSk7XG4gICAgfSBjYXRjaCAoZTogYW55KSB7XG4gICAgICBjb25zdCB0eXBlID0gZT8uYm9keT8uZXJyb3I/LnR5cGUgfHwgZT8ubWV0YT8uYm9keT8uZXJyb3I/LnR5cGU7XG4gICAgICBpZiAodHlwZSAhPT0gJ3Jlc291cmNlX2FscmVhZHlfZXhpc3RzX2V4Y2VwdGlvbicpIHRocm93IGU7XG4gICAgfVxuICB9XG5cbiAgLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gIC8vIERvY3VtZW50IENSVURcbiAgLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbiAgLyoqXG4gICAqIEluZGV4IChjcmVhdGUvb3ZlcndyaXRlKSBhIGRvY3VtZW50LlxuICAgKiBJZiBgaWRgIGlzIHByb3ZpZGVkIHRoZSBkb2N1bWVudCBpcyBzdG9yZWQgdW5kZXIgdGhhdCBfaWQsIG90aGVyd2lzZVxuICAgKiBPcGVuU2VhcmNoIGF1dG8tZ2VuZXJhdGVzIG9uZS5cbiAgICovXG4gIHN0YXRpYyBhc3luYyBjcmVhdGVEb2N1bWVudChcbiAgICBjbGllbnQ6IGFueSxcbiAgICBpbmRleDogc3RyaW5nLFxuICAgIGJvZHk6IGFueSxcbiAgICBpZD86IHN0cmluZyxcbiAgKTogUHJvbWlzZTx7IF9pZDogc3RyaW5nIH0+IHtcbiAgICBjb25zdCBwYXJhbXM6IGFueSA9IHsgaW5kZXgsIGJvZHksIHJlZnJlc2g6ICd3YWl0X2ZvcicgfTtcbiAgICBpZiAoaWQpIHBhcmFtcy5pZCA9IGlkO1xuICAgIGNvbnN0IHsgYm9keTogcmVzdWx0IH0gPSBhd2FpdCBjbGllbnQuaW5kZXgocGFyYW1zKTtcbiAgICByZXR1cm4geyBfaWQ6IHJlc3VsdC5faWQgfTtcbiAgfVxuXG4gIC8qKiBSZXRyaWV2ZSBhIHNpbmdsZSBkb2N1bWVudCBieSBfaWQgKi9cbiAgc3RhdGljIGFzeW5jIGdldERvY3VtZW50KGNsaWVudDogYW55LCBpbmRleDogc3RyaW5nLCBpZDogc3RyaW5nKTogUHJvbWlzZTxhbnk+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgeyBib2R5IH0gPSBhd2FpdCBjbGllbnQuZ2V0KHsgaW5kZXgsIGlkIH0pO1xuICAgICAgcmV0dXJuIHsgX2lkOiBib2R5Ll9pZCwgX3NvdXJjZTogYm9keS5fc291cmNlIH07XG4gICAgfSBjYXRjaCAoZXJyb3I6IGFueSkge1xuICAgICAgaWYgKGVycm9yPy5zdGF0dXNDb2RlID09PSA0MDQgfHwgZXJyb3I/Lm1ldGE/LnN0YXR1c0NvZGUgPT09IDQwNCkge1xuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgIH1cbiAgICAgIHRocm93IGVycm9yO1xuICAgIH1cbiAgfVxuXG4gIC8qKiBQYXJ0aWFsbHkgdXBkYXRlIGEgZG9jdW1lbnQgKG1lcmdlIGZpZWxkcykgKi9cbiAgc3RhdGljIGFzeW5jIHVwZGF0ZURvY3VtZW50KFxuICAgIGNsaWVudDogYW55LFxuICAgIGluZGV4OiBzdHJpbmcsXG4gICAgaWQ6IHN0cmluZyxcbiAgICBkb2M6IGFueSxcbiAgKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgYXdhaXQgY2xpZW50LnVwZGF0ZSh7XG4gICAgICBpbmRleCxcbiAgICAgIGlkLFxuICAgICAgYm9keTogeyBkb2MgfSxcbiAgICAgIHJlZnJlc2g6ICd3YWl0X2ZvcicsXG4gICAgICByZXRyeV9vbl9jb25mbGljdDogMyxcbiAgICB9KTtcbiAgfVxuXG4gIC8qKiBEZWxldGUgYSBkb2N1bWVudCBieSBfaWQgKi9cbiAgc3RhdGljIGFzeW5jIGRlbGV0ZURvY3VtZW50KGNsaWVudDogYW55LCBpbmRleDogc3RyaW5nLCBpZDogc3RyaW5nKTogUHJvbWlzZTxib29sZWFuPiB7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IGNsaWVudC5kZWxldGUoeyBpbmRleCwgaWQsIHJlZnJlc2g6ICd3YWl0X2ZvcicgfSk7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9IGNhdGNoIChlcnJvcjogYW55KSB7XG4gICAgICBpZiAoZXJyb3I/LnN0YXR1c0NvZGUgPT09IDQwNCB8fCBlcnJvcj8ubWV0YT8uc3RhdHVzQ29kZSA9PT0gNDA0KSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIH1cbiAgICAgIHRocm93IGVycm9yO1xuICAgIH1cbiAgfVxuXG4gIC8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICAvLyBTZWFyY2ggJiBBZ2dyZWdhdGlvblxuICAvLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuICAvKipcbiAgICogUGVyZm9ybSBhIHNlYXJjaCBxdWVyeSBhZ2FpbnN0IGFuIGluZGV4LlxuICAgKiBSZXR1cm5zIHRoZSByYXcgaGl0cyBhcnJheSB0b2dldGhlciB3aXRoIHRoZSB0b3RhbCBjb3VudC5cbiAgICovXG4gIHN0YXRpYyBhc3luYyBzZWFyY2hEb2N1bWVudHMoXG4gICAgY2xpZW50OiBhbnksXG4gICAgaW5kZXg6IHN0cmluZyxcbiAgICBib2R5OiBhbnksXG4gICk6IFByb21pc2U8eyBoaXRzOiBhbnlbXTsgdG90YWw6IG51bWJlciB9PiB7XG4gICAgY29uc3QgeyBib2R5OiByZXN1bHQgfSA9IGF3YWl0IGNsaWVudC5zZWFyY2goeyBpbmRleCwgYm9keSB9KTtcbiAgICBjb25zdCB0b3RhbCA9XG4gICAgICB0eXBlb2YgcmVzdWx0LmhpdHMudG90YWwgPT09ICdudW1iZXInXG4gICAgICAgID8gcmVzdWx0LmhpdHMudG90YWxcbiAgICAgICAgOiByZXN1bHQuaGl0cy50b3RhbD8udmFsdWUgPz8gMDtcbiAgICByZXR1cm4ge1xuICAgICAgaGl0czogcmVzdWx0LmhpdHMuaGl0cyxcbiAgICAgIHRvdGFsLFxuICAgIH07XG4gIH1cblxuICAvKipcbiAgICogUnVuIGFuIGFnZ3JlZ2F0aW9uLW9ubHkgcXVlcnkgKHNpemU9MCkuXG4gICAqIFJldHVybnMgdGhlIHJhdyBhZ2dyZWdhdGlvbnMgb2JqZWN0LlxuICAgKi9cbiAgc3RhdGljIGFzeW5jIGFnZ3JlZ2F0ZURvY3VtZW50cyhcbiAgICBjbGllbnQ6IGFueSxcbiAgICBpbmRleDogc3RyaW5nLFxuICAgIGJvZHk6IGFueSxcbiAgKTogUHJvbWlzZTxhbnk+IHtcbiAgICBjb25zdCB7IGJvZHk6IHJlc3VsdCB9ID0gYXdhaXQgY2xpZW50LnNlYXJjaCh7IGluZGV4LCBib2R5OiB7IHNpemU6IDAsIC4uLmJvZHkgfSB9KTtcbiAgICByZXR1cm4gcmVzdWx0LmFnZ3JlZ2F0aW9ucyA/PyB7fTtcbiAgfVxuXG4gIC8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICAvLyBDb3VudGVyIG1hbmFnZW1lbnQgZm9yIGNhc2UgSUQgZ2VuZXJhdGlvblxuICAvLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuICAvKiogVGhlIHdlbGwta25vd24gZG9jdW1lbnQgSUQgdGhhdCBob2xkcyB0aGUgY2FzZSBjb3VudGVyICovXG4gIHByaXZhdGUgc3RhdGljIHJlYWRvbmx5IENPVU5URVJfRE9DX0lEID0gJ2Nhc2VfaWRfY291bnRlcic7XG5cbiAgLyoqXG4gICAqIEF0b21pY2FsbHkgaW5jcmVtZW50LWFuZC1yZXR1cm4gdGhlIGNhc2UgY291bnRlci5cbiAgICogVXNlcyBvcHRpbWlzdGljIGNvbmN1cnJlbmN5IGNvbnRyb2wgKHNlcV9ubyArIHByaW1hcnlfdGVybSkgaW5zdGVhZCBvZlxuICAgKiBQYWlubGVzcyBzY3JpcHRzLCB3aGljaCBtYXkgYmUgZGlzYWJsZWQgaW4gV2F6dWgncyBPcGVuU2VhcmNoIGRlcGxveW1lbnQuXG4gICAqL1xuICBzdGF0aWMgYXN5bmMgZ2V0TmV4dENvdW50ZXJWYWx1ZShjbGllbnQ6IGFueSk6IFByb21pc2U8bnVtYmVyPiB7XG4gICAgY29uc3QgTUFYX1JFVFJJRVMgPSAxMDtcblxuICAgIGZvciAobGV0IGF0dGVtcHQgPSAwOyBhdHRlbXB0IDwgTUFYX1JFVFJJRVM7IGF0dGVtcHQrKykge1xuICAgICAgbGV0IHNlcU5vOiBudW1iZXIgfCB1bmRlZmluZWQ7XG4gICAgICBsZXQgcHJpbWFyeVRlcm06IG51bWJlciB8IHVuZGVmaW5lZDtcbiAgICAgIGxldCBjdXJyZW50VmFsdWUgPSAwO1xuXG4gICAgICAvLyBUcnkgdG8gcmVhZCB0aGUgZXhpc3RpbmcgY291bnRlciBkb2N1bWVudFxuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgeyBib2R5IH0gPSBhd2FpdCBjbGllbnQuZ2V0KHtcbiAgICAgICAgICBpbmRleDogQ0FTRV9DT1VOVEVSX0lOREVYLFxuICAgICAgICAgIGlkOiBPcGVuU2VhcmNoU2VydmljZS5DT1VOVEVSX0RPQ19JRCxcbiAgICAgICAgfSk7XG4gICAgICAgIHNlcU5vID0gYm9keS5fc2VxX25vO1xuICAgICAgICBwcmltYXJ5VGVybSA9IGJvZHkuX3ByaW1hcnlfdGVybTtcbiAgICAgICAgY3VycmVudFZhbHVlID0gYm9keS5fc291cmNlPy5jdXJyZW50X3ZhbHVlID8/IDA7XG4gICAgICB9IGNhdGNoIChlcnI6IGFueSkge1xuICAgICAgICAvLyA0MDQg4oCUIGNvdW50ZXIgZG9lc24ndCBleGlzdCB5ZXQsIHdlJ2xsIGNyZWF0ZSBpdCBiZWxvd1xuICAgICAgICBpZiAoZXJyPy5zdGF0dXNDb2RlICE9PSA0MDQgJiYgZXJyPy5tZXRhPy5zdGF0dXNDb2RlICE9PSA0MDQpIHtcbiAgICAgICAgICB0aHJvdyBlcnI7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgY29uc3QgbmV4dFZhbHVlID0gY3VycmVudFZhbHVlICsgMTtcblxuICAgICAgdHJ5IHtcbiAgICAgICAgaWYgKHNlcU5vID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAvLyBDcmVhdGUgdGhlIGNvdW50ZXIgZG9jdW1lbnQgZm9yIHRoZSBmaXJzdCB0aW1lXG4gICAgICAgICAgYXdhaXQgY2xpZW50LmluZGV4KHtcbiAgICAgICAgICAgIGluZGV4OiBDQVNFX0NPVU5URVJfSU5ERVgsXG4gICAgICAgICAgICBpZDogT3BlblNlYXJjaFNlcnZpY2UuQ09VTlRFUl9ET0NfSUQsXG4gICAgICAgICAgICBib2R5OiB7IGNvdW50ZXJfbmFtZTogJ2Nhc2VfaWQnLCBjdXJyZW50X3ZhbHVlOiBuZXh0VmFsdWUgfSxcbiAgICAgICAgICAgIG9wX3R5cGU6ICdjcmVhdGUnLFxuICAgICAgICAgICAgcmVmcmVzaDogJ3dhaXRfZm9yJyxcbiAgICAgICAgICB9KTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAvLyBVcGRhdGUgd2l0aCBvcHRpbWlzdGljIGNvbmN1cnJlbmN5IGNoZWNrXG4gICAgICAgICAgYXdhaXQgY2xpZW50LmluZGV4KHtcbiAgICAgICAgICAgIGluZGV4OiBDQVNFX0NPVU5URVJfSU5ERVgsXG4gICAgICAgICAgICBpZDogT3BlblNlYXJjaFNlcnZpY2UuQ09VTlRFUl9ET0NfSUQsXG4gICAgICAgICAgICBib2R5OiB7IGNvdW50ZXJfbmFtZTogJ2Nhc2VfaWQnLCBjdXJyZW50X3ZhbHVlOiBuZXh0VmFsdWUgfSxcbiAgICAgICAgICAgIGlmX3NlcV9ubzogc2VxTm8sXG4gICAgICAgICAgICBpZl9wcmltYXJ5X3Rlcm06IHByaW1hcnlUZXJtLFxuICAgICAgICAgICAgcmVmcmVzaDogJ3dhaXRfZm9yJyxcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gbmV4dFZhbHVlO1xuICAgICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgICAgY29uc3Qgc3RhdHVzID0gZXJyPy5zdGF0dXNDb2RlID8/IGVycj8ubWV0YT8uc3RhdHVzQ29kZTtcbiAgICAgICAgLy8gNDA5IGNvbmZsaWN0IG1lYW5zIGFub3RoZXIgcmVxdWVzdCB1cGRhdGVkIHRoZSBjb3VudGVyIGZpcnN0IOKAlCByZXRyeVxuICAgICAgICBpZiAoc3RhdHVzID09PSA0MDkpIHtcbiAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuICAgICAgICB0aHJvdyBlcnI7XG4gICAgICB9XG4gICAgfVxuXG4gICAgLy8gRmFsbGJhY2s6IHVzZSB0aW1lc3RhbXAtYmFzZWQgdmFsdWUgaWYgYWxsIHJldHJpZXMgZXhoYXVzdGVkXG4gICAgcmV0dXJuIERhdGUubm93KCk7XG4gIH1cbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBU0EsSUFBQUEsVUFBQSxHQUFBQyxPQUFBO0FBQTRELFNBQUFDLGdCQUFBQyxDQUFBLEVBQUFDLENBQUEsRUFBQUMsQ0FBQSxZQUFBRCxDQUFBLEdBQUFFLGNBQUEsQ0FBQUYsQ0FBQSxNQUFBRCxDQUFBLEdBQUFJLE1BQUEsQ0FBQUMsY0FBQSxDQUFBTCxDQUFBLEVBQUFDLENBQUEsSUFBQUssS0FBQSxFQUFBSixDQUFBLEVBQUFLLFVBQUEsTUFBQUMsWUFBQSxNQUFBQyxRQUFBLFVBQUFULENBQUEsQ0FBQUMsQ0FBQSxJQUFBQyxDQUFBLEVBQUFGLENBQUE7QUFBQSxTQUFBRyxlQUFBRCxDQUFBLFFBQUFRLENBQUEsR0FBQUMsWUFBQSxDQUFBVCxDQUFBLHVDQUFBUSxDQUFBLEdBQUFBLENBQUEsR0FBQUEsQ0FBQTtBQUFBLFNBQUFDLGFBQUFULENBQUEsRUFBQUQsQ0FBQSwyQkFBQUMsQ0FBQSxLQUFBQSxDQUFBLFNBQUFBLENBQUEsTUFBQUYsQ0FBQSxHQUFBRSxDQUFBLENBQUFVLE1BQUEsQ0FBQUMsV0FBQSxrQkFBQWIsQ0FBQSxRQUFBVSxDQUFBLEdBQUFWLENBQUEsQ0FBQWMsSUFBQSxDQUFBWixDQUFBLEVBQUFELENBQUEsdUNBQUFTLENBQUEsU0FBQUEsQ0FBQSxZQUFBSyxTQUFBLHlFQUFBZCxDQUFBLEdBQUFlLE1BQUEsR0FBQUMsTUFBQSxFQUFBZixDQUFBLEtBVDVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFJQTs7QUFjQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLE1BQU1nQixpQkFBaUIsQ0FBQztFQUM3QjtFQUNBO0VBQ0E7O0VBRUE7RUFDQSxhQUFhQyxXQUFXQSxDQUFDQyxNQUFXLEVBQUVDLEtBQWEsRUFBb0I7SUFDckUsSUFBSTtNQUNGLE1BQU07UUFBRUM7TUFBSyxDQUFDLEdBQUcsTUFBTUYsTUFBTSxDQUFDRyxPQUFPLENBQUNDLE1BQU0sQ0FBQztRQUFFSDtNQUFNLENBQUMsQ0FBQztNQUN2RCxPQUFPQyxJQUFJO0lBQ2IsQ0FBQyxDQUFDLE9BQU9HLEtBQUssRUFBRTtNQUNkO01BQ0EsT0FBTyxLQUFLO0lBQ2Q7RUFDRjs7RUFFQTtFQUNBLGFBQWFDLFdBQVdBLENBQUNOLE1BQVcsRUFBRUMsS0FBYSxFQUFFQyxJQUFTLEVBQWlCO0lBQzdFLE1BQU1GLE1BQU0sQ0FBQ0csT0FBTyxDQUFDSSxNQUFNLENBQUM7TUFBRU4sS0FBSztNQUFFQztJQUFLLENBQUMsQ0FBQztFQUM5Qzs7RUFFQTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7RUFDRSxhQUFhTSxjQUFjQSxDQUN6QlIsTUFBVyxFQUNYUyxJQUFZLEVBQ1pDLGFBQXVCLEVBQ3ZCQyxPQUEyQyxFQUM1QjtJQUNmLE1BQU1DLFFBQVEsR0FBRztNQUFFQyxRQUFRLEVBQUVGLE9BQU8sQ0FBQ0UsUUFBUSxJQUFJLENBQUMsQ0FBQztNQUFFQyxRQUFRLEVBQUVILE9BQU8sQ0FBQ0csUUFBUSxJQUFJLENBQUM7SUFBRSxDQUFDO0lBQ3ZGLElBQUk7TUFDRjtNQUNBLE1BQU1kLE1BQU0sQ0FBQ0csT0FBTyxDQUFDWSxnQkFBZ0IsQ0FBQztRQUNwQ04sSUFBSTtRQUNKUCxJQUFJLEVBQUU7VUFBRWMsY0FBYyxFQUFFTixhQUFhO1VBQUVFLFFBQVE7VUFBRUssUUFBUSxFQUFFO1FBQUk7TUFDakUsQ0FBQyxDQUFDO0lBQ0osQ0FBQyxDQUFDLE9BQU9yQyxDQUFNLEVBQUU7TUFDZjtNQUNBLE1BQU1vQixNQUFNLENBQUNHLE9BQU8sQ0FBQ2UsV0FBVyxDQUFDO1FBQy9CVCxJQUFJO1FBQ0pQLElBQUksRUFBRTtVQUFFYyxjQUFjLEVBQUVOLGFBQWE7VUFBRUcsUUFBUSxFQUFFRCxRQUFRLENBQUNDLFFBQVE7VUFBRUMsUUFBUSxFQUFFRixRQUFRLENBQUNFO1FBQVM7TUFDbEcsQ0FBQyxDQUFDO0lBQ0o7RUFDRjs7RUFFQTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0VBQ0UsYUFBYUssV0FBV0EsQ0FBQ25CLE1BQVcsRUFBRUMsS0FBYSxFQUFFQyxJQUFTLEVBQWlCO0lBQzdFLE1BQU1FLE1BQU0sR0FBRyxNQUFNTixpQkFBaUIsQ0FBQ0MsV0FBVyxDQUFDQyxNQUFNLEVBQUVDLEtBQUssQ0FBQztJQUNqRSxJQUFJRyxNQUFNLEVBQUU7SUFDWixJQUFJO01BQ0YsTUFBTUosTUFBTSxDQUFDRyxPQUFPLENBQUNJLE1BQU0sQ0FBQztRQUFFTixLQUFLO1FBQUVDO01BQUssQ0FBQyxDQUFDO0lBQzlDLENBQUMsQ0FBQyxPQUFPdEIsQ0FBTSxFQUFFO01BQUEsSUFBQXdDLE9BQUEsRUFBQUMsT0FBQTtNQUNmLE1BQU1DLElBQUksR0FBRyxDQUFBMUMsQ0FBQyxhQUFEQSxDQUFDLGdCQUFBd0MsT0FBQSxHQUFEeEMsQ0FBQyxDQUFFc0IsSUFBSSxjQUFBa0IsT0FBQSxnQkFBQUEsT0FBQSxHQUFQQSxPQUFBLENBQVNmLEtBQUssY0FBQWUsT0FBQSx1QkFBZEEsT0FBQSxDQUFnQkUsSUFBSSxNQUFJMUMsQ0FBQyxhQUFEQSxDQUFDLGdCQUFBeUMsT0FBQSxHQUFEekMsQ0FBQyxDQUFFMkMsSUFBSSxjQUFBRixPQUFBLGdCQUFBQSxPQUFBLEdBQVBBLE9BQUEsQ0FBU25CLElBQUksY0FBQW1CLE9BQUEsZ0JBQUFBLE9BQUEsR0FBYkEsT0FBQSxDQUFlaEIsS0FBSyxjQUFBZ0IsT0FBQSx1QkFBcEJBLE9BQUEsQ0FBc0JDLElBQUk7TUFDL0QsSUFBSUEsSUFBSSxLQUFLLG1DQUFtQyxFQUFFLE1BQU0xQyxDQUFDO0lBQzNEO0VBQ0Y7O0VBRUE7RUFDQTtFQUNBOztFQUVBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7RUFDRSxhQUFhNEMsY0FBY0EsQ0FDekJ4QixNQUFXLEVBQ1hDLEtBQWEsRUFDYkMsSUFBUyxFQUNUdUIsRUFBVyxFQUNlO0lBQzFCLE1BQU1DLE1BQVcsR0FBRztNQUFFekIsS0FBSztNQUFFQyxJQUFJO01BQUV5QixPQUFPLEVBQUU7SUFBVyxDQUFDO0lBQ3hELElBQUlGLEVBQUUsRUFBRUMsTUFBTSxDQUFDRCxFQUFFLEdBQUdBLEVBQUU7SUFDdEIsTUFBTTtNQUFFdkIsSUFBSSxFQUFFMEI7SUFBTyxDQUFDLEdBQUcsTUFBTTVCLE1BQU0sQ0FBQ0MsS0FBSyxDQUFDeUIsTUFBTSxDQUFDO0lBQ25ELE9BQU87TUFBRUcsR0FBRyxFQUFFRCxNQUFNLENBQUNDO0lBQUksQ0FBQztFQUM1Qjs7RUFFQTtFQUNBLGFBQWFDLFdBQVdBLENBQUM5QixNQUFXLEVBQUVDLEtBQWEsRUFBRXdCLEVBQVUsRUFBZ0I7SUFDN0UsSUFBSTtNQUNGLE1BQU07UUFBRXZCO01BQUssQ0FBQyxHQUFHLE1BQU1GLE1BQU0sQ0FBQytCLEdBQUcsQ0FBQztRQUFFOUIsS0FBSztRQUFFd0I7TUFBRyxDQUFDLENBQUM7TUFDaEQsT0FBTztRQUFFSSxHQUFHLEVBQUUzQixJQUFJLENBQUMyQixHQUFHO1FBQUVHLE9BQU8sRUFBRTlCLElBQUksQ0FBQzhCO01BQVEsQ0FBQztJQUNqRCxDQUFDLENBQUMsT0FBTzNCLEtBQVUsRUFBRTtNQUFBLElBQUE0QixXQUFBO01BQ25CLElBQUksQ0FBQTVCLEtBQUssYUFBTEEsS0FBSyx1QkFBTEEsS0FBSyxDQUFFNkIsVUFBVSxNQUFLLEdBQUcsSUFBSSxDQUFBN0IsS0FBSyxhQUFMQSxLQUFLLGdCQUFBNEIsV0FBQSxHQUFMNUIsS0FBSyxDQUFFa0IsSUFBSSxjQUFBVSxXQUFBLHVCQUFYQSxXQUFBLENBQWFDLFVBQVUsTUFBSyxHQUFHLEVBQUU7UUFDaEUsT0FBTyxJQUFJO01BQ2I7TUFDQSxNQUFNN0IsS0FBSztJQUNiO0VBQ0Y7O0VBRUE7RUFDQSxhQUFhOEIsY0FBY0EsQ0FDekJuQyxNQUFXLEVBQ1hDLEtBQWEsRUFDYndCLEVBQVUsRUFDVlcsR0FBUSxFQUNPO0lBQ2YsTUFBTXBDLE1BQU0sQ0FBQ3FDLE1BQU0sQ0FBQztNQUNsQnBDLEtBQUs7TUFDTHdCLEVBQUU7TUFDRnZCLElBQUksRUFBRTtRQUFFa0M7TUFBSSxDQUFDO01BQ2JULE9BQU8sRUFBRSxVQUFVO01BQ25CVyxpQkFBaUIsRUFBRTtJQUNyQixDQUFDLENBQUM7RUFDSjs7RUFFQTtFQUNBLGFBQWFDLGNBQWNBLENBQUN2QyxNQUFXLEVBQUVDLEtBQWEsRUFBRXdCLEVBQVUsRUFBb0I7SUFDcEYsSUFBSTtNQUNGLE1BQU16QixNQUFNLENBQUN3QyxNQUFNLENBQUM7UUFBRXZDLEtBQUs7UUFBRXdCLEVBQUU7UUFBRUUsT0FBTyxFQUFFO01BQVcsQ0FBQyxDQUFDO01BQ3ZELE9BQU8sSUFBSTtJQUNiLENBQUMsQ0FBQyxPQUFPdEIsS0FBVSxFQUFFO01BQUEsSUFBQW9DLFlBQUE7TUFDbkIsSUFBSSxDQUFBcEMsS0FBSyxhQUFMQSxLQUFLLHVCQUFMQSxLQUFLLENBQUU2QixVQUFVLE1BQUssR0FBRyxJQUFJLENBQUE3QixLQUFLLGFBQUxBLEtBQUssZ0JBQUFvQyxZQUFBLEdBQUxwQyxLQUFLLENBQUVrQixJQUFJLGNBQUFrQixZQUFBLHVCQUFYQSxZQUFBLENBQWFQLFVBQVUsTUFBSyxHQUFHLEVBQUU7UUFDaEUsT0FBTyxLQUFLO01BQ2Q7TUFDQSxNQUFNN0IsS0FBSztJQUNiO0VBQ0Y7O0VBRUE7RUFDQTtFQUNBOztFQUVBO0FBQ0Y7QUFDQTtBQUNBO0VBQ0UsYUFBYXFDLGVBQWVBLENBQzFCMUMsTUFBVyxFQUNYQyxLQUFhLEVBQ2JDLElBQVMsRUFDZ0M7SUFBQSxJQUFBeUMscUJBQUEsRUFBQUMsa0JBQUE7SUFDekMsTUFBTTtNQUFFMUMsSUFBSSxFQUFFMEI7SUFBTyxDQUFDLEdBQUcsTUFBTTVCLE1BQU0sQ0FBQzZDLE1BQU0sQ0FBQztNQUFFNUMsS0FBSztNQUFFQztJQUFLLENBQUMsQ0FBQztJQUM3RCxNQUFNNEMsS0FBSyxHQUNULE9BQU9sQixNQUFNLENBQUNtQixJQUFJLENBQUNELEtBQUssS0FBSyxRQUFRLEdBQ2pDbEIsTUFBTSxDQUFDbUIsSUFBSSxDQUFDRCxLQUFLLElBQUFILHFCQUFBLElBQUFDLGtCQUFBLEdBQ2pCaEIsTUFBTSxDQUFDbUIsSUFBSSxDQUFDRCxLQUFLLGNBQUFGLGtCQUFBLHVCQUFqQkEsa0JBQUEsQ0FBbUIxRCxLQUFLLGNBQUF5RCxxQkFBQSxjQUFBQSxxQkFBQSxHQUFJLENBQUM7SUFDbkMsT0FBTztNQUNMSSxJQUFJLEVBQUVuQixNQUFNLENBQUNtQixJQUFJLENBQUNBLElBQUk7TUFDdEJEO0lBQ0YsQ0FBQztFQUNIOztFQUVBO0FBQ0Y7QUFDQTtBQUNBO0VBQ0UsYUFBYUUsa0JBQWtCQSxDQUM3QmhELE1BQVcsRUFDWEMsS0FBYSxFQUNiQyxJQUFTLEVBQ0s7SUFBQSxJQUFBK0Msb0JBQUE7SUFDZCxNQUFNO01BQUUvQyxJQUFJLEVBQUUwQjtJQUFPLENBQUMsR0FBRyxNQUFNNUIsTUFBTSxDQUFDNkMsTUFBTSxDQUFDO01BQUU1QyxLQUFLO01BQUVDLElBQUksRUFBRTtRQUFFZ0QsSUFBSSxFQUFFLENBQUM7UUFBRSxHQUFHaEQ7TUFBSztJQUFFLENBQUMsQ0FBQztJQUNuRixRQUFBK0Msb0JBQUEsR0FBT3JCLE1BQU0sQ0FBQ3VCLFlBQVksY0FBQUYsb0JBQUEsY0FBQUEsb0JBQUEsR0FBSSxDQUFDLENBQUM7RUFDbEM7O0VBRUE7RUFDQTtFQUNBOztFQUVBOztFQUdBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7RUFDRSxhQUFhRyxtQkFBbUJBLENBQUNwRCxNQUFXLEVBQW1CO0lBQzdELE1BQU1xRCxXQUFXLEdBQUcsRUFBRTtJQUV0QixLQUFLLElBQUlDLE9BQU8sR0FBRyxDQUFDLEVBQUVBLE9BQU8sR0FBR0QsV0FBVyxFQUFFQyxPQUFPLEVBQUUsRUFBRTtNQUN0RCxJQUFJQyxLQUF5QjtNQUM3QixJQUFJQyxXQUErQjtNQUNuQyxJQUFJQyxZQUFZLEdBQUcsQ0FBQzs7TUFFcEI7TUFDQSxJQUFJO1FBQUEsSUFBQUMscUJBQUEsRUFBQUMsYUFBQTtRQUNGLE1BQU07VUFBRXpEO1FBQUssQ0FBQyxHQUFHLE1BQU1GLE1BQU0sQ0FBQytCLEdBQUcsQ0FBQztVQUNoQzlCLEtBQUssRUFBRTJELDZCQUFrQjtVQUN6Qm5DLEVBQUUsRUFBRTNCLGlCQUFpQixDQUFDK0Q7UUFDeEIsQ0FBQyxDQUFDO1FBQ0ZOLEtBQUssR0FBR3JELElBQUksQ0FBQzRELE9BQU87UUFDcEJOLFdBQVcsR0FBR3RELElBQUksQ0FBQzZELGFBQWE7UUFDaENOLFlBQVksSUFBQUMscUJBQUEsSUFBQUMsYUFBQSxHQUFHekQsSUFBSSxDQUFDOEIsT0FBTyxjQUFBMkIsYUFBQSx1QkFBWkEsYUFBQSxDQUFjSyxhQUFhLGNBQUFOLHFCQUFBLGNBQUFBLHFCQUFBLEdBQUksQ0FBQztNQUNqRCxDQUFDLENBQUMsT0FBT08sR0FBUSxFQUFFO1FBQUEsSUFBQUMsU0FBQTtRQUNqQjtRQUNBLElBQUksQ0FBQUQsR0FBRyxhQUFIQSxHQUFHLHVCQUFIQSxHQUFHLENBQUUvQixVQUFVLE1BQUssR0FBRyxJQUFJLENBQUErQixHQUFHLGFBQUhBLEdBQUcsZ0JBQUFDLFNBQUEsR0FBSEQsR0FBRyxDQUFFMUMsSUFBSSxjQUFBMkMsU0FBQSx1QkFBVEEsU0FBQSxDQUFXaEMsVUFBVSxNQUFLLEdBQUcsRUFBRTtVQUM1RCxNQUFNK0IsR0FBRztRQUNYO01BQ0Y7TUFFQSxNQUFNRSxTQUFTLEdBQUdWLFlBQVksR0FBRyxDQUFDO01BRWxDLElBQUk7UUFDRixJQUFJRixLQUFLLEtBQUthLFNBQVMsRUFBRTtVQUN2QjtVQUNBLE1BQU1wRSxNQUFNLENBQUNDLEtBQUssQ0FBQztZQUNqQkEsS0FBSyxFQUFFMkQsNkJBQWtCO1lBQ3pCbkMsRUFBRSxFQUFFM0IsaUJBQWlCLENBQUMrRCxjQUFjO1lBQ3BDM0QsSUFBSSxFQUFFO2NBQUVtRSxZQUFZLEVBQUUsU0FBUztjQUFFTCxhQUFhLEVBQUVHO1lBQVUsQ0FBQztZQUMzREcsT0FBTyxFQUFFLFFBQVE7WUFDakIzQyxPQUFPLEVBQUU7VUFDWCxDQUFDLENBQUM7UUFDSixDQUFDLE1BQU07VUFDTDtVQUNBLE1BQU0zQixNQUFNLENBQUNDLEtBQUssQ0FBQztZQUNqQkEsS0FBSyxFQUFFMkQsNkJBQWtCO1lBQ3pCbkMsRUFBRSxFQUFFM0IsaUJBQWlCLENBQUMrRCxjQUFjO1lBQ3BDM0QsSUFBSSxFQUFFO2NBQUVtRSxZQUFZLEVBQUUsU0FBUztjQUFFTCxhQUFhLEVBQUVHO1lBQVUsQ0FBQztZQUMzREksU0FBUyxFQUFFaEIsS0FBSztZQUNoQmlCLGVBQWUsRUFBRWhCLFdBQVc7WUFDNUI3QixPQUFPLEVBQUU7VUFDWCxDQUFDLENBQUM7UUFDSjtRQUNBLE9BQU93QyxTQUFTO01BQ2xCLENBQUMsQ0FBQyxPQUFPRixHQUFRLEVBQUU7UUFBQSxJQUFBUSxlQUFBLEVBQUFDLFVBQUE7UUFDakIsTUFBTUMsTUFBTSxJQUFBRixlQUFBLEdBQUdSLEdBQUcsYUFBSEEsR0FBRyx1QkFBSEEsR0FBRyxDQUFFL0IsVUFBVSxjQUFBdUMsZUFBQSxjQUFBQSxlQUFBLEdBQUlSLEdBQUcsYUFBSEEsR0FBRyxnQkFBQVMsVUFBQSxHQUFIVCxHQUFHLENBQUUxQyxJQUFJLGNBQUFtRCxVQUFBLHVCQUFUQSxVQUFBLENBQVd4QyxVQUFVO1FBQ3ZEO1FBQ0EsSUFBSXlDLE1BQU0sS0FBSyxHQUFHLEVBQUU7VUFDbEI7UUFDRjtRQUNBLE1BQU1WLEdBQUc7TUFDWDtJQUNGOztJQUVBO0lBQ0EsT0FBT1csSUFBSSxDQUFDQyxHQUFHLENBQUMsQ0FBQztFQUNuQjtBQUNGO0FBQUNDLE9BQUEsQ0FBQWhGLGlCQUFBLEdBQUFBLGlCQUFBO0FBQUFuQixlQUFBLENBOU9ZbUIsaUJBQWlCLG9CQTBLYSxpQkFBaUIifQ==