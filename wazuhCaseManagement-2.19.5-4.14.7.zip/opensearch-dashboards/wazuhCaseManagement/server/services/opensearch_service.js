"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.OpenSearchService = void 0;
var _constants = require("../../common/constants");
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); } /*
 * Wazuh Case Management Plugin
 * OpenSearch Service — Low-level OpenSearch client operations
 *
 * Provides reusable CRUD helpers, search, aggregation, and counter management
 * that wrap the OpenSearch client obtained from the request context.
 * This service is stateless — every method receives the client explicitly.
 */
/** A minimal interface representing the scoped OpenSearch client */

/**
 * OpenSearchService — thin wrapper around the scoped OpenSearch client.
 *
 * Design notes:
 *  - Every public method is static so callers don't need to manage instances.
 *  - The `client` parameter must be `context.core.opensearch.client.asCurrentUser`.
 */
class OpenSearchService {
  // ──────────────────────────────────────────────────────────────
  // Index operations
  // ──────────────────────────────────────────────────────────────

  /** Check whether an index already exists */
  static async indexExists(client, index) {
    try {
      const {
        body
      } = await client.indices.exists({
        index
      });
      return body;
    } catch (error) {
      // 404 means it does not exist — not an error
      return false;
    }
  }

  /** Create an index with the given body (settings + mappings) */
  static async createIndex(client, index, body) {
    await client.indices.create({
      index,
      body
    });
  }

  // ──────────────────────────────────────────────────────────────
  // Document CRUD
  // ──────────────────────────────────────────────────────────────

  /**
   * Index (create/overwrite) a document.
   * If `id` is provided the document is stored under that _id, otherwise
   * OpenSearch auto-generates one.
   */
  static async createDocument(client, index, body, id) {
    const params = {
      index,
      body,
      refresh: 'wait_for'
    };
    if (id) params.id = id;
    const {
      body: result
    } = await client.index(params);
    return {
      _id: result._id
    };
  }

  /** Retrieve a single document by _id */
  static async getDocument(client, index, id) {
    try {
      const {
        body
      } = await client.get({
        index,
        id
      });
      return {
        _id: body._id,
        _source: body._source
      };
    } catch (error) {
      var _error$meta;
      if ((error === null || error === void 0 ? void 0 : error.statusCode) === 404 || (error === null || error === void 0 || (_error$meta = error.meta) === null || _error$meta === void 0 ? void 0 : _error$meta.statusCode) === 404) {
        return null;
      }
      throw error;
    }
  }

  /** Partially update a document (merge fields) */
  static async updateDocument(client, index, id, doc) {
    await client.update({
      index,
      id,
      body: {
        doc
      },
      refresh: 'wait_for',
      retry_on_conflict: 3
    });
  }

  /** Delete a document by _id */
  static async deleteDocument(client, index, id) {
    try {
      await client.delete({
        index,
        id,
        refresh: 'wait_for'
      });
      return true;
    } catch (error) {
      var _error$meta2;
      if ((error === null || error === void 0 ? void 0 : error.statusCode) === 404 || (error === null || error === void 0 || (_error$meta2 = error.meta) === null || _error$meta2 === void 0 ? void 0 : _error$meta2.statusCode) === 404) {
        return false;
      }
      throw error;
    }
  }

  // ──────────────────────────────────────────────────────────────
  // Search & Aggregation
  // ──────────────────────────────────────────────────────────────

  /**
   * Perform a search query against an index.
   * Returns the raw hits array together with the total count.
   */
  static async searchDocuments(client, index, body) {
    var _result$hits$total$va, _result$hits$total;
    const {
      body: result
    } = await client.search({
      index,
      body
    });
    const total = typeof result.hits.total === 'number' ? result.hits.total : (_result$hits$total$va = (_result$hits$total = result.hits.total) === null || _result$hits$total === void 0 ? void 0 : _result$hits$total.value) !== null && _result$hits$total$va !== void 0 ? _result$hits$total$va : 0;
    return {
      hits: result.hits.hits,
      total
    };
  }

  /**
   * Run an aggregation-only query (size=0).
   * Returns the raw aggregations object.
   */
  static async aggregateDocuments(client, index, body) {
    var _result$aggregations;
    const {
      body: result
    } = await client.search({
      index,
      body: {
        size: 0,
        ...body
      }
    });
    return (_result$aggregations = result.aggregations) !== null && _result$aggregations !== void 0 ? _result$aggregations : {};
  }

  // ──────────────────────────────────────────────────────────────
  // Counter management for case ID generation
  // ──────────────────────────────────────────────────────────────

  /** The well-known document ID that holds the case counter */

  /**
   * Atomically increment-and-return the case counter.
   * Uses optimistic concurrency control (seq_no + primary_term) instead of
   * Painless scripts, which may be disabled in Wazuh's OpenSearch deployment.
   */
  static async getNextCounterValue(client) {
    const MAX_RETRIES = 10;
    for (let attempt = 0; attempt < MAX_RETRIES; attempt++) {
      let seqNo;
      let primaryTerm;
      let currentValue = 0;

      // Try to read the existing counter document
      try {
        var _body$_source$current, _body$_source;
        const {
          body
        } = await client.get({
          index: _constants.CASE_COUNTER_INDEX,
          id: OpenSearchService.COUNTER_DOC_ID
        });
        seqNo = body._seq_no;
        primaryTerm = body._primary_term;
        currentValue = (_body$_source$current = (_body$_source = body._source) === null || _body$_source === void 0 ? void 0 : _body$_source.current_value) !== null && _body$_source$current !== void 0 ? _body$_source$current : 0;
      } catch (err) {
        var _err$meta;
        // 404 — counter doesn't exist yet, we'll create it below
        if ((err === null || err === void 0 ? void 0 : err.statusCode) !== 404 && (err === null || err === void 0 || (_err$meta = err.meta) === null || _err$meta === void 0 ? void 0 : _err$meta.statusCode) !== 404) {
          throw err;
        }
      }
      const nextValue = currentValue + 1;
      try {
        if (seqNo === undefined) {
          // Create the counter document for the first time
          await client.index({
            index: _constants.CASE_COUNTER_INDEX,
            id: OpenSearchService.COUNTER_DOC_ID,
            body: {
              counter_name: 'case_id',
              current_value: nextValue
            },
            op_type: 'create',
            refresh: 'wait_for'
          });
        } else {
          // Update with optimistic concurrency check
          await client.index({
            index: _constants.CASE_COUNTER_INDEX,
            id: OpenSearchService.COUNTER_DOC_ID,
            body: {
              counter_name: 'case_id',
              current_value: nextValue
            },
            if_seq_no: seqNo,
            if_primary_term: primaryTerm,
            refresh: 'wait_for'
          });
        }
        return nextValue;
      } catch (err) {
        var _err$statusCode, _err$meta2;
        const status = (_err$statusCode = err === null || err === void 0 ? void 0 : err.statusCode) !== null && _err$statusCode !== void 0 ? _err$statusCode : err === null || err === void 0 || (_err$meta2 = err.meta) === null || _err$meta2 === void 0 ? void 0 : _err$meta2.statusCode;
        // 409 conflict means another request updated the counter first — retry
        if (status === 409) {
          continue;
        }
        throw err;
      }
    }

    // Fallback: use timestamp-based value if all retries exhausted
    return Date.now();
  }
}
exports.OpenSearchService = OpenSearchService;
_defineProperty(OpenSearchService, "COUNTER_DOC_ID", 'case_id_counter');
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfY29uc3RhbnRzIiwicmVxdWlyZSIsIl9kZWZpbmVQcm9wZXJ0eSIsImUiLCJyIiwidCIsIl90b1Byb3BlcnR5S2V5IiwiT2JqZWN0IiwiZGVmaW5lUHJvcGVydHkiLCJ2YWx1ZSIsImVudW1lcmFibGUiLCJjb25maWd1cmFibGUiLCJ3cml0YWJsZSIsImkiLCJfdG9QcmltaXRpdmUiLCJTeW1ib2wiLCJ0b1ByaW1pdGl2ZSIsImNhbGwiLCJUeXBlRXJyb3IiLCJTdHJpbmciLCJOdW1iZXIiLCJPcGVuU2VhcmNoU2VydmljZSIsImluZGV4RXhpc3RzIiwiY2xpZW50IiwiaW5kZXgiLCJib2R5IiwiaW5kaWNlcyIsImV4aXN0cyIsImVycm9yIiwiY3JlYXRlSW5kZXgiLCJjcmVhdGUiLCJjcmVhdGVEb2N1bWVudCIsImlkIiwicGFyYW1zIiwicmVmcmVzaCIsInJlc3VsdCIsIl9pZCIsImdldERvY3VtZW50IiwiZ2V0IiwiX3NvdXJjZSIsIl9lcnJvciRtZXRhIiwic3RhdHVzQ29kZSIsIm1ldGEiLCJ1cGRhdGVEb2N1bWVudCIsImRvYyIsInVwZGF0ZSIsInJldHJ5X29uX2NvbmZsaWN0IiwiZGVsZXRlRG9jdW1lbnQiLCJkZWxldGUiLCJfZXJyb3IkbWV0YTIiLCJzZWFyY2hEb2N1bWVudHMiLCJfcmVzdWx0JGhpdHMkdG90YWwkdmEiLCJfcmVzdWx0JGhpdHMkdG90YWwiLCJzZWFyY2giLCJ0b3RhbCIsImhpdHMiLCJhZ2dyZWdhdGVEb2N1bWVudHMiLCJfcmVzdWx0JGFnZ3JlZ2F0aW9ucyIsInNpemUiLCJhZ2dyZWdhdGlvbnMiLCJnZXROZXh0Q291bnRlclZhbHVlIiwiTUFYX1JFVFJJRVMiLCJhdHRlbXB0Iiwic2VxTm8iLCJwcmltYXJ5VGVybSIsImN1cnJlbnRWYWx1ZSIsIl9ib2R5JF9zb3VyY2UkY3VycmVudCIsIl9ib2R5JF9zb3VyY2UiLCJDQVNFX0NPVU5URVJfSU5ERVgiLCJDT1VOVEVSX0RPQ19JRCIsIl9zZXFfbm8iLCJfcHJpbWFyeV90ZXJtIiwiY3VycmVudF92YWx1ZSIsImVyciIsIl9lcnIkbWV0YSIsIm5leHRWYWx1ZSIsInVuZGVmaW5lZCIsImNvdW50ZXJfbmFtZSIsIm9wX3R5cGUiLCJpZl9zZXFfbm8iLCJpZl9wcmltYXJ5X3Rlcm0iLCJfZXJyJHN0YXR1c0NvZGUiLCJfZXJyJG1ldGEyIiwic3RhdHVzIiwiRGF0ZSIsIm5vdyIsImV4cG9ydHMiXSwic291cmNlcyI6WyJvcGVuc2VhcmNoX3NlcnZpY2UudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLypcbiAqIFdhenVoIENhc2UgTWFuYWdlbWVudCBQbHVnaW5cbiAqIE9wZW5TZWFyY2ggU2VydmljZSDigJQgTG93LWxldmVsIE9wZW5TZWFyY2ggY2xpZW50IG9wZXJhdGlvbnNcbiAqXG4gKiBQcm92aWRlcyByZXVzYWJsZSBDUlVEIGhlbHBlcnMsIHNlYXJjaCwgYWdncmVnYXRpb24sIGFuZCBjb3VudGVyIG1hbmFnZW1lbnRcbiAqIHRoYXQgd3JhcCB0aGUgT3BlblNlYXJjaCBjbGllbnQgb2J0YWluZWQgZnJvbSB0aGUgcmVxdWVzdCBjb250ZXh0LlxuICogVGhpcyBzZXJ2aWNlIGlzIHN0YXRlbGVzcyDigJQgZXZlcnkgbWV0aG9kIHJlY2VpdmVzIHRoZSBjbGllbnQgZXhwbGljaXRseS5cbiAqL1xuXG5pbXBvcnQgeyBDQVNFX0NPVU5URVJfSU5ERVggfSBmcm9tICcuLi8uLi9jb21tb24vY29uc3RhbnRzJztcblxuLyoqIEEgbWluaW1hbCBpbnRlcmZhY2UgcmVwcmVzZW50aW5nIHRoZSBzY29wZWQgT3BlblNlYXJjaCBjbGllbnQgKi9cbnR5cGUgT3BlblNlYXJjaENsaWVudCA9IHtcbiAgaW5kaWNlczoge1xuICAgIGV4aXN0czogKHBhcmFtczogYW55KSA9PiBQcm9taXNlPHsgYm9keTogYm9vbGVhbiB9PjtcbiAgICBjcmVhdGU6IChwYXJhbXM6IGFueSkgPT4gUHJvbWlzZTxhbnk+O1xuICB9O1xuICBpbmRleDogKHBhcmFtczogYW55KSA9PiBQcm9taXNlPGFueT47XG4gIGdldDogKHBhcmFtczogYW55KSA9PiBQcm9taXNlPGFueT47XG4gIHVwZGF0ZTogKHBhcmFtczogYW55KSA9PiBQcm9taXNlPGFueT47XG4gIGRlbGV0ZTogKHBhcmFtczogYW55KSA9PiBQcm9taXNlPGFueT47XG4gIHNlYXJjaDogKHBhcmFtczogYW55KSA9PiBQcm9taXNlPGFueT47XG4gIGNvdW50OiAocGFyYW1zOiBhbnkpID0+IFByb21pc2U8YW55Pjtcbn07XG5cbi8qKlxuICogT3BlblNlYXJjaFNlcnZpY2Ug4oCUIHRoaW4gd3JhcHBlciBhcm91bmQgdGhlIHNjb3BlZCBPcGVuU2VhcmNoIGNsaWVudC5cbiAqXG4gKiBEZXNpZ24gbm90ZXM6XG4gKiAgLSBFdmVyeSBwdWJsaWMgbWV0aG9kIGlzIHN0YXRpYyBzbyBjYWxsZXJzIGRvbid0IG5lZWQgdG8gbWFuYWdlIGluc3RhbmNlcy5cbiAqICAtIFRoZSBgY2xpZW50YCBwYXJhbWV0ZXIgbXVzdCBiZSBgY29udGV4dC5jb3JlLm9wZW5zZWFyY2guY2xpZW50LmFzQ3VycmVudFVzZXJgLlxuICovXG5leHBvcnQgY2xhc3MgT3BlblNlYXJjaFNlcnZpY2Uge1xuICAvLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAgLy8gSW5kZXggb3BlcmF0aW9uc1xuICAvLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuICAvKiogQ2hlY2sgd2hldGhlciBhbiBpbmRleCBhbHJlYWR5IGV4aXN0cyAqL1xuICBzdGF0aWMgYXN5bmMgaW5kZXhFeGlzdHMoY2xpZW50OiBhbnksIGluZGV4OiBzdHJpbmcpOiBQcm9taXNlPGJvb2xlYW4+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgeyBib2R5IH0gPSBhd2FpdCBjbGllbnQuaW5kaWNlcy5leGlzdHMoeyBpbmRleCB9KTtcbiAgICAgIHJldHVybiBib2R5IGFzIGJvb2xlYW47XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIC8vIDQwNCBtZWFucyBpdCBkb2VzIG5vdCBleGlzdCDigJQgbm90IGFuIGVycm9yXG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICB9XG5cbiAgLyoqIENyZWF0ZSBhbiBpbmRleCB3aXRoIHRoZSBnaXZlbiBib2R5IChzZXR0aW5ncyArIG1hcHBpbmdzKSAqL1xuICBzdGF0aWMgYXN5bmMgY3JlYXRlSW5kZXgoY2xpZW50OiBhbnksIGluZGV4OiBzdHJpbmcsIGJvZHk6IGFueSk6IFByb21pc2U8dm9pZD4ge1xuICAgIGF3YWl0IGNsaWVudC5pbmRpY2VzLmNyZWF0ZSh7IGluZGV4LCBib2R5IH0pO1xuICB9XG5cbiAgLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG4gIC8vIERvY3VtZW50IENSVURcbiAgLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbiAgLyoqXG4gICAqIEluZGV4IChjcmVhdGUvb3ZlcndyaXRlKSBhIGRvY3VtZW50LlxuICAgKiBJZiBgaWRgIGlzIHByb3ZpZGVkIHRoZSBkb2N1bWVudCBpcyBzdG9yZWQgdW5kZXIgdGhhdCBfaWQsIG90aGVyd2lzZVxuICAgKiBPcGVuU2VhcmNoIGF1dG8tZ2VuZXJhdGVzIG9uZS5cbiAgICovXG4gIHN0YXRpYyBhc3luYyBjcmVhdGVEb2N1bWVudChcbiAgICBjbGllbnQ6IGFueSxcbiAgICBpbmRleDogc3RyaW5nLFxuICAgIGJvZHk6IGFueSxcbiAgICBpZD86IHN0cmluZyxcbiAgKTogUHJvbWlzZTx7IF9pZDogc3RyaW5nIH0+IHtcbiAgICBjb25zdCBwYXJhbXM6IGFueSA9IHsgaW5kZXgsIGJvZHksIHJlZnJlc2g6ICd3YWl0X2ZvcicgfTtcbiAgICBpZiAoaWQpIHBhcmFtcy5pZCA9IGlkO1xuICAgIGNvbnN0IHsgYm9keTogcmVzdWx0IH0gPSBhd2FpdCBjbGllbnQuaW5kZXgocGFyYW1zKTtcbiAgICByZXR1cm4geyBfaWQ6IHJlc3VsdC5faWQgfTtcbiAgfVxuXG4gIC8qKiBSZXRyaWV2ZSBhIHNpbmdsZSBkb2N1bWVudCBieSBfaWQgKi9cbiAgc3RhdGljIGFzeW5jIGdldERvY3VtZW50KGNsaWVudDogYW55LCBpbmRleDogc3RyaW5nLCBpZDogc3RyaW5nKTogUHJvbWlzZTxhbnk+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgeyBib2R5IH0gPSBhd2FpdCBjbGllbnQuZ2V0KHsgaW5kZXgsIGlkIH0pO1xuICAgICAgcmV0dXJuIHsgX2lkOiBib2R5Ll9pZCwgX3NvdXJjZTogYm9keS5fc291cmNlIH07XG4gICAgfSBjYXRjaCAoZXJyb3I6IGFueSkge1xuICAgICAgaWYgKGVycm9yPy5zdGF0dXNDb2RlID09PSA0MDQgfHwgZXJyb3I/Lm1ldGE/LnN0YXR1c0NvZGUgPT09IDQwNCkge1xuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgIH1cbiAgICAgIHRocm93IGVycm9yO1xuICAgIH1cbiAgfVxuXG4gIC8qKiBQYXJ0aWFsbHkgdXBkYXRlIGEgZG9jdW1lbnQgKG1lcmdlIGZpZWxkcykgKi9cbiAgc3RhdGljIGFzeW5jIHVwZGF0ZURvY3VtZW50KFxuICAgIGNsaWVudDogYW55LFxuICAgIGluZGV4OiBzdHJpbmcsXG4gICAgaWQ6IHN0cmluZyxcbiAgICBkb2M6IGFueSxcbiAgKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgYXdhaXQgY2xpZW50LnVwZGF0ZSh7XG4gICAgICBpbmRleCxcbiAgICAgIGlkLFxuICAgICAgYm9keTogeyBkb2MgfSxcbiAgICAgIHJlZnJlc2g6ICd3YWl0X2ZvcicsXG4gICAgICByZXRyeV9vbl9jb25mbGljdDogMyxcbiAgICB9KTtcbiAgfVxuXG4gIC8qKiBEZWxldGUgYSBkb2N1bWVudCBieSBfaWQgKi9cbiAgc3RhdGljIGFzeW5jIGRlbGV0ZURvY3VtZW50KGNsaWVudDogYW55LCBpbmRleDogc3RyaW5nLCBpZDogc3RyaW5nKTogUHJvbWlzZTxib29sZWFuPiB7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IGNsaWVudC5kZWxldGUoeyBpbmRleCwgaWQsIHJlZnJlc2g6ICd3YWl0X2ZvcicgfSk7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9IGNhdGNoIChlcnJvcjogYW55KSB7XG4gICAgICBpZiAoZXJyb3I/LnN0YXR1c0NvZGUgPT09IDQwNCB8fCBlcnJvcj8ubWV0YT8uc3RhdHVzQ29kZSA9PT0gNDA0KSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIH1cbiAgICAgIHRocm93IGVycm9yO1xuICAgIH1cbiAgfVxuXG4gIC8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICAvLyBTZWFyY2ggJiBBZ2dyZWdhdGlvblxuICAvLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuICAvKipcbiAgICogUGVyZm9ybSBhIHNlYXJjaCBxdWVyeSBhZ2FpbnN0IGFuIGluZGV4LlxuICAgKiBSZXR1cm5zIHRoZSByYXcgaGl0cyBhcnJheSB0b2dldGhlciB3aXRoIHRoZSB0b3RhbCBjb3VudC5cbiAgICovXG4gIHN0YXRpYyBhc3luYyBzZWFyY2hEb2N1bWVudHMoXG4gICAgY2xpZW50OiBhbnksXG4gICAgaW5kZXg6IHN0cmluZyxcbiAgICBib2R5OiBhbnksXG4gICk6IFByb21pc2U8eyBoaXRzOiBhbnlbXTsgdG90YWw6IG51bWJlciB9PiB7XG4gICAgY29uc3QgeyBib2R5OiByZXN1bHQgfSA9IGF3YWl0IGNsaWVudC5zZWFyY2goeyBpbmRleCwgYm9keSB9KTtcbiAgICBjb25zdCB0b3RhbCA9XG4gICAgICB0eXBlb2YgcmVzdWx0LmhpdHMudG90YWwgPT09ICdudW1iZXInXG4gICAgICAgID8gcmVzdWx0LmhpdHMudG90YWxcbiAgICAgICAgOiByZXN1bHQuaGl0cy50b3RhbD8udmFsdWUgPz8gMDtcbiAgICByZXR1cm4ge1xuICAgICAgaGl0czogcmVzdWx0LmhpdHMuaGl0cyxcbiAgICAgIHRvdGFsLFxuICAgIH07XG4gIH1cblxuICAvKipcbiAgICogUnVuIGFuIGFnZ3JlZ2F0aW9uLW9ubHkgcXVlcnkgKHNpemU9MCkuXG4gICAqIFJldHVybnMgdGhlIHJhdyBhZ2dyZWdhdGlvbnMgb2JqZWN0LlxuICAgKi9cbiAgc3RhdGljIGFzeW5jIGFnZ3JlZ2F0ZURvY3VtZW50cyhcbiAgICBjbGllbnQ6IGFueSxcbiAgICBpbmRleDogc3RyaW5nLFxuICAgIGJvZHk6IGFueSxcbiAgKTogUHJvbWlzZTxhbnk+IHtcbiAgICBjb25zdCB7IGJvZHk6IHJlc3VsdCB9ID0gYXdhaXQgY2xpZW50LnNlYXJjaCh7IGluZGV4LCBib2R5OiB7IHNpemU6IDAsIC4uLmJvZHkgfSB9KTtcbiAgICByZXR1cm4gcmVzdWx0LmFnZ3JlZ2F0aW9ucyA/PyB7fTtcbiAgfVxuXG4gIC8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuICAvLyBDb3VudGVyIG1hbmFnZW1lbnQgZm9yIGNhc2UgSUQgZ2VuZXJhdGlvblxuICAvLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuICAvKiogVGhlIHdlbGwta25vd24gZG9jdW1lbnQgSUQgdGhhdCBob2xkcyB0aGUgY2FzZSBjb3VudGVyICovXG4gIHByaXZhdGUgc3RhdGljIHJlYWRvbmx5IENPVU5URVJfRE9DX0lEID0gJ2Nhc2VfaWRfY291bnRlcic7XG5cbiAgLyoqXG4gICAqIEF0b21pY2FsbHkgaW5jcmVtZW50LWFuZC1yZXR1cm4gdGhlIGNhc2UgY291bnRlci5cbiAgICogVXNlcyBvcHRpbWlzdGljIGNvbmN1cnJlbmN5IGNvbnRyb2wgKHNlcV9ubyArIHByaW1hcnlfdGVybSkgaW5zdGVhZCBvZlxuICAgKiBQYWlubGVzcyBzY3JpcHRzLCB3aGljaCBtYXkgYmUgZGlzYWJsZWQgaW4gV2F6dWgncyBPcGVuU2VhcmNoIGRlcGxveW1lbnQuXG4gICAqL1xuICBzdGF0aWMgYXN5bmMgZ2V0TmV4dENvdW50ZXJWYWx1ZShjbGllbnQ6IGFueSk6IFByb21pc2U8bnVtYmVyPiB7XG4gICAgY29uc3QgTUFYX1JFVFJJRVMgPSAxMDtcblxuICAgIGZvciAobGV0IGF0dGVtcHQgPSAwOyBhdHRlbXB0IDwgTUFYX1JFVFJJRVM7IGF0dGVtcHQrKykge1xuICAgICAgbGV0IHNlcU5vOiBudW1iZXIgfCB1bmRlZmluZWQ7XG4gICAgICBsZXQgcHJpbWFyeVRlcm06IG51bWJlciB8IHVuZGVmaW5lZDtcbiAgICAgIGxldCBjdXJyZW50VmFsdWUgPSAwO1xuXG4gICAgICAvLyBUcnkgdG8gcmVhZCB0aGUgZXhpc3RpbmcgY291bnRlciBkb2N1bWVudFxuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgeyBib2R5IH0gPSBhd2FpdCBjbGllbnQuZ2V0KHtcbiAgICAgICAgICBpbmRleDogQ0FTRV9DT1VOVEVSX0lOREVYLFxuICAgICAgICAgIGlkOiBPcGVuU2VhcmNoU2VydmljZS5DT1VOVEVSX0RPQ19JRCxcbiAgICAgICAgfSk7XG4gICAgICAgIHNlcU5vID0gYm9keS5fc2VxX25vO1xuICAgICAgICBwcmltYXJ5VGVybSA9IGJvZHkuX3ByaW1hcnlfdGVybTtcbiAgICAgICAgY3VycmVudFZhbHVlID0gYm9keS5fc291cmNlPy5jdXJyZW50X3ZhbHVlID8/IDA7XG4gICAgICB9IGNhdGNoIChlcnI6IGFueSkge1xuICAgICAgICAvLyA0MDQg4oCUIGNvdW50ZXIgZG9lc24ndCBleGlzdCB5ZXQsIHdlJ2xsIGNyZWF0ZSBpdCBiZWxvd1xuICAgICAgICBpZiAoZXJyPy5zdGF0dXNDb2RlICE9PSA0MDQgJiYgZXJyPy5tZXRhPy5zdGF0dXNDb2RlICE9PSA0MDQpIHtcbiAgICAgICAgICB0aHJvdyBlcnI7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgY29uc3QgbmV4dFZhbHVlID0gY3VycmVudFZhbHVlICsgMTtcblxuICAgICAgdHJ5IHtcbiAgICAgICAgaWYgKHNlcU5vID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAvLyBDcmVhdGUgdGhlIGNvdW50ZXIgZG9jdW1lbnQgZm9yIHRoZSBmaXJzdCB0aW1lXG4gICAgICAgICAgYXdhaXQgY2xpZW50LmluZGV4KHtcbiAgICAgICAgICAgIGluZGV4OiBDQVNFX0NPVU5URVJfSU5ERVgsXG4gICAgICAgICAgICBpZDogT3BlblNlYXJjaFNlcnZpY2UuQ09VTlRFUl9ET0NfSUQsXG4gICAgICAgICAgICBib2R5OiB7IGNvdW50ZXJfbmFtZTogJ2Nhc2VfaWQnLCBjdXJyZW50X3ZhbHVlOiBuZXh0VmFsdWUgfSxcbiAgICAgICAgICAgIG9wX3R5cGU6ICdjcmVhdGUnLFxuICAgICAgICAgICAgcmVmcmVzaDogJ3dhaXRfZm9yJyxcbiAgICAgICAgICB9KTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAvLyBVcGRhdGUgd2l0aCBvcHRpbWlzdGljIGNvbmN1cnJlbmN5IGNoZWNrXG4gICAgICAgICAgYXdhaXQgY2xpZW50LmluZGV4KHtcbiAgICAgICAgICAgIGluZGV4OiBDQVNFX0NPVU5URVJfSU5ERVgsXG4gICAgICAgICAgICBpZDogT3BlblNlYXJjaFNlcnZpY2UuQ09VTlRFUl9ET0NfSUQsXG4gICAgICAgICAgICBib2R5OiB7IGNvdW50ZXJfbmFtZTogJ2Nhc2VfaWQnLCBjdXJyZW50X3ZhbHVlOiBuZXh0VmFsdWUgfSxcbiAgICAgICAgICAgIGlmX3NlcV9ubzogc2VxTm8sXG4gICAgICAgICAgICBpZl9wcmltYXJ5X3Rlcm06IHByaW1hcnlUZXJtLFxuICAgICAgICAgICAgcmVmcmVzaDogJ3dhaXRfZm9yJyxcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gbmV4dFZhbHVlO1xuICAgICAgfSBjYXRjaCAoZXJyOiBhbnkpIHtcbiAgICAgICAgY29uc3Qgc3RhdHVzID0gZXJyPy5zdGF0dXNDb2RlID8/IGVycj8ubWV0YT8uc3RhdHVzQ29kZTtcbiAgICAgICAgLy8gNDA5IGNvbmZsaWN0IG1lYW5zIGFub3RoZXIgcmVxdWVzdCB1cGRhdGVkIHRoZSBjb3VudGVyIGZpcnN0IOKAlCByZXRyeVxuICAgICAgICBpZiAoc3RhdHVzID09PSA0MDkpIHtcbiAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuICAgICAgICB0aHJvdyBlcnI7XG4gICAgICB9XG4gICAgfVxuXG4gICAgLy8gRmFsbGJhY2s6IHVzZSB0aW1lc3RhbXAtYmFzZWQgdmFsdWUgaWYgYWxsIHJldHJpZXMgZXhoYXVzdGVkXG4gICAgcmV0dXJuIERhdGUubm93KCk7XG4gIH1cbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBU0EsSUFBQUEsVUFBQSxHQUFBQyxPQUFBO0FBQTRELFNBQUFDLGdCQUFBQyxDQUFBLEVBQUFDLENBQUEsRUFBQUMsQ0FBQSxZQUFBRCxDQUFBLEdBQUFFLGNBQUEsQ0FBQUYsQ0FBQSxNQUFBRCxDQUFBLEdBQUFJLE1BQUEsQ0FBQUMsY0FBQSxDQUFBTCxDQUFBLEVBQUFDLENBQUEsSUFBQUssS0FBQSxFQUFBSixDQUFBLEVBQUFLLFVBQUEsTUFBQUMsWUFBQSxNQUFBQyxRQUFBLFVBQUFULENBQUEsQ0FBQUMsQ0FBQSxJQUFBQyxDQUFBLEVBQUFGLENBQUE7QUFBQSxTQUFBRyxlQUFBRCxDQUFBLFFBQUFRLENBQUEsR0FBQUMsWUFBQSxDQUFBVCxDQUFBLHVDQUFBUSxDQUFBLEdBQUFBLENBQUEsR0FBQUEsQ0FBQTtBQUFBLFNBQUFDLGFBQUFULENBQUEsRUFBQUQsQ0FBQSwyQkFBQUMsQ0FBQSxLQUFBQSxDQUFBLFNBQUFBLENBQUEsTUFBQUYsQ0FBQSxHQUFBRSxDQUFBLENBQUFVLE1BQUEsQ0FBQUMsV0FBQSxrQkFBQWIsQ0FBQSxRQUFBVSxDQUFBLEdBQUFWLENBQUEsQ0FBQWMsSUFBQSxDQUFBWixDQUFBLEVBQUFELENBQUEsdUNBQUFTLENBQUEsU0FBQUEsQ0FBQSxZQUFBSyxTQUFBLHlFQUFBZCxDQUFBLEdBQUFlLE1BQUEsR0FBQUMsTUFBQSxFQUFBZixDQUFBLEtBVDVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFJQTs7QUFjQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLE1BQU1nQixpQkFBaUIsQ0FBQztFQUM3QjtFQUNBO0VBQ0E7O0VBRUE7RUFDQSxhQUFhQyxXQUFXQSxDQUFDQyxNQUFXLEVBQUVDLEtBQWEsRUFBb0I7SUFDckUsSUFBSTtNQUNGLE1BQU07UUFBRUM7TUFBSyxDQUFDLEdBQUcsTUFBTUYsTUFBTSxDQUFDRyxPQUFPLENBQUNDLE1BQU0sQ0FBQztRQUFFSDtNQUFNLENBQUMsQ0FBQztNQUN2RCxPQUFPQyxJQUFJO0lBQ2IsQ0FBQyxDQUFDLE9BQU9HLEtBQUssRUFBRTtNQUNkO01BQ0EsT0FBTyxLQUFLO0lBQ2Q7RUFDRjs7RUFFQTtFQUNBLGFBQWFDLFdBQVdBLENBQUNOLE1BQVcsRUFBRUMsS0FBYSxFQUFFQyxJQUFTLEVBQWlCO0lBQzdFLE1BQU1GLE1BQU0sQ0FBQ0csT0FBTyxDQUFDSSxNQUFNLENBQUM7TUFBRU4sS0FBSztNQUFFQztJQUFLLENBQUMsQ0FBQztFQUM5Qzs7RUFFQTtFQUNBO0VBQ0E7O0VBRUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtFQUNFLGFBQWFNLGNBQWNBLENBQ3pCUixNQUFXLEVBQ1hDLEtBQWEsRUFDYkMsSUFBUyxFQUNUTyxFQUFXLEVBQ2U7SUFDMUIsTUFBTUMsTUFBVyxHQUFHO01BQUVULEtBQUs7TUFBRUMsSUFBSTtNQUFFUyxPQUFPLEVBQUU7SUFBVyxDQUFDO0lBQ3hELElBQUlGLEVBQUUsRUFBRUMsTUFBTSxDQUFDRCxFQUFFLEdBQUdBLEVBQUU7SUFDdEIsTUFBTTtNQUFFUCxJQUFJLEVBQUVVO0lBQU8sQ0FBQyxHQUFHLE1BQU1aLE1BQU0sQ0FBQ0MsS0FBSyxDQUFDUyxNQUFNLENBQUM7SUFDbkQsT0FBTztNQUFFRyxHQUFHLEVBQUVELE1BQU0sQ0FBQ0M7SUFBSSxDQUFDO0VBQzVCOztFQUVBO0VBQ0EsYUFBYUMsV0FBV0EsQ0FBQ2QsTUFBVyxFQUFFQyxLQUFhLEVBQUVRLEVBQVUsRUFBZ0I7SUFDN0UsSUFBSTtNQUNGLE1BQU07UUFBRVA7TUFBSyxDQUFDLEdBQUcsTUFBTUYsTUFBTSxDQUFDZSxHQUFHLENBQUM7UUFBRWQsS0FBSztRQUFFUTtNQUFHLENBQUMsQ0FBQztNQUNoRCxPQUFPO1FBQUVJLEdBQUcsRUFBRVgsSUFBSSxDQUFDVyxHQUFHO1FBQUVHLE9BQU8sRUFBRWQsSUFBSSxDQUFDYztNQUFRLENBQUM7SUFDakQsQ0FBQyxDQUFDLE9BQU9YLEtBQVUsRUFBRTtNQUFBLElBQUFZLFdBQUE7TUFDbkIsSUFBSSxDQUFBWixLQUFLLGFBQUxBLEtBQUssdUJBQUxBLEtBQUssQ0FBRWEsVUFBVSxNQUFLLEdBQUcsSUFBSSxDQUFBYixLQUFLLGFBQUxBLEtBQUssZ0JBQUFZLFdBQUEsR0FBTFosS0FBSyxDQUFFYyxJQUFJLGNBQUFGLFdBQUEsdUJBQVhBLFdBQUEsQ0FBYUMsVUFBVSxNQUFLLEdBQUcsRUFBRTtRQUNoRSxPQUFPLElBQUk7TUFDYjtNQUNBLE1BQU1iLEtBQUs7SUFDYjtFQUNGOztFQUVBO0VBQ0EsYUFBYWUsY0FBY0EsQ0FDekJwQixNQUFXLEVBQ1hDLEtBQWEsRUFDYlEsRUFBVSxFQUNWWSxHQUFRLEVBQ087SUFDZixNQUFNckIsTUFBTSxDQUFDc0IsTUFBTSxDQUFDO01BQ2xCckIsS0FBSztNQUNMUSxFQUFFO01BQ0ZQLElBQUksRUFBRTtRQUFFbUI7TUFBSSxDQUFDO01BQ2JWLE9BQU8sRUFBRSxVQUFVO01BQ25CWSxpQkFBaUIsRUFBRTtJQUNyQixDQUFDLENBQUM7RUFDSjs7RUFFQTtFQUNBLGFBQWFDLGNBQWNBLENBQUN4QixNQUFXLEVBQUVDLEtBQWEsRUFBRVEsRUFBVSxFQUFvQjtJQUNwRixJQUFJO01BQ0YsTUFBTVQsTUFBTSxDQUFDeUIsTUFBTSxDQUFDO1FBQUV4QixLQUFLO1FBQUVRLEVBQUU7UUFBRUUsT0FBTyxFQUFFO01BQVcsQ0FBQyxDQUFDO01BQ3ZELE9BQU8sSUFBSTtJQUNiLENBQUMsQ0FBQyxPQUFPTixLQUFVLEVBQUU7TUFBQSxJQUFBcUIsWUFBQTtNQUNuQixJQUFJLENBQUFyQixLQUFLLGFBQUxBLEtBQUssdUJBQUxBLEtBQUssQ0FBRWEsVUFBVSxNQUFLLEdBQUcsSUFBSSxDQUFBYixLQUFLLGFBQUxBLEtBQUssZ0JBQUFxQixZQUFBLEdBQUxyQixLQUFLLENBQUVjLElBQUksY0FBQU8sWUFBQSx1QkFBWEEsWUFBQSxDQUFhUixVQUFVLE1BQUssR0FBRyxFQUFFO1FBQ2hFLE9BQU8sS0FBSztNQUNkO01BQ0EsTUFBTWIsS0FBSztJQUNiO0VBQ0Y7O0VBRUE7RUFDQTtFQUNBOztFQUVBO0FBQ0Y7QUFDQTtBQUNBO0VBQ0UsYUFBYXNCLGVBQWVBLENBQzFCM0IsTUFBVyxFQUNYQyxLQUFhLEVBQ2JDLElBQVMsRUFDZ0M7SUFBQSxJQUFBMEIscUJBQUEsRUFBQUMsa0JBQUE7SUFDekMsTUFBTTtNQUFFM0IsSUFBSSxFQUFFVTtJQUFPLENBQUMsR0FBRyxNQUFNWixNQUFNLENBQUM4QixNQUFNLENBQUM7TUFBRTdCLEtBQUs7TUFBRUM7SUFBSyxDQUFDLENBQUM7SUFDN0QsTUFBTTZCLEtBQUssR0FDVCxPQUFPbkIsTUFBTSxDQUFDb0IsSUFBSSxDQUFDRCxLQUFLLEtBQUssUUFBUSxHQUNqQ25CLE1BQU0sQ0FBQ29CLElBQUksQ0FBQ0QsS0FBSyxJQUFBSCxxQkFBQSxJQUFBQyxrQkFBQSxHQUNqQmpCLE1BQU0sQ0FBQ29CLElBQUksQ0FBQ0QsS0FBSyxjQUFBRixrQkFBQSx1QkFBakJBLGtCQUFBLENBQW1CM0MsS0FBSyxjQUFBMEMscUJBQUEsY0FBQUEscUJBQUEsR0FBSSxDQUFDO0lBQ25DLE9BQU87TUFDTEksSUFBSSxFQUFFcEIsTUFBTSxDQUFDb0IsSUFBSSxDQUFDQSxJQUFJO01BQ3RCRDtJQUNGLENBQUM7RUFDSDs7RUFFQTtBQUNGO0FBQ0E7QUFDQTtFQUNFLGFBQWFFLGtCQUFrQkEsQ0FDN0JqQyxNQUFXLEVBQ1hDLEtBQWEsRUFDYkMsSUFBUyxFQUNLO0lBQUEsSUFBQWdDLG9CQUFBO0lBQ2QsTUFBTTtNQUFFaEMsSUFBSSxFQUFFVTtJQUFPLENBQUMsR0FBRyxNQUFNWixNQUFNLENBQUM4QixNQUFNLENBQUM7TUFBRTdCLEtBQUs7TUFBRUMsSUFBSSxFQUFFO1FBQUVpQyxJQUFJLEVBQUUsQ0FBQztRQUFFLEdBQUdqQztNQUFLO0lBQUUsQ0FBQyxDQUFDO0lBQ25GLFFBQUFnQyxvQkFBQSxHQUFPdEIsTUFBTSxDQUFDd0IsWUFBWSxjQUFBRixvQkFBQSxjQUFBQSxvQkFBQSxHQUFJLENBQUMsQ0FBQztFQUNsQzs7RUFFQTtFQUNBO0VBQ0E7O0VBRUE7O0VBR0E7QUFDRjtBQUNBO0FBQ0E7QUFDQTtFQUNFLGFBQWFHLG1CQUFtQkEsQ0FBQ3JDLE1BQVcsRUFBbUI7SUFDN0QsTUFBTXNDLFdBQVcsR0FBRyxFQUFFO0lBRXRCLEtBQUssSUFBSUMsT0FBTyxHQUFHLENBQUMsRUFBRUEsT0FBTyxHQUFHRCxXQUFXLEVBQUVDLE9BQU8sRUFBRSxFQUFFO01BQ3RELElBQUlDLEtBQXlCO01BQzdCLElBQUlDLFdBQStCO01BQ25DLElBQUlDLFlBQVksR0FBRyxDQUFDOztNQUVwQjtNQUNBLElBQUk7UUFBQSxJQUFBQyxxQkFBQSxFQUFBQyxhQUFBO1FBQ0YsTUFBTTtVQUFFMUM7UUFBSyxDQUFDLEdBQUcsTUFBTUYsTUFBTSxDQUFDZSxHQUFHLENBQUM7VUFDaENkLEtBQUssRUFBRTRDLDZCQUFrQjtVQUN6QnBDLEVBQUUsRUFBRVgsaUJBQWlCLENBQUNnRDtRQUN4QixDQUFDLENBQUM7UUFDRk4sS0FBSyxHQUFHdEMsSUFBSSxDQUFDNkMsT0FBTztRQUNwQk4sV0FBVyxHQUFHdkMsSUFBSSxDQUFDOEMsYUFBYTtRQUNoQ04sWUFBWSxJQUFBQyxxQkFBQSxJQUFBQyxhQUFBLEdBQUcxQyxJQUFJLENBQUNjLE9BQU8sY0FBQTRCLGFBQUEsdUJBQVpBLGFBQUEsQ0FBY0ssYUFBYSxjQUFBTixxQkFBQSxjQUFBQSxxQkFBQSxHQUFJLENBQUM7TUFDakQsQ0FBQyxDQUFDLE9BQU9PLEdBQVEsRUFBRTtRQUFBLElBQUFDLFNBQUE7UUFDakI7UUFDQSxJQUFJLENBQUFELEdBQUcsYUFBSEEsR0FBRyx1QkFBSEEsR0FBRyxDQUFFaEMsVUFBVSxNQUFLLEdBQUcsSUFBSSxDQUFBZ0MsR0FBRyxhQUFIQSxHQUFHLGdCQUFBQyxTQUFBLEdBQUhELEdBQUcsQ0FBRS9CLElBQUksY0FBQWdDLFNBQUEsdUJBQVRBLFNBQUEsQ0FBV2pDLFVBQVUsTUFBSyxHQUFHLEVBQUU7VUFDNUQsTUFBTWdDLEdBQUc7UUFDWDtNQUNGO01BRUEsTUFBTUUsU0FBUyxHQUFHVixZQUFZLEdBQUcsQ0FBQztNQUVsQyxJQUFJO1FBQ0YsSUFBSUYsS0FBSyxLQUFLYSxTQUFTLEVBQUU7VUFDdkI7VUFDQSxNQUFNckQsTUFBTSxDQUFDQyxLQUFLLENBQUM7WUFDakJBLEtBQUssRUFBRTRDLDZCQUFrQjtZQUN6QnBDLEVBQUUsRUFBRVgsaUJBQWlCLENBQUNnRCxjQUFjO1lBQ3BDNUMsSUFBSSxFQUFFO2NBQUVvRCxZQUFZLEVBQUUsU0FBUztjQUFFTCxhQUFhLEVBQUVHO1lBQVUsQ0FBQztZQUMzREcsT0FBTyxFQUFFLFFBQVE7WUFDakI1QyxPQUFPLEVBQUU7VUFDWCxDQUFDLENBQUM7UUFDSixDQUFDLE1BQU07VUFDTDtVQUNBLE1BQU1YLE1BQU0sQ0FBQ0MsS0FBSyxDQUFDO1lBQ2pCQSxLQUFLLEVBQUU0Qyw2QkFBa0I7WUFDekJwQyxFQUFFLEVBQUVYLGlCQUFpQixDQUFDZ0QsY0FBYztZQUNwQzVDLElBQUksRUFBRTtjQUFFb0QsWUFBWSxFQUFFLFNBQVM7Y0FBRUwsYUFBYSxFQUFFRztZQUFVLENBQUM7WUFDM0RJLFNBQVMsRUFBRWhCLEtBQUs7WUFDaEJpQixlQUFlLEVBQUVoQixXQUFXO1lBQzVCOUIsT0FBTyxFQUFFO1VBQ1gsQ0FBQyxDQUFDO1FBQ0o7UUFDQSxPQUFPeUMsU0FBUztNQUNsQixDQUFDLENBQUMsT0FBT0YsR0FBUSxFQUFFO1FBQUEsSUFBQVEsZUFBQSxFQUFBQyxVQUFBO1FBQ2pCLE1BQU1DLE1BQU0sSUFBQUYsZUFBQSxHQUFHUixHQUFHLGFBQUhBLEdBQUcsdUJBQUhBLEdBQUcsQ0FBRWhDLFVBQVUsY0FBQXdDLGVBQUEsY0FBQUEsZUFBQSxHQUFJUixHQUFHLGFBQUhBLEdBQUcsZ0JBQUFTLFVBQUEsR0FBSFQsR0FBRyxDQUFFL0IsSUFBSSxjQUFBd0MsVUFBQSx1QkFBVEEsVUFBQSxDQUFXekMsVUFBVTtRQUN2RDtRQUNBLElBQUkwQyxNQUFNLEtBQUssR0FBRyxFQUFFO1VBQ2xCO1FBQ0Y7UUFDQSxNQUFNVixHQUFHO01BQ1g7SUFDRjs7SUFFQTtJQUNBLE9BQU9XLElBQUksQ0FBQ0MsR0FBRyxDQUFDLENBQUM7RUFDbkI7QUFDRjtBQUFDQyxPQUFBLENBQUFqRSxpQkFBQSxHQUFBQSxpQkFBQTtBQUFBbkIsZUFBQSxDQWxNWW1CLGlCQUFpQixvQkE4SGEsaUJBQWlCIn0=