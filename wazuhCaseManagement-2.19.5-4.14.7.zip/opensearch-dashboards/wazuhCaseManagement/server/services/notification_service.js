"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.NotificationService = void 0;
exports.buildChannelHeaders = buildChannelHeaders;
exports.isEmailAddress = isEmailAddress;
exports.maskHeaders = maskHeaders;
exports.normalizeRecipients = normalizeRecipients;
exports.parseRecipients = parseRecipients;
var _http = require("http");
var _https = require("https");
var _url = require("url");
var _smtp_service = require("./smtp_service");
var _constants = require("../../common/constants");
var _settings_service = require("./settings_service");
/*
 * Wazuh Case Management Plugin
 * Notification Service: in-app notifications and outbound webhook delivery
 *
 * A single dispatch() call fans an event out to:
 *   1. in-app notification records (one per recipient), shown in the nav bell
 *   2. every enabled outbound channel subscribed to that event
 */

const notificationMappings = {
  settings: {
    number_of_shards: 1,
    number_of_replicas: 1
  },
  mappings: {
    properties: {
      user: {
        type: 'keyword'
      },
      event: {
        type: 'keyword'
      },
      title: {
        type: 'text',
        fields: {
          keyword: {
            type: 'keyword'
          }
        }
      },
      message: {
        type: 'text'
      },
      case_id: {
        type: 'keyword'
      },
      case_doc_id: {
        type: 'keyword'
      },
      read: {
        type: 'boolean'
      },
      created_at: {
        type: 'date'
      },
      created_by: {
        type: 'keyword'
      }
    }
  }
};

/** Outbound HTTP POST with a hard timeout. Never throws. */
function postJson(url, body, headers, options = {}) {
  var _options$timeoutMs;
  const timeoutMs = (_options$timeoutMs = options.timeoutMs) !== null && _options$timeoutMs !== void 0 ? _options$timeoutMs : 8000;
  // Certificates are verified unless the channel explicitly opts out.
  const verifyTls = options.verifyTls !== false;
  return new Promise(resolve => {
    let parsed;
    try {
      parsed = new _url.URL(url);
    } catch (e) {
      resolve({
        ok: false,
        status: 0,
        error: `Invalid URL: ${url}`
      });
      return;
    }
    const payload = JSON.stringify(body);
    const isHttps = parsed.protocol === 'https:';
    const doRequest = isHttps ? _https.request : _http.request;
    const req = doRequest({
      protocol: parsed.protocol,
      hostname: parsed.hostname,
      port: parsed.port || (isHttps ? 443 : 80),
      path: `${parsed.pathname}${parsed.search}`,
      method: 'POST',
      timeout: timeoutMs,
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(payload),
        ...headers
      },
      rejectUnauthorized: verifyTls
    }, res => {
      res.resume(); // drain so the socket can be released
      const status = res.statusCode || 0;
      resolve({
        ok: status >= 200 && status < 300,
        status
      });
    });
    req.on('timeout', () => {
      req.destroy();
      resolve({
        ok: false,
        status: 0,
        error: 'timeout'
      });
    });
    req.on('error', err => resolve({
      ok: false,
      status: 0,
      error: err.message
    }));
    req.write(payload);
    req.end();
  });
}

/**
 * Build the outbound header set for a channel: its configured credentials plus
 * any static custom headers. Custom headers are applied last so an explicit
 * override always wins.
 */
function buildChannelHeaders(channel) {
  const headers = {};
  const auth = channel.auth;
  if (auth && auth.type && auth.type !== 'none') {
    switch (auth.type) {
      case 'bearer':
        if (auth.token) headers.Authorization = `Bearer ${auth.token}`;
        break;
      case 'basic':
        if (auth.username || auth.password) {
          const encoded = Buffer.from(`${auth.username || ''}:${auth.password || ''}`).toString('base64');
          headers.Authorization = `Basic ${encoded}`;
        }
        break;
      case 'api_key':
        if (auth.header_name && auth.header_value) {
          headers[auth.header_name] = auth.header_value;
        }
        break;
      default:
        break;
    }
  }
  for (const [key, value] of Object.entries(channel.headers || {})) {
    if (key) headers[key] = value;
  }
  return headers;
}

/** Redact credential-bearing header values so they can be shown or logged. */
function maskHeaders(headers) {
  const SENSITIVE = /^(authorization|x-api-key|apikey|token|x-auth-token|proxy-authorization)$/i;
  const masked = {};
  for (const [key, value] of Object.entries(headers)) {
    if (SENSITIVE.test(key)) {
      // Keep the scheme (Bearer/Basic) visible: it is the useful part when debugging.
      const scheme = value.split(' ')[0];
      masked[key] = /^(Bearer|Basic)$/i.test(scheme) ? `${scheme} ********` : '********';
    } else {
      masked[key] = value;
    }
  }
  return masked;
}

/** A pragmatic address check: enough to catch typos before SMTP sees them. */
function isEmailAddress(value) {
  return /^[^@\s,;]+@[^@\s,;]+\.[^@\s,;]+$/.test(String(value || '').trim());
}

/**
 * Split free-form input into addresses. Accepts commas, semicolons, whitespace
 * and newlines, so a pasted distribution list works as-is.
 *
 * Display-name form is unwrapped first, because a list copied out of a mail
 * client usually looks like `John Smith <john@example.com>, ops@example.com`
 * and splitting that on whitespace would shred it.
 */
function parseRecipients(input) {
  const raw = Array.isArray(input) ? input.join(',') : String(input || '');
  const unwrapped = raw.replace(/(?:"[^"]*"\s*|[^<>,;]*)?<\s*([^<>\s,;]+@[^<>\s,;]+)\s*>/g, (_match, address) => ` ${address} `);
  return unwrapped.split(/[,;\s]+/).map(value => value.trim()).filter(Boolean);
}

/** Validate and de-duplicate a recipient list, preserving the original order. */
function normalizeRecipients(input) {
  const seen = new Set();
  const valid = [];
  const invalid = [];
  for (const address of parseRecipients(input)) {
    if (!isEmailAddress(address)) {
      invalid.push(address);
      continue;
    }
    // Addresses are case-insensitive for routing purposes.
    const key = address.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    valid.push(address);
  }
  return {
    valid,
    invalid
  };
}

/** Escape text interpolated into the HTML mail body. */
function escapeHtml(value) {
  return String(value !== null && value !== void 0 ? value : '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}
class NotificationService {
  static async ensureIndex(client) {
    try {
      const {
        body: exists
      } = await client.indices.exists({
        index: _constants.NOTIFICATION_INDEX
      });
      if (!exists) {
        await client.indices.create({
          index: _constants.NOTIFICATION_INDEX,
          body: notificationMappings
        });
      }
    } catch (_e) {
      /* non-fatal: notifications degrade to webhook-only */
    }
  }

  // ── Dispatch ─────────────────────────────────────────────────

  /**
   * Fan an event out to in-app recipients and subscribed webhook channels.
   * Best-effort: a failure here must never break the originating action.
   */
  static async dispatch(client, params, logger) {
    let settings;
    try {
      settings = await _settings_service.SettingsService.getSettings(client);
    } catch (e) {
      logger === null || logger === void 0 || logger.warn(`Notifications: could not read settings: ${e.message}`);
      return;
    }
    await Promise.all([NotificationService.createInApp(client, settings, params, logger), NotificationService.sendToChannels(client, settings, params, logger)]);
  }
  static async createInApp(client, settings, params, logger) {
    const {
      notifications
    } = settings;
    if (!notifications.in_app_enabled) return;
    if (!notifications.in_app_events.includes(params.event)) return;

    // Don't notify people about their own actions.
    const recipients = Array.from(new Set(params.recipients.filter(r => !!r && r !== 'unknown' && r !== params.actor)));
    if (recipients.length === 0) return;
    try {
      await NotificationService.ensureIndex(client);
      const now = new Date().toISOString();
      const operations = [];
      for (const user of recipients) {
        var _params$caseRef, _params$caseRef2;
        const doc = {
          user,
          event: params.event,
          title: params.title,
          message: params.message,
          case_id: ((_params$caseRef = params.caseRef) === null || _params$caseRef === void 0 ? void 0 : _params$caseRef.case_id) || null,
          case_doc_id: ((_params$caseRef2 = params.caseRef) === null || _params$caseRef2 === void 0 ? void 0 : _params$caseRef2.id) || null,
          read: false,
          created_at: now,
          created_by: params.actor
        };
        operations.push({
          index: {
            _index: _constants.NOTIFICATION_INDEX
          }
        }, doc);
      }
      await client.bulk({
        body: operations,
        refresh: 'wait_for'
      });
    } catch (e) {
      logger === null || logger === void 0 || logger.warn(`Notifications: in-app write failed: ${e.message}`);
    }
  }
  static async sendToChannels(client, settings, params, logger) {
    const channels = settings.notifications.channels.filter(c => c.enabled && c.events.includes(params.event));
    if (channels.length === 0) return;
    await Promise.all(channels.map(async channel => {
      if (channel.type === 'email') {
        const result = await NotificationService.sendEmail(settings, channel, params);
        if (!result.ok) {
          logger === null || logger === void 0 || logger.warn(`Notifications: email channel "${channel.name}" failed: ${result.error}`);
        }
        return;
      }
      const body = NotificationService.buildChannelPayload(channel, params);
      const headers = buildChannelHeaders(channel);
      const result = await postJson(channel.url, body, headers, {
        verifyTls: channel.verify_tls
      });
      if (!result.ok) {
        logger === null || logger === void 0 || logger.warn(`Notifications: channel "${channel.name}" failed (${result.status}) ${result.error || ''}`);
      }
    }));
  }

  /** Deliver one event to an email channel over SMTP. */
  static async sendEmail(settings, channel, params) {
    var _settings$smtp;
    if (!((_settings$smtp = settings.smtp) !== null && _settings$smtp !== void 0 && _settings$smtp.enabled)) {
      return {
        ok: false,
        error: 'SMTP is not enabled in Settings'
      };
    }
    const {
      valid: recipients
    } = normalizeRecipients(channel.recipients || []);
    if (recipients.length === 0) {
      return {
        ok: false,
        error: `Email channel "${channel.name}" has no recipients`
      };
    }
    const message = NotificationService.buildMail(settings, recipients, params, channel.recipient_mode);
    return _smtp_service.SmtpService.send(settings.smtp, message);
  }

  /** Compose the plain-text and HTML bodies for one event. */
  static buildMail(settings, recipients, params, recipientMode = 'to') {
    const c = params.caseRef;
    const caseLink = NotificationService.caseUrl(settings, c === null || c === void 0 ? void 0 : c.id);
    const facts = [];
    if (c !== null && c !== void 0 && c.case_id) facts.push(['Case', c.case_id]);
    if (c !== null && c !== void 0 && c.title) facts.push(['Title', c.title]);
    if (c !== null && c !== void 0 && c.priority) facts.push(['Priority', String(c.priority)]);
    if (c !== null && c !== void 0 && c.severity) facts.push(['Severity', String(c.severity)]);
    if (c !== null && c !== void 0 && c.status) facts.push(['Status', String(c.status).replace('_', ' ')]);
    facts.push(['Triggered by', params.actor]);
    facts.push(['Time', new Date().toISOString().replace('T', ' ').replace(/\..*$/, ' UTC')]);
    const subject = c !== null && c !== void 0 && c.case_id ? `[${c.case_id}] ${params.title}` : params.title;
    const textLines = [params.title, '', params.message, '', ...facts.map(([k, v]) => `${k}: ${v}`)];
    if (caseLink) textLines.push('', `Open the case: ${caseLink}`);
    textLines.push('', 'Sent by the Wazuh Case Management plugin.');
    const accent = NotificationService.severityColor(c === null || c === void 0 ? void 0 : c.severity);
    const html = `<!doctype html>
<html><body style="margin:0;padding:0;background:#f5f7fa;font-family:-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;color:#343741;">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f5f7fa;padding:24px 12px;">
    <tr><td align="center">
      <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:600px;background:#ffffff;border:1px solid #d3dae6;border-radius:6px;overflow:hidden;">
        <tr><td style="height:4px;background:${accent};font-size:0;line-height:0;">&nbsp;</td></tr>
        <tr><td style="padding:20px 24px 8px;">
          <div style="font-size:17px;font-weight:600;color:#343741;">${escapeHtml(params.title)}</div>
          <div style="font-size:14px;color:#535966;margin-top:8px;line-height:1.5;">${escapeHtml(params.message)}</div>
        </td></tr>
        <tr><td style="padding:8px 24px 4px;">
          <table role="presentation" cellpadding="0" cellspacing="0" width="100%" style="font-size:13px;">
            ${facts.map(([k, v]) => `<tr><td style="padding:4px 0;color:#535966;width:120px;">${escapeHtml(k)}</td><td style="padding:4px 0;color:#343741;font-weight:500;">${escapeHtml(v)}</td></tr>`).join('')}
          </table>
        </td></tr>
        ${caseLink ? `<tr><td style="padding:16px 24px 24px;">
                 <a href="${escapeHtml(caseLink)}" style="display:inline-block;background:#006BB4;color:#ffffff;text-decoration:none;font-size:14px;font-weight:600;padding:10px 18px;border-radius:4px;">Open the case</a>
               </td></tr>` : '<tr><td style="padding:0 24px 24px;"></td></tr>'}
        <tr><td style="padding:12px 24px;background:#f5f7fa;border-top:1px solid #d3dae6;font-size:11px;color:#98a2b3;">
          Sent by the Wazuh Case Management plugin.
        </td></tr>
      </table>
    </td></tr>
  </table>
</body></html>`;
    return {
      to: recipients,
      subject,
      text: textLines.join('\n'),
      html,
      // Blind delivery keeps every address off the header; the envelope still
      // carries them all, so everyone receives the message.
      headerTo: recipientMode === 'bcc' ? 'undisclosed-recipients:;' : undefined
    };
  }

  /** Deep link to a case, when a public dashboard URL has been configured. */
  static caseUrl(settings, caseDocId) {
    const base = (settings.base_url || '').replace(/\/+$/, '');
    if (!base || !caseDocId) return '';
    return `${base}/app/wazuhCaseManagement#/cases/${caseDocId}`;
  }
  static buildChannelPayload(channel, params) {
    var _params$caseRef3;
    const text = `${params.title}\n${params.message}`;
    switch (channel.type) {
      case 'slack':
        return {
          text,
          attachments: params.caseRef ? [{
            color: NotificationService.severityColor(params.caseRef.severity),
            fields: [{
              title: 'Case',
              value: params.caseRef.case_id || '',
              short: true
            }, {
              title: 'Priority',
              value: params.caseRef.priority || '',
              short: true
            }, {
              title: 'Severity',
              value: params.caseRef.severity || '',
              short: true
            }, {
              title: 'Status',
              value: params.caseRef.status || '',
              short: true
            }]
          }] : undefined
        };
      case 'teams':
        return {
          '@type': 'MessageCard',
          '@context': 'https://schema.org/extensions',
          summary: params.title,
          themeColor: NotificationService.severityColor((_params$caseRef3 = params.caseRef) === null || _params$caseRef3 === void 0 ? void 0 : _params$caseRef3.severity).replace('#', ''),
          title: params.title,
          text: params.message,
          sections: params.caseRef ? [{
            facts: [{
              name: 'Case',
              value: params.caseRef.case_id || ''
            }, {
              name: 'Priority',
              value: params.caseRef.priority || ''
            }, {
              name: 'Severity',
              value: params.caseRef.severity || ''
            }, {
              name: 'Status',
              value: params.caseRef.status || ''
            }]
          }] : undefined
        };
      case 'webhook':
      default:
        return {
          event: params.event,
          title: params.title,
          message: params.message,
          actor: params.actor,
          timestamp: new Date().toISOString(),
          case: params.caseRef || null,
          ...(params.context || {})
        };
    }
  }
  static severityColor(severity) {
    switch (severity) {
      case 'critical':
        return '#E7664C';
      case 'high':
        return '#DA8B45';
      case 'medium':
        return '#D6BF57';
      case 'low':
        return '#54B399';
      default:
        return '#98A2B3';
    }
  }

  // ── Reading / marking ────────────────────────────────────────

  static async list(client, user, opts = {}) {
    await NotificationService.ensureIndex(client);
    const size = Math.min(opts.size || 50, 200);
    const must = [{
      term: {
        user
      }
    }];
    if (opts.unread_only) must.push({
      term: {
        read: false
      }
    });
    try {
      var _body$hits;
      const {
        body
      } = await client.search({
        index: _constants.NOTIFICATION_INDEX,
        body: {
          query: {
            bool: {
              must
            }
          },
          sort: [{
            created_at: {
              order: 'desc'
            }
          }],
          size
        }
      });
      const notifications = (((_body$hits = body.hits) === null || _body$hits === void 0 ? void 0 : _body$hits.hits) || []).map(h => ({
        id: h._id,
        ...h._source
      }));
      const {
        body: countBody
      } = await client.count({
        index: _constants.NOTIFICATION_INDEX,
        body: {
          query: {
            bool: {
              must: [{
                term: {
                  user
                }
              }, {
                term: {
                  read: false
                }
              }]
            }
          }
        }
      });
      return {
        notifications,
        unread: countBody.count || 0
      };
    } catch (_e) {
      return {
        notifications: [],
        unread: 0
      };
    }
  }

  /** Mark specific notifications read, or every notification for the user. */
  static async markRead(client, user, ids) {
    try {
      if (ids && ids.length > 0) {
        const operations = ids.flatMap(id => [{
          update: {
            _index: _constants.NOTIFICATION_INDEX,
            _id: id
          }
        }, {
          doc: {
            read: true
          }
        }]);
        await client.bulk({
          body: operations,
          refresh: 'wait_for'
        });
        return ids.length;
      }
      const {
        body
      } = await client.updateByQuery({
        index: _constants.NOTIFICATION_INDEX,
        refresh: true,
        body: {
          query: {
            bool: {
              must: [{
                term: {
                  user
                }
              }, {
                term: {
                  read: false
                }
              }]
            }
          },
          script: {
            source: 'ctx._source.read = true',
            lang: 'painless'
          }
        }
      });
      return body.updated || 0;
    } catch (_e) {
      return 0;
    }
  }

  /**
   * Send a sample payload to a channel so the user can confirm the URL and
   * credentials work before relying on it. Returns the masked headers so a
   * failure can be diagnosed without exposing the secret.
   */
  static async testChannel(channel, settings) {
    const headers = buildChannelHeaders(channel);
    const params = {
      event: 'case_created',
      recipients: [],
      title: 'Wazuh Case Management test notification',
      message: 'If you can read this, the channel URL and credentials are working.',
      caseRef: {
        case_id: 'CASE-0000-TEST',
        title: 'Test case',
        priority: 'P3',
        severity: 'medium',
        status: 'open'
      },
      actor: 'settings-test',
      context: {
        test: true
      }
    };
    if (channel.type === 'email') {
      var _settings$smtp2;
      if (!settings) {
        return {
          ok: false,
          status: 0,
          error: 'Settings unavailable',
          sent_headers: {}
        };
      }
      if (!((_settings$smtp2 = settings.smtp) !== null && _settings$smtp2 !== void 0 && _settings$smtp2.enabled)) {
        return {
          ok: false,
          status: 0,
          error: 'SMTP is not enabled. Turn it on and save before testing an email channel.',
          sent_headers: {}
        };
      }
      const {
        valid: recipients,
        invalid
      } = normalizeRecipients(channel.recipients || []);
      if (invalid.length > 0) {
        return {
          ok: false,
          status: 0,
          error: `Not a valid address: ${invalid.join(', ')}`,
          sent_headers: {}
        };
      }
      if (recipients.length === 0) {
        return {
          ok: false,
          status: 0,
          error: 'Add at least one recipient',
          sent_headers: {}
        };
      }
      const mail = NotificationService.buildMail(settings, recipients, params, channel.recipient_mode);
      const sent = await _smtp_service.SmtpService.send(settings.smtp, mail);
      return {
        ok: sent.ok,
        status: sent.ok ? 250 : 0,
        error: sent.error,
        sent_headers: {},
        transcript: sent.transcript
      };
    }
    const body = NotificationService.buildChannelPayload(channel, params);
    const result = await postJson(channel.url, body, headers, {
      verifyTls: channel.verify_tls
    });
    return {
      ok: result.ok,
      status: result.status,
      error: result.error,
      sent_headers: maskHeaders({
        'Content-Type': 'application/json',
        ...headers
      })
    };
  }

  /** Send a standalone test email to verify the SMTP server settings. */
  static async testSmtp(settings, recipient) {
    const mail = NotificationService.buildMail(settings, [recipient], {
      event: 'case_created',
      recipients: [],
      title: 'Wazuh Case Management test email',
      message: 'If this message reached you, the SMTP server, credentials and sender address are configured correctly.',
      caseRef: {
        case_id: 'CASE-0000-TEST',
        title: 'Test case',
        priority: 'P3',
        severity: 'medium',
        status: 'open'
      },
      actor: 'settings-test'
    });
    return _smtp_service.SmtpService.send(settings.smtp, mail);
  }
  static async remove(client, id) {
    try {
      await client.delete({
        index: _constants.NOTIFICATION_INDEX,
        id,
        refresh: 'wait_for'
      });
      return true;
    } catch (_e) {
      return false;
    }
  }
}
exports.NotificationService = NotificationService;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfaHR0cCIsInJlcXVpcmUiLCJfaHR0cHMiLCJfdXJsIiwiX3NtdHBfc2VydmljZSIsIl9jb25zdGFudHMiLCJfc2V0dGluZ3Nfc2VydmljZSIsIm5vdGlmaWNhdGlvbk1hcHBpbmdzIiwic2V0dGluZ3MiLCJudW1iZXJfb2Zfc2hhcmRzIiwibnVtYmVyX29mX3JlcGxpY2FzIiwibWFwcGluZ3MiLCJwcm9wZXJ0aWVzIiwidXNlciIsInR5cGUiLCJldmVudCIsInRpdGxlIiwiZmllbGRzIiwia2V5d29yZCIsIm1lc3NhZ2UiLCJjYXNlX2lkIiwiY2FzZV9kb2NfaWQiLCJyZWFkIiwiY3JlYXRlZF9hdCIsImNyZWF0ZWRfYnkiLCJwb3N0SnNvbiIsInVybCIsImJvZHkiLCJoZWFkZXJzIiwib3B0aW9ucyIsIl9vcHRpb25zJHRpbWVvdXRNcyIsInRpbWVvdXRNcyIsInZlcmlmeVRscyIsIlByb21pc2UiLCJyZXNvbHZlIiwicGFyc2VkIiwiVVJMIiwiZSIsIm9rIiwic3RhdHVzIiwiZXJyb3IiLCJwYXlsb2FkIiwiSlNPTiIsInN0cmluZ2lmeSIsImlzSHR0cHMiLCJwcm90b2NvbCIsImRvUmVxdWVzdCIsImh0dHBzUmVxdWVzdCIsImh0dHBSZXF1ZXN0IiwicmVxIiwiaG9zdG5hbWUiLCJwb3J0IiwicGF0aCIsInBhdGhuYW1lIiwic2VhcmNoIiwibWV0aG9kIiwidGltZW91dCIsIkJ1ZmZlciIsImJ5dGVMZW5ndGgiLCJyZWplY3RVbmF1dGhvcml6ZWQiLCJyZXMiLCJyZXN1bWUiLCJzdGF0dXNDb2RlIiwib24iLCJkZXN0cm95IiwiZXJyIiwid3JpdGUiLCJlbmQiLCJidWlsZENoYW5uZWxIZWFkZXJzIiwiY2hhbm5lbCIsImF1dGgiLCJ0b2tlbiIsIkF1dGhvcml6YXRpb24iLCJ1c2VybmFtZSIsInBhc3N3b3JkIiwiZW5jb2RlZCIsImZyb20iLCJ0b1N0cmluZyIsImhlYWRlcl9uYW1lIiwiaGVhZGVyX3ZhbHVlIiwia2V5IiwidmFsdWUiLCJPYmplY3QiLCJlbnRyaWVzIiwibWFza0hlYWRlcnMiLCJTRU5TSVRJVkUiLCJtYXNrZWQiLCJ0ZXN0Iiwic2NoZW1lIiwic3BsaXQiLCJpc0VtYWlsQWRkcmVzcyIsIlN0cmluZyIsInRyaW0iLCJwYXJzZVJlY2lwaWVudHMiLCJpbnB1dCIsInJhdyIsIkFycmF5IiwiaXNBcnJheSIsImpvaW4iLCJ1bndyYXBwZWQiLCJyZXBsYWNlIiwiX21hdGNoIiwiYWRkcmVzcyIsIm1hcCIsImZpbHRlciIsIkJvb2xlYW4iLCJub3JtYWxpemVSZWNpcGllbnRzIiwic2VlbiIsIlNldCIsInZhbGlkIiwiaW52YWxpZCIsInB1c2giLCJ0b0xvd2VyQ2FzZSIsImhhcyIsImFkZCIsImVzY2FwZUh0bWwiLCJOb3RpZmljYXRpb25TZXJ2aWNlIiwiZW5zdXJlSW5kZXgiLCJjbGllbnQiLCJleGlzdHMiLCJpbmRpY2VzIiwiaW5kZXgiLCJOT1RJRklDQVRJT05fSU5ERVgiLCJjcmVhdGUiLCJfZSIsImRpc3BhdGNoIiwicGFyYW1zIiwibG9nZ2VyIiwiU2V0dGluZ3NTZXJ2aWNlIiwiZ2V0U2V0dGluZ3MiLCJ3YXJuIiwiYWxsIiwiY3JlYXRlSW5BcHAiLCJzZW5kVG9DaGFubmVscyIsIm5vdGlmaWNhdGlvbnMiLCJpbl9hcHBfZW5hYmxlZCIsImluX2FwcF9ldmVudHMiLCJpbmNsdWRlcyIsInJlY2lwaWVudHMiLCJyIiwiYWN0b3IiLCJsZW5ndGgiLCJub3ciLCJEYXRlIiwidG9JU09TdHJpbmciLCJvcGVyYXRpb25zIiwiX3BhcmFtcyRjYXNlUmVmIiwiX3BhcmFtcyRjYXNlUmVmMiIsImRvYyIsImNhc2VSZWYiLCJpZCIsIl9pbmRleCIsImJ1bGsiLCJyZWZyZXNoIiwiY2hhbm5lbHMiLCJjIiwiZW5hYmxlZCIsImV2ZW50cyIsInJlc3VsdCIsInNlbmRFbWFpbCIsIm5hbWUiLCJidWlsZENoYW5uZWxQYXlsb2FkIiwidmVyaWZ5X3RscyIsIl9zZXR0aW5ncyRzbXRwIiwic210cCIsImJ1aWxkTWFpbCIsInJlY2lwaWVudF9tb2RlIiwiU210cFNlcnZpY2UiLCJzZW5kIiwicmVjaXBpZW50TW9kZSIsImNhc2VMaW5rIiwiY2FzZVVybCIsImZhY3RzIiwicHJpb3JpdHkiLCJzZXZlcml0eSIsInN1YmplY3QiLCJ0ZXh0TGluZXMiLCJrIiwidiIsImFjY2VudCIsInNldmVyaXR5Q29sb3IiLCJodG1sIiwidG8iLCJ0ZXh0IiwiaGVhZGVyVG8iLCJ1bmRlZmluZWQiLCJjYXNlRG9jSWQiLCJiYXNlIiwiYmFzZV91cmwiLCJfcGFyYW1zJGNhc2VSZWYzIiwiYXR0YWNobWVudHMiLCJjb2xvciIsInNob3J0Iiwic3VtbWFyeSIsInRoZW1lQ29sb3IiLCJzZWN0aW9ucyIsInRpbWVzdGFtcCIsImNhc2UiLCJjb250ZXh0IiwibGlzdCIsIm9wdHMiLCJzaXplIiwiTWF0aCIsIm1pbiIsIm11c3QiLCJ0ZXJtIiwidW5yZWFkX29ubHkiLCJfYm9keSRoaXRzIiwicXVlcnkiLCJib29sIiwic29ydCIsIm9yZGVyIiwiaGl0cyIsImgiLCJfaWQiLCJfc291cmNlIiwiY291bnRCb2R5IiwiY291bnQiLCJ1bnJlYWQiLCJtYXJrUmVhZCIsImlkcyIsImZsYXRNYXAiLCJ1cGRhdGUiLCJ1cGRhdGVCeVF1ZXJ5Iiwic2NyaXB0Iiwic291cmNlIiwibGFuZyIsInVwZGF0ZWQiLCJ0ZXN0Q2hhbm5lbCIsIl9zZXR0aW5ncyRzbXRwMiIsInNlbnRfaGVhZGVycyIsIm1haWwiLCJzZW50IiwidHJhbnNjcmlwdCIsInRlc3RTbXRwIiwicmVjaXBpZW50IiwicmVtb3ZlIiwiZGVsZXRlIiwiZXhwb3J0cyJdLCJzb3VyY2VzIjpbIm5vdGlmaWNhdGlvbl9zZXJ2aWNlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qXG4gKiBXYXp1aCBDYXNlIE1hbmFnZW1lbnQgUGx1Z2luXG4gKiBOb3RpZmljYXRpb24gU2VydmljZTogaW4tYXBwIG5vdGlmaWNhdGlvbnMgYW5kIG91dGJvdW5kIHdlYmhvb2sgZGVsaXZlcnlcbiAqXG4gKiBBIHNpbmdsZSBkaXNwYXRjaCgpIGNhbGwgZmFucyBhbiBldmVudCBvdXQgdG86XG4gKiAgIDEuIGluLWFwcCBub3RpZmljYXRpb24gcmVjb3JkcyAob25lIHBlciByZWNpcGllbnQpLCBzaG93biBpbiB0aGUgbmF2IGJlbGxcbiAqICAgMi4gZXZlcnkgZW5hYmxlZCBvdXRib3VuZCBjaGFubmVsIHN1YnNjcmliZWQgdG8gdGhhdCBldmVudFxuICovXG5cbmltcG9ydCB7IHJlcXVlc3QgYXMgaHR0cFJlcXVlc3QgfSBmcm9tICdodHRwJztcbmltcG9ydCB7IHJlcXVlc3QgYXMgaHR0cHNSZXF1ZXN0IH0gZnJvbSAnaHR0cHMnO1xuaW1wb3J0IHsgVVJMIH0gZnJvbSAndXJsJztcbmltcG9ydCB7IExvZ2dlciB9IGZyb20gJy4uLy4uLy4uLy4uL3NyYy9jb3JlL3NlcnZlcic7XG5pbXBvcnQge1xuICBDYXNlLFxuICBDYXNlTm90aWZpY2F0aW9uLFxuICBDaGFubmVsVGVzdFJlc3VsdCxcbiAgTm90aWZpY2F0aW9uQ2hhbm5lbCxcbiAgTm90aWZpY2F0aW9uRXZlbnQsXG4gIFBsdWdpblNldHRpbmdzLFxufSBmcm9tICcuLi8uLi9jb21tb24vdHlwZXMnO1xuaW1wb3J0IHsgU210cFNlcnZpY2UsIE1haWxNZXNzYWdlIH0gZnJvbSAnLi9zbXRwX3NlcnZpY2UnO1xuaW1wb3J0IHsgTk9USUZJQ0FUSU9OX0lOREVYIH0gZnJvbSAnLi4vLi4vY29tbW9uL2NvbnN0YW50cyc7XG5pbXBvcnQgeyBTZXR0aW5nc1NlcnZpY2UgfSBmcm9tICcuL3NldHRpbmdzX3NlcnZpY2UnO1xuXG5jb25zdCBub3RpZmljYXRpb25NYXBwaW5ncyA9IHtcbiAgc2V0dGluZ3M6IHsgbnVtYmVyX29mX3NoYXJkczogMSwgbnVtYmVyX29mX3JlcGxpY2FzOiAxIH0sXG4gIG1hcHBpbmdzOiB7XG4gICAgcHJvcGVydGllczoge1xuICAgICAgdXNlcjogeyB0eXBlOiAna2V5d29yZCcgfSxcbiAgICAgIGV2ZW50OiB7IHR5cGU6ICdrZXl3b3JkJyB9LFxuICAgICAgdGl0bGU6IHsgdHlwZTogJ3RleHQnLCBmaWVsZHM6IHsga2V5d29yZDogeyB0eXBlOiAna2V5d29yZCcgfSB9IH0sXG4gICAgICBtZXNzYWdlOiB7IHR5cGU6ICd0ZXh0JyB9LFxuICAgICAgY2FzZV9pZDogeyB0eXBlOiAna2V5d29yZCcgfSxcbiAgICAgIGNhc2VfZG9jX2lkOiB7IHR5cGU6ICdrZXl3b3JkJyB9LFxuICAgICAgcmVhZDogeyB0eXBlOiAnYm9vbGVhbicgfSxcbiAgICAgIGNyZWF0ZWRfYXQ6IHsgdHlwZTogJ2RhdGUnIH0sXG4gICAgICBjcmVhdGVkX2J5OiB7IHR5cGU6ICdrZXl3b3JkJyB9LFxuICAgIH0sXG4gIH0sXG59O1xuXG4vKiogT3V0Ym91bmQgSFRUUCBQT1NUIHdpdGggYSBoYXJkIHRpbWVvdXQuIE5ldmVyIHRocm93cy4gKi9cbmZ1bmN0aW9uIHBvc3RKc29uKFxuICB1cmw6IHN0cmluZyxcbiAgYm9keTogYW55LFxuICBoZWFkZXJzOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+LFxuICBvcHRpb25zOiB7IHZlcmlmeVRscz86IGJvb2xlYW47IHRpbWVvdXRNcz86IG51bWJlciB9ID0ge30sXG4pOiBQcm9taXNlPHsgb2s6IGJvb2xlYW47IHN0YXR1czogbnVtYmVyOyBlcnJvcj86IHN0cmluZyB9PiB7XG4gIGNvbnN0IHRpbWVvdXRNcyA9IG9wdGlvbnMudGltZW91dE1zID8/IDgwMDA7XG4gIC8vIENlcnRpZmljYXRlcyBhcmUgdmVyaWZpZWQgdW5sZXNzIHRoZSBjaGFubmVsIGV4cGxpY2l0bHkgb3B0cyBvdXQuXG4gIGNvbnN0IHZlcmlmeVRscyA9IG9wdGlvbnMudmVyaWZ5VGxzICE9PSBmYWxzZTtcbiAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG4gICAgbGV0IHBhcnNlZDogVVJMO1xuICAgIHRyeSB7XG4gICAgICBwYXJzZWQgPSBuZXcgVVJMKHVybCk7XG4gICAgfSBjYXRjaCAoZTogYW55KSB7XG4gICAgICByZXNvbHZlKHsgb2s6IGZhbHNlLCBzdGF0dXM6IDAsIGVycm9yOiBgSW52YWxpZCBVUkw6ICR7dXJsfWAgfSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgY29uc3QgcGF5bG9hZCA9IEpTT04uc3RyaW5naWZ5KGJvZHkpO1xuICAgIGNvbnN0IGlzSHR0cHMgPSBwYXJzZWQucHJvdG9jb2wgPT09ICdodHRwczonO1xuICAgIGNvbnN0IGRvUmVxdWVzdCA9IGlzSHR0cHMgPyBodHRwc1JlcXVlc3QgOiBodHRwUmVxdWVzdDtcblxuICAgIGNvbnN0IHJlcSA9IGRvUmVxdWVzdChcbiAgICAgIHtcbiAgICAgICAgcHJvdG9jb2w6IHBhcnNlZC5wcm90b2NvbCxcbiAgICAgICAgaG9zdG5hbWU6IHBhcnNlZC5ob3N0bmFtZSxcbiAgICAgICAgcG9ydDogcGFyc2VkLnBvcnQgfHwgKGlzSHR0cHMgPyA0NDMgOiA4MCksXG4gICAgICAgIHBhdGg6IGAke3BhcnNlZC5wYXRobmFtZX0ke3BhcnNlZC5zZWFyY2h9YCxcbiAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgIHRpbWVvdXQ6IHRpbWVvdXRNcyxcbiAgICAgICAgaGVhZGVyczoge1xuICAgICAgICAgICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICAgICAgJ0NvbnRlbnQtTGVuZ3RoJzogQnVmZmVyLmJ5dGVMZW5ndGgocGF5bG9hZCksXG4gICAgICAgICAgLi4uaGVhZGVycyxcbiAgICAgICAgfSxcbiAgICAgICAgcmVqZWN0VW5hdXRob3JpemVkOiB2ZXJpZnlUbHMsXG4gICAgICB9IGFzIGFueSxcbiAgICAgIChyZXMpID0+IHtcbiAgICAgICAgcmVzLnJlc3VtZSgpOyAvLyBkcmFpbiBzbyB0aGUgc29ja2V0IGNhbiBiZSByZWxlYXNlZFxuICAgICAgICBjb25zdCBzdGF0dXMgPSByZXMuc3RhdHVzQ29kZSB8fCAwO1xuICAgICAgICByZXNvbHZlKHsgb2s6IHN0YXR1cyA+PSAyMDAgJiYgc3RhdHVzIDwgMzAwLCBzdGF0dXMgfSk7XG4gICAgICB9LFxuICAgICk7XG5cbiAgICByZXEub24oJ3RpbWVvdXQnLCAoKSA9PiB7XG4gICAgICByZXEuZGVzdHJveSgpO1xuICAgICAgcmVzb2x2ZSh7IG9rOiBmYWxzZSwgc3RhdHVzOiAwLCBlcnJvcjogJ3RpbWVvdXQnIH0pO1xuICAgIH0pO1xuICAgIHJlcS5vbignZXJyb3InLCAoZXJyOiBhbnkpID0+IHJlc29sdmUoeyBvazogZmFsc2UsIHN0YXR1czogMCwgZXJyb3I6IGVyci5tZXNzYWdlIH0pKTtcbiAgICByZXEud3JpdGUocGF5bG9hZCk7XG4gICAgcmVxLmVuZCgpO1xuICB9KTtcbn1cblxuLyoqXG4gKiBCdWlsZCB0aGUgb3V0Ym91bmQgaGVhZGVyIHNldCBmb3IgYSBjaGFubmVsOiBpdHMgY29uZmlndXJlZCBjcmVkZW50aWFscyBwbHVzXG4gKiBhbnkgc3RhdGljIGN1c3RvbSBoZWFkZXJzLiBDdXN0b20gaGVhZGVycyBhcmUgYXBwbGllZCBsYXN0IHNvIGFuIGV4cGxpY2l0XG4gKiBvdmVycmlkZSBhbHdheXMgd2lucy5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGJ1aWxkQ2hhbm5lbEhlYWRlcnMoY2hhbm5lbDogTm90aWZpY2F0aW9uQ2hhbm5lbCk6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4ge1xuICBjb25zdCBoZWFkZXJzOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+ID0ge307XG4gIGNvbnN0IGF1dGggPSBjaGFubmVsLmF1dGg7XG5cbiAgaWYgKGF1dGggJiYgYXV0aC50eXBlICYmIGF1dGgudHlwZSAhPT0gJ25vbmUnKSB7XG4gICAgc3dpdGNoIChhdXRoLnR5cGUpIHtcbiAgICAgIGNhc2UgJ2JlYXJlcic6XG4gICAgICAgIGlmIChhdXRoLnRva2VuKSBoZWFkZXJzLkF1dGhvcml6YXRpb24gPSBgQmVhcmVyICR7YXV0aC50b2tlbn1gO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgJ2Jhc2ljJzpcbiAgICAgICAgaWYgKGF1dGgudXNlcm5hbWUgfHwgYXV0aC5wYXNzd29yZCkge1xuICAgICAgICAgIGNvbnN0IGVuY29kZWQgPSBCdWZmZXIuZnJvbShgJHthdXRoLnVzZXJuYW1lIHx8ICcnfToke2F1dGgucGFzc3dvcmQgfHwgJyd9YCkudG9TdHJpbmcoJ2Jhc2U2NCcpO1xuICAgICAgICAgIGhlYWRlcnMuQXV0aG9yaXphdGlvbiA9IGBCYXNpYyAke2VuY29kZWR9YDtcbiAgICAgICAgfVxuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgJ2FwaV9rZXknOlxuICAgICAgICBpZiAoYXV0aC5oZWFkZXJfbmFtZSAmJiBhdXRoLmhlYWRlcl92YWx1ZSkge1xuICAgICAgICAgIGhlYWRlcnNbYXV0aC5oZWFkZXJfbmFtZV0gPSBhdXRoLmhlYWRlcl92YWx1ZTtcbiAgICAgICAgfVxuICAgICAgICBicmVhaztcbiAgICAgIGRlZmF1bHQ6XG4gICAgICAgIGJyZWFrO1xuICAgIH1cbiAgfVxuXG4gIGZvciAoY29uc3QgW2tleSwgdmFsdWVdIG9mIE9iamVjdC5lbnRyaWVzKGNoYW5uZWwuaGVhZGVycyB8fCB7fSkpIHtcbiAgICBpZiAoa2V5KSBoZWFkZXJzW2tleV0gPSB2YWx1ZTtcbiAgfVxuXG4gIHJldHVybiBoZWFkZXJzO1xufVxuXG4vKiogUmVkYWN0IGNyZWRlbnRpYWwtYmVhcmluZyBoZWFkZXIgdmFsdWVzIHNvIHRoZXkgY2FuIGJlIHNob3duIG9yIGxvZ2dlZC4gKi9cbmV4cG9ydCBmdW5jdGlvbiBtYXNrSGVhZGVycyhoZWFkZXJzOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+KTogUmVjb3JkPHN0cmluZywgc3RyaW5nPiB7XG4gIGNvbnN0IFNFTlNJVElWRSA9IC9eKGF1dGhvcml6YXRpb258eC1hcGkta2V5fGFwaWtleXx0b2tlbnx4LWF1dGgtdG9rZW58cHJveHktYXV0aG9yaXphdGlvbikkL2k7XG4gIGNvbnN0IG1hc2tlZDogUmVjb3JkPHN0cmluZywgc3RyaW5nPiA9IHt9O1xuICBmb3IgKGNvbnN0IFtrZXksIHZhbHVlXSBvZiBPYmplY3QuZW50cmllcyhoZWFkZXJzKSkge1xuICAgIGlmIChTRU5TSVRJVkUudGVzdChrZXkpKSB7XG4gICAgICAvLyBLZWVwIHRoZSBzY2hlbWUgKEJlYXJlci9CYXNpYykgdmlzaWJsZTogaXQgaXMgdGhlIHVzZWZ1bCBwYXJ0IHdoZW4gZGVidWdnaW5nLlxuICAgICAgY29uc3Qgc2NoZW1lID0gdmFsdWUuc3BsaXQoJyAnKVswXTtcbiAgICAgIG1hc2tlZFtrZXldID0gL14oQmVhcmVyfEJhc2ljKSQvaS50ZXN0KHNjaGVtZSkgPyBgJHtzY2hlbWV9ICoqKioqKioqYCA6ICcqKioqKioqKic7XG4gICAgfSBlbHNlIHtcbiAgICAgIG1hc2tlZFtrZXldID0gdmFsdWU7XG4gICAgfVxuICB9XG4gIHJldHVybiBtYXNrZWQ7XG59XG5cbi8qKiBBIHByYWdtYXRpYyBhZGRyZXNzIGNoZWNrOiBlbm91Z2ggdG8gY2F0Y2ggdHlwb3MgYmVmb3JlIFNNVFAgc2VlcyB0aGVtLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGlzRW1haWxBZGRyZXNzKHZhbHVlOiBzdHJpbmcpOiBib29sZWFuIHtcbiAgcmV0dXJuIC9eW15AXFxzLDtdK0BbXkBcXHMsO10rXFwuW15AXFxzLDtdKyQvLnRlc3QoU3RyaW5nKHZhbHVlIHx8ICcnKS50cmltKCkpO1xufVxuXG4vKipcbiAqIFNwbGl0IGZyZWUtZm9ybSBpbnB1dCBpbnRvIGFkZHJlc3Nlcy4gQWNjZXB0cyBjb21tYXMsIHNlbWljb2xvbnMsIHdoaXRlc3BhY2VcbiAqIGFuZCBuZXdsaW5lcywgc28gYSBwYXN0ZWQgZGlzdHJpYnV0aW9uIGxpc3Qgd29ya3MgYXMtaXMuXG4gKlxuICogRGlzcGxheS1uYW1lIGZvcm0gaXMgdW53cmFwcGVkIGZpcnN0LCBiZWNhdXNlIGEgbGlzdCBjb3BpZWQgb3V0IG9mIGEgbWFpbFxuICogY2xpZW50IHVzdWFsbHkgbG9va3MgbGlrZSBgSm9obiBTbWl0aCA8am9obkBleGFtcGxlLmNvbT4sIG9wc0BleGFtcGxlLmNvbWBcbiAqIGFuZCBzcGxpdHRpbmcgdGhhdCBvbiB3aGl0ZXNwYWNlIHdvdWxkIHNocmVkIGl0LlxuICovXG5leHBvcnQgZnVuY3Rpb24gcGFyc2VSZWNpcGllbnRzKGlucHV0OiBzdHJpbmcgfCBzdHJpbmdbXSk6IHN0cmluZ1tdIHtcbiAgY29uc3QgcmF3ID0gQXJyYXkuaXNBcnJheShpbnB1dCkgPyBpbnB1dC5qb2luKCcsJykgOiBTdHJpbmcoaW5wdXQgfHwgJycpO1xuXG4gIGNvbnN0IHVud3JhcHBlZCA9IHJhdy5yZXBsYWNlKFxuICAgIC8oPzpcIlteXCJdKlwiXFxzKnxbXjw+LDtdKik/PFxccyooW148Plxccyw7XStAW148Plxccyw7XSspXFxzKj4vZyxcbiAgICAoX21hdGNoLCBhZGRyZXNzKSA9PiBgICR7YWRkcmVzc30gYCxcbiAgKTtcblxuICByZXR1cm4gdW53cmFwcGVkXG4gICAgLnNwbGl0KC9bLDtcXHNdKy8pXG4gICAgLm1hcCgodmFsdWUpID0+IHZhbHVlLnRyaW0oKSlcbiAgICAuZmlsdGVyKEJvb2xlYW4pO1xufVxuXG4vKiogVmFsaWRhdGUgYW5kIGRlLWR1cGxpY2F0ZSBhIHJlY2lwaWVudCBsaXN0LCBwcmVzZXJ2aW5nIHRoZSBvcmlnaW5hbCBvcmRlci4gKi9cbmV4cG9ydCBmdW5jdGlvbiBub3JtYWxpemVSZWNpcGllbnRzKGlucHV0OiBzdHJpbmcgfCBzdHJpbmdbXSk6IHtcbiAgdmFsaWQ6IHN0cmluZ1tdO1xuICBpbnZhbGlkOiBzdHJpbmdbXTtcbn0ge1xuICBjb25zdCBzZWVuID0gbmV3IFNldDxzdHJpbmc+KCk7XG4gIGNvbnN0IHZhbGlkOiBzdHJpbmdbXSA9IFtdO1xuICBjb25zdCBpbnZhbGlkOiBzdHJpbmdbXSA9IFtdO1xuXG4gIGZvciAoY29uc3QgYWRkcmVzcyBvZiBwYXJzZVJlY2lwaWVudHMoaW5wdXQpKSB7XG4gICAgaWYgKCFpc0VtYWlsQWRkcmVzcyhhZGRyZXNzKSkge1xuICAgICAgaW52YWxpZC5wdXNoKGFkZHJlc3MpO1xuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIC8vIEFkZHJlc3NlcyBhcmUgY2FzZS1pbnNlbnNpdGl2ZSBmb3Igcm91dGluZyBwdXJwb3Nlcy5cbiAgICBjb25zdCBrZXkgPSBhZGRyZXNzLnRvTG93ZXJDYXNlKCk7XG4gICAgaWYgKHNlZW4uaGFzKGtleSkpIGNvbnRpbnVlO1xuICAgIHNlZW4uYWRkKGtleSk7XG4gICAgdmFsaWQucHVzaChhZGRyZXNzKTtcbiAgfVxuXG4gIHJldHVybiB7IHZhbGlkLCBpbnZhbGlkIH07XG59XG5cbi8qKiBFc2NhcGUgdGV4dCBpbnRlcnBvbGF0ZWQgaW50byB0aGUgSFRNTCBtYWlsIGJvZHkuICovXG5mdW5jdGlvbiBlc2NhcGVIdG1sKHZhbHVlOiBzdHJpbmcpOiBzdHJpbmcge1xuICByZXR1cm4gU3RyaW5nKHZhbHVlID8/ICcnKVxuICAgIC5yZXBsYWNlKC8mL2csICcmYW1wOycpXG4gICAgLnJlcGxhY2UoLzwvZywgJyZsdDsnKVxuICAgIC5yZXBsYWNlKC8+L2csICcmZ3Q7JylcbiAgICAucmVwbGFjZSgvXCIvZywgJyZxdW90OycpXG4gICAgLnJlcGxhY2UoLycvZywgJyYjMzk7Jyk7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgRGlzcGF0Y2hQYXJhbXMge1xuICBldmVudDogTm90aWZpY2F0aW9uRXZlbnQ7XG4gIC8qKiBVc2VybmFtZXMgdG8gbm90aWZ5IGluLWFwcC4gRHVwbGljYXRlcyBhbmQgZW1wdGllcyBhcmUgaWdub3JlZC4gKi9cbiAgcmVjaXBpZW50czogQXJyYXk8c3RyaW5nIHwgbnVsbCB8IHVuZGVmaW5lZD47XG4gIHRpdGxlOiBzdHJpbmc7XG4gIG1lc3NhZ2U6IHN0cmluZztcbiAgLyoqIFRoZSBjYXNlIHRoZSBldmVudCByZWxhdGVzIHRvLiBBIGZ1bGwgQ2FzZSBpcyBmaW5lLiBPbmx5IGEgZmV3IGZpZWxkcyBhcmUgcmVhZC4gKi9cbiAgY2FzZVJlZj86IFBhcnRpYWw8Q2FzZT4gfCBudWxsO1xuICBhY3Rvcjogc3RyaW5nO1xuICAvKiogRXh0cmEgZmllbGRzIGluY2x1ZGVkIGluIHRoZSBvdXRib3VuZCB3ZWJob29rIHBheWxvYWQgKi9cbiAgY29udGV4dD86IFJlY29yZDxzdHJpbmcsIGFueT47XG59XG5cbmV4cG9ydCBjbGFzcyBOb3RpZmljYXRpb25TZXJ2aWNlIHtcbiAgc3RhdGljIGFzeW5jIGVuc3VyZUluZGV4KGNsaWVudDogYW55KTogUHJvbWlzZTx2b2lkPiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHsgYm9keTogZXhpc3RzIH0gPSBhd2FpdCBjbGllbnQuaW5kaWNlcy5leGlzdHMoeyBpbmRleDogTk9USUZJQ0FUSU9OX0lOREVYIH0pO1xuICAgICAgaWYgKCFleGlzdHMpIHtcbiAgICAgICAgYXdhaXQgY2xpZW50LmluZGljZXMuY3JlYXRlKHsgaW5kZXg6IE5PVElGSUNBVElPTl9JTkRFWCwgYm9keTogbm90aWZpY2F0aW9uTWFwcGluZ3MgfSk7XG4gICAgICB9XG4gICAgfSBjYXRjaCAoX2UpIHtcbiAgICAgIC8qIG5vbi1mYXRhbDogbm90aWZpY2F0aW9ucyBkZWdyYWRlIHRvIHdlYmhvb2stb25seSAqL1xuICAgIH1cbiAgfVxuXG4gIC8vIOKUgOKUgCBEaXNwYXRjaCDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuICAvKipcbiAgICogRmFuIGFuIGV2ZW50IG91dCB0byBpbi1hcHAgcmVjaXBpZW50cyBhbmQgc3Vic2NyaWJlZCB3ZWJob29rIGNoYW5uZWxzLlxuICAgKiBCZXN0LWVmZm9ydDogYSBmYWlsdXJlIGhlcmUgbXVzdCBuZXZlciBicmVhayB0aGUgb3JpZ2luYXRpbmcgYWN0aW9uLlxuICAgKi9cbiAgc3RhdGljIGFzeW5jIGRpc3BhdGNoKGNsaWVudDogYW55LCBwYXJhbXM6IERpc3BhdGNoUGFyYW1zLCBsb2dnZXI/OiBMb2dnZXIpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBsZXQgc2V0dGluZ3M6IFBsdWdpblNldHRpbmdzO1xuICAgIHRyeSB7XG4gICAgICBzZXR0aW5ncyA9IGF3YWl0IFNldHRpbmdzU2VydmljZS5nZXRTZXR0aW5ncyhjbGllbnQpO1xuICAgIH0gY2F0Y2ggKGU6IGFueSkge1xuICAgICAgbG9nZ2VyPy53YXJuKGBOb3RpZmljYXRpb25zOiBjb3VsZCBub3QgcmVhZCBzZXR0aW5nczogJHtlLm1lc3NhZ2V9YCk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgYXdhaXQgUHJvbWlzZS5hbGwoW1xuICAgICAgTm90aWZpY2F0aW9uU2VydmljZS5jcmVhdGVJbkFwcChjbGllbnQsIHNldHRpbmdzLCBwYXJhbXMsIGxvZ2dlciksXG4gICAgICBOb3RpZmljYXRpb25TZXJ2aWNlLnNlbmRUb0NoYW5uZWxzKGNsaWVudCwgc2V0dGluZ3MsIHBhcmFtcywgbG9nZ2VyKSxcbiAgICBdKTtcbiAgfVxuXG4gIHByaXZhdGUgc3RhdGljIGFzeW5jIGNyZWF0ZUluQXBwKFxuICAgIGNsaWVudDogYW55LFxuICAgIHNldHRpbmdzOiBQbHVnaW5TZXR0aW5ncyxcbiAgICBwYXJhbXM6IERpc3BhdGNoUGFyYW1zLFxuICAgIGxvZ2dlcj86IExvZ2dlcixcbiAgKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgY29uc3QgeyBub3RpZmljYXRpb25zIH0gPSBzZXR0aW5ncztcbiAgICBpZiAoIW5vdGlmaWNhdGlvbnMuaW5fYXBwX2VuYWJsZWQpIHJldHVybjtcbiAgICBpZiAoIW5vdGlmaWNhdGlvbnMuaW5fYXBwX2V2ZW50cy5pbmNsdWRlcyhwYXJhbXMuZXZlbnQpKSByZXR1cm47XG5cbiAgICAvLyBEb24ndCBub3RpZnkgcGVvcGxlIGFib3V0IHRoZWlyIG93biBhY3Rpb25zLlxuICAgIGNvbnN0IHJlY2lwaWVudHMgPSBBcnJheS5mcm9tKFxuICAgICAgbmV3IFNldChcbiAgICAgICAgcGFyYW1zLnJlY2lwaWVudHMuZmlsdGVyKFxuICAgICAgICAgIChyKTogciBpcyBzdHJpbmcgPT4gISFyICYmIHIgIT09ICd1bmtub3duJyAmJiByICE9PSBwYXJhbXMuYWN0b3IsXG4gICAgICAgICksXG4gICAgICApLFxuICAgICk7XG4gICAgaWYgKHJlY2lwaWVudHMubGVuZ3RoID09PSAwKSByZXR1cm47XG5cbiAgICB0cnkge1xuICAgICAgYXdhaXQgTm90aWZpY2F0aW9uU2VydmljZS5lbnN1cmVJbmRleChjbGllbnQpO1xuICAgICAgY29uc3Qgbm93ID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpO1xuICAgICAgY29uc3Qgb3BlcmF0aW9uczogYW55W10gPSBbXTtcbiAgICAgIGZvciAoY29uc3QgdXNlciBvZiByZWNpcGllbnRzKSB7XG4gICAgICAgIGNvbnN0IGRvYzogQ2FzZU5vdGlmaWNhdGlvbiA9IHtcbiAgICAgICAgICB1c2VyLFxuICAgICAgICAgIGV2ZW50OiBwYXJhbXMuZXZlbnQsXG4gICAgICAgICAgdGl0bGU6IHBhcmFtcy50aXRsZSxcbiAgICAgICAgICBtZXNzYWdlOiBwYXJhbXMubWVzc2FnZSxcbiAgICAgICAgICBjYXNlX2lkOiBwYXJhbXMuY2FzZVJlZj8uY2FzZV9pZCB8fCBudWxsLFxuICAgICAgICAgIGNhc2VfZG9jX2lkOiBwYXJhbXMuY2FzZVJlZj8uaWQgfHwgbnVsbCxcbiAgICAgICAgICByZWFkOiBmYWxzZSxcbiAgICAgICAgICBjcmVhdGVkX2F0OiBub3csXG4gICAgICAgICAgY3JlYXRlZF9ieTogcGFyYW1zLmFjdG9yLFxuICAgICAgICB9O1xuICAgICAgICBvcGVyYXRpb25zLnB1c2goeyBpbmRleDogeyBfaW5kZXg6IE5PVElGSUNBVElPTl9JTkRFWCB9IH0sIGRvYyk7XG4gICAgICB9XG4gICAgICBhd2FpdCBjbGllbnQuYnVsayh7IGJvZHk6IG9wZXJhdGlvbnMsIHJlZnJlc2g6ICd3YWl0X2ZvcicgfSk7XG4gICAgfSBjYXRjaCAoZTogYW55KSB7XG4gICAgICBsb2dnZXI/Lndhcm4oYE5vdGlmaWNhdGlvbnM6IGluLWFwcCB3cml0ZSBmYWlsZWQ6ICR7ZS5tZXNzYWdlfWApO1xuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgc3RhdGljIGFzeW5jIHNlbmRUb0NoYW5uZWxzKFxuICAgIGNsaWVudDogYW55LFxuICAgIHNldHRpbmdzOiBQbHVnaW5TZXR0aW5ncyxcbiAgICBwYXJhbXM6IERpc3BhdGNoUGFyYW1zLFxuICAgIGxvZ2dlcj86IExvZ2dlcixcbiAgKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgY29uc3QgY2hhbm5lbHMgPSBzZXR0aW5ncy5ub3RpZmljYXRpb25zLmNoYW5uZWxzLmZpbHRlcihcbiAgICAgIChjKSA9PiBjLmVuYWJsZWQgJiYgYy5ldmVudHMuaW5jbHVkZXMocGFyYW1zLmV2ZW50KSxcbiAgICApO1xuICAgIGlmIChjaGFubmVscy5sZW5ndGggPT09IDApIHJldHVybjtcblxuICAgIGF3YWl0IFByb21pc2UuYWxsKFxuICAgICAgY2hhbm5lbHMubWFwKGFzeW5jIChjaGFubmVsKSA9PiB7XG4gICAgICAgIGlmIChjaGFubmVsLnR5cGUgPT09ICdlbWFpbCcpIHtcbiAgICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBOb3RpZmljYXRpb25TZXJ2aWNlLnNlbmRFbWFpbChzZXR0aW5ncywgY2hhbm5lbCwgcGFyYW1zKTtcbiAgICAgICAgICBpZiAoIXJlc3VsdC5vaykge1xuICAgICAgICAgICAgbG9nZ2VyPy53YXJuKGBOb3RpZmljYXRpb25zOiBlbWFpbCBjaGFubmVsIFwiJHtjaGFubmVsLm5hbWV9XCIgZmFpbGVkOiAke3Jlc3VsdC5lcnJvcn1gKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgYm9keSA9IE5vdGlmaWNhdGlvblNlcnZpY2UuYnVpbGRDaGFubmVsUGF5bG9hZChjaGFubmVsLCBwYXJhbXMpO1xuICAgICAgICBjb25zdCBoZWFkZXJzID0gYnVpbGRDaGFubmVsSGVhZGVycyhjaGFubmVsKTtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgcG9zdEpzb24oY2hhbm5lbC51cmwsIGJvZHksIGhlYWRlcnMsIHtcbiAgICAgICAgICB2ZXJpZnlUbHM6IGNoYW5uZWwudmVyaWZ5X3RscyxcbiAgICAgICAgfSk7XG4gICAgICAgIGlmICghcmVzdWx0Lm9rKSB7XG4gICAgICAgICAgbG9nZ2VyPy53YXJuKFxuICAgICAgICAgICAgYE5vdGlmaWNhdGlvbnM6IGNoYW5uZWwgXCIke2NoYW5uZWwubmFtZX1cIiBmYWlsZWQgKCR7cmVzdWx0LnN0YXR1c30pICR7cmVzdWx0LmVycm9yIHx8ICcnfWAsXG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgICAgfSksXG4gICAgKTtcbiAgfVxuXG4gIC8qKiBEZWxpdmVyIG9uZSBldmVudCB0byBhbiBlbWFpbCBjaGFubmVsIG92ZXIgU01UUC4gKi9cbiAgcHJpdmF0ZSBzdGF0aWMgYXN5bmMgc2VuZEVtYWlsKFxuICAgIHNldHRpbmdzOiBQbHVnaW5TZXR0aW5ncyxcbiAgICBjaGFubmVsOiBOb3RpZmljYXRpb25DaGFubmVsLFxuICAgIHBhcmFtczogRGlzcGF0Y2hQYXJhbXMsXG4gICkge1xuICAgIGlmICghc2V0dGluZ3Muc210cD8uZW5hYmxlZCkge1xuICAgICAgcmV0dXJuIHsgb2s6IGZhbHNlLCBlcnJvcjogJ1NNVFAgaXMgbm90IGVuYWJsZWQgaW4gU2V0dGluZ3MnIH07XG4gICAgfVxuICAgIGNvbnN0IHsgdmFsaWQ6IHJlY2lwaWVudHMgfSA9IG5vcm1hbGl6ZVJlY2lwaWVudHMoY2hhbm5lbC5yZWNpcGllbnRzIHx8IFtdKTtcbiAgICBpZiAocmVjaXBpZW50cy5sZW5ndGggPT09IDApIHtcbiAgICAgIHJldHVybiB7IG9rOiBmYWxzZSwgZXJyb3I6IGBFbWFpbCBjaGFubmVsIFwiJHtjaGFubmVsLm5hbWV9XCIgaGFzIG5vIHJlY2lwaWVudHNgIH07XG4gICAgfVxuXG4gICAgY29uc3QgbWVzc2FnZSA9IE5vdGlmaWNhdGlvblNlcnZpY2UuYnVpbGRNYWlsKHNldHRpbmdzLCByZWNpcGllbnRzLCBwYXJhbXMsIGNoYW5uZWwucmVjaXBpZW50X21vZGUpO1xuICAgIHJldHVybiBTbXRwU2VydmljZS5zZW5kKHNldHRpbmdzLnNtdHAsIG1lc3NhZ2UpO1xuICB9XG5cbiAgLyoqIENvbXBvc2UgdGhlIHBsYWluLXRleHQgYW5kIEhUTUwgYm9kaWVzIGZvciBvbmUgZXZlbnQuICovXG4gIHN0YXRpYyBidWlsZE1haWwoXG4gICAgc2V0dGluZ3M6IFBsdWdpblNldHRpbmdzLFxuICAgIHJlY2lwaWVudHM6IHN0cmluZ1tdLFxuICAgIHBhcmFtczogRGlzcGF0Y2hQYXJhbXMsXG4gICAgcmVjaXBpZW50TW9kZTogJ3RvJyB8ICdiY2MnID0gJ3RvJyxcbiAgKTogTWFpbE1lc3NhZ2Uge1xuICAgIGNvbnN0IGMgPSBwYXJhbXMuY2FzZVJlZjtcbiAgICBjb25zdCBjYXNlTGluayA9IE5vdGlmaWNhdGlvblNlcnZpY2UuY2FzZVVybChzZXR0aW5ncywgYz8uaWQpO1xuXG4gICAgY29uc3QgZmFjdHM6IEFycmF5PFtzdHJpbmcsIHN0cmluZ10+ID0gW107XG4gICAgaWYgKGM/LmNhc2VfaWQpIGZhY3RzLnB1c2goWydDYXNlJywgYy5jYXNlX2lkXSk7XG4gICAgaWYgKGM/LnRpdGxlKSBmYWN0cy5wdXNoKFsnVGl0bGUnLCBjLnRpdGxlXSk7XG4gICAgaWYgKGM/LnByaW9yaXR5KSBmYWN0cy5wdXNoKFsnUHJpb3JpdHknLCBTdHJpbmcoYy5wcmlvcml0eSldKTtcbiAgICBpZiAoYz8uc2V2ZXJpdHkpIGZhY3RzLnB1c2goWydTZXZlcml0eScsIFN0cmluZyhjLnNldmVyaXR5KV0pO1xuICAgIGlmIChjPy5zdGF0dXMpIGZhY3RzLnB1c2goWydTdGF0dXMnLCBTdHJpbmcoYy5zdGF0dXMpLnJlcGxhY2UoJ18nLCAnICcpXSk7XG4gICAgZmFjdHMucHVzaChbJ1RyaWdnZXJlZCBieScsIHBhcmFtcy5hY3Rvcl0pO1xuICAgIGZhY3RzLnB1c2goWydUaW1lJywgbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnJlcGxhY2UoJ1QnLCAnICcpLnJlcGxhY2UoL1xcLi4qJC8sICcgVVRDJyldKTtcblxuICAgIGNvbnN0IHN1YmplY3QgPSBjPy5jYXNlX2lkID8gYFske2MuY2FzZV9pZH1dICR7cGFyYW1zLnRpdGxlfWAgOiBwYXJhbXMudGl0bGU7XG5cbiAgICBjb25zdCB0ZXh0TGluZXMgPSBbXG4gICAgICBwYXJhbXMudGl0bGUsXG4gICAgICAnJyxcbiAgICAgIHBhcmFtcy5tZXNzYWdlLFxuICAgICAgJycsXG4gICAgICAuLi5mYWN0cy5tYXAoKFtrLCB2XSkgPT4gYCR7a306ICR7dn1gKSxcbiAgICBdO1xuICAgIGlmIChjYXNlTGluaykgdGV4dExpbmVzLnB1c2goJycsIGBPcGVuIHRoZSBjYXNlOiAke2Nhc2VMaW5rfWApO1xuICAgIHRleHRMaW5lcy5wdXNoKCcnLCAnU2VudCBieSB0aGUgV2F6dWggQ2FzZSBNYW5hZ2VtZW50IHBsdWdpbi4nKTtcblxuICAgIGNvbnN0IGFjY2VudCA9IE5vdGlmaWNhdGlvblNlcnZpY2Uuc2V2ZXJpdHlDb2xvcihjPy5zZXZlcml0eSk7XG4gICAgY29uc3QgaHRtbCA9IGA8IWRvY3R5cGUgaHRtbD5cbjxodG1sPjxib2R5IHN0eWxlPVwibWFyZ2luOjA7cGFkZGluZzowO2JhY2tncm91bmQ6I2Y1ZjdmYTtmb250LWZhbWlseTotYXBwbGUtc3lzdGVtLFNlZ29lIFVJLFJvYm90byxIZWx2ZXRpY2EsQXJpYWwsc2Fucy1zZXJpZjtjb2xvcjojMzQzNzQxO1wiPlxuICA8dGFibGUgcm9sZT1cInByZXNlbnRhdGlvblwiIHdpZHRoPVwiMTAwJVwiIGNlbGxwYWRkaW5nPVwiMFwiIGNlbGxzcGFjaW5nPVwiMFwiIHN0eWxlPVwiYmFja2dyb3VuZDojZjVmN2ZhO3BhZGRpbmc6MjRweCAxMnB4O1wiPlxuICAgIDx0cj48dGQgYWxpZ249XCJjZW50ZXJcIj5cbiAgICAgIDx0YWJsZSByb2xlPVwicHJlc2VudGF0aW9uXCIgd2lkdGg9XCIxMDAlXCIgY2VsbHBhZGRpbmc9XCIwXCIgY2VsbHNwYWNpbmc9XCIwXCIgc3R5bGU9XCJtYXgtd2lkdGg6NjAwcHg7YmFja2dyb3VuZDojZmZmZmZmO2JvcmRlcjoxcHggc29saWQgI2QzZGFlNjtib3JkZXItcmFkaXVzOjZweDtvdmVyZmxvdzpoaWRkZW47XCI+XG4gICAgICAgIDx0cj48dGQgc3R5bGU9XCJoZWlnaHQ6NHB4O2JhY2tncm91bmQ6JHthY2NlbnR9O2ZvbnQtc2l6ZTowO2xpbmUtaGVpZ2h0OjA7XCI+Jm5ic3A7PC90ZD48L3RyPlxuICAgICAgICA8dHI+PHRkIHN0eWxlPVwicGFkZGluZzoyMHB4IDI0cHggOHB4O1wiPlxuICAgICAgICAgIDxkaXYgc3R5bGU9XCJmb250LXNpemU6MTdweDtmb250LXdlaWdodDo2MDA7Y29sb3I6IzM0Mzc0MTtcIj4ke2VzY2FwZUh0bWwocGFyYW1zLnRpdGxlKX08L2Rpdj5cbiAgICAgICAgICA8ZGl2IHN0eWxlPVwiZm9udC1zaXplOjE0cHg7Y29sb3I6IzUzNTk2NjttYXJnaW4tdG9wOjhweDtsaW5lLWhlaWdodDoxLjU7XCI+JHtlc2NhcGVIdG1sKHBhcmFtcy5tZXNzYWdlKX08L2Rpdj5cbiAgICAgICAgPC90ZD48L3RyPlxuICAgICAgICA8dHI+PHRkIHN0eWxlPVwicGFkZGluZzo4cHggMjRweCA0cHg7XCI+XG4gICAgICAgICAgPHRhYmxlIHJvbGU9XCJwcmVzZW50YXRpb25cIiBjZWxscGFkZGluZz1cIjBcIiBjZWxsc3BhY2luZz1cIjBcIiB3aWR0aD1cIjEwMCVcIiBzdHlsZT1cImZvbnQtc2l6ZToxM3B4O1wiPlxuICAgICAgICAgICAgJHtmYWN0c1xuICAgICAgICAgICAgICAubWFwKFxuICAgICAgICAgICAgICAgIChbaywgdl0pID0+XG4gICAgICAgICAgICAgICAgICBgPHRyPjx0ZCBzdHlsZT1cInBhZGRpbmc6NHB4IDA7Y29sb3I6IzUzNTk2Njt3aWR0aDoxMjBweDtcIj4ke2VzY2FwZUh0bWwoayl9PC90ZD48dGQgc3R5bGU9XCJwYWRkaW5nOjRweCAwO2NvbG9yOiMzNDM3NDE7Zm9udC13ZWlnaHQ6NTAwO1wiPiR7ZXNjYXBlSHRtbCh2KX08L3RkPjwvdHI+YCxcbiAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAuam9pbignJyl9XG4gICAgICAgICAgPC90YWJsZT5cbiAgICAgICAgPC90ZD48L3RyPlxuICAgICAgICAke1xuICAgICAgICAgIGNhc2VMaW5rXG4gICAgICAgICAgICA/IGA8dHI+PHRkIHN0eWxlPVwicGFkZGluZzoxNnB4IDI0cHggMjRweDtcIj5cbiAgICAgICAgICAgICAgICAgPGEgaHJlZj1cIiR7ZXNjYXBlSHRtbChjYXNlTGluayl9XCIgc3R5bGU9XCJkaXNwbGF5OmlubGluZS1ibG9jaztiYWNrZ3JvdW5kOiMwMDZCQjQ7Y29sb3I6I2ZmZmZmZjt0ZXh0LWRlY29yYXRpb246bm9uZTtmb250LXNpemU6MTRweDtmb250LXdlaWdodDo2MDA7cGFkZGluZzoxMHB4IDE4cHg7Ym9yZGVyLXJhZGl1czo0cHg7XCI+T3BlbiB0aGUgY2FzZTwvYT5cbiAgICAgICAgICAgICAgIDwvdGQ+PC90cj5gXG4gICAgICAgICAgICA6ICc8dHI+PHRkIHN0eWxlPVwicGFkZGluZzowIDI0cHggMjRweDtcIj48L3RkPjwvdHI+J1xuICAgICAgICB9XG4gICAgICAgIDx0cj48dGQgc3R5bGU9XCJwYWRkaW5nOjEycHggMjRweDtiYWNrZ3JvdW5kOiNmNWY3ZmE7Ym9yZGVyLXRvcDoxcHggc29saWQgI2QzZGFlNjtmb250LXNpemU6MTFweDtjb2xvcjojOThhMmIzO1wiPlxuICAgICAgICAgIFNlbnQgYnkgdGhlIFdhenVoIENhc2UgTWFuYWdlbWVudCBwbHVnaW4uXG4gICAgICAgIDwvdGQ+PC90cj5cbiAgICAgIDwvdGFibGU+XG4gICAgPC90ZD48L3RyPlxuICA8L3RhYmxlPlxuPC9ib2R5PjwvaHRtbD5gO1xuXG4gICAgcmV0dXJuIHtcbiAgICAgIHRvOiByZWNpcGllbnRzLFxuICAgICAgc3ViamVjdCxcbiAgICAgIHRleHQ6IHRleHRMaW5lcy5qb2luKCdcXG4nKSxcbiAgICAgIGh0bWwsXG4gICAgICAvLyBCbGluZCBkZWxpdmVyeSBrZWVwcyBldmVyeSBhZGRyZXNzIG9mZiB0aGUgaGVhZGVyOyB0aGUgZW52ZWxvcGUgc3RpbGxcbiAgICAgIC8vIGNhcnJpZXMgdGhlbSBhbGwsIHNvIGV2ZXJ5b25lIHJlY2VpdmVzIHRoZSBtZXNzYWdlLlxuICAgICAgaGVhZGVyVG86IHJlY2lwaWVudE1vZGUgPT09ICdiY2MnID8gJ3VuZGlzY2xvc2VkLXJlY2lwaWVudHM6OycgOiB1bmRlZmluZWQsXG4gICAgfTtcbiAgfVxuXG4gIC8qKiBEZWVwIGxpbmsgdG8gYSBjYXNlLCB3aGVuIGEgcHVibGljIGRhc2hib2FyZCBVUkwgaGFzIGJlZW4gY29uZmlndXJlZC4gKi9cbiAgcHJpdmF0ZSBzdGF0aWMgY2FzZVVybChzZXR0aW5nczogUGx1Z2luU2V0dGluZ3MsIGNhc2VEb2NJZD86IHN0cmluZyk6IHN0cmluZyB7XG4gICAgY29uc3QgYmFzZSA9IChzZXR0aW5ncy5iYXNlX3VybCB8fCAnJykucmVwbGFjZSgvXFwvKyQvLCAnJyk7XG4gICAgaWYgKCFiYXNlIHx8ICFjYXNlRG9jSWQpIHJldHVybiAnJztcbiAgICByZXR1cm4gYCR7YmFzZX0vYXBwL3dhenVoQ2FzZU1hbmFnZW1lbnQjL2Nhc2VzLyR7Y2FzZURvY0lkfWA7XG4gIH1cblxuICBwcml2YXRlIHN0YXRpYyBidWlsZENoYW5uZWxQYXlsb2FkKGNoYW5uZWw6IE5vdGlmaWNhdGlvbkNoYW5uZWwsIHBhcmFtczogRGlzcGF0Y2hQYXJhbXMpOiBhbnkge1xuICAgIGNvbnN0IHRleHQgPSBgJHtwYXJhbXMudGl0bGV9XFxuJHtwYXJhbXMubWVzc2FnZX1gO1xuXG4gICAgc3dpdGNoIChjaGFubmVsLnR5cGUpIHtcbiAgICAgIGNhc2UgJ3NsYWNrJzpcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICB0ZXh0LFxuICAgICAgICAgIGF0dGFjaG1lbnRzOiBwYXJhbXMuY2FzZVJlZlxuICAgICAgICAgICAgPyBbXG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgY29sb3I6IE5vdGlmaWNhdGlvblNlcnZpY2Uuc2V2ZXJpdHlDb2xvcihwYXJhbXMuY2FzZVJlZi5zZXZlcml0eSksXG4gICAgICAgICAgICAgICAgICBmaWVsZHM6IFtcbiAgICAgICAgICAgICAgICAgICAgeyB0aXRsZTogJ0Nhc2UnLCB2YWx1ZTogcGFyYW1zLmNhc2VSZWYuY2FzZV9pZCB8fCAnJywgc2hvcnQ6IHRydWUgfSxcbiAgICAgICAgICAgICAgICAgICAgeyB0aXRsZTogJ1ByaW9yaXR5JywgdmFsdWU6IHBhcmFtcy5jYXNlUmVmLnByaW9yaXR5IHx8ICcnLCBzaG9ydDogdHJ1ZSB9LFxuICAgICAgICAgICAgICAgICAgICB7IHRpdGxlOiAnU2V2ZXJpdHknLCB2YWx1ZTogcGFyYW1zLmNhc2VSZWYuc2V2ZXJpdHkgfHwgJycsIHNob3J0OiB0cnVlIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgdGl0bGU6ICdTdGF0dXMnLCB2YWx1ZTogcGFyYW1zLmNhc2VSZWYuc3RhdHVzIHx8ICcnLCBzaG9ydDogdHJ1ZSB9LFxuICAgICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICBdXG4gICAgICAgICAgICA6IHVuZGVmaW5lZCxcbiAgICAgICAgfTtcblxuICAgICAgY2FzZSAndGVhbXMnOlxuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICdAdHlwZSc6ICdNZXNzYWdlQ2FyZCcsXG4gICAgICAgICAgJ0Bjb250ZXh0JzogJ2h0dHBzOi8vc2NoZW1hLm9yZy9leHRlbnNpb25zJyxcbiAgICAgICAgICBzdW1tYXJ5OiBwYXJhbXMudGl0bGUsXG4gICAgICAgICAgdGhlbWVDb2xvcjogTm90aWZpY2F0aW9uU2VydmljZS5zZXZlcml0eUNvbG9yKHBhcmFtcy5jYXNlUmVmPy5zZXZlcml0eSkucmVwbGFjZSgnIycsICcnKSxcbiAgICAgICAgICB0aXRsZTogcGFyYW1zLnRpdGxlLFxuICAgICAgICAgIHRleHQ6IHBhcmFtcy5tZXNzYWdlLFxuICAgICAgICAgIHNlY3Rpb25zOiBwYXJhbXMuY2FzZVJlZlxuICAgICAgICAgICAgPyBbXG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgZmFjdHM6IFtcbiAgICAgICAgICAgICAgICAgICAgeyBuYW1lOiAnQ2FzZScsIHZhbHVlOiBwYXJhbXMuY2FzZVJlZi5jYXNlX2lkIHx8ICcnIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgbmFtZTogJ1ByaW9yaXR5JywgdmFsdWU6IHBhcmFtcy5jYXNlUmVmLnByaW9yaXR5IHx8ICcnIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgbmFtZTogJ1NldmVyaXR5JywgdmFsdWU6IHBhcmFtcy5jYXNlUmVmLnNldmVyaXR5IHx8ICcnIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgbmFtZTogJ1N0YXR1cycsIHZhbHVlOiBwYXJhbXMuY2FzZVJlZi5zdGF0dXMgfHwgJycgfSxcbiAgICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgXVxuICAgICAgICAgICAgOiB1bmRlZmluZWQsXG4gICAgICAgIH07XG5cbiAgICAgIGNhc2UgJ3dlYmhvb2snOlxuICAgICAgZGVmYXVsdDpcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBldmVudDogcGFyYW1zLmV2ZW50LFxuICAgICAgICAgIHRpdGxlOiBwYXJhbXMudGl0bGUsXG4gICAgICAgICAgbWVzc2FnZTogcGFyYW1zLm1lc3NhZ2UsXG4gICAgICAgICAgYWN0b3I6IHBhcmFtcy5hY3RvcixcbiAgICAgICAgICB0aW1lc3RhbXA6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgICAgICBjYXNlOiBwYXJhbXMuY2FzZVJlZiB8fCBudWxsLFxuICAgICAgICAgIC4uLihwYXJhbXMuY29udGV4dCB8fCB7fSksXG4gICAgICAgIH07XG4gICAgfVxuICB9XG5cbiAgc3RhdGljIHNldmVyaXR5Q29sb3Ioc2V2ZXJpdHk/OiBzdHJpbmcpOiBzdHJpbmcge1xuICAgIHN3aXRjaCAoc2V2ZXJpdHkpIHtcbiAgICAgIGNhc2UgJ2NyaXRpY2FsJzogcmV0dXJuICcjRTc2NjRDJztcbiAgICAgIGNhc2UgJ2hpZ2gnOiAgICAgcmV0dXJuICcjREE4QjQ1JztcbiAgICAgIGNhc2UgJ21lZGl1bSc6ICAgcmV0dXJuICcjRDZCRjU3JztcbiAgICAgIGNhc2UgJ2xvdyc6ICAgICAgcmV0dXJuICcjNTRCMzk5JztcbiAgICAgIGRlZmF1bHQ6ICAgICAgICAgcmV0dXJuICcjOThBMkIzJztcbiAgICB9XG4gIH1cblxuICAvLyDilIDilIAgUmVhZGluZyAvIG1hcmtpbmcg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbiAgc3RhdGljIGFzeW5jIGxpc3QoXG4gICAgY2xpZW50OiBhbnksXG4gICAgdXNlcjogc3RyaW5nLFxuICAgIG9wdHM6IHsgdW5yZWFkX29ubHk/OiBib29sZWFuOyBzaXplPzogbnVtYmVyIH0gPSB7fSxcbiAgKTogUHJvbWlzZTx7IG5vdGlmaWNhdGlvbnM6IENhc2VOb3RpZmljYXRpb25bXTsgdW5yZWFkOiBudW1iZXIgfT4ge1xuICAgIGF3YWl0IE5vdGlmaWNhdGlvblNlcnZpY2UuZW5zdXJlSW5kZXgoY2xpZW50KTtcbiAgICBjb25zdCBzaXplID0gTWF0aC5taW4ob3B0cy5zaXplIHx8IDUwLCAyMDApO1xuXG4gICAgY29uc3QgbXVzdDogYW55W10gPSBbeyB0ZXJtOiB7IHVzZXIgfSB9XTtcbiAgICBpZiAob3B0cy51bnJlYWRfb25seSkgbXVzdC5wdXNoKHsgdGVybTogeyByZWFkOiBmYWxzZSB9IH0pO1xuXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHsgYm9keSB9ID0gYXdhaXQgY2xpZW50LnNlYXJjaCh7XG4gICAgICAgIGluZGV4OiBOT1RJRklDQVRJT05fSU5ERVgsXG4gICAgICAgIGJvZHk6IHtcbiAgICAgICAgICBxdWVyeTogeyBib29sOiB7IG11c3QgfSB9LFxuICAgICAgICAgIHNvcnQ6IFt7IGNyZWF0ZWRfYXQ6IHsgb3JkZXI6ICdkZXNjJyB9IH1dLFxuICAgICAgICAgIHNpemUsXG4gICAgICAgIH0sXG4gICAgICB9KTtcblxuICAgICAgY29uc3Qgbm90aWZpY2F0aW9ucyA9IChib2R5LmhpdHM/LmhpdHMgfHwgW10pLm1hcCgoaDogYW55KSA9PiAoe1xuICAgICAgICBpZDogaC5faWQsXG4gICAgICAgIC4uLmguX3NvdXJjZSxcbiAgICAgIH0pKSBhcyBDYXNlTm90aWZpY2F0aW9uW107XG5cbiAgICAgIGNvbnN0IHsgYm9keTogY291bnRCb2R5IH0gPSBhd2FpdCBjbGllbnQuY291bnQoe1xuICAgICAgICBpbmRleDogTk9USUZJQ0FUSU9OX0lOREVYLFxuICAgICAgICBib2R5OiB7IHF1ZXJ5OiB7IGJvb2w6IHsgbXVzdDogW3sgdGVybTogeyB1c2VyIH0gfSwgeyB0ZXJtOiB7IHJlYWQ6IGZhbHNlIH0gfV0gfSB9IH0sXG4gICAgICB9KTtcblxuICAgICAgcmV0dXJuIHsgbm90aWZpY2F0aW9ucywgdW5yZWFkOiBjb3VudEJvZHkuY291bnQgfHwgMCB9O1xuICAgIH0gY2F0Y2ggKF9lKSB7XG4gICAgICByZXR1cm4geyBub3RpZmljYXRpb25zOiBbXSwgdW5yZWFkOiAwIH07XG4gICAgfVxuICB9XG5cbiAgLyoqIE1hcmsgc3BlY2lmaWMgbm90aWZpY2F0aW9ucyByZWFkLCBvciBldmVyeSBub3RpZmljYXRpb24gZm9yIHRoZSB1c2VyLiAqL1xuICBzdGF0aWMgYXN5bmMgbWFya1JlYWQoY2xpZW50OiBhbnksIHVzZXI6IHN0cmluZywgaWRzPzogc3RyaW5nW10pOiBQcm9taXNlPG51bWJlcj4ge1xuICAgIHRyeSB7XG4gICAgICBpZiAoaWRzICYmIGlkcy5sZW5ndGggPiAwKSB7XG4gICAgICAgIGNvbnN0IG9wZXJhdGlvbnMgPSBpZHMuZmxhdE1hcCgoaWQpID0+IFtcbiAgICAgICAgICB7IHVwZGF0ZTogeyBfaW5kZXg6IE5PVElGSUNBVElPTl9JTkRFWCwgX2lkOiBpZCB9IH0sXG4gICAgICAgICAgeyBkb2M6IHsgcmVhZDogdHJ1ZSB9IH0sXG4gICAgICAgIF0pO1xuICAgICAgICBhd2FpdCBjbGllbnQuYnVsayh7IGJvZHk6IG9wZXJhdGlvbnMsIHJlZnJlc2g6ICd3YWl0X2ZvcicgfSk7XG4gICAgICAgIHJldHVybiBpZHMubGVuZ3RoO1xuICAgICAgfVxuXG4gICAgICBjb25zdCB7IGJvZHkgfSA9IGF3YWl0IGNsaWVudC51cGRhdGVCeVF1ZXJ5KHtcbiAgICAgICAgaW5kZXg6IE5PVElGSUNBVElPTl9JTkRFWCxcbiAgICAgICAgcmVmcmVzaDogdHJ1ZSxcbiAgICAgICAgYm9keToge1xuICAgICAgICAgIHF1ZXJ5OiB7IGJvb2w6IHsgbXVzdDogW3sgdGVybTogeyB1c2VyIH0gfSwgeyB0ZXJtOiB7IHJlYWQ6IGZhbHNlIH0gfV0gfSB9LFxuICAgICAgICAgIHNjcmlwdDogeyBzb3VyY2U6ICdjdHguX3NvdXJjZS5yZWFkID0gdHJ1ZScsIGxhbmc6ICdwYWlubGVzcycgfSxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgICAgcmV0dXJuIGJvZHkudXBkYXRlZCB8fCAwO1xuICAgIH0gY2F0Y2ggKF9lKSB7XG4gICAgICByZXR1cm4gMDtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogU2VuZCBhIHNhbXBsZSBwYXlsb2FkIHRvIGEgY2hhbm5lbCBzbyB0aGUgdXNlciBjYW4gY29uZmlybSB0aGUgVVJMIGFuZFxuICAgKiBjcmVkZW50aWFscyB3b3JrIGJlZm9yZSByZWx5aW5nIG9uIGl0LiBSZXR1cm5zIHRoZSBtYXNrZWQgaGVhZGVycyBzbyBhXG4gICAqIGZhaWx1cmUgY2FuIGJlIGRpYWdub3NlZCB3aXRob3V0IGV4cG9zaW5nIHRoZSBzZWNyZXQuXG4gICAqL1xuICBzdGF0aWMgYXN5bmMgdGVzdENoYW5uZWwoXG4gICAgY2hhbm5lbDogTm90aWZpY2F0aW9uQ2hhbm5lbCxcbiAgICBzZXR0aW5ncz86IFBsdWdpblNldHRpbmdzLFxuICApOiBQcm9taXNlPENoYW5uZWxUZXN0UmVzdWx0PiB7XG4gICAgY29uc3QgaGVhZGVycyA9IGJ1aWxkQ2hhbm5lbEhlYWRlcnMoY2hhbm5lbCk7XG4gICAgY29uc3QgcGFyYW1zOiBEaXNwYXRjaFBhcmFtcyA9IHtcbiAgICAgIGV2ZW50OiAnY2FzZV9jcmVhdGVkJyxcbiAgICAgIHJlY2lwaWVudHM6IFtdLFxuICAgICAgdGl0bGU6ICdXYXp1aCBDYXNlIE1hbmFnZW1lbnQgdGVzdCBub3RpZmljYXRpb24nLFxuICAgICAgbWVzc2FnZTogJ0lmIHlvdSBjYW4gcmVhZCB0aGlzLCB0aGUgY2hhbm5lbCBVUkwgYW5kIGNyZWRlbnRpYWxzIGFyZSB3b3JraW5nLicsXG4gICAgICBjYXNlUmVmOiB7XG4gICAgICAgIGNhc2VfaWQ6ICdDQVNFLTAwMDAtVEVTVCcsXG4gICAgICAgIHRpdGxlOiAnVGVzdCBjYXNlJyxcbiAgICAgICAgcHJpb3JpdHk6ICdQMycsXG4gICAgICAgIHNldmVyaXR5OiAnbWVkaXVtJyxcbiAgICAgICAgc3RhdHVzOiAnb3BlbicsXG4gICAgICB9LFxuICAgICAgYWN0b3I6ICdzZXR0aW5ncy10ZXN0JyxcbiAgICAgIGNvbnRleHQ6IHsgdGVzdDogdHJ1ZSB9LFxuICAgIH07XG5cbiAgICBpZiAoY2hhbm5lbC50eXBlID09PSAnZW1haWwnKSB7XG4gICAgICBpZiAoIXNldHRpbmdzKSB7XG4gICAgICAgIHJldHVybiB7IG9rOiBmYWxzZSwgc3RhdHVzOiAwLCBlcnJvcjogJ1NldHRpbmdzIHVuYXZhaWxhYmxlJywgc2VudF9oZWFkZXJzOiB7fSB9O1xuICAgICAgfVxuICAgICAgaWYgKCFzZXR0aW5ncy5zbXRwPy5lbmFibGVkKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgb2s6IGZhbHNlLFxuICAgICAgICAgIHN0YXR1czogMCxcbiAgICAgICAgICBlcnJvcjogJ1NNVFAgaXMgbm90IGVuYWJsZWQuIFR1cm4gaXQgb24gYW5kIHNhdmUgYmVmb3JlIHRlc3RpbmcgYW4gZW1haWwgY2hhbm5lbC4nLFxuICAgICAgICAgIHNlbnRfaGVhZGVyczoge30sXG4gICAgICAgIH07XG4gICAgICB9XG4gICAgICBjb25zdCB7IHZhbGlkOiByZWNpcGllbnRzLCBpbnZhbGlkIH0gPSBub3JtYWxpemVSZWNpcGllbnRzKGNoYW5uZWwucmVjaXBpZW50cyB8fCBbXSk7XG4gICAgICBpZiAoaW52YWxpZC5sZW5ndGggPiAwKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgb2s6IGZhbHNlLFxuICAgICAgICAgIHN0YXR1czogMCxcbiAgICAgICAgICBlcnJvcjogYE5vdCBhIHZhbGlkIGFkZHJlc3M6ICR7aW52YWxpZC5qb2luKCcsICcpfWAsXG4gICAgICAgICAgc2VudF9oZWFkZXJzOiB7fSxcbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICAgIGlmIChyZWNpcGllbnRzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICByZXR1cm4geyBvazogZmFsc2UsIHN0YXR1czogMCwgZXJyb3I6ICdBZGQgYXQgbGVhc3Qgb25lIHJlY2lwaWVudCcsIHNlbnRfaGVhZGVyczoge30gfTtcbiAgICAgIH1cblxuICAgICAgY29uc3QgbWFpbCA9IE5vdGlmaWNhdGlvblNlcnZpY2UuYnVpbGRNYWlsKFxuICAgICAgICBzZXR0aW5ncyxcbiAgICAgICAgcmVjaXBpZW50cyxcbiAgICAgICAgcGFyYW1zLFxuICAgICAgICBjaGFubmVsLnJlY2lwaWVudF9tb2RlLFxuICAgICAgKTtcbiAgICAgIGNvbnN0IHNlbnQgPSBhd2FpdCBTbXRwU2VydmljZS5zZW5kKHNldHRpbmdzLnNtdHAsIG1haWwpO1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgb2s6IHNlbnQub2ssXG4gICAgICAgIHN0YXR1czogc2VudC5vayA/IDI1MCA6IDAsXG4gICAgICAgIGVycm9yOiBzZW50LmVycm9yLFxuICAgICAgICBzZW50X2hlYWRlcnM6IHt9LFxuICAgICAgICB0cmFuc2NyaXB0OiBzZW50LnRyYW5zY3JpcHQsXG4gICAgICB9O1xuICAgIH1cblxuICAgIGNvbnN0IGJvZHkgPSBOb3RpZmljYXRpb25TZXJ2aWNlLmJ1aWxkQ2hhbm5lbFBheWxvYWQoY2hhbm5lbCwgcGFyYW1zKTtcbiAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBwb3N0SnNvbihjaGFubmVsLnVybCwgYm9keSwgaGVhZGVycywge1xuICAgICAgdmVyaWZ5VGxzOiBjaGFubmVsLnZlcmlmeV90bHMsXG4gICAgfSk7XG5cbiAgICByZXR1cm4ge1xuICAgICAgb2s6IHJlc3VsdC5vayxcbiAgICAgIHN0YXR1czogcmVzdWx0LnN0YXR1cyxcbiAgICAgIGVycm9yOiByZXN1bHQuZXJyb3IsXG4gICAgICBzZW50X2hlYWRlcnM6IG1hc2tIZWFkZXJzKHsgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJywgLi4uaGVhZGVycyB9KSxcbiAgICB9O1xuICB9XG5cbiAgLyoqIFNlbmQgYSBzdGFuZGFsb25lIHRlc3QgZW1haWwgdG8gdmVyaWZ5IHRoZSBTTVRQIHNlcnZlciBzZXR0aW5ncy4gKi9cbiAgc3RhdGljIGFzeW5jIHRlc3RTbXRwKHNldHRpbmdzOiBQbHVnaW5TZXR0aW5ncywgcmVjaXBpZW50OiBzdHJpbmcpIHtcbiAgICBjb25zdCBtYWlsID0gTm90aWZpY2F0aW9uU2VydmljZS5idWlsZE1haWwoc2V0dGluZ3MsIFtyZWNpcGllbnRdLCB7XG4gICAgICBldmVudDogJ2Nhc2VfY3JlYXRlZCcsXG4gICAgICByZWNpcGllbnRzOiBbXSxcbiAgICAgIHRpdGxlOiAnV2F6dWggQ2FzZSBNYW5hZ2VtZW50IHRlc3QgZW1haWwnLFxuICAgICAgbWVzc2FnZTpcbiAgICAgICAgJ0lmIHRoaXMgbWVzc2FnZSByZWFjaGVkIHlvdSwgdGhlIFNNVFAgc2VydmVyLCBjcmVkZW50aWFscyBhbmQgc2VuZGVyIGFkZHJlc3MgYXJlIGNvbmZpZ3VyZWQgY29ycmVjdGx5LicsXG4gICAgICBjYXNlUmVmOiB7XG4gICAgICAgIGNhc2VfaWQ6ICdDQVNFLTAwMDAtVEVTVCcsXG4gICAgICAgIHRpdGxlOiAnVGVzdCBjYXNlJyxcbiAgICAgICAgcHJpb3JpdHk6ICdQMycsXG4gICAgICAgIHNldmVyaXR5OiAnbWVkaXVtJyxcbiAgICAgICAgc3RhdHVzOiAnb3BlbicsXG4gICAgICB9LFxuICAgICAgYWN0b3I6ICdzZXR0aW5ncy10ZXN0JyxcbiAgICB9KTtcbiAgICByZXR1cm4gU210cFNlcnZpY2Uuc2VuZChzZXR0aW5ncy5zbXRwLCBtYWlsKTtcbiAgfVxuXG4gIHN0YXRpYyBhc3luYyByZW1vdmUoY2xpZW50OiBhbnksIGlkOiBzdHJpbmcpOiBQcm9taXNlPGJvb2xlYW4+IHtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgY2xpZW50LmRlbGV0ZSh7IGluZGV4OiBOT1RJRklDQVRJT05fSU5ERVgsIGlkLCByZWZyZXNoOiAnd2FpdF9mb3InIH0pO1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfSBjYXRjaCAoX2UpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gIH1cbn1cbiJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7QUFTQSxJQUFBQSxLQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxNQUFBLEdBQUFELE9BQUE7QUFDQSxJQUFBRSxJQUFBLEdBQUFGLE9BQUE7QUFVQSxJQUFBRyxhQUFBLEdBQUFILE9BQUE7QUFDQSxJQUFBSSxVQUFBLEdBQUFKLE9BQUE7QUFDQSxJQUFBSyxpQkFBQSxHQUFBTCxPQUFBO0FBdkJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBa0JBLE1BQU1NLG9CQUFvQixHQUFHO0VBQzNCQyxRQUFRLEVBQUU7SUFBRUMsZ0JBQWdCLEVBQUUsQ0FBQztJQUFFQyxrQkFBa0IsRUFBRTtFQUFFLENBQUM7RUFDeERDLFFBQVEsRUFBRTtJQUNSQyxVQUFVLEVBQUU7TUFDVkMsSUFBSSxFQUFFO1FBQUVDLElBQUksRUFBRTtNQUFVLENBQUM7TUFDekJDLEtBQUssRUFBRTtRQUFFRCxJQUFJLEVBQUU7TUFBVSxDQUFDO01BQzFCRSxLQUFLLEVBQUU7UUFBRUYsSUFBSSxFQUFFLE1BQU07UUFBRUcsTUFBTSxFQUFFO1VBQUVDLE9BQU8sRUFBRTtZQUFFSixJQUFJLEVBQUU7VUFBVTtRQUFFO01BQUUsQ0FBQztNQUNqRUssT0FBTyxFQUFFO1FBQUVMLElBQUksRUFBRTtNQUFPLENBQUM7TUFDekJNLE9BQU8sRUFBRTtRQUFFTixJQUFJLEVBQUU7TUFBVSxDQUFDO01BQzVCTyxXQUFXLEVBQUU7UUFBRVAsSUFBSSxFQUFFO01BQVUsQ0FBQztNQUNoQ1EsSUFBSSxFQUFFO1FBQUVSLElBQUksRUFBRTtNQUFVLENBQUM7TUFDekJTLFVBQVUsRUFBRTtRQUFFVCxJQUFJLEVBQUU7TUFBTyxDQUFDO01BQzVCVSxVQUFVLEVBQUU7UUFBRVYsSUFBSSxFQUFFO01BQVU7SUFDaEM7RUFDRjtBQUNGLENBQUM7O0FBRUQ7QUFDQSxTQUFTVyxRQUFRQSxDQUNmQyxHQUFXLEVBQ1hDLElBQVMsRUFDVEMsT0FBK0IsRUFDL0JDLE9BQW9ELEdBQUcsQ0FBQyxDQUFDLEVBQ0M7RUFBQSxJQUFBQyxrQkFBQTtFQUMxRCxNQUFNQyxTQUFTLElBQUFELGtCQUFBLEdBQUdELE9BQU8sQ0FBQ0UsU0FBUyxjQUFBRCxrQkFBQSxjQUFBQSxrQkFBQSxHQUFJLElBQUk7RUFDM0M7RUFDQSxNQUFNRSxTQUFTLEdBQUdILE9BQU8sQ0FBQ0csU0FBUyxLQUFLLEtBQUs7RUFDN0MsT0FBTyxJQUFJQyxPQUFPLENBQUVDLE9BQU8sSUFBSztJQUM5QixJQUFJQyxNQUFXO0lBQ2YsSUFBSTtNQUNGQSxNQUFNLEdBQUcsSUFBSUMsUUFBRyxDQUFDVixHQUFHLENBQUM7SUFDdkIsQ0FBQyxDQUFDLE9BQU9XLENBQU0sRUFBRTtNQUNmSCxPQUFPLENBQUM7UUFBRUksRUFBRSxFQUFFLEtBQUs7UUFBRUMsTUFBTSxFQUFFLENBQUM7UUFBRUMsS0FBSyxFQUFHLGdCQUFlZCxHQUFJO01BQUUsQ0FBQyxDQUFDO01BQy9EO0lBQ0Y7SUFFQSxNQUFNZSxPQUFPLEdBQUdDLElBQUksQ0FBQ0MsU0FBUyxDQUFDaEIsSUFBSSxDQUFDO0lBQ3BDLE1BQU1pQixPQUFPLEdBQUdULE1BQU0sQ0FBQ1UsUUFBUSxLQUFLLFFBQVE7SUFDNUMsTUFBTUMsU0FBUyxHQUFHRixPQUFPLEdBQUdHLGNBQVksR0FBR0MsYUFBVztJQUV0RCxNQUFNQyxHQUFHLEdBQUdILFNBQVMsQ0FDbkI7TUFDRUQsUUFBUSxFQUFFVixNQUFNLENBQUNVLFFBQVE7TUFDekJLLFFBQVEsRUFBRWYsTUFBTSxDQUFDZSxRQUFRO01BQ3pCQyxJQUFJLEVBQUVoQixNQUFNLENBQUNnQixJQUFJLEtBQUtQLE9BQU8sR0FBRyxHQUFHLEdBQUcsRUFBRSxDQUFDO01BQ3pDUSxJQUFJLEVBQUcsR0FBRWpCLE1BQU0sQ0FBQ2tCLFFBQVMsR0FBRWxCLE1BQU0sQ0FBQ21CLE1BQU8sRUFBQztNQUMxQ0MsTUFBTSxFQUFFLE1BQU07TUFDZEMsT0FBTyxFQUFFekIsU0FBUztNQUNsQkgsT0FBTyxFQUFFO1FBQ1AsY0FBYyxFQUFFLGtCQUFrQjtRQUNsQyxnQkFBZ0IsRUFBRTZCLE1BQU0sQ0FBQ0MsVUFBVSxDQUFDakIsT0FBTyxDQUFDO1FBQzVDLEdBQUdiO01BQ0wsQ0FBQztNQUNEK0Isa0JBQWtCLEVBQUUzQjtJQUN0QixDQUFDLEVBQ0E0QixHQUFHLElBQUs7TUFDUEEsR0FBRyxDQUFDQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7TUFDZCxNQUFNdEIsTUFBTSxHQUFHcUIsR0FBRyxDQUFDRSxVQUFVLElBQUksQ0FBQztNQUNsQzVCLE9BQU8sQ0FBQztRQUFFSSxFQUFFLEVBQUVDLE1BQU0sSUFBSSxHQUFHLElBQUlBLE1BQU0sR0FBRyxHQUFHO1FBQUVBO01BQU8sQ0FBQyxDQUFDO0lBQ3hELENBQ0YsQ0FBQztJQUVEVSxHQUFHLENBQUNjLEVBQUUsQ0FBQyxTQUFTLEVBQUUsTUFBTTtNQUN0QmQsR0FBRyxDQUFDZSxPQUFPLENBQUMsQ0FBQztNQUNiOUIsT0FBTyxDQUFDO1FBQUVJLEVBQUUsRUFBRSxLQUFLO1FBQUVDLE1BQU0sRUFBRSxDQUFDO1FBQUVDLEtBQUssRUFBRTtNQUFVLENBQUMsQ0FBQztJQUNyRCxDQUFDLENBQUM7SUFDRlMsR0FBRyxDQUFDYyxFQUFFLENBQUMsT0FBTyxFQUFHRSxHQUFRLElBQUsvQixPQUFPLENBQUM7TUFBRUksRUFBRSxFQUFFLEtBQUs7TUFBRUMsTUFBTSxFQUFFLENBQUM7TUFBRUMsS0FBSyxFQUFFeUIsR0FBRyxDQUFDOUM7SUFBUSxDQUFDLENBQUMsQ0FBQztJQUNwRjhCLEdBQUcsQ0FBQ2lCLEtBQUssQ0FBQ3pCLE9BQU8sQ0FBQztJQUNsQlEsR0FBRyxDQUFDa0IsR0FBRyxDQUFDLENBQUM7RUFDWCxDQUFDLENBQUM7QUFDSjs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sU0FBU0MsbUJBQW1CQSxDQUFDQyxPQUE0QixFQUEwQjtFQUN4RixNQUFNekMsT0FBK0IsR0FBRyxDQUFDLENBQUM7RUFDMUMsTUFBTTBDLElBQUksR0FBR0QsT0FBTyxDQUFDQyxJQUFJO0VBRXpCLElBQUlBLElBQUksSUFBSUEsSUFBSSxDQUFDeEQsSUFBSSxJQUFJd0QsSUFBSSxDQUFDeEQsSUFBSSxLQUFLLE1BQU0sRUFBRTtJQUM3QyxRQUFRd0QsSUFBSSxDQUFDeEQsSUFBSTtNQUNmLEtBQUssUUFBUTtRQUNYLElBQUl3RCxJQUFJLENBQUNDLEtBQUssRUFBRTNDLE9BQU8sQ0FBQzRDLGFBQWEsR0FBSSxVQUFTRixJQUFJLENBQUNDLEtBQU0sRUFBQztRQUM5RDtNQUNGLEtBQUssT0FBTztRQUNWLElBQUlELElBQUksQ0FBQ0csUUFBUSxJQUFJSCxJQUFJLENBQUNJLFFBQVEsRUFBRTtVQUNsQyxNQUFNQyxPQUFPLEdBQUdsQixNQUFNLENBQUNtQixJQUFJLENBQUUsR0FBRU4sSUFBSSxDQUFDRyxRQUFRLElBQUksRUFBRyxJQUFHSCxJQUFJLENBQUNJLFFBQVEsSUFBSSxFQUFHLEVBQUMsQ0FBQyxDQUFDRyxRQUFRLENBQUMsUUFBUSxDQUFDO1VBQy9GakQsT0FBTyxDQUFDNEMsYUFBYSxHQUFJLFNBQVFHLE9BQVEsRUFBQztRQUM1QztRQUNBO01BQ0YsS0FBSyxTQUFTO1FBQ1osSUFBSUwsSUFBSSxDQUFDUSxXQUFXLElBQUlSLElBQUksQ0FBQ1MsWUFBWSxFQUFFO1VBQ3pDbkQsT0FBTyxDQUFDMEMsSUFBSSxDQUFDUSxXQUFXLENBQUMsR0FBR1IsSUFBSSxDQUFDUyxZQUFZO1FBQy9DO1FBQ0E7TUFDRjtRQUNFO0lBQ0o7RUFDRjtFQUVBLEtBQUssTUFBTSxDQUFDQyxHQUFHLEVBQUVDLEtBQUssQ0FBQyxJQUFJQyxNQUFNLENBQUNDLE9BQU8sQ0FBQ2QsT0FBTyxDQUFDekMsT0FBTyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUU7SUFDaEUsSUFBSW9ELEdBQUcsRUFBRXBELE9BQU8sQ0FBQ29ELEdBQUcsQ0FBQyxHQUFHQyxLQUFLO0VBQy9CO0VBRUEsT0FBT3JELE9BQU87QUFDaEI7O0FBRUE7QUFDTyxTQUFTd0QsV0FBV0EsQ0FBQ3hELE9BQStCLEVBQTBCO0VBQ25GLE1BQU15RCxTQUFTLEdBQUcsNEVBQTRFO0VBQzlGLE1BQU1DLE1BQThCLEdBQUcsQ0FBQyxDQUFDO0VBQ3pDLEtBQUssTUFBTSxDQUFDTixHQUFHLEVBQUVDLEtBQUssQ0FBQyxJQUFJQyxNQUFNLENBQUNDLE9BQU8sQ0FBQ3ZELE9BQU8sQ0FBQyxFQUFFO0lBQ2xELElBQUl5RCxTQUFTLENBQUNFLElBQUksQ0FBQ1AsR0FBRyxDQUFDLEVBQUU7TUFDdkI7TUFDQSxNQUFNUSxNQUFNLEdBQUdQLEtBQUssQ0FBQ1EsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztNQUNsQ0gsTUFBTSxDQUFDTixHQUFHLENBQUMsR0FBRyxtQkFBbUIsQ0FBQ08sSUFBSSxDQUFDQyxNQUFNLENBQUMsR0FBSSxHQUFFQSxNQUFPLFdBQVUsR0FBRyxVQUFVO0lBQ3BGLENBQUMsTUFBTTtNQUNMRixNQUFNLENBQUNOLEdBQUcsQ0FBQyxHQUFHQyxLQUFLO0lBQ3JCO0VBQ0Y7RUFDQSxPQUFPSyxNQUFNO0FBQ2Y7O0FBRUE7QUFDTyxTQUFTSSxjQUFjQSxDQUFDVCxLQUFhLEVBQVc7RUFDckQsT0FBTyxrQ0FBa0MsQ0FBQ00sSUFBSSxDQUFDSSxNQUFNLENBQUNWLEtBQUssSUFBSSxFQUFFLENBQUMsQ0FBQ1csSUFBSSxDQUFDLENBQUMsQ0FBQztBQUM1RTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sU0FBU0MsZUFBZUEsQ0FBQ0MsS0FBd0IsRUFBWTtFQUNsRSxNQUFNQyxHQUFHLEdBQUdDLEtBQUssQ0FBQ0MsT0FBTyxDQUFDSCxLQUFLLENBQUMsR0FBR0EsS0FBSyxDQUFDSSxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUdQLE1BQU0sQ0FBQ0csS0FBSyxJQUFJLEVBQUUsQ0FBQztFQUV4RSxNQUFNSyxTQUFTLEdBQUdKLEdBQUcsQ0FBQ0ssT0FBTyxDQUMzQiwwREFBMEQsRUFDMUQsQ0FBQ0MsTUFBTSxFQUFFQyxPQUFPLEtBQU0sSUFBR0EsT0FBUSxHQUNuQyxDQUFDO0VBRUQsT0FBT0gsU0FBUyxDQUNiVixLQUFLLENBQUMsU0FBUyxDQUFDLENBQ2hCYyxHQUFHLENBQUV0QixLQUFLLElBQUtBLEtBQUssQ0FBQ1csSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUM1QlksTUFBTSxDQUFDQyxPQUFPLENBQUM7QUFDcEI7O0FBRUE7QUFDTyxTQUFTQyxtQkFBbUJBLENBQUNaLEtBQXdCLEVBRzFEO0VBQ0EsTUFBTWEsSUFBSSxHQUFHLElBQUlDLEdBQUcsQ0FBUyxDQUFDO0VBQzlCLE1BQU1DLEtBQWUsR0FBRyxFQUFFO0VBQzFCLE1BQU1DLE9BQWlCLEdBQUcsRUFBRTtFQUU1QixLQUFLLE1BQU1SLE9BQU8sSUFBSVQsZUFBZSxDQUFDQyxLQUFLLENBQUMsRUFBRTtJQUM1QyxJQUFJLENBQUNKLGNBQWMsQ0FBQ1ksT0FBTyxDQUFDLEVBQUU7TUFDNUJRLE9BQU8sQ0FBQ0MsSUFBSSxDQUFDVCxPQUFPLENBQUM7TUFDckI7SUFDRjtJQUNBO0lBQ0EsTUFBTXRCLEdBQUcsR0FBR3NCLE9BQU8sQ0FBQ1UsV0FBVyxDQUFDLENBQUM7SUFDakMsSUFBSUwsSUFBSSxDQUFDTSxHQUFHLENBQUNqQyxHQUFHLENBQUMsRUFBRTtJQUNuQjJCLElBQUksQ0FBQ08sR0FBRyxDQUFDbEMsR0FBRyxDQUFDO0lBQ2I2QixLQUFLLENBQUNFLElBQUksQ0FBQ1QsT0FBTyxDQUFDO0VBQ3JCO0VBRUEsT0FBTztJQUFFTyxLQUFLO0lBQUVDO0VBQVEsQ0FBQztBQUMzQjs7QUFFQTtBQUNBLFNBQVNLLFVBQVVBLENBQUNsQyxLQUFhLEVBQVU7RUFDekMsT0FBT1UsTUFBTSxDQUFDVixLQUFLLGFBQUxBLEtBQUssY0FBTEEsS0FBSyxHQUFJLEVBQUUsQ0FBQyxDQUN2Qm1CLE9BQU8sQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLENBQ3RCQSxPQUFPLENBQUMsSUFBSSxFQUFFLE1BQU0sQ0FBQyxDQUNyQkEsT0FBTyxDQUFDLElBQUksRUFBRSxNQUFNLENBQUMsQ0FDckJBLE9BQU8sQ0FBQyxJQUFJLEVBQUUsUUFBUSxDQUFDLENBQ3ZCQSxPQUFPLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQztBQUMzQjtBQWVPLE1BQU1nQixtQkFBbUIsQ0FBQztFQUMvQixhQUFhQyxXQUFXQSxDQUFDQyxNQUFXLEVBQWlCO0lBQ25ELElBQUk7TUFDRixNQUFNO1FBQUUzRixJQUFJLEVBQUU0RjtNQUFPLENBQUMsR0FBRyxNQUFNRCxNQUFNLENBQUNFLE9BQU8sQ0FBQ0QsTUFBTSxDQUFDO1FBQUVFLEtBQUssRUFBRUM7TUFBbUIsQ0FBQyxDQUFDO01BQ25GLElBQUksQ0FBQ0gsTUFBTSxFQUFFO1FBQ1gsTUFBTUQsTUFBTSxDQUFDRSxPQUFPLENBQUNHLE1BQU0sQ0FBQztVQUFFRixLQUFLLEVBQUVDLDZCQUFrQjtVQUFFL0YsSUFBSSxFQUFFcEI7UUFBcUIsQ0FBQyxDQUFDO01BQ3hGO0lBQ0YsQ0FBQyxDQUFDLE9BQU9xSCxFQUFFLEVBQUU7TUFDWDtJQUFBO0VBRUo7O0VBRUE7O0VBRUE7QUFDRjtBQUNBO0FBQ0E7RUFDRSxhQUFhQyxRQUFRQSxDQUFDUCxNQUFXLEVBQUVRLE1BQXNCLEVBQUVDLE1BQWUsRUFBaUI7SUFDekYsSUFBSXZILFFBQXdCO0lBQzVCLElBQUk7TUFDRkEsUUFBUSxHQUFHLE1BQU13SCxpQ0FBZSxDQUFDQyxXQUFXLENBQUNYLE1BQU0sQ0FBQztJQUN0RCxDQUFDLENBQUMsT0FBT2pGLENBQU0sRUFBRTtNQUNmMEYsTUFBTSxhQUFOQSxNQUFNLGVBQU5BLE1BQU0sQ0FBRUcsSUFBSSxDQUFFLDJDQUEwQzdGLENBQUMsQ0FBQ2xCLE9BQVEsRUFBQyxDQUFDO01BQ3BFO0lBQ0Y7SUFFQSxNQUFNYyxPQUFPLENBQUNrRyxHQUFHLENBQUMsQ0FDaEJmLG1CQUFtQixDQUFDZ0IsV0FBVyxDQUFDZCxNQUFNLEVBQUU5RyxRQUFRLEVBQUVzSCxNQUFNLEVBQUVDLE1BQU0sQ0FBQyxFQUNqRVgsbUJBQW1CLENBQUNpQixjQUFjLENBQUNmLE1BQU0sRUFBRTlHLFFBQVEsRUFBRXNILE1BQU0sRUFBRUMsTUFBTSxDQUFDLENBQ3JFLENBQUM7RUFDSjtFQUVBLGFBQXFCSyxXQUFXQSxDQUM5QmQsTUFBVyxFQUNYOUcsUUFBd0IsRUFDeEJzSCxNQUFzQixFQUN0QkMsTUFBZSxFQUNBO0lBQ2YsTUFBTTtNQUFFTztJQUFjLENBQUMsR0FBRzlILFFBQVE7SUFDbEMsSUFBSSxDQUFDOEgsYUFBYSxDQUFDQyxjQUFjLEVBQUU7SUFDbkMsSUFBSSxDQUFDRCxhQUFhLENBQUNFLGFBQWEsQ0FBQ0MsUUFBUSxDQUFDWCxNQUFNLENBQUMvRyxLQUFLLENBQUMsRUFBRTs7SUFFekQ7SUFDQSxNQUFNMkgsVUFBVSxHQUFHMUMsS0FBSyxDQUFDcEIsSUFBSSxDQUMzQixJQUFJZ0MsR0FBRyxDQUNMa0IsTUFBTSxDQUFDWSxVQUFVLENBQUNsQyxNQUFNLENBQ3JCbUMsQ0FBQyxJQUFrQixDQUFDLENBQUNBLENBQUMsSUFBSUEsQ0FBQyxLQUFLLFNBQVMsSUFBSUEsQ0FBQyxLQUFLYixNQUFNLENBQUNjLEtBQzdELENBQ0YsQ0FDRixDQUFDO0lBQ0QsSUFBSUYsVUFBVSxDQUFDRyxNQUFNLEtBQUssQ0FBQyxFQUFFO0lBRTdCLElBQUk7TUFDRixNQUFNekIsbUJBQW1CLENBQUNDLFdBQVcsQ0FBQ0MsTUFBTSxDQUFDO01BQzdDLE1BQU13QixHQUFHLEdBQUcsSUFBSUMsSUFBSSxDQUFDLENBQUMsQ0FBQ0MsV0FBVyxDQUFDLENBQUM7TUFDcEMsTUFBTUMsVUFBaUIsR0FBRyxFQUFFO01BQzVCLEtBQUssTUFBTXBJLElBQUksSUFBSTZILFVBQVUsRUFBRTtRQUFBLElBQUFRLGVBQUEsRUFBQUMsZ0JBQUE7UUFDN0IsTUFBTUMsR0FBcUIsR0FBRztVQUM1QnZJLElBQUk7VUFDSkUsS0FBSyxFQUFFK0csTUFBTSxDQUFDL0csS0FBSztVQUNuQkMsS0FBSyxFQUFFOEcsTUFBTSxDQUFDOUcsS0FBSztVQUNuQkcsT0FBTyxFQUFFMkcsTUFBTSxDQUFDM0csT0FBTztVQUN2QkMsT0FBTyxFQUFFLEVBQUE4SCxlQUFBLEdBQUFwQixNQUFNLENBQUN1QixPQUFPLGNBQUFILGVBQUEsdUJBQWRBLGVBQUEsQ0FBZ0I5SCxPQUFPLEtBQUksSUFBSTtVQUN4Q0MsV0FBVyxFQUFFLEVBQUE4SCxnQkFBQSxHQUFBckIsTUFBTSxDQUFDdUIsT0FBTyxjQUFBRixnQkFBQSx1QkFBZEEsZ0JBQUEsQ0FBZ0JHLEVBQUUsS0FBSSxJQUFJO1VBQ3ZDaEksSUFBSSxFQUFFLEtBQUs7VUFDWEMsVUFBVSxFQUFFdUgsR0FBRztVQUNmdEgsVUFBVSxFQUFFc0csTUFBTSxDQUFDYztRQUNyQixDQUFDO1FBQ0RLLFVBQVUsQ0FBQ2xDLElBQUksQ0FBQztVQUFFVSxLQUFLLEVBQUU7WUFBRThCLE1BQU0sRUFBRTdCO1VBQW1CO1FBQUUsQ0FBQyxFQUFFMEIsR0FBRyxDQUFDO01BQ2pFO01BQ0EsTUFBTTlCLE1BQU0sQ0FBQ2tDLElBQUksQ0FBQztRQUFFN0gsSUFBSSxFQUFFc0gsVUFBVTtRQUFFUSxPQUFPLEVBQUU7TUFBVyxDQUFDLENBQUM7SUFDOUQsQ0FBQyxDQUFDLE9BQU9wSCxDQUFNLEVBQUU7TUFDZjBGLE1BQU0sYUFBTkEsTUFBTSxlQUFOQSxNQUFNLENBQUVHLElBQUksQ0FBRSx1Q0FBc0M3RixDQUFDLENBQUNsQixPQUFRLEVBQUMsQ0FBQztJQUNsRTtFQUNGO0VBRUEsYUFBcUJrSCxjQUFjQSxDQUNqQ2YsTUFBVyxFQUNYOUcsUUFBd0IsRUFDeEJzSCxNQUFzQixFQUN0QkMsTUFBZSxFQUNBO0lBQ2YsTUFBTTJCLFFBQVEsR0FBR2xKLFFBQVEsQ0FBQzhILGFBQWEsQ0FBQ29CLFFBQVEsQ0FBQ2xELE1BQU0sQ0FDcERtRCxDQUFDLElBQUtBLENBQUMsQ0FBQ0MsT0FBTyxJQUFJRCxDQUFDLENBQUNFLE1BQU0sQ0FBQ3BCLFFBQVEsQ0FBQ1gsTUFBTSxDQUFDL0csS0FBSyxDQUNwRCxDQUFDO0lBQ0QsSUFBSTJJLFFBQVEsQ0FBQ2IsTUFBTSxLQUFLLENBQUMsRUFBRTtJQUUzQixNQUFNNUcsT0FBTyxDQUFDa0csR0FBRyxDQUNmdUIsUUFBUSxDQUFDbkQsR0FBRyxDQUFDLE1BQU9sQyxPQUFPLElBQUs7TUFDOUIsSUFBSUEsT0FBTyxDQUFDdkQsSUFBSSxLQUFLLE9BQU8sRUFBRTtRQUM1QixNQUFNZ0osTUFBTSxHQUFHLE1BQU0xQyxtQkFBbUIsQ0FBQzJDLFNBQVMsQ0FBQ3ZKLFFBQVEsRUFBRTZELE9BQU8sRUFBRXlELE1BQU0sQ0FBQztRQUM3RSxJQUFJLENBQUNnQyxNQUFNLENBQUN4SCxFQUFFLEVBQUU7VUFDZHlGLE1BQU0sYUFBTkEsTUFBTSxlQUFOQSxNQUFNLENBQUVHLElBQUksQ0FBRSxpQ0FBZ0M3RCxPQUFPLENBQUMyRixJQUFLLGFBQVlGLE1BQU0sQ0FBQ3RILEtBQU0sRUFBQyxDQUFDO1FBQ3hGO1FBQ0E7TUFDRjtNQUVBLE1BQU1iLElBQUksR0FBR3lGLG1CQUFtQixDQUFDNkMsbUJBQW1CLENBQUM1RixPQUFPLEVBQUV5RCxNQUFNLENBQUM7TUFDckUsTUFBTWxHLE9BQU8sR0FBR3dDLG1CQUFtQixDQUFDQyxPQUFPLENBQUM7TUFDNUMsTUFBTXlGLE1BQU0sR0FBRyxNQUFNckksUUFBUSxDQUFDNEMsT0FBTyxDQUFDM0MsR0FBRyxFQUFFQyxJQUFJLEVBQUVDLE9BQU8sRUFBRTtRQUN4REksU0FBUyxFQUFFcUMsT0FBTyxDQUFDNkY7TUFDckIsQ0FBQyxDQUFDO01BQ0YsSUFBSSxDQUFDSixNQUFNLENBQUN4SCxFQUFFLEVBQUU7UUFDZHlGLE1BQU0sYUFBTkEsTUFBTSxlQUFOQSxNQUFNLENBQUVHLElBQUksQ0FDVCwyQkFBMEI3RCxPQUFPLENBQUMyRixJQUFLLGFBQVlGLE1BQU0sQ0FBQ3ZILE1BQU8sS0FBSXVILE1BQU0sQ0FBQ3RILEtBQUssSUFBSSxFQUFHLEVBQzNGLENBQUM7TUFDSDtJQUNGLENBQUMsQ0FDSCxDQUFDO0VBQ0g7O0VBRUE7RUFDQSxhQUFxQnVILFNBQVNBLENBQzVCdkosUUFBd0IsRUFDeEI2RCxPQUE0QixFQUM1QnlELE1BQXNCLEVBQ3RCO0lBQUEsSUFBQXFDLGNBQUE7SUFDQSxJQUFJLEdBQUFBLGNBQUEsR0FBQzNKLFFBQVEsQ0FBQzRKLElBQUksY0FBQUQsY0FBQSxlQUFiQSxjQUFBLENBQWVQLE9BQU8sR0FBRTtNQUMzQixPQUFPO1FBQUV0SCxFQUFFLEVBQUUsS0FBSztRQUFFRSxLQUFLLEVBQUU7TUFBa0MsQ0FBQztJQUNoRTtJQUNBLE1BQU07TUFBRXFFLEtBQUssRUFBRTZCO0lBQVcsQ0FBQyxHQUFHaEMsbUJBQW1CLENBQUNyQyxPQUFPLENBQUNxRSxVQUFVLElBQUksRUFBRSxDQUFDO0lBQzNFLElBQUlBLFVBQVUsQ0FBQ0csTUFBTSxLQUFLLENBQUMsRUFBRTtNQUMzQixPQUFPO1FBQUV2RyxFQUFFLEVBQUUsS0FBSztRQUFFRSxLQUFLLEVBQUcsa0JBQWlCNkIsT0FBTyxDQUFDMkYsSUFBSztNQUFxQixDQUFDO0lBQ2xGO0lBRUEsTUFBTTdJLE9BQU8sR0FBR2lHLG1CQUFtQixDQUFDaUQsU0FBUyxDQUFDN0osUUFBUSxFQUFFa0ksVUFBVSxFQUFFWixNQUFNLEVBQUV6RCxPQUFPLENBQUNpRyxjQUFjLENBQUM7SUFDbkcsT0FBT0MseUJBQVcsQ0FBQ0MsSUFBSSxDQUFDaEssUUFBUSxDQUFDNEosSUFBSSxFQUFFakosT0FBTyxDQUFDO0VBQ2pEOztFQUVBO0VBQ0EsT0FBT2tKLFNBQVNBLENBQ2Q3SixRQUF3QixFQUN4QmtJLFVBQW9CLEVBQ3BCWixNQUFzQixFQUN0QjJDLGFBQTJCLEdBQUcsSUFBSSxFQUNyQjtJQUNiLE1BQU1kLENBQUMsR0FBRzdCLE1BQU0sQ0FBQ3VCLE9BQU87SUFDeEIsTUFBTXFCLFFBQVEsR0FBR3RELG1CQUFtQixDQUFDdUQsT0FBTyxDQUFDbkssUUFBUSxFQUFFbUosQ0FBQyxhQUFEQSxDQUFDLHVCQUFEQSxDQUFDLENBQUVMLEVBQUUsQ0FBQztJQUU3RCxNQUFNc0IsS0FBOEIsR0FBRyxFQUFFO0lBQ3pDLElBQUlqQixDQUFDLGFBQURBLENBQUMsZUFBREEsQ0FBQyxDQUFFdkksT0FBTyxFQUFFd0osS0FBSyxDQUFDN0QsSUFBSSxDQUFDLENBQUMsTUFBTSxFQUFFNEMsQ0FBQyxDQUFDdkksT0FBTyxDQUFDLENBQUM7SUFDL0MsSUFBSXVJLENBQUMsYUFBREEsQ0FBQyxlQUFEQSxDQUFDLENBQUUzSSxLQUFLLEVBQUU0SixLQUFLLENBQUM3RCxJQUFJLENBQUMsQ0FBQyxPQUFPLEVBQUU0QyxDQUFDLENBQUMzSSxLQUFLLENBQUMsQ0FBQztJQUM1QyxJQUFJMkksQ0FBQyxhQUFEQSxDQUFDLGVBQURBLENBQUMsQ0FBRWtCLFFBQVEsRUFBRUQsS0FBSyxDQUFDN0QsSUFBSSxDQUFDLENBQUMsVUFBVSxFQUFFcEIsTUFBTSxDQUFDZ0UsQ0FBQyxDQUFDa0IsUUFBUSxDQUFDLENBQUMsQ0FBQztJQUM3RCxJQUFJbEIsQ0FBQyxhQUFEQSxDQUFDLGVBQURBLENBQUMsQ0FBRW1CLFFBQVEsRUFBRUYsS0FBSyxDQUFDN0QsSUFBSSxDQUFDLENBQUMsVUFBVSxFQUFFcEIsTUFBTSxDQUFDZ0UsQ0FBQyxDQUFDbUIsUUFBUSxDQUFDLENBQUMsQ0FBQztJQUM3RCxJQUFJbkIsQ0FBQyxhQUFEQSxDQUFDLGVBQURBLENBQUMsQ0FBRXBILE1BQU0sRUFBRXFJLEtBQUssQ0FBQzdELElBQUksQ0FBQyxDQUFDLFFBQVEsRUFBRXBCLE1BQU0sQ0FBQ2dFLENBQUMsQ0FBQ3BILE1BQU0sQ0FBQyxDQUFDNkQsT0FBTyxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDO0lBQ3pFd0UsS0FBSyxDQUFDN0QsSUFBSSxDQUFDLENBQUMsY0FBYyxFQUFFZSxNQUFNLENBQUNjLEtBQUssQ0FBQyxDQUFDO0lBQzFDZ0MsS0FBSyxDQUFDN0QsSUFBSSxDQUFDLENBQUMsTUFBTSxFQUFFLElBQUlnQyxJQUFJLENBQUMsQ0FBQyxDQUFDQyxXQUFXLENBQUMsQ0FBQyxDQUFDNUMsT0FBTyxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQ0EsT0FBTyxDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDO0lBRXpGLE1BQU0yRSxPQUFPLEdBQUdwQixDQUFDLGFBQURBLENBQUMsZUFBREEsQ0FBQyxDQUFFdkksT0FBTyxHQUFJLElBQUd1SSxDQUFDLENBQUN2SSxPQUFRLEtBQUkwRyxNQUFNLENBQUM5RyxLQUFNLEVBQUMsR0FBRzhHLE1BQU0sQ0FBQzlHLEtBQUs7SUFFNUUsTUFBTWdLLFNBQVMsR0FBRyxDQUNoQmxELE1BQU0sQ0FBQzlHLEtBQUssRUFDWixFQUFFLEVBQ0Y4RyxNQUFNLENBQUMzRyxPQUFPLEVBQ2QsRUFBRSxFQUNGLEdBQUd5SixLQUFLLENBQUNyRSxHQUFHLENBQUMsQ0FBQyxDQUFDMEUsQ0FBQyxFQUFFQyxDQUFDLENBQUMsS0FBTSxHQUFFRCxDQUFFLEtBQUlDLENBQUUsRUFBQyxDQUFDLENBQ3ZDO0lBQ0QsSUFBSVIsUUFBUSxFQUFFTSxTQUFTLENBQUNqRSxJQUFJLENBQUMsRUFBRSxFQUFHLGtCQUFpQjJELFFBQVMsRUFBQyxDQUFDO0lBQzlETSxTQUFTLENBQUNqRSxJQUFJLENBQUMsRUFBRSxFQUFFLDJDQUEyQyxDQUFDO0lBRS9ELE1BQU1vRSxNQUFNLEdBQUcvRCxtQkFBbUIsQ0FBQ2dFLGFBQWEsQ0FBQ3pCLENBQUMsYUFBREEsQ0FBQyx1QkFBREEsQ0FBQyxDQUFFbUIsUUFBUSxDQUFDO0lBQzdELE1BQU1PLElBQUksR0FBSTtBQUNsQjtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtDQUErQ0YsTUFBTztBQUN0RDtBQUNBLHVFQUF1RWhFLFVBQVUsQ0FBQ1csTUFBTSxDQUFDOUcsS0FBSyxDQUFFO0FBQ2hHLHNGQUFzRm1HLFVBQVUsQ0FBQ1csTUFBTSxDQUFDM0csT0FBTyxDQUFFO0FBQ2pIO0FBQ0E7QUFDQTtBQUNBLGNBQWN5SixLQUFLLENBQ0pyRSxHQUFHLENBQ0YsQ0FBQyxDQUFDMEUsQ0FBQyxFQUFFQyxDQUFDLENBQUMsS0FDSiw0REFBMkQvRCxVQUFVLENBQUM4RCxDQUFDLENBQUUsaUVBQWdFOUQsVUFBVSxDQUFDK0QsQ0FBQyxDQUFFLFlBQzVKLENBQUMsQ0FDQWhGLElBQUksQ0FBQyxFQUFFLENBQUU7QUFDeEI7QUFDQTtBQUNBLFVBQ1V3RSxRQUFRLEdBQ0g7QUFDZiw0QkFBNEJ2RCxVQUFVLENBQUN1RCxRQUFRLENBQUU7QUFDakQsMEJBQTBCLEdBQ1osaURBQ0w7QUFDVDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxlQUFlO0lBRVgsT0FBTztNQUNMWSxFQUFFLEVBQUU1QyxVQUFVO01BQ2RxQyxPQUFPO01BQ1BRLElBQUksRUFBRVAsU0FBUyxDQUFDOUUsSUFBSSxDQUFDLElBQUksQ0FBQztNQUMxQm1GLElBQUk7TUFDSjtNQUNBO01BQ0FHLFFBQVEsRUFBRWYsYUFBYSxLQUFLLEtBQUssR0FBRywwQkFBMEIsR0FBR2dCO0lBQ25FLENBQUM7RUFDSDs7RUFFQTtFQUNBLE9BQWVkLE9BQU9BLENBQUNuSyxRQUF3QixFQUFFa0wsU0FBa0IsRUFBVTtJQUMzRSxNQUFNQyxJQUFJLEdBQUcsQ0FBQ25MLFFBQVEsQ0FBQ29MLFFBQVEsSUFBSSxFQUFFLEVBQUV4RixPQUFPLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQztJQUMxRCxJQUFJLENBQUN1RixJQUFJLElBQUksQ0FBQ0QsU0FBUyxFQUFFLE9BQU8sRUFBRTtJQUNsQyxPQUFRLEdBQUVDLElBQUssbUNBQWtDRCxTQUFVLEVBQUM7RUFDOUQ7RUFFQSxPQUFlekIsbUJBQW1CQSxDQUFDNUYsT0FBNEIsRUFBRXlELE1BQXNCLEVBQU87SUFBQSxJQUFBK0QsZ0JBQUE7SUFDNUYsTUFBTU4sSUFBSSxHQUFJLEdBQUV6RCxNQUFNLENBQUM5RyxLQUFNLEtBQUk4RyxNQUFNLENBQUMzRyxPQUFRLEVBQUM7SUFFakQsUUFBUWtELE9BQU8sQ0FBQ3ZELElBQUk7TUFDbEIsS0FBSyxPQUFPO1FBQ1YsT0FBTztVQUNMeUssSUFBSTtVQUNKTyxXQUFXLEVBQUVoRSxNQUFNLENBQUN1QixPQUFPLEdBQ3ZCLENBQ0U7WUFDRTBDLEtBQUssRUFBRTNFLG1CQUFtQixDQUFDZ0UsYUFBYSxDQUFDdEQsTUFBTSxDQUFDdUIsT0FBTyxDQUFDeUIsUUFBUSxDQUFDO1lBQ2pFN0osTUFBTSxFQUFFLENBQ047Y0FBRUQsS0FBSyxFQUFFLE1BQU07Y0FBRWlFLEtBQUssRUFBRTZDLE1BQU0sQ0FBQ3VCLE9BQU8sQ0FBQ2pJLE9BQU8sSUFBSSxFQUFFO2NBQUU0SyxLQUFLLEVBQUU7WUFBSyxDQUFDLEVBQ25FO2NBQUVoTCxLQUFLLEVBQUUsVUFBVTtjQUFFaUUsS0FBSyxFQUFFNkMsTUFBTSxDQUFDdUIsT0FBTyxDQUFDd0IsUUFBUSxJQUFJLEVBQUU7Y0FBRW1CLEtBQUssRUFBRTtZQUFLLENBQUMsRUFDeEU7Y0FBRWhMLEtBQUssRUFBRSxVQUFVO2NBQUVpRSxLQUFLLEVBQUU2QyxNQUFNLENBQUN1QixPQUFPLENBQUN5QixRQUFRLElBQUksRUFBRTtjQUFFa0IsS0FBSyxFQUFFO1lBQUssQ0FBQyxFQUN4RTtjQUFFaEwsS0FBSyxFQUFFLFFBQVE7Y0FBRWlFLEtBQUssRUFBRTZDLE1BQU0sQ0FBQ3VCLE9BQU8sQ0FBQzlHLE1BQU0sSUFBSSxFQUFFO2NBQUV5SixLQUFLLEVBQUU7WUFBSyxDQUFDO1VBRXhFLENBQUMsQ0FDRixHQUNEUDtRQUNOLENBQUM7TUFFSCxLQUFLLE9BQU87UUFDVixPQUFPO1VBQ0wsT0FBTyxFQUFFLGFBQWE7VUFDdEIsVUFBVSxFQUFFLCtCQUErQjtVQUMzQ1EsT0FBTyxFQUFFbkUsTUFBTSxDQUFDOUcsS0FBSztVQUNyQmtMLFVBQVUsRUFBRTlFLG1CQUFtQixDQUFDZ0UsYUFBYSxFQUFBUyxnQkFBQSxHQUFDL0QsTUFBTSxDQUFDdUIsT0FBTyxjQUFBd0MsZ0JBQUEsdUJBQWRBLGdCQUFBLENBQWdCZixRQUFRLENBQUMsQ0FBQzFFLE9BQU8sQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDO1VBQ3hGcEYsS0FBSyxFQUFFOEcsTUFBTSxDQUFDOUcsS0FBSztVQUNuQnVLLElBQUksRUFBRXpELE1BQU0sQ0FBQzNHLE9BQU87VUFDcEJnTCxRQUFRLEVBQUVyRSxNQUFNLENBQUN1QixPQUFPLEdBQ3BCLENBQ0U7WUFDRXVCLEtBQUssRUFBRSxDQUNMO2NBQUVaLElBQUksRUFBRSxNQUFNO2NBQUUvRSxLQUFLLEVBQUU2QyxNQUFNLENBQUN1QixPQUFPLENBQUNqSSxPQUFPLElBQUk7WUFBRyxDQUFDLEVBQ3JEO2NBQUU0SSxJQUFJLEVBQUUsVUFBVTtjQUFFL0UsS0FBSyxFQUFFNkMsTUFBTSxDQUFDdUIsT0FBTyxDQUFDd0IsUUFBUSxJQUFJO1lBQUcsQ0FBQyxFQUMxRDtjQUFFYixJQUFJLEVBQUUsVUFBVTtjQUFFL0UsS0FBSyxFQUFFNkMsTUFBTSxDQUFDdUIsT0FBTyxDQUFDeUIsUUFBUSxJQUFJO1lBQUcsQ0FBQyxFQUMxRDtjQUFFZCxJQUFJLEVBQUUsUUFBUTtjQUFFL0UsS0FBSyxFQUFFNkMsTUFBTSxDQUFDdUIsT0FBTyxDQUFDOUcsTUFBTSxJQUFJO1lBQUcsQ0FBQztVQUUxRCxDQUFDLENBQ0YsR0FDRGtKO1FBQ04sQ0FBQztNQUVILEtBQUssU0FBUztNQUNkO1FBQ0UsT0FBTztVQUNMMUssS0FBSyxFQUFFK0csTUFBTSxDQUFDL0csS0FBSztVQUNuQkMsS0FBSyxFQUFFOEcsTUFBTSxDQUFDOUcsS0FBSztVQUNuQkcsT0FBTyxFQUFFMkcsTUFBTSxDQUFDM0csT0FBTztVQUN2QnlILEtBQUssRUFBRWQsTUFBTSxDQUFDYyxLQUFLO1VBQ25Cd0QsU0FBUyxFQUFFLElBQUlyRCxJQUFJLENBQUMsQ0FBQyxDQUFDQyxXQUFXLENBQUMsQ0FBQztVQUNuQ3FELElBQUksRUFBRXZFLE1BQU0sQ0FBQ3VCLE9BQU8sSUFBSSxJQUFJO1VBQzVCLElBQUl2QixNQUFNLENBQUN3RSxPQUFPLElBQUksQ0FBQyxDQUFDO1FBQzFCLENBQUM7SUFDTDtFQUNGO0VBRUEsT0FBT2xCLGFBQWFBLENBQUNOLFFBQWlCLEVBQVU7SUFDOUMsUUFBUUEsUUFBUTtNQUNkLEtBQUssVUFBVTtRQUFFLE9BQU8sU0FBUztNQUNqQyxLQUFLLE1BQU07UUFBTSxPQUFPLFNBQVM7TUFDakMsS0FBSyxRQUFRO1FBQUksT0FBTyxTQUFTO01BQ2pDLEtBQUssS0FBSztRQUFPLE9BQU8sU0FBUztNQUNqQztRQUFpQixPQUFPLFNBQVM7SUFDbkM7RUFDRjs7RUFFQTs7RUFFQSxhQUFheUIsSUFBSUEsQ0FDZmpGLE1BQVcsRUFDWHpHLElBQVksRUFDWjJMLElBQThDLEdBQUcsQ0FBQyxDQUFDLEVBQ2E7SUFDaEUsTUFBTXBGLG1CQUFtQixDQUFDQyxXQUFXLENBQUNDLE1BQU0sQ0FBQztJQUM3QyxNQUFNbUYsSUFBSSxHQUFHQyxJQUFJLENBQUNDLEdBQUcsQ0FBQ0gsSUFBSSxDQUFDQyxJQUFJLElBQUksRUFBRSxFQUFFLEdBQUcsQ0FBQztJQUUzQyxNQUFNRyxJQUFXLEdBQUcsQ0FBQztNQUFFQyxJQUFJLEVBQUU7UUFBRWhNO01BQUs7SUFBRSxDQUFDLENBQUM7SUFDeEMsSUFBSTJMLElBQUksQ0FBQ00sV0FBVyxFQUFFRixJQUFJLENBQUM3RixJQUFJLENBQUM7TUFBRThGLElBQUksRUFBRTtRQUFFdkwsSUFBSSxFQUFFO01BQU07SUFBRSxDQUFDLENBQUM7SUFFMUQsSUFBSTtNQUFBLElBQUF5TCxVQUFBO01BQ0YsTUFBTTtRQUFFcEw7TUFBSyxDQUFDLEdBQUcsTUFBTTJGLE1BQU0sQ0FBQ2hFLE1BQU0sQ0FBQztRQUNuQ21FLEtBQUssRUFBRUMsNkJBQWtCO1FBQ3pCL0YsSUFBSSxFQUFFO1VBQ0pxTCxLQUFLLEVBQUU7WUFBRUMsSUFBSSxFQUFFO2NBQUVMO1lBQUs7VUFBRSxDQUFDO1VBQ3pCTSxJQUFJLEVBQUUsQ0FBQztZQUFFM0wsVUFBVSxFQUFFO2NBQUU0TCxLQUFLLEVBQUU7WUFBTztVQUFFLENBQUMsQ0FBQztVQUN6Q1Y7UUFDRjtNQUNGLENBQUMsQ0FBQztNQUVGLE1BQU1uRSxhQUFhLEdBQUcsQ0FBQyxFQUFBeUUsVUFBQSxHQUFBcEwsSUFBSSxDQUFDeUwsSUFBSSxjQUFBTCxVQUFBLHVCQUFUQSxVQUFBLENBQVdLLElBQUksS0FBSSxFQUFFLEVBQUU3RyxHQUFHLENBQUU4RyxDQUFNLEtBQU07UUFDN0QvRCxFQUFFLEVBQUUrRCxDQUFDLENBQUNDLEdBQUc7UUFDVCxHQUFHRCxDQUFDLENBQUNFO01BQ1AsQ0FBQyxDQUFDLENBQXVCO01BRXpCLE1BQU07UUFBRTVMLElBQUksRUFBRTZMO01BQVUsQ0FBQyxHQUFHLE1BQU1sRyxNQUFNLENBQUNtRyxLQUFLLENBQUM7UUFDN0NoRyxLQUFLLEVBQUVDLDZCQUFrQjtRQUN6Qi9GLElBQUksRUFBRTtVQUFFcUwsS0FBSyxFQUFFO1lBQUVDLElBQUksRUFBRTtjQUFFTCxJQUFJLEVBQUUsQ0FBQztnQkFBRUMsSUFBSSxFQUFFO2tCQUFFaE07Z0JBQUs7Y0FBRSxDQUFDLEVBQUU7Z0JBQUVnTSxJQUFJLEVBQUU7a0JBQUV2TCxJQUFJLEVBQUU7Z0JBQU07Y0FBRSxDQUFDO1lBQUU7VUFBRTtRQUFFO01BQ3JGLENBQUMsQ0FBQztNQUVGLE9BQU87UUFBRWdILGFBQWE7UUFBRW9GLE1BQU0sRUFBRUYsU0FBUyxDQUFDQyxLQUFLLElBQUk7TUFBRSxDQUFDO0lBQ3hELENBQUMsQ0FBQyxPQUFPN0YsRUFBRSxFQUFFO01BQ1gsT0FBTztRQUFFVSxhQUFhLEVBQUUsRUFBRTtRQUFFb0YsTUFBTSxFQUFFO01BQUUsQ0FBQztJQUN6QztFQUNGOztFQUVBO0VBQ0EsYUFBYUMsUUFBUUEsQ0FBQ3JHLE1BQVcsRUFBRXpHLElBQVksRUFBRStNLEdBQWMsRUFBbUI7SUFDaEYsSUFBSTtNQUNGLElBQUlBLEdBQUcsSUFBSUEsR0FBRyxDQUFDL0UsTUFBTSxHQUFHLENBQUMsRUFBRTtRQUN6QixNQUFNSSxVQUFVLEdBQUcyRSxHQUFHLENBQUNDLE9BQU8sQ0FBRXZFLEVBQUUsSUFBSyxDQUNyQztVQUFFd0UsTUFBTSxFQUFFO1lBQUV2RSxNQUFNLEVBQUU3Qiw2QkFBa0I7WUFBRTRGLEdBQUcsRUFBRWhFO1VBQUc7UUFBRSxDQUFDLEVBQ25EO1VBQUVGLEdBQUcsRUFBRTtZQUFFOUgsSUFBSSxFQUFFO1VBQUs7UUFBRSxDQUFDLENBQ3hCLENBQUM7UUFDRixNQUFNZ0csTUFBTSxDQUFDa0MsSUFBSSxDQUFDO1VBQUU3SCxJQUFJLEVBQUVzSCxVQUFVO1VBQUVRLE9BQU8sRUFBRTtRQUFXLENBQUMsQ0FBQztRQUM1RCxPQUFPbUUsR0FBRyxDQUFDL0UsTUFBTTtNQUNuQjtNQUVBLE1BQU07UUFBRWxIO01BQUssQ0FBQyxHQUFHLE1BQU0yRixNQUFNLENBQUN5RyxhQUFhLENBQUM7UUFDMUN0RyxLQUFLLEVBQUVDLDZCQUFrQjtRQUN6QitCLE9BQU8sRUFBRSxJQUFJO1FBQ2I5SCxJQUFJLEVBQUU7VUFDSnFMLEtBQUssRUFBRTtZQUFFQyxJQUFJLEVBQUU7Y0FBRUwsSUFBSSxFQUFFLENBQUM7Z0JBQUVDLElBQUksRUFBRTtrQkFBRWhNO2dCQUFLO2NBQUUsQ0FBQyxFQUFFO2dCQUFFZ00sSUFBSSxFQUFFO2tCQUFFdkwsSUFBSSxFQUFFO2dCQUFNO2NBQUUsQ0FBQztZQUFFO1VBQUUsQ0FBQztVQUMxRTBNLE1BQU0sRUFBRTtZQUFFQyxNQUFNLEVBQUUseUJBQXlCO1lBQUVDLElBQUksRUFBRTtVQUFXO1FBQ2hFO01BQ0YsQ0FBQyxDQUFDO01BQ0YsT0FBT3ZNLElBQUksQ0FBQ3dNLE9BQU8sSUFBSSxDQUFDO0lBQzFCLENBQUMsQ0FBQyxPQUFPdkcsRUFBRSxFQUFFO01BQ1gsT0FBTyxDQUFDO0lBQ1Y7RUFDRjs7RUFFQTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0VBQ0UsYUFBYXdHLFdBQVdBLENBQ3RCL0osT0FBNEIsRUFDNUI3RCxRQUF5QixFQUNHO0lBQzVCLE1BQU1vQixPQUFPLEdBQUd3QyxtQkFBbUIsQ0FBQ0MsT0FBTyxDQUFDO0lBQzVDLE1BQU15RCxNQUFzQixHQUFHO01BQzdCL0csS0FBSyxFQUFFLGNBQWM7TUFDckIySCxVQUFVLEVBQUUsRUFBRTtNQUNkMUgsS0FBSyxFQUFFLHlDQUF5QztNQUNoREcsT0FBTyxFQUFFLG9FQUFvRTtNQUM3RWtJLE9BQU8sRUFBRTtRQUNQakksT0FBTyxFQUFFLGdCQUFnQjtRQUN6QkosS0FBSyxFQUFFLFdBQVc7UUFDbEI2SixRQUFRLEVBQUUsSUFBSTtRQUNkQyxRQUFRLEVBQUUsUUFBUTtRQUNsQnZJLE1BQU0sRUFBRTtNQUNWLENBQUM7TUFDRHFHLEtBQUssRUFBRSxlQUFlO01BQ3RCMEQsT0FBTyxFQUFFO1FBQUUvRyxJQUFJLEVBQUU7TUFBSztJQUN4QixDQUFDO0lBRUQsSUFBSWxCLE9BQU8sQ0FBQ3ZELElBQUksS0FBSyxPQUFPLEVBQUU7TUFBQSxJQUFBdU4sZUFBQTtNQUM1QixJQUFJLENBQUM3TixRQUFRLEVBQUU7UUFDYixPQUFPO1VBQUU4QixFQUFFLEVBQUUsS0FBSztVQUFFQyxNQUFNLEVBQUUsQ0FBQztVQUFFQyxLQUFLLEVBQUUsc0JBQXNCO1VBQUU4TCxZQUFZLEVBQUUsQ0FBQztRQUFFLENBQUM7TUFDbEY7TUFDQSxJQUFJLEdBQUFELGVBQUEsR0FBQzdOLFFBQVEsQ0FBQzRKLElBQUksY0FBQWlFLGVBQUEsZUFBYkEsZUFBQSxDQUFlekUsT0FBTyxHQUFFO1FBQzNCLE9BQU87VUFDTHRILEVBQUUsRUFBRSxLQUFLO1VBQ1RDLE1BQU0sRUFBRSxDQUFDO1VBQ1RDLEtBQUssRUFBRSwyRUFBMkU7VUFDbEY4TCxZQUFZLEVBQUUsQ0FBQztRQUNqQixDQUFDO01BQ0g7TUFDQSxNQUFNO1FBQUV6SCxLQUFLLEVBQUU2QixVQUFVO1FBQUU1QjtNQUFRLENBQUMsR0FBR0osbUJBQW1CLENBQUNyQyxPQUFPLENBQUNxRSxVQUFVLElBQUksRUFBRSxDQUFDO01BQ3BGLElBQUk1QixPQUFPLENBQUMrQixNQUFNLEdBQUcsQ0FBQyxFQUFFO1FBQ3RCLE9BQU87VUFDTHZHLEVBQUUsRUFBRSxLQUFLO1VBQ1RDLE1BQU0sRUFBRSxDQUFDO1VBQ1RDLEtBQUssRUFBRyx3QkFBdUJzRSxPQUFPLENBQUNaLElBQUksQ0FBQyxJQUFJLENBQUUsRUFBQztVQUNuRG9JLFlBQVksRUFBRSxDQUFDO1FBQ2pCLENBQUM7TUFDSDtNQUNBLElBQUk1RixVQUFVLENBQUNHLE1BQU0sS0FBSyxDQUFDLEVBQUU7UUFDM0IsT0FBTztVQUFFdkcsRUFBRSxFQUFFLEtBQUs7VUFBRUMsTUFBTSxFQUFFLENBQUM7VUFBRUMsS0FBSyxFQUFFLDRCQUE0QjtVQUFFOEwsWUFBWSxFQUFFLENBQUM7UUFBRSxDQUFDO01BQ3hGO01BRUEsTUFBTUMsSUFBSSxHQUFHbkgsbUJBQW1CLENBQUNpRCxTQUFTLENBQ3hDN0osUUFBUSxFQUNSa0ksVUFBVSxFQUNWWixNQUFNLEVBQ056RCxPQUFPLENBQUNpRyxjQUNWLENBQUM7TUFDRCxNQUFNa0UsSUFBSSxHQUFHLE1BQU1qRSx5QkFBVyxDQUFDQyxJQUFJLENBQUNoSyxRQUFRLENBQUM0SixJQUFJLEVBQUVtRSxJQUFJLENBQUM7TUFDeEQsT0FBTztRQUNMak0sRUFBRSxFQUFFa00sSUFBSSxDQUFDbE0sRUFBRTtRQUNYQyxNQUFNLEVBQUVpTSxJQUFJLENBQUNsTSxFQUFFLEdBQUcsR0FBRyxHQUFHLENBQUM7UUFDekJFLEtBQUssRUFBRWdNLElBQUksQ0FBQ2hNLEtBQUs7UUFDakI4TCxZQUFZLEVBQUUsQ0FBQyxDQUFDO1FBQ2hCRyxVQUFVLEVBQUVELElBQUksQ0FBQ0M7TUFDbkIsQ0FBQztJQUNIO0lBRUEsTUFBTTlNLElBQUksR0FBR3lGLG1CQUFtQixDQUFDNkMsbUJBQW1CLENBQUM1RixPQUFPLEVBQUV5RCxNQUFNLENBQUM7SUFDckUsTUFBTWdDLE1BQU0sR0FBRyxNQUFNckksUUFBUSxDQUFDNEMsT0FBTyxDQUFDM0MsR0FBRyxFQUFFQyxJQUFJLEVBQUVDLE9BQU8sRUFBRTtNQUN4REksU0FBUyxFQUFFcUMsT0FBTyxDQUFDNkY7SUFDckIsQ0FBQyxDQUFDO0lBRUYsT0FBTztNQUNMNUgsRUFBRSxFQUFFd0gsTUFBTSxDQUFDeEgsRUFBRTtNQUNiQyxNQUFNLEVBQUV1SCxNQUFNLENBQUN2SCxNQUFNO01BQ3JCQyxLQUFLLEVBQUVzSCxNQUFNLENBQUN0SCxLQUFLO01BQ25COEwsWUFBWSxFQUFFbEosV0FBVyxDQUFDO1FBQUUsY0FBYyxFQUFFLGtCQUFrQjtRQUFFLEdBQUd4RDtNQUFRLENBQUM7SUFDOUUsQ0FBQztFQUNIOztFQUVBO0VBQ0EsYUFBYThNLFFBQVFBLENBQUNsTyxRQUF3QixFQUFFbU8sU0FBaUIsRUFBRTtJQUNqRSxNQUFNSixJQUFJLEdBQUduSCxtQkFBbUIsQ0FBQ2lELFNBQVMsQ0FBQzdKLFFBQVEsRUFBRSxDQUFDbU8sU0FBUyxDQUFDLEVBQUU7TUFDaEU1TixLQUFLLEVBQUUsY0FBYztNQUNyQjJILFVBQVUsRUFBRSxFQUFFO01BQ2QxSCxLQUFLLEVBQUUsa0NBQWtDO01BQ3pDRyxPQUFPLEVBQ0wsd0dBQXdHO01BQzFHa0ksT0FBTyxFQUFFO1FBQ1BqSSxPQUFPLEVBQUUsZ0JBQWdCO1FBQ3pCSixLQUFLLEVBQUUsV0FBVztRQUNsQjZKLFFBQVEsRUFBRSxJQUFJO1FBQ2RDLFFBQVEsRUFBRSxRQUFRO1FBQ2xCdkksTUFBTSxFQUFFO01BQ1YsQ0FBQztNQUNEcUcsS0FBSyxFQUFFO0lBQ1QsQ0FBQyxDQUFDO0lBQ0YsT0FBTzJCLHlCQUFXLENBQUNDLElBQUksQ0FBQ2hLLFFBQVEsQ0FBQzRKLElBQUksRUFBRW1FLElBQUksQ0FBQztFQUM5QztFQUVBLGFBQWFLLE1BQU1BLENBQUN0SCxNQUFXLEVBQUVnQyxFQUFVLEVBQW9CO0lBQzdELElBQUk7TUFDRixNQUFNaEMsTUFBTSxDQUFDdUgsTUFBTSxDQUFDO1FBQUVwSCxLQUFLLEVBQUVDLDZCQUFrQjtRQUFFNEIsRUFBRTtRQUFFRyxPQUFPLEVBQUU7TUFBVyxDQUFDLENBQUM7TUFDM0UsT0FBTyxJQUFJO0lBQ2IsQ0FBQyxDQUFDLE9BQU83QixFQUFFLEVBQUU7TUFDWCxPQUFPLEtBQUs7SUFDZDtFQUNGO0FBQ0Y7QUFBQ2tILE9BQUEsQ0FBQTFILG1CQUFBLEdBQUFBLG1CQUFBIn0=