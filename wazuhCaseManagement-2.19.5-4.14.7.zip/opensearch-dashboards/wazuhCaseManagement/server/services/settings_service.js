"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.SettingsService = exports.DEFAULT_SETTINGS = void 0;
var _crypto = require("crypto");
var _types = require("../../common/types");
var _constants = require("../../common/constants");
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); } /*
 * Wazuh Case Management Plugin
 * Settings Service: persisted, user-editable plugin configuration
 *
 * Everything that used to be a hard-coded constant (case ID format, theme,
 * timestamp rendering, notification channels, escalation policies, API keys)
 * lives in a single document in the settings index so it survives restarts and
 * can be edited from Settings without a rebuild.
 */
const SETTINGS_DOC_ID = 'plugin_settings';

/** Settings are read on nearly every request. Cache them briefly. */
const CACHE_TTL_MS = 15_000;
const DEFAULT_SETTINGS = exports.DEFAULT_SETTINGS = {
  case_id: {
    prefix: _constants.CASE_ID_PREFIX,
    separator: _constants.CASE_ID_SEPARATOR,
    include_year: _constants.CASE_ID_INCLUDE_YEAR,
    padding: _constants.CASE_ID_PADDING
  },
  theme: 'auto',
  timestamp: {
    clock: '24h',
    show_seconds: true,
    timezone: 'browser'
  },
  notifications: {
    in_app_enabled: true,
    in_app_events: ['case_assigned', 'task_assigned', 'case_escalated', 'comment_added'],
    channels: []
  },
  escalation: {
    enabled: false,
    policies: []
  },
  smtp: {
    enabled: false,
    host: '',
    port: 587,
    security: 'starttls',
    auth_type: 'auto',
    username: '',
    password: '',
    from_address: '',
    from_name: 'Wazuh Case Management',
    reject_unauthorized: true,
    timeout_ms: _constants.SMTP_DEFAULT_TIMEOUT_MS
  },
  base_url: '',
  api_keys: [],
  updated_at: new Date().toISOString(),
  updated_by: 'system'
};
const settingsMappings = {
  settings: {
    number_of_shards: 1,
    number_of_replicas: 1
  },
  mappings: {
    // The settings document is a single, deeply-nested blob that is only ever
    // fetched by ID, so indexing its fields would only invite mapping conflicts.
    dynamic: false,
    properties: {
      updated_at: {
        type: 'date'
      },
      updated_by: {
        type: 'keyword'
      }
    }
  }
};
class SettingsService {
  // ── Index bootstrap ──────────────────────────────────────────

  static async ensureIndex(client) {
    try {
      const {
        body: exists
      } = await client.indices.exists({
        index: _constants.SETTINGS_INDEX
      });
      if (!exists) {
        await client.indices.create({
          index: _constants.SETTINGS_INDEX,
          body: settingsMappings
        });
      }
    } catch (e) {
      var _e$body, _e$meta;
      const type = (e === null || e === void 0 || (_e$body = e.body) === null || _e$body === void 0 || (_e$body = _e$body.error) === null || _e$body === void 0 ? void 0 : _e$body.type) || (e === null || e === void 0 || (_e$meta = e.meta) === null || _e$meta === void 0 || (_e$meta = _e$meta.body) === null || _e$meta === void 0 || (_e$meta = _e$meta.error) === null || _e$meta === void 0 ? void 0 : _e$meta.type);
      if (type !== 'resource_already_exists_exception') {
        // Non-fatal: getSettings falls back to defaults if the index is missing.
      }
    }
  }

  // ── Read / write ─────────────────────────────────────────────

  /** Fetch the effective settings, merged over defaults. */
  static async getSettings(client, useCache = true) {
    if (useCache && SettingsService.cache && Date.now() - SettingsService.cache.at < CACHE_TTL_MS) {
      return SettingsService.cache.value;
    }
    let stored = {};
    try {
      const {
        body
      } = await client.get({
        index: _constants.SETTINGS_INDEX,
        id: SETTINGS_DOC_ID
      });
      stored = body._source || {};
    } catch (e) {
      var _e$statusCode, _e$meta2;
      const status = (_e$statusCode = e === null || e === void 0 ? void 0 : e.statusCode) !== null && _e$statusCode !== void 0 ? _e$statusCode : e === null || e === void 0 || (_e$meta2 = e.meta) === null || _e$meta2 === void 0 ? void 0 : _e$meta2.statusCode;
      // 404 (no document) and 404-on-missing-index both mean "use defaults".
      if (status !== 404) throw e;
    }
    const merged = SettingsService.merge(stored);
    SettingsService.cache = {
      value: merged,
      at: Date.now()
    };
    return merged;
  }

  /** Merge a stored (possibly partial or older-schema) document over the defaults. */
  static merge(stored) {
    var _stored$notifications, _stored$escalation;
    return {
      ...DEFAULT_SETTINGS,
      ...stored,
      case_id: {
        ...DEFAULT_SETTINGS.case_id,
        ...(stored.case_id || {})
      },
      timestamp: {
        ...DEFAULT_SETTINGS.timestamp,
        ...(stored.timestamp || {})
      },
      notifications: {
        ...DEFAULT_SETTINGS.notifications,
        ...(stored.notifications || {}),
        channels: ((_stored$notifications = stored.notifications) === null || _stored$notifications === void 0 ? void 0 : _stored$notifications.channels) || []
      },
      escalation: {
        ...DEFAULT_SETTINGS.escalation,
        ...(stored.escalation || {}),
        policies: ((_stored$escalation = stored.escalation) === null || _stored$escalation === void 0 ? void 0 : _stored$escalation.policies) || []
      },
      smtp: {
        ...DEFAULT_SETTINGS.smtp,
        ...(stored.smtp || {})
      },
      api_keys: stored.api_keys || []
    };
  }

  /** Persist a partial settings update and return the merged result. */
  static async saveSettings(client, updates, user) {
    await SettingsService.ensureIndex(client);
    const existing = await SettingsService.getSettings(client, false);
    const merged = {
      ...existing,
      ...updates,
      // Nested sections are replaced wholesale when supplied, so that removing
      // a channel or policy actually removes it.
      case_id: {
        ...existing.case_id,
        ...(updates.case_id || {})
      },
      timestamp: {
        ...existing.timestamp,
        ...(updates.timestamp || {})
      },
      notifications: updates.notifications ? {
        ...existing.notifications,
        ...updates.notifications,
        // Re-attach any secret the browser echoed back as a placeholder.
        channels: (updates.notifications.channels || []).map(channel => SettingsService.mergeChannelSecrets(channel, existing.notifications.channels.find(c => c.id === channel.id)))
      } : existing.notifications,
      escalation: updates.escalation ? {
        ...existing.escalation,
        ...updates.escalation
      } : existing.escalation,
      smtp: updates.smtp ? {
        ...existing.smtp,
        ...updates.smtp,
        // The browser echoes the placeholder back when the password is unchanged.
        password: updates.smtp.password === _types.SECRET_PLACEHOLDER ? existing.smtp.password : updates.smtp.password
      } : existing.smtp,
      // API keys are never written through this path. Use the key helpers.
      api_keys: existing.api_keys,
      updated_at: new Date().toISOString(),
      updated_by: user
    };
    await client.index({
      index: _constants.SETTINGS_INDEX,
      id: SETTINGS_DOC_ID,
      body: merged,
      refresh: 'wait_for'
    });
    SettingsService.cache = {
      value: merged,
      at: Date.now()
    };
    return merged;
  }

  /** Strip secrets so the settings can be sent to the browser. */
  static toPublic(settings) {
    return {
      ...settings,
      api_keys: settings.api_keys.map(SettingsService.keyToPublic),
      notifications: {
        ...settings.notifications,
        channels: settings.notifications.channels.map(SettingsService.channelToPublic)
      },
      smtp: {
        ...settings.smtp,
        password: settings.smtp.password ? _types.SECRET_PLACEHOLDER : ''
      }
    };
  }

  /**
   * Replace a channel's stored credentials with a placeholder. The browser gets
   * enough to render the form (which auth mode, which header name) but never the
   * secret itself; saving the placeholder back preserves what is stored.
   */
  static channelToPublic(channel) {
    if (!channel.auth) return channel;
    const auth = {
      ...channel.auth
    };
    if (auth.token) auth.token = _types.SECRET_PLACEHOLDER;
    if (auth.password) auth.password = _types.SECRET_PLACEHOLDER;
    if (auth.header_value) auth.header_value = _types.SECRET_PLACEHOLDER;
    return {
      ...channel,
      auth
    };
  }

  /**
   * Merge an incoming channel over its stored counterpart, restoring any secret
   * the client sent back as the placeholder.
   */
  static mergeChannelSecrets(incoming, stored) {
    if (!incoming.auth) return incoming;
    const auth = {
      ...incoming.auth
    };
    const previous = stored === null || stored === void 0 ? void 0 : stored.auth;
    if (auth.token === _types.SECRET_PLACEHOLDER) auth.token = previous === null || previous === void 0 ? void 0 : previous.token;
    if (auth.password === _types.SECRET_PLACEHOLDER) auth.password = previous === null || previous === void 0 ? void 0 : previous.password;
    if (auth.header_value === _types.SECRET_PLACEHOLDER) auth.header_value = previous === null || previous === void 0 ? void 0 : previous.header_value;
    return {
      ...incoming,
      auth
    };
  }

  /**
   * Resolve a channel for an outbound send: if the caller passed placeholders
   * (e.g. the Test button on an unsaved edit), swap in the stored secrets.
   */
  static async resolveChannelSecrets(client, channel) {
    const settings = await SettingsService.getSettings(client);
    const stored = settings.notifications.channels.find(c => c.id === channel.id);
    return SettingsService.mergeChannelSecrets(channel, stored);
  }
  static keyToPublic(key) {
    const {
      hash,
      ...rest
    } = key;
    return rest;
  }

  // ── Case ID formatting ───────────────────────────────────────

  /**
   * Render a case ID from the configured format.
   * e.g. { prefix: 'INC', separator: '-', include_year: true, padding: 5 }
   *      with counter 42 → "INC-2026-00042"
   */
  static formatCaseId(settings, counter, date = new Date()) {
    const {
      prefix,
      separator,
      include_year,
      padding
    } = settings.case_id;
    const sep = separator !== null && separator !== void 0 ? separator : '-';
    const segments = [];
    if (prefix) segments.push(prefix);
    if (include_year) segments.push(String(date.getFullYear()));
    segments.push(String(counter).padStart(Math.max(1, padding || 1), '0'));
    return segments.join(sep);
  }

  // ── API keys ─────────────────────────────────────────────────

  static hashKey(rawKey) {
    return (0, _crypto.createHash)('sha256').update(rawKey).digest('hex');
  }

  /**
   * Create an API key. Returns the record plus the raw secret, which is shown
   * to the user exactly once and never stored in plaintext.
   */
  static async createApiKey(client, params, user) {
    await SettingsService.ensureIndex(client);
    const settings = await SettingsService.getSettings(client, false);
    const id = (0, _crypto.randomBytes)(8).toString('hex');
    const secretBody = (0, _crypto.randomBytes)(24).toString('base64url');
    const secret = `${_constants.API_KEY_TOKEN_PREFIX}_${id}_${secretBody}`;
    const record = {
      id,
      name: params.name,
      key_prefix: `${_constants.API_KEY_TOKEN_PREFIX}_${id}`,
      hash: SettingsService.hashKey(secret),
      scopes: params.scopes.length ? params.scopes : ['read'],
      enabled: true,
      created_at: new Date().toISOString(),
      created_by: user,
      last_used_at: null,
      expires_at: params.expires_at || null
    };
    await SettingsService.writeKeys(client, [...settings.api_keys, record], settings);
    return {
      key: SettingsService.keyToPublic(record),
      secret
    };
  }
  static async deleteApiKey(client, keyId) {
    const settings = await SettingsService.getSettings(client, false);
    const remaining = settings.api_keys.filter(k => k.id !== keyId);
    if (remaining.length === settings.api_keys.length) return false;
    await SettingsService.writeKeys(client, remaining, settings);
    return true;
  }
  static async setApiKeyEnabled(client, keyId, enabled) {
    const settings = await SettingsService.getSettings(client, false);
    let found = false;
    const updated = settings.api_keys.map(k => {
      if (k.id !== keyId) return k;
      found = true;
      return {
        ...k,
        enabled
      };
    });
    if (!found) return false;
    await SettingsService.writeKeys(client, updated, settings);
    return true;
  }

  /**
   * Look up an API key by its raw secret. Returns null when the key is unknown,
   * disabled or expired. Comparison is over the SHA-256 hash.
   */
  static async verifyApiKey(client, secret) {
    if (!secret) return null;
    const settings = await SettingsService.getSettings(client);
    const hash = SettingsService.hashKey(secret);
    const match = settings.api_keys.find(k => k.hash === hash);
    if (!match || !match.enabled) return null;
    if (match.expires_at && new Date(match.expires_at).getTime() < Date.now()) return null;
    return match;
  }

  /** Record key usage. Best-effort: never blocks the request. */
  static async touchApiKey(client, keyId) {
    try {
      const settings = await SettingsService.getSettings(client, false);
      const updated = settings.api_keys.map(k => k.id === keyId ? {
        ...k,
        last_used_at: new Date().toISOString()
      } : k);
      await SettingsService.writeKeys(client, updated, settings);
    } catch (_e) {
      /* usage tracking must never fail a request */
    }
  }
  static async writeKeys(client, keys, settings) {
    const merged = {
      ...settings,
      api_keys: keys,
      updated_at: new Date().toISOString()
    };
    await client.index({
      index: _constants.SETTINGS_INDEX,
      id: SETTINGS_DOC_ID,
      body: merged,
      refresh: 'wait_for'
    });
    SettingsService.cache = {
      value: merged,
      at: Date.now()
    };
  }

  /** Drop the cache: used after out-of-band writes. */
  static invalidateCache() {
    SettingsService.cache = null;
  }
}
exports.SettingsService = SettingsService;
_defineProperty(SettingsService, "cache", null);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6WyJfY3J5cHRvIiwicmVxdWlyZSIsIl90eXBlcyIsIl9jb25zdGFudHMiLCJfZGVmaW5lUHJvcGVydHkiLCJlIiwiciIsInQiLCJfdG9Qcm9wZXJ0eUtleSIsIk9iamVjdCIsImRlZmluZVByb3BlcnR5IiwidmFsdWUiLCJlbnVtZXJhYmxlIiwiY29uZmlndXJhYmxlIiwid3JpdGFibGUiLCJpIiwiX3RvUHJpbWl0aXZlIiwiU3ltYm9sIiwidG9QcmltaXRpdmUiLCJjYWxsIiwiVHlwZUVycm9yIiwiU3RyaW5nIiwiTnVtYmVyIiwiU0VUVElOR1NfRE9DX0lEIiwiQ0FDSEVfVFRMX01TIiwiREVGQVVMVF9TRVRUSU5HUyIsImV4cG9ydHMiLCJjYXNlX2lkIiwicHJlZml4IiwiQ0FTRV9JRF9QUkVGSVgiLCJzZXBhcmF0b3IiLCJDQVNFX0lEX1NFUEFSQVRPUiIsImluY2x1ZGVfeWVhciIsIkNBU0VfSURfSU5DTFVERV9ZRUFSIiwicGFkZGluZyIsIkNBU0VfSURfUEFERElORyIsInRoZW1lIiwidGltZXN0YW1wIiwiY2xvY2siLCJzaG93X3NlY29uZHMiLCJ0aW1lem9uZSIsIm5vdGlmaWNhdGlvbnMiLCJpbl9hcHBfZW5hYmxlZCIsImluX2FwcF9ldmVudHMiLCJjaGFubmVscyIsImVzY2FsYXRpb24iLCJlbmFibGVkIiwicG9saWNpZXMiLCJzbXRwIiwiaG9zdCIsInBvcnQiLCJzZWN1cml0eSIsImF1dGhfdHlwZSIsInVzZXJuYW1lIiwicGFzc3dvcmQiLCJmcm9tX2FkZHJlc3MiLCJmcm9tX25hbWUiLCJyZWplY3RfdW5hdXRob3JpemVkIiwidGltZW91dF9tcyIsIlNNVFBfREVGQVVMVF9USU1FT1VUX01TIiwiYmFzZV91cmwiLCJhcGlfa2V5cyIsInVwZGF0ZWRfYXQiLCJEYXRlIiwidG9JU09TdHJpbmciLCJ1cGRhdGVkX2J5Iiwic2V0dGluZ3NNYXBwaW5ncyIsInNldHRpbmdzIiwibnVtYmVyX29mX3NoYXJkcyIsIm51bWJlcl9vZl9yZXBsaWNhcyIsIm1hcHBpbmdzIiwiZHluYW1pYyIsInByb3BlcnRpZXMiLCJ0eXBlIiwiU2V0dGluZ3NTZXJ2aWNlIiwiZW5zdXJlSW5kZXgiLCJjbGllbnQiLCJib2R5IiwiZXhpc3RzIiwiaW5kaWNlcyIsImluZGV4IiwiU0VUVElOR1NfSU5ERVgiLCJjcmVhdGUiLCJfZSRib2R5IiwiX2UkbWV0YSIsImVycm9yIiwibWV0YSIsImdldFNldHRpbmdzIiwidXNlQ2FjaGUiLCJjYWNoZSIsIm5vdyIsImF0Iiwic3RvcmVkIiwiZ2V0IiwiaWQiLCJfc291cmNlIiwiX2Ukc3RhdHVzQ29kZSIsIl9lJG1ldGEyIiwic3RhdHVzIiwic3RhdHVzQ29kZSIsIm1lcmdlZCIsIm1lcmdlIiwiX3N0b3JlZCRub3RpZmljYXRpb25zIiwiX3N0b3JlZCRlc2NhbGF0aW9uIiwic2F2ZVNldHRpbmdzIiwidXBkYXRlcyIsInVzZXIiLCJleGlzdGluZyIsIm1hcCIsImNoYW5uZWwiLCJtZXJnZUNoYW5uZWxTZWNyZXRzIiwiZmluZCIsImMiLCJTRUNSRVRfUExBQ0VIT0xERVIiLCJyZWZyZXNoIiwidG9QdWJsaWMiLCJrZXlUb1B1YmxpYyIsImNoYW5uZWxUb1B1YmxpYyIsImF1dGgiLCJ0b2tlbiIsImhlYWRlcl92YWx1ZSIsImluY29taW5nIiwicHJldmlvdXMiLCJyZXNvbHZlQ2hhbm5lbFNlY3JldHMiLCJrZXkiLCJoYXNoIiwicmVzdCIsImZvcm1hdENhc2VJZCIsImNvdW50ZXIiLCJkYXRlIiwic2VwIiwic2VnbWVudHMiLCJwdXNoIiwiZ2V0RnVsbFllYXIiLCJwYWRTdGFydCIsIk1hdGgiLCJtYXgiLCJqb2luIiwiaGFzaEtleSIsInJhd0tleSIsImNyZWF0ZUhhc2giLCJ1cGRhdGUiLCJkaWdlc3QiLCJjcmVhdGVBcGlLZXkiLCJwYXJhbXMiLCJyYW5kb21CeXRlcyIsInRvU3RyaW5nIiwic2VjcmV0Qm9keSIsInNlY3JldCIsIkFQSV9LRVlfVE9LRU5fUFJFRklYIiwicmVjb3JkIiwibmFtZSIsImtleV9wcmVmaXgiLCJzY29wZXMiLCJsZW5ndGgiLCJjcmVhdGVkX2F0IiwiY3JlYXRlZF9ieSIsImxhc3RfdXNlZF9hdCIsImV4cGlyZXNfYXQiLCJ3cml0ZUtleXMiLCJkZWxldGVBcGlLZXkiLCJrZXlJZCIsInJlbWFpbmluZyIsImZpbHRlciIsImsiLCJzZXRBcGlLZXlFbmFibGVkIiwiZm91bmQiLCJ1cGRhdGVkIiwidmVyaWZ5QXBpS2V5IiwibWF0Y2giLCJnZXRUaW1lIiwidG91Y2hBcGlLZXkiLCJfZSIsImtleXMiLCJpbnZhbGlkYXRlQ2FjaGUiXSwic291cmNlcyI6WyJzZXR0aW5nc19zZXJ2aWNlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qXG4gKiBXYXp1aCBDYXNlIE1hbmFnZW1lbnQgUGx1Z2luXG4gKiBTZXR0aW5ncyBTZXJ2aWNlOiBwZXJzaXN0ZWQsIHVzZXItZWRpdGFibGUgcGx1Z2luIGNvbmZpZ3VyYXRpb25cbiAqXG4gKiBFdmVyeXRoaW5nIHRoYXQgdXNlZCB0byBiZSBhIGhhcmQtY29kZWQgY29uc3RhbnQgKGNhc2UgSUQgZm9ybWF0LCB0aGVtZSxcbiAqIHRpbWVzdGFtcCByZW5kZXJpbmcsIG5vdGlmaWNhdGlvbiBjaGFubmVscywgZXNjYWxhdGlvbiBwb2xpY2llcywgQVBJIGtleXMpXG4gKiBsaXZlcyBpbiBhIHNpbmdsZSBkb2N1bWVudCBpbiB0aGUgc2V0dGluZ3MgaW5kZXggc28gaXQgc3Vydml2ZXMgcmVzdGFydHMgYW5kXG4gKiBjYW4gYmUgZWRpdGVkIGZyb20gU2V0dGluZ3Mgd2l0aG91dCBhIHJlYnVpbGQuXG4gKi9cblxuaW1wb3J0IHsgY3JlYXRlSGFzaCwgcmFuZG9tQnl0ZXMgfSBmcm9tICdjcnlwdG8nO1xuaW1wb3J0IHtcbiAgUGx1Z2luU2V0dGluZ3MsXG4gIFBsdWdpblNldHRpbmdzUHVibGljLFxuICBBcGlLZXksXG4gIEFwaUtleVB1YmxpYyxcbiAgQXBpS2V5U2NvcGUsXG4gIE5vdGlmaWNhdGlvbkNoYW5uZWwsXG4gIFNFQ1JFVF9QTEFDRUhPTERFUixcbn0gZnJvbSAnLi4vLi4vY29tbW9uL3R5cGVzJztcbmltcG9ydCB7IFNNVFBfREVGQVVMVF9USU1FT1VUX01TIH0gZnJvbSAnLi4vLi4vY29tbW9uL2NvbnN0YW50cyc7XG5pbXBvcnQge1xuICBTRVRUSU5HU19JTkRFWCxcbiAgQ0FTRV9JRF9QUkVGSVgsXG4gIENBU0VfSURfU0VQQVJBVE9SLFxuICBDQVNFX0lEX1BBRERJTkcsXG4gIENBU0VfSURfSU5DTFVERV9ZRUFSLFxuICBBUElfS0VZX1RPS0VOX1BSRUZJWCxcbn0gZnJvbSAnLi4vLi4vY29tbW9uL2NvbnN0YW50cyc7XG5cbmNvbnN0IFNFVFRJTkdTX0RPQ19JRCA9ICdwbHVnaW5fc2V0dGluZ3MnO1xuXG4vKiogU2V0dGluZ3MgYXJlIHJlYWQgb24gbmVhcmx5IGV2ZXJ5IHJlcXVlc3QuIENhY2hlIHRoZW0gYnJpZWZseS4gKi9cbmNvbnN0IENBQ0hFX1RUTF9NUyA9IDE1XzAwMDtcblxuZXhwb3J0IGNvbnN0IERFRkFVTFRfU0VUVElOR1M6IFBsdWdpblNldHRpbmdzID0ge1xuICBjYXNlX2lkOiB7XG4gICAgcHJlZml4OiBDQVNFX0lEX1BSRUZJWCxcbiAgICBzZXBhcmF0b3I6IENBU0VfSURfU0VQQVJBVE9SLFxuICAgIGluY2x1ZGVfeWVhcjogQ0FTRV9JRF9JTkNMVURFX1lFQVIsXG4gICAgcGFkZGluZzogQ0FTRV9JRF9QQURESU5HLFxuICB9LFxuICB0aGVtZTogJ2F1dG8nLFxuICB0aW1lc3RhbXA6IHtcbiAgICBjbG9jazogJzI0aCcsXG4gICAgc2hvd19zZWNvbmRzOiB0cnVlLFxuICAgIHRpbWV6b25lOiAnYnJvd3NlcicsXG4gIH0sXG4gIG5vdGlmaWNhdGlvbnM6IHtcbiAgICBpbl9hcHBfZW5hYmxlZDogdHJ1ZSxcbiAgICBpbl9hcHBfZXZlbnRzOiBbJ2Nhc2VfYXNzaWduZWQnLCAndGFza19hc3NpZ25lZCcsICdjYXNlX2VzY2FsYXRlZCcsICdjb21tZW50X2FkZGVkJ10sXG4gICAgY2hhbm5lbHM6IFtdLFxuICB9LFxuICBlc2NhbGF0aW9uOiB7XG4gICAgZW5hYmxlZDogZmFsc2UsXG4gICAgcG9saWNpZXM6IFtdLFxuICB9LFxuICBzbXRwOiB7XG4gICAgZW5hYmxlZDogZmFsc2UsXG4gICAgaG9zdDogJycsXG4gICAgcG9ydDogNTg3LFxuICAgIHNlY3VyaXR5OiAnc3RhcnR0bHMnLFxuICAgIGF1dGhfdHlwZTogJ2F1dG8nLFxuICAgIHVzZXJuYW1lOiAnJyxcbiAgICBwYXNzd29yZDogJycsXG4gICAgZnJvbV9hZGRyZXNzOiAnJyxcbiAgICBmcm9tX25hbWU6ICdXYXp1aCBDYXNlIE1hbmFnZW1lbnQnLFxuICAgIHJlamVjdF91bmF1dGhvcml6ZWQ6IHRydWUsXG4gICAgdGltZW91dF9tczogU01UUF9ERUZBVUxUX1RJTUVPVVRfTVMsXG4gIH0sXG4gIGJhc2VfdXJsOiAnJyxcbiAgYXBpX2tleXM6IFtdLFxuICB1cGRhdGVkX2F0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gIHVwZGF0ZWRfYnk6ICdzeXN0ZW0nLFxufTtcblxuY29uc3Qgc2V0dGluZ3NNYXBwaW5ncyA9IHtcbiAgc2V0dGluZ3M6IHsgbnVtYmVyX29mX3NoYXJkczogMSwgbnVtYmVyX29mX3JlcGxpY2FzOiAxIH0sXG4gIG1hcHBpbmdzOiB7XG4gICAgLy8gVGhlIHNldHRpbmdzIGRvY3VtZW50IGlzIGEgc2luZ2xlLCBkZWVwbHktbmVzdGVkIGJsb2IgdGhhdCBpcyBvbmx5IGV2ZXJcbiAgICAvLyBmZXRjaGVkIGJ5IElELCBzbyBpbmRleGluZyBpdHMgZmllbGRzIHdvdWxkIG9ubHkgaW52aXRlIG1hcHBpbmcgY29uZmxpY3RzLlxuICAgIGR5bmFtaWM6IGZhbHNlLFxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgIHVwZGF0ZWRfYXQ6IHsgdHlwZTogJ2RhdGUnIH0sXG4gICAgICB1cGRhdGVkX2J5OiB7IHR5cGU6ICdrZXl3b3JkJyB9LFxuICAgIH0sXG4gIH0sXG59O1xuXG5leHBvcnQgY2xhc3MgU2V0dGluZ3NTZXJ2aWNlIHtcbiAgcHJpdmF0ZSBzdGF0aWMgY2FjaGU6IHsgdmFsdWU6IFBsdWdpblNldHRpbmdzOyBhdDogbnVtYmVyIH0gfCBudWxsID0gbnVsbDtcblxuICAvLyDilIDilIAgSW5kZXggYm9vdHN0cmFwIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG4gIHN0YXRpYyBhc3luYyBlbnN1cmVJbmRleChjbGllbnQ6IGFueSk6IFByb21pc2U8dm9pZD4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB7IGJvZHk6IGV4aXN0cyB9ID0gYXdhaXQgY2xpZW50LmluZGljZXMuZXhpc3RzKHsgaW5kZXg6IFNFVFRJTkdTX0lOREVYIH0pO1xuICAgICAgaWYgKCFleGlzdHMpIHtcbiAgICAgICAgYXdhaXQgY2xpZW50LmluZGljZXMuY3JlYXRlKHsgaW5kZXg6IFNFVFRJTkdTX0lOREVYLCBib2R5OiBzZXR0aW5nc01hcHBpbmdzIH0pO1xuICAgICAgfVxuICAgIH0gY2F0Y2ggKGU6IGFueSkge1xuICAgICAgY29uc3QgdHlwZSA9IGU/LmJvZHk/LmVycm9yPy50eXBlIHx8IGU/Lm1ldGE/LmJvZHk/LmVycm9yPy50eXBlO1xuICAgICAgaWYgKHR5cGUgIT09ICdyZXNvdXJjZV9hbHJlYWR5X2V4aXN0c19leGNlcHRpb24nKSB7XG4gICAgICAgIC8vIE5vbi1mYXRhbDogZ2V0U2V0dGluZ3MgZmFsbHMgYmFjayB0byBkZWZhdWx0cyBpZiB0aGUgaW5kZXggaXMgbWlzc2luZy5cbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICAvLyDilIDilIAgUmVhZCAvIHdyaXRlIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG4gIC8qKiBGZXRjaCB0aGUgZWZmZWN0aXZlIHNldHRpbmdzLCBtZXJnZWQgb3ZlciBkZWZhdWx0cy4gKi9cbiAgc3RhdGljIGFzeW5jIGdldFNldHRpbmdzKGNsaWVudDogYW55LCB1c2VDYWNoZSA9IHRydWUpOiBQcm9taXNlPFBsdWdpblNldHRpbmdzPiB7XG4gICAgaWYgKHVzZUNhY2hlICYmIFNldHRpbmdzU2VydmljZS5jYWNoZSAmJiBEYXRlLm5vdygpIC0gU2V0dGluZ3NTZXJ2aWNlLmNhY2hlLmF0IDwgQ0FDSEVfVFRMX01TKSB7XG4gICAgICByZXR1cm4gU2V0dGluZ3NTZXJ2aWNlLmNhY2hlLnZhbHVlO1xuICAgIH1cblxuICAgIGxldCBzdG9yZWQ6IFBhcnRpYWw8UGx1Z2luU2V0dGluZ3M+ID0ge307XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHsgYm9keSB9ID0gYXdhaXQgY2xpZW50LmdldCh7IGluZGV4OiBTRVRUSU5HU19JTkRFWCwgaWQ6IFNFVFRJTkdTX0RPQ19JRCB9KTtcbiAgICAgIHN0b3JlZCA9IGJvZHkuX3NvdXJjZSB8fCB7fTtcbiAgICB9IGNhdGNoIChlOiBhbnkpIHtcbiAgICAgIGNvbnN0IHN0YXR1cyA9IGU/LnN0YXR1c0NvZGUgPz8gZT8ubWV0YT8uc3RhdHVzQ29kZTtcbiAgICAgIC8vIDQwNCAobm8gZG9jdW1lbnQpIGFuZCA0MDQtb24tbWlzc2luZy1pbmRleCBib3RoIG1lYW4gXCJ1c2UgZGVmYXVsdHNcIi5cbiAgICAgIGlmIChzdGF0dXMgIT09IDQwNCkgdGhyb3cgZTtcbiAgICB9XG5cbiAgICBjb25zdCBtZXJnZWQgPSBTZXR0aW5nc1NlcnZpY2UubWVyZ2Uoc3RvcmVkKTtcbiAgICBTZXR0aW5nc1NlcnZpY2UuY2FjaGUgPSB7IHZhbHVlOiBtZXJnZWQsIGF0OiBEYXRlLm5vdygpIH07XG4gICAgcmV0dXJuIG1lcmdlZDtcbiAgfVxuXG4gIC8qKiBNZXJnZSBhIHN0b3JlZCAocG9zc2libHkgcGFydGlhbCBvciBvbGRlci1zY2hlbWEpIGRvY3VtZW50IG92ZXIgdGhlIGRlZmF1bHRzLiAqL1xuICBwcml2YXRlIHN0YXRpYyBtZXJnZShzdG9yZWQ6IFBhcnRpYWw8UGx1Z2luU2V0dGluZ3M+KTogUGx1Z2luU2V0dGluZ3Mge1xuICAgIHJldHVybiB7XG4gICAgICAuLi5ERUZBVUxUX1NFVFRJTkdTLFxuICAgICAgLi4uc3RvcmVkLFxuICAgICAgY2FzZV9pZDogeyAuLi5ERUZBVUxUX1NFVFRJTkdTLmNhc2VfaWQsIC4uLihzdG9yZWQuY2FzZV9pZCB8fCB7fSkgfSxcbiAgICAgIHRpbWVzdGFtcDogeyAuLi5ERUZBVUxUX1NFVFRJTkdTLnRpbWVzdGFtcCwgLi4uKHN0b3JlZC50aW1lc3RhbXAgfHwge30pIH0sXG4gICAgICBub3RpZmljYXRpb25zOiB7XG4gICAgICAgIC4uLkRFRkFVTFRfU0VUVElOR1Mubm90aWZpY2F0aW9ucyxcbiAgICAgICAgLi4uKHN0b3JlZC5ub3RpZmljYXRpb25zIHx8IHt9KSxcbiAgICAgICAgY2hhbm5lbHM6IHN0b3JlZC5ub3RpZmljYXRpb25zPy5jaGFubmVscyB8fCBbXSxcbiAgICAgIH0sXG4gICAgICBlc2NhbGF0aW9uOiB7XG4gICAgICAgIC4uLkRFRkFVTFRfU0VUVElOR1MuZXNjYWxhdGlvbixcbiAgICAgICAgLi4uKHN0b3JlZC5lc2NhbGF0aW9uIHx8IHt9KSxcbiAgICAgICAgcG9saWNpZXM6IHN0b3JlZC5lc2NhbGF0aW9uPy5wb2xpY2llcyB8fCBbXSxcbiAgICAgIH0sXG4gICAgICBzbXRwOiB7IC4uLkRFRkFVTFRfU0VUVElOR1Muc210cCwgLi4uKHN0b3JlZC5zbXRwIHx8IHt9KSB9LFxuICAgICAgYXBpX2tleXM6IHN0b3JlZC5hcGlfa2V5cyB8fCBbXSxcbiAgICB9O1xuICB9XG5cbiAgLyoqIFBlcnNpc3QgYSBwYXJ0aWFsIHNldHRpbmdzIHVwZGF0ZSBhbmQgcmV0dXJuIHRoZSBtZXJnZWQgcmVzdWx0LiAqL1xuICBzdGF0aWMgYXN5bmMgc2F2ZVNldHRpbmdzKFxuICAgIGNsaWVudDogYW55LFxuICAgIHVwZGF0ZXM6IFBhcnRpYWw8UGx1Z2luU2V0dGluZ3M+LFxuICAgIHVzZXI6IHN0cmluZyxcbiAgKTogUHJvbWlzZTxQbHVnaW5TZXR0aW5ncz4ge1xuICAgIGF3YWl0IFNldHRpbmdzU2VydmljZS5lbnN1cmVJbmRleChjbGllbnQpO1xuICAgIGNvbnN0IGV4aXN0aW5nID0gYXdhaXQgU2V0dGluZ3NTZXJ2aWNlLmdldFNldHRpbmdzKGNsaWVudCwgZmFsc2UpO1xuXG4gICAgY29uc3QgbWVyZ2VkOiBQbHVnaW5TZXR0aW5ncyA9IHtcbiAgICAgIC4uLmV4aXN0aW5nLFxuICAgICAgLi4udXBkYXRlcyxcbiAgICAgIC8vIE5lc3RlZCBzZWN0aW9ucyBhcmUgcmVwbGFjZWQgd2hvbGVzYWxlIHdoZW4gc3VwcGxpZWQsIHNvIHRoYXQgcmVtb3ZpbmdcbiAgICAgIC8vIGEgY2hhbm5lbCBvciBwb2xpY3kgYWN0dWFsbHkgcmVtb3ZlcyBpdC5cbiAgICAgIGNhc2VfaWQ6IHsgLi4uZXhpc3RpbmcuY2FzZV9pZCwgLi4uKHVwZGF0ZXMuY2FzZV9pZCB8fCB7fSkgfSxcbiAgICAgIHRpbWVzdGFtcDogeyAuLi5leGlzdGluZy50aW1lc3RhbXAsIC4uLih1cGRhdGVzLnRpbWVzdGFtcCB8fCB7fSkgfSxcbiAgICAgIG5vdGlmaWNhdGlvbnM6IHVwZGF0ZXMubm90aWZpY2F0aW9uc1xuICAgICAgICA/IHtcbiAgICAgICAgICAgIC4uLmV4aXN0aW5nLm5vdGlmaWNhdGlvbnMsXG4gICAgICAgICAgICAuLi51cGRhdGVzLm5vdGlmaWNhdGlvbnMsXG4gICAgICAgICAgICAvLyBSZS1hdHRhY2ggYW55IHNlY3JldCB0aGUgYnJvd3NlciBlY2hvZWQgYmFjayBhcyBhIHBsYWNlaG9sZGVyLlxuICAgICAgICAgICAgY2hhbm5lbHM6ICh1cGRhdGVzLm5vdGlmaWNhdGlvbnMuY2hhbm5lbHMgfHwgW10pLm1hcCgoY2hhbm5lbCkgPT5cbiAgICAgICAgICAgICAgU2V0dGluZ3NTZXJ2aWNlLm1lcmdlQ2hhbm5lbFNlY3JldHMoXG4gICAgICAgICAgICAgICAgY2hhbm5lbCxcbiAgICAgICAgICAgICAgICBleGlzdGluZy5ub3RpZmljYXRpb25zLmNoYW5uZWxzLmZpbmQoKGMpID0+IGMuaWQgPT09IGNoYW5uZWwuaWQpLFxuICAgICAgICAgICAgICApLFxuICAgICAgICAgICAgKSxcbiAgICAgICAgICB9XG4gICAgICAgIDogZXhpc3Rpbmcubm90aWZpY2F0aW9ucyxcbiAgICAgIGVzY2FsYXRpb246IHVwZGF0ZXMuZXNjYWxhdGlvblxuICAgICAgICA/IHsgLi4uZXhpc3RpbmcuZXNjYWxhdGlvbiwgLi4udXBkYXRlcy5lc2NhbGF0aW9uIH1cbiAgICAgICAgOiBleGlzdGluZy5lc2NhbGF0aW9uLFxuICAgICAgc210cDogdXBkYXRlcy5zbXRwXG4gICAgICAgID8ge1xuICAgICAgICAgICAgLi4uZXhpc3Rpbmcuc210cCxcbiAgICAgICAgICAgIC4uLnVwZGF0ZXMuc210cCxcbiAgICAgICAgICAgIC8vIFRoZSBicm93c2VyIGVjaG9lcyB0aGUgcGxhY2Vob2xkZXIgYmFjayB3aGVuIHRoZSBwYXNzd29yZCBpcyB1bmNoYW5nZWQuXG4gICAgICAgICAgICBwYXNzd29yZDpcbiAgICAgICAgICAgICAgdXBkYXRlcy5zbXRwLnBhc3N3b3JkID09PSBTRUNSRVRfUExBQ0VIT0xERVJcbiAgICAgICAgICAgICAgICA/IGV4aXN0aW5nLnNtdHAucGFzc3dvcmRcbiAgICAgICAgICAgICAgICA6IHVwZGF0ZXMuc210cC5wYXNzd29yZCxcbiAgICAgICAgICB9XG4gICAgICAgIDogZXhpc3Rpbmcuc210cCxcbiAgICAgIC8vIEFQSSBrZXlzIGFyZSBuZXZlciB3cml0dGVuIHRocm91Z2ggdGhpcyBwYXRoLiBVc2UgdGhlIGtleSBoZWxwZXJzLlxuICAgICAgYXBpX2tleXM6IGV4aXN0aW5nLmFwaV9rZXlzLFxuICAgICAgdXBkYXRlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgdXBkYXRlZF9ieTogdXNlcixcbiAgICB9O1xuXG4gICAgYXdhaXQgY2xpZW50LmluZGV4KHtcbiAgICAgIGluZGV4OiBTRVRUSU5HU19JTkRFWCxcbiAgICAgIGlkOiBTRVRUSU5HU19ET0NfSUQsXG4gICAgICBib2R5OiBtZXJnZWQsXG4gICAgICByZWZyZXNoOiAnd2FpdF9mb3InLFxuICAgIH0pO1xuXG4gICAgU2V0dGluZ3NTZXJ2aWNlLmNhY2hlID0geyB2YWx1ZTogbWVyZ2VkLCBhdDogRGF0ZS5ub3coKSB9O1xuICAgIHJldHVybiBtZXJnZWQ7XG4gIH1cblxuICAvKiogU3RyaXAgc2VjcmV0cyBzbyB0aGUgc2V0dGluZ3MgY2FuIGJlIHNlbnQgdG8gdGhlIGJyb3dzZXIuICovXG4gIHN0YXRpYyB0b1B1YmxpYyhzZXR0aW5nczogUGx1Z2luU2V0dGluZ3MpOiBQbHVnaW5TZXR0aW5nc1B1YmxpYyB7XG4gICAgcmV0dXJuIHtcbiAgICAgIC4uLnNldHRpbmdzLFxuICAgICAgYXBpX2tleXM6IHNldHRpbmdzLmFwaV9rZXlzLm1hcChTZXR0aW5nc1NlcnZpY2Uua2V5VG9QdWJsaWMpLFxuICAgICAgbm90aWZpY2F0aW9uczoge1xuICAgICAgICAuLi5zZXR0aW5ncy5ub3RpZmljYXRpb25zLFxuICAgICAgICBjaGFubmVsczogc2V0dGluZ3Mubm90aWZpY2F0aW9ucy5jaGFubmVscy5tYXAoU2V0dGluZ3NTZXJ2aWNlLmNoYW5uZWxUb1B1YmxpYyksXG4gICAgICB9LFxuICAgICAgc210cDoge1xuICAgICAgICAuLi5zZXR0aW5ncy5zbXRwLFxuICAgICAgICBwYXNzd29yZDogc2V0dGluZ3Muc210cC5wYXNzd29yZCA/IFNFQ1JFVF9QTEFDRUhPTERFUiA6ICcnLFxuICAgICAgfSxcbiAgICB9O1xuICB9XG5cbiAgLyoqXG4gICAqIFJlcGxhY2UgYSBjaGFubmVsJ3Mgc3RvcmVkIGNyZWRlbnRpYWxzIHdpdGggYSBwbGFjZWhvbGRlci4gVGhlIGJyb3dzZXIgZ2V0c1xuICAgKiBlbm91Z2ggdG8gcmVuZGVyIHRoZSBmb3JtICh3aGljaCBhdXRoIG1vZGUsIHdoaWNoIGhlYWRlciBuYW1lKSBidXQgbmV2ZXIgdGhlXG4gICAqIHNlY3JldCBpdHNlbGY7IHNhdmluZyB0aGUgcGxhY2Vob2xkZXIgYmFjayBwcmVzZXJ2ZXMgd2hhdCBpcyBzdG9yZWQuXG4gICAqL1xuICBwcml2YXRlIHN0YXRpYyBjaGFubmVsVG9QdWJsaWMoY2hhbm5lbDogTm90aWZpY2F0aW9uQ2hhbm5lbCk6IE5vdGlmaWNhdGlvbkNoYW5uZWwge1xuICAgIGlmICghY2hhbm5lbC5hdXRoKSByZXR1cm4gY2hhbm5lbDtcbiAgICBjb25zdCBhdXRoID0geyAuLi5jaGFubmVsLmF1dGggfTtcbiAgICBpZiAoYXV0aC50b2tlbikgYXV0aC50b2tlbiA9IFNFQ1JFVF9QTEFDRUhPTERFUjtcbiAgICBpZiAoYXV0aC5wYXNzd29yZCkgYXV0aC5wYXNzd29yZCA9IFNFQ1JFVF9QTEFDRUhPTERFUjtcbiAgICBpZiAoYXV0aC5oZWFkZXJfdmFsdWUpIGF1dGguaGVhZGVyX3ZhbHVlID0gU0VDUkVUX1BMQUNFSE9MREVSO1xuICAgIHJldHVybiB7IC4uLmNoYW5uZWwsIGF1dGggfTtcbiAgfVxuXG4gIC8qKlxuICAgKiBNZXJnZSBhbiBpbmNvbWluZyBjaGFubmVsIG92ZXIgaXRzIHN0b3JlZCBjb3VudGVycGFydCwgcmVzdG9yaW5nIGFueSBzZWNyZXRcbiAgICogdGhlIGNsaWVudCBzZW50IGJhY2sgYXMgdGhlIHBsYWNlaG9sZGVyLlxuICAgKi9cbiAgcHJpdmF0ZSBzdGF0aWMgbWVyZ2VDaGFubmVsU2VjcmV0cyhcbiAgICBpbmNvbWluZzogTm90aWZpY2F0aW9uQ2hhbm5lbCxcbiAgICBzdG9yZWQ/OiBOb3RpZmljYXRpb25DaGFubmVsLFxuICApOiBOb3RpZmljYXRpb25DaGFubmVsIHtcbiAgICBpZiAoIWluY29taW5nLmF1dGgpIHJldHVybiBpbmNvbWluZztcbiAgICBjb25zdCBhdXRoID0geyAuLi5pbmNvbWluZy5hdXRoIH07XG4gICAgY29uc3QgcHJldmlvdXMgPSBzdG9yZWQ/LmF1dGg7XG5cbiAgICBpZiAoYXV0aC50b2tlbiA9PT0gU0VDUkVUX1BMQUNFSE9MREVSKSBhdXRoLnRva2VuID0gcHJldmlvdXM/LnRva2VuO1xuICAgIGlmIChhdXRoLnBhc3N3b3JkID09PSBTRUNSRVRfUExBQ0VIT0xERVIpIGF1dGgucGFzc3dvcmQgPSBwcmV2aW91cz8ucGFzc3dvcmQ7XG4gICAgaWYgKGF1dGguaGVhZGVyX3ZhbHVlID09PSBTRUNSRVRfUExBQ0VIT0xERVIpIGF1dGguaGVhZGVyX3ZhbHVlID0gcHJldmlvdXM/LmhlYWRlcl92YWx1ZTtcblxuICAgIHJldHVybiB7IC4uLmluY29taW5nLCBhdXRoIH07XG4gIH1cblxuICAvKipcbiAgICogUmVzb2x2ZSBhIGNoYW5uZWwgZm9yIGFuIG91dGJvdW5kIHNlbmQ6IGlmIHRoZSBjYWxsZXIgcGFzc2VkIHBsYWNlaG9sZGVyc1xuICAgKiAoZS5nLiB0aGUgVGVzdCBidXR0b24gb24gYW4gdW5zYXZlZCBlZGl0KSwgc3dhcCBpbiB0aGUgc3RvcmVkIHNlY3JldHMuXG4gICAqL1xuICBzdGF0aWMgYXN5bmMgcmVzb2x2ZUNoYW5uZWxTZWNyZXRzKFxuICAgIGNsaWVudDogYW55LFxuICAgIGNoYW5uZWw6IE5vdGlmaWNhdGlvbkNoYW5uZWwsXG4gICk6IFByb21pc2U8Tm90aWZpY2F0aW9uQ2hhbm5lbD4ge1xuICAgIGNvbnN0IHNldHRpbmdzID0gYXdhaXQgU2V0dGluZ3NTZXJ2aWNlLmdldFNldHRpbmdzKGNsaWVudCk7XG4gICAgY29uc3Qgc3RvcmVkID0gc2V0dGluZ3Mubm90aWZpY2F0aW9ucy5jaGFubmVscy5maW5kKChjKSA9PiBjLmlkID09PSBjaGFubmVsLmlkKTtcbiAgICByZXR1cm4gU2V0dGluZ3NTZXJ2aWNlLm1lcmdlQ2hhbm5lbFNlY3JldHMoY2hhbm5lbCwgc3RvcmVkKTtcbiAgfVxuXG4gIHByaXZhdGUgc3RhdGljIGtleVRvUHVibGljKGtleTogQXBpS2V5KTogQXBpS2V5UHVibGljIHtcbiAgICBjb25zdCB7IGhhc2gsIC4uLnJlc3QgfSA9IGtleTtcbiAgICByZXR1cm4gcmVzdDtcbiAgfVxuXG4gIC8vIOKUgOKUgCBDYXNlIElEIGZvcm1hdHRpbmcg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbiAgLyoqXG4gICAqIFJlbmRlciBhIGNhc2UgSUQgZnJvbSB0aGUgY29uZmlndXJlZCBmb3JtYXQuXG4gICAqIGUuZy4geyBwcmVmaXg6ICdJTkMnLCBzZXBhcmF0b3I6ICctJywgaW5jbHVkZV95ZWFyOiB0cnVlLCBwYWRkaW5nOiA1IH1cbiAgICogICAgICB3aXRoIGNvdW50ZXIgNDIg4oaSIFwiSU5DLTIwMjYtMDAwNDJcIlxuICAgKi9cbiAgc3RhdGljIGZvcm1hdENhc2VJZChzZXR0aW5nczogUGx1Z2luU2V0dGluZ3MsIGNvdW50ZXI6IG51bWJlciwgZGF0ZSA9IG5ldyBEYXRlKCkpOiBzdHJpbmcge1xuICAgIGNvbnN0IHsgcHJlZml4LCBzZXBhcmF0b3IsIGluY2x1ZGVfeWVhciwgcGFkZGluZyB9ID0gc2V0dGluZ3MuY2FzZV9pZDtcbiAgICBjb25zdCBzZXAgPSBzZXBhcmF0b3IgPz8gJy0nO1xuICAgIGNvbnN0IHNlZ21lbnRzOiBzdHJpbmdbXSA9IFtdO1xuXG4gICAgaWYgKHByZWZpeCkgc2VnbWVudHMucHVzaChwcmVmaXgpO1xuICAgIGlmIChpbmNsdWRlX3llYXIpIHNlZ21lbnRzLnB1c2goU3RyaW5nKGRhdGUuZ2V0RnVsbFllYXIoKSkpO1xuICAgIHNlZ21lbnRzLnB1c2goU3RyaW5nKGNvdW50ZXIpLnBhZFN0YXJ0KE1hdGgubWF4KDEsIHBhZGRpbmcgfHwgMSksICcwJykpO1xuXG4gICAgcmV0dXJuIHNlZ21lbnRzLmpvaW4oc2VwKTtcbiAgfVxuXG4gIC8vIOKUgOKUgCBBUEkga2V5cyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuICBzdGF0aWMgaGFzaEtleShyYXdLZXk6IHN0cmluZyk6IHN0cmluZyB7XG4gICAgcmV0dXJuIGNyZWF0ZUhhc2goJ3NoYTI1NicpLnVwZGF0ZShyYXdLZXkpLmRpZ2VzdCgnaGV4Jyk7XG4gIH1cblxuICAvKipcbiAgICogQ3JlYXRlIGFuIEFQSSBrZXkuIFJldHVybnMgdGhlIHJlY29yZCBwbHVzIHRoZSByYXcgc2VjcmV0LCB3aGljaCBpcyBzaG93blxuICAgKiB0byB0aGUgdXNlciBleGFjdGx5IG9uY2UgYW5kIG5ldmVyIHN0b3JlZCBpbiBwbGFpbnRleHQuXG4gICAqL1xuICBzdGF0aWMgYXN5bmMgY3JlYXRlQXBpS2V5KFxuICAgIGNsaWVudDogYW55LFxuICAgIHBhcmFtczogeyBuYW1lOiBzdHJpbmc7IHNjb3BlczogQXBpS2V5U2NvcGVbXTsgZXhwaXJlc19hdD86IHN0cmluZyB8IG51bGwgfSxcbiAgICB1c2VyOiBzdHJpbmcsXG4gICk6IFByb21pc2U8eyBrZXk6IEFwaUtleVB1YmxpYzsgc2VjcmV0OiBzdHJpbmcgfT4ge1xuICAgIGF3YWl0IFNldHRpbmdzU2VydmljZS5lbnN1cmVJbmRleChjbGllbnQpO1xuICAgIGNvbnN0IHNldHRpbmdzID0gYXdhaXQgU2V0dGluZ3NTZXJ2aWNlLmdldFNldHRpbmdzKGNsaWVudCwgZmFsc2UpO1xuXG4gICAgY29uc3QgaWQgPSByYW5kb21CeXRlcyg4KS50b1N0cmluZygnaGV4Jyk7XG4gICAgY29uc3Qgc2VjcmV0Qm9keSA9IHJhbmRvbUJ5dGVzKDI0KS50b1N0cmluZygnYmFzZTY0dXJsJyk7XG4gICAgY29uc3Qgc2VjcmV0ID0gYCR7QVBJX0tFWV9UT0tFTl9QUkVGSVh9XyR7aWR9XyR7c2VjcmV0Qm9keX1gO1xuXG4gICAgY29uc3QgcmVjb3JkOiBBcGlLZXkgPSB7XG4gICAgICBpZCxcbiAgICAgIG5hbWU6IHBhcmFtcy5uYW1lLFxuICAgICAga2V5X3ByZWZpeDogYCR7QVBJX0tFWV9UT0tFTl9QUkVGSVh9XyR7aWR9YCxcbiAgICAgIGhhc2g6IFNldHRpbmdzU2VydmljZS5oYXNoS2V5KHNlY3JldCksXG4gICAgICBzY29wZXM6IHBhcmFtcy5zY29wZXMubGVuZ3RoID8gcGFyYW1zLnNjb3BlcyA6IFsncmVhZCddLFxuICAgICAgZW5hYmxlZDogdHJ1ZSxcbiAgICAgIGNyZWF0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgIGNyZWF0ZWRfYnk6IHVzZXIsXG4gICAgICBsYXN0X3VzZWRfYXQ6IG51bGwsXG4gICAgICBleHBpcmVzX2F0OiBwYXJhbXMuZXhwaXJlc19hdCB8fCBudWxsLFxuICAgIH07XG5cbiAgICBhd2FpdCBTZXR0aW5nc1NlcnZpY2Uud3JpdGVLZXlzKGNsaWVudCwgWy4uLnNldHRpbmdzLmFwaV9rZXlzLCByZWNvcmRdLCBzZXR0aW5ncyk7XG4gICAgcmV0dXJuIHsga2V5OiBTZXR0aW5nc1NlcnZpY2Uua2V5VG9QdWJsaWMocmVjb3JkKSwgc2VjcmV0IH07XG4gIH1cblxuICBzdGF0aWMgYXN5bmMgZGVsZXRlQXBpS2V5KGNsaWVudDogYW55LCBrZXlJZDogc3RyaW5nKTogUHJvbWlzZTxib29sZWFuPiB7XG4gICAgY29uc3Qgc2V0dGluZ3MgPSBhd2FpdCBTZXR0aW5nc1NlcnZpY2UuZ2V0U2V0dGluZ3MoY2xpZW50LCBmYWxzZSk7XG4gICAgY29uc3QgcmVtYWluaW5nID0gc2V0dGluZ3MuYXBpX2tleXMuZmlsdGVyKChrKSA9PiBrLmlkICE9PSBrZXlJZCk7XG4gICAgaWYgKHJlbWFpbmluZy5sZW5ndGggPT09IHNldHRpbmdzLmFwaV9rZXlzLmxlbmd0aCkgcmV0dXJuIGZhbHNlO1xuICAgIGF3YWl0IFNldHRpbmdzU2VydmljZS53cml0ZUtleXMoY2xpZW50LCByZW1haW5pbmcsIHNldHRpbmdzKTtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuXG4gIHN0YXRpYyBhc3luYyBzZXRBcGlLZXlFbmFibGVkKGNsaWVudDogYW55LCBrZXlJZDogc3RyaW5nLCBlbmFibGVkOiBib29sZWFuKTogUHJvbWlzZTxib29sZWFuPiB7XG4gICAgY29uc3Qgc2V0dGluZ3MgPSBhd2FpdCBTZXR0aW5nc1NlcnZpY2UuZ2V0U2V0dGluZ3MoY2xpZW50LCBmYWxzZSk7XG4gICAgbGV0IGZvdW5kID0gZmFsc2U7XG4gICAgY29uc3QgdXBkYXRlZCA9IHNldHRpbmdzLmFwaV9rZXlzLm1hcCgoaykgPT4ge1xuICAgICAgaWYgKGsuaWQgIT09IGtleUlkKSByZXR1cm4gaztcbiAgICAgIGZvdW5kID0gdHJ1ZTtcbiAgICAgIHJldHVybiB7IC4uLmssIGVuYWJsZWQgfTtcbiAgICB9KTtcbiAgICBpZiAoIWZvdW5kKSByZXR1cm4gZmFsc2U7XG4gICAgYXdhaXQgU2V0dGluZ3NTZXJ2aWNlLndyaXRlS2V5cyhjbGllbnQsIHVwZGF0ZWQsIHNldHRpbmdzKTtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuXG4gIC8qKlxuICAgKiBMb29rIHVwIGFuIEFQSSBrZXkgYnkgaXRzIHJhdyBzZWNyZXQuIFJldHVybnMgbnVsbCB3aGVuIHRoZSBrZXkgaXMgdW5rbm93bixcbiAgICogZGlzYWJsZWQgb3IgZXhwaXJlZC4gQ29tcGFyaXNvbiBpcyBvdmVyIHRoZSBTSEEtMjU2IGhhc2guXG4gICAqL1xuICBzdGF0aWMgYXN5bmMgdmVyaWZ5QXBpS2V5KGNsaWVudDogYW55LCBzZWNyZXQ6IHN0cmluZyk6IFByb21pc2U8QXBpS2V5IHwgbnVsbD4ge1xuICAgIGlmICghc2VjcmV0KSByZXR1cm4gbnVsbDtcbiAgICBjb25zdCBzZXR0aW5ncyA9IGF3YWl0IFNldHRpbmdzU2VydmljZS5nZXRTZXR0aW5ncyhjbGllbnQpO1xuICAgIGNvbnN0IGhhc2ggPSBTZXR0aW5nc1NlcnZpY2UuaGFzaEtleShzZWNyZXQpO1xuICAgIGNvbnN0IG1hdGNoID0gc2V0dGluZ3MuYXBpX2tleXMuZmluZCgoaykgPT4gay5oYXNoID09PSBoYXNoKTtcbiAgICBpZiAoIW1hdGNoIHx8ICFtYXRjaC5lbmFibGVkKSByZXR1cm4gbnVsbDtcbiAgICBpZiAobWF0Y2guZXhwaXJlc19hdCAmJiBuZXcgRGF0ZShtYXRjaC5leHBpcmVzX2F0KS5nZXRUaW1lKCkgPCBEYXRlLm5vdygpKSByZXR1cm4gbnVsbDtcbiAgICByZXR1cm4gbWF0Y2g7XG4gIH1cblxuICAvKiogUmVjb3JkIGtleSB1c2FnZS4gQmVzdC1lZmZvcnQ6IG5ldmVyIGJsb2NrcyB0aGUgcmVxdWVzdC4gKi9cbiAgc3RhdGljIGFzeW5jIHRvdWNoQXBpS2V5KGNsaWVudDogYW55LCBrZXlJZDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHNldHRpbmdzID0gYXdhaXQgU2V0dGluZ3NTZXJ2aWNlLmdldFNldHRpbmdzKGNsaWVudCwgZmFsc2UpO1xuICAgICAgY29uc3QgdXBkYXRlZCA9IHNldHRpbmdzLmFwaV9rZXlzLm1hcCgoaykgPT5cbiAgICAgICAgay5pZCA9PT0ga2V5SWQgPyB7IC4uLmssIGxhc3RfdXNlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpIH0gOiBrLFxuICAgICAgKTtcbiAgICAgIGF3YWl0IFNldHRpbmdzU2VydmljZS53cml0ZUtleXMoY2xpZW50LCB1cGRhdGVkLCBzZXR0aW5ncyk7XG4gICAgfSBjYXRjaCAoX2UpIHtcbiAgICAgIC8qIHVzYWdlIHRyYWNraW5nIG11c3QgbmV2ZXIgZmFpbCBhIHJlcXVlc3QgKi9cbiAgICB9XG4gIH1cblxuICBwcml2YXRlIHN0YXRpYyBhc3luYyB3cml0ZUtleXMoY2xpZW50OiBhbnksIGtleXM6IEFwaUtleVtdLCBzZXR0aW5nczogUGx1Z2luU2V0dGluZ3MpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBjb25zdCBtZXJnZWQgPSB7IC4uLnNldHRpbmdzLCBhcGlfa2V5czoga2V5cywgdXBkYXRlZF9hdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpIH07XG4gICAgYXdhaXQgY2xpZW50LmluZGV4KHtcbiAgICAgIGluZGV4OiBTRVRUSU5HU19JTkRFWCxcbiAgICAgIGlkOiBTRVRUSU5HU19ET0NfSUQsXG4gICAgICBib2R5OiBtZXJnZWQsXG4gICAgICByZWZyZXNoOiAnd2FpdF9mb3InLFxuICAgIH0pO1xuICAgIFNldHRpbmdzU2VydmljZS5jYWNoZSA9IHsgdmFsdWU6IG1lcmdlZCwgYXQ6IERhdGUubm93KCkgfTtcbiAgfVxuXG4gIC8qKiBEcm9wIHRoZSBjYWNoZTogdXNlZCBhZnRlciBvdXQtb2YtYmFuZCB3cml0ZXMuICovXG4gIHN0YXRpYyBpbnZhbGlkYXRlQ2FjaGUoKTogdm9pZCB7XG4gICAgU2V0dGluZ3NTZXJ2aWNlLmNhY2hlID0gbnVsbDtcbiAgfVxufVxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFVQSxJQUFBQSxPQUFBLEdBQUFDLE9BQUE7QUFDQSxJQUFBQyxNQUFBLEdBQUFELE9BQUE7QUFTQSxJQUFBRSxVQUFBLEdBQUFGLE9BQUE7QUFBaUUsU0FBQUcsZ0JBQUFDLENBQUEsRUFBQUMsQ0FBQSxFQUFBQyxDQUFBLFlBQUFELENBQUEsR0FBQUUsY0FBQSxDQUFBRixDQUFBLE1BQUFELENBQUEsR0FBQUksTUFBQSxDQUFBQyxjQUFBLENBQUFMLENBQUEsRUFBQUMsQ0FBQSxJQUFBSyxLQUFBLEVBQUFKLENBQUEsRUFBQUssVUFBQSxNQUFBQyxZQUFBLE1BQUFDLFFBQUEsVUFBQVQsQ0FBQSxDQUFBQyxDQUFBLElBQUFDLENBQUEsRUFBQUYsQ0FBQTtBQUFBLFNBQUFHLGVBQUFELENBQUEsUUFBQVEsQ0FBQSxHQUFBQyxZQUFBLENBQUFULENBQUEsdUNBQUFRLENBQUEsR0FBQUEsQ0FBQSxHQUFBQSxDQUFBO0FBQUEsU0FBQUMsYUFBQVQsQ0FBQSxFQUFBRCxDQUFBLDJCQUFBQyxDQUFBLEtBQUFBLENBQUEsU0FBQUEsQ0FBQSxNQUFBRixDQUFBLEdBQUFFLENBQUEsQ0FBQVUsTUFBQSxDQUFBQyxXQUFBLGtCQUFBYixDQUFBLFFBQUFVLENBQUEsR0FBQVYsQ0FBQSxDQUFBYyxJQUFBLENBQUFaLENBQUEsRUFBQUQsQ0FBQSx1Q0FBQVMsQ0FBQSxTQUFBQSxDQUFBLFlBQUFLLFNBQUEseUVBQUFkLENBQUEsR0FBQWUsTUFBQSxHQUFBQyxNQUFBLEVBQUFmLENBQUEsS0FwQmpFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQXNCQSxNQUFNZ0IsZUFBZSxHQUFHLGlCQUFpQjs7QUFFekM7QUFDQSxNQUFNQyxZQUFZLEdBQUcsTUFBTTtBQUVwQixNQUFNQyxnQkFBZ0MsR0FBQUMsT0FBQSxDQUFBRCxnQkFBQSxHQUFHO0VBQzlDRSxPQUFPLEVBQUU7SUFDUEMsTUFBTSxFQUFFQyx5QkFBYztJQUN0QkMsU0FBUyxFQUFFQyw0QkFBaUI7SUFDNUJDLFlBQVksRUFBRUMsK0JBQW9CO0lBQ2xDQyxPQUFPLEVBQUVDO0VBQ1gsQ0FBQztFQUNEQyxLQUFLLEVBQUUsTUFBTTtFQUNiQyxTQUFTLEVBQUU7SUFDVEMsS0FBSyxFQUFFLEtBQUs7SUFDWkMsWUFBWSxFQUFFLElBQUk7SUFDbEJDLFFBQVEsRUFBRTtFQUNaLENBQUM7RUFDREMsYUFBYSxFQUFFO0lBQ2JDLGNBQWMsRUFBRSxJQUFJO0lBQ3BCQyxhQUFhLEVBQUUsQ0FBQyxlQUFlLEVBQUUsZUFBZSxFQUFFLGdCQUFnQixFQUFFLGVBQWUsQ0FBQztJQUNwRkMsUUFBUSxFQUFFO0VBQ1osQ0FBQztFQUNEQyxVQUFVLEVBQUU7SUFDVkMsT0FBTyxFQUFFLEtBQUs7SUFDZEMsUUFBUSxFQUFFO0VBQ1osQ0FBQztFQUNEQyxJQUFJLEVBQUU7SUFDSkYsT0FBTyxFQUFFLEtBQUs7SUFDZEcsSUFBSSxFQUFFLEVBQUU7SUFDUkMsSUFBSSxFQUFFLEdBQUc7SUFDVEMsUUFBUSxFQUFFLFVBQVU7SUFDcEJDLFNBQVMsRUFBRSxNQUFNO0lBQ2pCQyxRQUFRLEVBQUUsRUFBRTtJQUNaQyxRQUFRLEVBQUUsRUFBRTtJQUNaQyxZQUFZLEVBQUUsRUFBRTtJQUNoQkMsU0FBUyxFQUFFLHVCQUF1QjtJQUNsQ0MsbUJBQW1CLEVBQUUsSUFBSTtJQUN6QkMsVUFBVSxFQUFFQztFQUNkLENBQUM7RUFDREMsUUFBUSxFQUFFLEVBQUU7RUFDWkMsUUFBUSxFQUFFLEVBQUU7RUFDWkMsVUFBVSxFQUFFLElBQUlDLElBQUksQ0FBQyxDQUFDLENBQUNDLFdBQVcsQ0FBQyxDQUFDO0VBQ3BDQyxVQUFVLEVBQUU7QUFDZCxDQUFDO0FBRUQsTUFBTUMsZ0JBQWdCLEdBQUc7RUFDdkJDLFFBQVEsRUFBRTtJQUFFQyxnQkFBZ0IsRUFBRSxDQUFDO0lBQUVDLGtCQUFrQixFQUFFO0VBQUUsQ0FBQztFQUN4REMsUUFBUSxFQUFFO0lBQ1I7SUFDQTtJQUNBQyxPQUFPLEVBQUUsS0FBSztJQUNkQyxVQUFVLEVBQUU7TUFDVlYsVUFBVSxFQUFFO1FBQUVXLElBQUksRUFBRTtNQUFPLENBQUM7TUFDNUJSLFVBQVUsRUFBRTtRQUFFUSxJQUFJLEVBQUU7TUFBVTtJQUNoQztFQUNGO0FBQ0YsQ0FBQztBQUVNLE1BQU1DLGVBQWUsQ0FBQztFQUczQjs7RUFFQSxhQUFhQyxXQUFXQSxDQUFDQyxNQUFXLEVBQWlCO0lBQ25ELElBQUk7TUFDRixNQUFNO1FBQUVDLElBQUksRUFBRUM7TUFBTyxDQUFDLEdBQUcsTUFBTUYsTUFBTSxDQUFDRyxPQUFPLENBQUNELE1BQU0sQ0FBQztRQUFFRSxLQUFLLEVBQUVDO01BQWUsQ0FBQyxDQUFDO01BQy9FLElBQUksQ0FBQ0gsTUFBTSxFQUFFO1FBQ1gsTUFBTUYsTUFBTSxDQUFDRyxPQUFPLENBQUNHLE1BQU0sQ0FBQztVQUFFRixLQUFLLEVBQUVDLHlCQUFjO1VBQUVKLElBQUksRUFBRVg7UUFBaUIsQ0FBQyxDQUFDO01BQ2hGO0lBQ0YsQ0FBQyxDQUFDLE9BQU83RCxDQUFNLEVBQUU7TUFBQSxJQUFBOEUsT0FBQSxFQUFBQyxPQUFBO01BQ2YsTUFBTVgsSUFBSSxHQUFHLENBQUFwRSxDQUFDLGFBQURBLENBQUMsZ0JBQUE4RSxPQUFBLEdBQUQ5RSxDQUFDLENBQUV3RSxJQUFJLGNBQUFNLE9BQUEsZ0JBQUFBLE9BQUEsR0FBUEEsT0FBQSxDQUFTRSxLQUFLLGNBQUFGLE9BQUEsdUJBQWRBLE9BQUEsQ0FBZ0JWLElBQUksTUFBSXBFLENBQUMsYUFBREEsQ0FBQyxnQkFBQStFLE9BQUEsR0FBRC9FLENBQUMsQ0FBRWlGLElBQUksY0FBQUYsT0FBQSxnQkFBQUEsT0FBQSxHQUFQQSxPQUFBLENBQVNQLElBQUksY0FBQU8sT0FBQSxnQkFBQUEsT0FBQSxHQUFiQSxPQUFBLENBQWVDLEtBQUssY0FBQUQsT0FBQSx1QkFBcEJBLE9BQUEsQ0FBc0JYLElBQUk7TUFDL0QsSUFBSUEsSUFBSSxLQUFLLG1DQUFtQyxFQUFFO1FBQ2hEO01BQUE7SUFFSjtFQUNGOztFQUVBOztFQUVBO0VBQ0EsYUFBYWMsV0FBV0EsQ0FBQ1gsTUFBVyxFQUFFWSxRQUFRLEdBQUcsSUFBSSxFQUEyQjtJQUM5RSxJQUFJQSxRQUFRLElBQUlkLGVBQWUsQ0FBQ2UsS0FBSyxJQUFJMUIsSUFBSSxDQUFDMkIsR0FBRyxDQUFDLENBQUMsR0FBR2hCLGVBQWUsQ0FBQ2UsS0FBSyxDQUFDRSxFQUFFLEdBQUduRSxZQUFZLEVBQUU7TUFDN0YsT0FBT2tELGVBQWUsQ0FBQ2UsS0FBSyxDQUFDOUUsS0FBSztJQUNwQztJQUVBLElBQUlpRixNQUErQixHQUFHLENBQUMsQ0FBQztJQUN4QyxJQUFJO01BQ0YsTUFBTTtRQUFFZjtNQUFLLENBQUMsR0FBRyxNQUFNRCxNQUFNLENBQUNpQixHQUFHLENBQUM7UUFBRWIsS0FBSyxFQUFFQyx5QkFBYztRQUFFYSxFQUFFLEVBQUV2RTtNQUFnQixDQUFDLENBQUM7TUFDakZxRSxNQUFNLEdBQUdmLElBQUksQ0FBQ2tCLE9BQU8sSUFBSSxDQUFDLENBQUM7SUFDN0IsQ0FBQyxDQUFDLE9BQU8xRixDQUFNLEVBQUU7TUFBQSxJQUFBMkYsYUFBQSxFQUFBQyxRQUFBO01BQ2YsTUFBTUMsTUFBTSxJQUFBRixhQUFBLEdBQUczRixDQUFDLGFBQURBLENBQUMsdUJBQURBLENBQUMsQ0FBRThGLFVBQVUsY0FBQUgsYUFBQSxjQUFBQSxhQUFBLEdBQUkzRixDQUFDLGFBQURBLENBQUMsZ0JBQUE0RixRQUFBLEdBQUQ1RixDQUFDLENBQUVpRixJQUFJLGNBQUFXLFFBQUEsdUJBQVBBLFFBQUEsQ0FBU0UsVUFBVTtNQUNuRDtNQUNBLElBQUlELE1BQU0sS0FBSyxHQUFHLEVBQUUsTUFBTTdGLENBQUM7SUFDN0I7SUFFQSxNQUFNK0YsTUFBTSxHQUFHMUIsZUFBZSxDQUFDMkIsS0FBSyxDQUFDVCxNQUFNLENBQUM7SUFDNUNsQixlQUFlLENBQUNlLEtBQUssR0FBRztNQUFFOUUsS0FBSyxFQUFFeUYsTUFBTTtNQUFFVCxFQUFFLEVBQUU1QixJQUFJLENBQUMyQixHQUFHLENBQUM7SUFBRSxDQUFDO0lBQ3pELE9BQU9VLE1BQU07RUFDZjs7RUFFQTtFQUNBLE9BQWVDLEtBQUtBLENBQUNULE1BQStCLEVBQWtCO0lBQUEsSUFBQVUscUJBQUEsRUFBQUMsa0JBQUE7SUFDcEUsT0FBTztNQUNMLEdBQUc5RSxnQkFBZ0I7TUFDbkIsR0FBR21FLE1BQU07TUFDVGpFLE9BQU8sRUFBRTtRQUFFLEdBQUdGLGdCQUFnQixDQUFDRSxPQUFPO1FBQUUsSUFBSWlFLE1BQU0sQ0FBQ2pFLE9BQU8sSUFBSSxDQUFDLENBQUM7TUFBRSxDQUFDO01BQ25FVSxTQUFTLEVBQUU7UUFBRSxHQUFHWixnQkFBZ0IsQ0FBQ1ksU0FBUztRQUFFLElBQUl1RCxNQUFNLENBQUN2RCxTQUFTLElBQUksQ0FBQyxDQUFDO01BQUUsQ0FBQztNQUN6RUksYUFBYSxFQUFFO1FBQ2IsR0FBR2hCLGdCQUFnQixDQUFDZ0IsYUFBYTtRQUNqQyxJQUFJbUQsTUFBTSxDQUFDbkQsYUFBYSxJQUFJLENBQUMsQ0FBQyxDQUFDO1FBQy9CRyxRQUFRLEVBQUUsRUFBQTBELHFCQUFBLEdBQUFWLE1BQU0sQ0FBQ25ELGFBQWEsY0FBQTZELHFCQUFBLHVCQUFwQkEscUJBQUEsQ0FBc0IxRCxRQUFRLEtBQUk7TUFDOUMsQ0FBQztNQUNEQyxVQUFVLEVBQUU7UUFDVixHQUFHcEIsZ0JBQWdCLENBQUNvQixVQUFVO1FBQzlCLElBQUkrQyxNQUFNLENBQUMvQyxVQUFVLElBQUksQ0FBQyxDQUFDLENBQUM7UUFDNUJFLFFBQVEsRUFBRSxFQUFBd0Qsa0JBQUEsR0FBQVgsTUFBTSxDQUFDL0MsVUFBVSxjQUFBMEQsa0JBQUEsdUJBQWpCQSxrQkFBQSxDQUFtQnhELFFBQVEsS0FBSTtNQUMzQyxDQUFDO01BQ0RDLElBQUksRUFBRTtRQUFFLEdBQUd2QixnQkFBZ0IsQ0FBQ3VCLElBQUk7UUFBRSxJQUFJNEMsTUFBTSxDQUFDNUMsSUFBSSxJQUFJLENBQUMsQ0FBQztNQUFFLENBQUM7TUFDMURhLFFBQVEsRUFBRStCLE1BQU0sQ0FBQy9CLFFBQVEsSUFBSTtJQUMvQixDQUFDO0VBQ0g7O0VBRUE7RUFDQSxhQUFhMkMsWUFBWUEsQ0FDdkI1QixNQUFXLEVBQ1g2QixPQUFnQyxFQUNoQ0MsSUFBWSxFQUNhO0lBQ3pCLE1BQU1oQyxlQUFlLENBQUNDLFdBQVcsQ0FBQ0MsTUFBTSxDQUFDO0lBQ3pDLE1BQU0rQixRQUFRLEdBQUcsTUFBTWpDLGVBQWUsQ0FBQ2EsV0FBVyxDQUFDWCxNQUFNLEVBQUUsS0FBSyxDQUFDO0lBRWpFLE1BQU13QixNQUFzQixHQUFHO01BQzdCLEdBQUdPLFFBQVE7TUFDWCxHQUFHRixPQUFPO01BQ1Y7TUFDQTtNQUNBOUUsT0FBTyxFQUFFO1FBQUUsR0FBR2dGLFFBQVEsQ0FBQ2hGLE9BQU87UUFBRSxJQUFJOEUsT0FBTyxDQUFDOUUsT0FBTyxJQUFJLENBQUMsQ0FBQztNQUFFLENBQUM7TUFDNURVLFNBQVMsRUFBRTtRQUFFLEdBQUdzRSxRQUFRLENBQUN0RSxTQUFTO1FBQUUsSUFBSW9FLE9BQU8sQ0FBQ3BFLFNBQVMsSUFBSSxDQUFDLENBQUM7TUFBRSxDQUFDO01BQ2xFSSxhQUFhLEVBQUVnRSxPQUFPLENBQUNoRSxhQUFhLEdBQ2hDO1FBQ0UsR0FBR2tFLFFBQVEsQ0FBQ2xFLGFBQWE7UUFDekIsR0FBR2dFLE9BQU8sQ0FBQ2hFLGFBQWE7UUFDeEI7UUFDQUcsUUFBUSxFQUFFLENBQUM2RCxPQUFPLENBQUNoRSxhQUFhLENBQUNHLFFBQVEsSUFBSSxFQUFFLEVBQUVnRSxHQUFHLENBQUVDLE9BQU8sSUFDM0RuQyxlQUFlLENBQUNvQyxtQkFBbUIsQ0FDakNELE9BQU8sRUFDUEYsUUFBUSxDQUFDbEUsYUFBYSxDQUFDRyxRQUFRLENBQUNtRSxJQUFJLENBQUVDLENBQUMsSUFBS0EsQ0FBQyxDQUFDbEIsRUFBRSxLQUFLZSxPQUFPLENBQUNmLEVBQUUsQ0FDakUsQ0FDRjtNQUNGLENBQUMsR0FDRGEsUUFBUSxDQUFDbEUsYUFBYTtNQUMxQkksVUFBVSxFQUFFNEQsT0FBTyxDQUFDNUQsVUFBVSxHQUMxQjtRQUFFLEdBQUc4RCxRQUFRLENBQUM5RCxVQUFVO1FBQUUsR0FBRzRELE9BQU8sQ0FBQzVEO01BQVcsQ0FBQyxHQUNqRDhELFFBQVEsQ0FBQzlELFVBQVU7TUFDdkJHLElBQUksRUFBRXlELE9BQU8sQ0FBQ3pELElBQUksR0FDZDtRQUNFLEdBQUcyRCxRQUFRLENBQUMzRCxJQUFJO1FBQ2hCLEdBQUd5RCxPQUFPLENBQUN6RCxJQUFJO1FBQ2Y7UUFDQU0sUUFBUSxFQUNObUQsT0FBTyxDQUFDekQsSUFBSSxDQUFDTSxRQUFRLEtBQUsyRCx5QkFBa0IsR0FDeENOLFFBQVEsQ0FBQzNELElBQUksQ0FBQ00sUUFBUSxHQUN0Qm1ELE9BQU8sQ0FBQ3pELElBQUksQ0FBQ007TUFDckIsQ0FBQyxHQUNEcUQsUUFBUSxDQUFDM0QsSUFBSTtNQUNqQjtNQUNBYSxRQUFRLEVBQUU4QyxRQUFRLENBQUM5QyxRQUFRO01BQzNCQyxVQUFVLEVBQUUsSUFBSUMsSUFBSSxDQUFDLENBQUMsQ0FBQ0MsV0FBVyxDQUFDLENBQUM7TUFDcENDLFVBQVUsRUFBRXlDO0lBQ2QsQ0FBQztJQUVELE1BQU05QixNQUFNLENBQUNJLEtBQUssQ0FBQztNQUNqQkEsS0FBSyxFQUFFQyx5QkFBYztNQUNyQmEsRUFBRSxFQUFFdkUsZUFBZTtNQUNuQnNELElBQUksRUFBRXVCLE1BQU07TUFDWmMsT0FBTyxFQUFFO0lBQ1gsQ0FBQyxDQUFDO0lBRUZ4QyxlQUFlLENBQUNlLEtBQUssR0FBRztNQUFFOUUsS0FBSyxFQUFFeUYsTUFBTTtNQUFFVCxFQUFFLEVBQUU1QixJQUFJLENBQUMyQixHQUFHLENBQUM7SUFBRSxDQUFDO0lBQ3pELE9BQU9VLE1BQU07RUFDZjs7RUFFQTtFQUNBLE9BQU9lLFFBQVFBLENBQUNoRCxRQUF3QixFQUF3QjtJQUM5RCxPQUFPO01BQ0wsR0FBR0EsUUFBUTtNQUNYTixRQUFRLEVBQUVNLFFBQVEsQ0FBQ04sUUFBUSxDQUFDK0MsR0FBRyxDQUFDbEMsZUFBZSxDQUFDMEMsV0FBVyxDQUFDO01BQzVEM0UsYUFBYSxFQUFFO1FBQ2IsR0FBRzBCLFFBQVEsQ0FBQzFCLGFBQWE7UUFDekJHLFFBQVEsRUFBRXVCLFFBQVEsQ0FBQzFCLGFBQWEsQ0FBQ0csUUFBUSxDQUFDZ0UsR0FBRyxDQUFDbEMsZUFBZSxDQUFDMkMsZUFBZTtNQUMvRSxDQUFDO01BQ0RyRSxJQUFJLEVBQUU7UUFDSixHQUFHbUIsUUFBUSxDQUFDbkIsSUFBSTtRQUNoQk0sUUFBUSxFQUFFYSxRQUFRLENBQUNuQixJQUFJLENBQUNNLFFBQVEsR0FBRzJELHlCQUFrQixHQUFHO01BQzFEO0lBQ0YsQ0FBQztFQUNIOztFQUVBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7RUFDRSxPQUFlSSxlQUFlQSxDQUFDUixPQUE0QixFQUF1QjtJQUNoRixJQUFJLENBQUNBLE9BQU8sQ0FBQ1MsSUFBSSxFQUFFLE9BQU9ULE9BQU87SUFDakMsTUFBTVMsSUFBSSxHQUFHO01BQUUsR0FBR1QsT0FBTyxDQUFDUztJQUFLLENBQUM7SUFDaEMsSUFBSUEsSUFBSSxDQUFDQyxLQUFLLEVBQUVELElBQUksQ0FBQ0MsS0FBSyxHQUFHTix5QkFBa0I7SUFDL0MsSUFBSUssSUFBSSxDQUFDaEUsUUFBUSxFQUFFZ0UsSUFBSSxDQUFDaEUsUUFBUSxHQUFHMkQseUJBQWtCO0lBQ3JELElBQUlLLElBQUksQ0FBQ0UsWUFBWSxFQUFFRixJQUFJLENBQUNFLFlBQVksR0FBR1AseUJBQWtCO0lBQzdELE9BQU87TUFBRSxHQUFHSixPQUFPO01BQUVTO0lBQUssQ0FBQztFQUM3Qjs7RUFFQTtBQUNGO0FBQ0E7QUFDQTtFQUNFLE9BQWVSLG1CQUFtQkEsQ0FDaENXLFFBQTZCLEVBQzdCN0IsTUFBNEIsRUFDUDtJQUNyQixJQUFJLENBQUM2QixRQUFRLENBQUNILElBQUksRUFBRSxPQUFPRyxRQUFRO0lBQ25DLE1BQU1ILElBQUksR0FBRztNQUFFLEdBQUdHLFFBQVEsQ0FBQ0g7SUFBSyxDQUFDO0lBQ2pDLE1BQU1JLFFBQVEsR0FBRzlCLE1BQU0sYUFBTkEsTUFBTSx1QkFBTkEsTUFBTSxDQUFFMEIsSUFBSTtJQUU3QixJQUFJQSxJQUFJLENBQUNDLEtBQUssS0FBS04seUJBQWtCLEVBQUVLLElBQUksQ0FBQ0MsS0FBSyxHQUFHRyxRQUFRLGFBQVJBLFFBQVEsdUJBQVJBLFFBQVEsQ0FBRUgsS0FBSztJQUNuRSxJQUFJRCxJQUFJLENBQUNoRSxRQUFRLEtBQUsyRCx5QkFBa0IsRUFBRUssSUFBSSxDQUFDaEUsUUFBUSxHQUFHb0UsUUFBUSxhQUFSQSxRQUFRLHVCQUFSQSxRQUFRLENBQUVwRSxRQUFRO0lBQzVFLElBQUlnRSxJQUFJLENBQUNFLFlBQVksS0FBS1AseUJBQWtCLEVBQUVLLElBQUksQ0FBQ0UsWUFBWSxHQUFHRSxRQUFRLGFBQVJBLFFBQVEsdUJBQVJBLFFBQVEsQ0FBRUYsWUFBWTtJQUV4RixPQUFPO01BQUUsR0FBR0MsUUFBUTtNQUFFSDtJQUFLLENBQUM7RUFDOUI7O0VBRUE7QUFDRjtBQUNBO0FBQ0E7RUFDRSxhQUFhSyxxQkFBcUJBLENBQ2hDL0MsTUFBVyxFQUNYaUMsT0FBNEIsRUFDRTtJQUM5QixNQUFNMUMsUUFBUSxHQUFHLE1BQU1PLGVBQWUsQ0FBQ2EsV0FBVyxDQUFDWCxNQUFNLENBQUM7SUFDMUQsTUFBTWdCLE1BQU0sR0FBR3pCLFFBQVEsQ0FBQzFCLGFBQWEsQ0FBQ0csUUFBUSxDQUFDbUUsSUFBSSxDQUFFQyxDQUFDLElBQUtBLENBQUMsQ0FBQ2xCLEVBQUUsS0FBS2UsT0FBTyxDQUFDZixFQUFFLENBQUM7SUFDL0UsT0FBT3BCLGVBQWUsQ0FBQ29DLG1CQUFtQixDQUFDRCxPQUFPLEVBQUVqQixNQUFNLENBQUM7RUFDN0Q7RUFFQSxPQUFld0IsV0FBV0EsQ0FBQ1EsR0FBVyxFQUFnQjtJQUNwRCxNQUFNO01BQUVDLElBQUk7TUFBRSxHQUFHQztJQUFLLENBQUMsR0FBR0YsR0FBRztJQUM3QixPQUFPRSxJQUFJO0VBQ2I7O0VBRUE7O0VBRUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtFQUNFLE9BQU9DLFlBQVlBLENBQUM1RCxRQUF3QixFQUFFNkQsT0FBZSxFQUFFQyxJQUFJLEdBQUcsSUFBSWxFLElBQUksQ0FBQyxDQUFDLEVBQVU7SUFDeEYsTUFBTTtNQUFFbkMsTUFBTTtNQUFFRSxTQUFTO01BQUVFLFlBQVk7TUFBRUU7SUFBUSxDQUFDLEdBQUdpQyxRQUFRLENBQUN4QyxPQUFPO0lBQ3JFLE1BQU11RyxHQUFHLEdBQUdwRyxTQUFTLGFBQVRBLFNBQVMsY0FBVEEsU0FBUyxHQUFJLEdBQUc7SUFDNUIsTUFBTXFHLFFBQWtCLEdBQUcsRUFBRTtJQUU3QixJQUFJdkcsTUFBTSxFQUFFdUcsUUFBUSxDQUFDQyxJQUFJLENBQUN4RyxNQUFNLENBQUM7SUFDakMsSUFBSUksWUFBWSxFQUFFbUcsUUFBUSxDQUFDQyxJQUFJLENBQUMvRyxNQUFNLENBQUM0RyxJQUFJLENBQUNJLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUMzREYsUUFBUSxDQUFDQyxJQUFJLENBQUMvRyxNQUFNLENBQUMyRyxPQUFPLENBQUMsQ0FBQ00sUUFBUSxDQUFDQyxJQUFJLENBQUNDLEdBQUcsQ0FBQyxDQUFDLEVBQUV0RyxPQUFPLElBQUksQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7SUFFdkUsT0FBT2lHLFFBQVEsQ0FBQ00sSUFBSSxDQUFDUCxHQUFHLENBQUM7RUFDM0I7O0VBRUE7O0VBRUEsT0FBT1EsT0FBT0EsQ0FBQ0MsTUFBYyxFQUFVO0lBQ3JDLE9BQU8sSUFBQUMsa0JBQVUsRUFBQyxRQUFRLENBQUMsQ0FBQ0MsTUFBTSxDQUFDRixNQUFNLENBQUMsQ0FBQ0csTUFBTSxDQUFDLEtBQUssQ0FBQztFQUMxRDs7RUFFQTtBQUNGO0FBQ0E7QUFDQTtFQUNFLGFBQWFDLFlBQVlBLENBQ3ZCbkUsTUFBVyxFQUNYb0UsTUFBMkUsRUFDM0V0QyxJQUFZLEVBQ29DO0lBQ2hELE1BQU1oQyxlQUFlLENBQUNDLFdBQVcsQ0FBQ0MsTUFBTSxDQUFDO0lBQ3pDLE1BQU1ULFFBQVEsR0FBRyxNQUFNTyxlQUFlLENBQUNhLFdBQVcsQ0FBQ1gsTUFBTSxFQUFFLEtBQUssQ0FBQztJQUVqRSxNQUFNa0IsRUFBRSxHQUFHLElBQUFtRCxtQkFBVyxFQUFDLENBQUMsQ0FBQyxDQUFDQyxRQUFRLENBQUMsS0FBSyxDQUFDO0lBQ3pDLE1BQU1DLFVBQVUsR0FBRyxJQUFBRixtQkFBVyxFQUFDLEVBQUUsQ0FBQyxDQUFDQyxRQUFRLENBQUMsV0FBVyxDQUFDO0lBQ3hELE1BQU1FLE1BQU0sR0FBSSxHQUFFQywrQkFBcUIsSUFBR3ZELEVBQUcsSUFBR3FELFVBQVcsRUFBQztJQUU1RCxNQUFNRyxNQUFjLEdBQUc7TUFDckJ4RCxFQUFFO01BQ0Z5RCxJQUFJLEVBQUVQLE1BQU0sQ0FBQ08sSUFBSTtNQUNqQkMsVUFBVSxFQUFHLEdBQUVILCtCQUFxQixJQUFHdkQsRUFBRyxFQUFDO01BQzNDK0IsSUFBSSxFQUFFbkQsZUFBZSxDQUFDZ0UsT0FBTyxDQUFDVSxNQUFNLENBQUM7TUFDckNLLE1BQU0sRUFBRVQsTUFBTSxDQUFDUyxNQUFNLENBQUNDLE1BQU0sR0FBR1YsTUFBTSxDQUFDUyxNQUFNLEdBQUcsQ0FBQyxNQUFNLENBQUM7TUFDdkQzRyxPQUFPLEVBQUUsSUFBSTtNQUNiNkcsVUFBVSxFQUFFLElBQUk1RixJQUFJLENBQUMsQ0FBQyxDQUFDQyxXQUFXLENBQUMsQ0FBQztNQUNwQzRGLFVBQVUsRUFBRWxELElBQUk7TUFDaEJtRCxZQUFZLEVBQUUsSUFBSTtNQUNsQkMsVUFBVSxFQUFFZCxNQUFNLENBQUNjLFVBQVUsSUFBSTtJQUNuQyxDQUFDO0lBRUQsTUFBTXBGLGVBQWUsQ0FBQ3FGLFNBQVMsQ0FBQ25GLE1BQU0sRUFBRSxDQUFDLEdBQUdULFFBQVEsQ0FBQ04sUUFBUSxFQUFFeUYsTUFBTSxDQUFDLEVBQUVuRixRQUFRLENBQUM7SUFDakYsT0FBTztNQUFFeUQsR0FBRyxFQUFFbEQsZUFBZSxDQUFDMEMsV0FBVyxDQUFDa0MsTUFBTSxDQUFDO01BQUVGO0lBQU8sQ0FBQztFQUM3RDtFQUVBLGFBQWFZLFlBQVlBLENBQUNwRixNQUFXLEVBQUVxRixLQUFhLEVBQW9CO0lBQ3RFLE1BQU05RixRQUFRLEdBQUcsTUFBTU8sZUFBZSxDQUFDYSxXQUFXLENBQUNYLE1BQU0sRUFBRSxLQUFLLENBQUM7SUFDakUsTUFBTXNGLFNBQVMsR0FBRy9GLFFBQVEsQ0FBQ04sUUFBUSxDQUFDc0csTUFBTSxDQUFFQyxDQUFDLElBQUtBLENBQUMsQ0FBQ3RFLEVBQUUsS0FBS21FLEtBQUssQ0FBQztJQUNqRSxJQUFJQyxTQUFTLENBQUNSLE1BQU0sS0FBS3ZGLFFBQVEsQ0FBQ04sUUFBUSxDQUFDNkYsTUFBTSxFQUFFLE9BQU8sS0FBSztJQUMvRCxNQUFNaEYsZUFBZSxDQUFDcUYsU0FBUyxDQUFDbkYsTUFBTSxFQUFFc0YsU0FBUyxFQUFFL0YsUUFBUSxDQUFDO0lBQzVELE9BQU8sSUFBSTtFQUNiO0VBRUEsYUFBYWtHLGdCQUFnQkEsQ0FBQ3pGLE1BQVcsRUFBRXFGLEtBQWEsRUFBRW5ILE9BQWdCLEVBQW9CO0lBQzVGLE1BQU1xQixRQUFRLEdBQUcsTUFBTU8sZUFBZSxDQUFDYSxXQUFXLENBQUNYLE1BQU0sRUFBRSxLQUFLLENBQUM7SUFDakUsSUFBSTBGLEtBQUssR0FBRyxLQUFLO0lBQ2pCLE1BQU1DLE9BQU8sR0FBR3BHLFFBQVEsQ0FBQ04sUUFBUSxDQUFDK0MsR0FBRyxDQUFFd0QsQ0FBQyxJQUFLO01BQzNDLElBQUlBLENBQUMsQ0FBQ3RFLEVBQUUsS0FBS21FLEtBQUssRUFBRSxPQUFPRyxDQUFDO01BQzVCRSxLQUFLLEdBQUcsSUFBSTtNQUNaLE9BQU87UUFBRSxHQUFHRixDQUFDO1FBQUV0SDtNQUFRLENBQUM7SUFDMUIsQ0FBQyxDQUFDO0lBQ0YsSUFBSSxDQUFDd0gsS0FBSyxFQUFFLE9BQU8sS0FBSztJQUN4QixNQUFNNUYsZUFBZSxDQUFDcUYsU0FBUyxDQUFDbkYsTUFBTSxFQUFFMkYsT0FBTyxFQUFFcEcsUUFBUSxDQUFDO0lBQzFELE9BQU8sSUFBSTtFQUNiOztFQUVBO0FBQ0Y7QUFDQTtBQUNBO0VBQ0UsYUFBYXFHLFlBQVlBLENBQUM1RixNQUFXLEVBQUV3RSxNQUFjLEVBQTBCO0lBQzdFLElBQUksQ0FBQ0EsTUFBTSxFQUFFLE9BQU8sSUFBSTtJQUN4QixNQUFNakYsUUFBUSxHQUFHLE1BQU1PLGVBQWUsQ0FBQ2EsV0FBVyxDQUFDWCxNQUFNLENBQUM7SUFDMUQsTUFBTWlELElBQUksR0FBR25ELGVBQWUsQ0FBQ2dFLE9BQU8sQ0FBQ1UsTUFBTSxDQUFDO0lBQzVDLE1BQU1xQixLQUFLLEdBQUd0RyxRQUFRLENBQUNOLFFBQVEsQ0FBQ2tELElBQUksQ0FBRXFELENBQUMsSUFBS0EsQ0FBQyxDQUFDdkMsSUFBSSxLQUFLQSxJQUFJLENBQUM7SUFDNUQsSUFBSSxDQUFDNEMsS0FBSyxJQUFJLENBQUNBLEtBQUssQ0FBQzNILE9BQU8sRUFBRSxPQUFPLElBQUk7SUFDekMsSUFBSTJILEtBQUssQ0FBQ1gsVUFBVSxJQUFJLElBQUkvRixJQUFJLENBQUMwRyxLQUFLLENBQUNYLFVBQVUsQ0FBQyxDQUFDWSxPQUFPLENBQUMsQ0FBQyxHQUFHM0csSUFBSSxDQUFDMkIsR0FBRyxDQUFDLENBQUMsRUFBRSxPQUFPLElBQUk7SUFDdEYsT0FBTytFLEtBQUs7RUFDZDs7RUFFQTtFQUNBLGFBQWFFLFdBQVdBLENBQUMvRixNQUFXLEVBQUVxRixLQUFhLEVBQWlCO0lBQ2xFLElBQUk7TUFDRixNQUFNOUYsUUFBUSxHQUFHLE1BQU1PLGVBQWUsQ0FBQ2EsV0FBVyxDQUFDWCxNQUFNLEVBQUUsS0FBSyxDQUFDO01BQ2pFLE1BQU0yRixPQUFPLEdBQUdwRyxRQUFRLENBQUNOLFFBQVEsQ0FBQytDLEdBQUcsQ0FBRXdELENBQUMsSUFDdENBLENBQUMsQ0FBQ3RFLEVBQUUsS0FBS21FLEtBQUssR0FBRztRQUFFLEdBQUdHLENBQUM7UUFBRVAsWUFBWSxFQUFFLElBQUk5RixJQUFJLENBQUMsQ0FBQyxDQUFDQyxXQUFXLENBQUM7TUFBRSxDQUFDLEdBQUdvRyxDQUN0RSxDQUFDO01BQ0QsTUFBTTFGLGVBQWUsQ0FBQ3FGLFNBQVMsQ0FBQ25GLE1BQU0sRUFBRTJGLE9BQU8sRUFBRXBHLFFBQVEsQ0FBQztJQUM1RCxDQUFDLENBQUMsT0FBT3lHLEVBQUUsRUFBRTtNQUNYO0lBQUE7RUFFSjtFQUVBLGFBQXFCYixTQUFTQSxDQUFDbkYsTUFBVyxFQUFFaUcsSUFBYyxFQUFFMUcsUUFBd0IsRUFBaUI7SUFDbkcsTUFBTWlDLE1BQU0sR0FBRztNQUFFLEdBQUdqQyxRQUFRO01BQUVOLFFBQVEsRUFBRWdILElBQUk7TUFBRS9HLFVBQVUsRUFBRSxJQUFJQyxJQUFJLENBQUMsQ0FBQyxDQUFDQyxXQUFXLENBQUM7SUFBRSxDQUFDO0lBQ3BGLE1BQU1ZLE1BQU0sQ0FBQ0ksS0FBSyxDQUFDO01BQ2pCQSxLQUFLLEVBQUVDLHlCQUFjO01BQ3JCYSxFQUFFLEVBQUV2RSxlQUFlO01BQ25Cc0QsSUFBSSxFQUFFdUIsTUFBTTtNQUNaYyxPQUFPLEVBQUU7SUFDWCxDQUFDLENBQUM7SUFDRnhDLGVBQWUsQ0FBQ2UsS0FBSyxHQUFHO01BQUU5RSxLQUFLLEVBQUV5RixNQUFNO01BQUVULEVBQUUsRUFBRTVCLElBQUksQ0FBQzJCLEdBQUcsQ0FBQztJQUFFLENBQUM7RUFDM0Q7O0VBRUE7RUFDQSxPQUFPb0YsZUFBZUEsQ0FBQSxFQUFTO0lBQzdCcEcsZUFBZSxDQUFDZSxLQUFLLEdBQUcsSUFBSTtFQUM5QjtBQUNGO0FBQUMvRCxPQUFBLENBQUFnRCxlQUFBLEdBQUFBLGVBQUE7QUFBQXRFLGVBQUEsQ0F4VFlzRSxlQUFlLFdBQzJDLElBQUkifQ==